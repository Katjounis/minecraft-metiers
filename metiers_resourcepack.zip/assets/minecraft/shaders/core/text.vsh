#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
#ifdef IS_GUI
layout(location = 4) out float hudMark;
#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

    // Commerce : encadré du solde. Le « title » (échelle 4, centré) est ramené en haut à gauche, échelle 1.
    // Interface seulement (IS_GUI) : le texte du monde garde le code vanilla tel quel.
#ifdef IS_GUI
    hudMark = 0.0;
    ivec3 hudRgb = ivec3(round(Color.rgb * 255.0));
    if (hudRgb == ivec3(254, 254, 253) || hudRgb == ivec3(254, 200, 65)) {
        hudMark = 1.0;
        float sw = abs(2.0 / ProjMat[0][0]);
        float sh = abs(2.0 / ProjMat[1][1]);
        vec4 clip = gl_Position;
        float sx = (clip.x / clip.w + 1.0) * 0.5 * sw;
        float sy = (1.0 - clip.y / clip.w) * 0.5 * sh;
        float lx = (sx - sw * 0.5) / 4.0 + 41.5;
        float ly = (sy - sh * 0.5) / 4.0 + 10.0;
        float nx = 4.0 + lx;
        float ny = 8.0 + ly;
        gl_Position = vec4(nx / sw * 2.0 - 1.0, 1.0 - ny / sh * 2.0, clip.z / clip.w, 1.0);
    }
#endif
}
