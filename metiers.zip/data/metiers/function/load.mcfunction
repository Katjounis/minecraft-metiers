scoreboard objectives add m.tmp dummy
scoreboard objectives add m.gain dummy
scoreboard objectives add m.const dummy
scoreboard objectives add m.timer dummy
scoreboard objectives add m.pref dummy
scoreboard objectives add m.trig dummy
scoreboard objectives add metiers trigger "Menu métiers"
scoreboard objectives add m.b_lvl dummy
scoreboard objectives add m.b_xp dummy
scoreboard objectives add m.b_need dummy
scoreboard objectives add m.b_bal dummy
scoreboard objectives add m.b_spent dummy
scoreboard objectives add m.b_pal dummy
scoreboard objectives add m.b_pr dummy
scoreboard objectives add m.b_out dummy
scoreboard objectives add m.b_cd dummy
scoreboard objectives add m.b_st dummy
scoreboard objectives add m.dp_b dummy
scoreboard objectives add m.dd_b dummy
scoreboard objectives add m.f_lvl dummy
scoreboard objectives add m.f_xp dummy
scoreboard objectives add m.f_need dummy
scoreboard objectives add m.f_bal dummy
scoreboard objectives add m.f_spent dummy
scoreboard objectives add m.f_pal dummy
scoreboard objectives add m.f_pr dummy
scoreboard objectives add m.f_out dummy
scoreboard objectives add m.f_cd dummy
scoreboard objectives add m.f_st dummy
scoreboard objectives add m.dp_f dummy
scoreboard objectives add m.dd_f dummy
scoreboard objectives add m.m_lvl dummy
scoreboard objectives add m.m_xp dummy
scoreboard objectives add m.m_need dummy
scoreboard objectives add m.m_bal dummy
scoreboard objectives add m.m_spent dummy
scoreboard objectives add m.m_pal dummy
scoreboard objectives add m.m_pr dummy
scoreboard objectives add m.m_out dummy
scoreboard objectives add m.m_cd dummy
scoreboard objectives add m.m_st dummy
scoreboard objectives add m.dp_m dummy
scoreboard objectives add m.dd_m dummy
scoreboard objectives add m.c_lvl dummy
scoreboard objectives add m.c_xp dummy
scoreboard objectives add m.c_need dummy
scoreboard objectives add m.c_bal dummy
scoreboard objectives add m.c_spent dummy
scoreboard objectives add m.c_pal dummy
scoreboard objectives add m.c_pr dummy
scoreboard objectives add m.c_out dummy
scoreboard objectives add m.c_cd dummy
scoreboard objectives add m.c_st dummy
scoreboard objectives add m.dp_c dummy
scoreboard objectives add m.dd_c dummy
scoreboard objectives add m.p_lvl dummy
scoreboard objectives add m.p_xp dummy
scoreboard objectives add m.p_need dummy
scoreboard objectives add m.p_bal dummy
scoreboard objectives add m.p_spent dummy
scoreboard objectives add m.p_pal dummy
scoreboard objectives add m.p_pr dummy
scoreboard objectives add m.p_out dummy
scoreboard objectives add m.p_cd dummy
scoreboard objectives add m.p_st dummy
scoreboard objectives add m.dp_p dummy
scoreboard objectives add m.dd_p dummy
scoreboard objectives add s.b.mi.oak_log minecraft.mined:minecraft.oak_log
scoreboard objectives add s.b.us.oak_log minecraft.used:minecraft.oak_log
scoreboard objectives add s.b.mi.spruce_log minecraft.mined:minecraft.spruce_log
scoreboard objectives add s.b.us.spruce_log minecraft.used:minecraft.spruce_log
scoreboard objectives add s.b.mi.birch_log minecraft.mined:minecraft.birch_log
scoreboard objectives add s.b.us.birch_log minecraft.used:minecraft.birch_log
scoreboard objectives add s.b.mi.jungle_log minecraft.mined:minecraft.jungle_log
scoreboard objectives add s.b.us.jungle_log minecraft.used:minecraft.jungle_log
scoreboard objectives add s.b.mi.acacia_log minecraft.mined:minecraft.acacia_log
scoreboard objectives add s.b.us.acacia_log minecraft.used:minecraft.acacia_log
scoreboard objectives add s.b.mi.dark_oak_log minecraft.mined:minecraft.dark_oak_log
scoreboard objectives add s.b.us.dark_oak_log minecraft.used:minecraft.dark_oak_log
scoreboard objectives add s.b.mi.mangrove_log minecraft.mined:minecraft.mangrove_log
scoreboard objectives add s.b.us.mangrove_log minecraft.used:minecraft.mangrove_log
scoreboard objectives add s.b.mi.cherry_log minecraft.mined:minecraft.cherry_log
scoreboard objectives add s.b.us.cherry_log minecraft.used:minecraft.cherry_log
scoreboard objectives add s.b.mi.pale_oak_log minecraft.mined:minecraft.pale_oak_log
scoreboard objectives add s.b.us.pale_oak_log minecraft.used:minecraft.pale_oak_log
scoreboard objectives add s.b.mi.crimson_stem minecraft.mined:minecraft.crimson_stem
scoreboard objectives add s.b.us.crimson_stem minecraft.used:minecraft.crimson_stem
scoreboard objectives add s.b.mi.warped_stem minecraft.mined:minecraft.warped_stem
scoreboard objectives add s.b.us.warped_stem minecraft.used:minecraft.warped_stem
scoreboard objectives add s.f.pu.wheat minecraft.picked_up:minecraft.wheat
scoreboard objectives add s.f.dr.wheat minecraft.dropped:minecraft.wheat
scoreboard objectives add s.f.pu.carrot minecraft.picked_up:minecraft.carrot
scoreboard objectives add s.f.dr.carrot minecraft.dropped:minecraft.carrot
scoreboard objectives add s.f.us.carrot minecraft.used:minecraft.carrot
scoreboard objectives add s.f.pu.potato minecraft.picked_up:minecraft.potato
scoreboard objectives add s.f.dr.potato minecraft.dropped:minecraft.potato
scoreboard objectives add s.f.us.potato minecraft.used:minecraft.potato
scoreboard objectives add s.f.pu.beetroot minecraft.picked_up:minecraft.beetroot
scoreboard objectives add s.f.dr.beetroot minecraft.dropped:minecraft.beetroot
scoreboard objectives add s.f.pu.melon_slice minecraft.picked_up:minecraft.melon_slice
scoreboard objectives add s.f.dr.melon_slice minecraft.dropped:minecraft.melon_slice
scoreboard objectives add s.f.pu.pumpkin minecraft.picked_up:minecraft.pumpkin
scoreboard objectives add s.f.dr.pumpkin minecraft.dropped:minecraft.pumpkin
scoreboard objectives add s.f.us.pumpkin minecraft.used:minecraft.pumpkin
scoreboard objectives add s.f.pu.nether_wart minecraft.picked_up:minecraft.nether_wart
scoreboard objectives add s.f.dr.nether_wart minecraft.dropped:minecraft.nether_wart
scoreboard objectives add s.f.us.nether_wart minecraft.used:minecraft.nether_wart
scoreboard objectives add s.f.pu.cocoa_beans minecraft.picked_up:minecraft.cocoa_beans
scoreboard objectives add s.f.dr.cocoa_beans minecraft.dropped:minecraft.cocoa_beans
scoreboard objectives add s.f.us.cocoa_beans minecraft.used:minecraft.cocoa_beans
scoreboard objectives add s.f.pu.sweet_berries minecraft.picked_up:minecraft.sweet_berries
scoreboard objectives add s.f.dr.sweet_berries minecraft.dropped:minecraft.sweet_berries
scoreboard objectives add s.f.us.sweet_berries minecraft.used:minecraft.sweet_berries
scoreboard objectives add s.f.pu.sugar_cane minecraft.picked_up:minecraft.sugar_cane
scoreboard objectives add s.f.dr.sugar_cane minecraft.dropped:minecraft.sugar_cane
scoreboard objectives add s.f.us.sugar_cane minecraft.used:minecraft.sugar_cane
scoreboard objectives add s.m.mi.stone minecraft.mined:minecraft.stone
scoreboard objectives add s.m.us.stone minecraft.used:minecraft.stone
scoreboard objectives add s.m.mi.deepslate minecraft.mined:minecraft.deepslate
scoreboard objectives add s.m.us.deepslate minecraft.used:minecraft.deepslate
scoreboard objectives add s.m.mi.andesite minecraft.mined:minecraft.andesite
scoreboard objectives add s.m.us.andesite minecraft.used:minecraft.andesite
scoreboard objectives add s.m.mi.diorite minecraft.mined:minecraft.diorite
scoreboard objectives add s.m.us.diorite minecraft.used:minecraft.diorite
scoreboard objectives add s.m.mi.granite minecraft.mined:minecraft.granite
scoreboard objectives add s.m.us.granite minecraft.used:minecraft.granite
scoreboard objectives add s.m.mi.tuff minecraft.mined:minecraft.tuff
scoreboard objectives add s.m.us.tuff minecraft.used:minecraft.tuff
scoreboard objectives add s.m.mi.netherrack minecraft.mined:minecraft.netherrack
scoreboard objectives add s.m.us.netherrack minecraft.used:minecraft.netherrack
scoreboard objectives add s.m.mi.blackstone minecraft.mined:minecraft.blackstone
scoreboard objectives add s.m.us.blackstone minecraft.used:minecraft.blackstone
scoreboard objectives add s.m.mi.coal_ore minecraft.mined:minecraft.coal_ore
scoreboard objectives add s.m.us.coal_ore minecraft.used:minecraft.coal_ore
scoreboard objectives add s.m.mi.deepslate_coal_ore minecraft.mined:minecraft.deepslate_coal_ore
scoreboard objectives add s.m.us.deepslate_coal_ore minecraft.used:minecraft.deepslate_coal_ore
scoreboard objectives add s.m.mi.copper_ore minecraft.mined:minecraft.copper_ore
scoreboard objectives add s.m.us.copper_ore minecraft.used:minecraft.copper_ore
scoreboard objectives add s.m.mi.deepslate_copper_ore minecraft.mined:minecraft.deepslate_copper_ore
scoreboard objectives add s.m.us.deepslate_copper_ore minecraft.used:minecraft.deepslate_copper_ore
scoreboard objectives add s.m.mi.iron_ore minecraft.mined:minecraft.iron_ore
scoreboard objectives add s.m.us.iron_ore minecraft.used:minecraft.iron_ore
scoreboard objectives add s.m.mi.deepslate_iron_ore minecraft.mined:minecraft.deepslate_iron_ore
scoreboard objectives add s.m.us.deepslate_iron_ore minecraft.used:minecraft.deepslate_iron_ore
scoreboard objectives add s.m.mi.gold_ore minecraft.mined:minecraft.gold_ore
scoreboard objectives add s.m.us.gold_ore minecraft.used:minecraft.gold_ore
scoreboard objectives add s.m.mi.deepslate_gold_ore minecraft.mined:minecraft.deepslate_gold_ore
scoreboard objectives add s.m.us.deepslate_gold_ore minecraft.used:minecraft.deepslate_gold_ore
scoreboard objectives add s.m.mi.redstone_ore minecraft.mined:minecraft.redstone_ore
scoreboard objectives add s.m.us.redstone_ore minecraft.used:minecraft.redstone_ore
scoreboard objectives add s.m.mi.deepslate_redstone_ore minecraft.mined:minecraft.deepslate_redstone_ore
scoreboard objectives add s.m.us.deepslate_redstone_ore minecraft.used:minecraft.deepslate_redstone_ore
scoreboard objectives add s.m.mi.lapis_ore minecraft.mined:minecraft.lapis_ore
scoreboard objectives add s.m.us.lapis_ore minecraft.used:minecraft.lapis_ore
scoreboard objectives add s.m.mi.deepslate_lapis_ore minecraft.mined:minecraft.deepslate_lapis_ore
scoreboard objectives add s.m.us.deepslate_lapis_ore minecraft.used:minecraft.deepslate_lapis_ore
scoreboard objectives add s.m.mi.diamond_ore minecraft.mined:minecraft.diamond_ore
scoreboard objectives add s.m.us.diamond_ore minecraft.used:minecraft.diamond_ore
scoreboard objectives add s.m.mi.deepslate_diamond_ore minecraft.mined:minecraft.deepslate_diamond_ore
scoreboard objectives add s.m.us.deepslate_diamond_ore minecraft.used:minecraft.deepslate_diamond_ore
scoreboard objectives add s.m.mi.emerald_ore minecraft.mined:minecraft.emerald_ore
scoreboard objectives add s.m.us.emerald_ore minecraft.used:minecraft.emerald_ore
scoreboard objectives add s.m.mi.deepslate_emerald_ore minecraft.mined:minecraft.deepslate_emerald_ore
scoreboard objectives add s.m.us.deepslate_emerald_ore minecraft.used:minecraft.deepslate_emerald_ore
scoreboard objectives add s.m.mi.nether_gold_ore minecraft.mined:minecraft.nether_gold_ore
scoreboard objectives add s.m.us.nether_gold_ore minecraft.used:minecraft.nether_gold_ore
scoreboard objectives add s.m.mi.nether_quartz_ore minecraft.mined:minecraft.nether_quartz_ore
scoreboard objectives add s.m.us.nether_quartz_ore minecraft.used:minecraft.nether_quartz_ore
scoreboard objectives add s.m.mi.ancient_debris minecraft.mined:minecraft.ancient_debris
scoreboard objectives add s.m.us.ancient_debris minecraft.used:minecraft.ancient_debris
scoreboard objectives add s.c.kills minecraft.custom:minecraft.mob_kills
scoreboard objectives add s.c.k.wither minecraft.killed:minecraft.wither
scoreboard objectives add s.c.k.ender_dragon minecraft.killed:minecraft.ender_dragon
scoreboard objectives add s.c.k.warden minecraft.killed:minecraft.warden
scoreboard objectives add s.c.k.elder_guardian minecraft.killed:minecraft.elder_guardian
scoreboard objectives add s.p.fish minecraft.custom:minecraft.fish_caught
scoreboard objectives add a.oak_log minecraft.mined:minecraft.oak_log
scoreboard objectives add a.spruce_log minecraft.mined:minecraft.spruce_log
scoreboard objectives add a.birch_log minecraft.mined:minecraft.birch_log
scoreboard objectives add a.jungle_log minecraft.mined:minecraft.jungle_log
scoreboard objectives add a.acacia_log minecraft.mined:minecraft.acacia_log
scoreboard objectives add a.dark_oak_log minecraft.mined:minecraft.dark_oak_log
scoreboard objectives add a.mangrove_log minecraft.mined:minecraft.mangrove_log
scoreboard objectives add a.cherry_log minecraft.mined:minecraft.cherry_log
scoreboard objectives add a.pale_oak_log minecraft.mined:minecraft.pale_oak_log
scoreboard objectives add a.crimson_stem minecraft.mined:minecraft.crimson_stem
scoreboard objectives add a.warped_stem minecraft.mined:minecraft.warped_stem
scoreboard objectives add a.sneak minecraft.custom:minecraft.sneak_time
scoreboard objectives add m.quit minecraft.custom:minecraft.leave_game
scoreboard objectives add m.id dummy
scoreboard objectives add m.dshow dummy
scoreboard objectives add m.dall dummy
scoreboard objectives add m.defi dummy
scoreboard objectives add m.heure dummy
scoreboard objectives add m.boss dummy
scoreboard objectives add m.total dummy
scoreboard objectives add m.dmg minecraft.custom:minecraft.damage_dealt
scoreboard objectives add m.dur dummy
scoreboard objectives add dq.b1_0 minecraft.mined:minecraft.oak_log
scoreboard objectives add dq.b2_0 minecraft.mined:minecraft.spruce_log
scoreboard objectives add dq.b3_0 minecraft.mined:minecraft.birch_log
scoreboard objectives add dq.b4_0 minecraft.mined:minecraft.dark_oak_log
scoreboard objectives add dq.b5_0 minecraft.mined:minecraft.oak_log
scoreboard objectives add dq.b5_1 minecraft.mined:minecraft.spruce_log
scoreboard objectives add dq.b5_2 minecraft.mined:minecraft.birch_log
scoreboard objectives add dq.b5_3 minecraft.mined:minecraft.jungle_log
scoreboard objectives add dq.b5_4 minecraft.mined:minecraft.acacia_log
scoreboard objectives add dq.b5_5 minecraft.mined:minecraft.dark_oak_log
scoreboard objectives add dq.b5_6 minecraft.mined:minecraft.mangrove_log
scoreboard objectives add dq.b5_7 minecraft.mined:minecraft.cherry_log
scoreboard objectives add dq.b5_8 minecraft.mined:minecraft.pale_oak_log
scoreboard objectives add dq.b5_9 minecraft.mined:minecraft.crimson_stem
scoreboard objectives add dq.b5_10 minecraft.mined:minecraft.warped_stem
scoreboard objectives add dq.f1_0 minecraft.picked_up:minecraft.wheat
scoreboard objectives add dq.f2_0 minecraft.picked_up:minecraft.carrot
scoreboard objectives add dq.f3_0 minecraft.picked_up:minecraft.potato
scoreboard objectives add dq.f4_0 minecraft.picked_up:minecraft.sugar_cane
scoreboard objectives add dq.f5_0 minecraft.custom:minecraft.animals_bred
scoreboard objectives add dq.m1_0 minecraft.mined:minecraft.stone
scoreboard objectives add dq.m2_0 minecraft.mined:minecraft.deepslate
scoreboard objectives add dq.m3_0 minecraft.mined:minecraft.iron_ore
scoreboard objectives add dq.m3_1 minecraft.mined:minecraft.deepslate_iron_ore
scoreboard objectives add dq.m4_0 minecraft.mined:minecraft.coal_ore
scoreboard objectives add dq.m4_1 minecraft.mined:minecraft.deepslate_coal_ore
scoreboard objectives add dq.m5_0 minecraft.mined:minecraft.diamond_ore
scoreboard objectives add dq.m5_1 minecraft.mined:minecraft.deepslate_diamond_ore
scoreboard objectives add dq.c1_0 minecraft.custom:minecraft.mob_kills
scoreboard objectives add dq.c2_0 minecraft.killed:minecraft.zombie
scoreboard objectives add dq.c3_0 minecraft.killed:minecraft.skeleton
scoreboard objectives add dq.c4_0 minecraft.killed:minecraft.creeper
scoreboard objectives add dq.c5_0 minecraft.killed:minecraft.enderman
scoreboard objectives add dq.p1_0 minecraft.custom:minecraft.fish_caught
scoreboard objectives add dq.p2_0 minecraft.custom:minecraft.fish_caught
scoreboard objectives add dq.p3_0 minecraft.custom:minecraft.boat_one_cm
scoreboard objectives add dq.p4_0 minecraft.custom:minecraft.swim_one_cm
scoreboard objectives add dq.p5_0 minecraft.custom:minecraft.fish_caught
scoreboard players add #job m.heure 0
scoreboard players add #cycle m.heure 0
scoreboard players add #actif m.boss 0
scoreboard players add #compte m.boss 0
scoreboard players add #cycle m.boss 0
bossbar add metiers:heure ""
bossbar set metiers:heure max 3600
bossbar set metiers:heure visible false
bossbar add metiers:boss {"text":"Le Colosse des Métiers","color":"dark_red","bold":true}
bossbar set metiers:boss color red
bossbar set metiers:boss style notched_20
bossbar set metiers:boss max 600
execute unless score #actif m.boss matches 1 run bossbar set metiers:boss visible false
execute in minecraft:overworld run forceload add 0 0
scoreboard players set #1 m.const 1
scoreboard players set #2 m.const 2
scoreboard players set #3 m.const 3
scoreboard players set #4 m.const 4
scoreboard players set #5 m.const 5
scoreboard players set #6 m.const 6
scoreboard players set #8 m.const 8
scoreboard players set #10 m.const 10
scoreboard players set #20 m.const 20
scoreboard players set #25 m.const 25
scoreboard players set #30 m.const 30
scoreboard players set #40 m.const 40
scoreboard players set #60 m.const 60
scoreboard players set #100 m.const 100
scoreboard players set #150 m.const 150
scoreboard players set #300 m.const 300
scoreboard players set #500 m.const 500
scoreboard players set #7200 m.const 7200
function metiers:cmd {c:"gamerule sendCommandFeedback false"}
function metiers:cmd {c:"gamerule send_command_feedback false"}
function metiers:prefixe/equipes
tag @a add metiers.maj
schedule function metiers:loop 10t replace
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Datapack v2 chargé. Tape ","color":"gray"},{"text":"/trigger metiers","color":"yellow"}]
