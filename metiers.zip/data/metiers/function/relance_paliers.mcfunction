tag @s add metiers.v5
tag @s remove metiers.v4
scoreboard players set @s m.b_pal 0
scoreboard players set @s m.f_pal 0
scoreboard players set @s m.m_pal 0
scoreboard players set @s m.c_pal 0
scoreboard players set @s m.p_pal 0
scoreboard players set @s m.e_pal 0
scoreboard players set @s m.n_pal 0
scoreboard players set @s m.x_pal 0
scoreboard players set @s m.t_pal 0
