scoreboard players add #next m.id 1
scoreboard players operation @s m.id = #next m.id
execute store result storage metiers:tmp id int 1 run scoreboard players get @s m.id
function metiers:defis/creer_barre with storage metiers:tmp
