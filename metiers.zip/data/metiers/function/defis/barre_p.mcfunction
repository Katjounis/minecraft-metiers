$bossbar set metiers:d$(id) color blue
$execute if score #d_p m.defi matches 1 run bossbar set metiers:d$(id) name [{"text":"Défi ⚓ Pêcheur : ","color":"aqua","bold":true},{"text":"Pêche 20 poissons  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_p"},"color":"yellow"},{"text":" / 20","color":"gray"}]
$execute if score #d_p m.defi matches 1 run bossbar set metiers:d$(id) max 20
$execute if score #d_p m.defi matches 2 run bossbar set metiers:d$(id) name [{"text":"Défi ⚓ Pêcheur : ","color":"aqua","bold":true},{"text":"Pêche 35 poissons  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_p"},"color":"yellow"},{"text":" / 35","color":"gray"}]
$execute if score #d_p m.defi matches 2 run bossbar set metiers:d$(id) max 35
$execute if score #d_p m.defi matches 3 run bossbar set metiers:d$(id) name [{"text":"Défi ⚓ Pêcheur : ","color":"aqua","bold":true},{"text":"Parcours 1000 m en bateau  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_p"},"color":"yellow"},{"text":" / 1000","color":"gray"}]
$execute if score #d_p m.defi matches 3 run bossbar set metiers:d$(id) max 1000
$execute if score #d_p m.defi matches 4 run bossbar set metiers:d$(id) name [{"text":"Défi ⚓ Pêcheur : ","color":"aqua","bold":true},{"text":"Nage 500 m  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_p"},"color":"yellow"},{"text":" / 500","color":"gray"}]
$execute if score #d_p m.defi matches 4 run bossbar set metiers:d$(id) max 500
$execute if score #d_p m.defi matches 5 run bossbar set metiers:d$(id) name [{"text":"Défi ⚓ Pêcheur : ","color":"aqua","bold":true},{"text":"Pêche 50 poissons  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_p"},"color":"yellow"},{"text":" / 50","color":"gray"}]
$execute if score #d_p m.defi matches 5 run bossbar set metiers:d$(id) max 50
$execute store result bossbar metiers:d$(id) value run scoreboard players get @s m.dp_p
