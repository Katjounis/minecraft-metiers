$bossbar set metiers:d$(id) color purple
$bossbar set metiers:d$(id) style notched_10
$execute if score #d_p m.defi matches 1 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Pêcheur : ","color":"aqua","bold":true},{"text":"Pêche 25 poissons  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_p"},"color":"yellow"},{"text":" / 25","color":"gray"}]
$execute if score #d_p m.defi matches 1 run bossbar set metiers:d$(id) max 25
$execute if score #d_p m.defi matches 2 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Pêcheur : ","color":"aqua","bold":true},{"text":"Pêche 40 poissons  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_p"},"color":"yellow"},{"text":" / 40","color":"gray"}]
$execute if score #d_p m.defi matches 2 run bossbar set metiers:d$(id) max 40
$execute if score #d_p m.defi matches 3 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Pêcheur : ","color":"aqua","bold":true},{"text":"Pêche 12 saumons  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_p"},"color":"yellow"},{"text":" / 12","color":"gray"}]
$execute if score #d_p m.defi matches 3 run bossbar set metiers:d$(id) max 12
$execute if score #d_p m.defi matches 4 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Pêcheur : ","color":"aqua","bold":true},{"text":"Pêche 6 poissons-globes  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_p"},"color":"yellow"},{"text":" / 6","color":"gray"}]
$execute if score #d_p m.defi matches 4 run bossbar set metiers:d$(id) max 6
$execute if score #d_p m.defi matches 5 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Pêcheur : ","color":"aqua","bold":true},{"text":"Parcours 1000 m en bateau  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_p"},"color":"yellow"},{"text":" / 1000","color":"gray"}]
$execute if score #d_p m.defi matches 5 run bossbar set metiers:d$(id) max 1000
$execute if score #d_p m.defi matches 6 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Pêcheur : ","color":"aqua","bold":true},{"text":"Nage 500 m  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_p"},"color":"yellow"},{"text":" / 500","color":"gray"}]
$execute if score #d_p m.defi matches 6 run bossbar set metiers:d$(id) max 500
$execute store result bossbar metiers:d$(id) value run scoreboard players get @s m.dp_p
