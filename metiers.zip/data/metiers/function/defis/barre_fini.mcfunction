$bossbar set metiers:d$(id) name [{"text":"✔ Tous les défis du jour sont faits ! ","color":"green","bold":true},{"text":"Nouveaux défis dans ","color":"white","bold":false},{"score":{"name":"#left","objective":"m.defi"},"color":"yellow"},{"text":" h","color":"white"}]
$bossbar set metiers:d$(id) color green
$bossbar set metiers:d$(id) max 1
$bossbar set metiers:d$(id) value 1
