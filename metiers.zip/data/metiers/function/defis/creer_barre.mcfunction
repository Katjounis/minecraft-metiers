$bossbar add metiers:d$(id) ""
$bossbar set metiers:d$(id) style notched_10
