$bossbar set metiers:d$(id) color yellow
$execute if score #d_b m.defi matches 1 run bossbar set metiers:d$(id) name [{"text":"Défi ♣ Bûcheron : ","color":"gold","bold":true},{"text":"Coupe 128 bûches de chêne  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_b"},"color":"yellow"},{"text":" / 128","color":"gray"}]
$execute if score #d_b m.defi matches 1 run bossbar set metiers:d$(id) max 128
$execute if score #d_b m.defi matches 2 run bossbar set metiers:d$(id) name [{"text":"Défi ♣ Bûcheron : ","color":"gold","bold":true},{"text":"Coupe 128 bûches de sapin  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_b"},"color":"yellow"},{"text":" / 128","color":"gray"}]
$execute if score #d_b m.defi matches 2 run bossbar set metiers:d$(id) max 128
$execute if score #d_b m.defi matches 3 run bossbar set metiers:d$(id) name [{"text":"Défi ♣ Bûcheron : ","color":"gold","bold":true},{"text":"Coupe 128 bûches de bouleau  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_b"},"color":"yellow"},{"text":" / 128","color":"gray"}]
$execute if score #d_b m.defi matches 3 run bossbar set metiers:d$(id) max 128
$execute if score #d_b m.defi matches 4 run bossbar set metiers:d$(id) name [{"text":"Défi ♣ Bûcheron : ","color":"gold","bold":true},{"text":"Coupe 96 bûches de chêne noir  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_b"},"color":"yellow"},{"text":" / 96","color":"gray"}]
$execute if score #d_b m.defi matches 4 run bossbar set metiers:d$(id) max 96
$execute if score #d_b m.defi matches 5 run bossbar set metiers:d$(id) name [{"text":"Défi ♣ Bûcheron : ","color":"gold","bold":true},{"text":"Coupe 256 bûches, toutes essences  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_b"},"color":"yellow"},{"text":" / 256","color":"gray"}]
$execute if score #d_b m.defi matches 5 run bossbar set metiers:d$(id) max 256
$execute store result bossbar metiers:d$(id) value run scoreboard players get @s m.dp_b
