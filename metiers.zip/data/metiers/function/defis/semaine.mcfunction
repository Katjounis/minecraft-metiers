scoreboard players set #semaine m.defi 0
execute store result score #s_def m.defi run random value 1..9
execute store result score #c_def m.defi run random value 1..6
scoreboard players set #c_ok m.defi 0
scoreboard players reset * m.wd
scoreboard players reset * m.wk
scoreboard players reset * m.cc
scoreboard players reset * dw.1_0
scoreboard players reset * dw.1_1
scoreboard players reset * dw.1_2
scoreboard players reset * dw.1_3
scoreboard players reset * dw.1_4
scoreboard players reset * dw.1_5
scoreboard players reset * dw.1_6
scoreboard players reset * dw.1_7
scoreboard players reset * dw.1_8
scoreboard players reset * dw.1_9
scoreboard players reset * dw.1_10
scoreboard players reset * dw.2_0
scoreboard players reset * dw.2_1
scoreboard players reset * dw.2_2
scoreboard players reset * dw.2_3
scoreboard players reset * dw.3_0
scoreboard players reset * dw.3_1
scoreboard players reset * dw.4_0
scoreboard players reset * dw.5_0
scoreboard players reset * dw.6_0
scoreboard players reset * dw.7_0
scoreboard players reset * dw.8_0
scoreboard players reset * dw.8_1
scoreboard players reset * dw.9_0
scoreboard players reset * dc.1_0
scoreboard players reset * dc.1_1
scoreboard players reset * dc.2_0
scoreboard players reset * dc.2_1
scoreboard players reset * dc.2_2
scoreboard players reset * dc.2_3
scoreboard players reset * dc.2_4
scoreboard players reset * dc.2_5
scoreboard players reset * dc.2_6
scoreboard players reset * dc.2_7
scoreboard players reset * dc.2_8
scoreboard players reset * dc.2_9
scoreboard players reset * dc.2_10
scoreboard players reset * dc.3_0
scoreboard players reset * dc.4_0
scoreboard players reset * dc.5_0
scoreboard players reset * dc.6_0
scoreboard players reset * dc.6_1
scoreboard players reset * dc.6_2
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Nouvelle semaine : un défi de la semaine et un défi collectif sont lancés ","color":"light_purple","bold":true},{"text":"(touche G, Défis du jour).","color":"white"}]
