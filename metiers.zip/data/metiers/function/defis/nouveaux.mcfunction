scoreboard players set #jour m.defi 0
execute store result score #d_b m.defi run random value 1..5
scoreboard players reset * m.dd_b
scoreboard players reset * dq.b1_0
scoreboard players reset * dq.b2_0
scoreboard players reset * dq.b3_0
scoreboard players reset * dq.b4_0
scoreboard players reset * dq.b5_0
scoreboard players reset * dq.b5_1
scoreboard players reset * dq.b5_2
scoreboard players reset * dq.b5_3
scoreboard players reset * dq.b5_4
scoreboard players reset * dq.b5_5
scoreboard players reset * dq.b5_6
scoreboard players reset * dq.b5_7
scoreboard players reset * dq.b5_8
scoreboard players reset * dq.b5_9
scoreboard players reset * dq.b5_10
execute store result score #d_f m.defi run random value 1..5
scoreboard players reset * m.dd_f
scoreboard players reset * dq.f1_0
scoreboard players reset * dq.f2_0
scoreboard players reset * dq.f3_0
scoreboard players reset * dq.f4_0
scoreboard players reset * dq.f5_0
execute store result score #d_m m.defi run random value 1..5
scoreboard players reset * m.dd_m
scoreboard players reset * dq.m1_0
scoreboard players reset * dq.m2_0
scoreboard players reset * dq.m3_0
scoreboard players reset * dq.m3_1
scoreboard players reset * dq.m4_0
scoreboard players reset * dq.m4_1
scoreboard players reset * dq.m5_0
scoreboard players reset * dq.m5_1
execute store result score #d_c m.defi run random value 1..5
scoreboard players reset * m.dd_c
scoreboard players reset * dq.c1_0
scoreboard players reset * dq.c2_0
scoreboard players reset * dq.c3_0
scoreboard players reset * dq.c4_0
scoreboard players reset * dq.c5_0
execute store result score #d_p m.defi run random value 1..5
scoreboard players reset * m.dd_p
scoreboard players reset * dq.p1_0
scoreboard players reset * dq.p2_0
scoreboard players reset * dq.p3_0
scoreboard players reset * dq.p4_0
scoreboard players reset * dq.p5_0
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Nouveaux défis du jour ! ","color":"aqua","bold":true},{"text":"Ils défilent dans ta barre de boss (touche G > Défis du jour).","color":"white"}]
