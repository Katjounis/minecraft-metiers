scoreboard players set #jour m.defi 0
execute store result score #d_b m.defi run random value 1..8
scoreboard players reset * m.dd_b
scoreboard players reset * dq.b1_0
scoreboard players reset * dq.b2_0
scoreboard players reset * dq.b3_0
scoreboard players reset * dq.b4_0
scoreboard players reset * dq.b5_0
scoreboard players reset * dq.b6_0
scoreboard players reset * dq.b6_1
scoreboard players reset * dq.b7_0
scoreboard players reset * dq.b8_0
scoreboard players reset * dq.b8_1
scoreboard players reset * dq.b8_2
scoreboard players reset * dq.b8_3
scoreboard players reset * dq.b8_4
scoreboard players reset * dq.b8_5
scoreboard players reset * dq.b8_6
scoreboard players reset * dq.b8_7
scoreboard players reset * dq.b8_8
scoreboard players reset * dq.b8_9
scoreboard players reset * dq.b8_10
execute store result score #d_f m.defi run random value 1..8
scoreboard players reset * m.dd_f
scoreboard players reset * dq.f1_0
scoreboard players reset * dq.f2_0
scoreboard players reset * dq.f3_0
scoreboard players reset * dq.f4_0
scoreboard players reset * dq.f5_0
scoreboard players reset * dq.f6_0
scoreboard players reset * dq.f7_0
scoreboard players reset * dq.f8_0
execute store result score #d_m m.defi run random value 1..9
scoreboard players reset * m.dd_m
scoreboard players reset * dq.m1_0
scoreboard players reset * dq.m2_0
scoreboard players reset * dq.m3_0
scoreboard players reset * dq.m3_1
scoreboard players reset * dq.m4_0
scoreboard players reset * dq.m4_1
scoreboard players reset * dq.m5_0
scoreboard players reset * dq.m5_1
scoreboard players reset * dq.m6_0
scoreboard players reset * dq.m6_1
scoreboard players reset * dq.m7_0
scoreboard players reset * dq.m8_0
scoreboard players reset * dq.m8_1
scoreboard players reset * dq.m9_0
execute store result score #d_c m.defi run random value 1..9
scoreboard players reset * m.dd_c
scoreboard players reset * dq.c1_0
scoreboard players reset * dq.c2_0
scoreboard players reset * dq.c3_0
scoreboard players reset * dq.c4_0
scoreboard players reset * dq.c5_0
scoreboard players reset * dq.c6_0
scoreboard players reset * dq.c7_0
scoreboard players reset * dq.c8_0
scoreboard players reset * dq.c9_0
execute store result score #d_p m.defi run random value 1..6
scoreboard players reset * m.dd_p
scoreboard players reset * dq.p1_0
scoreboard players reset * dq.p2_0
scoreboard players reset * dq.p3_0
scoreboard players reset * dq.p4_0
scoreboard players reset * dq.p5_0
scoreboard players reset * dq.p6_0
execute store result score #d_e m.defi run random value 1..6
scoreboard players reset * m.dd_e
scoreboard players reset * dq.e1_0
scoreboard players reset * dq.e2_0
scoreboard players reset * dq.e3_0
scoreboard players reset * dq.e4_0
scoreboard players reset * dq.e5_0
scoreboard players reset * dq.e6_0
execute store result score #d_n m.defi run random value 1..5
scoreboard players reset * m.dd_n
scoreboard players reset * dq.n1_0
scoreboard players reset * dq.n2_0
scoreboard players reset * dq.n3_0
scoreboard players reset * dq.n4_0
scoreboard players reset * dq.n5_0
execute store result score #d_x m.defi run random value 1..7
scoreboard players reset * m.dd_x
scoreboard players reset * dq.x1_0
scoreboard players reset * dq.x2_0
scoreboard players reset * dq.x3_0
scoreboard players reset * dq.x3_1
scoreboard players reset * dq.x4_0
scoreboard players reset * dq.x5_0
scoreboard players reset * dq.x6_0
scoreboard players reset * dq.x7_0
execute store result score #d_t m.defi run random value 1..4
scoreboard players reset * m.dd_t
scoreboard players reset * dq.t1_0
scoreboard players reset * dq.t2_0
scoreboard players reset * dq.t3_0
scoreboard players reset * dq.t4_0
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Nouveaux défis du jour ! ","color":"aqua","bold":true},{"text":"Ils défilent dans ta barre de boss (touche G > Défis du jour).","color":"white"}]
