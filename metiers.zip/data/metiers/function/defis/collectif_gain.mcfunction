scoreboard players set @s m.wk 1
scoreboard players add @s m.ecl 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Défi collectif : +1 ","color":"light_purple"},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" éclat de boss.","color":"light_purple"}]
