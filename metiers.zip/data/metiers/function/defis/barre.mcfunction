$bossbar set metiers:d$(id) players @s
$execute if entity @s[tag=metiers.nobar] run bossbar set metiers:d$(id) visible false
execute if entity @s[tag=metiers.nobar] run return 0
$bossbar set metiers:d$(id) visible true
$execute if score @s m.dall matches 5 run function metiers:defis/barre_fini {id:$(id)}
execute if score @s m.dall matches 5 run return 0
$execute if score @s m.dshow matches 1 run function metiers:defis/barre_b {id:$(id)}
$execute if score @s m.dshow matches 2 run function metiers:defis/barre_f {id:$(id)}
$execute if score @s m.dshow matches 3 run function metiers:defis/barre_m {id:$(id)}
$execute if score @s m.dshow matches 4 run function metiers:defis/barre_c {id:$(id)}
$execute if score @s m.dshow matches 5 run function metiers:defis/barre_p {id:$(id)}
