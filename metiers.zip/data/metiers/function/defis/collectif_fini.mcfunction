scoreboard players set #c_ok m.defi 1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Défi collectif réussi ! ","color":"light_purple","bold":true},{"text":"Chaque joueur qui y a participé (2 % de l'objectif) reçoit un éclat de boss.","color":"white"}]
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.9
