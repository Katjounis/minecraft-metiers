give @s minecraft:enchanted_golden_apple 1
give @s minecraft:netherite_scrap 2
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" a réussi les 5 défis du jour !","color":"gold","bold":true}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 0.5
