scoreboard players add @s m.cr_b 2
scoreboard players add @s m.cr_f 2
scoreboard players add @s m.cr_m 2
scoreboard players add @s m.cr_c 2
scoreboard players add @s m.cr_p 2
scoreboard players add @s m.cr_e 2
scoreboard players add @s m.cr_n 2
scoreboard players add @s m.cr_x 2
scoreboard players add @s m.cr_t 2
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" a réussi tous les défis du jour ! +2 cristaux de chaque métier.","color":"gold","bold":true}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 0.5
