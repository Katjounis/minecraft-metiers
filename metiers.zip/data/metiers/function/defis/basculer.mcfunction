execute if entity @s[tag=metiers.nobar] run tag @s add metiers.barre_on
tag @s[tag=metiers.barre_on] remove metiers.nobar
execute unless entity @s[tag=metiers.barre_on] run tag @s add metiers.nobar
execute if entity @s[tag=metiers.nobar] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Barre des défis masquée.","color":"gray"}]
execute if entity @s[tag=metiers.barre_on] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Barre des défis affichée.","color":"gray"}]
tag @s remove metiers.barre_on
function metiers:defis/menu
