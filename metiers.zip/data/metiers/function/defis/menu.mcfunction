data modify storage metiers:defis wd set value "aucun"
data modify storage metiers:defis cd set value "aucun"
data modify storage metiers:defis wt set value 0
data modify storage metiers:defis cg set value 0
data modify storage metiers:defis cm set value 0
data modify storage metiers:defis wj set value ""
data modify storage metiers:defis b_d set value "aucun"
data modify storage metiers:defis f_d set value "aucun"
data modify storage metiers:defis m_d set value "aucun"
data modify storage metiers:defis c_d set value "aucun"
data modify storage metiers:defis p_d set value "aucun"
data modify storage metiers:defis e_d set value "aucun"
data modify storage metiers:defis n_d set value "aucun"
data modify storage metiers:defis x_d set value "aucun"
data modify storage metiers:defis t_d set value "aucun"
data modify storage metiers:defis b_t set value 0
data modify storage metiers:defis f_t set value 0
data modify storage metiers:defis m_t set value 0
data modify storage metiers:defis c_t set value 0
data modify storage metiers:defis p_t set value 0
data modify storage metiers:defis e_t set value 0
data modify storage metiers:defis n_t set value 0
data modify storage metiers:defis x_t set value 0
data modify storage metiers:defis t_t set value 0
function metiers:defis/joueur
execute store result storage metiers:defis left int 1 run scoreboard players get #left m.defi
execute store result storage metiers:defis sleft int 1 run scoreboard players get #sleft m.defi
execute store result storage metiers:defis wp int 1 run scoreboard players get @s m.wp
execute store result storage metiers:defis cc int 1 run scoreboard players get @s m.cc
execute store result storage metiers:defis ct int 1 run scoreboard players get #c_tot m.defi
data modify storage metiers:defis wok set value ""
execute if score @s m.wd matches 1 run data modify storage metiers:defis wok set value "  ✔ réussi"
data modify storage metiers:defis cok set value ""
execute if score #c_ok m.defi matches 1 run data modify storage metiers:defis cok set value "  ✔ réussi"
execute if score #s_def m.defi matches 1 run data modify storage metiers:defis wd set value "Coupe 1000 bûches"
execute if score #s_def m.defi matches 1 run data modify storage metiers:defis wt set value 1000
execute if score #s_def m.defi matches 1 run data modify storage metiers:defis wj set value ""
execute if score #s_def m.defi matches 2 run data modify storage metiers:defis wd set value "Récolte 1500 cultures"
execute if score #s_def m.defi matches 2 run data modify storage metiers:defis wt set value 1500
execute if score #s_def m.defi matches 2 run data modify storage metiers:defis wj set value ""
execute if score #s_def m.defi matches 3 run data modify storage metiers:defis wd set value "Mine 3000 blocs de pierre ou deepslate"
execute if score #s_def m.defi matches 3 run data modify storage metiers:defis wt set value 3000
execute if score #s_def m.defi matches 3 run data modify storage metiers:defis wj set value ""
execute if score #s_def m.defi matches 4 run data modify storage metiers:defis wd set value "Élimine 400 créatures"
execute if score #s_def m.defi matches 4 run data modify storage metiers:defis wt set value 400
execute if score #s_def m.defi matches 4 run data modify storage metiers:defis wj set value ""
execute if score #s_def m.defi matches 5 run data modify storage metiers:defis wd set value "Pêche 200 poissons"
execute if score #s_def m.defi matches 5 run data modify storage metiers:defis wt set value 200
execute if score #s_def m.defi matches 5 run data modify storage metiers:defis wj set value ""
execute if score #s_def m.defi matches 6 run data modify storage metiers:defis wd set value "Fais naître 120 animaux"
execute if score #s_def m.defi matches 6 run data modify storage metiers:defis wt set value 120
execute if score #s_def m.defi matches 6 run data modify storage metiers:defis wj set value ""
execute if score #s_def m.defi matches 7 run data modify storage metiers:defis wd set value "Enchante 40 objets"
execute if score #s_def m.defi matches 7 run data modify storage metiers:defis wt set value 40
execute if score #s_def m.defi matches 7 run data modify storage metiers:defis wj set value ""
execute if score #s_def m.defi matches 8 run data modify storage metiers:defis wd set value "Parcours 40 km à pied"
execute if score #s_def m.defi matches 8 run data modify storage metiers:defis wt set value 40000
execute if score #s_def m.defi matches 8 run data modify storage metiers:defis wj set value ""
execute if score #s_def m.defi matches 9 run data modify storage metiers:defis wd set value "Fais 150 échanges"
execute if score #s_def m.defi matches 9 run data modify storage metiers:defis wt set value 150
execute if score #s_def m.defi matches 9 run data modify storage metiers:defis wj set value ""
execute if score #c_def m.defi matches 1 run data modify storage metiers:defis cd set value "Ensemble : minez 10 000 blocs de pierre"
execute if score #c_def m.defi matches 1 run data modify storage metiers:defis cg set value 10000
execute if score #c_def m.defi matches 1 run data modify storage metiers:defis cm set value 200
execute if score #c_def m.defi matches 2 run data modify storage metiers:defis cd set value "Ensemble : coupez 3000 bûches"
execute if score #c_def m.defi matches 2 run data modify storage metiers:defis cg set value 3000
execute if score #c_def m.defi matches 2 run data modify storage metiers:defis cm set value 60
execute if score #c_def m.defi matches 3 run data modify storage metiers:defis cd set value "Ensemble : éliminez 1500 créatures"
execute if score #c_def m.defi matches 3 run data modify storage metiers:defis cg set value 1500
execute if score #c_def m.defi matches 3 run data modify storage metiers:defis cm set value 30
execute if score #c_def m.defi matches 4 run data modify storage metiers:defis cd set value "Ensemble : pêchez 400 poissons"
execute if score #c_def m.defi matches 4 run data modify storage metiers:defis cg set value 400
execute if score #c_def m.defi matches 4 run data modify storage metiers:defis cm set value 8
execute if score #c_def m.defi matches 5 run data modify storage metiers:defis cd set value "Ensemble : faites 400 échanges"
execute if score #c_def m.defi matches 5 run data modify storage metiers:defis cg set value 400
execute if score #c_def m.defi matches 5 run data modify storage metiers:defis cm set value 8
execute if score #c_def m.defi matches 6 run data modify storage metiers:defis cd set value "Ensemble : récoltez 4000 cultures"
execute if score #c_def m.defi matches 6 run data modify storage metiers:defis cg set value 4000
execute if score #c_def m.defi matches 6 run data modify storage metiers:defis cm set value 80
execute store result storage metiers:defis b_p int 1 run scoreboard players get @s m.dp_b
data modify storage metiers:defis b_ok set value ""
execute if score @s m.dd_b matches 1 run data modify storage metiers:defis b_ok set value "  ✔"
execute if score #d_b m.defi matches 1 run data modify storage metiers:defis b_d set value "Coupe 128 bûches de chêne"
execute if score #d_b m.defi matches 1 run data modify storage metiers:defis b_t set value 128
execute if score #d_b m.defi matches 2 run data modify storage metiers:defis b_d set value "Coupe 128 bûches de sapin"
execute if score #d_b m.defi matches 2 run data modify storage metiers:defis b_t set value 128
execute if score #d_b m.defi matches 3 run data modify storage metiers:defis b_d set value "Coupe 96 bûches de bouleau"
execute if score #d_b m.defi matches 3 run data modify storage metiers:defis b_t set value 96
execute if score #d_b m.defi matches 4 run data modify storage metiers:defis b_d set value "Coupe 96 bûches de chêne noir"
execute if score #d_b m.defi matches 4 run data modify storage metiers:defis b_t set value 96
execute if score #d_b m.defi matches 5 run data modify storage metiers:defis b_d set value "Coupe 64 bûches de cerisier"
execute if score #d_b m.defi matches 5 run data modify storage metiers:defis b_t set value 64
execute if score #d_b m.defi matches 6 run data modify storage metiers:defis b_d set value "Coupe 96 tiges du Nether"
execute if score #d_b m.defi matches 6 run data modify storage metiers:defis b_t set value 96
execute if score #d_b m.defi matches 7 run data modify storage metiers:defis b_d set value "Ramasse 12 pommes"
execute if score #d_b m.defi matches 7 run data modify storage metiers:defis b_t set value 12
execute if score #d_b m.defi matches 8 run data modify storage metiers:defis b_d set value "Coupe 256 bûches, toutes essences"
execute if score #d_b m.defi matches 8 run data modify storage metiers:defis b_t set value 256
execute store result storage metiers:defis f_p int 1 run scoreboard players get @s m.dp_f
data modify storage metiers:defis f_ok set value ""
execute if score @s m.dd_f matches 1 run data modify storage metiers:defis f_ok set value "  ✔"
execute if score #d_f m.defi matches 1 run data modify storage metiers:defis f_d set value "Récolte 192 blés"
execute if score #d_f m.defi matches 1 run data modify storage metiers:defis f_t set value 192
execute if score #d_f m.defi matches 2 run data modify storage metiers:defis f_d set value "Récolte 160 carottes"
execute if score #d_f m.defi matches 2 run data modify storage metiers:defis f_t set value 160
execute if score #d_f m.defi matches 3 run data modify storage metiers:defis f_d set value "Récolte 160 pommes de terre"
execute if score #d_f m.defi matches 3 run data modify storage metiers:defis f_t set value 160
execute if score #d_f m.defi matches 4 run data modify storage metiers:defis f_d set value "Récolte 96 betteraves"
execute if score #d_f m.defi matches 4 run data modify storage metiers:defis f_t set value 96
execute if score #d_f m.defi matches 5 run data modify storage metiers:defis f_d set value "Récolte 96 cannes à sucre"
execute if score #d_f m.defi matches 5 run data modify storage metiers:defis f_t set value 96
execute if score #d_f m.defi matches 6 run data modify storage metiers:defis f_d set value "Récolte 48 melons"
execute if score #d_f m.defi matches 6 run data modify storage metiers:defis f_t set value 48
execute if score #d_f m.defi matches 7 run data modify storage metiers:defis f_d set value "Récolte 32 citrouilles"
execute if score #d_f m.defi matches 7 run data modify storage metiers:defis f_t set value 32
execute if score #d_f m.defi matches 8 run data modify storage metiers:defis f_d set value "Cuis 32 pains"
execute if score #d_f m.defi matches 8 run data modify storage metiers:defis f_t set value 32
execute store result storage metiers:defis m_p int 1 run scoreboard players get @s m.dp_m
data modify storage metiers:defis m_ok set value ""
execute if score @s m.dd_m matches 1 run data modify storage metiers:defis m_ok set value "  ✔"
execute if score #d_m m.defi matches 1 run data modify storage metiers:defis m_d set value "Mine 512 blocs de pierre"
execute if score #d_m m.defi matches 1 run data modify storage metiers:defis m_t set value 512
execute if score #d_m m.defi matches 2 run data modify storage metiers:defis m_d set value "Mine 256 blocs de deepslate"
execute if score #d_m m.defi matches 2 run data modify storage metiers:defis m_t set value 256
execute if score #d_m m.defi matches 3 run data modify storage metiers:defis m_d set value "Mine 24 minerais de fer"
execute if score #d_m m.defi matches 3 run data modify storage metiers:defis m_t set value 24
execute if score #d_m m.defi matches 4 run data modify storage metiers:defis m_d set value "Mine 48 minerais de charbon"
execute if score #d_m m.defi matches 4 run data modify storage metiers:defis m_t set value 48
execute if score #d_m m.defi matches 5 run data modify storage metiers:defis m_d set value "Mine 32 minerais de cuivre"
execute if score #d_m m.defi matches 5 run data modify storage metiers:defis m_t set value 32
execute if score #d_m m.defi matches 6 run data modify storage metiers:defis m_d set value "Mine 12 minerais de redstone"
execute if score #d_m m.defi matches 6 run data modify storage metiers:defis m_t set value 12
execute if score #d_m m.defi matches 7 run data modify storage metiers:defis m_d set value "Mine 24 quartz du Nether"
execute if score #d_m m.defi matches 7 run data modify storage metiers:defis m_t set value 24
execute if score #d_m m.defi matches 8 run data modify storage metiers:defis m_d set value "Mine 4 minerais de diamant"
execute if score #d_m m.defi matches 8 run data modify storage metiers:defis m_t set value 4
execute if score #d_m m.defi matches 9 run data modify storage metiers:defis m_d set value "Mine 2 débris antiques"
execute if score #d_m m.defi matches 9 run data modify storage metiers:defis m_t set value 2
execute store result storage metiers:defis c_p int 1 run scoreboard players get @s m.dp_c
data modify storage metiers:defis c_ok set value ""
execute if score @s m.dd_c matches 1 run data modify storage metiers:defis c_ok set value "  ✔"
execute if score #d_c m.defi matches 1 run data modify storage metiers:defis c_d set value "Élimine 60 créatures"
execute if score #d_c m.defi matches 1 run data modify storage metiers:defis c_t set value 60
execute if score #d_c m.defi matches 2 run data modify storage metiers:defis c_d set value "Élimine 25 zombies"
execute if score #d_c m.defi matches 2 run data modify storage metiers:defis c_t set value 25
execute if score #d_c m.defi matches 3 run data modify storage metiers:defis c_d set value "Élimine 25 squelettes"
execute if score #d_c m.defi matches 3 run data modify storage metiers:defis c_t set value 25
execute if score #d_c m.defi matches 4 run data modify storage metiers:defis c_d set value "Élimine 12 creepers"
execute if score #d_c m.defi matches 4 run data modify storage metiers:defis c_t set value 12
execute if score #d_c m.defi matches 5 run data modify storage metiers:defis c_d set value "Élimine 15 araignées"
execute if score #d_c m.defi matches 5 run data modify storage metiers:defis c_t set value 15
execute if score #d_c m.defi matches 6 run data modify storage metiers:defis c_d set value "Élimine 10 endermen"
execute if score #d_c m.defi matches 6 run data modify storage metiers:defis c_t set value 10
execute if score #d_c m.defi matches 7 run data modify storage metiers:defis c_d set value "Élimine 6 sorcières"
execute if score #d_c m.defi matches 7 run data modify storage metiers:defis c_t set value 6
execute if score #d_c m.defi matches 8 run data modify storage metiers:defis c_d set value "Élimine 8 blazes"
execute if score #d_c m.defi matches 8 run data modify storage metiers:defis c_t set value 8
execute if score #d_c m.defi matches 9 run data modify storage metiers:defis c_d set value "Élimine 15 noyés"
execute if score #d_c m.defi matches 9 run data modify storage metiers:defis c_t set value 15
execute store result storage metiers:defis p_p int 1 run scoreboard players get @s m.dp_p
data modify storage metiers:defis p_ok set value ""
execute if score @s m.dd_p matches 1 run data modify storage metiers:defis p_ok set value "  ✔"
execute if score #d_p m.defi matches 1 run data modify storage metiers:defis p_d set value "Pêche 25 poissons"
execute if score #d_p m.defi matches 1 run data modify storage metiers:defis p_t set value 25
execute if score #d_p m.defi matches 2 run data modify storage metiers:defis p_d set value "Pêche 40 poissons"
execute if score #d_p m.defi matches 2 run data modify storage metiers:defis p_t set value 40
execute if score #d_p m.defi matches 3 run data modify storage metiers:defis p_d set value "Pêche 12 saumons"
execute if score #d_p m.defi matches 3 run data modify storage metiers:defis p_t set value 12
execute if score #d_p m.defi matches 4 run data modify storage metiers:defis p_d set value "Pêche 6 poissons-globes"
execute if score #d_p m.defi matches 4 run data modify storage metiers:defis p_t set value 6
execute if score #d_p m.defi matches 5 run data modify storage metiers:defis p_d set value "Parcours 1000 m en bateau"
execute if score #d_p m.defi matches 5 run data modify storage metiers:defis p_t set value 1000
execute if score #d_p m.defi matches 6 run data modify storage metiers:defis p_d set value "Nage 500 m"
execute if score #d_p m.defi matches 6 run data modify storage metiers:defis p_t set value 500
execute store result storage metiers:defis e_p int 1 run scoreboard players get @s m.dp_e
data modify storage metiers:defis e_ok set value ""
execute if score @s m.dd_e matches 1 run data modify storage metiers:defis e_ok set value "  ✔"
execute if score #d_e m.defi matches 1 run data modify storage metiers:defis e_d set value "Fais naître 12 animaux"
execute if score #d_e m.defi matches 1 run data modify storage metiers:defis e_t set value 12
execute if score #d_e m.defi matches 2 run data modify storage metiers:defis e_d set value "Fais naître 24 animaux"
execute if score #d_e m.defi matches 2 run data modify storage metiers:defis e_t set value 24
execute if score #d_e m.defi matches 3 run data modify storage metiers:defis e_d set value "Tonds 32 laines blanches"
execute if score #d_e m.defi matches 3 run data modify storage metiers:defis e_t set value 32
execute if score #d_e m.defi matches 4 run data modify storage metiers:defis e_d set value "Ramasse 32 œufs"
execute if score #d_e m.defi matches 4 run data modify storage metiers:defis e_t set value 32
execute if score #d_e m.defi matches 5 run data modify storage metiers:defis e_d set value "Ramasse 16 cuirs"
execute if score #d_e m.defi matches 5 run data modify storage metiers:defis e_t set value 16
execute if score #d_e m.defi matches 6 run data modify storage metiers:defis e_d set value "Ramasse 32 plumes"
execute if score #d_e m.defi matches 6 run data modify storage metiers:defis e_t set value 32
execute store result storage metiers:defis n_p int 1 run scoreboard players get @s m.dp_n
data modify storage metiers:defis n_ok set value ""
execute if score @s m.dd_n matches 1 run data modify storage metiers:defis n_ok set value "  ✔"
execute if score #d_n m.defi matches 1 run data modify storage metiers:defis n_d set value "Enchante 3 objets"
execute if score #d_n m.defi matches 1 run data modify storage metiers:defis n_t set value 3
execute if score #d_n m.defi matches 2 run data modify storage metiers:defis n_d set value "Enchante 5 objets"
execute if score #d_n m.defi matches 2 run data modify storage metiers:defis n_t set value 5
execute if score #d_n m.defi matches 3 run data modify storage metiers:defis n_d set value "Enchante 8 objets"
execute if score #d_n m.defi matches 3 run data modify storage metiers:defis n_t set value 8
execute if score #d_n m.defi matches 4 run data modify storage metiers:defis n_d set value "Fabrique 24 livres"
execute if score #d_n m.defi matches 4 run data modify storage metiers:defis n_t set value 24
execute if score #d_n m.defi matches 5 run data modify storage metiers:defis n_d set value "Fabrique 8 bibliothèques"
execute if score #d_n m.defi matches 5 run data modify storage metiers:defis n_t set value 8
execute store result storage metiers:defis x_p int 1 run scoreboard players get @s m.dp_x
data modify storage metiers:defis x_ok set value ""
execute if score @s m.dd_x matches 1 run data modify storage metiers:defis x_ok set value "  ✔"
execute if score #d_x m.defi matches 1 run data modify storage metiers:defis x_d set value "Marche 3000 m"
execute if score #d_x m.defi matches 1 run data modify storage metiers:defis x_t set value 3000
execute if score #d_x m.defi matches 2 run data modify storage metiers:defis x_d set value "Sprinte 2000 m"
execute if score #d_x m.defi matches 2 run data modify storage metiers:defis x_t set value 2000
execute if score #d_x m.defi matches 3 run data modify storage metiers:defis x_d set value "Parcours 5000 m à pied"
execute if score #d_x m.defi matches 3 run data modify storage metiers:defis x_t set value 5000
execute if score #d_x m.defi matches 4 run data modify storage metiers:defis x_d set value "Vole 5000 m en élytres"
execute if score #d_x m.defi matches 4 run data modify storage metiers:defis x_t set value 5000
execute if score #d_x m.defi matches 5 run data modify storage metiers:defis x_d set value "Parcours 3000 m à cheval"
execute if score #d_x m.defi matches 5 run data modify storage metiers:defis x_t set value 3000
execute if score #d_x m.defi matches 6 run data modify storage metiers:defis x_d set value "Grimpe 150 m"
execute if score #d_x m.defi matches 6 run data modify storage metiers:defis x_t set value 150
execute if score #d_x m.defi matches 7 run data modify storage metiers:defis x_d set value "Marche 300 m sous l'eau"
execute if score #d_x m.defi matches 7 run data modify storage metiers:defis x_t set value 300
execute store result storage metiers:defis t_p int 1 run scoreboard players get @s m.dp_t
data modify storage metiers:defis t_ok set value ""
execute if score @s m.dd_t matches 1 run data modify storage metiers:defis t_ok set value "  ✔"
execute if score #d_t m.defi matches 1 run data modify storage metiers:defis t_d set value "Fais 8 échanges"
execute if score #d_t m.defi matches 1 run data modify storage metiers:defis t_t set value 8
execute if score #d_t m.defi matches 2 run data modify storage metiers:defis t_d set value "Fais 16 échanges"
execute if score #d_t m.defi matches 2 run data modify storage metiers:defis t_t set value 16
execute if score #d_t m.defi matches 3 run data modify storage metiers:defis t_d set value "Fais 24 échanges"
execute if score #d_t m.defi matches 3 run data modify storage metiers:defis t_t set value 24
execute if score #d_t m.defi matches 4 run data modify storage metiers:defis t_d set value "Parle à 15 villageois"
execute if score #d_t m.defi matches 4 run data modify storage metiers:defis t_t set value 15
function metiers:defis/menu_dialog with storage metiers:defis
