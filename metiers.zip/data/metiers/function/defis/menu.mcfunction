function metiers:defis/joueur
execute store result storage metiers:defis left int 1 run scoreboard players get #left m.defi
execute store result storage metiers:defis b_p int 1 run scoreboard players get @s m.dp_b
data modify storage metiers:defis b_ok set value ""
execute if score @s m.dd_b matches 1 run data modify storage metiers:defis b_ok set value "  ✔ réussi"
execute if score #d_b m.defi matches 1 run data modify storage metiers:defis b_d set value "Coupe 128 bûches de chêne"
execute if score #d_b m.defi matches 1 run data modify storage metiers:defis b_t set value 128
execute if score #d_b m.defi matches 2 run data modify storage metiers:defis b_d set value "Coupe 128 bûches de sapin"
execute if score #d_b m.defi matches 2 run data modify storage metiers:defis b_t set value 128
execute if score #d_b m.defi matches 3 run data modify storage metiers:defis b_d set value "Coupe 128 bûches de bouleau"
execute if score #d_b m.defi matches 3 run data modify storage metiers:defis b_t set value 128
execute if score #d_b m.defi matches 4 run data modify storage metiers:defis b_d set value "Coupe 96 bûches de chêne noir"
execute if score #d_b m.defi matches 4 run data modify storage metiers:defis b_t set value 96
execute if score #d_b m.defi matches 5 run data modify storage metiers:defis b_d set value "Coupe 256 bûches, toutes essences"
execute if score #d_b m.defi matches 5 run data modify storage metiers:defis b_t set value 256
execute store result storage metiers:defis f_p int 1 run scoreboard players get @s m.dp_f
data modify storage metiers:defis f_ok set value ""
execute if score @s m.dd_f matches 1 run data modify storage metiers:defis f_ok set value "  ✔ réussi"
execute if score #d_f m.defi matches 1 run data modify storage metiers:defis f_d set value "Récolte 192 blés"
execute if score #d_f m.defi matches 1 run data modify storage metiers:defis f_t set value 192
execute if score #d_f m.defi matches 2 run data modify storage metiers:defis f_d set value "Récolte 160 carottes"
execute if score #d_f m.defi matches 2 run data modify storage metiers:defis f_t set value 160
execute if score #d_f m.defi matches 3 run data modify storage metiers:defis f_d set value "Récolte 160 pommes de terre"
execute if score #d_f m.defi matches 3 run data modify storage metiers:defis f_t set value 160
execute if score #d_f m.defi matches 4 run data modify storage metiers:defis f_d set value "Récolte 96 cannes à sucre"
execute if score #d_f m.defi matches 4 run data modify storage metiers:defis f_t set value 96
execute if score #d_f m.defi matches 5 run data modify storage metiers:defis f_d set value "Fais naître 12 animaux"
execute if score #d_f m.defi matches 5 run data modify storage metiers:defis f_t set value 12
execute store result storage metiers:defis m_p int 1 run scoreboard players get @s m.dp_m
data modify storage metiers:defis m_ok set value ""
execute if score @s m.dd_m matches 1 run data modify storage metiers:defis m_ok set value "  ✔ réussi"
execute if score #d_m m.defi matches 1 run data modify storage metiers:defis m_d set value "Mine 512 blocs de pierre"
execute if score #d_m m.defi matches 1 run data modify storage metiers:defis m_t set value 512
execute if score #d_m m.defi matches 2 run data modify storage metiers:defis m_d set value "Mine 256 blocs de deepslate"
execute if score #d_m m.defi matches 2 run data modify storage metiers:defis m_t set value 256
execute if score #d_m m.defi matches 3 run data modify storage metiers:defis m_d set value "Mine 24 minerais de fer"
execute if score #d_m m.defi matches 3 run data modify storage metiers:defis m_t set value 24
execute if score #d_m m.defi matches 4 run data modify storage metiers:defis m_d set value "Mine 48 minerais de charbon"
execute if score #d_m m.defi matches 4 run data modify storage metiers:defis m_t set value 48
execute if score #d_m m.defi matches 5 run data modify storage metiers:defis m_d set value "Mine 4 minerais de diamant"
execute if score #d_m m.defi matches 5 run data modify storage metiers:defis m_t set value 4
execute store result storage metiers:defis c_p int 1 run scoreboard players get @s m.dp_c
data modify storage metiers:defis c_ok set value ""
execute if score @s m.dd_c matches 1 run data modify storage metiers:defis c_ok set value "  ✔ réussi"
execute if score #d_c m.defi matches 1 run data modify storage metiers:defis c_d set value "Élimine 60 créatures"
execute if score #d_c m.defi matches 1 run data modify storage metiers:defis c_t set value 60
execute if score #d_c m.defi matches 2 run data modify storage metiers:defis c_d set value "Élimine 25 zombies"
execute if score #d_c m.defi matches 2 run data modify storage metiers:defis c_t set value 25
execute if score #d_c m.defi matches 3 run data modify storage metiers:defis c_d set value "Élimine 25 squelettes"
execute if score #d_c m.defi matches 3 run data modify storage metiers:defis c_t set value 25
execute if score #d_c m.defi matches 4 run data modify storage metiers:defis c_d set value "Élimine 12 creepers"
execute if score #d_c m.defi matches 4 run data modify storage metiers:defis c_t set value 12
execute if score #d_c m.defi matches 5 run data modify storage metiers:defis c_d set value "Élimine 10 endermen"
execute if score #d_c m.defi matches 5 run data modify storage metiers:defis c_t set value 10
execute store result storage metiers:defis p_p int 1 run scoreboard players get @s m.dp_p
data modify storage metiers:defis p_ok set value ""
execute if score @s m.dd_p matches 1 run data modify storage metiers:defis p_ok set value "  ✔ réussi"
execute if score #d_p m.defi matches 1 run data modify storage metiers:defis p_d set value "Pêche 20 poissons"
execute if score #d_p m.defi matches 1 run data modify storage metiers:defis p_t set value 20
execute if score #d_p m.defi matches 2 run data modify storage metiers:defis p_d set value "Pêche 35 poissons"
execute if score #d_p m.defi matches 2 run data modify storage metiers:defis p_t set value 35
execute if score #d_p m.defi matches 3 run data modify storage metiers:defis p_d set value "Parcours 1000 m en bateau"
execute if score #d_p m.defi matches 3 run data modify storage metiers:defis p_t set value 1000
execute if score #d_p m.defi matches 4 run data modify storage metiers:defis p_d set value "Nage 500 m"
execute if score #d_p m.defi matches 4 run data modify storage metiers:defis p_t set value 500
execute if score #d_p m.defi matches 5 run data modify storage metiers:defis p_d set value "Pêche 50 poissons"
execute if score #d_p m.defi matches 5 run data modify storage metiers:defis p_t set value 50
function metiers:defis/menu_dialog with storage metiers:defis
