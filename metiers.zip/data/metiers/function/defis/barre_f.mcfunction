$bossbar set metiers:d$(id) color green
$execute if score #d_f m.defi matches 1 run bossbar set metiers:d$(id) name [{"text":"Défi ☘ Fermier : ","color":"green","bold":true},{"text":"Récolte 192 blés  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_f"},"color":"yellow"},{"text":" / 192","color":"gray"}]
$execute if score #d_f m.defi matches 1 run bossbar set metiers:d$(id) max 192
$execute if score #d_f m.defi matches 2 run bossbar set metiers:d$(id) name [{"text":"Défi ☘ Fermier : ","color":"green","bold":true},{"text":"Récolte 160 carottes  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_f"},"color":"yellow"},{"text":" / 160","color":"gray"}]
$execute if score #d_f m.defi matches 2 run bossbar set metiers:d$(id) max 160
$execute if score #d_f m.defi matches 3 run bossbar set metiers:d$(id) name [{"text":"Défi ☘ Fermier : ","color":"green","bold":true},{"text":"Récolte 160 pommes de terre  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_f"},"color":"yellow"},{"text":" / 160","color":"gray"}]
$execute if score #d_f m.defi matches 3 run bossbar set metiers:d$(id) max 160
$execute if score #d_f m.defi matches 4 run bossbar set metiers:d$(id) name [{"text":"Défi ☘ Fermier : ","color":"green","bold":true},{"text":"Récolte 96 cannes à sucre  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_f"},"color":"yellow"},{"text":" / 96","color":"gray"}]
$execute if score #d_f m.defi matches 4 run bossbar set metiers:d$(id) max 96
$execute if score #d_f m.defi matches 5 run bossbar set metiers:d$(id) name [{"text":"Défi ☘ Fermier : ","color":"green","bold":true},{"text":"Fais naître 12 animaux  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_f"},"color":"yellow"},{"text":" / 12","color":"gray"}]
$execute if score #d_f m.defi matches 5 run bossbar set metiers:d$(id) max 12
$execute store result bossbar metiers:d$(id) value run scoreboard players get @s m.dp_f
