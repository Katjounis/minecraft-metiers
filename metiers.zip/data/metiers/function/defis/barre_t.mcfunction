$bossbar set metiers:d$(id) color purple
$bossbar set metiers:d$(id) style notched_10
$execute if score #d_t m.defi matches 1 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Marchand : ","color":"dark_green","bold":true},{"text":"Fais 8 échanges  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_t"},"color":"yellow"},{"text":" / 8","color":"gray"}]
$execute if score #d_t m.defi matches 1 run bossbar set metiers:d$(id) max 8
$execute if score #d_t m.defi matches 2 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Marchand : ","color":"dark_green","bold":true},{"text":"Fais 16 échanges  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_t"},"color":"yellow"},{"text":" / 16","color":"gray"}]
$execute if score #d_t m.defi matches 2 run bossbar set metiers:d$(id) max 16
$execute if score #d_t m.defi matches 3 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Marchand : ","color":"dark_green","bold":true},{"text":"Fais 24 échanges  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_t"},"color":"yellow"},{"text":" / 24","color":"gray"}]
$execute if score #d_t m.defi matches 3 run bossbar set metiers:d$(id) max 24
$execute if score #d_t m.defi matches 4 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Marchand : ","color":"dark_green","bold":true},{"text":"Parle à 15 villageois  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_t"},"color":"yellow"},{"text":" / 15","color":"gray"}]
$execute if score #d_t m.defi matches 4 run bossbar set metiers:d$(id) max 15
$execute store result bossbar metiers:d$(id) value run scoreboard players get @s m.dp_t
