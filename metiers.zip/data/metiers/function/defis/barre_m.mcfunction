$bossbar set metiers:d$(id) color white
$execute if score #d_m m.defi matches 1 run bossbar set metiers:d$(id) name [{"text":"Défi ⛏ Mineur : ","color":"gray","bold":true},{"text":"Mine 512 blocs de pierre  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_m"},"color":"yellow"},{"text":" / 512","color":"gray"}]
$execute if score #d_m m.defi matches 1 run bossbar set metiers:d$(id) max 512
$execute if score #d_m m.defi matches 2 run bossbar set metiers:d$(id) name [{"text":"Défi ⛏ Mineur : ","color":"gray","bold":true},{"text":"Mine 256 blocs de deepslate  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_m"},"color":"yellow"},{"text":" / 256","color":"gray"}]
$execute if score #d_m m.defi matches 2 run bossbar set metiers:d$(id) max 256
$execute if score #d_m m.defi matches 3 run bossbar set metiers:d$(id) name [{"text":"Défi ⛏ Mineur : ","color":"gray","bold":true},{"text":"Mine 24 minerais de fer  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_m"},"color":"yellow"},{"text":" / 24","color":"gray"}]
$execute if score #d_m m.defi matches 3 run bossbar set metiers:d$(id) max 24
$execute if score #d_m m.defi matches 4 run bossbar set metiers:d$(id) name [{"text":"Défi ⛏ Mineur : ","color":"gray","bold":true},{"text":"Mine 48 minerais de charbon  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_m"},"color":"yellow"},{"text":" / 48","color":"gray"}]
$execute if score #d_m m.defi matches 4 run bossbar set metiers:d$(id) max 48
$execute if score #d_m m.defi matches 5 run bossbar set metiers:d$(id) name [{"text":"Défi ⛏ Mineur : ","color":"gray","bold":true},{"text":"Mine 4 minerais de diamant  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_m"},"color":"yellow"},{"text":" / 4","color":"gray"}]
$execute if score #d_m m.defi matches 5 run bossbar set metiers:d$(id) max 4
$execute store result bossbar metiers:d$(id) value run scoreboard players get @s m.dp_m
