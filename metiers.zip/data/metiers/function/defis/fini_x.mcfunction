scoreboard players set @s m.dd_x 1
scoreboard players operation @s m.tmp = @s m.x_need
scoreboard players operation @s m.tmp /= #2 m.const
scoreboard players operation @s m.x_bal += @s m.tmp
scoreboard players add @s m.cr_x 4
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" a réussi le défi du jour ","color":"gray"},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Explorateur","color":"blue","bold":true}]
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"+4 ","color":"aqua"},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" cristaux d'Explorateur et un demi-niveau.","color":"aqua"}]
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
scoreboard players set @s m.tmp 0
execute if score @s m.dd_b matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.dd_f matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.dd_m matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.dd_c matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.dd_p matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.dd_e matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.dd_n matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.dd_x matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.dd_t matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.tmp matches 9 run function metiers:defis/tous
function metiers:defis/plus1
