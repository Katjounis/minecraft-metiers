scoreboard players add @s m.dshow 1
execute if score @s m.dshow matches 10.. run scoreboard players set @s m.dshow 1
