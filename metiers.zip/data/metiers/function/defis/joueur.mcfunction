scoreboard players set @s m.dp_b 0
execute if score #d_b m.defi matches 1 run scoreboard players operation @s m.dp_b += @s dq.b1_0
execute if score #d_b m.defi matches 1 unless score @s m.dd_b matches 1 if score @s m.dp_b matches 128.. run function metiers:defis/fini_b
execute if score #d_b m.defi matches 2 run scoreboard players operation @s m.dp_b += @s dq.b2_0
execute if score #d_b m.defi matches 2 unless score @s m.dd_b matches 1 if score @s m.dp_b matches 128.. run function metiers:defis/fini_b
execute if score #d_b m.defi matches 3 run scoreboard players operation @s m.dp_b += @s dq.b3_0
execute if score #d_b m.defi matches 3 unless score @s m.dd_b matches 1 if score @s m.dp_b matches 96.. run function metiers:defis/fini_b
execute if score #d_b m.defi matches 4 run scoreboard players operation @s m.dp_b += @s dq.b4_0
execute if score #d_b m.defi matches 4 unless score @s m.dd_b matches 1 if score @s m.dp_b matches 96.. run function metiers:defis/fini_b
execute if score #d_b m.defi matches 5 run scoreboard players operation @s m.dp_b += @s dq.b5_0
execute if score #d_b m.defi matches 5 unless score @s m.dd_b matches 1 if score @s m.dp_b matches 64.. run function metiers:defis/fini_b
execute if score #d_b m.defi matches 6 run scoreboard players operation @s m.dp_b += @s dq.b6_0
execute if score #d_b m.defi matches 6 run scoreboard players operation @s m.dp_b += @s dq.b6_1
execute if score #d_b m.defi matches 6 unless score @s m.dd_b matches 1 if score @s m.dp_b matches 96.. run function metiers:defis/fini_b
execute if score #d_b m.defi matches 7 run scoreboard players operation @s m.dp_b += @s dq.b7_0
execute if score #d_b m.defi matches 7 unless score @s m.dd_b matches 1 if score @s m.dp_b matches 12.. run function metiers:defis/fini_b
execute if score #d_b m.defi matches 8 run scoreboard players operation @s m.dp_b += @s dq.b8_0
execute if score #d_b m.defi matches 8 run scoreboard players operation @s m.dp_b += @s dq.b8_1
execute if score #d_b m.defi matches 8 run scoreboard players operation @s m.dp_b += @s dq.b8_2
execute if score #d_b m.defi matches 8 run scoreboard players operation @s m.dp_b += @s dq.b8_3
execute if score #d_b m.defi matches 8 run scoreboard players operation @s m.dp_b += @s dq.b8_4
execute if score #d_b m.defi matches 8 run scoreboard players operation @s m.dp_b += @s dq.b8_5
execute if score #d_b m.defi matches 8 run scoreboard players operation @s m.dp_b += @s dq.b8_6
execute if score #d_b m.defi matches 8 run scoreboard players operation @s m.dp_b += @s dq.b8_7
execute if score #d_b m.defi matches 8 run scoreboard players operation @s m.dp_b += @s dq.b8_8
execute if score #d_b m.defi matches 8 run scoreboard players operation @s m.dp_b += @s dq.b8_9
execute if score #d_b m.defi matches 8 run scoreboard players operation @s m.dp_b += @s dq.b8_10
execute if score #d_b m.defi matches 8 unless score @s m.dd_b matches 1 if score @s m.dp_b matches 256.. run function metiers:defis/fini_b
scoreboard players set @s m.dp_f 0
execute if score #d_f m.defi matches 1 run scoreboard players operation @s m.dp_f += @s dq.f1_0
execute if score #d_f m.defi matches 1 unless score @s m.dd_f matches 1 if score @s m.dp_f matches 192.. run function metiers:defis/fini_f
execute if score #d_f m.defi matches 2 run scoreboard players operation @s m.dp_f += @s dq.f2_0
execute if score #d_f m.defi matches 2 unless score @s m.dd_f matches 1 if score @s m.dp_f matches 160.. run function metiers:defis/fini_f
execute if score #d_f m.defi matches 3 run scoreboard players operation @s m.dp_f += @s dq.f3_0
execute if score #d_f m.defi matches 3 unless score @s m.dd_f matches 1 if score @s m.dp_f matches 160.. run function metiers:defis/fini_f
execute if score #d_f m.defi matches 4 run scoreboard players operation @s m.dp_f += @s dq.f4_0
execute if score #d_f m.defi matches 4 unless score @s m.dd_f matches 1 if score @s m.dp_f matches 96.. run function metiers:defis/fini_f
execute if score #d_f m.defi matches 5 run scoreboard players operation @s m.dp_f += @s dq.f5_0
execute if score #d_f m.defi matches 5 unless score @s m.dd_f matches 1 if score @s m.dp_f matches 96.. run function metiers:defis/fini_f
execute if score #d_f m.defi matches 6 run scoreboard players operation @s m.dp_f += @s dq.f6_0
execute if score #d_f m.defi matches 6 unless score @s m.dd_f matches 1 if score @s m.dp_f matches 48.. run function metiers:defis/fini_f
execute if score #d_f m.defi matches 7 run scoreboard players operation @s m.dp_f += @s dq.f7_0
execute if score #d_f m.defi matches 7 unless score @s m.dd_f matches 1 if score @s m.dp_f matches 32.. run function metiers:defis/fini_f
execute if score #d_f m.defi matches 8 run scoreboard players operation @s m.dp_f += @s dq.f8_0
execute if score #d_f m.defi matches 8 unless score @s m.dd_f matches 1 if score @s m.dp_f matches 32.. run function metiers:defis/fini_f
scoreboard players set @s m.dp_m 0
execute if score #d_m m.defi matches 1 run scoreboard players operation @s m.dp_m += @s dq.m1_0
execute if score #d_m m.defi matches 1 unless score @s m.dd_m matches 1 if score @s m.dp_m matches 512.. run function metiers:defis/fini_m
execute if score #d_m m.defi matches 2 run scoreboard players operation @s m.dp_m += @s dq.m2_0
execute if score #d_m m.defi matches 2 unless score @s m.dd_m matches 1 if score @s m.dp_m matches 256.. run function metiers:defis/fini_m
execute if score #d_m m.defi matches 3 run scoreboard players operation @s m.dp_m += @s dq.m3_0
execute if score #d_m m.defi matches 3 run scoreboard players operation @s m.dp_m += @s dq.m3_1
execute if score #d_m m.defi matches 3 unless score @s m.dd_m matches 1 if score @s m.dp_m matches 24.. run function metiers:defis/fini_m
execute if score #d_m m.defi matches 4 run scoreboard players operation @s m.dp_m += @s dq.m4_0
execute if score #d_m m.defi matches 4 run scoreboard players operation @s m.dp_m += @s dq.m4_1
execute if score #d_m m.defi matches 4 unless score @s m.dd_m matches 1 if score @s m.dp_m matches 48.. run function metiers:defis/fini_m
execute if score #d_m m.defi matches 5 run scoreboard players operation @s m.dp_m += @s dq.m5_0
execute if score #d_m m.defi matches 5 run scoreboard players operation @s m.dp_m += @s dq.m5_1
execute if score #d_m m.defi matches 5 unless score @s m.dd_m matches 1 if score @s m.dp_m matches 32.. run function metiers:defis/fini_m
execute if score #d_m m.defi matches 6 run scoreboard players operation @s m.dp_m += @s dq.m6_0
execute if score #d_m m.defi matches 6 run scoreboard players operation @s m.dp_m += @s dq.m6_1
execute if score #d_m m.defi matches 6 unless score @s m.dd_m matches 1 if score @s m.dp_m matches 12.. run function metiers:defis/fini_m
execute if score #d_m m.defi matches 7 run scoreboard players operation @s m.dp_m += @s dq.m7_0
execute if score #d_m m.defi matches 7 unless score @s m.dd_m matches 1 if score @s m.dp_m matches 24.. run function metiers:defis/fini_m
execute if score #d_m m.defi matches 8 run scoreboard players operation @s m.dp_m += @s dq.m8_0
execute if score #d_m m.defi matches 8 run scoreboard players operation @s m.dp_m += @s dq.m8_1
execute if score #d_m m.defi matches 8 unless score @s m.dd_m matches 1 if score @s m.dp_m matches 4.. run function metiers:defis/fini_m
execute if score #d_m m.defi matches 9 run scoreboard players operation @s m.dp_m += @s dq.m9_0
execute if score #d_m m.defi matches 9 unless score @s m.dd_m matches 1 if score @s m.dp_m matches 2.. run function metiers:defis/fini_m
scoreboard players set @s m.dp_c 0
execute if score #d_c m.defi matches 1 run scoreboard players operation @s m.dp_c += @s dq.c1_0
execute if score #d_c m.defi matches 1 unless score @s m.dd_c matches 1 if score @s m.dp_c matches 60.. run function metiers:defis/fini_c
execute if score #d_c m.defi matches 2 run scoreboard players operation @s m.dp_c += @s dq.c2_0
execute if score #d_c m.defi matches 2 unless score @s m.dd_c matches 1 if score @s m.dp_c matches 25.. run function metiers:defis/fini_c
execute if score #d_c m.defi matches 3 run scoreboard players operation @s m.dp_c += @s dq.c3_0
execute if score #d_c m.defi matches 3 unless score @s m.dd_c matches 1 if score @s m.dp_c matches 25.. run function metiers:defis/fini_c
execute if score #d_c m.defi matches 4 run scoreboard players operation @s m.dp_c += @s dq.c4_0
execute if score #d_c m.defi matches 4 unless score @s m.dd_c matches 1 if score @s m.dp_c matches 12.. run function metiers:defis/fini_c
execute if score #d_c m.defi matches 5 run scoreboard players operation @s m.dp_c += @s dq.c5_0
execute if score #d_c m.defi matches 5 unless score @s m.dd_c matches 1 if score @s m.dp_c matches 15.. run function metiers:defis/fini_c
execute if score #d_c m.defi matches 6 run scoreboard players operation @s m.dp_c += @s dq.c6_0
execute if score #d_c m.defi matches 6 unless score @s m.dd_c matches 1 if score @s m.dp_c matches 10.. run function metiers:defis/fini_c
execute if score #d_c m.defi matches 7 run scoreboard players operation @s m.dp_c += @s dq.c7_0
execute if score #d_c m.defi matches 7 unless score @s m.dd_c matches 1 if score @s m.dp_c matches 6.. run function metiers:defis/fini_c
execute if score #d_c m.defi matches 8 run scoreboard players operation @s m.dp_c += @s dq.c8_0
execute if score #d_c m.defi matches 8 unless score @s m.dd_c matches 1 if score @s m.dp_c matches 8.. run function metiers:defis/fini_c
execute if score #d_c m.defi matches 9 run scoreboard players operation @s m.dp_c += @s dq.c9_0
execute if score #d_c m.defi matches 9 unless score @s m.dd_c matches 1 if score @s m.dp_c matches 15.. run function metiers:defis/fini_c
scoreboard players set @s m.dp_p 0
execute if score #d_p m.defi matches 1 run scoreboard players operation @s m.dp_p += @s dq.p1_0
execute if score #d_p m.defi matches 1 unless score @s m.dd_p matches 1 if score @s m.dp_p matches 25.. run function metiers:defis/fini_p
execute if score #d_p m.defi matches 2 run scoreboard players operation @s m.dp_p += @s dq.p2_0
execute if score #d_p m.defi matches 2 unless score @s m.dd_p matches 1 if score @s m.dp_p matches 40.. run function metiers:defis/fini_p
execute if score #d_p m.defi matches 3 run scoreboard players operation @s m.dp_p += @s dq.p3_0
execute if score #d_p m.defi matches 3 unless score @s m.dd_p matches 1 if score @s m.dp_p matches 12.. run function metiers:defis/fini_p
execute if score #d_p m.defi matches 4 run scoreboard players operation @s m.dp_p += @s dq.p4_0
execute if score #d_p m.defi matches 4 unless score @s m.dd_p matches 1 if score @s m.dp_p matches 6.. run function metiers:defis/fini_p
execute if score #d_p m.defi matches 5 run scoreboard players operation @s m.dp_p += @s dq.p5_0
execute if score #d_p m.defi matches 5 run scoreboard players operation @s m.dp_p /= #100 m.const
execute if score #d_p m.defi matches 5 unless score @s m.dd_p matches 1 if score @s m.dp_p matches 1000.. run function metiers:defis/fini_p
execute if score #d_p m.defi matches 6 run scoreboard players operation @s m.dp_p += @s dq.p6_0
execute if score #d_p m.defi matches 6 run scoreboard players operation @s m.dp_p /= #100 m.const
execute if score #d_p m.defi matches 6 unless score @s m.dd_p matches 1 if score @s m.dp_p matches 500.. run function metiers:defis/fini_p
scoreboard players set @s m.dp_e 0
execute if score #d_e m.defi matches 1 run scoreboard players operation @s m.dp_e += @s dq.e1_0
execute if score #d_e m.defi matches 1 unless score @s m.dd_e matches 1 if score @s m.dp_e matches 12.. run function metiers:defis/fini_e
execute if score #d_e m.defi matches 2 run scoreboard players operation @s m.dp_e += @s dq.e2_0
execute if score #d_e m.defi matches 2 unless score @s m.dd_e matches 1 if score @s m.dp_e matches 24.. run function metiers:defis/fini_e
execute if score #d_e m.defi matches 3 run scoreboard players operation @s m.dp_e += @s dq.e3_0
execute if score #d_e m.defi matches 3 unless score @s m.dd_e matches 1 if score @s m.dp_e matches 32.. run function metiers:defis/fini_e
execute if score #d_e m.defi matches 4 run scoreboard players operation @s m.dp_e += @s dq.e4_0
execute if score #d_e m.defi matches 4 unless score @s m.dd_e matches 1 if score @s m.dp_e matches 32.. run function metiers:defis/fini_e
execute if score #d_e m.defi matches 5 run scoreboard players operation @s m.dp_e += @s dq.e5_0
execute if score #d_e m.defi matches 5 unless score @s m.dd_e matches 1 if score @s m.dp_e matches 16.. run function metiers:defis/fini_e
execute if score #d_e m.defi matches 6 run scoreboard players operation @s m.dp_e += @s dq.e6_0
execute if score #d_e m.defi matches 6 unless score @s m.dd_e matches 1 if score @s m.dp_e matches 32.. run function metiers:defis/fini_e
scoreboard players set @s m.dp_n 0
execute if score #d_n m.defi matches 1 run scoreboard players operation @s m.dp_n += @s dq.n1_0
execute if score #d_n m.defi matches 1 unless score @s m.dd_n matches 1 if score @s m.dp_n matches 3.. run function metiers:defis/fini_n
execute if score #d_n m.defi matches 2 run scoreboard players operation @s m.dp_n += @s dq.n2_0
execute if score #d_n m.defi matches 2 unless score @s m.dd_n matches 1 if score @s m.dp_n matches 5.. run function metiers:defis/fini_n
execute if score #d_n m.defi matches 3 run scoreboard players operation @s m.dp_n += @s dq.n3_0
execute if score #d_n m.defi matches 3 unless score @s m.dd_n matches 1 if score @s m.dp_n matches 8.. run function metiers:defis/fini_n
execute if score #d_n m.defi matches 4 run scoreboard players operation @s m.dp_n += @s dq.n4_0
execute if score #d_n m.defi matches 4 unless score @s m.dd_n matches 1 if score @s m.dp_n matches 24.. run function metiers:defis/fini_n
execute if score #d_n m.defi matches 5 run scoreboard players operation @s m.dp_n += @s dq.n5_0
execute if score #d_n m.defi matches 5 unless score @s m.dd_n matches 1 if score @s m.dp_n matches 8.. run function metiers:defis/fini_n
scoreboard players set @s m.dp_x 0
execute if score #d_x m.defi matches 1 run scoreboard players operation @s m.dp_x += @s dq.x1_0
execute if score #d_x m.defi matches 1 run scoreboard players operation @s m.dp_x /= #100 m.const
execute if score #d_x m.defi matches 1 unless score @s m.dd_x matches 1 if score @s m.dp_x matches 3000.. run function metiers:defis/fini_x
execute if score #d_x m.defi matches 2 run scoreboard players operation @s m.dp_x += @s dq.x2_0
execute if score #d_x m.defi matches 2 run scoreboard players operation @s m.dp_x /= #100 m.const
execute if score #d_x m.defi matches 2 unless score @s m.dd_x matches 1 if score @s m.dp_x matches 2000.. run function metiers:defis/fini_x
execute if score #d_x m.defi matches 3 run scoreboard players operation @s m.dp_x += @s dq.x3_0
execute if score #d_x m.defi matches 3 run scoreboard players operation @s m.dp_x += @s dq.x3_1
execute if score #d_x m.defi matches 3 run scoreboard players operation @s m.dp_x /= #100 m.const
execute if score #d_x m.defi matches 3 unless score @s m.dd_x matches 1 if score @s m.dp_x matches 5000.. run function metiers:defis/fini_x
execute if score #d_x m.defi matches 4 run scoreboard players operation @s m.dp_x += @s dq.x4_0
execute if score #d_x m.defi matches 4 run scoreboard players operation @s m.dp_x /= #100 m.const
execute if score #d_x m.defi matches 4 unless score @s m.dd_x matches 1 if score @s m.dp_x matches 5000.. run function metiers:defis/fini_x
execute if score #d_x m.defi matches 5 run scoreboard players operation @s m.dp_x += @s dq.x5_0
execute if score #d_x m.defi matches 5 run scoreboard players operation @s m.dp_x /= #100 m.const
execute if score #d_x m.defi matches 5 unless score @s m.dd_x matches 1 if score @s m.dp_x matches 3000.. run function metiers:defis/fini_x
execute if score #d_x m.defi matches 6 run scoreboard players operation @s m.dp_x += @s dq.x6_0
execute if score #d_x m.defi matches 6 run scoreboard players operation @s m.dp_x /= #100 m.const
execute if score #d_x m.defi matches 6 unless score @s m.dd_x matches 1 if score @s m.dp_x matches 150.. run function metiers:defis/fini_x
execute if score #d_x m.defi matches 7 run scoreboard players operation @s m.dp_x += @s dq.x7_0
execute if score #d_x m.defi matches 7 run scoreboard players operation @s m.dp_x /= #100 m.const
execute if score #d_x m.defi matches 7 unless score @s m.dd_x matches 1 if score @s m.dp_x matches 300.. run function metiers:defis/fini_x
scoreboard players set @s m.dp_t 0
execute if score #d_t m.defi matches 1 run scoreboard players operation @s m.dp_t += @s dq.t1_0
execute if score #d_t m.defi matches 1 unless score @s m.dd_t matches 1 if score @s m.dp_t matches 8.. run function metiers:defis/fini_t
execute if score #d_t m.defi matches 2 run scoreboard players operation @s m.dp_t += @s dq.t2_0
execute if score #d_t m.defi matches 2 unless score @s m.dd_t matches 1 if score @s m.dp_t matches 16.. run function metiers:defis/fini_t
execute if score #d_t m.defi matches 3 run scoreboard players operation @s m.dp_t += @s dq.t3_0
execute if score #d_t m.defi matches 3 unless score @s m.dd_t matches 1 if score @s m.dp_t matches 24.. run function metiers:defis/fini_t
execute if score #d_t m.defi matches 4 run scoreboard players operation @s m.dp_t += @s dq.t4_0
execute if score #d_t m.defi matches 4 unless score @s m.dd_t matches 1 if score @s m.dp_t matches 15.. run function metiers:defis/fini_t
scoreboard players set @s m.dall 0
execute if score @s m.dd_b matches 1 run scoreboard players add @s m.dall 1
execute if score @s m.dd_f matches 1 run scoreboard players add @s m.dall 1
execute if score @s m.dd_m matches 1 run scoreboard players add @s m.dall 1
execute if score @s m.dd_c matches 1 run scoreboard players add @s m.dall 1
execute if score @s m.dd_p matches 1 run scoreboard players add @s m.dall 1
execute if score @s m.dd_e matches 1 run scoreboard players add @s m.dall 1
execute if score @s m.dd_n matches 1 run scoreboard players add @s m.dall 1
execute if score @s m.dd_x matches 1 run scoreboard players add @s m.dall 1
execute if score @s m.dd_t matches 1 run scoreboard players add @s m.dall 1
execute unless score @s m.dshow matches 1..9 run scoreboard players set @s m.dshow 1
execute if score #huit m.timer matches 0 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 1 if score @s m.dd_b matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 2 if score @s m.dd_f matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 3 if score @s m.dd_m matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 4 if score @s m.dd_c matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 5 if score @s m.dd_p matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 6 if score @s m.dd_e matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 7 if score @s m.dd_n matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 8 if score @s m.dd_x matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 9 if score @s m.dd_t matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 1 if score @s m.dd_b matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 2 if score @s m.dd_f matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 3 if score @s m.dd_m matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 4 if score @s m.dd_c matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 5 if score @s m.dd_p matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 6 if score @s m.dd_e matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 7 if score @s m.dd_n matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 8 if score @s m.dd_x matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 9 if score @s m.dd_t matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 1 if score @s m.dd_b matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 2 if score @s m.dd_f matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 3 if score @s m.dd_m matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 4 if score @s m.dd_c matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 5 if score @s m.dd_p matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 6 if score @s m.dd_e matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 7 if score @s m.dd_n matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 8 if score @s m.dd_x matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 9 if score @s m.dd_t matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 1 if score @s m.dd_b matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 2 if score @s m.dd_f matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 3 if score @s m.dd_m matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 4 if score @s m.dd_c matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 5 if score @s m.dd_p matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 6 if score @s m.dd_e matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 7 if score @s m.dd_n matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 8 if score @s m.dd_x matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 9 if score @s m.dd_t matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 1 if score @s m.dd_b matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 2 if score @s m.dd_f matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 3 if score @s m.dd_m matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 4 if score @s m.dd_c matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 5 if score @s m.dd_p matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 6 if score @s m.dd_e matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 7 if score @s m.dd_n matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 8 if score @s m.dd_x matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 9 if score @s m.dd_t matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 1 if score @s m.dd_b matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 2 if score @s m.dd_f matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 3 if score @s m.dd_m matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 4 if score @s m.dd_c matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 5 if score @s m.dd_p matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 6 if score @s m.dd_e matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 7 if score @s m.dd_n matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 8 if score @s m.dd_x matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 9 if score @s m.dd_t matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 1 if score @s m.dd_b matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 2 if score @s m.dd_f matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 3 if score @s m.dd_m matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 4 if score @s m.dd_c matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 5 if score @s m.dd_p matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 6 if score @s m.dd_e matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 7 if score @s m.dd_n matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 8 if score @s m.dd_x matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 9 if score @s m.dd_t matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 1 if score @s m.dd_b matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 2 if score @s m.dd_f matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 3 if score @s m.dd_m matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 4 if score @s m.dd_c matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 5 if score @s m.dd_p matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 6 if score @s m.dd_e matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 7 if score @s m.dd_n matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 8 if score @s m.dd_x matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 9 if score @s m.dd_t matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 1 if score @s m.dd_b matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 2 if score @s m.dd_f matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 3 if score @s m.dd_m matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 4 if score @s m.dd_c matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 5 if score @s m.dd_p matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 6 if score @s m.dd_e matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 7 if score @s m.dd_n matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 8 if score @s m.dd_x matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..8 if score @s m.dshow matches 9 if score @s m.dd_t matches 1 run function metiers:defis/plus1
execute store result storage metiers:tmp id int 1 run scoreboard players get @s m.id
function metiers:defis/barre with storage metiers:tmp
scoreboard players set @s m.wp 0
scoreboard players set @s m.cc 0
execute if score #s_def m.defi matches 1 run scoreboard players operation @s m.wp += @s dw.1_0
execute if score #s_def m.defi matches 1 run scoreboard players operation @s m.wp += @s dw.1_1
execute if score #s_def m.defi matches 1 run scoreboard players operation @s m.wp += @s dw.1_2
execute if score #s_def m.defi matches 1 run scoreboard players operation @s m.wp += @s dw.1_3
execute if score #s_def m.defi matches 1 run scoreboard players operation @s m.wp += @s dw.1_4
execute if score #s_def m.defi matches 1 run scoreboard players operation @s m.wp += @s dw.1_5
execute if score #s_def m.defi matches 1 run scoreboard players operation @s m.wp += @s dw.1_6
execute if score #s_def m.defi matches 1 run scoreboard players operation @s m.wp += @s dw.1_7
execute if score #s_def m.defi matches 1 run scoreboard players operation @s m.wp += @s dw.1_8
execute if score #s_def m.defi matches 1 run scoreboard players operation @s m.wp += @s dw.1_9
execute if score #s_def m.defi matches 1 run scoreboard players operation @s m.wp += @s dw.1_10
execute if score #s_def m.defi matches 1 unless score @s m.wd matches 1 if score @s m.wp matches 1000.. run function metiers:defis/semaine_fini_1
execute if score #s_def m.defi matches 2 run scoreboard players operation @s m.wp += @s dw.2_0
execute if score #s_def m.defi matches 2 run scoreboard players operation @s m.wp += @s dw.2_1
execute if score #s_def m.defi matches 2 run scoreboard players operation @s m.wp += @s dw.2_2
execute if score #s_def m.defi matches 2 run scoreboard players operation @s m.wp += @s dw.2_3
execute if score #s_def m.defi matches 2 unless score @s m.wd matches 1 if score @s m.wp matches 1500.. run function metiers:defis/semaine_fini_2
execute if score #s_def m.defi matches 3 run scoreboard players operation @s m.wp += @s dw.3_0
execute if score #s_def m.defi matches 3 run scoreboard players operation @s m.wp += @s dw.3_1
execute if score #s_def m.defi matches 3 unless score @s m.wd matches 1 if score @s m.wp matches 3000.. run function metiers:defis/semaine_fini_3
execute if score #s_def m.defi matches 4 run scoreboard players operation @s m.wp += @s dw.4_0
execute if score #s_def m.defi matches 4 unless score @s m.wd matches 1 if score @s m.wp matches 400.. run function metiers:defis/semaine_fini_4
execute if score #s_def m.defi matches 5 run scoreboard players operation @s m.wp += @s dw.5_0
execute if score #s_def m.defi matches 5 unless score @s m.wd matches 1 if score @s m.wp matches 200.. run function metiers:defis/semaine_fini_5
execute if score #s_def m.defi matches 6 run scoreboard players operation @s m.wp += @s dw.6_0
execute if score #s_def m.defi matches 6 unless score @s m.wd matches 1 if score @s m.wp matches 120.. run function metiers:defis/semaine_fini_6
execute if score #s_def m.defi matches 7 run scoreboard players operation @s m.wp += @s dw.7_0
execute if score #s_def m.defi matches 7 unless score @s m.wd matches 1 if score @s m.wp matches 40.. run function metiers:defis/semaine_fini_7
execute if score #s_def m.defi matches 8 run scoreboard players operation @s m.wp += @s dw.8_0
execute if score #s_def m.defi matches 8 run scoreboard players operation @s m.wp += @s dw.8_1
execute if score #s_def m.defi matches 8 run scoreboard players operation @s m.wp /= #100 m.const
execute if score #s_def m.defi matches 8 unless score @s m.wd matches 1 if score @s m.wp matches 40000.. run function metiers:defis/semaine_fini_8
execute if score #s_def m.defi matches 9 run scoreboard players operation @s m.wp += @s dw.9_0
execute if score #s_def m.defi matches 9 unless score @s m.wd matches 1 if score @s m.wp matches 150.. run function metiers:defis/semaine_fini_9
execute if score #c_def m.defi matches 1 run scoreboard players operation @s m.cc += @s dc.1_0
execute if score #c_def m.defi matches 1 run scoreboard players operation @s m.cc += @s dc.1_1
execute if score #c_def m.defi matches 1 run scoreboard players set #c_min m.defi 200
execute if score #c_def m.defi matches 2 run scoreboard players operation @s m.cc += @s dc.2_0
execute if score #c_def m.defi matches 2 run scoreboard players operation @s m.cc += @s dc.2_1
execute if score #c_def m.defi matches 2 run scoreboard players operation @s m.cc += @s dc.2_2
execute if score #c_def m.defi matches 2 run scoreboard players operation @s m.cc += @s dc.2_3
execute if score #c_def m.defi matches 2 run scoreboard players operation @s m.cc += @s dc.2_4
execute if score #c_def m.defi matches 2 run scoreboard players operation @s m.cc += @s dc.2_5
execute if score #c_def m.defi matches 2 run scoreboard players operation @s m.cc += @s dc.2_6
execute if score #c_def m.defi matches 2 run scoreboard players operation @s m.cc += @s dc.2_7
execute if score #c_def m.defi matches 2 run scoreboard players operation @s m.cc += @s dc.2_8
execute if score #c_def m.defi matches 2 run scoreboard players operation @s m.cc += @s dc.2_9
execute if score #c_def m.defi matches 2 run scoreboard players operation @s m.cc += @s dc.2_10
execute if score #c_def m.defi matches 2 run scoreboard players set #c_min m.defi 60
execute if score #c_def m.defi matches 3 run scoreboard players operation @s m.cc += @s dc.3_0
execute if score #c_def m.defi matches 3 run scoreboard players set #c_min m.defi 30
execute if score #c_def m.defi matches 4 run scoreboard players operation @s m.cc += @s dc.4_0
execute if score #c_def m.defi matches 4 run scoreboard players set #c_min m.defi 8
execute if score #c_def m.defi matches 5 run scoreboard players operation @s m.cc += @s dc.5_0
execute if score #c_def m.defi matches 5 run scoreboard players set #c_min m.defi 8
execute if score #c_def m.defi matches 6 run scoreboard players operation @s m.cc += @s dc.6_0
execute if score #c_def m.defi matches 6 run scoreboard players operation @s m.cc += @s dc.6_1
execute if score #c_def m.defi matches 6 run scoreboard players operation @s m.cc += @s dc.6_2
execute if score #c_def m.defi matches 6 run scoreboard players set #c_min m.defi 80
execute if score #c_ok m.defi matches 1 unless score @s m.wk matches 1 if score @s m.cc >= #c_min m.defi run function metiers:defis/collectif_gain
