scoreboard players set @s m.dp_b 0
execute if score #d_b m.defi matches 1 run scoreboard players operation @s m.dp_b += @s dq.b1_0
execute if score #d_b m.defi matches 1 unless score @s m.dd_b matches 1 if score @s m.dp_b matches 128.. run function metiers:defis/fini_b
execute if score #d_b m.defi matches 2 run scoreboard players operation @s m.dp_b += @s dq.b2_0
execute if score #d_b m.defi matches 2 unless score @s m.dd_b matches 1 if score @s m.dp_b matches 128.. run function metiers:defis/fini_b
execute if score #d_b m.defi matches 3 run scoreboard players operation @s m.dp_b += @s dq.b3_0
execute if score #d_b m.defi matches 3 unless score @s m.dd_b matches 1 if score @s m.dp_b matches 128.. run function metiers:defis/fini_b
execute if score #d_b m.defi matches 4 run scoreboard players operation @s m.dp_b += @s dq.b4_0
execute if score #d_b m.defi matches 4 unless score @s m.dd_b matches 1 if score @s m.dp_b matches 96.. run function metiers:defis/fini_b
execute if score #d_b m.defi matches 5 run scoreboard players operation @s m.dp_b += @s dq.b5_0
execute if score #d_b m.defi matches 5 run scoreboard players operation @s m.dp_b += @s dq.b5_1
execute if score #d_b m.defi matches 5 run scoreboard players operation @s m.dp_b += @s dq.b5_2
execute if score #d_b m.defi matches 5 run scoreboard players operation @s m.dp_b += @s dq.b5_3
execute if score #d_b m.defi matches 5 run scoreboard players operation @s m.dp_b += @s dq.b5_4
execute if score #d_b m.defi matches 5 run scoreboard players operation @s m.dp_b += @s dq.b5_5
execute if score #d_b m.defi matches 5 run scoreboard players operation @s m.dp_b += @s dq.b5_6
execute if score #d_b m.defi matches 5 run scoreboard players operation @s m.dp_b += @s dq.b5_7
execute if score #d_b m.defi matches 5 run scoreboard players operation @s m.dp_b += @s dq.b5_8
execute if score #d_b m.defi matches 5 run scoreboard players operation @s m.dp_b += @s dq.b5_9
execute if score #d_b m.defi matches 5 run scoreboard players operation @s m.dp_b += @s dq.b5_10
execute if score #d_b m.defi matches 5 unless score @s m.dd_b matches 1 if score @s m.dp_b matches 256.. run function metiers:defis/fini_b
scoreboard players set @s m.dp_f 0
execute if score #d_f m.defi matches 1 run scoreboard players operation @s m.dp_f += @s dq.f1_0
execute if score #d_f m.defi matches 1 unless score @s m.dd_f matches 1 if score @s m.dp_f matches 192.. run function metiers:defis/fini_f
execute if score #d_f m.defi matches 2 run scoreboard players operation @s m.dp_f += @s dq.f2_0
execute if score #d_f m.defi matches 2 unless score @s m.dd_f matches 1 if score @s m.dp_f matches 160.. run function metiers:defis/fini_f
execute if score #d_f m.defi matches 3 run scoreboard players operation @s m.dp_f += @s dq.f3_0
execute if score #d_f m.defi matches 3 unless score @s m.dd_f matches 1 if score @s m.dp_f matches 160.. run function metiers:defis/fini_f
execute if score #d_f m.defi matches 4 run scoreboard players operation @s m.dp_f += @s dq.f4_0
execute if score #d_f m.defi matches 4 unless score @s m.dd_f matches 1 if score @s m.dp_f matches 96.. run function metiers:defis/fini_f
execute if score #d_f m.defi matches 5 run scoreboard players operation @s m.dp_f += @s dq.f5_0
execute if score #d_f m.defi matches 5 unless score @s m.dd_f matches 1 if score @s m.dp_f matches 12.. run function metiers:defis/fini_f
scoreboard players set @s m.dp_m 0
execute if score #d_m m.defi matches 1 run scoreboard players operation @s m.dp_m += @s dq.m1_0
execute if score #d_m m.defi matches 1 unless score @s m.dd_m matches 1 if score @s m.dp_m matches 512.. run function metiers:defis/fini_m
execute if score #d_m m.defi matches 2 run scoreboard players operation @s m.dp_m += @s dq.m2_0
execute if score #d_m m.defi matches 2 unless score @s m.dd_m matches 1 if score @s m.dp_m matches 256.. run function metiers:defis/fini_m
execute if score #d_m m.defi matches 3 run scoreboard players operation @s m.dp_m += @s dq.m3_0
execute if score #d_m m.defi matches 3 run scoreboard players operation @s m.dp_m += @s dq.m3_1
execute if score #d_m m.defi matches 3 unless score @s m.dd_m matches 1 if score @s m.dp_m matches 24.. run function metiers:defis/fini_m
execute if score #d_m m.defi matches 4 run scoreboard players operation @s m.dp_m += @s dq.m4_0
execute if score #d_m m.defi matches 4 run scoreboard players operation @s m.dp_m += @s dq.m4_1
execute if score #d_m m.defi matches 4 unless score @s m.dd_m matches 1 if score @s m.dp_m matches 48.. run function metiers:defis/fini_m
execute if score #d_m m.defi matches 5 run scoreboard players operation @s m.dp_m += @s dq.m5_0
execute if score #d_m m.defi matches 5 run scoreboard players operation @s m.dp_m += @s dq.m5_1
execute if score #d_m m.defi matches 5 unless score @s m.dd_m matches 1 if score @s m.dp_m matches 4.. run function metiers:defis/fini_m
scoreboard players set @s m.dp_c 0
execute if score #d_c m.defi matches 1 run scoreboard players operation @s m.dp_c += @s dq.c1_0
execute if score #d_c m.defi matches 1 unless score @s m.dd_c matches 1 if score @s m.dp_c matches 60.. run function metiers:defis/fini_c
execute if score #d_c m.defi matches 2 run scoreboard players operation @s m.dp_c += @s dq.c2_0
execute if score #d_c m.defi matches 2 unless score @s m.dd_c matches 1 if score @s m.dp_c matches 25.. run function metiers:defis/fini_c
execute if score #d_c m.defi matches 3 run scoreboard players operation @s m.dp_c += @s dq.c3_0
execute if score #d_c m.defi matches 3 unless score @s m.dd_c matches 1 if score @s m.dp_c matches 25.. run function metiers:defis/fini_c
execute if score #d_c m.defi matches 4 run scoreboard players operation @s m.dp_c += @s dq.c4_0
execute if score #d_c m.defi matches 4 unless score @s m.dd_c matches 1 if score @s m.dp_c matches 12.. run function metiers:defis/fini_c
execute if score #d_c m.defi matches 5 run scoreboard players operation @s m.dp_c += @s dq.c5_0
execute if score #d_c m.defi matches 5 unless score @s m.dd_c matches 1 if score @s m.dp_c matches 10.. run function metiers:defis/fini_c
scoreboard players set @s m.dp_p 0
execute if score #d_p m.defi matches 1 run scoreboard players operation @s m.dp_p += @s dq.p1_0
execute if score #d_p m.defi matches 1 unless score @s m.dd_p matches 1 if score @s m.dp_p matches 20.. run function metiers:defis/fini_p
execute if score #d_p m.defi matches 2 run scoreboard players operation @s m.dp_p += @s dq.p2_0
execute if score #d_p m.defi matches 2 unless score @s m.dd_p matches 1 if score @s m.dp_p matches 35.. run function metiers:defis/fini_p
execute if score #d_p m.defi matches 3 run scoreboard players operation @s m.dp_p += @s dq.p3_0
execute if score #d_p m.defi matches 3 run scoreboard players operation @s m.dp_p /= #100 m.const
execute if score #d_p m.defi matches 3 unless score @s m.dd_p matches 1 if score @s m.dp_p matches 1000.. run function metiers:defis/fini_p
execute if score #d_p m.defi matches 4 run scoreboard players operation @s m.dp_p += @s dq.p4_0
execute if score #d_p m.defi matches 4 run scoreboard players operation @s m.dp_p /= #100 m.const
execute if score #d_p m.defi matches 4 unless score @s m.dd_p matches 1 if score @s m.dp_p matches 500.. run function metiers:defis/fini_p
execute if score #d_p m.defi matches 5 run scoreboard players operation @s m.dp_p += @s dq.p5_0
execute if score #d_p m.defi matches 5 unless score @s m.dd_p matches 1 if score @s m.dp_p matches 50.. run function metiers:defis/fini_p
scoreboard players set @s m.dall 0
execute if score @s m.dd_b matches 1 run scoreboard players add @s m.dall 1
execute if score @s m.dd_f matches 1 run scoreboard players add @s m.dall 1
execute if score @s m.dd_m matches 1 run scoreboard players add @s m.dall 1
execute if score @s m.dd_c matches 1 run scoreboard players add @s m.dall 1
execute if score @s m.dd_p matches 1 run scoreboard players add @s m.dall 1
execute unless score @s m.dshow matches 1..5 run scoreboard players set @s m.dshow 1
execute if score #huit m.timer matches 0 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 1 if score @s m.dd_b matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 2 if score @s m.dd_f matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 3 if score @s m.dd_m matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 4 if score @s m.dd_c matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 5 if score @s m.dd_p matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 1 if score @s m.dd_b matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 2 if score @s m.dd_f matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 3 if score @s m.dd_m matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 4 if score @s m.dd_c matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 5 if score @s m.dd_p matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 1 if score @s m.dd_b matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 2 if score @s m.dd_f matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 3 if score @s m.dd_m matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 4 if score @s m.dd_c matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 5 if score @s m.dd_p matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 1 if score @s m.dd_b matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 2 if score @s m.dd_f matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 3 if score @s m.dd_m matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 4 if score @s m.dd_c matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 5 if score @s m.dd_p matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 1 if score @s m.dd_b matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 2 if score @s m.dd_f matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 3 if score @s m.dd_m matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 4 if score @s m.dd_c matches 1 run function metiers:defis/plus1
execute if score @s m.dall matches ..4 if score @s m.dshow matches 5 if score @s m.dd_p matches 1 run function metiers:defis/plus1
execute store result storage metiers:tmp id int 1 run scoreboard players get @s m.id
function metiers:defis/barre with storage metiers:tmp
