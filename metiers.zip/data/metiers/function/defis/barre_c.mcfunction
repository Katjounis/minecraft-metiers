$bossbar set metiers:d$(id) color red
$execute if score #d_c m.defi matches 1 run bossbar set metiers:d$(id) name [{"text":"Défi ⚔ Chasseur : ","color":"red","bold":true},{"text":"Élimine 60 créatures  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_c"},"color":"yellow"},{"text":" / 60","color":"gray"}]
$execute if score #d_c m.defi matches 1 run bossbar set metiers:d$(id) max 60
$execute if score #d_c m.defi matches 2 run bossbar set metiers:d$(id) name [{"text":"Défi ⚔ Chasseur : ","color":"red","bold":true},{"text":"Élimine 25 zombies  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_c"},"color":"yellow"},{"text":" / 25","color":"gray"}]
$execute if score #d_c m.defi matches 2 run bossbar set metiers:d$(id) max 25
$execute if score #d_c m.defi matches 3 run bossbar set metiers:d$(id) name [{"text":"Défi ⚔ Chasseur : ","color":"red","bold":true},{"text":"Élimine 25 squelettes  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_c"},"color":"yellow"},{"text":" / 25","color":"gray"}]
$execute if score #d_c m.defi matches 3 run bossbar set metiers:d$(id) max 25
$execute if score #d_c m.defi matches 4 run bossbar set metiers:d$(id) name [{"text":"Défi ⚔ Chasseur : ","color":"red","bold":true},{"text":"Élimine 12 creepers  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_c"},"color":"yellow"},{"text":" / 12","color":"gray"}]
$execute if score #d_c m.defi matches 4 run bossbar set metiers:d$(id) max 12
$execute if score #d_c m.defi matches 5 run bossbar set metiers:d$(id) name [{"text":"Défi ⚔ Chasseur : ","color":"red","bold":true},{"text":"Élimine 10 endermen  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_c"},"color":"yellow"},{"text":" / 10","color":"gray"}]
$execute if score #d_c m.defi matches 5 run bossbar set metiers:d$(id) max 10
$execute store result bossbar metiers:d$(id) value run scoreboard players get @s m.dp_c
