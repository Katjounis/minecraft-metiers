$bossbar set metiers:d$(id) color purple
$bossbar set metiers:d$(id) style notched_10
$execute if score #d_n m.defi matches 1 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Enchanteur : ","color":"dark_purple","bold":true},{"text":"Enchante 3 objets  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_n"},"color":"yellow"},{"text":" / 3","color":"gray"}]
$execute if score #d_n m.defi matches 1 run bossbar set metiers:d$(id) max 3
$execute if score #d_n m.defi matches 2 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Enchanteur : ","color":"dark_purple","bold":true},{"text":"Enchante 5 objets  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_n"},"color":"yellow"},{"text":" / 5","color":"gray"}]
$execute if score #d_n m.defi matches 2 run bossbar set metiers:d$(id) max 5
$execute if score #d_n m.defi matches 3 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Enchanteur : ","color":"dark_purple","bold":true},{"text":"Enchante 8 objets  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_n"},"color":"yellow"},{"text":" / 8","color":"gray"}]
$execute if score #d_n m.defi matches 3 run bossbar set metiers:d$(id) max 8
$execute if score #d_n m.defi matches 4 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Enchanteur : ","color":"dark_purple","bold":true},{"text":"Fabrique 24 livres  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_n"},"color":"yellow"},{"text":" / 24","color":"gray"}]
$execute if score #d_n m.defi matches 4 run bossbar set metiers:d$(id) max 24
$execute if score #d_n m.defi matches 5 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Enchanteur : ","color":"dark_purple","bold":true},{"text":"Fabrique 8 bibliothèques  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_n"},"color":"yellow"},{"text":" / 8","color":"gray"}]
$execute if score #d_n m.defi matches 5 run bossbar set metiers:d$(id) max 8
$execute store result bossbar metiers:d$(id) value run scoreboard players get @s m.dp_n
