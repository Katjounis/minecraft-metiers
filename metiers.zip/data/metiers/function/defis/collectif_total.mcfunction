scoreboard players set #c_tot m.defi 0
execute if score #c_def m.defi matches 1 run scoreboard players operation #c_tot m.defi += * dc.1_0
execute if score #c_def m.defi matches 1 run scoreboard players operation #c_tot m.defi += * dc.1_1
execute if score #c_def m.defi matches 1 run scoreboard players set #c_tgt m.defi 10000
execute if score #c_def m.defi matches 2 run scoreboard players operation #c_tot m.defi += * dc.2_0
execute if score #c_def m.defi matches 2 run scoreboard players operation #c_tot m.defi += * dc.2_1
execute if score #c_def m.defi matches 2 run scoreboard players operation #c_tot m.defi += * dc.2_2
execute if score #c_def m.defi matches 2 run scoreboard players operation #c_tot m.defi += * dc.2_3
execute if score #c_def m.defi matches 2 run scoreboard players operation #c_tot m.defi += * dc.2_4
execute if score #c_def m.defi matches 2 run scoreboard players operation #c_tot m.defi += * dc.2_5
execute if score #c_def m.defi matches 2 run scoreboard players operation #c_tot m.defi += * dc.2_6
execute if score #c_def m.defi matches 2 run scoreboard players operation #c_tot m.defi += * dc.2_7
execute if score #c_def m.defi matches 2 run scoreboard players operation #c_tot m.defi += * dc.2_8
execute if score #c_def m.defi matches 2 run scoreboard players operation #c_tot m.defi += * dc.2_9
execute if score #c_def m.defi matches 2 run scoreboard players operation #c_tot m.defi += * dc.2_10
execute if score #c_def m.defi matches 2 run scoreboard players set #c_tgt m.defi 3000
execute if score #c_def m.defi matches 3 run scoreboard players operation #c_tot m.defi += * dc.3_0
execute if score #c_def m.defi matches 3 run scoreboard players set #c_tgt m.defi 1500
execute if score #c_def m.defi matches 4 run scoreboard players operation #c_tot m.defi += * dc.4_0
execute if score #c_def m.defi matches 4 run scoreboard players set #c_tgt m.defi 400
execute if score #c_def m.defi matches 5 run scoreboard players operation #c_tot m.defi += * dc.5_0
execute if score #c_def m.defi matches 5 run scoreboard players set #c_tgt m.defi 400
execute if score #c_def m.defi matches 6 run scoreboard players operation #c_tot m.defi += * dc.6_0
execute if score #c_def m.defi matches 6 run scoreboard players operation #c_tot m.defi += * dc.6_1
execute if score #c_def m.defi matches 6 run scoreboard players operation #c_tot m.defi += * dc.6_2
execute if score #c_def m.defi matches 6 run scoreboard players set #c_tgt m.defi 4000
execute if score #c_ok m.defi matches 0 if score #c_tot m.defi >= #c_tgt m.defi run function metiers:defis/collectif_fini
