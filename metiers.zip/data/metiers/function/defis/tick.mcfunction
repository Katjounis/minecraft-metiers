scoreboard players add #jour m.defi 1
execute unless score #d_b m.defi matches 1.. run function metiers:defis/nouveaux
execute if score #jour m.defi matches 172800.. run function metiers:defis/nouveaux
scoreboard players set #left m.defi 172800
scoreboard players operation #left m.defi -= #jour m.defi
scoreboard players operation #left m.defi /= #7200 m.const
scoreboard players add #left m.defi 1
