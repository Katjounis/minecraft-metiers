execute if entity @a run scoreboard players add #jour m.defi 1
execute unless score #d_b m.defi matches 1.. run function metiers:defis/nouveaux
execute if score #jour m.defi matches 28800.. run function metiers:defis/nouveaux
scoreboard players set #left m.defi 28800
scoreboard players operation #left m.defi -= #jour m.defi
scoreboard players operation #left m.defi /= #7200 m.const
scoreboard players add #left m.defi 1
execute if entity @a run scoreboard players add #semaine m.defi 1
execute unless score #s_def m.defi matches 1.. run function metiers:defis/semaine
execute if score #semaine m.defi matches 201600.. run function metiers:defis/semaine
scoreboard players set #sleft m.defi 201600
scoreboard players operation #sleft m.defi -= #semaine m.defi
scoreboard players operation #sleft m.defi /= #7200 m.const
scoreboard players add #sleft m.defi 1
execute if score #quatre m.timer matches 0 run function metiers:defis/collectif_total
execute unless score #d_b m.defi matches 1..8 run function metiers:defis/nouveaux
execute unless score #d_f m.defi matches 1..8 run function metiers:defis/nouveaux
execute unless score #d_m m.defi matches 1..9 run function metiers:defis/nouveaux
execute unless score #d_c m.defi matches 1..9 run function metiers:defis/nouveaux
execute unless score #d_p m.defi matches 1..6 run function metiers:defis/nouveaux
execute unless score #d_e m.defi matches 1..6 run function metiers:defis/nouveaux
execute unless score #d_n m.defi matches 1..5 run function metiers:defis/nouveaux
execute unless score #d_x m.defi matches 1..7 run function metiers:defis/nouveaux
execute unless score #d_t m.defi matches 1..4 run function metiers:defis/nouveaux
execute unless score #s_def m.defi matches 1..9 run function metiers:defis/semaine
execute unless score #c_def m.defi matches 1..6 run function metiers:defis/semaine
