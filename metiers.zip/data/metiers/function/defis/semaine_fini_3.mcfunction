scoreboard players set @s m.wd 1
scoreboard players add @s m.cr_m 20
scoreboard players add @s m.ecl 1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" a réussi le défi de la semaine ! ","color":"light_purple","bold":true},{"text":"+20 ","color":"aqua"},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" et 1 ","color":"aqua"},{"text": "", "font": "metiers:icones", "color": "white", "bold": false}]
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.8
