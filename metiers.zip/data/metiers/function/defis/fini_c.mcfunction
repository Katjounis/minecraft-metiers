scoreboard players set @s m.dd_c 1
scoreboard players add @s m.c_bal 400
give @s minecraft:diamond 2
give @s minecraft:experience_bottle 16
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" a réussi le défi du jour ","color":"gray"},{"text":"⚔ Chasseur","color":"red","bold":true}]
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
scoreboard players set @s m.tmp 0
execute if score @s m.dd_b matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.dd_f matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.dd_m matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.dd_c matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.dd_p matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.tmp matches 5 run function metiers:defis/tous
function metiers:defis/plus1
