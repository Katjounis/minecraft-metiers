$bossbar set metiers:d$(id) color purple
$bossbar set metiers:d$(id) style notched_10
$execute if score #d_e m.defi matches 1 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Éleveur : ","color":"light_purple","bold":true},{"text":"Fais naître 12 animaux  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_e"},"color":"yellow"},{"text":" / 12","color":"gray"}]
$execute if score #d_e m.defi matches 1 run bossbar set metiers:d$(id) max 12
$execute if score #d_e m.defi matches 2 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Éleveur : ","color":"light_purple","bold":true},{"text":"Fais naître 24 animaux  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_e"},"color":"yellow"},{"text":" / 24","color":"gray"}]
$execute if score #d_e m.defi matches 2 run bossbar set metiers:d$(id) max 24
$execute if score #d_e m.defi matches 3 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Éleveur : ","color":"light_purple","bold":true},{"text":"Tonds 32 laines blanches  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_e"},"color":"yellow"},{"text":" / 32","color":"gray"}]
$execute if score #d_e m.defi matches 3 run bossbar set metiers:d$(id) max 32
$execute if score #d_e m.defi matches 4 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Éleveur : ","color":"light_purple","bold":true},{"text":"Ramasse 32 œufs  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_e"},"color":"yellow"},{"text":" / 32","color":"gray"}]
$execute if score #d_e m.defi matches 4 run bossbar set metiers:d$(id) max 32
$execute if score #d_e m.defi matches 5 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Éleveur : ","color":"light_purple","bold":true},{"text":"Ramasse 16 cuirs  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_e"},"color":"yellow"},{"text":" / 16","color":"gray"}]
$execute if score #d_e m.defi matches 5 run bossbar set metiers:d$(id) max 16
$execute if score #d_e m.defi matches 6 run bossbar set metiers:d$(id) name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Défi Éleveur : ","color":"light_purple","bold":true},{"text":"Ramasse 32 plumes  ","color":"white","bold":false},{"score":{"name":"@s","objective":"m.dp_e"},"color":"yellow"},{"text":" / 32","color":"gray"}]
$execute if score #d_e m.defi matches 6 run bossbar set metiers:d$(id) max 32
$execute store result bossbar metiers:d$(id) value run scoreboard players get @s m.dp_e
