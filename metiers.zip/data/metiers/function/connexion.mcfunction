scoreboard players set @s m.quit 0
function metiers:recompenses
