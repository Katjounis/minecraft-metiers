execute as @a[distance=..16,gamemode=!spectator,gamemode=!creative] at @s run particle minecraft:snowflake ~ ~2 ~ 1 1 1 0.02 40
execute as @a[distance=..16,gamemode=!spectator,gamemode=!creative] run damage @s 5 minecraft:freeze
effect give @a[distance=..16,gamemode=!spectator,gamemode=!creative] minecraft:slowness 3 1
playsound minecraft:block.powder_snow.break hostile @a ~ ~ ~ 2 0.5
