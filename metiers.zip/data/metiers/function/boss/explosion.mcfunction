particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0 1
playsound minecraft:entity.generic.explode hostile @a ~ ~ ~ 2 0.8
execute as @a[distance=..3.5,gamemode=!spectator,gamemode=!creative] run damage @s 10 minecraft:explosion
