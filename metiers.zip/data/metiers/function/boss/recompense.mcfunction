scoreboard players add @s m.ecl 1
execute if entity @s[tag=metiers.btop] run scoreboard players add @s m.ecl 1
scoreboard players operation @s m.tmp = @s m.c_need
scoreboard players operation @s m.tmp /= #2 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
function metiers:c/gain
execute if score #type m.boss matches 1 run scoreboard players add @s m.bk1 1
execute if score #type m.boss matches 2 run scoreboard players add @s m.bk2 1
execute if score #type m.boss matches 3 run scoreboard players add @s m.bk3 1
execute if score #type m.boss matches 4 run scoreboard players add @s m.bk4 1
execute if score #type m.boss matches 5 run scoreboard players add @s m.bk5 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Récompense : ","color":"gold"},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" 1 éclat de boss et un demi-niveau de Chasseur.","color":"gold"}]
execute if entity @s[tag=metiers.btop] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Plus gros dégâts : +1 éclat de boss.","color":"light_purple"}]
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.4 80
