scoreboard players add @s m.c_bal 1500
give @s minecraft:netherite_ingot 2
give @s minecraft:enchanted_golden_apple 2
give @s minecraft:diamond 8
give @s minecraft:totem_of_undying 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Récompense du Colosse : 1500 XP Chasseur, 2 lingots de netherite, 2 pommes de Notch, 8 diamants et un totem.","color":"gold"}]
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.4 80
tag @s remove metiers.bossp
