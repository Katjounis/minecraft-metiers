execute as @p[distance=4..30,gamemode=!spectator,gamemode=!creative] at @s run tp @e[tag=metiers.boss,limit=1] ~ ~ ~
playsound minecraft:entity.ravager.attack hostile @a ~ ~ ~ 2 0.6
execute at @s as @a[distance=..4,gamemode=!spectator,gamemode=!creative] run damage @s 6 minecraft:mob_attack by @e[tag=metiers.boss,limit=1]
