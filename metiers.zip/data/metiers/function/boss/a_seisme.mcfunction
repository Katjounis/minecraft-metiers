particle minecraft:explosion ~ ~ ~ 4 0.2 4 0 30
playsound minecraft:entity.generic.explode hostile @a ~ ~ ~ 2 0.5
execute as @a[distance=..9,gamemode=!spectator,gamemode=!creative] run damage @s 8 minecraft:mob_attack by @e[tag=metiers.boss,limit=1]
effect give @a[distance=..9,gamemode=!spectator,gamemode=!creative] minecraft:levitation 1 3 true
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le Colosse frappe le sol !","color":"dark_red"}]
