tp @e[type=minecraft:zombie,tag=metiers.boss] ~ -400 ~
kill @e[tag=metiers.boss]
kill @e[tag=metiers.sbire]
scoreboard players set #actif m.boss 0
scoreboard players set #cycle m.boss 0
bossbar set metiers:boss visible false
tag @a remove metiers.bossp
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le Colosse s'est enfui... Il reviendra.","color":"gray"}]
