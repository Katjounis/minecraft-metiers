execute as @e[tag=metiers.boss,limit=1] run tp @s ~ -400 ~
kill @e[tag=metiers.boss]
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le boss s'est enfui... Il reviendra.","color":"gray"}]
function metiers:boss/fin
