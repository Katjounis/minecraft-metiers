effect give @a[distance=..12,gamemode=!spectator,gamemode=!creative] minecraft:wither 4 1
effect give @s minecraft:instant_damage 1 1 true
particle minecraft:soul ~ ~2 ~ 3 1 3 0.02 40
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"La Liche draine votre vie.","color":"aqua"}]
