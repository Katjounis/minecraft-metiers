scoreboard players set #enrage m.boss 1
execute as @e[type=minecraft:zombie,tag=metiers.boss,limit=1] at @s run function metiers:boss/sbires
effect give @e[type=minecraft:zombie,tag=metiers.boss] minecraft:speed infinite 1 true
effect give @e[type=minecraft:zombie,tag=metiers.boss] minecraft:strength infinite 0 true
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le Colosse est enragé et appelle ses sbires !","color":"red","bold":true}]
execute as @a at @s run playsound minecraft:entity.ravager.roar master @s ~ ~ ~ 1 0.4
