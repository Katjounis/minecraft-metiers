execute as @r[gamemode=!spectator] at @s run function metiers:boss/apparaitre
