kill @e[tag=metiers.sbire]
kill @e[type=minecraft:marker,tag=metiers.bmark]
scoreboard players set #actif m.boss 0
scoreboard players set #cycle m.boss 0
scoreboard players set #mk m.boss 0
bossbar set metiers:boss visible false
tag @a remove metiers.bossp
tag @a remove metiers.btop
scoreboard players set @a m.bdmg 0
