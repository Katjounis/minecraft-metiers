execute as @a[distance=..16,gamemode=!spectator,gamemode=!creative] at @s run particle minecraft:crit ~ ~1 ~ 0.6 1 0.6 0 30
effect give @a[distance=..16,gamemode=!spectator,gamemode=!creative] minecraft:slowness 4 3
effect give @a[distance=..16,gamemode=!spectator,gamemode=!creative] minecraft:mining_fatigue 4 1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Vous êtes pris dans la toile !","color":"dark_green"}]
