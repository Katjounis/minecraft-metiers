summon minecraft:zombie ~2 ~ ~0 {Tags:["metiers.sbire"],CustomName:{text:"Rejeton du Creeper",color:"green"},equipment:{head:{id:"minecraft:creeper_head",count:1}},drop_chances:{head:0f}}
summon minecraft:zombie ~-2 ~ ~0 {Tags:["metiers.sbire"],CustomName:{text:"Rejeton du Creeper",color:"green"},equipment:{head:{id:"minecraft:creeper_head",count:1}},drop_chances:{head:0f}}
summon minecraft:zombie ~0 ~ ~2 {Tags:["metiers.sbire"],CustomName:{text:"Rejeton du Creeper",color:"green"},equipment:{head:{id:"minecraft:creeper_head",count:1}},drop_chances:{head:0f}}
summon minecraft:zombie ~0 ~ ~-2 {Tags:["metiers.sbire"],CustomName:{text:"Rejeton du Creeper",color:"green"},equipment:{head:{id:"minecraft:creeper_head",count:1}},drop_chances:{head:0f}}
