execute unless score #actif m.boss matches 1 run return 0
scoreboard players set #top m.boss 0
execute as @a[tag=metiers.bossp] run scoreboard players operation #top m.boss > @s m.bdmg
execute as @a[tag=metiers.bossp] if score @s m.bdmg = #top m.boss run tag @s add metiers.btop
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le boss est terrassé ! ","color":"gold","bold":true},{"text":"Récompensés : ","color":"white"},{"selector":"@a[tag=metiers.bossp]","color":"yellow"},{"text":". Plus gros dégâts : ","color":"white"},{"selector":"@a[tag=metiers.btop]","color":"light_purple"}]
execute as @a[tag=metiers.bossp] at @s run function metiers:boss/recompense
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.7
function metiers:boss/fin
