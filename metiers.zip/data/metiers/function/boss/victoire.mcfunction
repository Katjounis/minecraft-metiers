execute unless score #actif m.boss matches 1 run return 0
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le Colosse des Métiers est terrassé ! ","color":"gold","bold":true},{"text":"Tous ceux qui l'ont frappé sont récompensés : ","color":"white"},{"selector":"@a[tag=metiers.bossp]","color":"yellow"}]
execute as @a[tag=metiers.bossp] at @s run function metiers:boss/recompense
kill @e[tag=metiers.sbire]
scoreboard players set #actif m.boss 0
scoreboard players set #cycle m.boss 0
bossbar set metiers:boss visible false
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.7
