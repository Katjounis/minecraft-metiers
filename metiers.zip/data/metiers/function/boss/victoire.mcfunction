advancement revoke @s only metiers:boss/tue
execute unless score #actif m.boss matches 1 run return 0
tag @s add metiers.bossp
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" a terrassé le Colosse des Métiers ! ","color":"gold","bold":true},{"text":"Tous les participants sont récompensés.","color":"white"}]
execute as @a[tag=metiers.bossp] at @s run function metiers:boss/recompense
kill @e[tag=metiers.sbire]
scoreboard players set #actif m.boss 0
scoreboard players set #cycle m.boss 0
bossbar set metiers:boss visible false
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.7
