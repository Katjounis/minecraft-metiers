$summon minecraft:blaze ~ ~ ~ {Tags:["metiers.boss"],CustomName:{text:"Le Brasier ancestral",color:"gold",bold:true},CustomNameVisible:1b,PersistenceRequired:1b,Health:$(hp)f,attributes:[{id:"minecraft:max_health",base:$(hp)d},{id:"minecraft:attack_damage",base:10d},{id:"minecraft:armor",base:12d},{id:"minecraft:knockback_resistance",base:1d},{id:"minecraft:movement_speed",base:0.3d},{id:"minecraft:follow_range",base:64d},{id:"minecraft:scale",base:2.5d}]}
effect give @e[tag=metiers.boss,limit=1] minecraft:fire_resistance infinite 0 true
bossbar set metiers:boss name {"text":"Le Brasier ancestral","color":"gold","bold":true}
bossbar set metiers:boss color yellow
