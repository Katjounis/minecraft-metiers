execute as @r[distance=..40,gamemode=!spectator,gamemode=!creative] at @s run tp @e[tag=metiers.boss,limit=1] ^ ^ ^-4
particle minecraft:reverse_portal ~ ~1 ~ 1 1 1 0.2 60
playsound minecraft:entity.enderman.teleport hostile @a ~ ~ ~ 2 0.5
