scoreboard players set #atk m.boss 0
execute if score #type m.boss matches 1 store result score #r m.boss run random value 1..2
execute if score #type m.boss matches 1 if score #r m.boss matches 1 run function metiers:boss/a_seisme
execute if score #type m.boss matches 1 if score #r m.boss matches 2 run function metiers:boss/a_bond
execute if score #type m.boss matches 2 store result score #r m.boss run random value 1..2
execute if score #type m.boss matches 2 if score #r m.boss matches 1 run function metiers:boss/a_venin
execute if score #type m.boss matches 2 if score #r m.boss matches 2 run function metiers:boss/a_toile
execute if score #type m.boss matches 3 store result score #r m.boss run random value 1..3
execute if score #type m.boss matches 3 if score #r m.boss matches 1 run function metiers:boss/a_drain
execute if score #type m.boss matches 3 if score #r m.boss matches 2 run function metiers:boss/a_blizzard
execute if score #type m.boss matches 3 if score #r m.boss matches 3 run function metiers:boss/a_clignement
execute if score #type m.boss matches 4 store result score #r m.boss run random value 1..2
execute if score #type m.boss matches 4 if score #r m.boss matches 1 run function metiers:boss/a_pluie_feu
execute if score #type m.boss matches 4 if score #r m.boss matches 2 run function metiers:boss/a_onde
execute if score #type m.boss matches 5 store result score #r m.boss run random value 1..2
execute if score #type m.boss matches 5 if score #r m.boss matches 1 run function metiers:boss/a_detonation
execute if score #type m.boss matches 5 if score #r m.boss matches 2 run function metiers:boss/a_souffle
