summon minecraft:magma_cube ~2 ~ ~0 {Tags:["metiers.sbire"],Size:2,CustomName:{text:"Braise vivante",color:"gold"}}
summon minecraft:magma_cube ~-2 ~ ~0 {Tags:["metiers.sbire"],Size:2,CustomName:{text:"Braise vivante",color:"gold"}}
summon minecraft:magma_cube ~0 ~ ~2 {Tags:["metiers.sbire"],Size:2,CustomName:{text:"Braise vivante",color:"gold"}}
