scoreboard players add #phase m.boss 1
execute if score #type m.boss matches 1 run function metiers:boss/vague_1
execute if score #type m.boss matches 2 run function metiers:boss/vague_2
execute if score #type m.boss matches 3 run function metiers:boss/vague_3
execute if score #type m.boss matches 4 run function metiers:boss/vague_4
execute if score #type m.boss matches 5 run function metiers:boss/vague_5
particle minecraft:large_smoke ~ ~1 ~ 2 1 2 0.05 120
execute as @a at @s run playsound minecraft:entity.ravager.roar master @s ~ ~ ~ 1 0.5
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le boss appelle ses renforts !","color":"red"}]
execute if score #phase m.boss matches 2 run effect give @s minecraft:speed infinite 0 true
execute if score #phase m.boss matches 2 run effect give @s minecraft:strength infinite 0 true
execute if score #phase m.boss matches 2 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le boss est enragé : ses attaques s'accélèrent.","color":"dark_red","bold":true}]
