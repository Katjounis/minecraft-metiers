execute as @a[distance=..20,gamemode=!spectator,gamemode=!creative] at @s run summon minecraft:marker ~ ~ ~ {Tags:["metiers.bmark"]}
scoreboard players set #mk m.boss 6
playsound minecraft:entity.creeper.primed hostile @a ~ ~ ~ 2 0.5
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le Creeper géant gonfle... éloignez-vous des cercles !","color":"green"}]
