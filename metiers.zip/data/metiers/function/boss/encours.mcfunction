scoreboard players add #temps m.boss 1
execute store result score #hp m.boss run data get entity @e[type=minecraft:zombie,tag=metiers.boss,limit=1] Health
execute if score #hp m.boss matches 1.. store result bossbar metiers:boss value run scoreboard players get #hp m.boss
bossbar set metiers:boss players @a
execute at @e[type=minecraft:zombie,tag=metiers.boss,limit=1] run particle minecraft:soul_fire_flame ~ ~2.5 ~ 0.8 1.6 0.8 0.02 8
execute if score #enrage m.boss matches 0 if score #hp m.boss matches 1..300 run function metiers:boss/enrage
execute if score #temps m.boss matches 3600.. run function metiers:boss/fuite
