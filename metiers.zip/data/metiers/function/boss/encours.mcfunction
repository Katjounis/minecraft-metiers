scoreboard players add #temps m.boss 1
execute store result score #hp m.boss run data get entity @e[type=minecraft:zombie,tag=metiers.boss,limit=1] Health
execute if score #hp m.boss matches 1.. store result bossbar metiers:boss value run scoreboard players get #hp m.boss
execute if entity @e[type=minecraft:zombie,tag=metiers.boss] run scoreboard players operation #last m.boss = #hp m.boss
execute as @a[scores={m.dmg=1..}] at @s if entity @e[type=minecraft:zombie,tag=metiers.boss,distance=..32] run tag @s add metiers.bossp
scoreboard players set @a m.dmg 0
execute unless entity @e[type=minecraft:zombie,tag=metiers.boss] if score #last m.boss matches ..90 run return run function metiers:boss/victoire
bossbar set metiers:boss players @a
execute at @e[type=minecraft:zombie,tag=metiers.boss,limit=1] run particle minecraft:soul_fire_flame ~ ~2.5 ~ 0.8 1.6 0.8 0.02 8
execute if score #enrage m.boss matches 0 if score #hp m.boss matches 1..300 run function metiers:boss/enrage
execute if score #temps m.boss matches 3600.. run function metiers:boss/fuite
