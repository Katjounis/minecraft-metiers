scoreboard players add #temps m.boss 1
execute store result score #hp m.boss run data get entity @e[tag=metiers.boss,limit=1] Health
execute if score #hp m.boss matches 1.. store result bossbar metiers:boss value run scoreboard players get #hp m.boss
execute if entity @e[tag=metiers.boss,limit=1] run scoreboard players operation #last m.boss = #hp m.boss
execute as @a[scores={m.dmg=1..}] at @s if entity @e[tag=metiers.boss,distance=..32] run function metiers:boss/frappe
scoreboard players set @a m.dmg 0
execute unless entity @e[tag=metiers.boss,limit=1] run return run function metiers:boss/disparu
bossbar set metiers:boss players @a
scoreboard players set #seuil m.boss 0
scoreboard players operation #seuil m.boss = #max m.boss
scoreboard players operation #seuil m.boss *= #2 m.const
scoreboard players operation #hp3 m.boss = #hp m.boss
scoreboard players operation #hp3 m.boss *= #3 m.const
execute if score #phase m.boss matches 0 if score #hp3 m.boss <= #seuil m.boss as @e[tag=metiers.boss,limit=1] at @s run function metiers:boss/vague
scoreboard players operation #seuil m.boss = #max m.boss
execute if score #phase m.boss matches 1 if score #hp3 m.boss <= #seuil m.boss as @e[tag=metiers.boss,limit=1] at @s run function metiers:boss/vague
scoreboard players add #atk m.boss 1
execute if score #phase m.boss matches 2 run scoreboard players add #atk m.boss 1
execute if score #atk m.boss matches 16.. as @e[tag=metiers.boss,limit=1] at @s run function metiers:boss/attaque
execute if score #mk m.boss matches 1.. run function metiers:boss/marques
execute at @e[tag=metiers.boss,limit=1] run function metiers:boss/particules
execute if score #type m.boss matches 5 if score #temps m.boss matches 2400.. run function metiers:boss/fuite
execute if score #temps m.boss matches 3600.. run function metiers:boss/fuite
