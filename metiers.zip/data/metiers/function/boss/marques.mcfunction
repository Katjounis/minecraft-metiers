scoreboard players remove #mk m.boss 1
execute at @e[type=minecraft:marker,tag=metiers.bmark] run particle minecraft:dust{color:[1.0,0.2,0.2],scale:1.5} ~ ~0.1 ~ 1.5 0 1.5 0 30
execute if score #mk m.boss matches 0 at @e[type=minecraft:marker,tag=metiers.bmark] run function metiers:boss/explosion
execute if score #mk m.boss matches 0 run kill @e[type=minecraft:marker,tag=metiers.bmark]
