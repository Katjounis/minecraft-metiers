execute if score #tue m.boss matches 1 run return run function metiers:boss/victoire
scoreboard players operation #seuil m.boss = #max m.boss
scoreboard players operation #seuil m.boss /= #4 m.const
execute if score #last m.boss <= #seuil m.boss run return run function metiers:boss/victoire
function metiers:boss/fuite
