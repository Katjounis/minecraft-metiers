tag @s add metiers.bossp
scoreboard players operation @s m.bdmg += @s m.dmg
