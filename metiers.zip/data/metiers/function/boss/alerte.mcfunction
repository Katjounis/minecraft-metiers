execute store result score #n m.boss if entity @a
execute if score #n m.boss matches ..1 run return run scoreboard players set #cycle m.boss 18000
scoreboard players set #cycle m.boss 0
scoreboard players set #compte m.boss 240
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le Colosse des Métiers se réveille ! ","color":"dark_red","bold":true},{"text":"Il apparaît dans 2 minutes près d'un joueur au hasard. Préparez-vous.","color":"white"}]
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.6 0.6
