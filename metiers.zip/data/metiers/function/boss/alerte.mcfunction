execute store result score #n m.boss if entity @a[gamemode=!spectator]
execute if score #n m.boss matches ..1 run return run scoreboard players set #cycle m.boss 18000
scoreboard players set #cycle m.boss 0
scoreboard players set #compte m.boss 240
scoreboard players add #type m.boss 1
execute unless score #type m.boss matches 1..5 run scoreboard players set #type m.boss 1
execute if score #type m.boss matches 1 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le Colosse des Métiers se réveille ! ","color":"dark_red","bold":true},{"text":"Il apparaît dans 2 minutes près d'un joueur au hasard. Préparez-vous.","color":"white"}]
execute if score #type m.boss matches 2 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"La Reine arachnide se réveille ! ","color":"dark_green","bold":true},{"text":"Il apparaît dans 2 minutes près d'un joueur au hasard. Préparez-vous.","color":"white"}]
execute if score #type m.boss matches 3 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"La Liche du givre se réveille ! ","color":"aqua","bold":true},{"text":"Il apparaît dans 2 minutes près d'un joueur au hasard. Préparez-vous.","color":"white"}]
execute if score #type m.boss matches 4 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le Brasier ancestral se réveille ! ","color":"gold","bold":true},{"text":"Il apparaît dans 2 minutes près d'un joueur au hasard. Préparez-vous.","color":"white"}]
execute if score #type m.boss matches 5 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le Creeper géant se réveille ! ","color":"white","bold":true},{"text":"Il apparaît dans 2 minutes près d'un joueur au hasard. Préparez-vous.","color":"white"}]
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.6 0.6
