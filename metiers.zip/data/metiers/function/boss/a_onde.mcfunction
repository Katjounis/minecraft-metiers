particle minecraft:flame ~ ~1 ~ 4 0.3 4 0.1 120
execute as @a[distance=..8,gamemode=!spectator,gamemode=!creative] run damage @s 9 minecraft:on_fire
playsound minecraft:item.firecharge.use hostile @a ~ ~ ~ 2 0.5
