advancement revoke @s only metiers:boss_tue
scoreboard players set #tue m.boss 1
tag @s add metiers.bossp
