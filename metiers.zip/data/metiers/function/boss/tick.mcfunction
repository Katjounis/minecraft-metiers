scoreboard players add #cycle m.boss 1
execute if score #actif m.boss matches 0 if score #compte m.boss matches 1.. run function metiers:boss/compte
execute if score #actif m.boss matches 0 if score #compte m.boss matches ..0 if score #cycle m.boss matches 21600.. run function metiers:boss/alerte
execute if score #actif m.boss matches 1 run function metiers:boss/encours
