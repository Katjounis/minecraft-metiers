summon minecraft:cave_spider ~2 ~ ~0 {Tags:["metiers.sbire"],CustomName:{text:"Couvée de la Reine",color:"green"}}
summon minecraft:cave_spider ~-2 ~ ~0 {Tags:["metiers.sbire"],CustomName:{text:"Couvée de la Reine",color:"green"}}
summon minecraft:cave_spider ~0 ~ ~2 {Tags:["metiers.sbire"],CustomName:{text:"Couvée de la Reine",color:"green"}}
summon minecraft:cave_spider ~0 ~ ~-2 {Tags:["metiers.sbire"],CustomName:{text:"Couvée de la Reine",color:"green"}}
summon minecraft:cave_spider ~2 ~ ~2 {Tags:["metiers.sbire"],CustomName:{text:"Couvée de la Reine",color:"green"}}
