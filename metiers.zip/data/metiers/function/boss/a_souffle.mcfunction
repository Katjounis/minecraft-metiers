particle minecraft:explosion_emitter ~ ~1 ~ 0 0 0 0 1
playsound minecraft:entity.generic.explode hostile @a ~ ~ ~ 3 0.6
execute as @a[distance=..7,gamemode=!spectator,gamemode=!creative] run damage @s 12 minecraft:explosion
