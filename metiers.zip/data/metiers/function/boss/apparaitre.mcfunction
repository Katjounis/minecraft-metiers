summon minecraft:zombie ~ ~ ~ {Tags:["metiers.boss"],CustomName:{text:"Le Colosse des Métiers",color:"dark_red",bold:true},CustomNameVisible:1b,PersistenceRequired:1b,CanPickUpLoot:0b,Health:600f,attributes:[{id:"minecraft:max_health",base:600d},{id:"minecraft:attack_damage",base:14d},{id:"minecraft:armor",base:16d},{id:"minecraft:knockback_resistance",base:1d},{id:"minecraft:movement_speed",base:0.3d},{id:"minecraft:follow_range",base:64d},{id:"minecraft:scale",base:2.5d},{id:"minecraft:spawn_reinforcements",base:0d}],equipment:{head:{id:"minecraft:netherite_helmet",count:1},chest:{id:"minecraft:netherite_chestplate",count:1},legs:{id:"minecraft:netherite_leggings",count:1},feet:{id:"minecraft:netherite_boots",count:1},mainhand:{id:"minecraft:netherite_axe",count:1}},drop_chances:{head:0f,chest:0f,legs:0f,feet:0f,mainhand:0f}}
spreadplayers ~ ~ 6 14 false @e[type=minecraft:zombie,tag=metiers.boss,limit=1]
scoreboard players set #actif m.boss 1
scoreboard players set #temps m.boss 0
scoreboard players set #enrage m.boss 0
scoreboard players set #last m.boss 600
scoreboard players set @a m.dmg 0
bossbar set metiers:boss value 600
bossbar set metiers:boss visible true
bossbar set metiers:boss players @a
execute store result score #x m.boss run data get entity @e[type=minecraft:zombie,tag=metiers.boss,limit=1] Pos[0]
execute store result score #y m.boss run data get entity @e[type=minecraft:zombie,tag=metiers.boss,limit=1] Pos[1]
execute store result score #z m.boss run data get entity @e[type=minecraft:zombie,tag=metiers.boss,limit=1] Pos[2]
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le Colosse est apparu près de ","color":"dark_red","bold":true},{"selector":"@s"},{"text":" en ","color":"white"},{"score":{"name":"#x","objective":"m.boss"},"color":"yellow"},{"text":" ","color":"white"},{"score":{"name":"#y","objective":"m.boss"},"color":"yellow"},{"text":" ","color":"white"},{"score":{"name":"#z","objective":"m.boss"},"color":"yellow"},{"text":". Tous ceux qui le frappent sont récompensés !","color":"white"}]
execute as @a at @s run playsound minecraft:entity.ravager.roar master @s ~ ~ ~ 1 0.6
