execute store result score #n m.boss if entity @a[gamemode=!spectator]
scoreboard players operation #max m.boss = #n m.boss
scoreboard players operation #max m.boss *= #150 m.const
scoreboard players add #max m.boss 250
execute store result storage metiers:boss hp int 1 run scoreboard players get #max m.boss
execute if score #type m.boss matches 1 run function metiers:boss/apparaitre_1 with storage metiers:boss
execute if score #type m.boss matches 2 run function metiers:boss/apparaitre_2 with storage metiers:boss
execute if score #type m.boss matches 3 run function metiers:boss/apparaitre_3 with storage metiers:boss
execute if score #type m.boss matches 4 run function metiers:boss/apparaitre_4 with storage metiers:boss
execute if score #type m.boss matches 5 run function metiers:boss/apparaitre_5 with storage metiers:boss
spreadplayers ~ ~ 6 14 false @e[tag=metiers.boss,limit=1]
scoreboard players set #actif m.boss 1
scoreboard players set #temps m.boss 0
scoreboard players set #phase m.boss 0
scoreboard players set #atk m.boss 0
scoreboard players set #tue m.boss 0
scoreboard players set #mk m.boss 0
scoreboard players operation #last m.boss = #max m.boss
scoreboard players set @a m.dmg 0
scoreboard players set @a m.bdmg 0
execute store result bossbar metiers:boss max run scoreboard players get #max m.boss
execute store result bossbar metiers:boss value run scoreboard players get #max m.boss
bossbar set metiers:boss style notched_10
bossbar set metiers:boss visible true
bossbar set metiers:boss players @a
execute store result score #x m.boss run data get entity @e[tag=metiers.boss,limit=1] Pos[0]
execute store result score #y m.boss run data get entity @e[tag=metiers.boss,limit=1] Pos[1]
execute store result score #z m.boss run data get entity @e[tag=metiers.boss,limit=1] Pos[2]
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Le boss est apparu près de ","color":"red","bold":true},{"selector":"@s"},{"text":" en ","color":"white"},{"score":{"name":"#x","objective":"m.boss"},"color":"yellow"},{"text":" ","color":"white"},{"score":{"name":"#y","objective":"m.boss"},"color":"yellow"},{"text":" ","color":"white"},{"score":{"name":"#z","objective":"m.boss"},"color":"yellow"},{"text":". PV : ","color":"white"},{"score":{"name":"#max","objective":"m.boss"},"color":"red"},{"text":". Chaque participant gagne un éclat de boss.","color":"white"}]
execute as @a at @s run playsound minecraft:entity.ravager.roar master @s ~ ~ ~ 1 0.6
