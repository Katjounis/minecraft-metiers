scoreboard players remove #compte m.boss 1
execute if score #compte m.boss matches 0 run function metiers:boss/invoquer
