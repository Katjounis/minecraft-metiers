$summon minecraft:creeper ~ ~ ~ {Tags:["metiers.boss"],CustomName:{text:"Le Creeper géant",color:"white",bold:true},CustomNameVisible:1b,PersistenceRequired:1b,Health:$(hp)f,attributes:[{id:"minecraft:max_health",base:$(hp)d},{id:"minecraft:attack_damage",base:1d},{id:"minecraft:armor",base:14d},{id:"minecraft:knockback_resistance",base:1d},{id:"minecraft:movement_speed",base:0.28d},{id:"minecraft:follow_range",base:64d},{id:"minecraft:scale",base:3.0d}],Fuse:32767s,ExplosionRadius:0b}
effect give @e[tag=metiers.boss,limit=1] minecraft:fire_resistance infinite 0 true
bossbar set metiers:boss name {"text":"Le Creeper géant","color":"white","bold":true}
bossbar set metiers:boss color white
