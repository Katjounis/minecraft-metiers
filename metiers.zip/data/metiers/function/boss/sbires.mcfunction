summon minecraft:zombie ~2 ~ ~0 {Tags:["metiers.sbire"],CustomName:{text:"Sbire du Colosse",color:"red"},equipment:{head:{id:"minecraft:iron_helmet",count:1}},drop_chances:{head:0f}}
summon minecraft:zombie ~-2 ~ ~0 {Tags:["metiers.sbire"],CustomName:{text:"Sbire du Colosse",color:"red"},equipment:{head:{id:"minecraft:iron_helmet",count:1}},drop_chances:{head:0f}}
summon minecraft:zombie ~0 ~ ~2 {Tags:["metiers.sbire"],CustomName:{text:"Sbire du Colosse",color:"red"},equipment:{head:{id:"minecraft:iron_helmet",count:1}},drop_chances:{head:0f}}
summon minecraft:zombie ~0 ~ ~-2 {Tags:["metiers.sbire"],CustomName:{text:"Sbire du Colosse",color:"red"},equipment:{head:{id:"minecraft:iron_helmet",count:1}},drop_chances:{head:0f}}
particle minecraft:large_smoke ~ ~1 ~ 2 1 2 0.05 120
