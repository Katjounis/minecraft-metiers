execute if score #type m.boss matches 1 run particle minecraft:soul_fire_flame ~ ~2.5 ~ 0.9 1.6 0.9 0.02 10
execute if score #type m.boss matches 2 run particle minecraft:spore_blossom_air ~ ~2.5 ~ 0.9 1.6 0.9 0.02 10
execute if score #type m.boss matches 3 run particle minecraft:snowflake ~ ~2.5 ~ 0.9 1.6 0.9 0.02 10
execute if score #type m.boss matches 4 run particle minecraft:flame ~ ~2.5 ~ 0.9 1.6 0.9 0.02 10
execute if score #type m.boss matches 5 run particle minecraft:happy_villager ~ ~2.5 ~ 0.9 1.6 0.9 0.02 10
