tag @s add metiers.bossp
advancement revoke @s only metiers:boss/touche
