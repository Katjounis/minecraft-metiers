execute as @a[distance=..20,gamemode=!spectator,gamemode=!creative] at @s run particle minecraft:flame ~ ~3 ~ 1 0.5 1 0.02 40
execute as @a[distance=..20,gamemode=!spectator,gamemode=!creative] at @s run particle minecraft:lava ~ ~1 ~ 1 0.5 1 0 10
execute as @a[distance=..20,gamemode=!spectator,gamemode=!creative] run damage @s 6 minecraft:in_fire
playsound minecraft:entity.blaze.shoot hostile @a ~ ~ ~ 2 0.5
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"Une pluie de braises s’abat !","color":"gold"}]
