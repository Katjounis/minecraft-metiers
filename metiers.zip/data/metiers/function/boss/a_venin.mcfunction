particle minecraft:item_slime ~ ~1 ~ 4 1 4 0 60
effect give @a[distance=..10,gamemode=!spectator,gamemode=!creative] minecraft:poison 6 1
playsound minecraft:entity.spider.ambient hostile @a ~ ~ ~ 2 0.5
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"La Reine crache son venin.","color":"dark_green"}]
