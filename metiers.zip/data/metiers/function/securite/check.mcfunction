execute store result storage metiers:sec o int 1 run scoreboard players get @s m.id
execute store result storage metiers:sec sa int 1 run scoreboard players get @s m.aser
execute store result storage metiers:sec sb int 1 run scoreboard players get @s m.b_ser
execute store result storage metiers:sec sf int 1 run scoreboard players get @s m.f_ser
execute store result storage metiers:sec sm int 1 run scoreboard players get @s m.m_ser
execute store result storage metiers:sec sc int 1 run scoreboard players get @s m.c_ser
execute store result storage metiers:sec sp int 1 run scoreboard players get @s m.p_ser
execute store result storage metiers:sec se int 1 run scoreboard players get @s m.e_ser
execute store result storage metiers:sec sn int 1 run scoreboard players get @s m.n_ser
execute store result storage metiers:sec sx int 1 run scoreboard players get @s m.x_ser
execute store result storage metiers:sec st int 1 run scoreboard players get @s m.t_ser
function metiers:securite/check_m with storage metiers:sec
