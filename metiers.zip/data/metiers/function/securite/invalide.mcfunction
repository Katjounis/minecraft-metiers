$item replace entity @s $(slot) with minecraft:air
playsound minecraft:entity.item.break master @s ~ ~ ~ 1 0.8
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cet objet de métier n'est plus valide (copie, ancien exemplaire ou objet d'un autre joueur) : il disparaît. Le tien se récupère avec la touche G.","color":"red"}]
