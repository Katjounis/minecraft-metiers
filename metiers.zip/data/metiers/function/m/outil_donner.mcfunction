clear @s *[minecraft:custom_data~{metiers_outil:"m"}]
scoreboard players add @s m.m_ser 1
execute store result storage metiers:tmp o int 1 run scoreboard players get @s m.id
execute store result storage metiers:tmp s int 1 run scoreboard players get @s m.m_ser
function metiers:m/outil_donner_m with storage metiers:tmp
playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.6 1.4
