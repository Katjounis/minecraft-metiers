$data modify storage metiers:fonte out set value "$(out)"
$execute store result storage metiers:fonte n int 1 run clear @s minecraft:$(raw)
function metiers:m/fonte_give with storage metiers:fonte
playsound minecraft:block.furnace.fire_crackle master @s ~ ~ ~ 0.6 1.2
