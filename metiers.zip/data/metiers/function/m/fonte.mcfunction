execute store result score @s m.tmp run clear @s minecraft:raw_iron 0
execute if score @s m.tmp matches 1.. run function metiers:m/fonte_item {raw:"raw_iron",out:"iron_ingot"}
execute store result score @s m.tmp run clear @s minecraft:raw_gold 0
execute if score @s m.tmp matches 1.. run function metiers:m/fonte_item {raw:"raw_gold",out:"gold_ingot"}
execute store result score @s m.tmp run clear @s minecraft:raw_copper 0
execute if score @s m.tmp matches 1.. run function metiers:m/fonte_item {raw:"raw_copper",out:"copper_ingot"}
