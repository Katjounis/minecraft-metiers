scoreboard players operation @s m.gain = @s m.m_bal
scoreboard players set @s m.m_bal 0
scoreboard players operation @s m.tmp = @s m.gain
scoreboard players operation @s m.tmp *= @s m.m_pr
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.gain += @s m.tmp
execute if score #job m.heure matches 3 run scoreboard players operation @s m.gain *= #2 m.const
execute if score @s m.m_lvl matches 100.. run return 0
scoreboard players operation @s m.m_xp += @s m.gain
function metiers:m/check
title @s actionbar [{"text":"+","color":"green"},{"score":{"name":"@s","objective":"m.gain"},"color":"green"},{"text":" XP Mineur","color":"gray"},{"text":"  |  niv ","color":"gray"},{"score":{"name":"@s","objective":"m.m_lvl"},"color":"white"},{"text":"  (","color":"gray"},{"score":{"name":"@s","objective":"m.m_xp"},"color":"white"},{"text":"/","color":"gray"},{"score":{"name":"@s","objective":"m.m_need"},"color":"white"},{"text":")","color":"gray"}]
