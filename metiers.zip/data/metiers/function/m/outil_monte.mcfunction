scoreboard players operation @s m.tmp = @s m.m_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.m_out >= @s m.tmp run return 0
scoreboard players operation @s m.m_out = @s m.tmp
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" fait évoluer son outil de Mineur !","color":"gray","bold":true}]
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"m"}] run return run function metiers:m/outil_donner
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"m"}] run return run function metiers:m/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton outil de Mineur a évolué : récupère-le avec G, Mineur, « Récupérer mon outil ».","color":"yellow"}]
