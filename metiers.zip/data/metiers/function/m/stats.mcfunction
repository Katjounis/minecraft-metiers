# Anti-triche : poser ou jeter l'objet retire l'XP gagnée
scoreboard players operation @s m.tmp = @s s.m.mi.stone
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.stone 0
scoreboard players operation @s m.tmp = @s s.m.us.stone
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.stone 0
scoreboard players operation @s m.tmp = @s s.m.mi.deepslate
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.deepslate 0
scoreboard players operation @s m.tmp = @s s.m.us.deepslate
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.deepslate 0
scoreboard players operation @s m.tmp = @s s.m.mi.andesite
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.andesite 0
scoreboard players operation @s m.tmp = @s s.m.us.andesite
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.andesite 0
scoreboard players operation @s m.tmp = @s s.m.mi.diorite
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.diorite 0
scoreboard players operation @s m.tmp = @s s.m.us.diorite
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.diorite 0
scoreboard players operation @s m.tmp = @s s.m.mi.granite
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.granite 0
scoreboard players operation @s m.tmp = @s s.m.us.granite
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.granite 0
scoreboard players operation @s m.tmp = @s s.m.mi.tuff
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.tuff 0
scoreboard players operation @s m.tmp = @s s.m.us.tuff
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.tuff 0
scoreboard players operation @s m.tmp = @s s.m.mi.blackstone
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.blackstone 0
scoreboard players operation @s m.tmp = @s s.m.us.blackstone
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.blackstone 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.coal_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.coal_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:coal 1
scoreboard players operation @s m.tmp = @s s.m.mi.coal_ore
scoreboard players operation @s m.tmp *= #8 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.coal_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.coal_ore
scoreboard players operation @s m.tmp *= #8 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.coal_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_coal_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_coal_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:coal 1
scoreboard players operation @s m.tmp = @s s.m.mi.deepslate_coal_ore
scoreboard players operation @s m.tmp *= #10 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.deepslate_coal_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.deepslate_coal_ore
scoreboard players operation @s m.tmp *= #10 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.deepslate_coal_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.copper_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.copper_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:raw_copper 2
scoreboard players operation @s m.tmp = @s s.m.mi.copper_ore
scoreboard players operation @s m.tmp *= #6 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.copper_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.copper_ore
scoreboard players operation @s m.tmp *= #6 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.copper_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_copper_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_copper_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:raw_copper 2
scoreboard players operation @s m.tmp = @s s.m.mi.deepslate_copper_ore
scoreboard players operation @s m.tmp *= #8 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.deepslate_copper_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.deepslate_copper_ore
scoreboard players operation @s m.tmp *= #8 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.deepslate_copper_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.iron_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.iron_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:raw_iron 1
scoreboard players operation @s m.tmp = @s s.m.mi.iron_ore
scoreboard players operation @s m.tmp *= #16 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.iron_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.iron_ore
scoreboard players operation @s m.tmp *= #16 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.iron_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_iron_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_iron_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:raw_iron 1
scoreboard players operation @s m.tmp = @s s.m.mi.deepslate_iron_ore
scoreboard players operation @s m.tmp *= #20 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.deepslate_iron_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.deepslate_iron_ore
scoreboard players operation @s m.tmp *= #20 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.deepslate_iron_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.gold_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.gold_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:raw_gold 1
scoreboard players operation @s m.tmp = @s s.m.mi.gold_ore
scoreboard players operation @s m.tmp *= #24 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.gold_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.gold_ore
scoreboard players operation @s m.tmp *= #24 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.gold_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_gold_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_gold_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:raw_gold 1
scoreboard players operation @s m.tmp = @s s.m.mi.deepslate_gold_ore
scoreboard players operation @s m.tmp *= #28 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.deepslate_gold_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.deepslate_gold_ore
scoreboard players operation @s m.tmp *= #28 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.deepslate_gold_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.redstone_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.redstone_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:redstone 4
scoreboard players operation @s m.tmp = @s s.m.mi.redstone_ore
scoreboard players operation @s m.tmp *= #12 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.redstone_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.redstone_ore
scoreboard players operation @s m.tmp *= #12 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.redstone_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_redstone_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_redstone_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:redstone 4
scoreboard players operation @s m.tmp = @s s.m.mi.deepslate_redstone_ore
scoreboard players operation @s m.tmp *= #14 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.deepslate_redstone_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.deepslate_redstone_ore
scoreboard players operation @s m.tmp *= #14 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.deepslate_redstone_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.lapis_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.lapis_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:lapis_lazuli 4
scoreboard players operation @s m.tmp = @s s.m.mi.lapis_ore
scoreboard players operation @s m.tmp *= #20 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.lapis_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.lapis_ore
scoreboard players operation @s m.tmp *= #20 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.lapis_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_lapis_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_lapis_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:lapis_lazuli 4
scoreboard players operation @s m.tmp = @s s.m.mi.deepslate_lapis_ore
scoreboard players operation @s m.tmp *= #24 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.deepslate_lapis_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.deepslate_lapis_ore
scoreboard players operation @s m.tmp *= #24 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.deepslate_lapis_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.diamond_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.diamond_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:diamond 1
scoreboard players operation @s m.tmp = @s s.m.mi.diamond_ore
scoreboard players operation @s m.tmp *= #80 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.diamond_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.diamond_ore
scoreboard players operation @s m.tmp *= #80 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.diamond_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_diamond_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_diamond_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:diamond 1
scoreboard players operation @s m.tmp = @s s.m.mi.deepslate_diamond_ore
scoreboard players operation @s m.tmp *= #90 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.deepslate_diamond_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.deepslate_diamond_ore
scoreboard players operation @s m.tmp *= #90 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.deepslate_diamond_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.emerald_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.emerald_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:emerald 1
scoreboard players operation @s m.tmp = @s s.m.mi.emerald_ore
scoreboard players operation @s m.tmp *= #100 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.emerald_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.emerald_ore
scoreboard players operation @s m.tmp *= #100 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.emerald_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_emerald_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.deepslate_emerald_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:emerald 1
scoreboard players operation @s m.tmp = @s s.m.mi.deepslate_emerald_ore
scoreboard players operation @s m.tmp *= #110 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.deepslate_emerald_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.deepslate_emerald_ore
scoreboard players operation @s m.tmp *= #110 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.deepslate_emerald_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.nether_gold_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.nether_gold_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:gold_nugget 3
scoreboard players operation @s m.tmp = @s s.m.mi.nether_gold_ore
scoreboard players operation @s m.tmp *= #6 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.nether_gold_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.nether_gold_ore
scoreboard players operation @s m.tmp *= #6 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.nether_gold_ore 0
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.nether_quartz_ore matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.m3] if score @s s.m.mi.nether_quartz_ore matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:quartz 1
scoreboard players operation @s m.tmp = @s s.m.mi.nether_quartz_ore
scoreboard players operation @s m.tmp *= #6 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.nether_quartz_ore 0
scoreboard players operation @s m.tmp = @s s.m.us.nether_quartz_ore
scoreboard players operation @s m.tmp *= #6 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.nether_quartz_ore 0
scoreboard players operation @s m.tmp = @s s.m.mi.ancient_debris
scoreboard players operation @s m.tmp *= #160 m.const
scoreboard players operation @s m.m_raw += @s m.tmp
scoreboard players set @s s.m.mi.ancient_debris 0
scoreboard players operation @s m.tmp = @s s.m.us.ancient_debris
scoreboard players operation @s m.tmp *= #160 m.const
scoreboard players operation @s m.m_raw -= @s m.tmp
scoreboard players set @s s.m.us.ancient_debris 0
execute if score @s m.m_raw matches 4.. run scoreboard players operation @s m.tmp = @s m.m_raw
execute if score @s m.m_raw matches 4.. run scoreboard players operation @s m.tmp /= #4 m.const
execute if score @s m.m_raw matches 4.. run scoreboard players operation @s m.m_bal += @s m.tmp
execute if score @s m.m_raw matches 4.. run scoreboard players operation @s m.tmp *= #4 m.const
execute if score @s m.m_raw matches 4.. run scoreboard players operation @s m.m_raw -= @s m.tmp
execute if score @s m.m_bal matches 1.. run function metiers:m/gain
