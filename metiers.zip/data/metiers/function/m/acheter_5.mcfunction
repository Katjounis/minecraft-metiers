execute if entity @s[tag=metiers.sk.m5] run return run function metiers:m/arbre
function metiers:m/points
execute unless entity @s[tag=metiers.sk.m3] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Filon chanceux.","color":"red"}]
execute unless entity @s[tag=metiers.sk.m3] run return run function metiers:m/arbre
execute if score @s m.tmp matches ..23 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (24 requis).","color":"red"}]
execute if score @s m.tmp matches ..23 run return run function metiers:m/arbre
scoreboard players add @s m.m_spent 24
tag @s add metiers.sk.m5
advancement grant @s only metiers:m/competence_5
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Fonte automatique","color":"gray","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:m/arbre
