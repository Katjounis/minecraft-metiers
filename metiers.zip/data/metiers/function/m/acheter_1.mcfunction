execute if entity @s[tag=metiers.sk.m1] run return run function metiers:m/arbre
function metiers:m/points
execute if score @s m.tmp matches ..5 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (6 requis).","color":"red"}]
execute if score @s m.tmp matches ..5 run return run function metiers:m/arbre
scoreboard players add @s m.m_spent 6
tag @s add metiers.sk.m1
advancement grant @s only metiers:m/competence_1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Coup de pioche","color":"gray","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:m/arbre
