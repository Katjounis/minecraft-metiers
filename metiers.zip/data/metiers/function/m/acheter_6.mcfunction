execute if entity @s[tag=metiers.sk.m6] run return run function metiers:m/arbre
function metiers:m/points
execute unless entity @s[tag=metiers.sk.m4,tag=metiers.sk.m5] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Bras de fer + Fonte automatique.","color":"red"}]
execute unless entity @s[tag=metiers.sk.m4,tag=metiers.sk.m5] run return run function metiers:m/arbre
execute if score @s m.tmp matches ..31 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (32 requis).","color":"red"}]
execute if score @s m.tmp matches ..31 run return run function metiers:m/arbre
scoreboard players add @s m.m_spent 32
tag @s add metiers.sk.m6
advancement grant @s only metiers:m/competence_6
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Cœur de la montagne","color":"gray","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:m/arbre
