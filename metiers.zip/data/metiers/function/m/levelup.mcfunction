scoreboard players operation @s m.m_xp -= @s m.m_need
scoreboard players add @s m.m_lvl 1
xp add @s 2 levels
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
tellraw @a [{"selector":"@s","color":"white"},{"text":" passe ","color":"gray"},{"text":"Mineur","color":"gray"},{"text":" niveau ","color":"gray"},{"score":{"name":"@s","objective":"m.m_lvl"},"color":"yellow"}]
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"+1 point de compétence Mineur.","color":"yellow"}]
execute if score @s m.m_lvl matches 10 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "white", "text": "Initié Mineur"}]
execute if score @s m.m_lvl matches 20 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "gray", "text": "Compagnon Mineur"}]
execute if score @s m.m_lvl matches 30 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "gray", "bold": true, "text": "Artisan Mineur"}]
execute if score @s m.m_lvl matches 40 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "yellow", "bold": true, "text": "Expert Mineur"}]
execute if score @s m.m_lvl matches 50 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "gold", "bold": true, "text": "Vétéran Mineur"}]
execute if score @s m.m_lvl matches 60 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "red", "bold": true, "text": "Maître Mineur"}]
execute if score @s m.m_lvl matches 70 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "light_purple", "bold": true, "text": "Grand Maître Mineur"}]
execute if score @s m.m_lvl matches 80 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "dark_purple", "bold": true, "text": "Légende Mineur"}]
execute if score @s m.m_lvl matches 90 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "aqua", "bold": true, "text": "Mythique Mineur"}]
execute if score @s m.m_lvl matches 100 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "dark_red", "bold": true, "text": "Dieu Mineur"}]
tag @s add metiers.maj
execute if score @s m.m_lvl matches 100 run scoreboard players set @s m.m_xp 0
execute if score @s m.m_lvl matches 10 run function metiers:appel {f:"m/outil_monte"}
execute if score @s m.m_lvl matches 10 run function metiers:recompenses
execute if score @s m.m_lvl matches 20 run function metiers:appel {f:"m/outil_monte"}
execute if score @s m.m_lvl matches 20 run function metiers:recompenses
execute if score @s m.m_lvl matches 30 run function metiers:appel {f:"m/outil_monte"}
execute if score @s m.m_lvl matches 30 run function metiers:recompenses
execute if score @s m.m_lvl matches 40 run function metiers:appel {f:"m/outil_monte"}
execute if score @s m.m_lvl matches 40 run function metiers:recompenses
execute if score @s m.m_lvl matches 50 run function metiers:appel {f:"m/outil_monte"}
execute if score @s m.m_lvl matches 50 run function metiers:recompenses
execute if score @s m.m_lvl matches 60 run function metiers:appel {f:"m/outil_monte"}
execute if score @s m.m_lvl matches 60 run function metiers:recompenses
execute if score @s m.m_lvl matches 70 run function metiers:appel {f:"m/outil_monte"}
execute if score @s m.m_lvl matches 70 run function metiers:recompenses
execute if score @s m.m_lvl matches 80 run function metiers:appel {f:"m/outil_monte"}
execute if score @s m.m_lvl matches 80 run function metiers:recompenses
execute if score @s m.m_lvl matches 90 run function metiers:appel {f:"m/outil_monte"}
execute if score @s m.m_lvl matches 90 run function metiers:recompenses
execute if score @s m.m_lvl matches 100 run function metiers:appel {f:"m/outil_monte"}
execute if score @s m.m_lvl matches 100 run function metiers:recompenses
execute if score @s m.m_lvl matches 10 run advancement grant @s only metiers:m/niveau_10
execute if score @s m.m_lvl matches 20 run advancement grant @s only metiers:m/niveau_20
execute if score @s m.m_lvl matches 30 run advancement grant @s only metiers:m/niveau_30
execute if score @s m.m_lvl matches 40 run advancement grant @s only metiers:m/niveau_40
execute if score @s m.m_lvl matches 50 run advancement grant @s only metiers:m/niveau_50
execute if score @s m.m_lvl matches 60 run advancement grant @s only metiers:m/niveau_60
execute if score @s m.m_lvl matches 70 run advancement grant @s only metiers:m/niveau_70
execute if score @s m.m_lvl matches 80 run advancement grant @s only metiers:m/niveau_80
execute if score @s m.m_lvl matches 90 run advancement grant @s only metiers:m/niveau_90
execute if score @s m.m_lvl matches 100 run advancement grant @s only metiers:m/niveau_100
function metiers:m/check
