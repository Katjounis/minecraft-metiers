$give @s minecraft:$(out) $(n)
