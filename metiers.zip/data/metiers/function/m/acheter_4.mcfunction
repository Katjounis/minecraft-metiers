execute if entity @s[tag=metiers.sk.m4] run return run function metiers:m/arbre
function metiers:m/points
execute unless entity @s[tag=metiers.sk.m2] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Œil de lynx.","color":"red"}]
execute unless entity @s[tag=metiers.sk.m2] run return run function metiers:m/arbre
execute if score @s m.tmp matches ..15 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (16 requis).","color":"red"}]
execute if score @s m.tmp matches ..15 run return run function metiers:m/arbre
scoreboard players add @s m.m_spent 16
tag @s add metiers.sk.m4
advancement grant @s only metiers:m/competence_4
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Bras de fer","color":"gray","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:m/arbre
