execute if score @s m.m_lvl matches ..99 run return 0
execute if score @s m.m_pr matches 5.. run return 0
scoreboard players add @s m.m_pr 1
scoreboard players set @s m.m_lvl 1
scoreboard players set @s m.m_xp 0
scoreboard players set @s m.m_need 50
scoreboard players set @s m.m_spent 0
scoreboard players set @s m.m_pal 0
tag @s remove metiers.sk.m1
tag @s remove metiers.sk.m2
tag @s remove metiers.sk.m3
tag @s remove metiers.sk.m4
tag @s remove metiers.sk.m5
tag @s remove metiers.sk.m6
advancement revoke @s from metiers:m/competence_1
advancement revoke @s from metiers:m/niveau_10
tag @s add metiers.maj
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" passe ","color":"gray"},{"text":"★ Prestige ","color":"gold","bold":true},{"score":{"name":"@s","objective":"m.m_pr"},"color":"gold","bold":true},{"text":" en Mineur !","color":"gray","bold":true}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 0.8
playsound minecraft:entity.firework_rocket.large_blast master @a ~ ~ ~ 1 1
particle minecraft:totem_of_undying ~ ~1 ~ 0.6 1.2 0.6 0.5 200
particle minecraft:end_rod ~ ~1 ~ 0.4 1 0.4 0.15 80
