scoreboard players operation @s m.m_need = @s m.m_lvl
scoreboard players operation @s m.m_need *= #10 m.const
scoreboard players operation @s m.m_need += #40 m.const
execute if score @s m.m_lvl matches ..99 if score @s m.m_xp >= @s m.m_need run function metiers:m/levelup
