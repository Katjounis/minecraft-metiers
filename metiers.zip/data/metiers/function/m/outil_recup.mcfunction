execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"m"}] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu as déjà ton outil de Mineur sur toi.","color":"gray"}]
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"m"}] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu as déjà ton outil de Mineur sur toi.","color":"gray"}]
scoreboard players operation @s m.tmp = @s m.m_cd
scoreboard players operation @s m.tmp /= #60 m.const
scoreboard players operation @s m.tmp /= #2 m.const
scoreboard players add @s m.tmp 1
execute if score @s m.m_cd matches 1.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Patiente encore ","color":"red"},{"score":{"name":"@s","objective":"m.tmp"},"color":"yellow"},{"text":" min avant de le récupérer.","color":"red"}]
scoreboard players set @s m.m_cd 1200
function metiers:m/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Voici ton outil de Mineur. Il évolue tout seul à chaque palier de 10 niveaux.","color":"green"}]
