tag @s remove metiers.a_head
tag @s remove metiers.a_chest
tag @s remove metiers.a_legs
tag @s remove metiers.a_feet
execute if items entity @s armor.head *[minecraft:custom_data~{metiers_armure:1b}] run tag @s add metiers.a_head
execute if items entity @s armor.chest *[minecraft:custom_data~{metiers_armure:1b}] run tag @s add metiers.a_chest
execute if items entity @s armor.legs *[minecraft:custom_data~{metiers_armure:1b}] run tag @s add metiers.a_legs
execute if items entity @s armor.feet *[minecraft:custom_data~{metiers_armure:1b}] run tag @s add metiers.a_feet
execute if items entity @s armor.head *[minecraft:custom_data~{metiers_armure:1b}] run item replace entity @s armor.head with minecraft:air
execute if items entity @s armor.chest *[minecraft:custom_data~{metiers_armure:1b}] run item replace entity @s armor.chest with minecraft:air
execute if items entity @s armor.legs *[minecraft:custom_data~{metiers_armure:1b}] run item replace entity @s armor.legs with minecraft:air
execute if items entity @s armor.feet *[minecraft:custom_data~{metiers_armure:1b}] run item replace entity @s armor.feet with minecraft:air
clear @s *[minecraft:custom_data~{metiers_armure:1b}]
scoreboard players add @s m.aser 1
execute store result storage metiers:tmp o int 1 run scoreboard players get @s m.id
execute store result storage metiers:tmp s int 1 run scoreboard players get @s m.aser
function metiers:armure/donner_m with storage metiers:tmp
tag @s remove metiers.a_head
tag @s remove metiers.a_chest
tag @s remove metiers.a_legs
tag @s remove metiers.a_feet
playsound minecraft:item.armor.equip_netherite master @s ~ ~ ~ 1 0.8
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 1 0.4 0.3 60
