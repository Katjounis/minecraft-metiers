clear @s *[minecraft:custom_data~{metiers_armure:1b}]
scoreboard players add @s m.aser 1
execute store result storage metiers:tmp o int 1 run scoreboard players get @s m.id
execute store result storage metiers:tmp s int 1 run scoreboard players get @s m.aser
function metiers:armure/donner_m with storage metiers:tmp
playsound minecraft:item.armor.equip_netherite master @s ~ ~ ~ 1 0.8
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 1 0.4 0.3 60
