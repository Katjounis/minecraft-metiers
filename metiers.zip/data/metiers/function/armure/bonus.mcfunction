execute unless items entity @s armor.head *[minecraft:custom_data~{metiers_armure:1b}] run return 0
execute unless items entity @s armor.chest *[minecraft:custom_data~{metiers_armure:1b}] run return 0
execute unless items entity @s armor.legs *[minecraft:custom_data~{metiers_armure:1b}] run return 0
execute unless items entity @s armor.feet *[minecraft:custom_data~{metiers_armure:1b}] run return 0
execute if score @s m.arm matches 1.. run effect give @s minecraft:haste 2 0 true
execute if score @s m.arm matches 2.. run effect give @s minecraft:speed 2 0 true
execute if score @s m.arm matches 3.. run effect give @s minecraft:resistance 2 0 true
execute if score @s m.arm matches 4.. run effect give @s minecraft:regeneration 3 0 true
execute if score @s m.arm matches 5.. run effect give @s minecraft:strength 2 0 true
execute if score @s m.arm matches 4.. if score #huit m.timer matches 0 run particle minecraft:end_rod ~ ~1 ~ 0.35 0.6 0.35 0.01 6
execute if score @s m.arm matches 5.. run particle minecraft:wax_off ~ ~1.2 ~ 0.3 0.5 0.3 0 2
