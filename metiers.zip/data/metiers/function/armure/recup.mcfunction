scoreboard players add @s m.arm 0
execute if score @s m.arm matches 0 run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton armure se débloque à 50 points de score (somme de tes niveaux).","color":"red"}]
scoreboard players operation @s m.tmp = @s m.acd
scoreboard players operation @s m.tmp /= #60 m.const
scoreboard players operation @s m.tmp /= #2 m.const
scoreboard players add @s m.tmp 1
execute if score @s m.acd matches 1.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Patiente encore ","color":"red"},{"score":{"name":"@s","objective":"m.tmp"},"color":"yellow"},{"text":" min.","color":"red"}]
scoreboard players set @s m.acd 1200
function metiers:appel {f:"armure/donner"}
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton Armure des Guildes est remise à neuf : les pièces libres sont équipées, les autres sont dans ton inventaire.","color":"green"}]
