scoreboard players add @s m.arm 0
tag @s add metiers.arm2
scoreboard players set @s m.tmp 0
execute if score @s m.total matches 30.. run scoreboard players set @s m.tmp 1
execute if score @s m.total matches 60.. run scoreboard players set @s m.tmp 2
execute if score @s m.total matches 100.. run scoreboard players set @s m.tmp 3
execute if score @s m.total matches 150.. run scoreboard players set @s m.tmp 4
execute if score @s m.total matches 210.. run scoreboard players set @s m.tmp 5
execute if score @s m.total matches 280.. run scoreboard players set @s m.tmp 6
execute if score @s m.total matches 360.. run scoreboard players set @s m.tmp 7
execute if score @s m.total matches 450.. run scoreboard players set @s m.tmp 8
execute if score @s m.total matches 560.. run scoreboard players set @s m.tmp 9
execute if score @s m.total matches 700.. run scoreboard players set @s m.tmp 10
execute if score @s m.total matches 850.. run scoreboard players set @s m.tmp 11
execute if score @s m.tmp <= @s m.arm run return 0
scoreboard players operation @s m.arm = @s m.tmp
execute if score @s m.arm matches 1 unless entity @s[tag=metiers.avait_armure] run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Diamant","color":"#33C4CB","bold":true}]
execute if score @s m.arm matches 2 unless entity @s[tag=metiers.avait_armure] run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Diamant forgé","color":"#8CEFED","bold":true}]
execute if score @s m.arm matches 3 unless entity @s[tag=metiers.avait_armure] run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Netherite","color":"#9A8790","bold":true}]
execute if score @s m.arm matches 4 unless entity @s[tag=metiers.avait_armure] run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Netherite épineuse","color":"#C83A3A","bold":true}]
execute if score @s m.arm matches 5 unless entity @s[tag=metiers.avait_armure] run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Netherite d'améthyste","color":"#B787EC","bold":true}]
execute if score @s m.arm matches 6 unless entity @s[tag=metiers.avait_armure] run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Netherite de braise","color":"#FF8A2E","bold":true}]
execute if score @s m.arm matches 7 unless entity @s[tag=metiers.avait_armure] run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Netherite rubis","color":"#FF3030","bold":true}]
execute if score @s m.arm matches 8 unless entity @s[tag=metiers.avait_armure] run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Netherite runique","color":"#2FE6FF","bold":true}]
execute if score @s m.arm matches 9 unless entity @s[tag=metiers.avait_armure] run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Netherite du Vide","color":"#8A3CFF","bold":true}]
execute if score @s m.arm matches 10 unless entity @s[tag=metiers.avait_armure] run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Mythique","color":"#5FF5DC","bold":true}]
execute if score @s m.arm matches 11 unless entity @s[tag=metiers.avait_armure] run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Céleste","color":"#FFF4D2","bold":true}]
function metiers:appel {f:"armure/donner"}
execute unless entity @s[tag=metiers.avait_armure] as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.6 1.3
