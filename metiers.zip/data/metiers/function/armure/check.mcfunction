scoreboard players add @s m.arm 0
scoreboard players set @s m.tmp 0
execute if score @s m.total matches 50.. run scoreboard players set @s m.tmp 1
execute if score @s m.total matches 120.. run scoreboard players set @s m.tmp 2
execute if score @s m.total matches 220.. run scoreboard players set @s m.tmp 3
execute if score @s m.total matches 350.. run scoreboard players set @s m.tmp 4
execute if score @s m.total matches 520.. run scoreboard players set @s m.tmp 5
execute if score @s m.tmp <= @s m.arm run return 0
scoreboard players operation @s m.arm = @s m.tmp
execute if score @s m.arm matches 1 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Bronze guildien","color":"#D4945A","bold":true}]
execute if score @s m.arm matches 2 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Argent runique","color":"#9CC2FF","bold":true}]
execute if score @s m.arm matches 3 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Or royal","color":"#F1CF4E","bold":true}]
execute if score @s m.arm matches 4 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Obsidienne astrale","color":"#22C9E6","bold":true}]
execute if score @s m.arm matches 5 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" obtient l'Armure des Guildes : ","color":"gray"},{"text":"Céleste","color":"#FFF4D2","bold":true}]
function metiers:appel {f:"armure/donner"}
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.6 1.3
