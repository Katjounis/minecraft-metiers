team remove m.b0
team add m.b0_0
team modify m.b0_0 prefix [{"text": "", "color": "white"}, {"color": "gray", "text": "♣ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.b0_1
team modify m.b0_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "♣ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.b0_2
team modify m.b0_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "♣ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.b0_3
team modify m.b0_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "♣ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.b0_4
team modify m.b0_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "♣ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.b0_5
team modify m.b0_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "♣ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team remove m.b1
team add m.b1_0
team modify m.b1_0 prefix [{"text": "", "color": "white"}, {"color": "white", "text": "♣ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.b1_1
team modify m.b1_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "white", "text": "♣ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.b1_2
team modify m.b1_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "♣ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.b1_3
team modify m.b1_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "♣ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.b1_4
team modify m.b1_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "♣ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.b1_5
team modify m.b1_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "♣ Initié"}, {"text": " ", "color": "white", "bold": false}]
team remove m.b2
team add m.b2_0
team modify m.b2_0 prefix [{"text": "", "color": "white"}, {"color": "gold", "text": "♣ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.b2_1
team modify m.b2_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gold", "text": "♣ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.b2_2
team modify m.b2_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gold", "text": "♣ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.b2_3
team modify m.b2_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gold", "text": "♣ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.b2_4
team modify m.b2_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "text": "♣ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.b2_5
team modify m.b2_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "text": "♣ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team remove m.b3
team add m.b3_0
team modify m.b3_0 prefix [{"text": "", "color": "white"}, {"color": "gold", "bold": true, "text": "♣ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.b3_1
team modify m.b3_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♣ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.b3_2
team modify m.b3_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♣ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.b3_3
team modify m.b3_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♣ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.b3_4
team modify m.b3_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♣ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.b3_5
team modify m.b3_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♣ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team remove m.b4
team add m.b4_0
team modify m.b4_0 prefix [{"text": "", "color": "white"}, {"color": "yellow", "bold": true, "text": "♣ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.b4_1
team modify m.b4_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "♣ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.b4_2
team modify m.b4_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "♣ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.b4_3
team modify m.b4_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "♣ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.b4_4
team modify m.b4_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "♣ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.b4_5
team modify m.b4_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "♣ Expert"}, {"text": " ", "color": "white", "bold": false}]
team remove m.b5
team add m.b5_0
team modify m.b5_0 prefix [{"text": "", "color": "white"}, {"color": "gold", "bold": true, "text": "♣ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.b5_1
team modify m.b5_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♣ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.b5_2
team modify m.b5_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♣ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.b5_3
team modify m.b5_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♣ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.b5_4
team modify m.b5_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♣ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.b5_5
team modify m.b5_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♣ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team remove m.b6
team add m.b6_0
team modify m.b6_0 prefix [{"text": "", "color": "white"}, {"color": "red", "bold": true, "text": "♣ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.b6_1
team modify m.b6_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "♣ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.b6_2
team modify m.b6_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "♣ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.b6_3
team modify m.b6_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "♣ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.b6_4
team modify m.b6_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "♣ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.b6_5
team modify m.b6_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "♣ Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.b7
team add m.b7_0
team modify m.b7_0 prefix [{"text": "", "color": "white"}, {"color": "light_purple", "bold": true, "text": "♣ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.b7_1
team modify m.b7_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♣ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.b7_2
team modify m.b7_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♣ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.b7_3
team modify m.b7_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♣ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.b7_4
team modify m.b7_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♣ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.b7_5
team modify m.b7_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♣ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.b8
team add m.b8_0
team modify m.b8_0 prefix [{"text": "", "color": "white"}, {"color": "dark_purple", "bold": true, "text": "♣ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.b8_1
team modify m.b8_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "♣ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.b8_2
team modify m.b8_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "♣ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.b8_3
team modify m.b8_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "♣ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.b8_4
team modify m.b8_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "♣ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.b8_5
team modify m.b8_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "♣ Légende"}, {"text": " ", "color": "white", "bold": false}]
team remove m.b9
team add m.b9_0
team modify m.b9_0 prefix [{"text": "", "color": "white"}, {"color": "aqua", "bold": true, "text": "♣ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.b9_1
team modify m.b9_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "♣ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.b9_2
team modify m.b9_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "♣ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.b9_3
team modify m.b9_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "♣ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.b9_4
team modify m.b9_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "♣ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.b9_5
team modify m.b9_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "♣ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team remove m.b10
team add m.b10_0
team modify m.b10_0 prefix [{"text": "", "color": "white"}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "♣ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.b10_1
team modify m.b10_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "♣ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.b10_2
team modify m.b10_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "♣ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.b10_3
team modify m.b10_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "♣ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.b10_4
team modify m.b10_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "♣ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.b10_5
team modify m.b10_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "♣ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team remove m.f0
team add m.f0_0
team modify m.f0_0 prefix [{"text": "", "color": "white"}, {"color": "gray", "text": "☘ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.f0_1
team modify m.f0_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "☘ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.f0_2
team modify m.f0_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "☘ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.f0_3
team modify m.f0_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "☘ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.f0_4
team modify m.f0_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "☘ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.f0_5
team modify m.f0_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "☘ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team remove m.f1
team add m.f1_0
team modify m.f1_0 prefix [{"text": "", "color": "white"}, {"color": "white", "text": "☘ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.f1_1
team modify m.f1_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "white", "text": "☘ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.f1_2
team modify m.f1_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "☘ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.f1_3
team modify m.f1_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "☘ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.f1_4
team modify m.f1_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "☘ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.f1_5
team modify m.f1_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "☘ Initié"}, {"text": " ", "color": "white", "bold": false}]
team remove m.f2
team add m.f2_0
team modify m.f2_0 prefix [{"text": "", "color": "white"}, {"color": "green", "text": "☘ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.f2_1
team modify m.f2_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "green", "text": "☘ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.f2_2
team modify m.f2_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "green", "text": "☘ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.f2_3
team modify m.f2_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "green", "text": "☘ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.f2_4
team modify m.f2_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "green", "text": "☘ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.f2_5
team modify m.f2_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "green", "text": "☘ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team remove m.f3
team add m.f3_0
team modify m.f3_0 prefix [{"text": "", "color": "white"}, {"color": "green", "bold": true, "text": "☘ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.f3_1
team modify m.f3_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "green", "bold": true, "text": "☘ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.f3_2
team modify m.f3_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "green", "bold": true, "text": "☘ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.f3_3
team modify m.f3_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "green", "bold": true, "text": "☘ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.f3_4
team modify m.f3_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "green", "bold": true, "text": "☘ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.f3_5
team modify m.f3_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "green", "bold": true, "text": "☘ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team remove m.f4
team add m.f4_0
team modify m.f4_0 prefix [{"text": "", "color": "white"}, {"color": "yellow", "bold": true, "text": "☘ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.f4_1
team modify m.f4_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "☘ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.f4_2
team modify m.f4_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "☘ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.f4_3
team modify m.f4_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "☘ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.f4_4
team modify m.f4_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "☘ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.f4_5
team modify m.f4_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "☘ Expert"}, {"text": " ", "color": "white", "bold": false}]
team remove m.f5
team add m.f5_0
team modify m.f5_0 prefix [{"text": "", "color": "white"}, {"color": "gold", "bold": true, "text": "☘ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.f5_1
team modify m.f5_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "☘ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.f5_2
team modify m.f5_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "☘ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.f5_3
team modify m.f5_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "☘ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.f5_4
team modify m.f5_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "☘ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.f5_5
team modify m.f5_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "☘ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team remove m.f6
team add m.f6_0
team modify m.f6_0 prefix [{"text": "", "color": "white"}, {"color": "red", "bold": true, "text": "☘ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.f6_1
team modify m.f6_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "☘ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.f6_2
team modify m.f6_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "☘ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.f6_3
team modify m.f6_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "☘ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.f6_4
team modify m.f6_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "☘ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.f6_5
team modify m.f6_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "☘ Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.f7
team add m.f7_0
team modify m.f7_0 prefix [{"text": "", "color": "white"}, {"color": "light_purple", "bold": true, "text": "☘ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.f7_1
team modify m.f7_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "☘ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.f7_2
team modify m.f7_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "☘ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.f7_3
team modify m.f7_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "☘ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.f7_4
team modify m.f7_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "☘ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.f7_5
team modify m.f7_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "☘ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.f8
team add m.f8_0
team modify m.f8_0 prefix [{"text": "", "color": "white"}, {"color": "dark_purple", "bold": true, "text": "☘ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.f8_1
team modify m.f8_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "☘ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.f8_2
team modify m.f8_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "☘ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.f8_3
team modify m.f8_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "☘ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.f8_4
team modify m.f8_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "☘ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.f8_5
team modify m.f8_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "☘ Légende"}, {"text": " ", "color": "white", "bold": false}]
team remove m.f9
team add m.f9_0
team modify m.f9_0 prefix [{"text": "", "color": "white"}, {"color": "aqua", "bold": true, "text": "☘ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.f9_1
team modify m.f9_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "☘ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.f9_2
team modify m.f9_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "☘ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.f9_3
team modify m.f9_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "☘ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.f9_4
team modify m.f9_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "☘ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.f9_5
team modify m.f9_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "☘ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team remove m.f10
team add m.f10_0
team modify m.f10_0 prefix [{"text": "", "color": "white"}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "☘ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.f10_1
team modify m.f10_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "☘ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.f10_2
team modify m.f10_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "☘ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.f10_3
team modify m.f10_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "☘ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.f10_4
team modify m.f10_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "☘ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.f10_5
team modify m.f10_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "☘ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team remove m.m0
team add m.m0_0
team modify m.m0_0 prefix [{"text": "", "color": "white"}, {"color": "gray", "text": "⛏ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.m0_1
team modify m.m0_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛏ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.m0_2
team modify m.m0_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛏ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.m0_3
team modify m.m0_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛏ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.m0_4
team modify m.m0_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛏ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.m0_5
team modify m.m0_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛏ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team remove m.m1
team add m.m1_0
team modify m.m1_0 prefix [{"text": "", "color": "white"}, {"color": "white", "text": "⛏ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.m1_1
team modify m.m1_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⛏ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.m1_2
team modify m.m1_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⛏ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.m1_3
team modify m.m1_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⛏ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.m1_4
team modify m.m1_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⛏ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.m1_5
team modify m.m1_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⛏ Initié"}, {"text": " ", "color": "white", "bold": false}]
team remove m.m2
team add m.m2_0
team modify m.m2_0 prefix [{"text": "", "color": "white"}, {"color": "gray", "text": "⛏ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.m2_1
team modify m.m2_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛏ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.m2_2
team modify m.m2_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛏ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.m2_3
team modify m.m2_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛏ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.m2_4
team modify m.m2_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛏ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.m2_5
team modify m.m2_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛏ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team remove m.m3
team add m.m3_0
team modify m.m3_0 prefix [{"text": "", "color": "white"}, {"color": "gray", "bold": true, "text": "⛏ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.m3_1
team modify m.m3_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gray", "bold": true, "text": "⛏ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.m3_2
team modify m.m3_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gray", "bold": true, "text": "⛏ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.m3_3
team modify m.m3_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gray", "bold": true, "text": "⛏ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.m3_4
team modify m.m3_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "bold": true, "text": "⛏ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.m3_5
team modify m.m3_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "bold": true, "text": "⛏ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team remove m.m4
team add m.m4_0
team modify m.m4_0 prefix [{"text": "", "color": "white"}, {"color": "yellow", "bold": true, "text": "⛏ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.m4_1
team modify m.m4_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⛏ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.m4_2
team modify m.m4_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⛏ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.m4_3
team modify m.m4_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⛏ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.m4_4
team modify m.m4_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⛏ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.m4_5
team modify m.m4_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⛏ Expert"}, {"text": " ", "color": "white", "bold": false}]
team remove m.m5
team add m.m5_0
team modify m.m5_0 prefix [{"text": "", "color": "white"}, {"color": "gold", "bold": true, "text": "⛏ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.m5_1
team modify m.m5_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⛏ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.m5_2
team modify m.m5_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⛏ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.m5_3
team modify m.m5_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⛏ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.m5_4
team modify m.m5_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⛏ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.m5_5
team modify m.m5_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⛏ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team remove m.m6
team add m.m6_0
team modify m.m6_0 prefix [{"text": "", "color": "white"}, {"color": "red", "bold": true, "text": "⛏ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.m6_1
team modify m.m6_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⛏ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.m6_2
team modify m.m6_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⛏ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.m6_3
team modify m.m6_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⛏ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.m6_4
team modify m.m6_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⛏ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.m6_5
team modify m.m6_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⛏ Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.m7
team add m.m7_0
team modify m.m7_0 prefix [{"text": "", "color": "white"}, {"color": "light_purple", "bold": true, "text": "⛏ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.m7_1
team modify m.m7_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⛏ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.m7_2
team modify m.m7_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⛏ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.m7_3
team modify m.m7_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⛏ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.m7_4
team modify m.m7_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⛏ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.m7_5
team modify m.m7_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⛏ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.m8
team add m.m8_0
team modify m.m8_0 prefix [{"text": "", "color": "white"}, {"color": "dark_purple", "bold": true, "text": "⛏ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.m8_1
team modify m.m8_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⛏ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.m8_2
team modify m.m8_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⛏ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.m8_3
team modify m.m8_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⛏ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.m8_4
team modify m.m8_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⛏ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.m8_5
team modify m.m8_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⛏ Légende"}, {"text": " ", "color": "white", "bold": false}]
team remove m.m9
team add m.m9_0
team modify m.m9_0 prefix [{"text": "", "color": "white"}, {"color": "aqua", "bold": true, "text": "⛏ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.m9_1
team modify m.m9_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⛏ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.m9_2
team modify m.m9_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⛏ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.m9_3
team modify m.m9_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⛏ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.m9_4
team modify m.m9_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⛏ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.m9_5
team modify m.m9_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⛏ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team remove m.m10
team add m.m10_0
team modify m.m10_0 prefix [{"text": "", "color": "white"}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⛏ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.m10_1
team modify m.m10_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⛏ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.m10_2
team modify m.m10_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⛏ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.m10_3
team modify m.m10_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⛏ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.m10_4
team modify m.m10_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⛏ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.m10_5
team modify m.m10_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⛏ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team remove m.c0
team add m.c0_0
team modify m.c0_0 prefix [{"text": "", "color": "white"}, {"color": "gray", "text": "⚔ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.c0_1
team modify m.c0_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚔ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.c0_2
team modify m.c0_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚔ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.c0_3
team modify m.c0_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚔ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.c0_4
team modify m.c0_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚔ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.c0_5
team modify m.c0_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚔ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team remove m.c1
team add m.c1_0
team modify m.c1_0 prefix [{"text": "", "color": "white"}, {"color": "white", "text": "⚔ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.c1_1
team modify m.c1_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚔ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.c1_2
team modify m.c1_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚔ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.c1_3
team modify m.c1_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚔ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.c1_4
team modify m.c1_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚔ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.c1_5
team modify m.c1_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚔ Initié"}, {"text": " ", "color": "white", "bold": false}]
team remove m.c2
team add m.c2_0
team modify m.c2_0 prefix [{"text": "", "color": "white"}, {"color": "red", "text": "⚔ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.c2_1
team modify m.c2_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "red", "text": "⚔ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.c2_2
team modify m.c2_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "red", "text": "⚔ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.c2_3
team modify m.c2_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "red", "text": "⚔ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.c2_4
team modify m.c2_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "red", "text": "⚔ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.c2_5
team modify m.c2_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "red", "text": "⚔ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team remove m.c3
team add m.c3_0
team modify m.c3_0 prefix [{"text": "", "color": "white"}, {"color": "red", "bold": true, "text": "⚔ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.c3_1
team modify m.c3_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚔ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.c3_2
team modify m.c3_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚔ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.c3_3
team modify m.c3_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚔ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.c3_4
team modify m.c3_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚔ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.c3_5
team modify m.c3_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚔ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team remove m.c4
team add m.c4_0
team modify m.c4_0 prefix [{"text": "", "color": "white"}, {"color": "yellow", "bold": true, "text": "⚔ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.c4_1
team modify m.c4_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚔ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.c4_2
team modify m.c4_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚔ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.c4_3
team modify m.c4_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚔ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.c4_4
team modify m.c4_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚔ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.c4_5
team modify m.c4_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚔ Expert"}, {"text": " ", "color": "white", "bold": false}]
team remove m.c5
team add m.c5_0
team modify m.c5_0 prefix [{"text": "", "color": "white"}, {"color": "gold", "bold": true, "text": "⚔ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.c5_1
team modify m.c5_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚔ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.c5_2
team modify m.c5_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚔ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.c5_3
team modify m.c5_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚔ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.c5_4
team modify m.c5_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚔ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.c5_5
team modify m.c5_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚔ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team remove m.c6
team add m.c6_0
team modify m.c6_0 prefix [{"text": "", "color": "white"}, {"color": "red", "bold": true, "text": "⚔ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.c6_1
team modify m.c6_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚔ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.c6_2
team modify m.c6_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚔ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.c6_3
team modify m.c6_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚔ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.c6_4
team modify m.c6_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚔ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.c6_5
team modify m.c6_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚔ Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.c7
team add m.c7_0
team modify m.c7_0 prefix [{"text": "", "color": "white"}, {"color": "light_purple", "bold": true, "text": "⚔ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.c7_1
team modify m.c7_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚔ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.c7_2
team modify m.c7_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚔ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.c7_3
team modify m.c7_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚔ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.c7_4
team modify m.c7_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚔ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.c7_5
team modify m.c7_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚔ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.c8
team add m.c8_0
team modify m.c8_0 prefix [{"text": "", "color": "white"}, {"color": "dark_purple", "bold": true, "text": "⚔ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.c8_1
team modify m.c8_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚔ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.c8_2
team modify m.c8_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚔ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.c8_3
team modify m.c8_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚔ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.c8_4
team modify m.c8_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚔ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.c8_5
team modify m.c8_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚔ Légende"}, {"text": " ", "color": "white", "bold": false}]
team remove m.c9
team add m.c9_0
team modify m.c9_0 prefix [{"text": "", "color": "white"}, {"color": "aqua", "bold": true, "text": "⚔ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.c9_1
team modify m.c9_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚔ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.c9_2
team modify m.c9_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚔ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.c9_3
team modify m.c9_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚔ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.c9_4
team modify m.c9_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚔ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.c9_5
team modify m.c9_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚔ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team remove m.c10
team add m.c10_0
team modify m.c10_0 prefix [{"text": "", "color": "white"}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚔ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.c10_1
team modify m.c10_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚔ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.c10_2
team modify m.c10_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚔ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.c10_3
team modify m.c10_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚔ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.c10_4
team modify m.c10_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚔ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.c10_5
team modify m.c10_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚔ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team remove m.p0
team add m.p0_0
team modify m.p0_0 prefix [{"text": "", "color": "white"}, {"color": "gray", "text": "⚓ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.p0_1
team modify m.p0_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚓ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.p0_2
team modify m.p0_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚓ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.p0_3
team modify m.p0_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚓ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.p0_4
team modify m.p0_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚓ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.p0_5
team modify m.p0_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚓ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team remove m.p1
team add m.p1_0
team modify m.p1_0 prefix [{"text": "", "color": "white"}, {"color": "white", "text": "⚓ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.p1_1
team modify m.p1_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚓ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.p1_2
team modify m.p1_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚓ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.p1_3
team modify m.p1_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚓ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.p1_4
team modify m.p1_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚓ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.p1_5
team modify m.p1_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚓ Initié"}, {"text": " ", "color": "white", "bold": false}]
team remove m.p2
team add m.p2_0
team modify m.p2_0 prefix [{"text": "", "color": "white"}, {"color": "aqua", "text": "⚓ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.p2_1
team modify m.p2_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "aqua", "text": "⚓ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.p2_2
team modify m.p2_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "aqua", "text": "⚓ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.p2_3
team modify m.p2_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "text": "⚓ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.p2_4
team modify m.p2_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "text": "⚓ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.p2_5
team modify m.p2_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "text": "⚓ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team remove m.p3
team add m.p3_0
team modify m.p3_0 prefix [{"text": "", "color": "white"}, {"color": "aqua", "bold": true, "text": "⚓ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.p3_1
team modify m.p3_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚓ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.p3_2
team modify m.p3_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚓ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.p3_3
team modify m.p3_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚓ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.p3_4
team modify m.p3_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚓ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.p3_5
team modify m.p3_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚓ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team remove m.p4
team add m.p4_0
team modify m.p4_0 prefix [{"text": "", "color": "white"}, {"color": "yellow", "bold": true, "text": "⚓ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.p4_1
team modify m.p4_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚓ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.p4_2
team modify m.p4_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚓ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.p4_3
team modify m.p4_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚓ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.p4_4
team modify m.p4_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚓ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.p4_5
team modify m.p4_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚓ Expert"}, {"text": " ", "color": "white", "bold": false}]
team remove m.p5
team add m.p5_0
team modify m.p5_0 prefix [{"text": "", "color": "white"}, {"color": "gold", "bold": true, "text": "⚓ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.p5_1
team modify m.p5_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚓ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.p5_2
team modify m.p5_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚓ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.p5_3
team modify m.p5_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚓ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.p5_4
team modify m.p5_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚓ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.p5_5
team modify m.p5_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚓ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team remove m.p6
team add m.p6_0
team modify m.p6_0 prefix [{"text": "", "color": "white"}, {"color": "red", "bold": true, "text": "⚓ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.p6_1
team modify m.p6_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚓ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.p6_2
team modify m.p6_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚓ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.p6_3
team modify m.p6_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚓ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.p6_4
team modify m.p6_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚓ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.p6_5
team modify m.p6_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚓ Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.p7
team add m.p7_0
team modify m.p7_0 prefix [{"text": "", "color": "white"}, {"color": "light_purple", "bold": true, "text": "⚓ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.p7_1
team modify m.p7_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚓ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.p7_2
team modify m.p7_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚓ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.p7_3
team modify m.p7_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚓ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.p7_4
team modify m.p7_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚓ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.p7_5
team modify m.p7_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚓ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.p8
team add m.p8_0
team modify m.p8_0 prefix [{"text": "", "color": "white"}, {"color": "dark_purple", "bold": true, "text": "⚓ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.p8_1
team modify m.p8_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚓ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.p8_2
team modify m.p8_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚓ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.p8_3
team modify m.p8_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚓ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.p8_4
team modify m.p8_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚓ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.p8_5
team modify m.p8_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚓ Légende"}, {"text": " ", "color": "white", "bold": false}]
team remove m.p9
team add m.p9_0
team modify m.p9_0 prefix [{"text": "", "color": "white"}, {"color": "aqua", "bold": true, "text": "⚓ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.p9_1
team modify m.p9_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚓ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.p9_2
team modify m.p9_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚓ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.p9_3
team modify m.p9_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚓ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.p9_4
team modify m.p9_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚓ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.p9_5
team modify m.p9_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚓ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team remove m.p10
team add m.p10_0
team modify m.p10_0 prefix [{"text": "", "color": "white"}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚓ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.p10_1
team modify m.p10_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚓ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.p10_2
team modify m.p10_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚓ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.p10_3
team modify m.p10_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚓ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.p10_4
team modify m.p10_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚓ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.p10_5
team modify m.p10_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚓ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team remove m.e0
team add m.e0_0
team modify m.e0_0 prefix [{"text": "", "color": "white"}, {"color": "gray", "text": "♞ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.e0_1
team modify m.e0_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "♞ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.e0_2
team modify m.e0_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "♞ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.e0_3
team modify m.e0_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "♞ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.e0_4
team modify m.e0_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "♞ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.e0_5
team modify m.e0_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "♞ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team remove m.e1
team add m.e1_0
team modify m.e1_0 prefix [{"text": "", "color": "white"}, {"color": "white", "text": "♞ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.e1_1
team modify m.e1_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "white", "text": "♞ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.e1_2
team modify m.e1_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "♞ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.e1_3
team modify m.e1_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "♞ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.e1_4
team modify m.e1_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "♞ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.e1_5
team modify m.e1_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "♞ Initié"}, {"text": " ", "color": "white", "bold": false}]
team remove m.e2
team add m.e2_0
team modify m.e2_0 prefix [{"text": "", "color": "white"}, {"color": "light_purple", "text": "♞ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.e2_1
team modify m.e2_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "light_purple", "text": "♞ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.e2_2
team modify m.e2_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "text": "♞ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.e2_3
team modify m.e2_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "text": "♞ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.e2_4
team modify m.e2_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "text": "♞ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.e2_5
team modify m.e2_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "text": "♞ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team remove m.e3
team add m.e3_0
team modify m.e3_0 prefix [{"text": "", "color": "white"}, {"color": "light_purple", "bold": true, "text": "♞ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.e3_1
team modify m.e3_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♞ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.e3_2
team modify m.e3_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♞ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.e3_3
team modify m.e3_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♞ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.e3_4
team modify m.e3_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♞ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.e3_5
team modify m.e3_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♞ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team remove m.e4
team add m.e4_0
team modify m.e4_0 prefix [{"text": "", "color": "white"}, {"color": "yellow", "bold": true, "text": "♞ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.e4_1
team modify m.e4_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "♞ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.e4_2
team modify m.e4_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "♞ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.e4_3
team modify m.e4_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "♞ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.e4_4
team modify m.e4_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "♞ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.e4_5
team modify m.e4_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "♞ Expert"}, {"text": " ", "color": "white", "bold": false}]
team remove m.e5
team add m.e5_0
team modify m.e5_0 prefix [{"text": "", "color": "white"}, {"color": "gold", "bold": true, "text": "♞ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.e5_1
team modify m.e5_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♞ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.e5_2
team modify m.e5_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♞ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.e5_3
team modify m.e5_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♞ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.e5_4
team modify m.e5_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♞ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.e5_5
team modify m.e5_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "♞ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team remove m.e6
team add m.e6_0
team modify m.e6_0 prefix [{"text": "", "color": "white"}, {"color": "red", "bold": true, "text": "♞ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.e6_1
team modify m.e6_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "♞ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.e6_2
team modify m.e6_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "♞ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.e6_3
team modify m.e6_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "♞ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.e6_4
team modify m.e6_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "♞ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.e6_5
team modify m.e6_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "♞ Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.e7
team add m.e7_0
team modify m.e7_0 prefix [{"text": "", "color": "white"}, {"color": "light_purple", "bold": true, "text": "♞ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.e7_1
team modify m.e7_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♞ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.e7_2
team modify m.e7_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♞ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.e7_3
team modify m.e7_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♞ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.e7_4
team modify m.e7_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♞ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.e7_5
team modify m.e7_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "♞ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.e8
team add m.e8_0
team modify m.e8_0 prefix [{"text": "", "color": "white"}, {"color": "dark_purple", "bold": true, "text": "♞ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.e8_1
team modify m.e8_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "♞ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.e8_2
team modify m.e8_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "♞ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.e8_3
team modify m.e8_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "♞ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.e8_4
team modify m.e8_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "♞ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.e8_5
team modify m.e8_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "♞ Légende"}, {"text": " ", "color": "white", "bold": false}]
team remove m.e9
team add m.e9_0
team modify m.e9_0 prefix [{"text": "", "color": "white"}, {"color": "aqua", "bold": true, "text": "♞ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.e9_1
team modify m.e9_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "♞ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.e9_2
team modify m.e9_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "♞ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.e9_3
team modify m.e9_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "♞ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.e9_4
team modify m.e9_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "♞ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.e9_5
team modify m.e9_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "♞ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team remove m.e10
team add m.e10_0
team modify m.e10_0 prefix [{"text": "", "color": "white"}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "♞ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.e10_1
team modify m.e10_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "♞ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.e10_2
team modify m.e10_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "♞ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.e10_3
team modify m.e10_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "♞ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.e10_4
team modify m.e10_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "♞ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.e10_5
team modify m.e10_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "♞ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team remove m.n0
team add m.n0_0
team modify m.n0_0 prefix [{"text": "", "color": "white"}, {"color": "gray", "text": "✦ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.n0_1
team modify m.n0_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "✦ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.n0_2
team modify m.n0_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "✦ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.n0_3
team modify m.n0_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "✦ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.n0_4
team modify m.n0_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "✦ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.n0_5
team modify m.n0_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "✦ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team remove m.n1
team add m.n1_0
team modify m.n1_0 prefix [{"text": "", "color": "white"}, {"color": "white", "text": "✦ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.n1_1
team modify m.n1_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "white", "text": "✦ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.n1_2
team modify m.n1_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "✦ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.n1_3
team modify m.n1_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "✦ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.n1_4
team modify m.n1_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "✦ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.n1_5
team modify m.n1_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "✦ Initié"}, {"text": " ", "color": "white", "bold": false}]
team remove m.n2
team add m.n2_0
team modify m.n2_0 prefix [{"text": "", "color": "white"}, {"color": "dark_purple", "text": "✦ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.n2_1
team modify m.n2_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "text": "✦ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.n2_2
team modify m.n2_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "text": "✦ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.n2_3
team modify m.n2_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "text": "✦ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.n2_4
team modify m.n2_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "text": "✦ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.n2_5
team modify m.n2_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "text": "✦ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team remove m.n3
team add m.n3_0
team modify m.n3_0 prefix [{"text": "", "color": "white"}, {"color": "dark_purple", "bold": true, "text": "✦ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.n3_1
team modify m.n3_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "✦ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.n3_2
team modify m.n3_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "✦ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.n3_3
team modify m.n3_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "✦ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.n3_4
team modify m.n3_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "✦ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.n3_5
team modify m.n3_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "✦ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team remove m.n4
team add m.n4_0
team modify m.n4_0 prefix [{"text": "", "color": "white"}, {"color": "yellow", "bold": true, "text": "✦ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.n4_1
team modify m.n4_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "✦ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.n4_2
team modify m.n4_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "✦ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.n4_3
team modify m.n4_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "✦ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.n4_4
team modify m.n4_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "✦ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.n4_5
team modify m.n4_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "✦ Expert"}, {"text": " ", "color": "white", "bold": false}]
team remove m.n5
team add m.n5_0
team modify m.n5_0 prefix [{"text": "", "color": "white"}, {"color": "gold", "bold": true, "text": "✦ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.n5_1
team modify m.n5_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "✦ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.n5_2
team modify m.n5_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "✦ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.n5_3
team modify m.n5_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "✦ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.n5_4
team modify m.n5_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "✦ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.n5_5
team modify m.n5_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "✦ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team remove m.n6
team add m.n6_0
team modify m.n6_0 prefix [{"text": "", "color": "white"}, {"color": "red", "bold": true, "text": "✦ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.n6_1
team modify m.n6_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "✦ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.n6_2
team modify m.n6_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "✦ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.n6_3
team modify m.n6_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "✦ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.n6_4
team modify m.n6_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "✦ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.n6_5
team modify m.n6_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "✦ Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.n7
team add m.n7_0
team modify m.n7_0 prefix [{"text": "", "color": "white"}, {"color": "light_purple", "bold": true, "text": "✦ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.n7_1
team modify m.n7_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "✦ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.n7_2
team modify m.n7_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "✦ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.n7_3
team modify m.n7_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "✦ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.n7_4
team modify m.n7_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "✦ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.n7_5
team modify m.n7_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "✦ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.n8
team add m.n8_0
team modify m.n8_0 prefix [{"text": "", "color": "white"}, {"color": "dark_purple", "bold": true, "text": "✦ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.n8_1
team modify m.n8_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "✦ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.n8_2
team modify m.n8_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "✦ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.n8_3
team modify m.n8_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "✦ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.n8_4
team modify m.n8_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "✦ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.n8_5
team modify m.n8_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "✦ Légende"}, {"text": " ", "color": "white", "bold": false}]
team remove m.n9
team add m.n9_0
team modify m.n9_0 prefix [{"text": "", "color": "white"}, {"color": "aqua", "bold": true, "text": "✦ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.n9_1
team modify m.n9_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "✦ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.n9_2
team modify m.n9_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "✦ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.n9_3
team modify m.n9_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "✦ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.n9_4
team modify m.n9_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "✦ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.n9_5
team modify m.n9_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "✦ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team remove m.n10
team add m.n10_0
team modify m.n10_0 prefix [{"text": "", "color": "white"}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "✦ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.n10_1
team modify m.n10_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "✦ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.n10_2
team modify m.n10_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "✦ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.n10_3
team modify m.n10_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "✦ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.n10_4
team modify m.n10_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "✦ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.n10_5
team modify m.n10_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "✦ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team remove m.x0
team add m.x0_0
team modify m.x0_0 prefix [{"text": "", "color": "white"}, {"color": "gray", "text": "⛰ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.x0_1
team modify m.x0_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛰ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.x0_2
team modify m.x0_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛰ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.x0_3
team modify m.x0_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛰ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.x0_4
team modify m.x0_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛰ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.x0_5
team modify m.x0_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⛰ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team remove m.x1
team add m.x1_0
team modify m.x1_0 prefix [{"text": "", "color": "white"}, {"color": "white", "text": "⛰ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.x1_1
team modify m.x1_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⛰ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.x1_2
team modify m.x1_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⛰ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.x1_3
team modify m.x1_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⛰ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.x1_4
team modify m.x1_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⛰ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.x1_5
team modify m.x1_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⛰ Initié"}, {"text": " ", "color": "white", "bold": false}]
team remove m.x2
team add m.x2_0
team modify m.x2_0 prefix [{"text": "", "color": "white"}, {"color": "blue", "text": "⛰ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.x2_1
team modify m.x2_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "blue", "text": "⛰ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.x2_2
team modify m.x2_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "blue", "text": "⛰ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.x2_3
team modify m.x2_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "blue", "text": "⛰ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.x2_4
team modify m.x2_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "blue", "text": "⛰ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.x2_5
team modify m.x2_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "blue", "text": "⛰ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team remove m.x3
team add m.x3_0
team modify m.x3_0 prefix [{"text": "", "color": "white"}, {"color": "blue", "bold": true, "text": "⛰ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.x3_1
team modify m.x3_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "blue", "bold": true, "text": "⛰ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.x3_2
team modify m.x3_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "blue", "bold": true, "text": "⛰ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.x3_3
team modify m.x3_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "blue", "bold": true, "text": "⛰ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.x3_4
team modify m.x3_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "blue", "bold": true, "text": "⛰ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.x3_5
team modify m.x3_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "blue", "bold": true, "text": "⛰ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team remove m.x4
team add m.x4_0
team modify m.x4_0 prefix [{"text": "", "color": "white"}, {"color": "yellow", "bold": true, "text": "⛰ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.x4_1
team modify m.x4_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⛰ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.x4_2
team modify m.x4_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⛰ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.x4_3
team modify m.x4_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⛰ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.x4_4
team modify m.x4_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⛰ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.x4_5
team modify m.x4_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⛰ Expert"}, {"text": " ", "color": "white", "bold": false}]
team remove m.x5
team add m.x5_0
team modify m.x5_0 prefix [{"text": "", "color": "white"}, {"color": "gold", "bold": true, "text": "⛰ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.x5_1
team modify m.x5_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⛰ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.x5_2
team modify m.x5_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⛰ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.x5_3
team modify m.x5_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⛰ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.x5_4
team modify m.x5_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⛰ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.x5_5
team modify m.x5_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⛰ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team remove m.x6
team add m.x6_0
team modify m.x6_0 prefix [{"text": "", "color": "white"}, {"color": "red", "bold": true, "text": "⛰ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.x6_1
team modify m.x6_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⛰ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.x6_2
team modify m.x6_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⛰ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.x6_3
team modify m.x6_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⛰ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.x6_4
team modify m.x6_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⛰ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.x6_5
team modify m.x6_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⛰ Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.x7
team add m.x7_0
team modify m.x7_0 prefix [{"text": "", "color": "white"}, {"color": "light_purple", "bold": true, "text": "⛰ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.x7_1
team modify m.x7_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⛰ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.x7_2
team modify m.x7_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⛰ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.x7_3
team modify m.x7_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⛰ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.x7_4
team modify m.x7_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⛰ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.x7_5
team modify m.x7_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⛰ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.x8
team add m.x8_0
team modify m.x8_0 prefix [{"text": "", "color": "white"}, {"color": "dark_purple", "bold": true, "text": "⛰ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.x8_1
team modify m.x8_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⛰ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.x8_2
team modify m.x8_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⛰ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.x8_3
team modify m.x8_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⛰ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.x8_4
team modify m.x8_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⛰ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.x8_5
team modify m.x8_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⛰ Légende"}, {"text": " ", "color": "white", "bold": false}]
team remove m.x9
team add m.x9_0
team modify m.x9_0 prefix [{"text": "", "color": "white"}, {"color": "aqua", "bold": true, "text": "⛰ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.x9_1
team modify m.x9_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⛰ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.x9_2
team modify m.x9_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⛰ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.x9_3
team modify m.x9_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⛰ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.x9_4
team modify m.x9_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⛰ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.x9_5
team modify m.x9_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⛰ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team remove m.x10
team add m.x10_0
team modify m.x10_0 prefix [{"text": "", "color": "white"}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⛰ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.x10_1
team modify m.x10_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⛰ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.x10_2
team modify m.x10_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⛰ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.x10_3
team modify m.x10_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⛰ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.x10_4
team modify m.x10_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⛰ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.x10_5
team modify m.x10_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⛰ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team remove m.t0
team add m.t0_0
team modify m.t0_0 prefix [{"text": "", "color": "white"}, {"color": "gray", "text": "⚖ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.t0_1
team modify m.t0_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚖ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.t0_2
team modify m.t0_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚖ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.t0_3
team modify m.t0_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚖ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.t0_4
team modify m.t0_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚖ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team add m.t0_5
team modify m.t0_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gray", "text": "⚖ Apprenti"}, {"text": " ", "color": "white", "bold": false}]
team remove m.t1
team add m.t1_0
team modify m.t1_0 prefix [{"text": "", "color": "white"}, {"color": "white", "text": "⚖ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.t1_1
team modify m.t1_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚖ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.t1_2
team modify m.t1_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚖ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.t1_3
team modify m.t1_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚖ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.t1_4
team modify m.t1_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚖ Initié"}, {"text": " ", "color": "white", "bold": false}]
team add m.t1_5
team modify m.t1_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "white", "text": "⚖ Initié"}, {"text": " ", "color": "white", "bold": false}]
team remove m.t2
team add m.t2_0
team modify m.t2_0 prefix [{"text": "", "color": "white"}, {"color": "dark_green", "text": "⚖ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.t2_1
team modify m.t2_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "dark_green", "text": "⚖ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.t2_2
team modify m.t2_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "dark_green", "text": "⚖ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.t2_3
team modify m.t2_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "dark_green", "text": "⚖ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.t2_4
team modify m.t2_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "dark_green", "text": "⚖ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team add m.t2_5
team modify m.t2_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "dark_green", "text": "⚖ Compagnon"}, {"text": " ", "color": "white", "bold": false}]
team remove m.t3
team add m.t3_0
team modify m.t3_0 prefix [{"text": "", "color": "white"}, {"color": "dark_green", "bold": true, "text": "⚖ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.t3_1
team modify m.t3_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "dark_green", "bold": true, "text": "⚖ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.t3_2
team modify m.t3_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "dark_green", "bold": true, "text": "⚖ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.t3_3
team modify m.t3_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "dark_green", "bold": true, "text": "⚖ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.t3_4
team modify m.t3_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "dark_green", "bold": true, "text": "⚖ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team add m.t3_5
team modify m.t3_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "dark_green", "bold": true, "text": "⚖ Artisan"}, {"text": " ", "color": "white", "bold": false}]
team remove m.t4
team add m.t4_0
team modify m.t4_0 prefix [{"text": "", "color": "white"}, {"color": "yellow", "bold": true, "text": "⚖ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.t4_1
team modify m.t4_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚖ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.t4_2
team modify m.t4_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚖ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.t4_3
team modify m.t4_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚖ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.t4_4
team modify m.t4_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚖ Expert"}, {"text": " ", "color": "white", "bold": false}]
team add m.t4_5
team modify m.t4_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "yellow", "bold": true, "text": "⚖ Expert"}, {"text": " ", "color": "white", "bold": false}]
team remove m.t5
team add m.t5_0
team modify m.t5_0 prefix [{"text": "", "color": "white"}, {"color": "gold", "bold": true, "text": "⚖ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.t5_1
team modify m.t5_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚖ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.t5_2
team modify m.t5_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚖ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.t5_3
team modify m.t5_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚖ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.t5_4
team modify m.t5_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚖ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team add m.t5_5
team modify m.t5_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "gold", "bold": true, "text": "⚖ Vétéran"}, {"text": " ", "color": "white", "bold": false}]
team remove m.t6
team add m.t6_0
team modify m.t6_0 prefix [{"text": "", "color": "white"}, {"color": "red", "bold": true, "text": "⚖ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.t6_1
team modify m.t6_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚖ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.t6_2
team modify m.t6_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚖ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.t6_3
team modify m.t6_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚖ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.t6_4
team modify m.t6_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚖ Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.t6_5
team modify m.t6_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "red", "bold": true, "text": "⚖ Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.t7
team add m.t7_0
team modify m.t7_0 prefix [{"text": "", "color": "white"}, {"color": "light_purple", "bold": true, "text": "⚖ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.t7_1
team modify m.t7_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚖ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.t7_2
team modify m.t7_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚖ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.t7_3
team modify m.t7_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚖ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.t7_4
team modify m.t7_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚖ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team add m.t7_5
team modify m.t7_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "light_purple", "bold": true, "text": "⚖ Grand Maître"}, {"text": " ", "color": "white", "bold": false}]
team remove m.t8
team add m.t8_0
team modify m.t8_0 prefix [{"text": "", "color": "white"}, {"color": "dark_purple", "bold": true, "text": "⚖ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.t8_1
team modify m.t8_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚖ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.t8_2
team modify m.t8_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚖ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.t8_3
team modify m.t8_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚖ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.t8_4
team modify m.t8_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚖ Légende"}, {"text": " ", "color": "white", "bold": false}]
team add m.t8_5
team modify m.t8_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "dark_purple", "bold": true, "text": "⚖ Légende"}, {"text": " ", "color": "white", "bold": false}]
team remove m.t9
team add m.t9_0
team modify m.t9_0 prefix [{"text": "", "color": "white"}, {"color": "aqua", "bold": true, "text": "⚖ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.t9_1
team modify m.t9_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚖ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.t9_2
team modify m.t9_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚖ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.t9_3
team modify m.t9_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚖ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.t9_4
team modify m.t9_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚖ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team add m.t9_5
team modify m.t9_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"color": "aqua", "bold": true, "text": "⚖ Mythique"}, {"text": " ", "color": "white", "bold": false}]
team remove m.t10
team add m.t10_0
team modify m.t10_0 prefix [{"text": "", "color": "white"}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚖ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.t10_1
team modify m.t10_1 prefix [{"text": "", "color": "white"}, {"text": "★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚖ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.t10_2
team modify m.t10_2 prefix [{"text": "", "color": "white"}, {"text": "★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚖ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.t10_3
team modify m.t10_3 prefix [{"text": "", "color": "white"}, {"text": "★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚖ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.t10_4
team modify m.t10_4 prefix [{"text": "", "color": "white"}, {"text": "★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚖ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
team add m.t10_5
team modify m.t10_5 prefix [{"text": "", "color": "white"}, {"text": "★★★★★ ", "color": "gold", "bold": false}, {"text": "a", "color": "gold", "obfuscated": true}, {"color": "dark_red", "bold": true, "text": "⚖ Dieu"}, {"text": "a", "color": "gold", "obfuscated": true}, {"text": " ", "color": "white", "bold": false}]
