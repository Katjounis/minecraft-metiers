scoreboard players operation @s m.pref = @s m.trig
scoreboard players remove @s m.pref 10
execute if score @s m.pref matches 0 run team leave @s
execute if score @s m.pref matches 0 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Titre retiré.","color":"gray"}]
execute if score @s m.pref matches 1.. run tag @s add metiers.maj
execute if score @s m.pref matches 1.. run function metiers:prefixe/maj
execute if score @s m.pref matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Titre mis à jour.","color":"gray"}]
playsound minecraft:ui.button.click master @s
