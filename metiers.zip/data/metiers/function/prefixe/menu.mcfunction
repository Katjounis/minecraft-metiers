function metiers:menu_data
function metiers:prefixe/menu_dialog with storage metiers:menu
