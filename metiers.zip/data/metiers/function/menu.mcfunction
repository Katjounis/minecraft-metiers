function metiers:menu_data
function metiers:menu_dialog with storage metiers:menu
