advancement revoke @s only metiers:forge/faux
execute if score @s m.forgecd matches 1.. run return 0
scoreboard players set @s m.forgecd 2
execute positioned ~-2 ~ ~-2 run function metiers:forge/faux_bloc
execute positioned ~-2 ~ ~-1 run function metiers:forge/faux_bloc
execute positioned ~-2 ~ ~0 run function metiers:forge/faux_bloc
execute positioned ~-2 ~ ~1 run function metiers:forge/faux_bloc
execute positioned ~-2 ~ ~2 run function metiers:forge/faux_bloc
execute positioned ~-1 ~ ~-2 run function metiers:forge/faux_bloc
execute positioned ~-1 ~ ~-1 run function metiers:forge/faux_bloc
execute positioned ~-1 ~ ~0 run function metiers:forge/faux_bloc
execute positioned ~-1 ~ ~1 run function metiers:forge/faux_bloc
execute positioned ~-1 ~ ~2 run function metiers:forge/faux_bloc
execute positioned ~0 ~ ~-2 run function metiers:forge/faux_bloc
execute positioned ~0 ~ ~-1 run function metiers:forge/faux_bloc
execute positioned ~0 ~ ~0 run function metiers:forge/faux_bloc
execute positioned ~0 ~ ~1 run function metiers:forge/faux_bloc
execute positioned ~0 ~ ~2 run function metiers:forge/faux_bloc
execute positioned ~1 ~ ~-2 run function metiers:forge/faux_bloc
execute positioned ~1 ~ ~-1 run function metiers:forge/faux_bloc
execute positioned ~1 ~ ~0 run function metiers:forge/faux_bloc
execute positioned ~1 ~ ~1 run function metiers:forge/faux_bloc
execute positioned ~1 ~ ~2 run function metiers:forge/faux_bloc
execute positioned ~2 ~ ~-2 run function metiers:forge/faux_bloc
execute positioned ~2 ~ ~-1 run function metiers:forge/faux_bloc
execute positioned ~2 ~ ~0 run function metiers:forge/faux_bloc
execute positioned ~2 ~ ~1 run function metiers:forge/faux_bloc
execute positioned ~2 ~ ~2 run function metiers:forge/faux_bloc
playsound minecraft:item.hoe.till master @s ~ ~ ~ 1 0.8
particle minecraft:sweep_attack ~ ~0.5 ~ 1.5 0.2 1.5 0 6
