scoreboard players add #pas m.tmp 1
execute unless block ~ ~ ~ #metiers:vide align xyz positioned ~0.5 ~0.5 ~0.5 as @e[type=minecraft:marker,tag=metiers.mvise] if score @s m.own = #pid m.tmp run return run function metiers:forge/marteau_poser
execute if score #pas m.tmp matches ..50 positioned ^ ^ ^0.1 run function metiers:forge/marteau_rayon
