tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ce cristal ne va pas sur cet outil.","color":"red"}]
