tp @s ~ ~ ~
scoreboard players operation @s m.ax = #ax m.tmp
