execute if score @s m.cfor_c matches 1 run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ce cristal est déjà serti.","color":"red"}]
execute unless score @s m.c_lvl matches 40.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 40 dans ce métier.","color":"red"}]
scoreboard players set #sl m.tmp 0
execute if score @s m.c_out matches 3.. run scoreboard players add #sl m.tmp 1
execute if score @s m.c_out matches 6.. run scoreboard players add #sl m.tmp 1
execute if score @s m.c_out matches 9.. run scoreboard players add #sl m.tmp 1
scoreboard players operation #us m.tmp = @s m.csag_c
scoreboard players operation #us m.tmp += @s m.cfor_c
scoreboard players operation #us m.tmp += @s m.ceco_c
execute if score #us m.tmp >= #sl m.tmp run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Plus d’emplacement libre : il en faut un nouveau (paliers 3, 6 et 9).","color":"red"}]
execute unless score @s m.cr_c matches 160.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
scoreboard players remove @s m.cr_c 160
scoreboard players set @s m.cfor_c 1
function metiers:c/outil_donner
playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 1 1.2
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cristal serti dans ton outil.","color":"aqua"}]
function metiers:forge/menu
