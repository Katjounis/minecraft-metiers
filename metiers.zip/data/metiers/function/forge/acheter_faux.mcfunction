execute unless score @s m.f_lvl matches 50.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 50 en Fermier.","color":"red"}]
execute unless score @s m.cr_f matches 220.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
execute unless score @s m.ecl matches 3.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez d’éclats de boss.","color":"red"}]
scoreboard players remove @s m.cr_f 220
scoreboard players remove @s m.ecl 3
function metiers:forge/donner_faux
playsound minecraft:block.anvil.use master @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu as forgé : Faux du Fermier.","color":"gold"}]
function metiers:forge/menu
