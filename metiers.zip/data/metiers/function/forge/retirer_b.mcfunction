execute if score @s m.ceco_b matches 1 run return run function metiers:forge/retirer_fin {s:"m.ceco_b",j:"b"}
execute if score @s m.cfor_b matches 1 run return run function metiers:forge/retirer_fin {s:"m.cfor_b",j:"b"}
execute if score @s m.csag_b matches 1 run return run function metiers:forge/retirer_fin {s:"m.csag_b",j:"b"}
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucun cristal serti sur cet outil.","color":"red"}]
