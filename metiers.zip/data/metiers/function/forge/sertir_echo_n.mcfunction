execute if score @s m.ceco_n matches 1 run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ce cristal est déjà serti.","color":"red"}]
execute unless score @s m.n_lvl matches 60.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 60 dans ce métier.","color":"red"}]
scoreboard players set #sl m.tmp 0
execute if score @s m.n_out matches 3.. run scoreboard players add #sl m.tmp 1
execute if score @s m.n_out matches 6.. run scoreboard players add #sl m.tmp 1
execute if score @s m.n_out matches 9.. run scoreboard players add #sl m.tmp 1
scoreboard players operation #us m.tmp = @s m.csag_n
scoreboard players operation #us m.tmp += @s m.cfor_n
scoreboard players operation #us m.tmp += @s m.ceco_n
execute if score #us m.tmp >= #sl m.tmp run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Plus d’emplacement libre : il en faut un nouveau (paliers 3, 6 et 9).","color":"red"}]
execute unless score @s m.cr_n matches 240.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
scoreboard players remove @s m.cr_n 240
scoreboard players set @s m.ceco_n 1
function metiers:n/outil_donner
playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 1 1.2
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cristal serti dans ton outil.","color":"aqua"}]
function metiers:forge/menu
