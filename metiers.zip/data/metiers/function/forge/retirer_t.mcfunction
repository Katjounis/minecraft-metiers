execute if score @s m.ceco_t matches 1 run return run function metiers:forge/retirer_fin {s:"m.ceco_t",j:"t"}
execute if score @s m.cfor_t matches 1 run return run function metiers:forge/retirer_fin {s:"m.cfor_t",j:"t"}
execute if score @s m.csag_t matches 1 run return run function metiers:forge/retirer_fin {s:"m.csag_t",j:"t"}
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucun cristal serti sur cet outil.","color":"red"}]
