execute if score @s m.ceco_c matches 1 run return run function metiers:forge/retirer_fin {s:"m.ceco_c",j:"c"}
execute if score @s m.cfor_c matches 1 run return run function metiers:forge/retirer_fin {s:"m.cfor_c",j:"c"}
execute if score @s m.csag_c matches 1 run return run function metiers:forge/retirer_fin {s:"m.csag_c",j:"c"}
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucun cristal serti sur cet outil.","color":"red"}]
