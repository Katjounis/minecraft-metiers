tag @s remove metiers.lasso_plein
function metiers:forge/donner_lasso
