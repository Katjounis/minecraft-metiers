execute if score @s m.ceco_n matches 1 run return run function metiers:forge/retirer_fin {s:"m.ceco_n",j:"n"}
execute if score @s m.cfor_n matches 1 run return run function metiers:forge/retirer_fin {s:"m.cfor_n",j:"n"}
execute if score @s m.csag_n matches 1 run return run function metiers:forge/retirer_fin {s:"m.csag_n",j:"n"}
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucun cristal serti sur cet outil.","color":"red"}]
