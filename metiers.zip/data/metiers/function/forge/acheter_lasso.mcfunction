execute unless score @s m.e_lvl matches 40.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 40 en Éleveur.","color":"red"}]
execute unless score @s m.cr_e matches 140.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
execute unless score @s m.ecl matches 1.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez d’éclats de boss.","color":"red"}]
scoreboard players remove @s m.cr_e 140
scoreboard players remove @s m.ecl 1
function metiers:forge/donner_lasso
playsound minecraft:block.anvil.use master @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu as forgé : Lasso de l'Éleveur.","color":"gold"}]
function metiers:forge/menu
