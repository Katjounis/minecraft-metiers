execute if score @s m.ceco_x matches 1 run return run function metiers:forge/retirer_fin {s:"m.ceco_x",j:"x"}
execute if score @s m.cfor_x matches 1 run return run function metiers:forge/retirer_fin {s:"m.cfor_x",j:"x"}
execute if score @s m.csag_x matches 1 run return run function metiers:forge/retirer_fin {s:"m.csag_x",j:"x"}
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucun cristal serti sur cet outil.","color":"red"}]
