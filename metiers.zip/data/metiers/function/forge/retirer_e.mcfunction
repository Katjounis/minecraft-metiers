execute if score @s m.ceco_e matches 1 run return run function metiers:forge/retirer_fin {s:"m.ceco_e",j:"e"}
execute if score @s m.cfor_e matches 1 run return run function metiers:forge/retirer_fin {s:"m.cfor_e",j:"e"}
execute if score @s m.csag_e matches 1 run return run function metiers:forge/retirer_fin {s:"m.csag_e",j:"e"}
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucun cristal serti sur cet outil.","color":"red"}]
