scoreboard players add #pas m.tmp 1
execute as @e[type=#metiers:animaux,distance=..1.2,limit=1,sort=nearest] run return run function metiers:forge/lasso_prendre
execute if score #pas m.tmp matches ..40 positioned ^ ^ ^0.1 run function metiers:forge/lasso_rayon
