scoreboard players set #sl m.tmp 0
execute if score @s m.p_out matches 3.. run scoreboard players add #sl m.tmp 1
execute if score @s m.p_out matches 6.. run scoreboard players add #sl m.tmp 1
execute if score @s m.p_out matches 9.. run scoreboard players add #sl m.tmp 1
scoreboard players operation #us m.tmp = @s m.csag_p
scoreboard players operation #us m.tmp += @s m.cfor_p
scoreboard players operation #us m.tmp += @s m.ceco_p
execute store result storage metiers:fg us int 1 run scoreboard players get #us m.tmp
execute store result storage metiers:fg sl int 1 run scoreboard players get #sl m.tmp
data modify storage metiers:fg outil set value "Outil en main : Canne de Pêcheur, emplacements utilisés "
data modify storage metiers:fg g set value ""
data modify storage metiers:fg l_sag set value "Sagesse · 90"
data modify storage metiers:fg k_sag set value "red"
execute if score @s m.cr_p matches 90.. if score #us m.tmp < #sl m.tmp run data modify storage metiers:fg k_sag set value "yellow"
execute unless score @s m.p_lvl matches 20.. run data modify storage metiers:fg l_sag set value "✖ Sagesse · niv. 20"
execute unless score @s m.p_lvl matches 20.. run data modify storage metiers:fg k_sag set value "dark_gray"
execute if score @s m.csag_p matches 1 run data modify storage metiers:fg l_sag set value "✔ Sagesse serti"
execute if score @s m.csag_p matches 1 run data modify storage metiers:fg k_sag set value "green"
data modify storage metiers:fg l_for set value "Fortune · 160"
data modify storage metiers:fg k_for set value "red"
execute if score @s m.cr_p matches 160.. if score #us m.tmp < #sl m.tmp run data modify storage metiers:fg k_for set value "yellow"
execute unless score @s m.p_lvl matches 40.. run data modify storage metiers:fg l_for set value "✖ Fortune · niv. 40"
execute unless score @s m.p_lvl matches 40.. run data modify storage metiers:fg k_for set value "dark_gray"
execute if score @s m.cfor_p matches 1 run data modify storage metiers:fg l_for set value "✔ Fortune serti"
execute if score @s m.cfor_p matches 1 run data modify storage metiers:fg k_for set value "green"
data modify storage metiers:fg l_eco set value "Écho · 240"
data modify storage metiers:fg k_eco set value "red"
execute if score @s m.cr_p matches 240.. if score #us m.tmp < #sl m.tmp run data modify storage metiers:fg k_eco set value "yellow"
execute unless score @s m.p_lvl matches 60.. run data modify storage metiers:fg l_eco set value "✖ Écho · niv. 60"
execute unless score @s m.p_lvl matches 60.. run data modify storage metiers:fg k_eco set value "dark_gray"
execute if score @s m.ceco_p matches 1 run data modify storage metiers:fg l_eco set value "✔ Écho serti"
execute if score @s m.ceco_p matches 1 run data modify storage metiers:fg k_eco set value "green"
data modify storage metiers:fg l_eff set value "Efficacité : pas pour cet outil"
