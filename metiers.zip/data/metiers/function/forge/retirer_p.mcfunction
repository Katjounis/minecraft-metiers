execute if score @s m.ceco_p matches 1 run return run function metiers:forge/retirer_fin {s:"m.ceco_p",j:"p"}
execute if score @s m.cfor_p matches 1 run return run function metiers:forge/retirer_fin {s:"m.cfor_p",j:"p"}
execute if score @s m.csag_p matches 1 run return run function metiers:forge/retirer_fin {s:"m.csag_p",j:"p"}
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucun cristal serti sur cet outil.","color":"red"}]
