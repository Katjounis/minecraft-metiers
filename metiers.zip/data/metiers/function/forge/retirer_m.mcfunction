execute if score @s m.ceco_m matches 1 run return run function metiers:forge/retirer_fin {s:"m.ceco_m",j:"m"}
execute if score @s m.cfor_m matches 1 run return run function metiers:forge/retirer_fin {s:"m.cfor_m",j:"m"}
execute if score @s m.csag_m matches 1 run return run function metiers:forge/retirer_fin {s:"m.csag_m",j:"m"}
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucun cristal serti sur cet outil.","color":"red"}]
