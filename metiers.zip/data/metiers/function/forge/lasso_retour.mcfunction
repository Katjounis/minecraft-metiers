scoreboard players set #egg m.tmp 0
scoreboard players operation #egg m.tmp += @s s.egg_cow
scoreboard players operation #egg m.tmp += @s s.egg_mooshroom
scoreboard players operation #egg m.tmp += @s s.egg_sheep
scoreboard players operation #egg m.tmp += @s s.egg_pig
scoreboard players operation #egg m.tmp += @s s.egg_chicken
scoreboard players operation #egg m.tmp += @s s.egg_horse
scoreboard players operation #egg m.tmp += @s s.egg_donkey
scoreboard players operation #egg m.tmp += @s s.egg_mule
scoreboard players operation #egg m.tmp += @s s.egg_llama
scoreboard players operation #egg m.tmp += @s s.egg_goat
scoreboard players operation #egg m.tmp += @s s.egg_rabbit
scoreboard players operation #egg m.tmp += @s s.egg_camel
scoreboard players operation #egg m.tmp += @s s.egg_turtle
scoreboard players operation #egg m.tmp += @s s.egg_frog
scoreboard players operation #egg m.tmp += @s s.egg_armadillo
scoreboard players operation #egg m.tmp += @s s.egg_sniffer
scoreboard players operation #egg m.tmp += @s s.egg_wolf
scoreboard players operation #egg m.tmp += @s s.egg_cat
scoreboard players operation #egg m.tmp += @s s.egg_fox
scoreboard players operation #egg m.tmp += @s s.egg_bee
scoreboard players operation #egg m.tmp += @s s.egg_panda
scoreboard players operation #egg m.tmp += @s s.egg_strider
scoreboard players set @s s.egg_cow 0
scoreboard players set @s s.egg_mooshroom 0
scoreboard players set @s s.egg_sheep 0
scoreboard players set @s s.egg_pig 0
scoreboard players set @s s.egg_chicken 0
scoreboard players set @s s.egg_horse 0
scoreboard players set @s s.egg_donkey 0
scoreboard players set @s s.egg_mule 0
scoreboard players set @s s.egg_llama 0
scoreboard players set @s s.egg_goat 0
scoreboard players set @s s.egg_rabbit 0
scoreboard players set @s s.egg_camel 0
scoreboard players set @s s.egg_turtle 0
scoreboard players set @s s.egg_frog 0
scoreboard players set @s s.egg_armadillo 0
scoreboard players set @s s.egg_sniffer 0
scoreboard players set @s s.egg_wolf 0
scoreboard players set @s s.egg_cat 0
scoreboard players set @s s.egg_fox 0
scoreboard players set @s s.egg_bee 0
scoreboard players set @s s.egg_panda 0
scoreboard players set @s s.egg_strider 0
execute if score #egg m.tmp matches 1.. if entity @s[tag=metiers.lasso_plein] unless items entity @s container.* *[minecraft:custom_data~{forge:"lasso_plein"}] run function metiers:forge/lasso_rendre
