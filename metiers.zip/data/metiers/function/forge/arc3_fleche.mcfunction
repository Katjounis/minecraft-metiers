summon minecraft:marker ^ ^ ^ {Tags:["metiers.a0"]}
summon minecraft:marker ^ ^ ^3 {Tags:["metiers.a1"]}
execute store result score #x0 m.tmp run data get entity @e[tag=metiers.a0,limit=1] Pos[0] 1000
execute store result score #y0 m.tmp run data get entity @e[tag=metiers.a0,limit=1] Pos[1] 1000
execute store result score #z0 m.tmp run data get entity @e[tag=metiers.a0,limit=1] Pos[2] 1000
execute store result score #x1 m.tmp run data get entity @e[tag=metiers.a1,limit=1] Pos[0] 1000
execute store result score #y1 m.tmp run data get entity @e[tag=metiers.a1,limit=1] Pos[1] 1000
execute store result score #z1 m.tmp run data get entity @e[tag=metiers.a1,limit=1] Pos[2] 1000
scoreboard players operation #x1 m.tmp -= #x0 m.tmp
scoreboard players operation #y1 m.tmp -= #y0 m.tmp
scoreboard players operation #z1 m.tmp -= #z0 m.tmp
summon minecraft:arrow ^ ^ ^1 {Tags:["metiers.a2"],pickup:0b,damage:2.5d}
execute store result entity @e[tag=metiers.a2,limit=1] Motion[0] double 0.001 run scoreboard players get #x1 m.tmp
execute store result entity @e[tag=metiers.a2,limit=1] Motion[1] double 0.001 run scoreboard players get #y1 m.tmp
execute store result entity @e[tag=metiers.a2,limit=1] Motion[2] double 0.001 run scoreboard players get #z1 m.tmp
data modify entity @e[tag=metiers.a2,limit=1] Owner set from entity @s UUID
tag @e[tag=metiers.a2] remove metiers.a2
kill @e[type=minecraft:marker,tag=metiers.a0]
kill @e[type=minecraft:marker,tag=metiers.a1]
