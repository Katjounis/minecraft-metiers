execute unless score @s m.n_lvl matches 40.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 40 en Enchanteur.","color":"red"}]
execute unless score @s m.cr_n matches 60.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
execute unless score @s m.ecl matches 0.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez d’éclats de boss.","color":"red"}]
scoreboard players remove @s m.cr_n 60
scoreboard players remove @s m.ecl 0
function metiers:forge/donner_parchemin
playsound minecraft:block.anvil.use master @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu as forgé : Parchemin de transfert.","color":"gold"}]
function metiers:forge/menu
