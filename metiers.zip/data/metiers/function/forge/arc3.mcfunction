scoreboard players set @s s.bow 0
execute anchored eyes rotated ~10 ~ run function metiers:forge/arc3_fleche
execute anchored eyes rotated ~-10 ~ run function metiers:forge/arc3_fleche
playsound minecraft:entity.arrow.shoot master @a ~ ~ ~ 0.8 1.3
