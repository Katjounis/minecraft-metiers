execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"b"}] run return run function metiers:forge/eff_b
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"f"}] run return run function metiers:forge/eff_f
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"m"}] run return run function metiers:forge/eff_m
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"c"}] run return run function metiers:forge/eff_c
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"p"}] run return run function metiers:forge/eff_p
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"e"}] run return run function metiers:forge/eff_e
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"n"}] run return run function metiers:forge/eff_n
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"x"}] run return run function metiers:forge/eff_x
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"t"}] run return run function metiers:forge/eff_t
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tiens ton outil de métier en main.","color":"red"}]
