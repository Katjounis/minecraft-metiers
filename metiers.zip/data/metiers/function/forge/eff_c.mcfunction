tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"L’Efficacité ne va pas sur cet outil.","color":"red"}]
