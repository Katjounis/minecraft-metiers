execute store result storage metiers:fg ecl int 1 run scoreboard players get @s m.ecl
execute store result storage metiers:fg cr_b int 1 run scoreboard players get @s m.cr_b
execute store result storage metiers:fg cr_f int 1 run scoreboard players get @s m.cr_f
execute store result storage metiers:fg cr_m int 1 run scoreboard players get @s m.cr_m
execute store result storage metiers:fg cr_c int 1 run scoreboard players get @s m.cr_c
execute store result storage metiers:fg cr_p int 1 run scoreboard players get @s m.cr_p
execute store result storage metiers:fg cr_e int 1 run scoreboard players get @s m.cr_e
execute store result storage metiers:fg cr_n int 1 run scoreboard players get @s m.cr_n
execute store result storage metiers:fg cr_x int 1 run scoreboard players get @s m.cr_x
execute store result storage metiers:fg cr_t int 1 run scoreboard players get @s m.cr_t
data modify storage metiers:fg c_marteau set value "red"
execute if score @s m.cr_m matches 260.. if score @s m.ecl matches 4.. run data modify storage metiers:fg c_marteau set value "yellow"
execute unless score @s m.m_lvl matches 50.. run data modify storage metiers:fg c_marteau set value "dark_gray"
data modify storage metiers:fg c_faux set value "red"
execute if score @s m.cr_f matches 220.. if score @s m.ecl matches 3.. run data modify storage metiers:fg c_faux set value "yellow"
execute unless score @s m.f_lvl matches 50.. run data modify storage metiers:fg c_faux set value "dark_gray"
data modify storage metiers:fg c_arc3 set value "red"
execute if score @s m.cr_c matches 300.. if score @s m.ecl matches 5.. run data modify storage metiers:fg c_arc3 set value "yellow"
execute unless score @s m.c_lvl matches 60.. run data modify storage metiers:fg c_arc3 set value "dark_gray"
data modify storage metiers:fg c_lasso set value "red"
execute if score @s m.cr_e matches 140.. if score @s m.ecl matches 1.. run data modify storage metiers:fg c_lasso set value "yellow"
execute unless score @s m.e_lvl matches 40.. run data modify storage metiers:fg c_lasso set value "dark_gray"
data modify storage metiers:fg c_parchemin set value "red"
execute if score @s m.cr_n matches 60.. if score @s m.ecl matches 0.. run data modify storage metiers:fg c_parchemin set value "yellow"
execute unless score @s m.n_lvl matches 40.. run data modify storage metiers:fg c_parchemin set value "dark_gray"
data modify storage metiers:fg c_aimant set value "red"
execute if score @s m.ecl matches 6.. run data modify storage metiers:fg c_aimant set value "yellow"
data modify storage metiers:fg c_cape set value "red"
execute if score @s m.ecl matches 12.. run data modify storage metiers:fg c_cape set value "yellow"
scoreboard players set #hj m.tmp 0
data modify storage metiers:fg outil set value "Tiens ton outil de métier en main pour sertir un cristal."
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"b"}] run scoreboard players set #hj m.tmp 1
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"f"}] run scoreboard players set #hj m.tmp 2
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"m"}] run scoreboard players set #hj m.tmp 3
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"c"}] run scoreboard players set #hj m.tmp 4
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"p"}] run scoreboard players set #hj m.tmp 5
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"e"}] run scoreboard players set #hj m.tmp 6
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"n"}] run scoreboard players set #hj m.tmp 7
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"x"}] run scoreboard players set #hj m.tmp 8
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"t"}] run scoreboard players set #hj m.tmp 9
data modify storage metiers:fg l_sag set value "—"
data modify storage metiers:fg l_for set value "—"
data modify storage metiers:fg l_eco set value "—"
data modify storage metiers:fg l_eff set value "—"
data modify storage metiers:fg k_sag set value "dark_gray"
data modify storage metiers:fg k_for set value "dark_gray"
data modify storage metiers:fg k_eco set value "dark_gray"
data modify storage metiers:fg k_eff set value "dark_gray"
execute if score #hj m.tmp matches 1 run function metiers:forge/infos_b
execute if score #hj m.tmp matches 2 run function metiers:forge/infos_f
execute if score #hj m.tmp matches 3 run function metiers:forge/infos_m
execute if score #hj m.tmp matches 4 run function metiers:forge/infos_c
execute if score #hj m.tmp matches 5 run function metiers:forge/infos_p
execute if score #hj m.tmp matches 6 run function metiers:forge/infos_e
execute if score #hj m.tmp matches 7 run function metiers:forge/infos_n
execute if score #hj m.tmp matches 8 run function metiers:forge/infos_x
execute if score #hj m.tmp matches 9 run function metiers:forge/infos_t
function metiers:forge/menu_dialog with storage metiers:fg
