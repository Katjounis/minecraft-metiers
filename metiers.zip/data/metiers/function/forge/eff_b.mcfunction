execute if score @s m.ceff_b matches 7.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Efficacité déjà au maximum.","color":"red"}]
execute if score @s m.ceff_b matches 0 unless score @s m.b_lvl matches 10.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 10 dans ce métier.","color":"red"}]
execute if score @s m.ceff_b matches 0 unless score @s m.cr_b matches 40.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
execute if score @s m.ceff_b matches 0 run scoreboard players remove @s m.cr_b 40
execute if score @s m.ceff_b matches 1 unless score @s m.b_lvl matches 20.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 20 dans ce métier.","color":"red"}]
execute if score @s m.ceff_b matches 1 unless score @s m.cr_b matches 70.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
execute if score @s m.ceff_b matches 1 run scoreboard players remove @s m.cr_b 70
execute if score @s m.ceff_b matches 2 unless score @s m.b_lvl matches 30.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 30 dans ce métier.","color":"red"}]
execute if score @s m.ceff_b matches 2 unless score @s m.cr_b matches 110.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
execute if score @s m.ceff_b matches 2 run scoreboard players remove @s m.cr_b 110
execute if score @s m.ceff_b matches 3 unless score @s m.b_lvl matches 40.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 40 dans ce métier.","color":"red"}]
execute if score @s m.ceff_b matches 3 unless score @s m.cr_b matches 150.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
execute if score @s m.ceff_b matches 3 run scoreboard players remove @s m.cr_b 150
execute if score @s m.ceff_b matches 4 unless score @s m.b_lvl matches 50.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 50 dans ce métier.","color":"red"}]
execute if score @s m.ceff_b matches 4 unless score @s m.cr_b matches 200.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
execute if score @s m.ceff_b matches 4 run scoreboard players remove @s m.cr_b 200
execute if score @s m.ceff_b matches 5 unless score @s m.b_lvl matches 60.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 60 dans ce métier.","color":"red"}]
execute if score @s m.ceff_b matches 5 unless score @s m.cr_b matches 260.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
execute if score @s m.ceff_b matches 5 run scoreboard players remove @s m.cr_b 260
execute if score @s m.ceff_b matches 6 unless score @s m.b_lvl matches 80.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 80 dans ce métier.","color":"red"}]
execute if score @s m.ceff_b matches 6 unless score @s m.cr_b matches 330.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
execute if score @s m.ceff_b matches 6 run scoreboard players remove @s m.cr_b 330
scoreboard players add @s m.ceff_b 1
function metiers:b/outil_donner
playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 1 1.4
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Efficacité améliorée.","color":"aqua"}]
function metiers:forge/menu
