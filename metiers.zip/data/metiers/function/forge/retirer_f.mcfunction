execute if score @s m.ceco_f matches 1 run return run function metiers:forge/retirer_fin {s:"m.ceco_f",j:"f"}
execute if score @s m.cfor_f matches 1 run return run function metiers:forge/retirer_fin {s:"m.cfor_f",j:"f"}
execute if score @s m.csag_f matches 1 run return run function metiers:forge/retirer_fin {s:"m.csag_f",j:"f"}
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucun cristal serti sur cet outil.","color":"red"}]
