$scoreboard players set @s $(s) 0
$function metiers:$(j)/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cristal retiré.","color":"gray"}]
function metiers:forge/menu
