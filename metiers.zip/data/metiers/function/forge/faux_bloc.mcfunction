execute positioned ~ ~0 ~ if block ~ ~ ~ minecraft:wheat[age=7] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~0 ~ if block ~ ~ ~ minecraft:wheat[age=7] run setblock ~ ~ ~ minecraft:wheat[age=0]
execute positioned ~ ~0 ~ if block ~ ~ ~ minecraft:carrots[age=7] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~0 ~ if block ~ ~ ~ minecraft:carrots[age=7] run setblock ~ ~ ~ minecraft:carrots[age=0]
execute positioned ~ ~0 ~ if block ~ ~ ~ minecraft:potatoes[age=7] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~0 ~ if block ~ ~ ~ minecraft:potatoes[age=7] run setblock ~ ~ ~ minecraft:potatoes[age=0]
execute positioned ~ ~0 ~ if block ~ ~ ~ minecraft:beetroots[age=3] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~0 ~ if block ~ ~ ~ minecraft:beetroots[age=3] run setblock ~ ~ ~ minecraft:beetroots[age=0]
execute positioned ~ ~0 ~ if block ~ ~ ~ minecraft:nether_wart[age=3] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~0 ~ if block ~ ~ ~ minecraft:nether_wart[age=3] run setblock ~ ~ ~ minecraft:nether_wart[age=0]
execute positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:wheat[age=7] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:wheat[age=7] run setblock ~ ~ ~ minecraft:wheat[age=0]
execute positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:carrots[age=7] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:carrots[age=7] run setblock ~ ~ ~ minecraft:carrots[age=0]
execute positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:potatoes[age=7] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:potatoes[age=7] run setblock ~ ~ ~ minecraft:potatoes[age=0]
execute positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:beetroots[age=3] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:beetroots[age=3] run setblock ~ ~ ~ minecraft:beetroots[age=0]
execute positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:nether_wart[age=3] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:nether_wart[age=3] run setblock ~ ~ ~ minecraft:nether_wart[age=0]
execute positioned ~ ~1 ~ if block ~ ~ ~ minecraft:wheat[age=7] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~1 ~ if block ~ ~ ~ minecraft:wheat[age=7] run setblock ~ ~ ~ minecraft:wheat[age=0]
execute positioned ~ ~1 ~ if block ~ ~ ~ minecraft:carrots[age=7] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~1 ~ if block ~ ~ ~ minecraft:carrots[age=7] run setblock ~ ~ ~ minecraft:carrots[age=0]
execute positioned ~ ~1 ~ if block ~ ~ ~ minecraft:potatoes[age=7] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~1 ~ if block ~ ~ ~ minecraft:potatoes[age=7] run setblock ~ ~ ~ minecraft:potatoes[age=0]
execute positioned ~ ~1 ~ if block ~ ~ ~ minecraft:beetroots[age=3] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~1 ~ if block ~ ~ ~ minecraft:beetroots[age=3] run setblock ~ ~ ~ minecraft:beetroots[age=0]
execute positioned ~ ~1 ~ if block ~ ~ ~ minecraft:nether_wart[age=3] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ minecraft:netherite_hoe
execute positioned ~ ~1 ~ if block ~ ~ ~ minecraft:nether_wart[age=3] run setblock ~ ~ ~ minecraft:nether_wart[age=0]
