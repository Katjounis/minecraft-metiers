scoreboard players operation #pid m.tmp = @s m.id
scoreboard players set #has m.tmp 0
execute as @e[type=minecraft:marker,tag=metiers.mvise] if score @s m.own = #pid m.tmp run scoreboard players set #has m.tmp 1
execute if score #has m.tmp matches 0 run summon minecraft:marker ~ ~ ~ {Tags:["metiers.mvise","metiers.mnew"]}
scoreboard players operation @e[type=minecraft:marker,tag=metiers.mnew] m.own = #pid m.tmp
tag @e[tag=metiers.mnew] remove metiers.mnew
execute if score @s s.pick matches 1.. as @e[type=minecraft:marker,tag=metiers.mvise] if score @s m.own = #pid m.tmp at @s run function metiers:forge/marteau_casser
scoreboard players set @s s.pick 0
execute store result score #pitch m.tmp run data get entity @s Rotation[1]
execute store result score #yaw m.tmp run data get entity @s Rotation[0]
scoreboard players set #ax m.tmp 2
execute if score #yaw m.tmp matches -135..-45 run scoreboard players set #ax m.tmp 1
execute if score #yaw m.tmp matches 45..135 run scoreboard players set #ax m.tmp 1
execute if score #pitch m.tmp matches 45.. run scoreboard players set #ax m.tmp 0
execute if score #pitch m.tmp matches ..-45 run scoreboard players set #ax m.tmp 0
scoreboard players set #pas m.tmp 0
execute anchored eyes positioned ^ ^ ^ run function metiers:forge/marteau_rayon
