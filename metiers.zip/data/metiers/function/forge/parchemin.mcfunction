execute unless items entity @s weapon.offhand *[minecraft:enchantments] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Mets un objet enchanté dans ta main secondaire.","color":"red"}]
execute if data entity @s equipment.offhand.components."minecraft:custom_data".metiers_outil run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Impossible sur un objet de métier.","color":"red"}]
execute unless data entity @s equipment.offhand.components."minecraft:enchantments" run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cet objet n'a pas d'enchantement à transférer.","color":"red"}]
summon minecraft:item ~ ~ ~ {Tags:["metiers.livre"],PickupDelay:32767s,Item:{id:"minecraft:enchanted_book",count:1}}
data modify entity @e[tag=metiers.livre,limit=1] Item.components."minecraft:stored_enchantments" set from entity @s equipment.offhand.components."minecraft:enchantments"
item modify entity @s weapon.offhand {function:"minecraft:set_components",type:"minecraft:set_components",components:{"!minecraft:enchantments":{}}}
item replace entity @s weapon.mainhand from entity @e[tag=metiers.livre,limit=1] contents
kill @e[tag=metiers.livre]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1.4
particle minecraft:enchant ~ ~1 ~ 0.4 0.6 0.4 0.5 60
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Les enchantements sont passés sur le livre.","color":"light_purple"}]
