summon minecraft:item ~ ~ ~ {Tags:["metiers.lasso_oeuf"],PickupDelay:32767s,Item:{id:"minecraft:pig_spawn_egg",count:1}}
data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data" set from entity @s
data remove entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".UUID
data remove entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".Pos
data remove entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".Motion
data remove entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".leash
execute if entity @s[type=minecraft:cow] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:cow_spawn_egg"
execute if entity @s[type=minecraft:cow] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:cow"
execute if entity @s[type=minecraft:mooshroom] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:mooshroom_spawn_egg"
execute if entity @s[type=minecraft:mooshroom] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:mooshroom"
execute if entity @s[type=minecraft:sheep] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:sheep_spawn_egg"
execute if entity @s[type=minecraft:sheep] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:sheep"
execute if entity @s[type=minecraft:pig] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:pig_spawn_egg"
execute if entity @s[type=minecraft:pig] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:pig"
execute if entity @s[type=minecraft:chicken] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:chicken_spawn_egg"
execute if entity @s[type=minecraft:chicken] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:chicken"
execute if entity @s[type=minecraft:horse] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:horse_spawn_egg"
execute if entity @s[type=minecraft:horse] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:horse"
execute if entity @s[type=minecraft:donkey] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:donkey_spawn_egg"
execute if entity @s[type=minecraft:donkey] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:donkey"
execute if entity @s[type=minecraft:mule] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:mule_spawn_egg"
execute if entity @s[type=minecraft:mule] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:mule"
execute if entity @s[type=minecraft:llama] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:llama_spawn_egg"
execute if entity @s[type=minecraft:llama] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:llama"
execute if entity @s[type=minecraft:goat] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:goat_spawn_egg"
execute if entity @s[type=minecraft:goat] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:goat"
execute if entity @s[type=minecraft:rabbit] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:rabbit_spawn_egg"
execute if entity @s[type=minecraft:rabbit] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:rabbit"
execute if entity @s[type=minecraft:camel] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:camel_spawn_egg"
execute if entity @s[type=minecraft:camel] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:camel"
execute if entity @s[type=minecraft:turtle] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:turtle_spawn_egg"
execute if entity @s[type=minecraft:turtle] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:turtle"
execute if entity @s[type=minecraft:frog] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:frog_spawn_egg"
execute if entity @s[type=minecraft:frog] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:frog"
execute if entity @s[type=minecraft:armadillo] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:armadillo_spawn_egg"
execute if entity @s[type=minecraft:armadillo] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:armadillo"
execute if entity @s[type=minecraft:sniffer] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:sniffer_spawn_egg"
execute if entity @s[type=minecraft:sniffer] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:sniffer"
execute if entity @s[type=minecraft:wolf] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:wolf_spawn_egg"
execute if entity @s[type=minecraft:wolf] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:wolf"
execute if entity @s[type=minecraft:cat] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:cat_spawn_egg"
execute if entity @s[type=minecraft:cat] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:cat"
execute if entity @s[type=minecraft:fox] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:fox_spawn_egg"
execute if entity @s[type=minecraft:fox] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:fox"
execute if entity @s[type=minecraft:bee] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:bee_spawn_egg"
execute if entity @s[type=minecraft:bee] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:bee"
execute if entity @s[type=minecraft:panda] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:panda_spawn_egg"
execute if entity @s[type=minecraft:panda] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:panda"
execute if entity @s[type=minecraft:strider] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.id set value "minecraft:strider_spawn_egg"
execute if entity @s[type=minecraft:strider] run data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:entity_data".id set value "minecraft:strider"
data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:custom_name" set value {text:"Lasso (animal capturé)",color:"light_purple",bold:true,italic:false}
data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:item_model" set value "metiers:forge_lasso"
data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:custom_data" set value {forge:"lasso_plein"}
data modify entity @e[tag=metiers.lasso_oeuf,limit=1] Item.components."minecraft:enchantment_glint_override" set value 1b
execute as @a[tag=metiers.lanceur,limit=1] run item replace entity @s weapon.mainhand from entity @e[tag=metiers.lasso_oeuf,limit=1] contents
kill @e[tag=metiers.lasso_oeuf]
execute as @a[tag=metiers.lanceur] run tag @s add metiers.lasso_plein
particle minecraft:cloud ~ ~0.5 ~ 0.3 0.3 0.3 0.02 15
playsound minecraft:entity.leash_knot.place master @a ~ ~ ~ 1 1
tp @s ~ -400 ~
kill @s
