scoreboard players set #pas m.tmp 0
tag @s add metiers.lanceur
execute anchored eyes positioned ^ ^ ^ run function metiers:forge/lasso_rayon
tag @s remove metiers.lanceur
