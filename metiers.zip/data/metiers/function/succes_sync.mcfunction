tag @s add metiers.v3
execute if entity @s[tag=metiers.sk.b1] run advancement grant @s only metiers:b/competence_1
execute if entity @s[tag=metiers.sk.b2] run advancement grant @s only metiers:b/competence_2
execute if entity @s[tag=metiers.sk.b3] run advancement grant @s only metiers:b/competence_3
execute if entity @s[tag=metiers.sk.b4] run advancement grant @s only metiers:b/competence_4
execute if entity @s[tag=metiers.sk.b5] run advancement grant @s only metiers:b/competence_5
execute if entity @s[tag=metiers.sk.b6] run advancement grant @s only metiers:b/competence_6
execute if score @s m.b_lvl matches 10.. run advancement grant @s only metiers:b/niveau_10
execute if score @s m.b_lvl matches 20.. run advancement grant @s only metiers:b/niveau_20
execute if score @s m.b_lvl matches 30.. run advancement grant @s only metiers:b/niveau_30
execute if score @s m.b_lvl matches 40.. run advancement grant @s only metiers:b/niveau_40
execute if score @s m.b_lvl matches 50.. run advancement grant @s only metiers:b/niveau_50
execute if score @s m.b_lvl matches 60.. run advancement grant @s only metiers:b/niveau_60
execute if score @s m.b_lvl matches 70.. run advancement grant @s only metiers:b/niveau_70
execute if score @s m.b_lvl matches 80.. run advancement grant @s only metiers:b/niveau_80
execute if score @s m.b_lvl matches 90.. run advancement grant @s only metiers:b/niveau_90
execute if score @s m.b_lvl matches 100.. run advancement grant @s only metiers:b/niveau_100
execute if entity @s[tag=metiers.sk.f1] run advancement grant @s only metiers:f/competence_1
execute if entity @s[tag=metiers.sk.f2] run advancement grant @s only metiers:f/competence_2
execute if entity @s[tag=metiers.sk.f3] run advancement grant @s only metiers:f/competence_3
execute if entity @s[tag=metiers.sk.f4] run advancement grant @s only metiers:f/competence_4
execute if entity @s[tag=metiers.sk.f5] run advancement grant @s only metiers:f/competence_5
execute if entity @s[tag=metiers.sk.f6] run advancement grant @s only metiers:f/competence_6
execute if score @s m.f_lvl matches 10.. run advancement grant @s only metiers:f/niveau_10
execute if score @s m.f_lvl matches 20.. run advancement grant @s only metiers:f/niveau_20
execute if score @s m.f_lvl matches 30.. run advancement grant @s only metiers:f/niveau_30
execute if score @s m.f_lvl matches 40.. run advancement grant @s only metiers:f/niveau_40
execute if score @s m.f_lvl matches 50.. run advancement grant @s only metiers:f/niveau_50
execute if score @s m.f_lvl matches 60.. run advancement grant @s only metiers:f/niveau_60
execute if score @s m.f_lvl matches 70.. run advancement grant @s only metiers:f/niveau_70
execute if score @s m.f_lvl matches 80.. run advancement grant @s only metiers:f/niveau_80
execute if score @s m.f_lvl matches 90.. run advancement grant @s only metiers:f/niveau_90
execute if score @s m.f_lvl matches 100.. run advancement grant @s only metiers:f/niveau_100
execute if entity @s[tag=metiers.sk.m1] run advancement grant @s only metiers:m/competence_1
execute if entity @s[tag=metiers.sk.m2] run advancement grant @s only metiers:m/competence_2
execute if entity @s[tag=metiers.sk.m3] run advancement grant @s only metiers:m/competence_3
execute if entity @s[tag=metiers.sk.m4] run advancement grant @s only metiers:m/competence_4
execute if entity @s[tag=metiers.sk.m5] run advancement grant @s only metiers:m/competence_5
execute if entity @s[tag=metiers.sk.m6] run advancement grant @s only metiers:m/competence_6
execute if score @s m.m_lvl matches 10.. run advancement grant @s only metiers:m/niveau_10
execute if score @s m.m_lvl matches 20.. run advancement grant @s only metiers:m/niveau_20
execute if score @s m.m_lvl matches 30.. run advancement grant @s only metiers:m/niveau_30
execute if score @s m.m_lvl matches 40.. run advancement grant @s only metiers:m/niveau_40
execute if score @s m.m_lvl matches 50.. run advancement grant @s only metiers:m/niveau_50
execute if score @s m.m_lvl matches 60.. run advancement grant @s only metiers:m/niveau_60
execute if score @s m.m_lvl matches 70.. run advancement grant @s only metiers:m/niveau_70
execute if score @s m.m_lvl matches 80.. run advancement grant @s only metiers:m/niveau_80
execute if score @s m.m_lvl matches 90.. run advancement grant @s only metiers:m/niveau_90
execute if score @s m.m_lvl matches 100.. run advancement grant @s only metiers:m/niveau_100
execute if entity @s[tag=metiers.sk.c1] run advancement grant @s only metiers:c/competence_1
execute if entity @s[tag=metiers.sk.c2] run advancement grant @s only metiers:c/competence_2
execute if entity @s[tag=metiers.sk.c3] run advancement grant @s only metiers:c/competence_3
execute if entity @s[tag=metiers.sk.c4] run advancement grant @s only metiers:c/competence_4
execute if entity @s[tag=metiers.sk.c5] run advancement grant @s only metiers:c/competence_5
execute if entity @s[tag=metiers.sk.c6] run advancement grant @s only metiers:c/competence_6
execute if score @s m.c_lvl matches 10.. run advancement grant @s only metiers:c/niveau_10
execute if score @s m.c_lvl matches 20.. run advancement grant @s only metiers:c/niveau_20
execute if score @s m.c_lvl matches 30.. run advancement grant @s only metiers:c/niveau_30
execute if score @s m.c_lvl matches 40.. run advancement grant @s only metiers:c/niveau_40
execute if score @s m.c_lvl matches 50.. run advancement grant @s only metiers:c/niveau_50
execute if score @s m.c_lvl matches 60.. run advancement grant @s only metiers:c/niveau_60
execute if score @s m.c_lvl matches 70.. run advancement grant @s only metiers:c/niveau_70
execute if score @s m.c_lvl matches 80.. run advancement grant @s only metiers:c/niveau_80
execute if score @s m.c_lvl matches 90.. run advancement grant @s only metiers:c/niveau_90
execute if score @s m.c_lvl matches 100.. run advancement grant @s only metiers:c/niveau_100
execute if entity @s[tag=metiers.sk.p1] run advancement grant @s only metiers:p/competence_1
execute if entity @s[tag=metiers.sk.p2] run advancement grant @s only metiers:p/competence_2
execute if entity @s[tag=metiers.sk.p3] run advancement grant @s only metiers:p/competence_3
execute if entity @s[tag=metiers.sk.p4] run advancement grant @s only metiers:p/competence_4
execute if entity @s[tag=metiers.sk.p5] run advancement grant @s only metiers:p/competence_5
execute if entity @s[tag=metiers.sk.p6] run advancement grant @s only metiers:p/competence_6
execute if score @s m.p_lvl matches 10.. run advancement grant @s only metiers:p/niveau_10
execute if score @s m.p_lvl matches 20.. run advancement grant @s only metiers:p/niveau_20
execute if score @s m.p_lvl matches 30.. run advancement grant @s only metiers:p/niveau_30
execute if score @s m.p_lvl matches 40.. run advancement grant @s only metiers:p/niveau_40
execute if score @s m.p_lvl matches 50.. run advancement grant @s only metiers:p/niveau_50
execute if score @s m.p_lvl matches 60.. run advancement grant @s only metiers:p/niveau_60
execute if score @s m.p_lvl matches 70.. run advancement grant @s only metiers:p/niveau_70
execute if score @s m.p_lvl matches 80.. run advancement grant @s only metiers:p/niveau_80
execute if score @s m.p_lvl matches 90.. run advancement grant @s only metiers:p/niveau_90
execute if score @s m.p_lvl matches 100.. run advancement grant @s only metiers:p/niveau_100
