# Anti-triche : poser ou jeter l'objet retire l'XP gagnée
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.wheat matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.wheat matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:wheat 2
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.wheat matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.wheat matches 1.. if score #r m.tmp matches ..3 run give @s minecraft:golden_apple 1
scoreboard players operation @s m.tmp = @s s.f.pu.wheat
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.f_bal += @s m.tmp
scoreboard players set @s s.f.pu.wheat 0
scoreboard players operation @s m.tmp = @s s.f.dr.wheat
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.f_bal -= @s m.tmp
scoreboard players set @s s.f.dr.wheat 0
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.carrot matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.carrot matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:carrot 2
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.carrot matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.carrot matches 1.. if score #r m.tmp matches ..3 run give @s minecraft:golden_apple 1
scoreboard players operation @s m.f_bal += @s s.f.pu.carrot
scoreboard players set @s s.f.pu.carrot 0
scoreboard players operation @s m.f_bal -= @s s.f.dr.carrot
scoreboard players set @s s.f.dr.carrot 0
scoreboard players operation @s m.f_bal -= @s s.f.us.carrot
scoreboard players set @s s.f.us.carrot 0
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.potato matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.potato matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:potato 2
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.potato matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.potato matches 1.. if score #r m.tmp matches ..3 run give @s minecraft:golden_apple 1
scoreboard players operation @s m.f_bal += @s s.f.pu.potato
scoreboard players set @s s.f.pu.potato 0
scoreboard players operation @s m.f_bal -= @s s.f.dr.potato
scoreboard players set @s s.f.dr.potato 0
scoreboard players operation @s m.f_bal -= @s s.f.us.potato
scoreboard players set @s s.f.us.potato 0
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.beetroot matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.beetroot matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:beetroot 2
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.beetroot matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.beetroot matches 1.. if score #r m.tmp matches ..3 run give @s minecraft:golden_apple 1
scoreboard players operation @s m.tmp = @s s.f.pu.beetroot
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.f_bal += @s m.tmp
scoreboard players set @s s.f.pu.beetroot 0
scoreboard players operation @s m.tmp = @s s.f.dr.beetroot
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.f_bal -= @s m.tmp
scoreboard players set @s s.f.dr.beetroot 0
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.melon_slice matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.melon_slice matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:melon_slice 2
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.melon_slice matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.melon_slice matches 1.. if score #r m.tmp matches ..3 run give @s minecraft:golden_apple 1
scoreboard players operation @s m.f_bal += @s s.f.pu.melon_slice
scoreboard players set @s s.f.pu.melon_slice 0
scoreboard players operation @s m.f_bal -= @s s.f.dr.melon_slice
scoreboard players set @s s.f.dr.melon_slice 0
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.pumpkin matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.pumpkin matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:pumpkin 2
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.pumpkin matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.pumpkin matches 1.. if score #r m.tmp matches ..3 run give @s minecraft:golden_apple 1
scoreboard players operation @s m.tmp = @s s.f.pu.pumpkin
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.f_bal += @s m.tmp
scoreboard players set @s s.f.pu.pumpkin 0
scoreboard players operation @s m.tmp = @s s.f.dr.pumpkin
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.f_bal -= @s m.tmp
scoreboard players set @s s.f.dr.pumpkin 0
scoreboard players operation @s m.tmp = @s s.f.us.pumpkin
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.f_bal -= @s m.tmp
scoreboard players set @s s.f.us.pumpkin 0
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.nether_wart matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.nether_wart matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:nether_wart 2
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.nether_wart matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.nether_wart matches 1.. if score #r m.tmp matches ..3 run give @s minecraft:golden_apple 1
scoreboard players operation @s m.f_bal += @s s.f.pu.nether_wart
scoreboard players set @s s.f.pu.nether_wart 0
scoreboard players operation @s m.f_bal -= @s s.f.dr.nether_wart
scoreboard players set @s s.f.dr.nether_wart 0
scoreboard players operation @s m.f_bal -= @s s.f.us.nether_wart
scoreboard players set @s s.f.us.nether_wart 0
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.cocoa_beans matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.cocoa_beans matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:cocoa_beans 2
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.cocoa_beans matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.cocoa_beans matches 1.. if score #r m.tmp matches ..3 run give @s minecraft:golden_apple 1
scoreboard players operation @s m.f_bal += @s s.f.pu.cocoa_beans
scoreboard players set @s s.f.pu.cocoa_beans 0
scoreboard players operation @s m.f_bal -= @s s.f.dr.cocoa_beans
scoreboard players set @s s.f.dr.cocoa_beans 0
scoreboard players operation @s m.f_bal -= @s s.f.us.cocoa_beans
scoreboard players set @s s.f.us.cocoa_beans 0
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.sweet_berries matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.sweet_berries matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:sweet_berries 2
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.sweet_berries matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.sweet_berries matches 1.. if score #r m.tmp matches ..3 run give @s minecraft:golden_apple 1
scoreboard players operation @s m.f_bal += @s s.f.pu.sweet_berries
scoreboard players set @s s.f.pu.sweet_berries 0
scoreboard players operation @s m.f_bal -= @s s.f.dr.sweet_berries
scoreboard players set @s s.f.dr.sweet_berries 0
scoreboard players operation @s m.f_bal -= @s s.f.us.sweet_berries
scoreboard players set @s s.f.us.sweet_berries 0
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.sugar_cane matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f2] if score @s s.f.pu.sugar_cane matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:sugar_cane 2
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.sugar_cane matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f4] if score @s s.f.pu.sugar_cane matches 1.. if score #r m.tmp matches ..3 run give @s minecraft:golden_apple 1
scoreboard players operation @s m.f_bal += @s s.f.pu.sugar_cane
scoreboard players set @s s.f.pu.sugar_cane 0
scoreboard players operation @s m.f_bal -= @s s.f.dr.sugar_cane
scoreboard players set @s s.f.dr.sugar_cane 0
scoreboard players operation @s m.f_bal -= @s s.f.us.sugar_cane
scoreboard players set @s s.f.us.sugar_cane 0
execute if score @s m.f_bal matches 1.. run function metiers:f/gain
