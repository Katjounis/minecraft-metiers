scoreboard players operation @s m.b0 = @s m.f_bal
# Anti-triche : poser ou jeter l'objet retire l'XP gagnée
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.pu.wheat matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.pu.wheat matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:wheat 2
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.pu.wheat matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.pu.wheat matches 1.. if score #r m.tmp matches ..2 run give @s minecraft:golden_carrot 1
scoreboard players operation @s m.tmp = @s s.f.pu.wheat
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.f_raw += @s m.tmp
scoreboard players set @s s.f.pu.wheat 0
scoreboard players operation @s m.tmp = @s s.f.dr.wheat
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.f_raw -= @s m.tmp
scoreboard players set @s s.f.dr.wheat 0
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.pu.carrot matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.pu.carrot matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:carrot 2
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.pu.carrot matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.pu.carrot matches 1.. if score #r m.tmp matches ..2 run give @s minecraft:golden_carrot 1
scoreboard players operation @s m.f_raw += @s s.f.pu.carrot
scoreboard players set @s s.f.pu.carrot 0
scoreboard players operation @s m.f_raw -= @s s.f.dr.carrot
scoreboard players set @s s.f.dr.carrot 0
scoreboard players operation @s m.f_raw -= @s s.f.us.carrot
scoreboard players set @s s.f.us.carrot 0
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.pu.potato matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.pu.potato matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:potato 2
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.pu.potato matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.pu.potato matches 1.. if score #r m.tmp matches ..2 run give @s minecraft:golden_carrot 1
scoreboard players operation @s m.f_raw += @s s.f.pu.potato
scoreboard players set @s s.f.pu.potato 0
scoreboard players operation @s m.f_raw -= @s s.f.dr.potato
scoreboard players set @s s.f.dr.potato 0
scoreboard players operation @s m.f_raw -= @s s.f.us.potato
scoreboard players set @s s.f.us.potato 0
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.pu.beetroot matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.pu.beetroot matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:beetroot 2
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.pu.beetroot matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.pu.beetroot matches 1.. if score #r m.tmp matches ..2 run give @s minecraft:golden_carrot 1
scoreboard players operation @s m.tmp = @s s.f.pu.beetroot
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.f_raw += @s m.tmp
scoreboard players set @s s.f.pu.beetroot 0
scoreboard players operation @s m.tmp = @s s.f.dr.beetroot
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.f_raw -= @s m.tmp
scoreboard players set @s s.f.dr.beetroot 0
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.pu.nether_wart matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.pu.nether_wart matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:nether_wart 2
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.pu.nether_wart matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.pu.nether_wart matches 1.. if score #r m.tmp matches ..2 run give @s minecraft:golden_carrot 1
scoreboard players operation @s m.f_raw += @s s.f.pu.nether_wart
scoreboard players set @s s.f.pu.nether_wart 0
scoreboard players operation @s m.f_raw -= @s s.f.dr.nether_wart
scoreboard players set @s s.f.dr.nether_wart 0
scoreboard players operation @s m.f_raw -= @s s.f.us.nether_wart
scoreboard players set @s s.f.us.nether_wart 0
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.pu.sweet_berries matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.pu.sweet_berries matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:sweet_berries 2
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.pu.sweet_berries matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.pu.sweet_berries matches 1.. if score #r m.tmp matches ..2 run give @s minecraft:golden_carrot 1
scoreboard players operation @s m.f_raw += @s s.f.pu.sweet_berries
scoreboard players set @s s.f.pu.sweet_berries 0
scoreboard players operation @s m.f_raw -= @s s.f.dr.sweet_berries
scoreboard players set @s s.f.dr.sweet_berries 0
scoreboard players operation @s m.f_raw -= @s s.f.us.sweet_berries
scoreboard players set @s s.f.us.sweet_berries 0
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.pu.glow_berries matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.pu.glow_berries matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:glow_berries 2
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.pu.glow_berries matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.pu.glow_berries matches 1.. if score #r m.tmp matches ..2 run give @s minecraft:golden_carrot 1
scoreboard players operation @s m.f_raw += @s s.f.pu.glow_berries
scoreboard players set @s s.f.pu.glow_berries 0
scoreboard players operation @s m.f_raw -= @s s.f.dr.glow_berries
scoreboard players set @s s.f.dr.glow_berries 0
scoreboard players operation @s m.f_raw -= @s s.f.us.glow_berries
scoreboard players set @s s.f.us.glow_berries 0
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.mi.melon matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.mi.melon matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:melon_slice 2
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.mi.melon matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.mi.melon matches 1.. if score #r m.tmp matches ..2 run give @s minecraft:glistering_melon_slice 1
scoreboard players operation @s m.tmp = @s s.f.mi.melon
scoreboard players operation @s m.tmp *= #4 m.const
scoreboard players operation @s m.f_raw += @s m.tmp
scoreboard players set @s s.f.mi.melon 0
scoreboard players operation @s m.tmp = @s s.f.up.melon
scoreboard players operation @s m.tmp *= #4 m.const
scoreboard players operation @s m.f_raw -= @s m.tmp
scoreboard players set @s s.f.up.melon 0
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.mi.pumpkin matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.mi.pumpkin matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:pumpkin 2
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.mi.pumpkin matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.mi.pumpkin matches 1.. if score #r m.tmp matches ..2 run give @s minecraft:glistering_melon_slice 1
scoreboard players operation @s m.tmp = @s s.f.mi.pumpkin
scoreboard players operation @s m.tmp *= #4 m.const
scoreboard players operation @s m.f_raw += @s m.tmp
scoreboard players set @s s.f.mi.pumpkin 0
scoreboard players operation @s m.tmp = @s s.f.up.pumpkin
scoreboard players operation @s m.tmp *= #4 m.const
scoreboard players operation @s m.f_raw -= @s m.tmp
scoreboard players set @s s.f.up.pumpkin 0
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.mi.sugar_cane matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.mi.sugar_cane matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:sugar_cane 2
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.mi.sugar_cane matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.mi.sugar_cane matches 1.. if score #r m.tmp matches ..2 run give @s minecraft:glistering_melon_slice 1
scoreboard players operation @s m.tmp = @s s.f.mi.sugar_cane
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.f_raw += @s m.tmp
scoreboard players set @s s.f.mi.sugar_cane 0
scoreboard players operation @s m.tmp = @s s.f.up.sugar_cane
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.f_raw -= @s m.tmp
scoreboard players set @s s.f.up.sugar_cane 0
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.mi.cocoa matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.mi.cocoa matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:cocoa_beans 2
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.mi.cocoa matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.mi.cocoa matches 1.. if score #r m.tmp matches ..2 run give @s minecraft:glistering_melon_slice 1
scoreboard players operation @s m.tmp = @s s.f.mi.cocoa
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.f_raw += @s m.tmp
scoreboard players set @s s.f.mi.cocoa 0
scoreboard players operation @s m.tmp = @s s.f.up.cocoa
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.f_raw -= @s m.tmp
scoreboard players set @s s.f.up.cocoa 0
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.mi.cactus matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f1] if score @s s.f.mi.cactus matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:cactus 2
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.mi.cactus matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.f5] if score @s s.f.mi.cactus matches 1.. if score #r m.tmp matches ..2 run give @s minecraft:glistering_melon_slice 1
scoreboard players operation @s m.f_raw += @s s.f.mi.cactus
scoreboard players set @s s.f.mi.cactus 0
scoreboard players operation @s m.f_raw -= @s s.f.up.cactus
scoreboard players set @s s.f.up.cactus 0
execute if score @s m.f_raw matches 2.. run scoreboard players operation @s m.tmp = @s m.f_raw
execute if score @s m.f_raw matches 2.. run scoreboard players operation @s m.tmp /= #2 m.const
execute if score @s m.f_raw matches 2.. run scoreboard players operation @s m.f_bal += @s m.tmp
execute if score @s m.f_raw matches 2.. run scoreboard players operation @s m.tmp *= #2 m.const
execute if score @s m.f_raw matches 2.. run scoreboard players operation @s m.f_raw -= @s m.tmp
scoreboard players operation @s m.tmp = @s m.f_bal
scoreboard players operation @s m.tmp -= @s m.b0
execute if score @s m.f_bal matches 1.. run function metiers:f/gain
