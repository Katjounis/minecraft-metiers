execute if entity @s[tag=metiers.sk.f2] run return run function metiers:f/arbre
function metiers:f/points
execute unless entity @s[tag=metiers.sk.f1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Pas léger.","color":"red"}]
execute unless entity @s[tag=metiers.sk.f1] run return run function metiers:f/arbre
execute if score @s m.tmp matches ..7 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (8 requis).","color":"red"}]
execute if score @s m.tmp matches ..7 run return run function metiers:f/arbre
scoreboard players add @s m.f_spent 8
tag @s add metiers.sk.f2
advancement grant @s only metiers:f/competence_2
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Main verte","color":"green","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:f/arbre
