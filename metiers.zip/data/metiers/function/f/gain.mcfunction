scoreboard players operation @s m.gain = @s m.f_bal
scoreboard players set @s m.f_bal 0
scoreboard players operation @s m.tmp = @s m.gain
scoreboard players operation @s m.tmp *= @s m.f_pr
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.gain += @s m.tmp
execute if score #job m.heure matches 2 run scoreboard players operation @s m.gain *= #2 m.const
execute if score @s m.f_lvl matches 100.. run return 0
scoreboard players operation @s m.f_xp += @s m.gain
function metiers:f/check
title @s actionbar [{"text":"+","color":"green"},{"score":{"name":"@s","objective":"m.gain"},"color":"green"},{"text":" XP Fermier","color":"green"},{"text":"  |  niv ","color":"gray"},{"score":{"name":"@s","objective":"m.f_lvl"},"color":"white"},{"text":"  (","color":"gray"},{"score":{"name":"@s","objective":"m.f_xp"},"color":"white"},{"text":"/","color":"gray"},{"score":{"name":"@s","objective":"m.f_need"},"color":"white"},{"text":")","color":"gray"}]
