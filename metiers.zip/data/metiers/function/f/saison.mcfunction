execute unless entity @s[tag=metiers.sk.f6] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut la compétence Saison des moissons.","color":"red"}]
execute if score @s m.saison matches 1.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Saison des moissons déjà utilisée : reviens dans un jour de jeu (20 min).","color":"red"}]
scoreboard players set @s m.saison 2400
fill ~-12 ~-3 ~-12 ~12 ~3 ~12 minecraft:wheat[age=7] replace minecraft:wheat
fill ~-12 ~-3 ~-12 ~12 ~3 ~12 minecraft:carrots[age=7] replace minecraft:carrots
fill ~-12 ~-3 ~-12 ~12 ~3 ~12 minecraft:potatoes[age=7] replace minecraft:potatoes
fill ~-12 ~-3 ~-12 ~12 ~3 ~12 minecraft:beetroots[age=3] replace minecraft:beetroots
fill ~-12 ~-3 ~-12 ~12 ~3 ~12 minecraft:nether_wart[age=3] replace minecraft:nether_wart
fill ~-12 ~-3 ~-12 ~12 ~3 ~12 minecraft:sweet_berry_bush[age=3] replace minecraft:sweet_berry_bush
particle minecraft:happy_villager ~ ~1 ~ 8 1 8 0 200
playsound minecraft:block.amethyst_block.chime master @a ~ ~ ~ 1 0.8
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"La saison des moissons fait mûrir toutes les cultures autour de toi.","color":"green"}]
