execute if entity @s[tag=metiers.sk.f1] run return run function metiers:f/arbre
execute unless score @s m.f_lvl matches 5.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 5 en Fermier.","color":"red"}]
execute unless score @s m.f_lvl matches 5.. run return run function metiers:f/arbre
function metiers:f/points
execute if score @s m.tmp matches ..5 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (6 requis).","color":"red"}]
execute if score @s m.tmp matches ..5 run return run function metiers:f/arbre
scoreboard players add @s m.f_spent 6
tag @s add metiers.sk.f1
advancement grant @s only metiers:f/competence_1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Main verte","color":"green","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:f/arbre
