scoreboard players set #pas m.tmp 0
$execute anchored eyes positioned ^ ^ ^0.3 run function metiers:f/semer_rayon {item:"$(item)",bloc:"$(bloc)"}
