execute if score @s s.seed matches 1.. run function metiers:f/semer {item:"wheat_seeds",bloc:"wheat"}
execute if score @s s.seedc matches 1.. run function metiers:f/semer {item:"carrot",bloc:"carrots"}
execute if score @s s.seedp matches 1.. run function metiers:f/semer {item:"potato",bloc:"potatoes"}
execute if score @s s.seedb matches 1.. run function metiers:f/semer {item:"beetroot_seeds",bloc:"beetroots"}
scoreboard players set @s s.seed 0
scoreboard players set @s s.seedc 0
scoreboard players set @s s.seedp 0
scoreboard players set @s s.seedb 0
