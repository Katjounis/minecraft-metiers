execute if entity @s[tag=metiers.sk.f6] run return run function metiers:f/arbre
function metiers:f/points
execute unless entity @s[tag=metiers.sk.f4,tag=metiers.sk.f5] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Main d'or + Aura de croissance.","color":"red"}]
execute unless entity @s[tag=metiers.sk.f4,tag=metiers.sk.f5] run return run function metiers:f/arbre
execute if score @s m.tmp matches ..31 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (32 requis).","color":"red"}]
execute if score @s m.tmp matches ..31 run return run function metiers:f/arbre
scoreboard players add @s m.f_spent 32
tag @s add metiers.sk.f6
advancement grant @s only metiers:f/competence_6
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Mère Nature","color":"green","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:f/arbre
