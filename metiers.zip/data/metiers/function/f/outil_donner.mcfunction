clear @s *[minecraft:custom_data~{metiers_outil:"f"}]
scoreboard players add @s m.f_ser 1
execute store result storage metiers:tmp o int 1 run scoreboard players get @s m.id
execute store result storage metiers:tmp s int 1 run scoreboard players get @s m.f_ser
function metiers:f/outil_donner_m with storage metiers:tmp
playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.6 1.4
