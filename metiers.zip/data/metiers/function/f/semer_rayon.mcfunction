scoreboard players add #pas m.tmp 1
$execute if block ~ ~ ~ minecraft:$(bloc) align xyz positioned ~0.5 ~ ~0.5 run return run function metiers:f/semer_zone {item:"$(item)",bloc:"$(bloc)"}
$execute if score #pas m.tmp matches ..55 positioned ^ ^ ^0.1 run function metiers:f/semer_rayon {item:"$(item)",bloc:"$(bloc)"}
