scoreboard players operation @s m.f_need = @s m.f_lvl
scoreboard players operation @s m.f_need *= #10 m.const
scoreboard players operation @s m.f_need += #40 m.const
execute if score @s m.f_lvl matches ..99 if score @s m.f_xp >= @s m.f_need run function metiers:f/levelup
