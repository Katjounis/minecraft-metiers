scoreboard players operation @s m.tmp = @s m.f_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.f_out >= @s m.tmp run return 0
scoreboard players operation @s m.f_out = @s m.tmp
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" fait évoluer son outil de Fermier !","color":"green","bold":true}]
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"f"}] run return run function metiers:f/outil_donner
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"f"}] run return run function metiers:f/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton outil de Fermier a évolué : récupère-le avec G, Fermier, « Récupérer mon outil ».","color":"yellow"}]
