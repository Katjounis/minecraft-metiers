execute if entity @s[tag=metiers.sk.f5] run return run function metiers:f/arbre
function metiers:f/points
execute unless entity @s[tag=metiers.sk.f3] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Estomac solide.","color":"red"}]
execute unless entity @s[tag=metiers.sk.f3] run return run function metiers:f/arbre
execute if score @s m.tmp matches ..23 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (24 requis).","color":"red"}]
execute if score @s m.tmp matches ..23 run return run function metiers:f/arbre
scoreboard players add @s m.f_spent 24
tag @s add metiers.sk.f5
advancement grant @s only metiers:f/competence_5
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Aura de croissance","color":"green","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:f/arbre
