execute if score @s m.pref matches 2 run scoreboard players set @s m.trig 10
execute unless score @s m.pref matches 2 run scoreboard players set @s m.trig 12
function metiers:prefixe/choisir
function metiers:f/arbre
