$setblock ~ ~ ~ minecraft:$(bloc)
$clear @p minecraft:$(item) 1
