fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:wheat[age=7] replace minecraft:wheat
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:carrots[age=7] replace minecraft:carrots
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:potatoes[age=7] replace minecraft:potatoes
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:beetroots[age=3] replace minecraft:beetroots
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:nether_wart[age=3] replace minecraft:nether_wart
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 minecraft:sweet_berry_bush[age=3] replace minecraft:sweet_berry_bush
particle minecraft:happy_villager ~ ~0.5 ~ 3 0.5 3 0 40
playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1 1.2
