$function metiers:$(j)/ecran_$(k)
