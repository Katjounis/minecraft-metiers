tellraw @s {"text":"[Métiers] Version 11 : 9 métiers et Armure des Guildes (avec Éleveur, Enchanteur, Explorateur, Marchand)","color":"gold"}
