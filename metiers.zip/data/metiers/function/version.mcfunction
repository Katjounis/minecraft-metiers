tellraw @s {"text":"[Métiers] Version 24 : refonte (outils 11 paliers, Forge, skins, 5 boss, défis de la semaine et collectifs)","color":"gold"}
