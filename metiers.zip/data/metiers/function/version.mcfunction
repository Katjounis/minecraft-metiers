tellraw @s {"text":"[Métiers] Version 10 : 9 métiers (avec Éleveur, Enchanteur, Explorateur, Marchand)","color":"gold"}
