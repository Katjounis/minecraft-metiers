scoreboard players operation @s m.b0 = @s m.b_bal
# Anti-triche : poser ou jeter l'objet retire l'XP gagnée
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.oak_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:oak_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.oak_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.oak_log
scoreboard players set @s s.b.mi.oak_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.oak_log
scoreboard players set @s s.b.us.oak_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_oak_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_oak_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_oak_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_oak_log
scoreboard players set @s s.b.mi.stripped_oak_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_oak_log
scoreboard players set @s s.b.us.stripped_oak_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.oak_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.oak_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:oak_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.oak_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.oak_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.oak_wood
scoreboard players set @s s.b.mi.oak_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.oak_wood
scoreboard players set @s s.b.us.oak_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_oak_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_oak_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_oak_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_oak_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_oak_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_oak_wood
scoreboard players set @s s.b.mi.stripped_oak_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_oak_wood
scoreboard players set @s s.b.us.stripped_oak_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.spruce_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.spruce_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:spruce_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.spruce_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.spruce_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.spruce_log
scoreboard players set @s s.b.mi.spruce_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.spruce_log
scoreboard players set @s s.b.us.spruce_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_spruce_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_spruce_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_spruce_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_spruce_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_spruce_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_spruce_log
scoreboard players set @s s.b.mi.stripped_spruce_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_spruce_log
scoreboard players set @s s.b.us.stripped_spruce_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.spruce_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.spruce_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:spruce_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.spruce_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.spruce_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.spruce_wood
scoreboard players set @s s.b.mi.spruce_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.spruce_wood
scoreboard players set @s s.b.us.spruce_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_spruce_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_spruce_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_spruce_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_spruce_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_spruce_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_spruce_wood
scoreboard players set @s s.b.mi.stripped_spruce_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_spruce_wood
scoreboard players set @s s.b.us.stripped_spruce_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.birch_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.birch_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:birch_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.birch_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.birch_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.birch_log
scoreboard players set @s s.b.mi.birch_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.birch_log
scoreboard players set @s s.b.us.birch_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_birch_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_birch_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_birch_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_birch_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_birch_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_birch_log
scoreboard players set @s s.b.mi.stripped_birch_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_birch_log
scoreboard players set @s s.b.us.stripped_birch_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.birch_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.birch_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:birch_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.birch_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.birch_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.birch_wood
scoreboard players set @s s.b.mi.birch_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.birch_wood
scoreboard players set @s s.b.us.birch_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_birch_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_birch_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_birch_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_birch_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_birch_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_birch_wood
scoreboard players set @s s.b.mi.stripped_birch_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_birch_wood
scoreboard players set @s s.b.us.stripped_birch_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.jungle_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.jungle_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:jungle_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.jungle_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.jungle_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.jungle_log
scoreboard players set @s s.b.mi.jungle_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.jungle_log
scoreboard players set @s s.b.us.jungle_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_jungle_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_jungle_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_jungle_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_jungle_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_jungle_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_jungle_log
scoreboard players set @s s.b.mi.stripped_jungle_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_jungle_log
scoreboard players set @s s.b.us.stripped_jungle_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.jungle_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.jungle_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:jungle_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.jungle_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.jungle_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.jungle_wood
scoreboard players set @s s.b.mi.jungle_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.jungle_wood
scoreboard players set @s s.b.us.jungle_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_jungle_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_jungle_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_jungle_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_jungle_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_jungle_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_jungle_wood
scoreboard players set @s s.b.mi.stripped_jungle_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_jungle_wood
scoreboard players set @s s.b.us.stripped_jungle_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.acacia_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.acacia_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:acacia_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.acacia_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.acacia_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.acacia_log
scoreboard players set @s s.b.mi.acacia_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.acacia_log
scoreboard players set @s s.b.us.acacia_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_acacia_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_acacia_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_acacia_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_acacia_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_acacia_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_acacia_log
scoreboard players set @s s.b.mi.stripped_acacia_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_acacia_log
scoreboard players set @s s.b.us.stripped_acacia_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.acacia_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.acacia_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:acacia_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.acacia_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.acacia_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.acacia_wood
scoreboard players set @s s.b.mi.acacia_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.acacia_wood
scoreboard players set @s s.b.us.acacia_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_acacia_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_acacia_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_acacia_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_acacia_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_acacia_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_acacia_wood
scoreboard players set @s s.b.mi.stripped_acacia_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_acacia_wood
scoreboard players set @s s.b.us.stripped_acacia_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.dark_oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.dark_oak_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:dark_oak_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.dark_oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.dark_oak_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.dark_oak_log
scoreboard players set @s s.b.mi.dark_oak_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.dark_oak_log
scoreboard players set @s s.b.us.dark_oak_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_dark_oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_dark_oak_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_dark_oak_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_dark_oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_dark_oak_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_dark_oak_log
scoreboard players set @s s.b.mi.stripped_dark_oak_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_dark_oak_log
scoreboard players set @s s.b.us.stripped_dark_oak_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.dark_oak_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.dark_oak_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:dark_oak_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.dark_oak_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.dark_oak_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.dark_oak_wood
scoreboard players set @s s.b.mi.dark_oak_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.dark_oak_wood
scoreboard players set @s s.b.us.dark_oak_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_dark_oak_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_dark_oak_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_dark_oak_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_dark_oak_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_dark_oak_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_dark_oak_wood
scoreboard players set @s s.b.mi.stripped_dark_oak_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_dark_oak_wood
scoreboard players set @s s.b.us.stripped_dark_oak_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.mangrove_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.mangrove_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:mangrove_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.mangrove_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.mangrove_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.mangrove_log
scoreboard players set @s s.b.mi.mangrove_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.mangrove_log
scoreboard players set @s s.b.us.mangrove_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_mangrove_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_mangrove_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_mangrove_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_mangrove_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_mangrove_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_mangrove_log
scoreboard players set @s s.b.mi.stripped_mangrove_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_mangrove_log
scoreboard players set @s s.b.us.stripped_mangrove_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.mangrove_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.mangrove_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:mangrove_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.mangrove_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.mangrove_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.mangrove_wood
scoreboard players set @s s.b.mi.mangrove_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.mangrove_wood
scoreboard players set @s s.b.us.mangrove_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_mangrove_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_mangrove_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_mangrove_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_mangrove_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_mangrove_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_mangrove_wood
scoreboard players set @s s.b.mi.stripped_mangrove_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_mangrove_wood
scoreboard players set @s s.b.us.stripped_mangrove_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.cherry_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.cherry_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:cherry_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.cherry_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.cherry_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.cherry_log
scoreboard players set @s s.b.mi.cherry_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.cherry_log
scoreboard players set @s s.b.us.cherry_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_cherry_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_cherry_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_cherry_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_cherry_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_cherry_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_cherry_log
scoreboard players set @s s.b.mi.stripped_cherry_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_cherry_log
scoreboard players set @s s.b.us.stripped_cherry_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.cherry_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.cherry_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:cherry_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.cherry_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.cherry_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.cherry_wood
scoreboard players set @s s.b.mi.cherry_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.cherry_wood
scoreboard players set @s s.b.us.cherry_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_cherry_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_cherry_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_cherry_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_cherry_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_cherry_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_cherry_wood
scoreboard players set @s s.b.mi.stripped_cherry_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_cherry_wood
scoreboard players set @s s.b.us.stripped_cherry_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.pale_oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.pale_oak_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:pale_oak_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.pale_oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.pale_oak_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.pale_oak_log
scoreboard players set @s s.b.mi.pale_oak_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.pale_oak_log
scoreboard players set @s s.b.us.pale_oak_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_pale_oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_pale_oak_log matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_pale_oak_log 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_pale_oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_pale_oak_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_pale_oak_log
scoreboard players set @s s.b.mi.stripped_pale_oak_log 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_pale_oak_log
scoreboard players set @s s.b.us.stripped_pale_oak_log 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.pale_oak_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.pale_oak_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:pale_oak_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.pale_oak_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.pale_oak_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.pale_oak_wood
scoreboard players set @s s.b.mi.pale_oak_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.pale_oak_wood
scoreboard players set @s s.b.us.pale_oak_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_pale_oak_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_pale_oak_wood matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_pale_oak_wood 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_pale_oak_wood matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_pale_oak_wood matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_pale_oak_wood
scoreboard players set @s s.b.mi.stripped_pale_oak_wood 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_pale_oak_wood
scoreboard players set @s s.b.us.stripped_pale_oak_wood 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.crimson_stem matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.crimson_stem matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:crimson_stem 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.crimson_stem matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.crimson_stem matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.crimson_stem
scoreboard players set @s s.b.mi.crimson_stem 0
scoreboard players operation @s m.b_bal -= @s s.b.us.crimson_stem
scoreboard players set @s s.b.us.crimson_stem 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_crimson_stem matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_crimson_stem matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_crimson_stem 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_crimson_stem matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_crimson_stem matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_crimson_stem
scoreboard players set @s s.b.mi.stripped_crimson_stem 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_crimson_stem
scoreboard players set @s s.b.us.stripped_crimson_stem 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.crimson_hyphae matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.crimson_hyphae matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:crimson_hyphae 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.crimson_hyphae matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.crimson_hyphae matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.crimson_hyphae
scoreboard players set @s s.b.mi.crimson_hyphae 0
scoreboard players operation @s m.b_bal -= @s s.b.us.crimson_hyphae
scoreboard players set @s s.b.us.crimson_hyphae 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_crimson_hyphae matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_crimson_hyphae matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_crimson_hyphae 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_crimson_hyphae matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_crimson_hyphae matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_crimson_hyphae
scoreboard players set @s s.b.mi.stripped_crimson_hyphae 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_crimson_hyphae
scoreboard players set @s s.b.us.stripped_crimson_hyphae 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.warped_stem matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.warped_stem matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:warped_stem 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.warped_stem matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.warped_stem matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.warped_stem
scoreboard players set @s s.b.mi.warped_stem 0
scoreboard players operation @s m.b_bal -= @s s.b.us.warped_stem
scoreboard players set @s s.b.us.warped_stem 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_warped_stem matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_warped_stem matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_warped_stem 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_warped_stem matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_warped_stem matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_warped_stem
scoreboard players set @s s.b.mi.stripped_warped_stem 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_warped_stem
scoreboard players set @s s.b.us.stripped_warped_stem 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.warped_hyphae matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.warped_hyphae matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:warped_hyphae 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.warped_hyphae matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.warped_hyphae matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.warped_hyphae
scoreboard players set @s s.b.mi.warped_hyphae 0
scoreboard players operation @s m.b_bal -= @s s.b.us.warped_hyphae
scoreboard players set @s s.b.us.warped_hyphae 0
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_warped_hyphae matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b1] if score @s s.b.mi.stripped_warped_hyphae matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:stripped_warped_hyphae 1
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_warped_hyphae matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b5] if score @s s.b.mi.stripped_warped_hyphae matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:charcoal 1
scoreboard players operation @s m.b_bal += @s s.b.mi.stripped_warped_hyphae
scoreboard players set @s s.b.mi.stripped_warped_hyphae 0
scoreboard players operation @s m.b_bal -= @s s.b.us.stripped_warped_hyphae
scoreboard players set @s s.b.us.stripped_warped_hyphae 0
scoreboard players operation @s m.tmp = @s m.b_bal
scoreboard players operation @s m.tmp -= @s m.b0
execute if score @s m.b_bal matches 1.. run function metiers:b/gain
