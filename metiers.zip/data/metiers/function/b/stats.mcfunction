# Anti-triche : poser ou jeter l'objet retire l'XP gagnée
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.oak_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:apple 1
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.oak_log matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:oak_log 1
scoreboard players operation @s m.tmp = @s s.b.mi.oak_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal += @s m.tmp
scoreboard players set @s s.b.mi.oak_log 0
scoreboard players operation @s m.tmp = @s s.b.us.oak_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal -= @s m.tmp
scoreboard players set @s s.b.us.oak_log 0
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.spruce_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.spruce_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:apple 1
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.spruce_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.spruce_log matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:spruce_log 1
scoreboard players operation @s m.tmp = @s s.b.mi.spruce_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal += @s m.tmp
scoreboard players set @s s.b.mi.spruce_log 0
scoreboard players operation @s m.tmp = @s s.b.us.spruce_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal -= @s m.tmp
scoreboard players set @s s.b.us.spruce_log 0
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.birch_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.birch_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:apple 1
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.birch_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.birch_log matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:birch_log 1
scoreboard players operation @s m.tmp = @s s.b.mi.birch_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal += @s m.tmp
scoreboard players set @s s.b.mi.birch_log 0
scoreboard players operation @s m.tmp = @s s.b.us.birch_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal -= @s m.tmp
scoreboard players set @s s.b.us.birch_log 0
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.jungle_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.jungle_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:apple 1
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.jungle_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.jungle_log matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:jungle_log 1
scoreboard players operation @s m.tmp = @s s.b.mi.jungle_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal += @s m.tmp
scoreboard players set @s s.b.mi.jungle_log 0
scoreboard players operation @s m.tmp = @s s.b.us.jungle_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal -= @s m.tmp
scoreboard players set @s s.b.us.jungle_log 0
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.acacia_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.acacia_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:apple 1
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.acacia_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.acacia_log matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:acacia_log 1
scoreboard players operation @s m.tmp = @s s.b.mi.acacia_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal += @s m.tmp
scoreboard players set @s s.b.mi.acacia_log 0
scoreboard players operation @s m.tmp = @s s.b.us.acacia_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal -= @s m.tmp
scoreboard players set @s s.b.us.acacia_log 0
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.dark_oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.dark_oak_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:apple 1
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.dark_oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.dark_oak_log matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:dark_oak_log 1
scoreboard players operation @s m.tmp = @s s.b.mi.dark_oak_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal += @s m.tmp
scoreboard players set @s s.b.mi.dark_oak_log 0
scoreboard players operation @s m.tmp = @s s.b.us.dark_oak_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal -= @s m.tmp
scoreboard players set @s s.b.us.dark_oak_log 0
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.mangrove_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.mangrove_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:apple 1
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.mangrove_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.mangrove_log matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:mangrove_log 1
scoreboard players operation @s m.tmp = @s s.b.mi.mangrove_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal += @s m.tmp
scoreboard players set @s s.b.mi.mangrove_log 0
scoreboard players operation @s m.tmp = @s s.b.us.mangrove_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal -= @s m.tmp
scoreboard players set @s s.b.us.mangrove_log 0
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.cherry_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.cherry_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:apple 1
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.cherry_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.cherry_log matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:cherry_log 1
scoreboard players operation @s m.tmp = @s s.b.mi.cherry_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal += @s m.tmp
scoreboard players set @s s.b.mi.cherry_log 0
scoreboard players operation @s m.tmp = @s s.b.us.cherry_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal -= @s m.tmp
scoreboard players set @s s.b.us.cherry_log 0
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.pale_oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.pale_oak_log matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:apple 1
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.pale_oak_log matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.pale_oak_log matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:pale_oak_log 1
scoreboard players operation @s m.tmp = @s s.b.mi.pale_oak_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal += @s m.tmp
scoreboard players set @s s.b.mi.pale_oak_log 0
scoreboard players operation @s m.tmp = @s s.b.us.pale_oak_log
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal -= @s m.tmp
scoreboard players set @s s.b.us.pale_oak_log 0
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.crimson_stem matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.crimson_stem matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:apple 1
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.crimson_stem matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.crimson_stem matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:crimson_stem 1
scoreboard players operation @s m.tmp = @s s.b.mi.crimson_stem
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal += @s m.tmp
scoreboard players set @s s.b.mi.crimson_stem 0
scoreboard players operation @s m.tmp = @s s.b.us.crimson_stem
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal -= @s m.tmp
scoreboard players set @s s.b.us.crimson_stem 0
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.warped_stem matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b2] if score @s s.b.mi.warped_stem matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:apple 1
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.warped_stem matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.b3] if score @s s.b.mi.warped_stem matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:warped_stem 1
scoreboard players operation @s m.tmp = @s s.b.mi.warped_stem
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal += @s m.tmp
scoreboard players set @s s.b.mi.warped_stem 0
scoreboard players operation @s m.tmp = @s s.b.us.warped_stem
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal -= @s m.tmp
scoreboard players set @s s.b.us.warped_stem 0
execute if score @s m.b_bal matches 1.. run function metiers:b/gain
