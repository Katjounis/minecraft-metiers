scoreboard players set #sum m.tmp 0
scoreboard players operation #sum m.tmp += @s a.oak_log
scoreboard players operation #sum m.tmp += @s a.spruce_log
scoreboard players operation #sum m.tmp += @s a.birch_log
scoreboard players operation #sum m.tmp += @s a.jungle_log
scoreboard players operation #sum m.tmp += @s a.acacia_log
scoreboard players operation #sum m.tmp += @s a.dark_oak_log
scoreboard players operation #sum m.tmp += @s a.mangrove_log
scoreboard players operation #sum m.tmp += @s a.cherry_log
scoreboard players operation #sum m.tmp += @s a.pale_oak_log
scoreboard players operation #sum m.tmp += @s a.crimson_stem
scoreboard players operation #sum m.tmp += @s a.warped_stem
scoreboard players set @s a.oak_log 0
scoreboard players set @s a.spruce_log 0
scoreboard players set @s a.birch_log 0
scoreboard players set @s a.jungle_log 0
scoreboard players set @s a.acacia_log 0
scoreboard players set @s a.dark_oak_log 0
scoreboard players set @s a.mangrove_log 0
scoreboard players set @s a.cherry_log 0
scoreboard players set @s a.pale_oak_log 0
scoreboard players set @s a.crimson_stem 0
scoreboard players set @s a.warped_stem 0
execute if score #sum m.tmp matches 1.. if score @s a.sneak matches 1.. if items entity @s weapon.mainhand #minecraft:axes run function metiers:b/abattage/debut
scoreboard players set @s a.sneak 0
