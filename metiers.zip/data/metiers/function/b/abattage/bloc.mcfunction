execute if score #n m.tmp matches 150.. run return 0
setblock ~ ~ ~ minecraft:air destroy
scoreboard players add #n m.tmp 1
execute positioned ~ ~1 ~ if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~1 ~ ~ if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~-1 ~ ~ if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~ ~ ~1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~ ~ ~-1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~ ~-1 ~ if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~1 ~1 ~ if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~-1 ~1 ~ if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~ ~1 ~1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~ ~1 ~-1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~1 ~1 ~1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~1 ~1 ~-1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~-1 ~1 ~1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~-1 ~1 ~-1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
