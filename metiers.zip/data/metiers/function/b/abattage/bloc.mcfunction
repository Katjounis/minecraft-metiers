execute if score #n m.tmp matches 150.. run return 0
setblock ~ ~ ~ minecraft:air destroy
execute if entity @s[tag=metiers.sk.b4] run fill ~-2 ~-2 ~-2 ~2 ~2 ~2 minecraft:air replace #minecraft:leaves[persistent=false] destroy
scoreboard players add #n m.tmp 1
execute positioned ~ ~1 ~ if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~1 ~ ~ if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~-1 ~ ~ if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~ ~ ~1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~ ~ ~-1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~ ~-1 ~ if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~1 ~1 ~ if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~-1 ~1 ~ if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~ ~1 ~1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~ ~1 ~-1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~1 ~1 ~1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~1 ~1 ~-1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~-1 ~1 ~1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
execute positioned ~-1 ~1 ~-1 if block ~ ~ ~ #minecraft:logs run function metiers:b/abattage/bloc
