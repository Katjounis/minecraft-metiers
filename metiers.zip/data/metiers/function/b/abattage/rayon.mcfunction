scoreboard players add #pas m.tmp 1
execute if block ~ ~ ~ minecraft:air if block ~ ~1 ~ #minecraft:logs positioned ~ ~1 ~ align xyz run return run function metiers:b/abattage/demarrer
execute if score #pas m.tmp matches ..55 positioned ^ ^ ^0.1 run function metiers:b/abattage/rayon
