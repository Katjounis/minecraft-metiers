scoreboard players set #n m.tmp 0
function metiers:b/abattage/bloc
playsound minecraft:block.wood.break master @a ~ ~ ~ 1 0.7
scoreboard players operation #n m.tmp *= #2 m.const
scoreboard players operation @s m.b_bal += #n m.tmp
