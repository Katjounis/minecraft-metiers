scoreboard players set #n m.tmp 0
function metiers:b/abattage/bloc
playsound minecraft:block.wood.break master @a ~ ~ ~ 1 0.7
scoreboard players operation @s m.b_bal += #n m.tmp
execute if entity @s[tag=metiers.sk.b6] if score #n m.tmp matches 4.. run effect give @s minecraft:strength 20 1 true
execute if entity @s[tag=metiers.sk.b6] if score #n m.tmp matches 4.. run effect give @s minecraft:haste 20 1 true
