scoreboard players set #pas m.tmp 0
execute anchored eyes positioned ^ ^ ^0.5 run function metiers:b/abattage/rayon
