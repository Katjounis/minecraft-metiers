scoreboard players set #pas m.tmp 0
execute anchored eyes positioned ^ ^ ^0.3 run function metiers:b/replante/rayon
