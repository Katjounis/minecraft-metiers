$setblock ~ ~ ~ minecraft:$(pousse)
particle minecraft:happy_villager ~ ~0.3 ~ 0.3 0.3 0.3 0 8
