execute if entity @s[tag=metiers.sk.b5] run return run function metiers:b/arbre
function metiers:b/points
execute unless entity @s[tag=metiers.sk.b3] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Double coupe.","color":"red"}]
execute unless entity @s[tag=metiers.sk.b3] run return run function metiers:b/arbre
execute if score @s m.tmp matches ..23 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (24 requis).","color":"red"}]
execute if score @s m.tmp matches ..23 run return run function metiers:b/arbre
scoreboard players add @s m.b_spent 24
tag @s add metiers.sk.b5
advancement grant @s only metiers:b/competence_5
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Abattage","color":"gold","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
scoreboard players set @s a.oak_log 0
scoreboard players set @s a.spruce_log 0
scoreboard players set @s a.birch_log 0
scoreboard players set @s a.jungle_log 0
scoreboard players set @s a.acacia_log 0
scoreboard players set @s a.dark_oak_log 0
scoreboard players set @s a.mangrove_log 0
scoreboard players set @s a.cherry_log 0
scoreboard players set @s a.pale_oak_log 0
scoreboard players set @s a.crimson_stem 0
scoreboard players set @s a.warped_stem 0
function metiers:b/arbre
