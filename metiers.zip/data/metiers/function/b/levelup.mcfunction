scoreboard players operation @s m.b_xp -= @s m.b_need
scoreboard players add @s m.b_lvl 1
xp add @s 2 levels
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
tellraw @a [{"selector":"@s","color":"white"},{"text":" passe ","color":"gray"},{"text":"Bûcheron","color":"gold"},{"text":" niveau ","color":"gray"},{"score":{"name":"@s","objective":"m.b_lvl"},"color":"yellow"}]
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"+1 point de compétence Bûcheron.","color":"yellow"}]
execute if score @s m.b_lvl matches 10 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "white", "text": "Initié Bûcheron"}]
execute if score @s m.b_lvl matches 20 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "gold", "text": "Compagnon Bûcheron"}]
execute if score @s m.b_lvl matches 30 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "gold", "bold": true, "text": "Artisan Bûcheron"}]
execute if score @s m.b_lvl matches 40 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "yellow", "bold": true, "text": "Expert Bûcheron"}]
execute if score @s m.b_lvl matches 50 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "gold", "bold": true, "text": "Vétéran Bûcheron"}]
execute if score @s m.b_lvl matches 60 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "red", "bold": true, "text": "Maître Bûcheron"}]
execute if score @s m.b_lvl matches 70 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "light_purple", "bold": true, "text": "Grand Maître Bûcheron"}]
execute if score @s m.b_lvl matches 80 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "dark_purple", "bold": true, "text": "Légende Bûcheron"}]
execute if score @s m.b_lvl matches 90 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "aqua", "bold": true, "text": "Mythique Bûcheron"}]
execute if score @s m.b_lvl matches 100 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "dark_red", "bold": true, "text": "Dieu Bûcheron"}]
tag @s add metiers.maj
execute if score @s m.b_lvl matches 100 run scoreboard players set @s m.b_xp 0
execute if score @s m.b_lvl matches 10 run function metiers:appel {f:"b/outil_monte"}
execute if score @s m.b_lvl matches 10 run function metiers:recompenses
execute if score @s m.b_lvl matches 20 run function metiers:appel {f:"b/outil_monte"}
execute if score @s m.b_lvl matches 20 run function metiers:recompenses
execute if score @s m.b_lvl matches 30 run function metiers:appel {f:"b/outil_monte"}
execute if score @s m.b_lvl matches 30 run function metiers:recompenses
execute if score @s m.b_lvl matches 40 run function metiers:appel {f:"b/outil_monte"}
execute if score @s m.b_lvl matches 40 run function metiers:recompenses
execute if score @s m.b_lvl matches 50 run function metiers:appel {f:"b/outil_monte"}
execute if score @s m.b_lvl matches 50 run function metiers:recompenses
execute if score @s m.b_lvl matches 60 run function metiers:appel {f:"b/outil_monte"}
execute if score @s m.b_lvl matches 60 run function metiers:recompenses
execute if score @s m.b_lvl matches 70 run function metiers:appel {f:"b/outil_monte"}
execute if score @s m.b_lvl matches 70 run function metiers:recompenses
execute if score @s m.b_lvl matches 80 run function metiers:appel {f:"b/outil_monte"}
execute if score @s m.b_lvl matches 80 run function metiers:recompenses
execute if score @s m.b_lvl matches 90 run function metiers:appel {f:"b/outil_monte"}
execute if score @s m.b_lvl matches 90 run function metiers:recompenses
execute if score @s m.b_lvl matches 100 run function metiers:appel {f:"b/outil_monte"}
execute if score @s m.b_lvl matches 100 run function metiers:recompenses
execute if score @s m.b_lvl matches 10 run advancement grant @s only metiers:b/niveau_10
execute if score @s m.b_lvl matches 20 run advancement grant @s only metiers:b/niveau_20
execute if score @s m.b_lvl matches 30 run advancement grant @s only metiers:b/niveau_30
execute if score @s m.b_lvl matches 40 run advancement grant @s only metiers:b/niveau_40
execute if score @s m.b_lvl matches 50 run advancement grant @s only metiers:b/niveau_50
execute if score @s m.b_lvl matches 60 run advancement grant @s only metiers:b/niveau_60
execute if score @s m.b_lvl matches 70 run advancement grant @s only metiers:b/niveau_70
execute if score @s m.b_lvl matches 80 run advancement grant @s only metiers:b/niveau_80
execute if score @s m.b_lvl matches 90 run advancement grant @s only metiers:b/niveau_90
execute if score @s m.b_lvl matches 100 run advancement grant @s only metiers:b/niveau_100
function metiers:b/check
