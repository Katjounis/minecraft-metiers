execute if entity @s[tag=metiers.sk.b4] run return run function metiers:b/arbre
function metiers:b/points
execute unless entity @s[tag=metiers.sk.b2] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Cueilleur.","color":"red"}]
execute unless entity @s[tag=metiers.sk.b2] run return run function metiers:b/arbre
execute if score @s m.tmp matches ..15 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (16 requis).","color":"red"}]
execute if score @s m.tmp matches ..15 run return run function metiers:b/arbre
scoreboard players add @s m.b_spent 16
tag @s add metiers.sk.b4
advancement grant @s only metiers:b/competence_4
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Bras de fer","color":"gold","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:b/arbre
