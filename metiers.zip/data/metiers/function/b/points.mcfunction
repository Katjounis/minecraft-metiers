scoreboard players operation @s m.tmp = @s m.b_lvl
scoreboard players remove @s m.tmp 1
scoreboard players operation @s m.tmp -= @s m.b_spent
