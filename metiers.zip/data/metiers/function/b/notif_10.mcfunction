playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Récompense du palier 100 Bûcheron disponible ! ","color":"yellow"},{"text":"[Récupérer]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger metiers set 201"}}]
