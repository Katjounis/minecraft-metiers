scoreboard players operation @s m.gain = @s m.b_bal
scoreboard players set @s m.b_bal 0
scoreboard players operation @s m.tmp = @s m.gain
scoreboard players operation @s m.tmp *= @s m.b_pr
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.gain += @s m.tmp
execute if score #job m.heure matches 1 run scoreboard players operation @s m.gain *= #2 m.const
execute if score @s m.b_lvl matches 100.. run return 0
scoreboard players operation @s m.b_xp += @s m.gain
function metiers:b/check
title @s actionbar [{"text":"+","color":"green"},{"score":{"name":"@s","objective":"m.gain"},"color":"green"},{"text":" XP Bûcheron","color":"gold"},{"text":"  |  niv ","color":"gray"},{"score":{"name":"@s","objective":"m.b_lvl"},"color":"white"},{"text":"  (","color":"gray"},{"score":{"name":"@s","objective":"m.b_xp"},"color":"white"},{"text":"/","color":"gray"},{"score":{"name":"@s","objective":"m.b_need"},"color":"white"},{"text":")","color":"gray"}]
