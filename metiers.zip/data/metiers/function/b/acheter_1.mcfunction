execute if entity @s[tag=metiers.sk.b1] run return run function metiers:b/arbre
function metiers:b/points
execute if score @s m.tmp matches ..5 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (6 requis).","color":"red"}]
execute if score @s m.tmp matches ..5 run return run function metiers:b/arbre
scoreboard players add @s m.b_spent 6
tag @s add metiers.sk.b1
advancement grant @s only metiers:b/competence_1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Poigne ferme","color":"gold","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:b/arbre
