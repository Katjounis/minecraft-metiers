execute if score @s m.b_lvl matches ..99 run return 0
execute if score @s m.b_pr matches 5.. run return 0
scoreboard players add @s m.b_pr 1
scoreboard players set @s m.b_lvl 1
scoreboard players set @s m.b_xp 0
scoreboard players set @s m.b_need 50
scoreboard players set @s m.b_spent 0
scoreboard players set @s m.b_pal 0
tag @s remove metiers.sk.b1
tag @s remove metiers.sk.b2
tag @s remove metiers.sk.b3
tag @s remove metiers.sk.b4
tag @s remove metiers.sk.b5
tag @s remove metiers.sk.b6
advancement revoke @s from metiers:b/competence_1
advancement revoke @s from metiers:b/niveau_10
tag @s add metiers.maj
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" passe ","color":"gray"},{"text":"★ Prestige ","color":"gold","bold":true},{"score":{"name":"@s","objective":"m.b_pr"},"color":"gold","bold":true},{"text":" en Bûcheron !","color":"gold","bold":true}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 0.8
playsound minecraft:entity.firework_rocket.large_blast master @a ~ ~ ~ 1 1
particle minecraft:totem_of_undying ~ ~1 ~ 0.6 1.2 0.6 0.5 200
particle minecraft:end_rod ~ ~1 ~ 0.4 1 0.4 0.15 80
