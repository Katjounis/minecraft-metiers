execute if entity @s[tag=metiers.sk.b6] run return run function metiers:b/arbre
function metiers:b/points
execute unless entity @s[tag=metiers.sk.b4,tag=metiers.sk.b5] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Bras de fer + Abattage.","color":"red"}]
execute unless entity @s[tag=metiers.sk.b4,tag=metiers.sk.b5] run return run function metiers:b/arbre
execute if score @s m.tmp matches ..31 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (32 requis).","color":"red"}]
execute if score @s m.tmp matches ..31 run return run function metiers:b/arbre
scoreboard players add @s m.b_spent 32
tag @s add metiers.sk.b6
advancement grant @s only metiers:b/competence_6
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Esprit de la forêt","color":"gold","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:b/arbre
