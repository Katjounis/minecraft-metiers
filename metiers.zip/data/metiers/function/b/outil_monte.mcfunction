scoreboard players operation @s m.tmp = @s m.b_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.b_out >= @s m.tmp run return 0
scoreboard players operation @s m.b_out = @s m.tmp
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" fait évoluer son outil de Bûcheron !","color":"gold","bold":true}]
function metiers:b/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton nouvel outil de Bûcheron est dans ton inventaire (l'ancien a été remplacé).","color":"yellow"}]
