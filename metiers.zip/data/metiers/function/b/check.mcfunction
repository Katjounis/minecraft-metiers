scoreboard players operation @s m.b_need = @s m.b_lvl
scoreboard players operation @s m.b_need *= #10 m.const
scoreboard players operation @s m.b_need += #40 m.const
execute if score @s m.b_lvl matches ..99 if score @s m.b_xp >= @s m.b_need run function metiers:b/levelup
