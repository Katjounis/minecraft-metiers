execute if function metiers:b/attente run return 1
execute if function metiers:f/attente run return 1
execute if function metiers:m/attente run return 1
execute if function metiers:c/attente run return 1
execute if function metiers:p/attente run return 1
execute if function metiers:e/attente run return 1
execute if function metiers:n/attente run return 1
execute if function metiers:x/attente run return 1
execute if function metiers:t/attente run return 1
return 0
