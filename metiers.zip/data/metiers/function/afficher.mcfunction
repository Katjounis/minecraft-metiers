$function metiers:notif_m {j:"$(j)",k:$(k)}
$function metiers:ecran_m {j:"$(j)",k:$(k)}
return 1
