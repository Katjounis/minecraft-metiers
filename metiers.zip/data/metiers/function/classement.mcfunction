tag @s add metiers.req
tellraw @s {"text":"Bûcheron :","color":"gold"}
execute as @a run tellraw @p[tag=metiers.req] [{"text":"  "},{"selector":"@s"},{"text":" niv ","color":"gray"},{"score":{"name":"@s","objective":"m.b_lvl"},"color":"yellow"}]
tellraw @s {"text":"Fermier :","color":"green"}
execute as @a run tellraw @p[tag=metiers.req] [{"text":"  "},{"selector":"@s"},{"text":" niv ","color":"gray"},{"score":{"name":"@s","objective":"m.f_lvl"},"color":"yellow"}]
tellraw @s {"text":"Mineur :","color":"gray"}
execute as @a run tellraw @p[tag=metiers.req] [{"text":"  "},{"selector":"@s"},{"text":" niv ","color":"gray"},{"score":{"name":"@s","objective":"m.m_lvl"},"color":"yellow"}]
tellraw @s {"text":"Chasseur :","color":"red"}
execute as @a run tellraw @p[tag=metiers.req] [{"text":"  "},{"selector":"@s"},{"text":" niv ","color":"gray"},{"score":{"name":"@s","objective":"m.c_lvl"},"color":"yellow"}]
tellraw @s {"text":"Pêcheur :","color":"aqua"}
execute as @a run tellraw @p[tag=metiers.req] [{"text":"  "},{"selector":"@s"},{"text":" niv ","color":"gray"},{"score":{"name":"@s","objective":"m.p_lvl"},"color":"yellow"}]
tellraw @s {"text":"Éleveur :","color":"light_purple"}
execute as @a run tellraw @p[tag=metiers.req] [{"text":"  "},{"selector":"@s"},{"text":" niv ","color":"gray"},{"score":{"name":"@s","objective":"m.e_lvl"},"color":"yellow"}]
tellraw @s {"text":"Enchanteur :","color":"dark_purple"}
execute as @a run tellraw @p[tag=metiers.req] [{"text":"  "},{"selector":"@s"},{"text":" niv ","color":"gray"},{"score":{"name":"@s","objective":"m.n_lvl"},"color":"yellow"}]
tellraw @s {"text":"Explorateur :","color":"blue"}
execute as @a run tellraw @p[tag=metiers.req] [{"text":"  "},{"selector":"@s"},{"text":" niv ","color":"gray"},{"score":{"name":"@s","objective":"m.x_lvl"},"color":"yellow"}]
tellraw @s {"text":"Marchand :","color":"dark_green"}
execute as @a run tellraw @p[tag=metiers.req] [{"text":"  "},{"selector":"@s"},{"text":" niv ","color":"gray"},{"score":{"name":"@s","objective":"m.t_lvl"},"color":"yellow"}]
tag @s remove metiers.req
