tag @s remove metiers.ok
tag @s remove metiers.v2
tag @s remove metiers.v3
team leave @s
advancement revoke @s from metiers:b/racine
advancement revoke @s from metiers:f/racine
advancement revoke @s from metiers:m/racine
advancement revoke @s from metiers:c/racine
advancement revoke @s from metiers:p/racine
scoreboard players set @s m.pref 0
tag @s remove metiers.sk.b1
tag @s remove metiers.sk.b2
tag @s remove metiers.sk.b3
tag @s remove metiers.sk.b4
tag @s remove metiers.sk.b5
tag @s remove metiers.sk.b6
tag @s remove metiers.sk.f1
tag @s remove metiers.sk.f2
tag @s remove metiers.sk.f3
tag @s remove metiers.sk.f4
tag @s remove metiers.sk.f5
tag @s remove metiers.sk.f6
tag @s remove metiers.sk.m1
tag @s remove metiers.sk.m2
tag @s remove metiers.sk.m3
tag @s remove metiers.sk.m4
tag @s remove metiers.sk.m5
tag @s remove metiers.sk.m6
tag @s remove metiers.sk.c1
tag @s remove metiers.sk.c2
tag @s remove metiers.sk.c3
tag @s remove metiers.sk.c4
tag @s remove metiers.sk.c5
tag @s remove metiers.sk.c6
tag @s remove metiers.sk.p1
tag @s remove metiers.sk.p2
tag @s remove metiers.sk.p3
tag @s remove metiers.sk.p4
tag @s remove metiers.sk.p5
tag @s remove metiers.sk.p6
tag @s remove metiers.sk.e1
tag @s remove metiers.sk.e2
tag @s remove metiers.sk.e3
tag @s remove metiers.sk.e4
tag @s remove metiers.sk.e5
tag @s remove metiers.sk.e6
tag @s remove metiers.sk.n1
tag @s remove metiers.sk.n2
tag @s remove metiers.sk.n3
tag @s remove metiers.sk.n4
tag @s remove metiers.sk.n5
tag @s remove metiers.sk.n6
tag @s remove metiers.sk.x1
tag @s remove metiers.sk.x2
tag @s remove metiers.sk.x3
tag @s remove metiers.sk.x4
tag @s remove metiers.sk.x5
tag @s remove metiers.sk.x6
tag @s remove metiers.sk.t1
tag @s remove metiers.sk.t2
tag @s remove metiers.sk.t3
tag @s remove metiers.sk.t4
tag @s remove metiers.sk.t5
tag @s remove metiers.sk.t6
scoreboard players set @s m.b_spent 0
scoreboard players set @s m.b_pal 0
scoreboard players set @s m.f_spent 0
scoreboard players set @s m.f_pal 0
scoreboard players set @s m.m_spent 0
scoreboard players set @s m.m_pal 0
scoreboard players set @s m.c_spent 0
scoreboard players set @s m.c_pal 0
scoreboard players set @s m.p_spent 0
scoreboard players set @s m.p_pal 0
scoreboard players set @s m.e_spent 0
scoreboard players set @s m.e_pal 0
scoreboard players set @s m.n_spent 0
scoreboard players set @s m.n_pal 0
scoreboard players set @s m.x_spent 0
scoreboard players set @s m.x_pal 0
scoreboard players set @s m.t_spent 0
scoreboard players set @s m.t_pal 0
function metiers:init
function metiers:migration
