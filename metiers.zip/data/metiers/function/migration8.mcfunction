tag @s add metiers.v8
tag @s add metiers.v9
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"b"}] run function metiers:b/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"f"}] run function metiers:f/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"m"}] run function metiers:m/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"c"}] run function metiers:c/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"p"}] run function metiers:p/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"e"}] run function metiers:e/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"n"}] run function metiers:n/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"x"}] run function metiers:x/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"t"}] run function metiers:t/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tes outils de métier ont été mis à jour : incassables dès le niveau 50, bloqués avant de casser, et réparables uniquement via le menu (touche G).","color":"yellow"}]
