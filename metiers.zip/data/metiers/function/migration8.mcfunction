tag @s add metiers.v8
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"b"}] run function metiers:b/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"f"}] run function metiers:f/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"m"}] run function metiers:m/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"c"}] run function metiers:c/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"p"}] run function metiers:p/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tes outils de métier sont maintenant incassables dès le niveau 50, et ne peuvent plus se briser avant : ils se bloquent à 1 de durabilité.","color":"yellow"}]
