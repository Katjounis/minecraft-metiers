execute as @a run function metiers:classement/maj
function metiers:classement/top {f:"t"}
data modify storage metiers:podium p0n set value {text:"personne",color:"dark_gray"}
data modify storage metiers:podium p0n set from storage metiers:cl res[0].nom
execute store result storage metiers:podium p0v int 1 run data get storage metiers:cl res[0].t
execute store result score #p0 m.tmp run data get storage metiers:cl res[0].t
data modify storage metiers:podium p1n set value {text:"personne",color:"dark_gray"}
data modify storage metiers:podium p1n set from storage metiers:cl res[1].nom
execute store result storage metiers:podium p1v int 1 run data get storage metiers:cl res[1].t
execute store result score #p1 m.tmp run data get storage metiers:cl res[1].t
data modify storage metiers:podium p2n set value {text:"personne",color:"dark_gray"}
data modify storage metiers:podium p2n set from storage metiers:cl res[2].nom
execute store result storage metiers:podium p2v int 1 run data get storage metiers:cl res[2].t
execute store result score #p2 m.tmp run data get storage metiers:cl res[2].t
execute if score #p0 m.tmp matches ..0 run scoreboard players set #p0 m.tmp 1
scoreboard players operation #b m.tmp = #p0 m.tmp
scoreboard players operation #b m.tmp *= #20 m.const
scoreboard players operation #b m.tmp /= #p0 m.tmp
execute if score #b m.tmp matches 0 run data modify storage metiers:podium p0b set value ""
execute if score #b m.tmp matches 1 run data modify storage metiers:podium p0b set value "▌"
execute if score #b m.tmp matches 2 run data modify storage metiers:podium p0b set value "▌▌"
execute if score #b m.tmp matches 3 run data modify storage metiers:podium p0b set value "▌▌▌"
execute if score #b m.tmp matches 4 run data modify storage metiers:podium p0b set value "▌▌▌▌"
execute if score #b m.tmp matches 5 run data modify storage metiers:podium p0b set value "▌▌▌▌▌"
execute if score #b m.tmp matches 6 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌"
execute if score #b m.tmp matches 7 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 8 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 9 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 10 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 11 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 12 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 13 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 14 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 15 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 16 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 17 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 18 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 19 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 20 run data modify storage metiers:podium p0b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
scoreboard players operation #b m.tmp = #p1 m.tmp
scoreboard players operation #b m.tmp *= #20 m.const
scoreboard players operation #b m.tmp /= #p0 m.tmp
execute if score #b m.tmp matches 0 run data modify storage metiers:podium p1b set value ""
execute if score #b m.tmp matches 1 run data modify storage metiers:podium p1b set value "▌"
execute if score #b m.tmp matches 2 run data modify storage metiers:podium p1b set value "▌▌"
execute if score #b m.tmp matches 3 run data modify storage metiers:podium p1b set value "▌▌▌"
execute if score #b m.tmp matches 4 run data modify storage metiers:podium p1b set value "▌▌▌▌"
execute if score #b m.tmp matches 5 run data modify storage metiers:podium p1b set value "▌▌▌▌▌"
execute if score #b m.tmp matches 6 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌"
execute if score #b m.tmp matches 7 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 8 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 9 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 10 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 11 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 12 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 13 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 14 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 15 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 16 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 17 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 18 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 19 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 20 run data modify storage metiers:podium p1b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
scoreboard players operation #b m.tmp = #p2 m.tmp
scoreboard players operation #b m.tmp *= #20 m.const
scoreboard players operation #b m.tmp /= #p0 m.tmp
execute if score #b m.tmp matches 0 run data modify storage metiers:podium p2b set value ""
execute if score #b m.tmp matches 1 run data modify storage metiers:podium p2b set value "▌"
execute if score #b m.tmp matches 2 run data modify storage metiers:podium p2b set value "▌▌"
execute if score #b m.tmp matches 3 run data modify storage metiers:podium p2b set value "▌▌▌"
execute if score #b m.tmp matches 4 run data modify storage metiers:podium p2b set value "▌▌▌▌"
execute if score #b m.tmp matches 5 run data modify storage metiers:podium p2b set value "▌▌▌▌▌"
execute if score #b m.tmp matches 6 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌"
execute if score #b m.tmp matches 7 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 8 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 9 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 10 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 11 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 12 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 13 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 14 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 15 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 16 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 17 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 18 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 19 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
execute if score #b m.tmp matches 20 run data modify storage metiers:podium p2b set value "▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌▌"
function metiers:classement/top {f:"b"}
data modify storage metiers:podium cbn set value {text:"personne",color:"dark_gray"}
data modify storage metiers:podium cbn set from storage metiers:cl res[0].nom
execute store result storage metiers:podium cbl int 1 run data get storage metiers:cl res[0].bl
data modify storage metiers:podium cbs set value ""
data modify storage metiers:podium cbs set from storage metiers:cl res[0].bst
function metiers:classement/top {f:"f"}
data modify storage metiers:podium cfn set value {text:"personne",color:"dark_gray"}
data modify storage metiers:podium cfn set from storage metiers:cl res[0].nom
execute store result storage metiers:podium cfl int 1 run data get storage metiers:cl res[0].fl
data modify storage metiers:podium cfs set value ""
data modify storage metiers:podium cfs set from storage metiers:cl res[0].fst
function metiers:classement/top {f:"m"}
data modify storage metiers:podium cmn set value {text:"personne",color:"dark_gray"}
data modify storage metiers:podium cmn set from storage metiers:cl res[0].nom
execute store result storage metiers:podium cml int 1 run data get storage metiers:cl res[0].ml
data modify storage metiers:podium cms set value ""
data modify storage metiers:podium cms set from storage metiers:cl res[0].mst
function metiers:classement/top {f:"c"}
data modify storage metiers:podium ccn set value {text:"personne",color:"dark_gray"}
data modify storage metiers:podium ccn set from storage metiers:cl res[0].nom
execute store result storage metiers:podium ccl int 1 run data get storage metiers:cl res[0].cl
data modify storage metiers:podium ccs set value ""
data modify storage metiers:podium ccs set from storage metiers:cl res[0].cst
function metiers:classement/top {f:"p"}
data modify storage metiers:podium cpn set value {text:"personne",color:"dark_gray"}
data modify storage metiers:podium cpn set from storage metiers:cl res[0].nom
execute store result storage metiers:podium cpl int 1 run data get storage metiers:cl res[0].pl
data modify storage metiers:podium cps set value ""
data modify storage metiers:podium cps set from storage metiers:cl res[0].pst
function metiers:classement/dialog with storage metiers:podium
