execute unless data storage metiers:cl it[0] run return 0
$execute store result score #v m.tmp run data get storage metiers:cl it[0].$(f)
execute if score #v m.tmp > #best m.tmp run data modify storage metiers:cl best set from storage metiers:cl it[0]
execute if score #v m.tmp > #best m.tmp run scoreboard players operation #best m.tmp = #v m.tmp
data remove storage metiers:cl it[0]
$function metiers:classement/iter {f:"$(f)"}
