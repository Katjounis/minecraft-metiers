data modify storage metiers:cl copie set from storage metiers:cl joueurs
data modify storage metiers:cl res set value []
$function metiers:classement/rang {f:"$(f)"}
$function metiers:classement/rang {f:"$(f)"}
$function metiers:classement/rang {f:"$(f)"}
