$data modify storage metiers:cl joueurs[{id:$(id)}].nom set from storage metiers:tmp nom
