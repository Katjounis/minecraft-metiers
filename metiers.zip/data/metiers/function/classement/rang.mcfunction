scoreboard players set #best m.tmp -1
data remove storage metiers:cl best
data modify storage metiers:cl it set from storage metiers:cl copie
$function metiers:classement/iter {f:"$(f)"}
execute unless data storage metiers:cl best run return 0
data modify storage metiers:cl res append from storage metiers:cl best
function metiers:classement/retirer with storage metiers:cl best
