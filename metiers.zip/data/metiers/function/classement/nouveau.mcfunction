tag @s add metiers.nom
execute in minecraft:overworld run setblock 0 -64 0 minecraft:oak_sign
execute in minecraft:overworld run data modify block 0 -64 0 front_text.messages[0] set value {selector:"@a[tag=metiers.nom,limit=1]"}
$data modify storage metiers:cl joueurs append value {id:$(id)}
$execute in minecraft:overworld run data modify storage metiers:cl joueurs[{id:$(id)}].nom set from block 0 -64 0 front_text.messages[0]
execute in minecraft:overworld run setblock 0 -64 0 minecraft:bedrock
tag @s remove metiers.nom
