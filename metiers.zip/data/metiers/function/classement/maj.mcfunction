execute store result storage metiers:tmp id int 1 run scoreboard players get @s m.id
scoreboard players set @s m.total 0
scoreboard players operation @s m.tmp = @s m.b_pr
scoreboard players operation @s m.tmp *= #100 m.const
scoreboard players operation @s m.tmp += @s m.b_lvl
scoreboard players operation @s m.total += @s m.tmp
execute store result storage metiers:tmp b int 1 run scoreboard players get @s m.tmp
execute store result storage metiers:tmp bl int 1 run scoreboard players get @s m.b_lvl
data modify storage metiers:tmp bst set value ""
execute if score @s m.b_pr matches 1 run data modify storage metiers:tmp bst set value "★"
execute if score @s m.b_pr matches 2 run data modify storage metiers:tmp bst set value "★★"
execute if score @s m.b_pr matches 3 run data modify storage metiers:tmp bst set value "★★★"
execute if score @s m.b_pr matches 4 run data modify storage metiers:tmp bst set value "★★★★"
execute if score @s m.b_pr matches 5 run data modify storage metiers:tmp bst set value "★★★★★"
scoreboard players operation @s m.tmp = @s m.f_pr
scoreboard players operation @s m.tmp *= #100 m.const
scoreboard players operation @s m.tmp += @s m.f_lvl
scoreboard players operation @s m.total += @s m.tmp
execute store result storage metiers:tmp f int 1 run scoreboard players get @s m.tmp
execute store result storage metiers:tmp fl int 1 run scoreboard players get @s m.f_lvl
data modify storage metiers:tmp fst set value ""
execute if score @s m.f_pr matches 1 run data modify storage metiers:tmp fst set value "★"
execute if score @s m.f_pr matches 2 run data modify storage metiers:tmp fst set value "★★"
execute if score @s m.f_pr matches 3 run data modify storage metiers:tmp fst set value "★★★"
execute if score @s m.f_pr matches 4 run data modify storage metiers:tmp fst set value "★★★★"
execute if score @s m.f_pr matches 5 run data modify storage metiers:tmp fst set value "★★★★★"
scoreboard players operation @s m.tmp = @s m.m_pr
scoreboard players operation @s m.tmp *= #100 m.const
scoreboard players operation @s m.tmp += @s m.m_lvl
scoreboard players operation @s m.total += @s m.tmp
execute store result storage metiers:tmp m int 1 run scoreboard players get @s m.tmp
execute store result storage metiers:tmp ml int 1 run scoreboard players get @s m.m_lvl
data modify storage metiers:tmp mst set value ""
execute if score @s m.m_pr matches 1 run data modify storage metiers:tmp mst set value "★"
execute if score @s m.m_pr matches 2 run data modify storage metiers:tmp mst set value "★★"
execute if score @s m.m_pr matches 3 run data modify storage metiers:tmp mst set value "★★★"
execute if score @s m.m_pr matches 4 run data modify storage metiers:tmp mst set value "★★★★"
execute if score @s m.m_pr matches 5 run data modify storage metiers:tmp mst set value "★★★★★"
scoreboard players operation @s m.tmp = @s m.c_pr
scoreboard players operation @s m.tmp *= #100 m.const
scoreboard players operation @s m.tmp += @s m.c_lvl
scoreboard players operation @s m.total += @s m.tmp
execute store result storage metiers:tmp c int 1 run scoreboard players get @s m.tmp
execute store result storage metiers:tmp cl int 1 run scoreboard players get @s m.c_lvl
data modify storage metiers:tmp cst set value ""
execute if score @s m.c_pr matches 1 run data modify storage metiers:tmp cst set value "★"
execute if score @s m.c_pr matches 2 run data modify storage metiers:tmp cst set value "★★"
execute if score @s m.c_pr matches 3 run data modify storage metiers:tmp cst set value "★★★"
execute if score @s m.c_pr matches 4 run data modify storage metiers:tmp cst set value "★★★★"
execute if score @s m.c_pr matches 5 run data modify storage metiers:tmp cst set value "★★★★★"
scoreboard players operation @s m.tmp = @s m.p_pr
scoreboard players operation @s m.tmp *= #100 m.const
scoreboard players operation @s m.tmp += @s m.p_lvl
scoreboard players operation @s m.total += @s m.tmp
execute store result storage metiers:tmp p int 1 run scoreboard players get @s m.tmp
execute store result storage metiers:tmp pl int 1 run scoreboard players get @s m.p_lvl
data modify storage metiers:tmp pst set value ""
execute if score @s m.p_pr matches 1 run data modify storage metiers:tmp pst set value "★"
execute if score @s m.p_pr matches 2 run data modify storage metiers:tmp pst set value "★★"
execute if score @s m.p_pr matches 3 run data modify storage metiers:tmp pst set value "★★★"
execute if score @s m.p_pr matches 4 run data modify storage metiers:tmp pst set value "★★★★"
execute if score @s m.p_pr matches 5 run data modify storage metiers:tmp pst set value "★★★★★"
execute store result storage metiers:tmp t int 1 run scoreboard players get @s m.total
function metiers:classement/ecrire with storage metiers:tmp
