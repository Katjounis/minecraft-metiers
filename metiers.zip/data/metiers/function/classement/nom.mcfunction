data remove storage metiers:tmp nom
summon minecraft:item_display ~ ~-2 ~ {Tags:["metiers.nomeur"],item:{id:"minecraft:paper",count:1}}
item modify entity @e[type=minecraft:item_display,tag=metiers.nomeur,limit=1] contents {function:"minecraft:set_name",type:"minecraft:set_name",entity:"this",target:"custom_name",name:{selector:"@s"}}
data modify storage metiers:tmp nom set from entity @e[type=minecraft:item_display,tag=metiers.nomeur,limit=1] item.components."minecraft:custom_name"
kill @e[type=minecraft:item_display,tag=metiers.nomeur]
execute if data storage metiers:tmp nom run function metiers:classement/nom_m with storage metiers:tmp
