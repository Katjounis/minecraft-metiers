$execute unless data storage metiers:cl joueurs[{id:$(id)}] run function metiers:classement/nouveau {id:$(id)}
$data modify storage metiers:cl joueurs[{id:$(id)}].t set value $(t)
$data modify storage metiers:cl joueurs[{id:$(id)}].b set value $(b)
$data modify storage metiers:cl joueurs[{id:$(id)}].bl set value $(bl)
$data modify storage metiers:cl joueurs[{id:$(id)}].bst set value "$(bst)"
$data modify storage metiers:cl joueurs[{id:$(id)}].f set value $(f)
$data modify storage metiers:cl joueurs[{id:$(id)}].fl set value $(fl)
$data modify storage metiers:cl joueurs[{id:$(id)}].fst set value "$(fst)"
$data modify storage metiers:cl joueurs[{id:$(id)}].m set value $(m)
$data modify storage metiers:cl joueurs[{id:$(id)}].ml set value $(ml)
$data modify storage metiers:cl joueurs[{id:$(id)}].mst set value "$(mst)"
$data modify storage metiers:cl joueurs[{id:$(id)}].c set value $(c)
$data modify storage metiers:cl joueurs[{id:$(id)}].cl set value $(cl)
$data modify storage metiers:cl joueurs[{id:$(id)}].cst set value "$(cst)"
$data modify storage metiers:cl joueurs[{id:$(id)}].p set value $(p)
$data modify storage metiers:cl joueurs[{id:$(id)}].pl set value $(pl)
$data modify storage metiers:cl joueurs[{id:$(id)}].pst set value "$(pst)"
