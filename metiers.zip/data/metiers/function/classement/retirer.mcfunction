$data remove storage metiers:cl copie[{id:$(id)}]
