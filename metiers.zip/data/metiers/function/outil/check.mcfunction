execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"b"}] run function metiers:appel {f:"b/outil_lore"}
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"f"}] run function metiers:appel {f:"f/outil_lore"}
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"m"}] run function metiers:appel {f:"m/outil_lore"}
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"c"}] run function metiers:appel {f:"c/outil_lore"}
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"p"}] run function metiers:appel {f:"p/outil_lore"}
