execute unless data entity @s SelectedItem.components."minecraft:custom_data".metiers_outil run return 0
execute if data entity @s SelectedItem.components."minecraft:custom_data".verrou run return run title @s actionbar {"text":"✖ Outil à réparer ! Appuie sur G, choisis ton métier puis « Réparer mon outil ».","color":"red","bold":true}
execute if data entity @s SelectedItem.components."minecraft:unbreakable" run return 0
execute unless data entity @s SelectedItem.components."minecraft:custom_data".max run return 0
execute store result score @s m.tmp run data get entity @s SelectedItem.components."minecraft:custom_data".max
execute store result score @s m.dur run data get entity @s SelectedItem.components."minecraft:damage"
scoreboard players operation @s m.tmp -= @s m.dur
execute if score @s m.tmp matches ..3 run function metiers:outil/verrouiller
