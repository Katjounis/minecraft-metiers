execute as @a at @s run function metiers:outil/usure
