data modify storage metiers:tmp cd set from entity @s SelectedItem.components."minecraft:custom_data"
data modify storage metiers:tmp cd.verrou set value 1b
item modify entity @s weapon.mainhand {function:"minecraft:set_components",type:"minecraft:set_components",components:{"minecraft:unbreakable":{},"!minecraft:tool":{},"!minecraft:weapon":{}}}
function metiers:outil/verrou_m with storage metiers:tmp
playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.6 1.2
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton outil est à bout (3 de durabilité) : il est bloqué pour ne pas se casser. Appuie sur G, choisis ton métier puis « Réparer mon outil » (5 niveaux d'XP). L'enclume et le Raccommodage ne marchent pas sur les outils de métier.","color":"red"}]
