tag @s add metiers.v22
execute if score @s m.arm matches 1.. run function metiers:armure/donner
