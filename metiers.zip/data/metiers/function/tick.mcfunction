execute as @a[scores={metiers=1..}] at @s run function metiers:trigger
execute as @a[tag=metiers.sk.b2] at @s run function metiers:b/abattage/tick
function metiers:refonte/tick
function metiers:appel {f:"outil/usure_tick"}
