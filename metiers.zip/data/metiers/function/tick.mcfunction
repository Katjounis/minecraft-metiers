execute as @a[scores={metiers=1..}] at @s run function metiers:trigger
execute as @a[tag=metiers.sk.b5] at @s run function metiers:b/abattage/tick
