execute if entity @s[tag=metiers.sk.p4] run return run function metiers:p/arbre
function metiers:p/points
execute unless entity @s[tag=metiers.sk.p2] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Poumons d'acier.","color":"red"}]
execute unless entity @s[tag=metiers.sk.p2] run return run function metiers:p/arbre
execute if score @s m.tmp matches ..15 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (16 requis).","color":"red"}]
execute if score @s m.tmp matches ..15 run return run function metiers:p/arbre
scoreboard players add @s m.p_spent 16
tag @s add metiers.sk.p4
advancement grant @s only metiers:p/competence_4
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Nageur","color":"aqua","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:p/arbre
