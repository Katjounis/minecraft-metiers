function metiers:places
execute if score @s m.tmp matches ..0 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Inventaire plein ! Libère 1 emplacement puis réessaie (/trigger metiers > Récompenses).","color":"red"}]
execute if score @s m.tmp matches ..0 run playsound minecraft:entity.villager.no master @s ~ ~ ~ 1 1
execute if score @s m.tmp matches ..0 run return 0
scoreboard players set @s m.p_pal 4
give @s minecraft:trident[minecraft:enchantments={"minecraft:loyalty":3,"minecraft:unbreaking":5,"minecraft:mending":1},minecraft:custom_name={text:"Trident de l'Expert",color:"yellow",bold:true,italic:false},minecraft:rarity="epic"] 1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" récupère sa récompense","color":"gray"},{"text":" (palier 40 Pêcheur)","color":"gray"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 0.6
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.3 60
function metiers:recompenses
