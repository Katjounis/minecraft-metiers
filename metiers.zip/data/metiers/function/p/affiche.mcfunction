execute if score @s m.p_mul matches 2 run data modify storage metiers:peche mul set value "x1"
execute if score @s m.p_mul matches 3 run data modify storage metiers:peche mul set value "x1,5"
execute if score @s m.p_mul matches 4 run data modify storage metiers:peche mul set value "x2"
execute if score @s m.p_mul matches 5 run data modify storage metiers:peche mul set value "x2,5"
execute if score @s m.p_mul matches 6 run data modify storage metiers:peche mul set value "x3"
execute if score @s m.p_mul matches 7 run data modify storage metiers:peche mul set value "x3,5"
execute if score @s m.p_mul matches 8 run data modify storage metiers:peche mul set value "x4"
execute if score @s m.p_mul matches 9 run data modify storage metiers:peche mul set value "x4,5"
data modify storage metiers:peche amb set value ""
execute if score @s m.p_pluie matches 1 run data modify storage metiers:peche amb set value " · pluie"
execute if score @s m.p_nuit matches 1 run data modify storage metiers:peche amb2 set value " · nuit"
execute unless score @s m.p_nuit matches 1 run data modify storage metiers:peche amb2 set value ""
execute if score @s m.p_ocean matches 1 run data modify storage metiers:peche amb3 set value " · océan"
execute unless score @s m.p_ocean matches 1 run data modify storage metiers:peche amb3 set value ""
execute store result storage metiers:peche serie int 1 run scoreboard players get @s m.p_serie
execute store result storage metiers:peche gain int 1 run scoreboard players get @s m.gain
function metiers:p/affiche_m with storage metiers:peche
scoreboard players set @s m.p_aff 0
