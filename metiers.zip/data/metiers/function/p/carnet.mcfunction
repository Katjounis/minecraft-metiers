data modify storage metiers:carnet n1 set value "???"
data modify storage metiers:carnet c1 set value "dark_gray"
execute if score @s m.p_l1 matches 1 run data modify storage metiers:carnet n1 set value "✔ Carpe d'or"
execute if score @s m.p_l1 matches 1 run data modify storage metiers:carnet c1 set value "gold"
data modify storage metiers:carnet n2 set value "???"
data modify storage metiers:carnet c2 set value "dark_gray"
execute if score @s m.p_l2 matches 1 run data modify storage metiers:carnet n2 set value "✔ Brochet des abysses"
execute if score @s m.p_l2 matches 1 run data modify storage metiers:carnet c2 set value "dark_aqua"
data modify storage metiers:carnet n3 set value "???"
data modify storage metiers:carnet c3 set value "dark_gray"
execute if score @s m.p_l3 matches 1 run data modify storage metiers:carnet n3 set value "✔ Saumon royal"
execute if score @s m.p_l3 matches 1 run data modify storage metiers:carnet c3 set value "red"
data modify storage metiers:carnet n4 set value "???"
data modify storage metiers:carnet c4 set value "dark_gray"
execute if score @s m.p_l4 matches 1 run data modify storage metiers:carnet n4 set value "✔ Poisson-lune"
execute if score @s m.p_l4 matches 1 run data modify storage metiers:carnet c4 set value "light_purple"
data modify storage metiers:carnet n5 set value "???"
data modify storage metiers:carnet c5 set value "dark_gray"
execute if score @s m.p_l5 matches 1 run data modify storage metiers:carnet n5 set value "✔ Anguille électrique"
execute if score @s m.p_l5 matches 1 run data modify storage metiers:carnet c5 set value "yellow"
data modify storage metiers:carnet n6 set value "???"
data modify storage metiers:carnet c6 set value "dark_gray"
execute if score @s m.p_l6 matches 1 run data modify storage metiers:carnet n6 set value "✔ Silure géant"
execute if score @s m.p_l6 matches 1 run data modify storage metiers:carnet c6 set value "dark_green"
data modify storage metiers:carnet n7 set value "???"
data modify storage metiers:carnet c7 set value "dark_gray"
execute if score @s m.p_l7 matches 1 run data modify storage metiers:carnet n7 set value "✔ Raie fantôme"
execute if score @s m.p_l7 matches 1 run data modify storage metiers:carnet c7 set value "aqua"
data modify storage metiers:carnet n8 set value "???"
data modify storage metiers:carnet c8 set value "dark_gray"
execute if score @s m.p_l8 matches 1 run data modify storage metiers:carnet n8 set value "✔ Poisson-lanterne"
execute if score @s m.p_l8 matches 1 run data modify storage metiers:carnet c8 set value "gold"
data modify storage metiers:carnet n9 set value "???"
data modify storage metiers:carnet c9 set value "dark_gray"
execute if score @s m.p_l9 matches 1 run data modify storage metiers:carnet n9 set value "✔ Esturgeon millénaire"
execute if score @s m.p_l9 matches 1 run data modify storage metiers:carnet c9 set value "gray"
data modify storage metiers:carnet n10 set value "???"
data modify storage metiers:carnet c10 set value "dark_gray"
execute if score @s m.p_l10 matches 1 run data modify storage metiers:carnet n10 set value "✔ Kraken nain"
execute if score @s m.p_l10 matches 1 run data modify storage metiers:carnet c10 set value "dark_purple"
scoreboard players set @s m.tmp 0
execute if score @s m.p_l1 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l2 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l3 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l4 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l5 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l6 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l7 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l8 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l9 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l10 matches 1 run scoreboard players add @s m.tmp 1
execute store result storage metiers:carnet nb int 1 run scoreboard players get @s m.tmp
function metiers:p/carnet_dialog with storage metiers:carnet
