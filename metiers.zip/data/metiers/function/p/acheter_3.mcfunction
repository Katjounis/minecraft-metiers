execute if entity @s[tag=metiers.sk.p3] run return run function metiers:p/arbre
function metiers:p/points
execute unless entity @s[tag=metiers.sk.p1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Patience.","color":"red"}]
execute unless entity @s[tag=metiers.sk.p1] run return run function metiers:p/arbre
execute if score @s m.tmp matches ..11 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (12 requis).","color":"red"}]
execute if score @s m.tmp matches ..11 run return run function metiers:p/arbre
scoreboard players add @s m.p_spent 12
tag @s add metiers.sk.p3
advancement grant @s only metiers:p/competence_3
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Prise double","color":"aqua","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:p/arbre
