scoreboard players operation @s m.tmp = @s m.p_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.p_out >= @s m.tmp run return 0
scoreboard players operation @s m.p_out = @s m.tmp
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" fait évoluer son outil de Pêcheur !","color":"aqua","bold":true}]
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"p"}] run return run function metiers:p/outil_donner
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"p"}] run return run function metiers:p/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton outil de Pêcheur a évolué : récupère-le avec G, Pêcheur, « Récupérer mon outil ».","color":"yellow"}]
