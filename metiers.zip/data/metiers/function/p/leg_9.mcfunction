give @s minecraft:salmon[minecraft:custom_name={text:"Esturgeon millénaire",color:"gray",bold:true,italic:false},minecraft:lore=[{text:"Prise légendaire 9/10",color:"gray",italic:false},{text:"Trophée du Carnet du pêcheur",color:"dark_aqua",italic:false}],minecraft:custom_data={metiers_legende:9},minecraft:rarity="epic",minecraft:enchantment_glint_override=true,minecraft:max_stack_size=1] 1
scoreboard players add @s m.p_bal 50
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" a pêché une prise légendaire : ","color":"gray"},{"text":"Esturgeon millénaire","color":"gray","bold":true}]
execute unless score @s m.p_l9 matches 1 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Nouvelle espèce dans ton Carnet du pêcheur !","color":"aqua","bold":true}]
scoreboard players set @s m.p_l9 1
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.4
particle minecraft:bubble_column_up ~ ~0.5 ~ 0.6 0.4 0.6 0.1 60
function metiers:p/carnet_check
