function metiers:places
execute if score @s m.tmp matches ..1 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Inventaire plein ! Libère 2 emplacements puis réessaie (/trigger metiers > Récompenses).","color":"red"}]
execute if score @s m.tmp matches ..1 run playsound minecraft:entity.villager.no master @s ~ ~ ~ 1 1
execute if score @s m.tmp matches ..1 run return 0
scoreboard players set @s m.p_pal 6
give @s minecraft:turtle_helmet[minecraft:enchantments={"minecraft:respiration":3,"minecraft:aqua_affinity":1,"minecraft:unbreaking":7,"minecraft:mending":1},minecraft:custom_name={text:"Casque du Maître",color:"red",bold:true,italic:false},minecraft:rarity="epic"] 1
give @s minecraft:saddle 1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" récupère sa récompense","color":"gray"},{"text":" (palier 60 Pêcheur)","color":"gray"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 0.6
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.3 60
function metiers:recompenses
