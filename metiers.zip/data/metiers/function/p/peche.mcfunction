execute if score @s m.p_timer matches ..80 run scoreboard players operation @s m.p_serie += @s s.p.fish
execute unless score @s m.p_timer matches ..80 run scoreboard players operation @s m.p_serie = @s s.p.fish
scoreboard players set @s m.p_timer 0
scoreboard players set @s m.p_mul 2
execute if score @s m.p_serie matches 3..4 run scoreboard players add @s m.p_mul 1
execute if score @s m.p_serie matches 5..7 run scoreboard players add @s m.p_mul 2
execute if score @s m.p_serie matches 8.. run scoreboard players add @s m.p_mul 4
scoreboard players set @s m.p_pluie 0
scoreboard players set @s m.p_nuit 0
scoreboard players set @s m.p_ocean 0
function metiers:appel {f:"p/ambiance"}
scoreboard players operation @s m.tmp = @s m.p_mul
scoreboard players remove @s m.tmp 2
scoreboard players operation @s m.tmp *= @s s.p.fish
scoreboard players operation @s m.tmp *= #4 m.const
scoreboard players operation @s m.p_bal += @s m.tmp
scoreboard players set @s m.p_aff 1
execute store result score #r m.tmp run random value 1..1000
scoreboard players operation #thr m.tmp = @s m.p_lvl
scoreboard players add #thr m.tmp 20
execute if score #r m.tmp <= #thr m.tmp run function metiers:p/legende
execute store result score #r m.tmp run random value 1..1000
scoreboard players operation #thr m.tmp = @s m.p_lvl
scoreboard players operation #thr m.tmp /= #2 m.const
scoreboard players add #thr m.tmp 10
execute if score #r m.tmp <= #thr m.tmp run function metiers:p/tresor
