execute if entity @s[tag=metiers.sk.p1] run return run function metiers:p/arbre
function metiers:p/points
execute if score @s m.tmp matches ..5 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (6 requis).","color":"red"}]
execute if score @s m.tmp matches ..5 run return run function metiers:p/arbre
scoreboard players add @s m.p_spent 6
tag @s add metiers.sk.p1
advancement grant @s only metiers:p/competence_1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Patience","color":"aqua","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:p/arbre
