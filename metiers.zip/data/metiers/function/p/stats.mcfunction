scoreboard players add @s m.p_timer 1
execute if score @s s.p.fish matches 1.. run function metiers:appel {f:"p/peche"}
# Anti-triche : poser ou jeter l'objet retire l'XP gagnée
execute if entity @s[tag=metiers.sk.p3] if score @s s.p.fish matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.p3] if score @s s.p.fish matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:gameplay/fishing/fish
execute if entity @s[tag=metiers.sk.p5] if score @s s.p.fish matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.p5] if score @s s.p.fish matches 1.. if score #r m.tmp matches ..10 run loot give @s loot minecraft:gameplay/fishing/treasure
scoreboard players operation @s m.tmp = @s s.p.fish
scoreboard players operation @s m.tmp *= #8 m.const
scoreboard players operation @s m.p_bal += @s m.tmp
scoreboard players set @s s.p.fish 0
execute if score @s m.p_bal matches 1.. run function metiers:p/gain
execute if score @s m.p_aff matches 1 run function metiers:appel {f:"p/affiche"}
