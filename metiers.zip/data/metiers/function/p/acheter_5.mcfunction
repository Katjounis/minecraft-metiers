execute if entity @s[tag=metiers.sk.p5] run return run function metiers:p/arbre
function metiers:p/points
execute unless entity @s[tag=metiers.sk.p3] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Prise double.","color":"red"}]
execute unless entity @s[tag=metiers.sk.p3] run return run function metiers:p/arbre
execute if score @s m.tmp matches ..23 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (24 requis).","color":"red"}]
execute if score @s m.tmp matches ..23 run return run function metiers:p/arbre
scoreboard players add @s m.p_spent 24
tag @s add metiers.sk.p5
advancement grant @s only metiers:p/competence_5
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Chasseur de trésors","color":"aqua","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:p/arbre
