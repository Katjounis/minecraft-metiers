execute if predicate {type:"minecraft:weather_check",raining:true} run scoreboard players set @s m.p_pluie 1
execute if predicate {type:"minecraft:time_check",value:{min:13000,max:23000},period:24000} run scoreboard players set @s m.p_nuit 1
execute if biome ~ ~ ~ #minecraft:is_ocean run scoreboard players set @s m.p_ocean 1
execute if biome ~ ~ ~ #minecraft:is_deep_ocean run scoreboard players set @s m.p_ocean 1
scoreboard players operation @s m.p_mul += @s m.p_pluie
scoreboard players operation @s m.p_mul += @s m.p_nuit
scoreboard players operation @s m.p_mul += @s m.p_ocean
