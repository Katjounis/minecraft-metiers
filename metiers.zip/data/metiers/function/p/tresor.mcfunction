execute store result score #f m.tmp run random value 1..6
execute if score #f m.tmp matches 1 run loot give @s loot minecraft:chests/shipwreck_treasure
execute if score #f m.tmp matches 2 run loot give @s loot minecraft:chests/buried_treasure
execute if score #f m.tmp matches 3 run loot give @s loot minecraft:chests/ancient_city
execute if score #f m.tmp matches 4 run loot give @s loot minecraft:chests/ruined_portal
execute if score #f m.tmp matches 5 run loot give @s loot minecraft:chests/underwater_ruin_big
execute if score #f m.tmp matches 6 run loot give @s loot minecraft:chests/desert_pyramid
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" remonte un coffre des profondeurs !","color":"dark_aqua","bold":true}]
playsound minecraft:block.chest.open master @s ~ ~ ~ 1 0.8
particle minecraft:bubble ~ ~0.5 ~ 0.6 0.4 0.6 0.1 40
