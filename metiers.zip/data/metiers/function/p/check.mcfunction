scoreboard players operation @s m.p_need = @s m.p_lvl
scoreboard players operation @s m.p_need *= #10 m.const
scoreboard players operation @s m.p_need += #40 m.const
execute if score @s m.p_lvl matches ..99 if score @s m.p_xp >= @s m.p_need run function metiers:p/levelup
