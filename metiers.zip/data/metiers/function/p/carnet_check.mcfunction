scoreboard players set @s m.tmp 0
execute if score @s m.p_l1 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l2 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l3 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l4 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l5 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l6 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l7 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l8 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l9 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_l10 matches 1 run scoreboard players add @s m.tmp 1
execute if score @s m.p_legok matches 1 run return 0
execute unless score @s m.tmp matches 10 run return 0
scoreboard players set @s m.p_legok 1
give @s minecraft:enchanted_golden_apple 5
give @s minecraft:netherite_ingot 3
give @s minecraft:heart_of_the_sea 1
scoreboard players add @s m.p_bal 500
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" a complété le Carnet du pêcheur : les 10 légendes ! ","color":"aqua","bold":true}]
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.6
