execute if entity @s[tag=metiers.sk.p6] run return run function metiers:p/arbre
function metiers:p/points
execute unless entity @s[tag=metiers.sk.p4,tag=metiers.sk.p5] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Nageur + Chasseur de trésors.","color":"red"}]
execute unless entity @s[tag=metiers.sk.p4,tag=metiers.sk.p5] run return run function metiers:p/arbre
execute if score @s m.tmp matches ..31 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (32 requis).","color":"red"}]
execute if score @s m.tmp matches ..31 run return run function metiers:p/arbre
scoreboard players add @s m.p_spent 32
tag @s add metiers.sk.p6
advancement grant @s only metiers:p/competence_6
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Seigneur des mers","color":"aqua","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:p/arbre
