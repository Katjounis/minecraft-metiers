execute if entity @s[tag=metiers.sk.p2] run return run function metiers:p/arbre
function metiers:p/points
execute unless entity @s[tag=metiers.sk.p1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Patience.","color":"red"}]
execute unless entity @s[tag=metiers.sk.p1] run return run function metiers:p/arbre
execute if score @s m.tmp matches ..7 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (8 requis).","color":"red"}]
execute if score @s m.tmp matches ..7 run return run function metiers:p/arbre
scoreboard players add @s m.p_spent 8
tag @s add metiers.sk.p2
advancement grant @s only metiers:p/competence_2
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Poumons d'acier","color":"aqua","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:p/arbre
