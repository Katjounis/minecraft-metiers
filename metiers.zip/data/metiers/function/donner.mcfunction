$function metiers:$(j)/donner_$(k)
return 1
