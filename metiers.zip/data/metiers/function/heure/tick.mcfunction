scoreboard players add #cycle m.heure 1
execute if score #job m.heure matches 0 if score #cycle m.heure matches 10800.. if entity @a run function metiers:heure/lancer
execute if score #job m.heure matches 1.. run function metiers:heure/encours
