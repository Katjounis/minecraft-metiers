scoreboard players set #cycle m.heure 0
execute store result score #job m.heure run random value 1..9
scoreboard players set #reste m.heure 3600
bossbar set metiers:heure color pink
bossbar set metiers:heure style progress
execute if score #job m.heure matches 1 run bossbar set metiers:heure name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Heure du Bûcheron","color":"gold","bold":true},{"text":" : XP x2","color":"white","bold":false}]
execute if score #job m.heure matches 1 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"C'est l'heure du Bûcheron ! ","color":"gold","bold":true},{"text":"Toute l'XP de ce métier compte double pendant 30 minutes.","color":"white"}]
execute if score #job m.heure matches 2 run bossbar set metiers:heure name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Heure du Fermier","color":"green","bold":true},{"text":" : XP x2","color":"white","bold":false}]
execute if score #job m.heure matches 2 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"C'est l'heure du Fermier ! ","color":"green","bold":true},{"text":"Toute l'XP de ce métier compte double pendant 30 minutes.","color":"white"}]
execute if score #job m.heure matches 3 run bossbar set metiers:heure name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Heure du Mineur","color":"gray","bold":true},{"text":" : XP x2","color":"white","bold":false}]
execute if score #job m.heure matches 3 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"C'est l'heure du Mineur ! ","color":"gray","bold":true},{"text":"Toute l'XP de ce métier compte double pendant 30 minutes.","color":"white"}]
execute if score #job m.heure matches 4 run bossbar set metiers:heure name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Heure du Chasseur","color":"red","bold":true},{"text":" : XP x2","color":"white","bold":false}]
execute if score #job m.heure matches 4 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"C'est l'heure du Chasseur ! ","color":"red","bold":true},{"text":"Toute l'XP de ce métier compte double pendant 30 minutes.","color":"white"}]
execute if score #job m.heure matches 5 run bossbar set metiers:heure name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Heure du Pêcheur","color":"aqua","bold":true},{"text":" : XP x2","color":"white","bold":false}]
execute if score #job m.heure matches 5 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"C'est l'heure du Pêcheur ! ","color":"aqua","bold":true},{"text":"Toute l'XP de ce métier compte double pendant 30 minutes.","color":"white"}]
execute if score #job m.heure matches 6 run bossbar set metiers:heure name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Heure de l'Éleveur","color":"light_purple","bold":true},{"text":" : XP x2","color":"white","bold":false}]
execute if score #job m.heure matches 6 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"C'est l'heure de l'Éleveur ! ","color":"light_purple","bold":true},{"text":"Toute l'XP de ce métier compte double pendant 30 minutes.","color":"white"}]
execute if score #job m.heure matches 7 run bossbar set metiers:heure name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Heure de l'Enchanteur","color":"dark_purple","bold":true},{"text":" : XP x2","color":"white","bold":false}]
execute if score #job m.heure matches 7 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"C'est l'heure de l'Enchanteur ! ","color":"dark_purple","bold":true},{"text":"Toute l'XP de ce métier compte double pendant 30 minutes.","color":"white"}]
execute if score #job m.heure matches 8 run bossbar set metiers:heure name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Heure de l'Explorateur","color":"blue","bold":true},{"text":" : XP x2","color":"white","bold":false}]
execute if score #job m.heure matches 8 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"C'est l'heure de l'Explorateur ! ","color":"blue","bold":true},{"text":"Toute l'XP de ce métier compte double pendant 30 minutes.","color":"white"}]
execute if score #job m.heure matches 9 run bossbar set metiers:heure name [{"text":""},{"text": "", "font": "metiers:icones", "color": "white", "bold": false},{"text":" Heure du Marchand","color":"dark_green","bold":true},{"text":" : XP x2","color":"white","bold":false}]
execute if score #job m.heure matches 9 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"C'est l'heure du Marchand ! ","color":"dark_green","bold":true},{"text":"Toute l'XP de ce métier compte double pendant 30 minutes.","color":"white"}]
bossbar set metiers:heure visible true
bossbar set metiers:heure players @a
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 1 1
