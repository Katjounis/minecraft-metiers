scoreboard players set #job m.heure 0
bossbar set metiers:heure visible false
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"text":"L'heure du métier est terminée. Prochaine dans 1 h 30.","color":"gray"}]
