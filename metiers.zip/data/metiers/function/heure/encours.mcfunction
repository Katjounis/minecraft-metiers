scoreboard players remove #reste m.heure 1
execute store result bossbar metiers:heure value run scoreboard players get #reste m.heure
bossbar set metiers:heure players @a
execute if score #reste m.heure matches ..0 run function metiers:heure/fin
