scoreboard players operation @s m.tmp = @s m.n_prev
scoreboard players operation @s m.tmp -= @s m.n_now
execute if score @s m.tmp matches ..0 run scoreboard players set @s m.tmp 1
execute if score @s m.tmp matches 4.. run scoreboard players set @s m.tmp 3
scoreboard players operation @s m.tmp *= #20 m.const
scoreboard players operation @s m.n_bal += @s m.tmp
