execute store result score @s m.tmp run clear @s minecraft:lapis_lazuli 0
execute if score @s m.tmp matches ..15 run give @s minecraft:lapis_lazuli 8
