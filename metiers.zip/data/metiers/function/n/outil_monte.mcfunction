scoreboard players operation @s m.tmp = @s m.n_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.n_out >= @s m.tmp run return 0
scoreboard players operation @s m.n_out = @s m.tmp
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" fait évoluer son outil d'Enchanteur !","color":"dark_purple","bold":true}]
function metiers:n/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton nouvel outil d'Enchanteur est dans ton inventaire (l'ancien a été remplacé).","color":"yellow"}]
