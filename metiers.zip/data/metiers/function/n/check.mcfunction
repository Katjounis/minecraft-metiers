scoreboard players operation @s m.n_need = @s m.n_lvl
scoreboard players operation @s m.n_need *= #10 m.const
scoreboard players operation @s m.n_need += #40 m.const
execute if score @s m.n_lvl matches ..99 if score @s m.n_xp >= @s m.n_need run function metiers:n/levelup
