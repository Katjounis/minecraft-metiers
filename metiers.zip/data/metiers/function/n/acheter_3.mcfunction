execute if entity @s[tag=metiers.sk.n3] run return run function metiers:n/arbre
function metiers:n/points
execute unless entity @s[tag=metiers.sk.n1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Érudit.","color":"red"}]
execute unless entity @s[tag=metiers.sk.n1] run return run function metiers:n/arbre
execute if score @s m.tmp matches ..11 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (12 requis).","color":"red"}]
execute if score @s m.tmp matches ..11 run return run function metiers:n/arbre
scoreboard players add @s m.n_spent 12
tag @s add metiers.sk.n3
advancement grant @s only metiers:n/competence_3
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Lapis éternel","color":"dark_purple","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:n/arbre
