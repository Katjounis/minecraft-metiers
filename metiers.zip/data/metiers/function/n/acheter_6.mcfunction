execute if entity @s[tag=metiers.sk.n6] run return run function metiers:n/arbre
function metiers:n/points
execute unless entity @s[tag=metiers.sk.n4,tag=metiers.sk.n5] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Économe + Grimoire perdu.","color":"red"}]
execute unless entity @s[tag=metiers.sk.n4,tag=metiers.sk.n5] run return run function metiers:n/arbre
execute if score @s m.tmp matches ..31 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (32 requis).","color":"red"}]
execute if score @s m.tmp matches ..31 run return run function metiers:n/arbre
scoreboard players add @s m.n_spent 32
tag @s add metiers.sk.n6
advancement grant @s only metiers:n/competence_6
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Archimage","color":"dark_purple","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:n/arbre
