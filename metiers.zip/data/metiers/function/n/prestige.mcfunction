execute if score @s m.n_lvl matches ..99 run return 0
execute if score @s m.n_pr matches 5.. run return 0
scoreboard players add @s m.n_pr 1
scoreboard players set @s m.n_lvl 1
scoreboard players set @s m.n_xp 0
scoreboard players set @s m.n_need 50
scoreboard players set @s m.n_spent 0
scoreboard players set @s m.n_pal 0
tag @s remove metiers.sk.n1
tag @s remove metiers.sk.n2
tag @s remove metiers.sk.n3
tag @s remove metiers.sk.n4
tag @s remove metiers.sk.n5
tag @s remove metiers.sk.n6
advancement revoke @s from metiers:n/competence_1
advancement revoke @s from metiers:n/niveau_10
tag @s add metiers.maj
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" passe ","color":"gray"},{"text":"★ Prestige ","color":"gold","bold":true},{"score":{"name":"@s","objective":"m.n_pr"},"color":"gold","bold":true},{"text":" en Enchanteur !","color":"dark_purple","bold":true}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 0.8
playsound minecraft:entity.firework_rocket.large_blast master @a ~ ~ ~ 1 1
particle minecraft:totem_of_undying ~ ~1 ~ 0.6 1.2 0.6 0.5 200
particle minecraft:end_rod ~ ~1 ~ 0.4 1 0.4 0.15 80
