scoreboard players operation @s m.tmp = @s m.n_lvl
scoreboard players remove @s m.tmp 1
scoreboard players operation @s m.tmp -= @s m.n_spent
