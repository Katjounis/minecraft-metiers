execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"n"}] run item replace entity @s weapon.offhand with minecraft:air
execute if items entity @s armor.feet *[minecraft:custom_data~{metiers_outil:"n"}] run item replace entity @s armor.feet with minecraft:air
clear @s *[minecraft:custom_data~{metiers_outil:"n"}]
scoreboard players add @s m.n_ser 1
execute store result storage metiers:tmp o int 1 run scoreboard players get @s m.id
execute store result storage metiers:tmp s int 1 run scoreboard players get @s m.n_ser
function metiers:n/outil_donner_m with storage metiers:tmp
playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.6 1.4
