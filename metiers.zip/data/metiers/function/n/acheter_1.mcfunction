execute if entity @s[tag=metiers.sk.n1] run return run function metiers:n/arbre
function metiers:n/points
execute if score @s m.tmp matches ..5 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (6 requis).","color":"red"}]
execute if score @s m.tmp matches ..5 run return run function metiers:n/arbre
scoreboard players add @s m.n_spent 6
tag @s add metiers.sk.n1
advancement grant @s only metiers:n/competence_1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Érudit","color":"dark_purple","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:n/arbre
