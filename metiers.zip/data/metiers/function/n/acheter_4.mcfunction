execute if entity @s[tag=metiers.sk.n4] run return run function metiers:n/arbre
function metiers:n/points
execute unless entity @s[tag=metiers.sk.n2] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Lapidaire.","color":"red"}]
execute unless entity @s[tag=metiers.sk.n2] run return run function metiers:n/arbre
execute if score @s m.tmp matches ..15 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (16 requis).","color":"red"}]
execute if score @s m.tmp matches ..15 run return run function metiers:n/arbre
scoreboard players add @s m.n_spent 16
tag @s add metiers.sk.n4
advancement grant @s only metiers:n/competence_4
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Économe","color":"dark_purple","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:n/arbre
