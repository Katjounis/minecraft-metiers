scoreboard players operation @s m.n_xp -= @s m.n_need
scoreboard players add @s m.n_lvl 1
xp add @s 2 levels
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
tellraw @a [{"selector":"@s","color":"white"},{"text":" passe ","color":"gray"},{"text":"Enchanteur","color":"dark_purple"},{"text":" niveau ","color":"gray"},{"score":{"name":"@s","objective":"m.n_lvl"},"color":"yellow"}]
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"+1 point de compétence Enchanteur.","color":"yellow"}]
execute if score @s m.n_lvl matches 10 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "white", "text": "Initié Enchanteur"}]
execute if score @s m.n_lvl matches 20 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "dark_purple", "text": "Compagnon Enchanteur"}]
execute if score @s m.n_lvl matches 30 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "dark_purple", "bold": true, "text": "Artisan Enchanteur"}]
execute if score @s m.n_lvl matches 40 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "yellow", "bold": true, "text": "Expert Enchanteur"}]
execute if score @s m.n_lvl matches 50 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "gold", "bold": true, "text": "Vétéran Enchanteur"}]
execute if score @s m.n_lvl matches 60 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "red", "bold": true, "text": "Maître Enchanteur"}]
execute if score @s m.n_lvl matches 70 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "light_purple", "bold": true, "text": "Grand Maître Enchanteur"}]
execute if score @s m.n_lvl matches 80 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "dark_purple", "bold": true, "text": "Légend'Enchanteur"}]
execute if score @s m.n_lvl matches 90 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "aqua", "bold": true, "text": "Mythique Enchanteur"}]
execute if score @s m.n_lvl matches 100 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "dark_red", "bold": true, "text": "Dieu Enchanteur"}]
tag @s add metiers.maj
execute if score @s m.n_lvl matches 100 run scoreboard players set @s m.n_xp 0
execute if score @s m.n_lvl matches 10 run function metiers:appel {f:"n/outil_monte"}
execute if score @s m.n_lvl matches 10 run function metiers:recompenses
execute if score @s m.n_lvl matches 20 run function metiers:appel {f:"n/outil_monte"}
execute if score @s m.n_lvl matches 20 run function metiers:recompenses
execute if score @s m.n_lvl matches 30 run function metiers:appel {f:"n/outil_monte"}
execute if score @s m.n_lvl matches 30 run function metiers:recompenses
execute if score @s m.n_lvl matches 40 run function metiers:appel {f:"n/outil_monte"}
execute if score @s m.n_lvl matches 40 run function metiers:recompenses
execute if score @s m.n_lvl matches 50 run function metiers:appel {f:"n/outil_monte"}
execute if score @s m.n_lvl matches 50 run function metiers:recompenses
execute if score @s m.n_lvl matches 60 run function metiers:appel {f:"n/outil_monte"}
execute if score @s m.n_lvl matches 60 run function metiers:recompenses
execute if score @s m.n_lvl matches 70 run function metiers:appel {f:"n/outil_monte"}
execute if score @s m.n_lvl matches 70 run function metiers:recompenses
execute if score @s m.n_lvl matches 80 run function metiers:appel {f:"n/outil_monte"}
execute if score @s m.n_lvl matches 80 run function metiers:recompenses
execute if score @s m.n_lvl matches 90 run function metiers:appel {f:"n/outil_monte"}
execute if score @s m.n_lvl matches 90 run function metiers:recompenses
execute if score @s m.n_lvl matches 100 run function metiers:appel {f:"n/outil_monte"}
execute if score @s m.n_lvl matches 100 run function metiers:recompenses
execute if score @s m.n_lvl matches 10 run advancement grant @s only metiers:n/niveau_10
execute if score @s m.n_lvl matches 20 run advancement grant @s only metiers:n/niveau_20
execute if score @s m.n_lvl matches 30 run advancement grant @s only metiers:n/niveau_30
execute if score @s m.n_lvl matches 40 run advancement grant @s only metiers:n/niveau_40
execute if score @s m.n_lvl matches 50 run advancement grant @s only metiers:n/niveau_50
execute if score @s m.n_lvl matches 60 run advancement grant @s only metiers:n/niveau_60
execute if score @s m.n_lvl matches 70 run advancement grant @s only metiers:n/niveau_70
execute if score @s m.n_lvl matches 80 run advancement grant @s only metiers:n/niveau_80
execute if score @s m.n_lvl matches 90 run advancement grant @s only metiers:n/niveau_90
execute if score @s m.n_lvl matches 100 run advancement grant @s only metiers:n/niveau_100
function metiers:n/check
