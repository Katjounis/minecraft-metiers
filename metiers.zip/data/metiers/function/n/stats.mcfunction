# Anti-triche : poser ou jeter l'objet retire l'XP gagnée
execute if entity @s[tag=metiers.sk.n1] if score @s s.n.ench matches 1.. run xp add @s 1 levels
execute if entity @s[tag=metiers.sk.n4] if score @s s.n.ench matches 1.. run xp add @s 1 levels
execute if entity @s[tag=metiers.sk.n2] if score @s s.n.ench matches 1.. run give @s minecraft:lapis_lazuli 4
execute if entity @s[tag=metiers.sk.n5] if score @s s.n.ench matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.n5] if score @s s.n.ench matches 1.. if score #r m.tmp matches ..15 run loot give @s loot minecraft:chests/stronghold_library
scoreboard players operation @s m.tmp = @s s.n.ench
scoreboard players operation @s m.tmp *= #25 m.const
scoreboard players operation @s m.n_bal += @s m.tmp
scoreboard players set @s s.n.ench 0
scoreboard players operation @s m.tmp = @s s.n.shelf
scoreboard players operation @s m.tmp *= #4 m.const
scoreboard players operation @s m.n_bal += @s m.tmp
scoreboard players set @s s.n.shelf 0
execute if score @s m.n_bal matches 1.. run function metiers:n/gain
