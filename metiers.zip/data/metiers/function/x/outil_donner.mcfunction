tag @s remove metiers.o_main
tag @s remove metiers.o_off
tag @s remove metiers.o_feet
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_outil:"x"}] run tag @s add metiers.o_main
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"x"}] run tag @s add metiers.o_off
execute if items entity @s armor.feet *[minecraft:custom_data~{metiers_outil:"x"}] run tag @s add metiers.o_feet
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"x"}] run item replace entity @s weapon.offhand with minecraft:air
execute if items entity @s armor.feet *[minecraft:custom_data~{metiers_outil:"x"}] run item replace entity @s armor.feet with minecraft:air
clear @s *[minecraft:custom_data~{metiers_outil:"x"}]
scoreboard players add @s m.x_ser 1
execute store result storage metiers:tmp o int 1 run scoreboard players get @s m.id
execute store result storage metiers:tmp s int 1 run scoreboard players get @s m.x_ser
function metiers:x/outil_donner_m with storage metiers:tmp
tag @s remove metiers.o_main
tag @s remove metiers.o_off
tag @s remove metiers.o_feet
playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.6 1.4
