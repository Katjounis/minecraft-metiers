scoreboard players operation @s m.gain = @s m.x_bal
scoreboard players set @s m.x_bal 0
scoreboard players operation @s m.tmp = @s m.gain
scoreboard players operation @s m.tmp *= @s m.x_pr
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.gain += @s m.tmp
execute if score #job m.heure matches 8 run scoreboard players operation @s m.gain *= #2 m.const
execute if score @s m.x_lvl matches 100.. run return 0
scoreboard players operation @s m.x_xp += @s m.gain
function metiers:x/check
title @s actionbar [{"text":"+","color":"green"},{"score":{"name":"@s","objective":"m.gain"},"color":"green"},{"text":" XP Explorateur","color":"blue"},{"text":"  |  niv ","color":"gray"},{"score":{"name":"@s","objective":"m.x_lvl"},"color":"white"},{"text":"  (","color":"gray"},{"score":{"name":"@s","objective":"m.x_xp"},"color":"white"},{"text":"/","color":"gray"},{"score":{"name":"@s","objective":"m.x_need"},"color":"white"},{"text":")","color":"gray"}]
