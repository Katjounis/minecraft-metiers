scoreboard players operation @s m.tmp = @s m.x_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.x_out >= @s m.tmp run return 0
scoreboard players operation @s m.x_out = @s m.tmp
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" fait évoluer son outil d'Explorateur !","color":"blue","bold":true}]
function metiers:x/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton nouvel outil d'Explorateur est dans ton inventaire (l'ancien a été remplacé).","color":"yellow"}]
