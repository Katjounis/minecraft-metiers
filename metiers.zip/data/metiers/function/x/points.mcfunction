scoreboard players operation @s m.tmp = @s m.x_lvl
scoreboard players remove @s m.tmp 1
scoreboard players operation @s m.tmp -= @s m.x_spent
