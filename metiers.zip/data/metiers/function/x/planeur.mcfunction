execute store result score @s m.tmp run data get entity @s FallDistance
execute if score @s m.tmp matches 6.. run effect give @s minecraft:slow_falling 2 0 true
