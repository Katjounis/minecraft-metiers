# Anti-triche : poser ou jeter l'objet retire l'XP gagnée
scoreboard players operation @s m.x_acc += @s s.x.walk_one_cm
scoreboard players set @s s.x.walk_one_cm 0
scoreboard players operation @s m.x_acc += @s s.x.sprint_one_cm
scoreboard players set @s s.x.sprint_one_cm 0
scoreboard players operation @s m.x_acc += @s s.x.crouch_one_cm
scoreboard players set @s s.x.crouch_one_cm 0
scoreboard players operation @s s.x.aviate_one_cm /= #3 m.const
scoreboard players operation @s m.x_acc += @s s.x.aviate_one_cm
scoreboard players set @s s.x.aviate_one_cm 0
scoreboard players operation @s s.x.horse_one_cm /= #2 m.const
scoreboard players operation @s m.x_acc += @s s.x.horse_one_cm
scoreboard players set @s s.x.horse_one_cm 0
scoreboard players operation @s m.x_acc += @s s.x.climb_one_cm
scoreboard players set @s s.x.climb_one_cm 0
scoreboard players operation @s m.tmp = @s m.x_acc
scoreboard players operation @s m.tmp /= #20000 m.const
scoreboard players operation @s m.tmp *= #20 m.const
scoreboard players operation @s m.x_bal += @s m.tmp
scoreboard players operation @s m.x_acc %= #20000 m.const
execute if score @s m.x_bal matches 1.. run function metiers:x/gain
