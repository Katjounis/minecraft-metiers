execute if entity @s[tag=metiers.sk.x3] run return run function metiers:x/arbre
function metiers:x/points
execute unless entity @s[tag=metiers.sk.x1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Pas léger.","color":"red"}]
execute unless entity @s[tag=metiers.sk.x1] run return run function metiers:x/arbre
execute if score @s m.tmp matches ..11 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (12 requis).","color":"red"}]
execute if score @s m.tmp matches ..11 run return run function metiers:x/arbre
scoreboard players add @s m.x_spent 12
tag @s add metiers.sk.x3
advancement grant @s only metiers:x/competence_3
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Nyctalope","color":"blue","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:x/arbre
