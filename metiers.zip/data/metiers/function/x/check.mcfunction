scoreboard players operation @s m.x_need = @s m.x_lvl
scoreboard players operation @s m.x_need *= #10 m.const
scoreboard players operation @s m.x_need += #40 m.const
execute if score @s m.x_lvl matches ..99 if score @s m.x_xp >= @s m.x_need run function metiers:x/levelup
