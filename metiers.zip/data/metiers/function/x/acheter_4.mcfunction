execute if entity @s[tag=metiers.sk.x4] run return run function metiers:x/arbre
function metiers:x/points
execute unless entity @s[tag=metiers.sk.x2] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Bon pied.","color":"red"}]
execute unless entity @s[tag=metiers.sk.x2] run return run function metiers:x/arbre
execute if score @s m.tmp matches ..15 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (16 requis).","color":"red"}]
execute if score @s m.tmp matches ..15 run return run function metiers:x/arbre
scoreboard players add @s m.x_spent 16
tag @s add metiers.sk.x4
advancement grant @s only metiers:x/competence_4
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Coureur des bois","color":"blue","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:x/arbre
