execute if entity @s[tag=metiers.sk.x1] run return run function metiers:x/arbre
execute unless score @s m.x_lvl matches 5.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 5 en Explorateur.","color":"red"}]
execute unless score @s m.x_lvl matches 5.. run return run function metiers:x/arbre
function metiers:x/points
execute if score @s m.tmp matches ..5 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (6 requis).","color":"red"}]
execute if score @s m.tmp matches ..5 run return run function metiers:x/arbre
scoreboard players add @s m.x_spent 6
tag @s add metiers.sk.x1
advancement grant @s only metiers:x/competence_1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Grand pas","color":"blue","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:x/arbre
