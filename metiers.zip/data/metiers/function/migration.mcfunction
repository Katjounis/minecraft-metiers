tag @s add metiers.v2
attribute @s minecraft:attack_damage modifier remove metiers:chasseur
attribute @s minecraft:luck modifier remove metiers:pecheur
scoreboard players add @s m.b_spent 0
scoreboard players add @s m.b_pal 0
scoreboard players add @s m.f_spent 0
scoreboard players add @s m.f_pal 0
scoreboard players add @s m.m_spent 0
scoreboard players add @s m.m_pal 0
scoreboard players add @s m.c_spent 0
scoreboard players add @s m.c_pal 0
scoreboard players add @s m.p_spent 0
scoreboard players add @s m.p_pal 0
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Nouveau : niveau max 100, arbres de compétences (1 point par niveau déjà gagné) et récompenses de palier à récupérer. Ouvre le menu avec la touche G ou dans le menu Échap.","color":"yellow"}]
function metiers:recompenses
