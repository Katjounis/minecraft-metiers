# Bûcheron
execute if entity @s[tag=metiers.sk.b1] if items entity @s weapon.mainhand #minecraft:axes run effect give @s minecraft:haste 2 0 true
execute if entity @s[tag=metiers.sk.b4] if items entity @s weapon.mainhand #minecraft:axes run effect give @s minecraft:haste 2 1 true
execute if entity @s[tag=metiers.sk.b6] if items entity @s weapon.mainhand #minecraft:axes run effect give @s minecraft:strength 2 0 true
execute if entity @s[tag=metiers.sk.b6] if items entity @s weapon.mainhand #minecraft:axes run effect give @s minecraft:resistance 2 0 true

# Mineur
execute if entity @s[tag=metiers.sk.m1] if items entity @s weapon.mainhand #minecraft:pickaxes run effect give @s minecraft:haste 2 0 true
execute if entity @s[tag=metiers.sk.m4] if items entity @s weapon.mainhand #minecraft:pickaxes run effect give @s minecraft:haste 2 1 true
execute if entity @s[tag=metiers.sk.m6] if items entity @s weapon.mainhand #minecraft:pickaxes run effect give @s minecraft:haste 2 2 true
execute if entity @s[tag=metiers.sk.m2,y=-64,dy=103] run effect give @s minecraft:night_vision 15 0 true
execute if entity @s[tag=metiers.sk.m6,y=-64,dy=103] run effect give @s minecraft:resistance 2 0 true
execute if entity @s[tag=metiers.sk.m5] run function metiers:m/fonte

# Fermier
execute if entity @s[tag=metiers.sk.f1] if items entity @s weapon.mainhand #minecraft:hoes run effect give @s minecraft:speed 2 0 true
execute if entity @s[tag=metiers.sk.f3] if score #t m.timer matches 120 run effect give @s minecraft:saturation 1 0 true
execute if entity @s[tag=metiers.sk.f5] if score #t m.timer matches 120 run function metiers:f/aura
execute if entity @s[tag=metiers.sk.f6] if items entity @s weapon.mainhand #minecraft:hoes run effect give @s minecraft:regeneration 3 0 true

# Chasseur
attribute @s minecraft:attack_damage modifier remove metiers:c1
attribute @s minecraft:attack_damage modifier remove metiers:c5
execute if entity @s[tag=metiers.sk.c1] run attribute @s minecraft:attack_damage modifier add metiers:c1 1 add_value
execute if entity @s[tag=metiers.sk.c5] run attribute @s minecraft:attack_damage modifier add metiers:c5 2 add_value
execute if entity @s[tag=metiers.sk.c2] if items entity @s weapon.mainhand #metiers:epees run effect give @e[type=#metiers:hostiles,distance=..16] minecraft:glowing 2 0 true
execute if entity @s[tag=metiers.sk.c4] run effect give @s minecraft:resistance 2 0 true
execute if entity @s[tag=metiers.sk.c6] if entity @e[type=#metiers:hostiles,distance=..8] run effect give @s minecraft:strength 2 0 true
execute if entity @s[tag=metiers.sk.c6] if entity @e[type=#metiers:hostiles,distance=..8] run effect give @s minecraft:speed 2 0 true

# Pêcheur
attribute @s minecraft:luck modifier remove metiers:p1
attribute @s minecraft:luck modifier remove metiers:p6
execute if entity @s[tag=metiers.sk.p1] run attribute @s minecraft:luck modifier add metiers:p1 2 add_value
execute if entity @s[tag=metiers.sk.p6] run attribute @s minecraft:luck modifier add metiers:p6 3 add_value
execute if entity @s[tag=metiers.sk.p2] if block ~ ~ ~ minecraft:water run effect give @s minecraft:water_breathing 3 0 true
execute if entity @s[tag=metiers.sk.p4] if block ~ ~ ~ minecraft:water run effect give @s minecraft:dolphins_grace 2 0 true
execute if entity @s[tag=metiers.sk.p6] if block ~ ~ ~ minecraft:water run effect give @s minecraft:conduit_power 3 0 true

# Éleveur
execute if entity @s[tag=metiers.sk.e3] run effect give @e[type=#metiers:animaux,distance=..6] minecraft:regeneration 3 0 true
execute if entity @s[tag=metiers.sk.e4] if score #t m.timer matches 120 run effect give @s minecraft:absorption 60 0 true
execute if entity @s[tag=metiers.sk.e5] if score #t m.timer matches 120 run function metiers:e/croissance
execute if entity @s[tag=metiers.sk.e6] on vehicle run effect give @s minecraft:speed 2 1 true
execute if entity @s[tag=metiers.sk.e6] on vehicle run effect give @s minecraft:jump_boost 2 1 true

# Enchanteur
execute if entity @s[tag=metiers.sk.n3] if score #t m.timer matches 120 run function metiers:n/lapis
execute if entity @s[tag=metiers.sk.n6] run effect give @s minecraft:regeneration 3 0 true
execute if entity @s[tag=metiers.sk.n6] run effect give @s minecraft:resistance 2 0 true
execute if entity @s[tag=metiers.sk.n6] run effect give @s minecraft:night_vision 15 0 true

# Explorateur
execute if entity @s[tag=metiers.sk.x1] run effect give @s minecraft:speed 2 0 true
execute if entity @s[tag=metiers.sk.x4] run effect give @s minecraft:speed 2 1 true
execute if entity @s[tag=metiers.sk.x2] run effect give @s minecraft:jump_boost 2 0 true
execute if entity @s[tag=metiers.sk.x3] run effect give @s minecraft:night_vision 15 0 true
execute if entity @s[tag=metiers.sk.x5] run function metiers:x/planeur
execute if entity @s[tag=metiers.sk.x6] run effect give @s minecraft:fire_resistance 3 0 true
execute if entity @s[tag=metiers.sk.x6] run effect give @s minecraft:water_breathing 3 0 true

# Marchand
execute if entity @s[tag=metiers.sk.t2] run effect give @s minecraft:hero_of_the_village 3 0 true
execute if entity @s[tag=metiers.sk.t4] run effect give @s minecraft:hero_of_the_village 3 2 true
execute if entity @s[tag=metiers.sk.t6] run effect give @s minecraft:hero_of_the_village 3 4 true
execute if entity @s[tag=metiers.sk.t5] if entity @e[type=minecraft:villager,distance=..16] run effect give @s minecraft:speed 2 0 true
execute if entity @s[tag=metiers.sk.t5] if entity @e[type=minecraft:villager,distance=..16] run effect give @s minecraft:luck 2 1 true
