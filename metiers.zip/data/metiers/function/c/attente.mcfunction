execute if score @s m.c_pal matches 0 if score @s m.c_lvl matches 10.. run return run function metiers:afficher {j:"c",k:1}
execute if score @s m.c_pal matches 1 if score @s m.c_lvl matches 20.. run return run function metiers:afficher {j:"c",k:2}
execute if score @s m.c_pal matches 2 if score @s m.c_lvl matches 30.. run return run function metiers:afficher {j:"c",k:3}
execute if score @s m.c_pal matches 3 if score @s m.c_lvl matches 40.. run return run function metiers:afficher {j:"c",k:4}
execute if score @s m.c_pal matches 4 if score @s m.c_lvl matches 50.. run return run function metiers:afficher {j:"c",k:5}
execute if score @s m.c_pal matches 5 if score @s m.c_lvl matches 60.. run return run function metiers:afficher {j:"c",k:6}
execute if score @s m.c_pal matches 6 if score @s m.c_lvl matches 70.. run return run function metiers:afficher {j:"c",k:7}
execute if score @s m.c_pal matches 7 if score @s m.c_lvl matches 80.. run return run function metiers:afficher {j:"c",k:8}
execute if score @s m.c_pal matches 8 if score @s m.c_lvl matches 90.. run return run function metiers:afficher {j:"c",k:9}
execute if score @s m.c_pal matches 9 if score @s m.c_lvl matches 100.. run return run function metiers:afficher {j:"c",k:10}
return 0
