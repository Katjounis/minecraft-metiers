execute if entity @s[tag=metiers.sk.c1] run return run function metiers:c/arbre
function metiers:c/points
execute if score @s m.tmp matches ..5 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (6 requis).","color":"red"}]
execute if score @s m.tmp matches ..5 run return run function metiers:c/arbre
scoreboard players add @s m.c_spent 6
tag @s add metiers.sk.c1
advancement grant @s only metiers:c/competence_1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Lame affûtée","color":"red","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:c/arbre
