execute if entity @s[tag=metiers.sk.c4] run return run function metiers:c/arbre
function metiers:c/points
execute unless entity @s[tag=metiers.sk.c2] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Pisteur.","color":"red"}]
execute unless entity @s[tag=metiers.sk.c2] run return run function metiers:c/arbre
execute if score @s m.tmp matches ..15 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (16 requis).","color":"red"}]
execute if score @s m.tmp matches ..15 run return run function metiers:c/arbre
scoreboard players add @s m.c_spent 16
tag @s add metiers.sk.c4
advancement grant @s only metiers:c/competence_4
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Cuir épais","color":"red","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:c/arbre
