scoreboard players operation @s m.gain = @s m.c_bal
scoreboard players set @s m.c_bal 0
scoreboard players operation @s m.tmp = @s m.gain
scoreboard players operation @s m.tmp *= @s m.c_pr
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.gain += @s m.tmp
execute if score #job m.heure matches 4 run scoreboard players operation @s m.gain *= #2 m.const
execute if score @s m.c_lvl matches 100.. run return 0
scoreboard players operation @s m.c_xp += @s m.gain
function metiers:c/check
title @s actionbar [{"text":"+","color":"green"},{"score":{"name":"@s","objective":"m.gain"},"color":"green"},{"text":" XP Chasseur","color":"red"},{"text":"  |  niv ","color":"gray"},{"score":{"name":"@s","objective":"m.c_lvl"},"color":"white"},{"text":"  (","color":"gray"},{"score":{"name":"@s","objective":"m.c_xp"},"color":"white"},{"text":"/","color":"gray"},{"score":{"name":"@s","objective":"m.c_need"},"color":"white"},{"text":")","color":"gray"}]
