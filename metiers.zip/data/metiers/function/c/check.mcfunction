scoreboard players operation @s m.c_need = @s m.c_lvl
scoreboard players operation @s m.c_need *= #10 m.const
scoreboard players operation @s m.c_need += #40 m.const
execute if score @s m.c_lvl matches ..99 if score @s m.c_xp >= @s m.c_need run function metiers:c/levelup
