execute if items entity @s container.* *[minecraft:custom_data~{metiers_arc:1b}] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu as déjà ton arc de Chasseur sur toi.","color":"gray"}]
function metiers:c/arc_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Voici ton arc de Chasseur. Il évolue en même temps que ton épée.","color":"green"}]
