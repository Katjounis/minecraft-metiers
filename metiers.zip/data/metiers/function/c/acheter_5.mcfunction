execute if entity @s[tag=metiers.sk.c5] run return run function metiers:c/arbre
function metiers:c/points
execute unless entity @s[tag=metiers.sk.c3] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Soif de sang.","color":"red"}]
execute unless entity @s[tag=metiers.sk.c3] run return run function metiers:c/arbre
execute if score @s m.tmp matches ..23 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (24 requis).","color":"red"}]
execute if score @s m.tmp matches ..23 run return run function metiers:c/arbre
scoreboard players add @s m.c_spent 24
tag @s add metiers.sk.c5
advancement grant @s only metiers:c/competence_5
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Bourreau","color":"red","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:c/arbre
