# Anti-triche : poser ou jeter l'objet retire l'XP gagnée
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.kills matches 1.. run effect give @s minecraft:regeneration 3 1 true
scoreboard players operation @s m.tmp = @s s.c.kills
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.kills 0
scoreboard players operation @s m.tmp = @s s.c.k.wither
scoreboard players operation @s m.tmp *= #300 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.wither 0
scoreboard players operation @s m.tmp = @s s.c.k.ender_dragon
scoreboard players operation @s m.tmp *= #500 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.ender_dragon 0
scoreboard players operation @s m.tmp = @s s.c.k.warden
scoreboard players operation @s m.tmp *= #150 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.warden 0
scoreboard players operation @s m.tmp = @s s.c.k.elder_guardian
scoreboard players operation @s m.tmp *= #60 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.elder_guardian 0
execute if score @s m.c_bal matches 1.. run function metiers:c/gain
