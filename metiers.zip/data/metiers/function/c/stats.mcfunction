scoreboard players operation @s m.b0 = @s m.c_bal
# Anti-triche : poser ou jeter l'objet retire l'XP gagnée
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.chicken matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.chicken matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/chicken
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.chicken matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.c_bal += @s s.c.k.chicken
scoreboard players set @s s.c.k.chicken 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.cow matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.cow matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/cow
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.cow matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.c_bal += @s s.c.k.cow
scoreboard players set @s s.c.k.cow 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.pig matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.pig matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/pig
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.pig matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.c_bal += @s s.c.k.pig
scoreboard players set @s s.c.k.pig 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.sheep matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.sheep matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/sheep
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.sheep matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.c_bal += @s s.c.k.sheep
scoreboard players set @s s.c.k.sheep 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.rabbit matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.rabbit matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/rabbit
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.rabbit matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.c_bal += @s s.c.k.rabbit
scoreboard players set @s s.c.k.rabbit 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.goat matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.goat matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/goat
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.goat matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.c_bal += @s s.c.k.goat
scoreboard players set @s s.c.k.goat 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.mooshroom matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.mooshroom matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/mooshroom
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.mooshroom matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.c_bal += @s s.c.k.mooshroom
scoreboard players set @s s.c.k.mooshroom 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.silverfish matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.silverfish matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/silverfish
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.silverfish matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.c_bal += @s s.c.k.silverfish
scoreboard players set @s s.c.k.silverfish 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.slime matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.slime matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/slime
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.slime matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.c_bal += @s s.c.k.slime
scoreboard players set @s s.c.k.slime 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.magma_cube matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.magma_cube matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/magma_cube
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.magma_cube matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.c_bal += @s s.c.k.magma_cube
scoreboard players set @s s.c.k.magma_cube 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.zombie matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.zombie matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/zombie
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.zombie matches 1.. run effect give @s minecraft:instant_health 1 0 true
execute if entity @s[tag=metiers.sk.c5] if score @s s.c.k.zombie matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c5] if score @s s.c.k.zombie matches 1.. if score #r m.tmp matches ..3 run give @s minecraft:zombie_head 1
scoreboard players operation @s m.tmp = @s s.c.k.zombie
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.zombie 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.husk matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.husk matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/husk
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.husk matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.husk
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.husk 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.zombie_villager matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.zombie_villager matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/zombie_villager
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.zombie_villager matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.zombie_villager
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.zombie_villager 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.spider matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.spider matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/spider
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.spider matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.spider
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.spider 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.piglin matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.piglin matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/piglin
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.piglin matches 1.. run effect give @s minecraft:instant_health 1 0 true
execute if entity @s[tag=metiers.sk.c5] if score @s s.c.k.piglin matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c5] if score @s s.c.k.piglin matches 1.. if score #r m.tmp matches ..3 run give @s minecraft:piglin_head 1
scoreboard players operation @s m.tmp = @s s.c.k.piglin
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.piglin 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.zombified_piglin matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.zombified_piglin matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/zombified_piglin
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.zombified_piglin matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.c_bal += @s s.c.k.zombified_piglin
scoreboard players set @s s.c.k.zombified_piglin 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.drowned matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.drowned matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/drowned
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.drowned matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.drowned
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.drowned 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.skeleton matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.skeleton matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/skeleton
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.skeleton matches 1.. run effect give @s minecraft:instant_health 1 0 true
execute if entity @s[tag=metiers.sk.c5] if score @s s.c.k.skeleton matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c5] if score @s s.c.k.skeleton matches 1.. if score #r m.tmp matches ..3 run give @s minecraft:skeleton_skull 1
scoreboard players operation @s m.tmp = @s s.c.k.skeleton
scoreboard players operation @s m.tmp *= #4 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.skeleton 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.cave_spider matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.cave_spider matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/cave_spider
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.cave_spider matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.cave_spider
scoreboard players operation @s m.tmp *= #4 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.cave_spider 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.vex matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.vex matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/vex
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.vex matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.vex
scoreboard players operation @s m.tmp *= #4 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.vex 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.stray matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.stray matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/stray
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.stray matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.stray
scoreboard players operation @s m.tmp *= #5 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.stray 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.bogged matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.bogged matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/bogged
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.bogged matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.bogged
scoreboard players operation @s m.tmp *= #5 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.bogged 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.creeper matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.creeper matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/creeper
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.creeper matches 1.. run effect give @s minecraft:instant_health 1 0 true
execute if entity @s[tag=metiers.sk.c5] if score @s s.c.k.creeper matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c5] if score @s s.c.k.creeper matches 1.. if score #r m.tmp matches ..3 run give @s minecraft:creeper_head 1
scoreboard players operation @s m.tmp = @s s.c.k.creeper
scoreboard players operation @s m.tmp *= #5 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.creeper 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.phantom matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.phantom matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/phantom
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.phantom matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.phantom
scoreboard players operation @s m.tmp *= #6 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.phantom 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.pillager matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.pillager matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/pillager
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.pillager matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.pillager
scoreboard players operation @s m.tmp *= #6 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.pillager 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.witch matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.witch matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/witch
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.witch matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.witch
scoreboard players operation @s m.tmp *= #5 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.witch 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.enderman matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.enderman matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/enderman
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.enderman matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.enderman
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.enderman 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.blaze matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.blaze matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/blaze
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.blaze matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.blaze
scoreboard players operation @s m.tmp *= #5 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.blaze 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.guardian matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.guardian matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/guardian
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.guardian matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.guardian
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.guardian 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.hoglin matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.hoglin matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/hoglin
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.hoglin matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.hoglin
scoreboard players operation @s m.tmp *= #7 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.hoglin 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.creaking matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.creaking matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/creaking
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.creaking matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.creaking
scoreboard players operation @s m.tmp *= #8 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.creaking 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.vindicator matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.vindicator matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/vindicator
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.vindicator matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.vindicator
scoreboard players operation @s m.tmp *= #9 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.vindicator 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.shulker matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.shulker matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/shulker
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.shulker matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.shulker
scoreboard players operation @s m.tmp *= #9 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.shulker 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.zoglin matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.zoglin matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/zoglin
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.zoglin matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.zoglin
scoreboard players operation @s m.tmp *= #9 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.zoglin 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.ghast matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.ghast matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/ghast
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.ghast matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.ghast
scoreboard players operation @s m.tmp *= #11 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.ghast 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.wither_skeleton matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.wither_skeleton matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/wither_skeleton
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.wither_skeleton matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.wither_skeleton
scoreboard players operation @s m.tmp *= #11 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.wither_skeleton 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.breeze matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.breeze matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/breeze
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.breeze matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.breeze
scoreboard players operation @s m.tmp *= #11 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.breeze 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.piglin_brute matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.piglin_brute matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/piglin_brute
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.piglin_brute matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.piglin_brute
scoreboard players operation @s m.tmp *= #13 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.piglin_brute 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.evoker matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.evoker matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/evoker
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.evoker matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.evoker
scoreboard players operation @s m.tmp *= #15 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.evoker 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.ravager matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.k.ravager matches 1.. if score #r m.tmp matches ..25 run loot give @s loot minecraft:entities/ravager
execute if entity @s[tag=metiers.sk.c6] if score @s s.c.k.ravager matches 1.. run effect give @s minecraft:instant_health 1 0 true
scoreboard players operation @s m.tmp = @s s.c.k.ravager
scoreboard players operation @s m.tmp *= #21 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.ravager 0
scoreboard players set @s s.c.kills 0
scoreboard players operation @s m.tmp = @s s.c.k.wither
scoreboard players operation @s m.tmp *= #200 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.wither 0
scoreboard players operation @s m.tmp = @s s.c.k.ender_dragon
scoreboard players operation @s m.tmp *= #300 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.ender_dragon 0
scoreboard players operation @s m.tmp = @s s.c.k.warden
scoreboard players operation @s m.tmp *= #100 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.warden 0
scoreboard players operation @s m.tmp = @s s.c.k.elder_guardian
scoreboard players operation @s m.tmp *= #45 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.elder_guardian 0
scoreboard players operation @s m.tmp = @s m.c_bal
scoreboard players operation @s m.tmp -= @s m.b0
execute if score @s m.afk matches 240.. if score @s m.tmp matches 1.. run scoreboard players operation @s m.c_bal = @s m.b0
execute if score @s m.afk matches 240.. run scoreboard players set @s m.tmp 0
execute if score @s m.c_bal matches 1.. run function metiers:c/gain
