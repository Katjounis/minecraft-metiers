# Anti-triche : poser ou jeter l'objet retire l'XP gagnée
scoreboard players operation @s m.c_bal += @s s.c.k.chicken
scoreboard players set @s s.c.k.chicken 0
scoreboard players operation @s m.c_bal += @s s.c.k.cow
scoreboard players set @s s.c.k.cow 0
scoreboard players operation @s m.c_bal += @s s.c.k.pig
scoreboard players set @s s.c.k.pig 0
scoreboard players operation @s m.c_bal += @s s.c.k.sheep
scoreboard players set @s s.c.k.sheep 0
scoreboard players operation @s m.c_bal += @s s.c.k.rabbit
scoreboard players set @s s.c.k.rabbit 0
scoreboard players operation @s m.c_bal += @s s.c.k.goat
scoreboard players set @s s.c.k.goat 0
scoreboard players operation @s m.c_bal += @s s.c.k.mooshroom
scoreboard players set @s s.c.k.mooshroom 0
scoreboard players operation @s m.c_bal += @s s.c.k.silverfish
scoreboard players set @s s.c.k.silverfish 0
scoreboard players operation @s m.c_bal += @s s.c.k.slime
scoreboard players set @s s.c.k.slime 0
scoreboard players operation @s m.c_bal += @s s.c.k.magma_cube
scoreboard players set @s s.c.k.magma_cube 0
scoreboard players operation @s m.c_bal += @s s.c.k.endermite
scoreboard players set @s s.c.k.endermite 0
scoreboard players operation @s m.c_bal += @s s.c.k.iron_golem
scoreboard players set @s s.c.k.iron_golem 0
scoreboard players operation @s m.c_bal += @s s.c.k.zombified_piglin
scoreboard players set @s s.c.k.zombified_piglin 0
scoreboard players operation @s m.tmp = @s s.c.k.zombie
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.zombie 0
scoreboard players operation @s m.tmp = @s s.c.k.husk
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.husk 0
scoreboard players operation @s m.tmp = @s s.c.k.zombie_villager
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.zombie_villager 0
scoreboard players operation @s m.tmp = @s s.c.k.spider
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.spider 0
scoreboard players operation @s m.tmp = @s s.c.k.piglin
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.piglin 0
scoreboard players operation @s m.tmp = @s s.c.k.drowned
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.drowned 0
scoreboard players operation @s m.tmp = @s s.c.k.vex
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.vex 0
scoreboard players operation @s m.tmp = @s s.c.k.guardian
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.guardian 0
scoreboard players operation @s m.tmp = @s s.c.k.enderman
scoreboard players operation @s m.tmp *= #2 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.enderman 0
scoreboard players operation @s m.tmp = @s s.c.k.skeleton
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.skeleton 0
scoreboard players operation @s m.tmp = @s s.c.k.cave_spider
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.cave_spider 0
scoreboard players operation @s m.tmp = @s s.c.k.stray
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.stray 0
scoreboard players operation @s m.tmp = @s s.c.k.bogged
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.bogged 0
scoreboard players operation @s m.tmp = @s s.c.k.creeper
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.creeper 0
scoreboard players operation @s m.tmp = @s s.c.k.blaze
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.blaze 0
scoreboard players operation @s m.tmp = @s s.c.k.pillager
scoreboard players operation @s m.tmp *= #3 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.pillager 0
scoreboard players operation @s m.tmp = @s s.c.k.phantom
scoreboard players operation @s m.tmp *= #4 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.phantom 0
scoreboard players operation @s m.tmp = @s s.c.k.hoglin
scoreboard players operation @s m.tmp *= #4 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.hoglin 0
scoreboard players operation @s m.tmp = @s s.c.k.witch
scoreboard players operation @s m.tmp *= #5 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.witch 0
scoreboard players operation @s m.tmp = @s s.c.k.zoglin
scoreboard players operation @s m.tmp *= #5 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.zoglin 0
scoreboard players operation @s m.tmp = @s s.c.k.creaking
scoreboard players operation @s m.tmp *= #5 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.creaking 0
scoreboard players operation @s m.tmp = @s s.c.k.shulker
scoreboard players operation @s m.tmp *= #6 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.shulker 0
scoreboard players operation @s m.tmp = @s s.c.k.vindicator
scoreboard players operation @s m.tmp *= #6 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.vindicator 0
scoreboard players operation @s m.tmp = @s s.c.k.ghast
scoreboard players operation @s m.tmp *= #6 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.ghast 0
scoreboard players operation @s m.tmp = @s s.c.k.wither_skeleton
scoreboard players operation @s m.tmp *= #6 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.wither_skeleton 0
scoreboard players operation @s m.tmp = @s s.c.k.breeze
scoreboard players operation @s m.tmp *= #6 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.breeze 0
scoreboard players operation @s m.tmp = @s s.c.k.piglin_brute
scoreboard players operation @s m.tmp *= #8 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.piglin_brute 0
scoreboard players operation @s m.tmp = @s s.c.k.evoker
scoreboard players operation @s m.tmp *= #10 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.evoker 0
scoreboard players operation @s m.tmp = @s s.c.k.ravager
scoreboard players operation @s m.tmp *= #12 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.ravager 0
execute if entity @s[tag=metiers.sk.c3] if score @s s.c.kills matches 1.. run effect give @s minecraft:regeneration 3 1 true
scoreboard players operation @s m.tmp = @s s.c.kills
scoreboard players operation @s m.tmp *= #0 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.kills 0
scoreboard players operation @s m.tmp = @s s.c.k.wither
scoreboard players operation @s m.tmp *= #100 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.wither 0
scoreboard players operation @s m.tmp = @s s.c.k.ender_dragon
scoreboard players operation @s m.tmp *= #150 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.ender_dragon 0
scoreboard players operation @s m.tmp = @s s.c.k.warden
scoreboard players operation @s m.tmp *= #60 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.warden 0
scoreboard players operation @s m.tmp = @s s.c.k.elder_guardian
scoreboard players operation @s m.tmp *= #30 m.const
scoreboard players operation @s m.c_bal += @s m.tmp
scoreboard players set @s s.c.k.elder_guardian 0
execute if score @s m.c_bal matches 1.. run function metiers:c/gain
