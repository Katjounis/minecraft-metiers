scoreboard players operation @s m.tmp = @s m.c_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.c_out >= @s m.tmp run return 0
scoreboard players operation @s m.c_out = @s m.tmp
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" fait évoluer son outil de Chasseur !","color":"red","bold":true}]
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"c"}] run return run function metiers:c/outil_donner
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"c"}] run return run function metiers:c/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton outil de Chasseur a évolué : récupère-le avec G, Chasseur, « Récupérer mon outil ».","color":"yellow"}]
