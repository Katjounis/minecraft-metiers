scoreboard players operation @s m.tmp = @s m.c_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.c_out >= @s m.tmp run return 0
scoreboard players operation @s m.c_out = @s m.tmp
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" fait évoluer son outil de Chasseur !","color":"red","bold":true}]
function metiers:c/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton nouvel outil de Chasseur est dans ton inventaire (l'ancien a été remplacé).","color":"yellow"}]
