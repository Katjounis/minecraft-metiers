execute if entity @s[tag=metiers.sk.c6] run return run function metiers:c/arbre
function metiers:c/points
execute unless entity @s[tag=metiers.sk.c4,tag=metiers.sk.c5] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Cuir épais + Bourreau.","color":"red"}]
execute unless entity @s[tag=metiers.sk.c4,tag=metiers.sk.c5] run return run function metiers:c/arbre
execute if score @s m.tmp matches ..31 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (32 requis).","color":"red"}]
execute if score @s m.tmp matches ..31 run return run function metiers:c/arbre
scoreboard players add @s m.c_spent 32
tag @s add metiers.sk.c6
advancement grant @s only metiers:c/competence_6
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Prédateur","color":"red","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:c/arbre
