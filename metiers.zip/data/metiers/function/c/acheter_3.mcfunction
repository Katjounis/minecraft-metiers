execute if entity @s[tag=metiers.sk.c3] run return run function metiers:c/arbre
function metiers:c/points
execute unless entity @s[tag=metiers.sk.c1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Lame affûtée.","color":"red"}]
execute unless entity @s[tag=metiers.sk.c1] run return run function metiers:c/arbre
execute if score @s m.tmp matches ..11 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (12 requis).","color":"red"}]
execute if score @s m.tmp matches ..11 run return run function metiers:c/arbre
scoreboard players add @s m.c_spent 12
tag @s add metiers.sk.c3
advancement grant @s only metiers:c/competence_3
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Soif de sang","color":"red","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:c/arbre
