tag @s remove metiers.arc_main
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{metiers_arc:1b}] run tag @s add metiers.arc_main
clear @s *[minecraft:custom_data~{metiers_arc:1b}]
execute store result storage metiers:tmp o int 1 run scoreboard players get @s m.id
function metiers:c/arc_donner_m with storage metiers:tmp
tag @s remove metiers.arc_main
