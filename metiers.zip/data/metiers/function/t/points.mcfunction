scoreboard players operation @s m.tmp = @s m.t_lvl
scoreboard players remove @s m.tmp 1
scoreboard players operation @s m.tmp -= @s m.t_spent
