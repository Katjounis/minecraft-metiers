execute if entity @s[tag=metiers.sk.t5] run return run function metiers:t/arbre
function metiers:t/points
execute unless entity @s[tag=metiers.sk.t3] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Marché noir.","color":"red"}]
execute unless entity @s[tag=metiers.sk.t3] run return run function metiers:t/arbre
execute if score @s m.tmp matches ..23 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (24 requis).","color":"red"}]
execute if score @s m.tmp matches ..23 run return run function metiers:t/arbre
scoreboard players add @s m.t_spent 24
tag @s add metiers.sk.t5
advancement grant @s only metiers:t/competence_5
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Caravane","color":"dark_green","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:t/arbre
