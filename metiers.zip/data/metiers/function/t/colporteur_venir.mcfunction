scoreboard players set @s m.colp 0
summon minecraft:wandering_trader ~3 ~ ~3 {DespawnDelay:24000}
spreadplayers ~ ~ 2 6 false @e[type=minecraft:wandering_trader,distance=..6,limit=1,sort=nearest]
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Un marchand ambulant passe près de toi.","color":"dark_green"}]
