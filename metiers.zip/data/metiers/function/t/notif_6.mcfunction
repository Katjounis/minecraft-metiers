playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Récompense du palier 60 Marchand disponible ! ","color":"yellow"},{"text":"[Récupérer]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger metiers set 209"}}]
