scoreboard players add @s m.colp 1
execute if score @s m.colp matches 4800.. unless entity @e[type=minecraft:wandering_trader,distance=..64] run function metiers:t/colporteur_venir
