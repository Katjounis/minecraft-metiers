execute if entity @s[tag=metiers.sk.t6] run return run function metiers:t/arbre
function metiers:t/points
execute unless entity @s[tag=metiers.sk.t4,tag=metiers.sk.t5] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Notable + Caravane.","color":"red"}]
execute unless entity @s[tag=metiers.sk.t4,tag=metiers.sk.t5] run return run function metiers:t/arbre
execute if score @s m.tmp matches ..31 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (32 requis).","color":"red"}]
execute if score @s m.tmp matches ..31 run return run function metiers:t/arbre
scoreboard players add @s m.t_spent 32
tag @s add metiers.sk.t6
advancement grant @s only metiers:t/competence_6
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Magnat","color":"dark_green","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:t/arbre
