execute if score @s m.pref matches 9 run scoreboard players set @s m.trig 10
execute unless score @s m.pref matches 9 run scoreboard players set @s m.trig 19
function metiers:prefixe/choisir
function metiers:t/arbre
