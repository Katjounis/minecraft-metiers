# Anti-triche : poser ou jeter l'objet retire l'XP gagnée
execute if entity @s[tag=metiers.sk.t1] if score @s s.t.trade matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.t1] if score @s s.t.trade matches 1.. if score #r m.tmp matches ..20 run give @s minecraft:emerald 1
execute if entity @s[tag=metiers.sk.t3] if score @s s.t.trade matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.t3] if score @s s.t.trade matches 1.. if score #r m.tmp matches ..10 run give @s minecraft:diamond 1
execute if entity @s[tag=metiers.sk.t6] if score @s s.t.trade matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.t6] if score @s s.t.trade matches 1.. if score #r m.tmp matches ..5 run give @s minecraft:netherite_scrap 1
scoreboard players operation @s m.tmp = @s s.t.trade
scoreboard players operation @s m.tmp *= #6 m.const
scoreboard players operation @s m.t_bal += @s m.tmp
scoreboard players set @s s.t.trade 0
execute if score @s m.t_bal matches 1.. run function metiers:t/gain
