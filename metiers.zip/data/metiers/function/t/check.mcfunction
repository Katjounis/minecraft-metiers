scoreboard players operation @s m.t_need = @s m.t_lvl
scoreboard players operation @s m.t_need *= #10 m.const
scoreboard players operation @s m.t_need += #40 m.const
execute if score @s m.t_lvl matches ..99 if score @s m.t_xp >= @s m.t_need run function metiers:t/levelup
