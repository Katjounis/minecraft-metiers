execute if entity @s[tag=metiers.sk.t1] run return run function metiers:t/arbre
function metiers:t/points
execute if score @s m.tmp matches ..5 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (6 requis).","color":"red"}]
execute if score @s m.tmp matches ..5 run return run function metiers:t/arbre
scoreboard players add @s m.t_spent 6
tag @s add metiers.sk.t1
advancement grant @s only metiers:t/competence_1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Pourboire","color":"dark_green","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:t/arbre
