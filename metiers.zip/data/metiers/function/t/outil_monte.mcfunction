scoreboard players operation @s m.tmp = @s m.t_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.t_out >= @s m.tmp run return 0
scoreboard players operation @s m.t_out = @s m.tmp
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" fait évoluer son outil de Marchand !","color":"dark_green","bold":true}]
function metiers:t/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton nouvel outil de Marchand est dans ton inventaire (l'ancien a été remplacé).","color":"yellow"}]
