execute if entity @s[tag=metiers.sk.t3] run return run function metiers:t/arbre
function metiers:t/points
execute unless entity @s[tag=metiers.sk.t1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Pourboire.","color":"red"}]
execute unless entity @s[tag=metiers.sk.t1] run return run function metiers:t/arbre
execute if score @s m.tmp matches ..11 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (12 requis).","color":"red"}]
execute if score @s m.tmp matches ..11 run return run function metiers:t/arbre
scoreboard players add @s m.t_spent 12
tag @s add metiers.sk.t3
advancement grant @s only metiers:t/competence_3
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Marché noir","color":"dark_green","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:t/arbre
