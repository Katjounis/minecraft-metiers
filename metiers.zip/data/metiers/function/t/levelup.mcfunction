scoreboard players operation @s m.t_xp -= @s m.t_need
scoreboard players add @s m.t_lvl 1
xp add @s 2 levels
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
tellraw @a [{"selector":"@s","color":"white"},{"text":" passe ","color":"gray"},{"text":"Marchand","color":"dark_green"},{"text":" niveau ","color":"gray"},{"score":{"name":"@s","objective":"m.t_lvl"},"color":"yellow"}]
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"+1 point de compétence Marchand.","color":"yellow"}]
execute if score @s m.t_lvl matches 10 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "white", "text": "Initié Marchand"}]
execute if score @s m.t_lvl matches 20 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "dark_green", "text": "Compagnon Marchand"}]
execute if score @s m.t_lvl matches 30 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "dark_green", "bold": true, "text": "Artisan Marchand"}]
execute if score @s m.t_lvl matches 40 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "yellow", "bold": true, "text": "Expert Marchand"}]
execute if score @s m.t_lvl matches 50 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "gold", "bold": true, "text": "Vétéran Marchand"}]
execute if score @s m.t_lvl matches 60 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "red", "bold": true, "text": "Maître Marchand"}]
execute if score @s m.t_lvl matches 70 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "light_purple", "bold": true, "text": "Grand Maître Marchand"}]
execute if score @s m.t_lvl matches 80 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "dark_purple", "bold": true, "text": "Légende Marchand"}]
execute if score @s m.t_lvl matches 90 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "aqua", "bold": true, "text": "Mythique Marchand"}]
execute if score @s m.t_lvl matches 100 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "dark_red", "bold": true, "text": "Dieu Marchand"}]
tag @s add metiers.maj
execute if score @s m.t_lvl matches 100 run scoreboard players set @s m.t_xp 0
execute if score @s m.t_lvl matches 10 run function metiers:appel {f:"t/outil_monte"}
execute if score @s m.t_lvl matches 10 run function metiers:recompenses
execute if score @s m.t_lvl matches 20 run function metiers:appel {f:"t/outil_monte"}
execute if score @s m.t_lvl matches 20 run function metiers:recompenses
execute if score @s m.t_lvl matches 30 run function metiers:appel {f:"t/outil_monte"}
execute if score @s m.t_lvl matches 30 run function metiers:recompenses
execute if score @s m.t_lvl matches 40 run function metiers:appel {f:"t/outil_monte"}
execute if score @s m.t_lvl matches 40 run function metiers:recompenses
execute if score @s m.t_lvl matches 50 run function metiers:appel {f:"t/outil_monte"}
execute if score @s m.t_lvl matches 50 run function metiers:recompenses
execute if score @s m.t_lvl matches 60 run function metiers:appel {f:"t/outil_monte"}
execute if score @s m.t_lvl matches 60 run function metiers:recompenses
execute if score @s m.t_lvl matches 70 run function metiers:appel {f:"t/outil_monte"}
execute if score @s m.t_lvl matches 70 run function metiers:recompenses
execute if score @s m.t_lvl matches 80 run function metiers:appel {f:"t/outil_monte"}
execute if score @s m.t_lvl matches 80 run function metiers:recompenses
execute if score @s m.t_lvl matches 90 run function metiers:appel {f:"t/outil_monte"}
execute if score @s m.t_lvl matches 90 run function metiers:recompenses
execute if score @s m.t_lvl matches 100 run function metiers:appel {f:"t/outil_monte"}
execute if score @s m.t_lvl matches 100 run function metiers:recompenses
execute if score @s m.t_lvl matches 10 run advancement grant @s only metiers:t/niveau_10
execute if score @s m.t_lvl matches 20 run advancement grant @s only metiers:t/niveau_20
execute if score @s m.t_lvl matches 30 run advancement grant @s only metiers:t/niveau_30
execute if score @s m.t_lvl matches 40 run advancement grant @s only metiers:t/niveau_40
execute if score @s m.t_lvl matches 50 run advancement grant @s only metiers:t/niveau_50
execute if score @s m.t_lvl matches 60 run advancement grant @s only metiers:t/niveau_60
execute if score @s m.t_lvl matches 70 run advancement grant @s only metiers:t/niveau_70
execute if score @s m.t_lvl matches 80 run advancement grant @s only metiers:t/niveau_80
execute if score @s m.t_lvl matches 90 run advancement grant @s only metiers:t/niveau_90
execute if score @s m.t_lvl matches 100 run advancement grant @s only metiers:t/niveau_100
function metiers:t/check
