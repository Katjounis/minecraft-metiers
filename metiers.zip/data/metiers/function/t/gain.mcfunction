scoreboard players operation @s m.gain = @s m.t_bal
scoreboard players set @s m.t_bal 0
scoreboard players operation @s m.tmp = @s m.gain
scoreboard players operation @s m.tmp *= @s m.t_pr
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.gain += @s m.tmp
execute if score #job m.heure matches 9 run scoreboard players operation @s m.gain *= #2 m.const
execute if score @s m.t_lvl matches 100.. run return 0
scoreboard players operation @s m.t_xp += @s m.gain
function metiers:t/check
title @s actionbar [{"text":"+","color":"green"},{"score":{"name":"@s","objective":"m.gain"},"color":"green"},{"text":" XP Marchand","color":"dark_green"},{"text":"  |  niv ","color":"gray"},{"score":{"name":"@s","objective":"m.t_lvl"},"color":"white"},{"text":"  (","color":"gray"},{"score":{"name":"@s","objective":"m.t_xp"},"color":"white"},{"text":"/","color":"gray"},{"score":{"name":"@s","objective":"m.t_need"},"color":"white"},{"text":")","color":"gray"}]
