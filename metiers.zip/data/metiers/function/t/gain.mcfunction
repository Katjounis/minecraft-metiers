scoreboard players operation @s m.gain = @s m.t_bal
scoreboard players set @s m.t_bal 0
scoreboard players operation @s m.tmp = @s m.gain
scoreboard players operation @s m.tmp *= @s m.t_pr
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.gain += @s m.tmp
execute if score #job m.heure matches 9 run scoreboard players operation @s m.gain *= #2 m.const
execute if score @s m.csag_t matches 1 run function metiers:refonte/sagesse
execute if score @s m.ceco_t matches 1 store result score #r m.tmp run random value 1..100
execute if score @s m.ceco_t matches 1 if score #r m.tmp matches ..5 run scoreboard players add @s m.cr_t 1
execute if score @s m.t_lvl matches 100.. run return 0
scoreboard players operation @s m.t_xp += @s m.gain
function metiers:t/check
title @s actionbar [{"text":"+","color":"green"},{"score":{"name":"@s","objective":"m.gain"},"color":"green"},{"text":" XP Marchand","color":"dark_green"},{"text":"  |  niv ","color":"gray"},{"score":{"name":"@s","objective":"m.t_lvl"},"color":"white"},{"text":"  (","color":"gray"},{"score":{"name":"@s","objective":"m.t_xp"},"color":"white"},{"text":"/","color":"gray"},{"score":{"name":"@s","objective":"m.t_need"},"color":"white"},{"text":")","color":"gray"}]
