execute if entity @s[tag=metiers.sk.t2] run return run function metiers:t/arbre
function metiers:t/points
execute unless entity @s[tag=metiers.sk.t1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Pourboire.","color":"red"}]
execute unless entity @s[tag=metiers.sk.t1] run return run function metiers:t/arbre
execute if score @s m.tmp matches ..7 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (8 requis).","color":"red"}]
execute if score @s m.tmp matches ..7 run return run function metiers:t/arbre
scoreboard players add @s m.t_spent 8
tag @s add metiers.sk.t2
advancement grant @s only metiers:t/competence_2
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Réputation","color":"dark_green","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:t/arbre
