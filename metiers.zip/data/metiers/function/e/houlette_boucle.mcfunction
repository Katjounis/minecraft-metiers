execute if score #n m.tmp >= #max m.tmp run return 0
execute unless entity @e[type=#metiers:animaux,distance=..10,predicate=!metiers:suit_moi] run return 0
execute as @e[type=#metiers:animaux,distance=..10,sort=nearest,limit=1,predicate=!metiers:suit_moi] run function metiers:e/houlette_prendre
function metiers:e/houlette_boucle
