execute as @e[type=#metiers:animaux,distance=..6] store result score @s m.tmp run data get entity @s Age
execute as @e[type=#metiers:animaux,distance=..6] if score @s m.tmp matches 2.. store result entity @s Age int 0.5 run scoreboard players get @s m.tmp
