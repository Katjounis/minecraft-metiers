scoreboard players operation @s m.e_need = @s m.e_lvl
scoreboard players operation @s m.e_need *= #10 m.const
scoreboard players operation @s m.e_need += #40 m.const
execute if score @s m.e_lvl matches ..99 if score @s m.e_xp >= @s m.e_need run function metiers:e/levelup
