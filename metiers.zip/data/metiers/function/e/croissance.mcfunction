execute as @e[type=#metiers:animaux,distance=..8] store result score @s m.tmp run data get entity @s Age
execute as @e[type=#metiers:animaux,distance=..8] if score @s m.tmp matches ..-2 run data modify entity @s Age set value -1
particle minecraft:happy_villager ~ ~1 ~ 4 1 4 0 30
