execute if entity @s[tag=metiers.sk.e3] run return run function metiers:e/arbre
function metiers:e/points
execute unless entity @s[tag=metiers.sk.e1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Berger.","color":"red"}]
execute unless entity @s[tag=metiers.sk.e1] run return run function metiers:e/arbre
execute if score @s m.tmp matches ..11 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (12 requis).","color":"red"}]
execute if score @s m.tmp matches ..11 run return run function metiers:e/arbre
scoreboard players add @s m.e_spent 12
tag @s add metiers.sk.e3
advancement grant @s only metiers:e/competence_3
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Ami des bêtes","color":"light_purple","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:e/arbre
