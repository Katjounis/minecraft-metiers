execute unless items entity @s container.* *[minecraft:custom_data~{metiers_outil:"e"}] unless items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"e"}] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu dois avoir ton outil d'Éleveur sur toi pour le réparer.","color":"red"}]
execute if score @s m.e_out matches 5.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton outil est déjà incassable.","color":"green"}]
execute unless entity @s[level=5..] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il te faut 5 niveaux d’XP pour réparer ton outil.","color":"red"}]
xp add @s -5 levels
function metiers:e/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton outil d'Éleveur est comme neuf.","color":"green"}]
