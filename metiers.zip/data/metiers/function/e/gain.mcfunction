scoreboard players operation @s m.gain = @s m.e_bal
scoreboard players set @s m.e_bal 0
scoreboard players operation @s m.tmp = @s m.gain
scoreboard players operation @s m.tmp *= @s m.e_pr
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.gain += @s m.tmp
execute if score #job m.heure matches 6 run scoreboard players operation @s m.gain *= #2 m.const
execute if score @s m.csag_e matches 1 run function metiers:refonte/sagesse
execute if score @s m.ceco_e matches 1 store result score #r m.tmp run random value 1..100
execute if score @s m.ceco_e matches 1 if score #r m.tmp matches ..5 run scoreboard players add @s m.cr_e 1
execute if score @s m.e_lvl matches 100.. run return 0
scoreboard players operation @s m.e_xp += @s m.gain
function metiers:e/check
title @s actionbar [{"text":"+","color":"green"},{"score":{"name":"@s","objective":"m.gain"},"color":"green"},{"text":" XP Éleveur","color":"light_purple"},{"text":"  |  niv ","color":"gray"},{"score":{"name":"@s","objective":"m.e_lvl"},"color":"white"},{"text":"  (","color":"gray"},{"score":{"name":"@s","objective":"m.e_xp"},"color":"white"},{"text":"/","color":"gray"},{"score":{"name":"@s","objective":"m.e_need"},"color":"white"},{"text":")","color":"gray"}]
