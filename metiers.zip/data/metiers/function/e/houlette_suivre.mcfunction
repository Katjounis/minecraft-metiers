scoreboard players operation #pid m.tmp = @s m.id
execute as @e[type=#metiers:animaux,distance=..48] if score @s m.own = #pid m.tmp at @s unless entity @p[distance=..3] facing entity @p feet run tp @s ^ ^ ^0.28
