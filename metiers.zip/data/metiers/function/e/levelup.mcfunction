scoreboard players operation @s m.e_xp -= @s m.e_need
scoreboard players add @s m.e_lvl 1
xp add @s 30 points
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
tellraw @a [{"selector":"@s","color":"white"},{"text":" passe ","color":"gray"},{"text":"Éleveur","color":"light_purple"},{"text":" niveau ","color":"gray"},{"score":{"name":"@s","objective":"m.e_lvl"},"color":"yellow"}]
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"+1 point de compétence Éleveur.","color":"yellow"}]
execute if score @s m.e_lvl matches 10 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "white", "text": "Initié Éleveur"}]
execute if score @s m.e_lvl matches 20 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "light_purple", "text": "Compagnon Éleveur"}]
execute if score @s m.e_lvl matches 30 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "light_purple", "bold": true, "text": "Artisan Éleveur"}]
execute if score @s m.e_lvl matches 40 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "yellow", "bold": true, "text": "Expert Éleveur"}]
execute if score @s m.e_lvl matches 50 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "gold", "bold": true, "text": "Vétéran Éleveur"}]
execute if score @s m.e_lvl matches 60 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "red", "bold": true, "text": "Maître Éleveur"}]
execute if score @s m.e_lvl matches 70 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "light_purple", "bold": true, "text": "Grand Maître Éleveur"}]
execute if score @s m.e_lvl matches 80 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "dark_purple", "bold": true, "text": "Légend'Éleveur"}]
execute if score @s m.e_lvl matches 90 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "aqua", "bold": true, "text": "Mythique Éleveur"}]
execute if score @s m.e_lvl matches 100 run tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque le titre ","color":"gray"},{"color": "dark_red", "bold": true, "text": "Dieu Éleveur"}]
tag @s add metiers.maj
execute if score @s m.e_lvl matches 100 run scoreboard players set @s m.e_xp 0
execute if score @s m.e_lvl matches 10 run function metiers:appel {f:"e/outil_monte"}
execute if score @s m.e_lvl matches 10 run function metiers:recompenses
execute if score @s m.e_lvl matches 20 run function metiers:appel {f:"e/outil_monte"}
execute if score @s m.e_lvl matches 20 run function metiers:recompenses
execute if score @s m.e_lvl matches 30 run function metiers:appel {f:"e/outil_monte"}
execute if score @s m.e_lvl matches 30 run function metiers:recompenses
execute if score @s m.e_lvl matches 40 run function metiers:appel {f:"e/outil_monte"}
execute if score @s m.e_lvl matches 40 run function metiers:recompenses
execute if score @s m.e_lvl matches 50 run function metiers:appel {f:"e/outil_monte"}
execute if score @s m.e_lvl matches 50 run function metiers:recompenses
execute if score @s m.e_lvl matches 60 run function metiers:appel {f:"e/outil_monte"}
execute if score @s m.e_lvl matches 60 run function metiers:recompenses
execute if score @s m.e_lvl matches 70 run function metiers:appel {f:"e/outil_monte"}
execute if score @s m.e_lvl matches 70 run function metiers:recompenses
execute if score @s m.e_lvl matches 80 run function metiers:appel {f:"e/outil_monte"}
execute if score @s m.e_lvl matches 80 run function metiers:recompenses
execute if score @s m.e_lvl matches 90 run function metiers:appel {f:"e/outil_monte"}
execute if score @s m.e_lvl matches 90 run function metiers:recompenses
execute if score @s m.e_lvl matches 100 run function metiers:appel {f:"e/outil_monte"}
execute if score @s m.e_lvl matches 100 run function metiers:recompenses
execute if score @s m.e_lvl matches 10 run advancement grant @s only metiers:e/niveau_10
execute if score @s m.e_lvl matches 20 run advancement grant @s only metiers:e/niveau_20
execute if score @s m.e_lvl matches 30 run advancement grant @s only metiers:e/niveau_30
execute if score @s m.e_lvl matches 40 run advancement grant @s only metiers:e/niveau_40
execute if score @s m.e_lvl matches 50 run advancement grant @s only metiers:e/niveau_50
execute if score @s m.e_lvl matches 60 run advancement grant @s only metiers:e/niveau_60
execute if score @s m.e_lvl matches 70 run advancement grant @s only metiers:e/niveau_70
execute if score @s m.e_lvl matches 80 run advancement grant @s only metiers:e/niveau_80
execute if score @s m.e_lvl matches 90 run advancement grant @s only metiers:e/niveau_90
execute if score @s m.e_lvl matches 100 run advancement grant @s only metiers:e/niveau_100
function metiers:e/check
