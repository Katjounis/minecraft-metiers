scoreboard players operation @s m.own = #pid m.tmp
scoreboard players add #n m.tmp 1
particle minecraft:heart ~ ~1 ~ 0.3 0.3 0.3 0 2
