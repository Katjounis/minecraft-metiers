execute if score @s m.pref matches 6 run scoreboard players set @s m.trig 10
execute unless score @s m.pref matches 6 run scoreboard players set @s m.trig 16
function metiers:prefixe/choisir
function metiers:e/arbre
