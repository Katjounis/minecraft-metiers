execute if entity @s[tag=metiers.sk.e1] run return run function metiers:e/arbre
function metiers:e/points
execute if score @s m.tmp matches ..5 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (6 requis).","color":"red"}]
execute if score @s m.tmp matches ..5 run return run function metiers:e/arbre
scoreboard players add @s m.e_spent 6
tag @s add metiers.sk.e1
advancement grant @s only metiers:e/competence_1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Berger","color":"light_purple","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:e/arbre
