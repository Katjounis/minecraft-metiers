execute if entity @s[tag=metiers.sk.e6] run return run function metiers:e/arbre
function metiers:e/points
execute unless entity @s[tag=metiers.sk.e4,tag=metiers.sk.e5] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Vitalité + Croissance rapide.","color":"red"}]
execute unless entity @s[tag=metiers.sk.e4,tag=metiers.sk.e5] run return run function metiers:e/arbre
execute if score @s m.tmp matches ..31 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (32 requis).","color":"red"}]
execute if score @s m.tmp matches ..31 run return run function metiers:e/arbre
scoreboard players add @s m.e_spent 32
tag @s add metiers.sk.e6
advancement grant @s only metiers:e/competence_6
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Cavalier légendaire","color":"light_purple","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:e/arbre
