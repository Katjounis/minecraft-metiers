scoreboard players operation #pid m.tmp = @s m.id
scoreboard players set #n m.tmp 0
execute as @e[type=#metiers:animaux,distance=..48] if score @s m.own = #pid m.tmp run scoreboard players add #n m.tmp 1
execute if score #n m.tmp matches 1.. as @e[type=#metiers:animaux,distance=..48] if score @s m.own = #pid m.tmp run scoreboard players reset @s m.own
execute if score #n m.tmp matches 1.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Les animaux ne te suivent plus.","color":"gray"}]
scoreboard players set #n m.tmp 0
execute if score @s m.e_out matches 0 run scoreboard players set #max m.tmp 2
execute if score @s m.e_out matches 1 run scoreboard players set #max m.tmp 3
execute if score @s m.e_out matches 2 run scoreboard players set #max m.tmp 3
execute if score @s m.e_out matches 3 run scoreboard players set #max m.tmp 4
execute if score @s m.e_out matches 4 run scoreboard players set #max m.tmp 4
execute if score @s m.e_out matches 5 run scoreboard players set #max m.tmp 5
execute if score @s m.e_out matches 6 run scoreboard players set #max m.tmp 5
execute if score @s m.e_out matches 7 run scoreboard players set #max m.tmp 6
execute if score @s m.e_out matches 8 run scoreboard players set #max m.tmp 6
execute if score @s m.e_out matches 9 run scoreboard players set #max m.tmp 7
execute if score @s m.e_out matches 10 run scoreboard players set #max m.tmp 8
function metiers:e/houlette_boucle
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"score":{"name":"#n","objective":"m.tmp"},"color":"yellow"},{"text":" animaux te suivent. Clic droit à nouveau pour les libérer.","color":"light_purple"}]
playsound minecraft:block.note_block.bell master @a ~ ~ ~ 0.8 1.6
