scoreboard players operation @s m.tmp = @s m.e_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.e_out >= @s m.tmp run return 0
scoreboard players operation @s m.e_out = @s m.tmp
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" fait évoluer son outil d'Éleveur !","color":"light_purple","bold":true}]
function metiers:e/outil_donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ton nouvel outil d'Éleveur est dans ton inventaire (l'ancien a été remplacé).","color":"yellow"}]
