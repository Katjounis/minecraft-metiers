scoreboard players operation @s m.b0 = @s m.e_bal
# Anti-triche : poser ou jeter l'objet retire l'XP gagnée
execute if entity @s[tag=metiers.sk.e3] if score @s s.e.bred matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e3] if score @s s.e.bred matches 1.. if score #r m.tmp matches ..30 run give @s minecraft:leather 2
scoreboard players operation @s m.tmp = @s s.e.bred
scoreboard players operation @s m.tmp *= #16 m.const
scoreboard players operation @s m.e_raw += @s m.tmp
scoreboard players set @s s.e.bred 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.white matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.white matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:white_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.white
scoreboard players set @s s.e.pu.white 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.white
scoreboard players set @s s.e.dr.white 0
scoreboard players operation @s m.e_raw -= @s s.e.us.white
scoreboard players set @s s.e.us.white 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.black matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.black matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:black_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.black
scoreboard players set @s s.e.pu.black 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.black
scoreboard players set @s s.e.dr.black 0
scoreboard players operation @s m.e_raw -= @s s.e.us.black
scoreboard players set @s s.e.us.black 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.gray matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.gray matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:gray_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.gray
scoreboard players set @s s.e.pu.gray 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.gray
scoreboard players set @s s.e.dr.gray 0
scoreboard players operation @s m.e_raw -= @s s.e.us.gray
scoreboard players set @s s.e.us.gray 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.light_gray matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.light_gray matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:light_gray_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.light_gray
scoreboard players set @s s.e.pu.light_gray 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.light_gray
scoreboard players set @s s.e.dr.light_gray 0
scoreboard players operation @s m.e_raw -= @s s.e.us.light_gray
scoreboard players set @s s.e.us.light_gray 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.brown matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.brown matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:brown_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.brown
scoreboard players set @s s.e.pu.brown 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.brown
scoreboard players set @s s.e.dr.brown 0
scoreboard players operation @s m.e_raw -= @s s.e.us.brown
scoreboard players set @s s.e.us.brown 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.red matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.red matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:red_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.red
scoreboard players set @s s.e.pu.red 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.red
scoreboard players set @s s.e.dr.red 0
scoreboard players operation @s m.e_raw -= @s s.e.us.red
scoreboard players set @s s.e.us.red 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.orange matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.orange matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:orange_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.orange
scoreboard players set @s s.e.pu.orange 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.orange
scoreboard players set @s s.e.dr.orange 0
scoreboard players operation @s m.e_raw -= @s s.e.us.orange
scoreboard players set @s s.e.us.orange 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.yellow matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.yellow matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:yellow_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.yellow
scoreboard players set @s s.e.pu.yellow 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.yellow
scoreboard players set @s s.e.dr.yellow 0
scoreboard players operation @s m.e_raw -= @s s.e.us.yellow
scoreboard players set @s s.e.us.yellow 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.lime matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.lime matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:lime_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.lime
scoreboard players set @s s.e.pu.lime 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.lime
scoreboard players set @s s.e.dr.lime 0
scoreboard players operation @s m.e_raw -= @s s.e.us.lime
scoreboard players set @s s.e.us.lime 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.green matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.green matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:green_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.green
scoreboard players set @s s.e.pu.green 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.green
scoreboard players set @s s.e.dr.green 0
scoreboard players operation @s m.e_raw -= @s s.e.us.green
scoreboard players set @s s.e.us.green 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.cyan matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.cyan matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:cyan_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.cyan
scoreboard players set @s s.e.pu.cyan 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.cyan
scoreboard players set @s s.e.dr.cyan 0
scoreboard players operation @s m.e_raw -= @s s.e.us.cyan
scoreboard players set @s s.e.us.cyan 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.light_blue matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.light_blue matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:light_blue_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.light_blue
scoreboard players set @s s.e.pu.light_blue 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.light_blue
scoreboard players set @s s.e.dr.light_blue 0
scoreboard players operation @s m.e_raw -= @s s.e.us.light_blue
scoreboard players set @s s.e.us.light_blue 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.blue matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.blue matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:blue_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.blue
scoreboard players set @s s.e.pu.blue 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.blue
scoreboard players set @s s.e.dr.blue 0
scoreboard players operation @s m.e_raw -= @s s.e.us.blue
scoreboard players set @s s.e.us.blue 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.purple matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.purple matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:purple_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.purple
scoreboard players set @s s.e.pu.purple 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.purple
scoreboard players set @s s.e.dr.purple 0
scoreboard players operation @s m.e_raw -= @s s.e.us.purple
scoreboard players set @s s.e.us.purple 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.magenta matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.magenta matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:magenta_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.magenta
scoreboard players set @s s.e.pu.magenta 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.magenta
scoreboard players set @s s.e.dr.magenta 0
scoreboard players operation @s m.e_raw -= @s s.e.us.magenta
scoreboard players set @s s.e.us.magenta 0
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.pink matches 1.. store result score #r m.tmp run random value 1..100
execute if entity @s[tag=metiers.sk.e1] if score @s s.e.pu.pink matches 1.. if score #r m.tmp matches ..25 run give @s minecraft:pink_wool 2
scoreboard players operation @s m.e_raw += @s s.e.pu.pink
scoreboard players set @s s.e.pu.pink 0
scoreboard players operation @s m.e_raw -= @s s.e.dr.pink
scoreboard players set @s s.e.dr.pink 0
scoreboard players operation @s m.e_raw -= @s s.e.us.pink
scoreboard players set @s s.e.us.pink 0
execute if score @s m.e_raw matches 2.. run scoreboard players operation @s m.tmp = @s m.e_raw
execute if score @s m.e_raw matches 2.. run scoreboard players operation @s m.tmp /= #2 m.const
execute if score @s m.e_raw matches 2.. run scoreboard players operation @s m.e_bal += @s m.tmp
execute if score @s m.e_raw matches 2.. run scoreboard players operation @s m.tmp *= #2 m.const
execute if score @s m.e_raw matches 2.. run scoreboard players operation @s m.e_raw -= @s m.tmp
scoreboard players operation @s m.tmp = @s m.e_bal
scoreboard players operation @s m.tmp -= @s m.b0
execute if score @s m.e_bal matches 1.. run function metiers:e/gain
