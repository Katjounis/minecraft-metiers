execute if entity @s[tag=metiers.sk.e4] run return run function metiers:e/arbre
function metiers:e/points
execute unless entity @s[tag=metiers.sk.e2] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Tanneur.","color":"red"}]
execute unless entity @s[tag=metiers.sk.e2] run return run function metiers:e/arbre
execute if score @s m.tmp matches ..15 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (16 requis).","color":"red"}]
execute if score @s m.tmp matches ..15 run return run function metiers:e/arbre
scoreboard players add @s m.e_spent 16
tag @s add metiers.sk.e4
advancement grant @s only metiers:e/competence_4
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Vitalité","color":"light_purple","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:e/arbre
