tag @s add metiers.v13
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"b"}] run function metiers:b/outil_donner
execute if items entity @s armor.* *[minecraft:custom_data~{metiers_outil:"b"}] run function metiers:b/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"f"}] run function metiers:f/outil_donner
execute if items entity @s armor.* *[minecraft:custom_data~{metiers_outil:"f"}] run function metiers:f/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"m"}] run function metiers:m/outil_donner
execute if items entity @s armor.* *[minecraft:custom_data~{metiers_outil:"m"}] run function metiers:m/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"c"}] run function metiers:c/outil_donner
execute if items entity @s armor.* *[minecraft:custom_data~{metiers_outil:"c"}] run function metiers:c/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"p"}] run function metiers:p/outil_donner
execute if items entity @s armor.* *[minecraft:custom_data~{metiers_outil:"p"}] run function metiers:p/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"e"}] run function metiers:e/outil_donner
execute if items entity @s armor.* *[minecraft:custom_data~{metiers_outil:"e"}] run function metiers:e/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"n"}] run function metiers:n/outil_donner
execute if items entity @s armor.* *[minecraft:custom_data~{metiers_outil:"n"}] run function metiers:n/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"x"}] run function metiers:x/outil_donner
execute if items entity @s armor.* *[minecraft:custom_data~{metiers_outil:"x"}] run function metiers:x/outil_donner
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"t"}] run function metiers:t/outil_donner
execute if items entity @s armor.* *[minecraft:custom_data~{metiers_outil:"t"}] run function metiers:t/outil_donner
execute if score @s m.arm matches 1.. run function metiers:armure/donner
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tes outils et ton armure de métier ont reçu un numéro de série : les copies ne marchent plus.","color":"yellow"}]
