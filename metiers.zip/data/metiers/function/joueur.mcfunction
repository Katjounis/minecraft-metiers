execute unless entity @s[tag=metiers.v2] run function metiers:migration
execute unless entity @s[tag=metiers.v3] run function metiers:succes_sync
execute unless entity @s[tag=metiers.v5] run function metiers:relance_paliers
execute unless entity @s[tag=metiers.v4] run function metiers:connexion
tag @s add metiers.v4
execute if score @s m.quit matches 1.. run function metiers:connexion
execute unless score @s m.id matches 1.. run function metiers:id
execute unless entity @s[tag=metiers.v7] run function metiers:migration6
execute unless entity @s[tag=metiers.v9] run function metiers:appel {f:"migration8"}
execute unless entity @s[tag=metiers.v13] run function metiers:appel {f:"migration13"}
execute unless entity @s[tag=metiers.v22] run function metiers:appel {f:"migration22"}
execute if score @s m.b_cd matches 1.. run scoreboard players remove @s m.b_cd 1
execute if score @s m.f_cd matches 1.. run scoreboard players remove @s m.f_cd 1
execute if score @s m.m_cd matches 1.. run scoreboard players remove @s m.m_cd 1
execute if score @s m.c_cd matches 1.. run scoreboard players remove @s m.c_cd 1
execute if score @s m.p_cd matches 1.. run scoreboard players remove @s m.p_cd 1
execute if score @s m.e_cd matches 1.. run scoreboard players remove @s m.e_cd 1
execute if score @s m.n_cd matches 1.. run scoreboard players remove @s m.n_cd 1
execute if score @s m.x_cd matches 1.. run scoreboard players remove @s m.x_cd 1
execute if score @s m.t_cd matches 1.. run scoreboard players remove @s m.t_cd 1
execute if score #quatre m.timer matches 0 run function metiers:appel {f:"outil/check"}
execute if score #pair m.timer matches 0 run function metiers:appel {f:"defis/joueur"}
function metiers:appel {f:"armure/bonus"}
execute if score #quatre m.timer matches 0 run function metiers:appel {f:"securite/check"}
execute if score @s m.acd matches 1.. run scoreboard players remove @s m.acd 1
execute if score #soixante m.timer matches 0 run function metiers:appel {f:"classement/maj"}
execute unless score @s m.b_lvl matches 1.. run function metiers:b/init
execute unless score @s m.f_lvl matches 1.. run function metiers:f/init
execute unless score @s m.m_lvl matches 1.. run function metiers:m/init
execute unless score @s m.c_lvl matches 1.. run function metiers:c/init
execute unless score @s m.p_lvl matches 1.. run function metiers:p/init
execute unless score @s m.e_lvl matches 1.. run function metiers:e/init
execute unless score @s m.n_lvl matches 1.. run function metiers:n/init
execute unless score @s m.x_lvl matches 1.. run function metiers:x/init
execute unless score @s m.t_lvl matches 1.. run function metiers:t/init
function metiers:b/stats
function metiers:f/stats
function metiers:m/stats
function metiers:c/stats
function metiers:p/stats
function metiers:e/stats
function metiers:n/stats
function metiers:x/stats
function metiers:t/stats
function metiers:bonus
scoreboard players add @s m.pref 0
scoreboard players enable @s metiers
execute if entity @s[tag=metiers.maj] run function metiers:prefixe/maj
