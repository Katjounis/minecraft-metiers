schedule clear metiers:loop
execute as @a run attribute @s minecraft:attack_damage modifier remove metiers:c1
execute as @a run attribute @s minecraft:attack_damage modifier remove metiers:c5
execute as @a run attribute @s minecraft:attack_damage modifier remove metiers:chasseur
execute as @a run attribute @s minecraft:luck modifier remove metiers:p1
execute as @a run attribute @s minecraft:luck modifier remove metiers:p6
execute as @a run attribute @s minecraft:luck modifier remove metiers:pecheur
tag @a remove metiers.ok
tag @a remove metiers.v2
tag @a remove metiers.v3
advancement revoke @a from metiers:b/racine
advancement revoke @a from metiers:f/racine
advancement revoke @a from metiers:m/racine
advancement revoke @a from metiers:c/racine
advancement revoke @a from metiers:p/racine
tag @a remove metiers.sk.b1
tag @a remove metiers.sk.b2
tag @a remove metiers.sk.b3
tag @a remove metiers.sk.b4
tag @a remove metiers.sk.b5
tag @a remove metiers.sk.b6
tag @a remove metiers.sk.f1
tag @a remove metiers.sk.f2
tag @a remove metiers.sk.f3
tag @a remove metiers.sk.f4
tag @a remove metiers.sk.f5
tag @a remove metiers.sk.f6
tag @a remove metiers.sk.m1
tag @a remove metiers.sk.m2
tag @a remove metiers.sk.m3
tag @a remove metiers.sk.m4
tag @a remove metiers.sk.m5
tag @a remove metiers.sk.m6
tag @a remove metiers.sk.c1
tag @a remove metiers.sk.c2
tag @a remove metiers.sk.c3
tag @a remove metiers.sk.c4
tag @a remove metiers.sk.c5
tag @a remove metiers.sk.c6
tag @a remove metiers.sk.p1
tag @a remove metiers.sk.p2
tag @a remove metiers.sk.p3
tag @a remove metiers.sk.p4
tag @a remove metiers.sk.p5
tag @a remove metiers.sk.p6
scoreboard objectives remove m.tmp
scoreboard objectives remove m.gain
scoreboard objectives remove m.const
scoreboard objectives remove m.timer
scoreboard objectives remove m.pref
scoreboard objectives remove m.trig
scoreboard objectives remove metiers
scoreboard objectives remove m.b_lvl
scoreboard objectives remove m.b_xp
scoreboard objectives remove m.b_need
scoreboard objectives remove m.b_bal
scoreboard objectives remove m.b_spent
scoreboard objectives remove m.b_pal
team remove m.b0_0
team remove m.b0_1
team remove m.b0_2
team remove m.b0_3
team remove m.b0_4
team remove m.b0_5
team remove m.b1_0
team remove m.b1_1
team remove m.b1_2
team remove m.b1_3
team remove m.b1_4
team remove m.b1_5
team remove m.b2_0
team remove m.b2_1
team remove m.b2_2
team remove m.b2_3
team remove m.b2_4
team remove m.b2_5
team remove m.b3_0
team remove m.b3_1
team remove m.b3_2
team remove m.b3_3
team remove m.b3_4
team remove m.b3_5
team remove m.b4_0
team remove m.b4_1
team remove m.b4_2
team remove m.b4_3
team remove m.b4_4
team remove m.b4_5
team remove m.b5_0
team remove m.b5_1
team remove m.b5_2
team remove m.b5_3
team remove m.b5_4
team remove m.b5_5
team remove m.b6_0
team remove m.b6_1
team remove m.b6_2
team remove m.b6_3
team remove m.b6_4
team remove m.b6_5
team remove m.b7_0
team remove m.b7_1
team remove m.b7_2
team remove m.b7_3
team remove m.b7_4
team remove m.b7_5
team remove m.b8_0
team remove m.b8_1
team remove m.b8_2
team remove m.b8_3
team remove m.b8_4
team remove m.b8_5
team remove m.b9_0
team remove m.b9_1
team remove m.b9_2
team remove m.b9_3
team remove m.b9_4
team remove m.b9_5
team remove m.b10_0
team remove m.b10_1
team remove m.b10_2
team remove m.b10_3
team remove m.b10_4
team remove m.b10_5
scoreboard objectives remove m.f_lvl
scoreboard objectives remove m.f_xp
scoreboard objectives remove m.f_need
scoreboard objectives remove m.f_bal
scoreboard objectives remove m.f_spent
scoreboard objectives remove m.f_pal
team remove m.f0_0
team remove m.f0_1
team remove m.f0_2
team remove m.f0_3
team remove m.f0_4
team remove m.f0_5
team remove m.f1_0
team remove m.f1_1
team remove m.f1_2
team remove m.f1_3
team remove m.f1_4
team remove m.f1_5
team remove m.f2_0
team remove m.f2_1
team remove m.f2_2
team remove m.f2_3
team remove m.f2_4
team remove m.f2_5
team remove m.f3_0
team remove m.f3_1
team remove m.f3_2
team remove m.f3_3
team remove m.f3_4
team remove m.f3_5
team remove m.f4_0
team remove m.f4_1
team remove m.f4_2
team remove m.f4_3
team remove m.f4_4
team remove m.f4_5
team remove m.f5_0
team remove m.f5_1
team remove m.f5_2
team remove m.f5_3
team remove m.f5_4
team remove m.f5_5
team remove m.f6_0
team remove m.f6_1
team remove m.f6_2
team remove m.f6_3
team remove m.f6_4
team remove m.f6_5
team remove m.f7_0
team remove m.f7_1
team remove m.f7_2
team remove m.f7_3
team remove m.f7_4
team remove m.f7_5
team remove m.f8_0
team remove m.f8_1
team remove m.f8_2
team remove m.f8_3
team remove m.f8_4
team remove m.f8_5
team remove m.f9_0
team remove m.f9_1
team remove m.f9_2
team remove m.f9_3
team remove m.f9_4
team remove m.f9_5
team remove m.f10_0
team remove m.f10_1
team remove m.f10_2
team remove m.f10_3
team remove m.f10_4
team remove m.f10_5
scoreboard objectives remove m.m_lvl
scoreboard objectives remove m.m_xp
scoreboard objectives remove m.m_need
scoreboard objectives remove m.m_bal
scoreboard objectives remove m.m_spent
scoreboard objectives remove m.m_pal
team remove m.m0_0
team remove m.m0_1
team remove m.m0_2
team remove m.m0_3
team remove m.m0_4
team remove m.m0_5
team remove m.m1_0
team remove m.m1_1
team remove m.m1_2
team remove m.m1_3
team remove m.m1_4
team remove m.m1_5
team remove m.m2_0
team remove m.m2_1
team remove m.m2_2
team remove m.m2_3
team remove m.m2_4
team remove m.m2_5
team remove m.m3_0
team remove m.m3_1
team remove m.m3_2
team remove m.m3_3
team remove m.m3_4
team remove m.m3_5
team remove m.m4_0
team remove m.m4_1
team remove m.m4_2
team remove m.m4_3
team remove m.m4_4
team remove m.m4_5
team remove m.m5_0
team remove m.m5_1
team remove m.m5_2
team remove m.m5_3
team remove m.m5_4
team remove m.m5_5
team remove m.m6_0
team remove m.m6_1
team remove m.m6_2
team remove m.m6_3
team remove m.m6_4
team remove m.m6_5
team remove m.m7_0
team remove m.m7_1
team remove m.m7_2
team remove m.m7_3
team remove m.m7_4
team remove m.m7_5
team remove m.m8_0
team remove m.m8_1
team remove m.m8_2
team remove m.m8_3
team remove m.m8_4
team remove m.m8_5
team remove m.m9_0
team remove m.m9_1
team remove m.m9_2
team remove m.m9_3
team remove m.m9_4
team remove m.m9_5
team remove m.m10_0
team remove m.m10_1
team remove m.m10_2
team remove m.m10_3
team remove m.m10_4
team remove m.m10_5
scoreboard objectives remove m.c_lvl
scoreboard objectives remove m.c_xp
scoreboard objectives remove m.c_need
scoreboard objectives remove m.c_bal
scoreboard objectives remove m.c_spent
scoreboard objectives remove m.c_pal
team remove m.c0_0
team remove m.c0_1
team remove m.c0_2
team remove m.c0_3
team remove m.c0_4
team remove m.c0_5
team remove m.c1_0
team remove m.c1_1
team remove m.c1_2
team remove m.c1_3
team remove m.c1_4
team remove m.c1_5
team remove m.c2_0
team remove m.c2_1
team remove m.c2_2
team remove m.c2_3
team remove m.c2_4
team remove m.c2_5
team remove m.c3_0
team remove m.c3_1
team remove m.c3_2
team remove m.c3_3
team remove m.c3_4
team remove m.c3_5
team remove m.c4_0
team remove m.c4_1
team remove m.c4_2
team remove m.c4_3
team remove m.c4_4
team remove m.c4_5
team remove m.c5_0
team remove m.c5_1
team remove m.c5_2
team remove m.c5_3
team remove m.c5_4
team remove m.c5_5
team remove m.c6_0
team remove m.c6_1
team remove m.c6_2
team remove m.c6_3
team remove m.c6_4
team remove m.c6_5
team remove m.c7_0
team remove m.c7_1
team remove m.c7_2
team remove m.c7_3
team remove m.c7_4
team remove m.c7_5
team remove m.c8_0
team remove m.c8_1
team remove m.c8_2
team remove m.c8_3
team remove m.c8_4
team remove m.c8_5
team remove m.c9_0
team remove m.c9_1
team remove m.c9_2
team remove m.c9_3
team remove m.c9_4
team remove m.c9_5
team remove m.c10_0
team remove m.c10_1
team remove m.c10_2
team remove m.c10_3
team remove m.c10_4
team remove m.c10_5
scoreboard objectives remove m.p_lvl
scoreboard objectives remove m.p_xp
scoreboard objectives remove m.p_need
scoreboard objectives remove m.p_bal
scoreboard objectives remove m.p_spent
scoreboard objectives remove m.p_pal
team remove m.p0_0
team remove m.p0_1
team remove m.p0_2
team remove m.p0_3
team remove m.p0_4
team remove m.p0_5
team remove m.p1_0
team remove m.p1_1
team remove m.p1_2
team remove m.p1_3
team remove m.p1_4
team remove m.p1_5
team remove m.p2_0
team remove m.p2_1
team remove m.p2_2
team remove m.p2_3
team remove m.p2_4
team remove m.p2_5
team remove m.p3_0
team remove m.p3_1
team remove m.p3_2
team remove m.p3_3
team remove m.p3_4
team remove m.p3_5
team remove m.p4_0
team remove m.p4_1
team remove m.p4_2
team remove m.p4_3
team remove m.p4_4
team remove m.p4_5
team remove m.p5_0
team remove m.p5_1
team remove m.p5_2
team remove m.p5_3
team remove m.p5_4
team remove m.p5_5
team remove m.p6_0
team remove m.p6_1
team remove m.p6_2
team remove m.p6_3
team remove m.p6_4
team remove m.p6_5
team remove m.p7_0
team remove m.p7_1
team remove m.p7_2
team remove m.p7_3
team remove m.p7_4
team remove m.p7_5
team remove m.p8_0
team remove m.p8_1
team remove m.p8_2
team remove m.p8_3
team remove m.p8_4
team remove m.p8_5
team remove m.p9_0
team remove m.p9_1
team remove m.p9_2
team remove m.p9_3
team remove m.p9_4
team remove m.p9_5
team remove m.p10_0
team remove m.p10_1
team remove m.p10_2
team remove m.p10_3
team remove m.p10_4
team remove m.p10_5
scoreboard objectives remove s.b.mi.oak_log
scoreboard objectives remove s.b.us.oak_log
scoreboard objectives remove s.b.mi.spruce_log
scoreboard objectives remove s.b.us.spruce_log
scoreboard objectives remove s.b.mi.birch_log
scoreboard objectives remove s.b.us.birch_log
scoreboard objectives remove s.b.mi.jungle_log
scoreboard objectives remove s.b.us.jungle_log
scoreboard objectives remove s.b.mi.acacia_log
scoreboard objectives remove s.b.us.acacia_log
scoreboard objectives remove s.b.mi.dark_oak_log
scoreboard objectives remove s.b.us.dark_oak_log
scoreboard objectives remove s.b.mi.mangrove_log
scoreboard objectives remove s.b.us.mangrove_log
scoreboard objectives remove s.b.mi.cherry_log
scoreboard objectives remove s.b.us.cherry_log
scoreboard objectives remove s.b.mi.pale_oak_log
scoreboard objectives remove s.b.us.pale_oak_log
scoreboard objectives remove s.b.mi.crimson_stem
scoreboard objectives remove s.b.us.crimson_stem
scoreboard objectives remove s.b.mi.warped_stem
scoreboard objectives remove s.b.us.warped_stem
scoreboard objectives remove s.f.pu.wheat
scoreboard objectives remove s.f.dr.wheat
scoreboard objectives remove s.f.pu.carrot
scoreboard objectives remove s.f.dr.carrot
scoreboard objectives remove s.f.us.carrot
scoreboard objectives remove s.f.pu.potato
scoreboard objectives remove s.f.dr.potato
scoreboard objectives remove s.f.us.potato
scoreboard objectives remove s.f.pu.beetroot
scoreboard objectives remove s.f.dr.beetroot
scoreboard objectives remove s.f.pu.melon_slice
scoreboard objectives remove s.f.dr.melon_slice
scoreboard objectives remove s.f.pu.pumpkin
scoreboard objectives remove s.f.dr.pumpkin
scoreboard objectives remove s.f.us.pumpkin
scoreboard objectives remove s.f.pu.nether_wart
scoreboard objectives remove s.f.dr.nether_wart
scoreboard objectives remove s.f.us.nether_wart
scoreboard objectives remove s.f.pu.cocoa_beans
scoreboard objectives remove s.f.dr.cocoa_beans
scoreboard objectives remove s.f.us.cocoa_beans
scoreboard objectives remove s.f.pu.sweet_berries
scoreboard objectives remove s.f.dr.sweet_berries
scoreboard objectives remove s.f.us.sweet_berries
scoreboard objectives remove s.f.pu.sugar_cane
scoreboard objectives remove s.f.dr.sugar_cane
scoreboard objectives remove s.f.us.sugar_cane
scoreboard objectives remove s.m.mi.stone
scoreboard objectives remove s.m.us.stone
scoreboard objectives remove s.m.mi.deepslate
scoreboard objectives remove s.m.us.deepslate
scoreboard objectives remove s.m.mi.andesite
scoreboard objectives remove s.m.us.andesite
scoreboard objectives remove s.m.mi.diorite
scoreboard objectives remove s.m.us.diorite
scoreboard objectives remove s.m.mi.granite
scoreboard objectives remove s.m.us.granite
scoreboard objectives remove s.m.mi.tuff
scoreboard objectives remove s.m.us.tuff
scoreboard objectives remove s.m.mi.netherrack
scoreboard objectives remove s.m.us.netherrack
scoreboard objectives remove s.m.mi.blackstone
scoreboard objectives remove s.m.us.blackstone
scoreboard objectives remove s.m.mi.coal_ore
scoreboard objectives remove s.m.us.coal_ore
scoreboard objectives remove s.m.mi.deepslate_coal_ore
scoreboard objectives remove s.m.us.deepslate_coal_ore
scoreboard objectives remove s.m.mi.copper_ore
scoreboard objectives remove s.m.us.copper_ore
scoreboard objectives remove s.m.mi.deepslate_copper_ore
scoreboard objectives remove s.m.us.deepslate_copper_ore
scoreboard objectives remove s.m.mi.iron_ore
scoreboard objectives remove s.m.us.iron_ore
scoreboard objectives remove s.m.mi.deepslate_iron_ore
scoreboard objectives remove s.m.us.deepslate_iron_ore
scoreboard objectives remove s.m.mi.gold_ore
scoreboard objectives remove s.m.us.gold_ore
scoreboard objectives remove s.m.mi.deepslate_gold_ore
scoreboard objectives remove s.m.us.deepslate_gold_ore
scoreboard objectives remove s.m.mi.redstone_ore
scoreboard objectives remove s.m.us.redstone_ore
scoreboard objectives remove s.m.mi.deepslate_redstone_ore
scoreboard objectives remove s.m.us.deepslate_redstone_ore
scoreboard objectives remove s.m.mi.lapis_ore
scoreboard objectives remove s.m.us.lapis_ore
scoreboard objectives remove s.m.mi.deepslate_lapis_ore
scoreboard objectives remove s.m.us.deepslate_lapis_ore
scoreboard objectives remove s.m.mi.diamond_ore
scoreboard objectives remove s.m.us.diamond_ore
scoreboard objectives remove s.m.mi.deepslate_diamond_ore
scoreboard objectives remove s.m.us.deepslate_diamond_ore
scoreboard objectives remove s.m.mi.emerald_ore
scoreboard objectives remove s.m.us.emerald_ore
scoreboard objectives remove s.m.mi.deepslate_emerald_ore
scoreboard objectives remove s.m.us.deepslate_emerald_ore
scoreboard objectives remove s.m.mi.nether_gold_ore
scoreboard objectives remove s.m.us.nether_gold_ore
scoreboard objectives remove s.m.mi.nether_quartz_ore
scoreboard objectives remove s.m.us.nether_quartz_ore
scoreboard objectives remove s.m.mi.ancient_debris
scoreboard objectives remove s.m.us.ancient_debris
scoreboard objectives remove s.c.kills
scoreboard objectives remove s.c.k.wither
scoreboard objectives remove s.c.k.ender_dragon
scoreboard objectives remove s.c.k.warden
scoreboard objectives remove s.c.k.elder_guardian
scoreboard objectives remove s.p.fish
scoreboard objectives remove a.oak_log
scoreboard objectives remove a.spruce_log
scoreboard objectives remove a.birch_log
scoreboard objectives remove a.jungle_log
scoreboard objectives remove a.acacia_log
scoreboard objectives remove a.dark_oak_log
scoreboard objectives remove a.mangrove_log
scoreboard objectives remove a.cherry_log
scoreboard objectives remove a.pale_oak_log
scoreboard objectives remove a.crimson_stem
scoreboard objectives remove a.warped_stem
scoreboard objectives remove a.sneak
scoreboard objectives remove m.quit
scoreboard objectives remove m.dmg
scoreboard objectives remove m.id
scoreboard objectives remove m.dshow
scoreboard objectives remove m.dall
scoreboard objectives remove m.defi
scoreboard objectives remove m.heure
scoreboard objectives remove m.boss
scoreboard objectives remove m.total
scoreboard objectives remove m.b_pr
scoreboard objectives remove m.b_out
scoreboard objectives remove m.b_cd
scoreboard objectives remove m.b_st
scoreboard objectives remove m.dp_b
scoreboard objectives remove m.dd_b
scoreboard objectives remove m.f_pr
scoreboard objectives remove m.f_out
scoreboard objectives remove m.f_cd
scoreboard objectives remove m.f_st
scoreboard objectives remove m.dp_f
scoreboard objectives remove m.dd_f
scoreboard objectives remove m.m_pr
scoreboard objectives remove m.m_out
scoreboard objectives remove m.m_cd
scoreboard objectives remove m.m_st
scoreboard objectives remove m.dp_m
scoreboard objectives remove m.dd_m
scoreboard objectives remove m.c_pr
scoreboard objectives remove m.c_out
scoreboard objectives remove m.c_cd
scoreboard objectives remove m.c_st
scoreboard objectives remove m.dp_c
scoreboard objectives remove m.dd_c
scoreboard objectives remove m.p_pr
scoreboard objectives remove m.p_out
scoreboard objectives remove m.p_cd
scoreboard objectives remove m.p_st
scoreboard objectives remove m.dp_p
scoreboard objectives remove m.dd_p
scoreboard objectives remove dq.b1_0
scoreboard objectives remove dq.b2_0
scoreboard objectives remove dq.b3_0
scoreboard objectives remove dq.b4_0
scoreboard objectives remove dq.b5_0
scoreboard objectives remove dq.b5_1
scoreboard objectives remove dq.b5_2
scoreboard objectives remove dq.b5_3
scoreboard objectives remove dq.b5_4
scoreboard objectives remove dq.b5_5
scoreboard objectives remove dq.b5_6
scoreboard objectives remove dq.b5_7
scoreboard objectives remove dq.b5_8
scoreboard objectives remove dq.b5_9
scoreboard objectives remove dq.b5_10
scoreboard objectives remove dq.f1_0
scoreboard objectives remove dq.f2_0
scoreboard objectives remove dq.f3_0
scoreboard objectives remove dq.f4_0
scoreboard objectives remove dq.f5_0
scoreboard objectives remove dq.m1_0
scoreboard objectives remove dq.m2_0
scoreboard objectives remove dq.m3_0
scoreboard objectives remove dq.m3_1
scoreboard objectives remove dq.m4_0
scoreboard objectives remove dq.m4_1
scoreboard objectives remove dq.m5_0
scoreboard objectives remove dq.m5_1
scoreboard objectives remove dq.c1_0
scoreboard objectives remove dq.c2_0
scoreboard objectives remove dq.c3_0
scoreboard objectives remove dq.c4_0
scoreboard objectives remove dq.c5_0
scoreboard objectives remove dq.p1_0
scoreboard objectives remove dq.p2_0
scoreboard objectives remove dq.p3_0
scoreboard objectives remove dq.p4_0
scoreboard objectives remove dq.p5_0
bossbar remove metiers:heure
bossbar remove metiers:boss
tag @a remove metiers.v6
kill @e[tag=metiers.boss]
kill @e[tag=metiers.sbire]
execute in minecraft:overworld run forceload remove 0 0
tag @a remove metiers.v4
tag @a remove metiers.v5
tellraw @s {"text":"[Métiers] Désinstallé. Retire le zip du dossier datapacks puis redémarre.","color":"gold"}
