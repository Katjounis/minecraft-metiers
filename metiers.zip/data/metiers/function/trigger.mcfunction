scoreboard players operation @s m.trig = @s metiers
scoreboard players set @s metiers 0
scoreboard players enable @s metiers
execute if score @s m.trig matches 1 run function metiers:menu
execute if score @s m.trig matches 2 run function metiers:prefixe/menu
execute if score @s m.trig matches 3 unless function metiers:recompenses run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucune récompense en attente.","color":"gray"}]
execute if score @s m.trig matches 10..15 run function metiers:prefixe/choisir
execute if score @s m.trig matches 4 run function metiers:appel {f:"defis/menu"}
execute if score @s m.trig matches 5 run function metiers:appel {f:"classement/menu"}
execute if score @s m.trig matches 7 run function metiers:appel {f:"defis/basculer"}
execute if score @s m.trig matches 31 run function metiers:appel {f:"b/outil_recup"}
execute if score @s m.trig matches 41 run function metiers:appel {f:"b/prestige_confirmer"}
execute if score @s m.trig matches 46 run function metiers:appel {f:"b/prestige"}
execute if score @s m.trig matches 51 run function metiers:appel {f:"b/outil_reparer"}
execute if score @s m.trig matches 32 run function metiers:appel {f:"f/outil_recup"}
execute if score @s m.trig matches 42 run function metiers:appel {f:"f/prestige_confirmer"}
execute if score @s m.trig matches 47 run function metiers:appel {f:"f/prestige"}
execute if score @s m.trig matches 52 run function metiers:appel {f:"f/outil_reparer"}
execute if score @s m.trig matches 33 run function metiers:appel {f:"m/outil_recup"}
execute if score @s m.trig matches 43 run function metiers:appel {f:"m/prestige_confirmer"}
execute if score @s m.trig matches 48 run function metiers:appel {f:"m/prestige"}
execute if score @s m.trig matches 53 run function metiers:appel {f:"m/outil_reparer"}
execute if score @s m.trig matches 34 run function metiers:appel {f:"c/outil_recup"}
execute if score @s m.trig matches 44 run function metiers:appel {f:"c/prestige_confirmer"}
execute if score @s m.trig matches 49 run function metiers:appel {f:"c/prestige"}
execute if score @s m.trig matches 54 run function metiers:appel {f:"c/outil_reparer"}
execute if score @s m.trig matches 35 run function metiers:appel {f:"p/outil_recup"}
execute if score @s m.trig matches 45 run function metiers:appel {f:"p/prestige_confirmer"}
execute if score @s m.trig matches 50 run function metiers:appel {f:"p/prestige"}
execute if score @s m.trig matches 55 run function metiers:appel {f:"p/outil_reparer"}
execute if score @s m.trig matches 21 run function metiers:b/arbre
execute if score @s m.trig matches 201 run function metiers:b/reclamer
execute if score @s m.trig matches 111 run function metiers:b/acheter_1
execute if score @s m.trig matches 112 run function metiers:b/acheter_2
execute if score @s m.trig matches 113 run function metiers:b/acheter_3
execute if score @s m.trig matches 114 run function metiers:b/acheter_4
execute if score @s m.trig matches 115 run function metiers:b/acheter_5
execute if score @s m.trig matches 116 run function metiers:b/acheter_6
execute if score @s m.trig matches 22 run function metiers:f/arbre
execute if score @s m.trig matches 202 run function metiers:f/reclamer
execute if score @s m.trig matches 121 run function metiers:f/acheter_1
execute if score @s m.trig matches 122 run function metiers:f/acheter_2
execute if score @s m.trig matches 123 run function metiers:f/acheter_3
execute if score @s m.trig matches 124 run function metiers:f/acheter_4
execute if score @s m.trig matches 125 run function metiers:f/acheter_5
execute if score @s m.trig matches 126 run function metiers:f/acheter_6
execute if score @s m.trig matches 23 run function metiers:m/arbre
execute if score @s m.trig matches 203 run function metiers:m/reclamer
execute if score @s m.trig matches 131 run function metiers:m/acheter_1
execute if score @s m.trig matches 132 run function metiers:m/acheter_2
execute if score @s m.trig matches 133 run function metiers:m/acheter_3
execute if score @s m.trig matches 134 run function metiers:m/acheter_4
execute if score @s m.trig matches 135 run function metiers:m/acheter_5
execute if score @s m.trig matches 136 run function metiers:m/acheter_6
execute if score @s m.trig matches 24 run function metiers:c/arbre
execute if score @s m.trig matches 204 run function metiers:c/reclamer
execute if score @s m.trig matches 141 run function metiers:c/acheter_1
execute if score @s m.trig matches 142 run function metiers:c/acheter_2
execute if score @s m.trig matches 143 run function metiers:c/acheter_3
execute if score @s m.trig matches 144 run function metiers:c/acheter_4
execute if score @s m.trig matches 145 run function metiers:c/acheter_5
execute if score @s m.trig matches 146 run function metiers:c/acheter_6
execute if score @s m.trig matches 25 run function metiers:p/arbre
execute if score @s m.trig matches 205 run function metiers:p/reclamer
execute if score @s m.trig matches 151 run function metiers:p/acheter_1
execute if score @s m.trig matches 152 run function metiers:p/acheter_2
execute if score @s m.trig matches 153 run function metiers:p/acheter_3
execute if score @s m.trig matches 154 run function metiers:p/acheter_4
execute if score @s m.trig matches 155 run function metiers:p/acheter_5
execute if score @s m.trig matches 156 run function metiers:p/acheter_6
