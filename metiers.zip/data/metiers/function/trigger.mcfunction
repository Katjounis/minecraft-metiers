scoreboard players operation @s m.trig = @s metiers
scoreboard players set @s metiers 0
scoreboard players enable @s metiers
execute if score @s m.trig matches 1 run function metiers:menu
execute if score @s m.trig matches 2 run function metiers:prefixe/menu
execute if score @s m.trig matches 3 unless function metiers:recompenses run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucune récompense en attente.","color":"gray"}]
execute if score @s m.trig matches 10..19 run function metiers:prefixe/choisir
execute if score @s m.trig matches 4 run function metiers:appel {f:"defis/menu"}
execute if score @s m.trig matches 5 run function metiers:appel {f:"classement/menu"}
execute if score @s m.trig matches 7 run function metiers:appel {f:"defis/basculer"}
execute if score @s m.trig matches 6 run function metiers:appel {f:"armure/menu"}
execute if score @s m.trig matches 8 run function metiers:appel {f:"armure/recup"}
execute if score @s m.trig matches 70 run function metiers:appel {f:"p/carnet"}
execute if score @s m.trig matches 301 run function metiers:appel {f:"b/outil_recup"}
execute if score @s m.trig matches 311 run function metiers:appel {f:"b/prestige_confirmer"}
execute if score @s m.trig matches 321 run function metiers:appel {f:"b/prestige"}
execute if score @s m.trig matches 331 run function metiers:appel {f:"b/outil_reparer"}
execute if score @s m.trig matches 341 run function metiers:appel {f:"b/recompenses_menu"}
execute if score @s m.trig matches 302 run function metiers:appel {f:"f/outil_recup"}
execute if score @s m.trig matches 312 run function metiers:appel {f:"f/prestige_confirmer"}
execute if score @s m.trig matches 322 run function metiers:appel {f:"f/prestige"}
execute if score @s m.trig matches 332 run function metiers:appel {f:"f/outil_reparer"}
execute if score @s m.trig matches 342 run function metiers:appel {f:"f/recompenses_menu"}
execute if score @s m.trig matches 303 run function metiers:appel {f:"m/outil_recup"}
execute if score @s m.trig matches 313 run function metiers:appel {f:"m/prestige_confirmer"}
execute if score @s m.trig matches 323 run function metiers:appel {f:"m/prestige"}
execute if score @s m.trig matches 333 run function metiers:appel {f:"m/outil_reparer"}
execute if score @s m.trig matches 343 run function metiers:appel {f:"m/recompenses_menu"}
execute if score @s m.trig matches 304 run function metiers:appel {f:"c/outil_recup"}
execute if score @s m.trig matches 314 run function metiers:appel {f:"c/prestige_confirmer"}
execute if score @s m.trig matches 324 run function metiers:appel {f:"c/prestige"}
execute if score @s m.trig matches 334 run function metiers:appel {f:"c/outil_reparer"}
execute if score @s m.trig matches 344 run function metiers:appel {f:"c/recompenses_menu"}
execute if score @s m.trig matches 305 run function metiers:appel {f:"p/outil_recup"}
execute if score @s m.trig matches 315 run function metiers:appel {f:"p/prestige_confirmer"}
execute if score @s m.trig matches 325 run function metiers:appel {f:"p/prestige"}
execute if score @s m.trig matches 335 run function metiers:appel {f:"p/outil_reparer"}
execute if score @s m.trig matches 345 run function metiers:appel {f:"p/recompenses_menu"}
execute if score @s m.trig matches 306 run function metiers:appel {f:"e/outil_recup"}
execute if score @s m.trig matches 316 run function metiers:appel {f:"e/prestige_confirmer"}
execute if score @s m.trig matches 326 run function metiers:appel {f:"e/prestige"}
execute if score @s m.trig matches 336 run function metiers:appel {f:"e/outil_reparer"}
execute if score @s m.trig matches 346 run function metiers:appel {f:"e/recompenses_menu"}
execute if score @s m.trig matches 307 run function metiers:appel {f:"n/outil_recup"}
execute if score @s m.trig matches 317 run function metiers:appel {f:"n/prestige_confirmer"}
execute if score @s m.trig matches 327 run function metiers:appel {f:"n/prestige"}
execute if score @s m.trig matches 337 run function metiers:appel {f:"n/outil_reparer"}
execute if score @s m.trig matches 347 run function metiers:appel {f:"n/recompenses_menu"}
execute if score @s m.trig matches 308 run function metiers:appel {f:"x/outil_recup"}
execute if score @s m.trig matches 318 run function metiers:appel {f:"x/prestige_confirmer"}
execute if score @s m.trig matches 328 run function metiers:appel {f:"x/prestige"}
execute if score @s m.trig matches 338 run function metiers:appel {f:"x/outil_reparer"}
execute if score @s m.trig matches 348 run function metiers:appel {f:"x/recompenses_menu"}
execute if score @s m.trig matches 309 run function metiers:appel {f:"t/outil_recup"}
execute if score @s m.trig matches 319 run function metiers:appel {f:"t/prestige_confirmer"}
execute if score @s m.trig matches 329 run function metiers:appel {f:"t/prestige"}
execute if score @s m.trig matches 339 run function metiers:appel {f:"t/outil_reparer"}
execute if score @s m.trig matches 349 run function metiers:appel {f:"t/recompenses_menu"}
execute if score @s m.trig matches 21 run function metiers:b/arbre
execute if score @s m.trig matches 201 run function metiers:b/reclamer
execute if score @s m.trig matches 111 run function metiers:b/acheter_1
execute if score @s m.trig matches 112 run function metiers:b/acheter_2
execute if score @s m.trig matches 113 run function metiers:b/acheter_3
execute if score @s m.trig matches 114 run function metiers:b/acheter_4
execute if score @s m.trig matches 115 run function metiers:b/acheter_5
execute if score @s m.trig matches 116 run function metiers:b/acheter_6
execute if score @s m.trig matches 22 run function metiers:f/arbre
execute if score @s m.trig matches 202 run function metiers:f/reclamer
execute if score @s m.trig matches 121 run function metiers:f/acheter_1
execute if score @s m.trig matches 122 run function metiers:f/acheter_2
execute if score @s m.trig matches 123 run function metiers:f/acheter_3
execute if score @s m.trig matches 124 run function metiers:f/acheter_4
execute if score @s m.trig matches 125 run function metiers:f/acheter_5
execute if score @s m.trig matches 126 run function metiers:f/acheter_6
execute if score @s m.trig matches 23 run function metiers:m/arbre
execute if score @s m.trig matches 203 run function metiers:m/reclamer
execute if score @s m.trig matches 131 run function metiers:m/acheter_1
execute if score @s m.trig matches 132 run function metiers:m/acheter_2
execute if score @s m.trig matches 133 run function metiers:m/acheter_3
execute if score @s m.trig matches 134 run function metiers:m/acheter_4
execute if score @s m.trig matches 135 run function metiers:m/acheter_5
execute if score @s m.trig matches 136 run function metiers:m/acheter_6
execute if score @s m.trig matches 24 run function metiers:c/arbre
execute if score @s m.trig matches 204 run function metiers:c/reclamer
execute if score @s m.trig matches 141 run function metiers:c/acheter_1
execute if score @s m.trig matches 142 run function metiers:c/acheter_2
execute if score @s m.trig matches 143 run function metiers:c/acheter_3
execute if score @s m.trig matches 144 run function metiers:c/acheter_4
execute if score @s m.trig matches 145 run function metiers:c/acheter_5
execute if score @s m.trig matches 146 run function metiers:c/acheter_6
execute if score @s m.trig matches 25 run function metiers:p/arbre
execute if score @s m.trig matches 205 run function metiers:p/reclamer
execute if score @s m.trig matches 151 run function metiers:p/acheter_1
execute if score @s m.trig matches 152 run function metiers:p/acheter_2
execute if score @s m.trig matches 153 run function metiers:p/acheter_3
execute if score @s m.trig matches 154 run function metiers:p/acheter_4
execute if score @s m.trig matches 155 run function metiers:p/acheter_5
execute if score @s m.trig matches 156 run function metiers:p/acheter_6
execute if score @s m.trig matches 26 run function metiers:e/arbre
execute if score @s m.trig matches 206 run function metiers:e/reclamer
execute if score @s m.trig matches 161 run function metiers:e/acheter_1
execute if score @s m.trig matches 162 run function metiers:e/acheter_2
execute if score @s m.trig matches 163 run function metiers:e/acheter_3
execute if score @s m.trig matches 164 run function metiers:e/acheter_4
execute if score @s m.trig matches 165 run function metiers:e/acheter_5
execute if score @s m.trig matches 166 run function metiers:e/acheter_6
execute if score @s m.trig matches 27 run function metiers:n/arbre
execute if score @s m.trig matches 207 run function metiers:n/reclamer
execute if score @s m.trig matches 171 run function metiers:n/acheter_1
execute if score @s m.trig matches 172 run function metiers:n/acheter_2
execute if score @s m.trig matches 173 run function metiers:n/acheter_3
execute if score @s m.trig matches 174 run function metiers:n/acheter_4
execute if score @s m.trig matches 175 run function metiers:n/acheter_5
execute if score @s m.trig matches 176 run function metiers:n/acheter_6
execute if score @s m.trig matches 28 run function metiers:x/arbre
execute if score @s m.trig matches 208 run function metiers:x/reclamer
execute if score @s m.trig matches 181 run function metiers:x/acheter_1
execute if score @s m.trig matches 182 run function metiers:x/acheter_2
execute if score @s m.trig matches 183 run function metiers:x/acheter_3
execute if score @s m.trig matches 184 run function metiers:x/acheter_4
execute if score @s m.trig matches 185 run function metiers:x/acheter_5
execute if score @s m.trig matches 186 run function metiers:x/acheter_6
execute if score @s m.trig matches 29 run function metiers:t/arbre
execute if score @s m.trig matches 209 run function metiers:t/reclamer
execute if score @s m.trig matches 191 run function metiers:t/acheter_1
execute if score @s m.trig matches 192 run function metiers:t/acheter_2
execute if score @s m.trig matches 193 run function metiers:t/acheter_3
execute if score @s m.trig matches 194 run function metiers:t/acheter_4
execute if score @s m.trig matches 195 run function metiers:t/acheter_5
execute if score @s m.trig matches 196 run function metiers:t/acheter_6
