scoreboard players operation @s i.jb += #G i.t
scoreboard players set #com i.t 0
execute if score @s i.halle matches 0 run scoreboard players set #com i.t 12
execute if score @s i.halle matches 1 run scoreboard players set #com i.t 8
execute if score @s i.halle matches 2 run scoreboard players set #com i.t 5
execute if score @s i.halle matches 3 run scoreboard players set #com i.t 2
execute if score @s m.t_lvl matches 50.. run scoreboard players remove #com i.t 2
execute if score #com i.t matches ..-1 run scoreboard players set #com i.t 0
scoreboard players set #y i.t 100
scoreboard players operation #y i.t -= #com i.t
execute unless score @s i.pret matches 2 run scoreboard players operation @s i.rir += #G i.t
scoreboard players set #z i.t 25000
scoreboard players operation #x i.t = @s i.rir
scoreboard players operation #x i.t /= #z i.t
scoreboard players operation @s i.ri += #x i.t
scoreboard players operation @s i.rir %= #z i.t
scoreboard players operation #N i.t = #G i.t
scoreboard players operation #N i.t /= #100 i.g
scoreboard players operation #N i.t *= #y i.t
scoreboard players operation #R i.t = #G i.t
scoreboard players operation #R i.t %= #100 i.g
scoreboard players operation #R i.t *= #y i.t
scoreboard players operation #R i.t /= #100 i.g
scoreboard players operation #N i.t += #R i.t
scoreboard players set #ent i.t 0
execute if score #ent i.t matches 0 if score @s i.jn matches 12000000.. run scoreboard players set #ent i.t 55
execute if score #ent i.t matches 0 if score @s i.jn matches 5000000.. run scoreboard players set #ent i.t 75
execute if score #ent i.t matches 1.. run scoreboard players operation #N i.t /= #100 i.g
execute if score #ent i.t matches 1.. run scoreboard players operation #N i.t *= #ent i.t
execute if score @s i.dette matches 1.. run function industrie:banque/prelever
scoreboard players operation @s i.cts += #N i.t
scoreboard players operation #E i.t = @s i.cts
scoreboard players operation #E i.t /= #100 i.g
scoreboard players operation @s i.cts %= #100 i.g
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus += #E i.t
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.a_ind += #E i.t
scoreboard players operation @s i.jn += #E i.t
scoreboard players operation @s i.jv += #E i.t
