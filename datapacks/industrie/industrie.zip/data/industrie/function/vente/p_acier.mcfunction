scoreboard players operation #q i.t = @s i.s_acier
execute if score @s i.o_acier matches 4 run scoreboard players operation #q i.t -= @s i.x_acier
execute if score #q i.t matches ..0 run return 0
scoreboard players set #S i.t 2500
scoreboard players operation #S i.t *= #sb i.t
scoreboard players operation #S i.t /= #100 i.g
scoreboard players operation #S i.t *= #hb i.t
scoreboard players operation #S i.t /= #100 i.g
scoreboard players operation #S i.t *= #foire i.g
scoreboard players operation #S i.t /= #100 i.g
execute if score @s i.o_acier matches 3 run scoreboard players operation #x i.t = @s i.x_acier
execute if score @s i.o_acier matches 3 run scoreboard players operation #x i.t -= @s i.j_acier
execute if score @s i.o_acier matches 3 if score #q i.t > #x i.t run scoreboard players operation #q i.t = #x i.t
execute if score #q i.t > #capl i.t run scoreboard players operation #q i.t = #capl i.t
execute if score #q i.t matches ..0 run return 0
scoreboard players operation #pct i.t = #S i.t
scoreboard players operation #pct i.t *= #100 i.g
scoreboard players operation #den i.t = #S i.t
scoreboard players operation #den i.t += @s i.v_acier
scoreboard players operation #pct i.t /= #den i.t
scoreboard players set #ev i.t 100
execute if score #evp i.g matches 17 run scoreboard players operation #ev i.t = #evm i.g
scoreboard players operation #pct i.t *= #ev i.t
scoreboard players operation #pct i.t /= #100 i.g
execute if score @s i.o_acier matches 2 if score #pct i.t < @s i.x_acier run return 0
scoreboard players operation #h i.t = #q i.t
scoreboard players operation #h i.t /= #2 i.g
scoreboard players operation #den i.t += #h i.t
scoreboard players operation #r i.t = #S i.t
scoreboard players operation #r i.t *= #1000 i.g
scoreboard players operation #r i.t /= #den i.t
scoreboard players operation #r i.t *= #ev i.t
scoreboard players operation #r i.t /= #100 i.g
scoreboard players set #pq i.t 6000
scoreboard players operation #pq i.t *= #q i.t
scoreboard players set #big i.t 0
execute if score #pq i.t matches 2000000.. run scoreboard players set #big i.t 1
execute if score #big i.t matches 0 run scoreboard players operation #pq i.t *= #r i.t
execute if score #big i.t matches 0 run scoreboard players operation #pq i.t /= #1000 i.g
execute if score #big i.t matches 1 run scoreboard players operation #pq i.t /= #100 i.g
execute if score #big i.t matches 1 run scoreboard players operation #pq i.t *= #r i.t
execute if score #big i.t matches 1 run scoreboard players operation #pq i.t /= #10 i.g
scoreboard players operation #G i.t += #pq i.t
scoreboard players operation @s i.s_acier -= #q i.t
scoreboard players operation @s i.v_acier += #q i.t
scoreboard players operation @s i.j_acier += #q i.t
scoreboard players operation #capl i.t -= #q i.t
