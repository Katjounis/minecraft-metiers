execute unless score @s i.rang matches 2.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Le Laboratoire s'ouvre au rang Manufacture.",color:"red",bold:false,italic:false}]
execute if score @s i.rb matches 1.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Une recherche est déjà en cours.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 10.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Réseau commercial est au maximum.",color:"gray",bold:false,italic:false}]
execute if score @s i.b1 matches 5.. unless score @s i.rang matches 4.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Les niveaux 6 à 10 demandent le rang Consortium.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 0 unless score @s c.ecus matches 300000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 1 : 300 000 Écus et 1 000 or.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 0 unless score @s i.s_or matches 1000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 1 : il faut 1 000 or au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 0 run scoreboard players remove @s i.s_or 1000
execute if score @s i.b1 matches 0 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 300000
execute if score @s i.b1 matches 0 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 300000
execute if score @s i.b1 matches 1 unless score @s c.ecus matches 660000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 2 : 660 000 Écus et 2 000 or.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 1 unless score @s i.s_or matches 2000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 2 : il faut 2 000 or au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 1 run scoreboard players remove @s i.s_or 2000
execute if score @s i.b1 matches 1 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 660000
execute if score @s i.b1 matches 1 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 660000
execute if score @s i.b1 matches 2 unless score @s c.ecus matches 1452000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 3 : 1 452 000 Écus et 4 000 or.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 2 unless score @s i.s_or matches 4000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 3 : il faut 4 000 or au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 2 run scoreboard players remove @s i.s_or 4000
execute if score @s i.b1 matches 2 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 1452000
execute if score @s i.b1 matches 2 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 1452000
execute if score @s i.b1 matches 3 unless score @s c.ecus matches 3194400.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 4 : 3 194 400 Écus et 8 000 or.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 3 unless score @s i.s_or matches 8000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 4 : il faut 8 000 or au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 3 run scoreboard players remove @s i.s_or 8000
execute if score @s i.b1 matches 3 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 3194400
execute if score @s i.b1 matches 3 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 3194400
execute if score @s i.b1 matches 4 unless score @s c.ecus matches 7027680.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 5 : 7 027 680 Écus et 16 000 or.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 4 unless score @s i.s_or matches 16000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 5 : il faut 16 000 or au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 4 run scoreboard players remove @s i.s_or 16000
execute if score @s i.b1 matches 4 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 7027680
execute if score @s i.b1 matches 4 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 7027680
execute if score @s i.b1 matches 5 unless score @s c.ecus matches 15460896.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 6 : 15 460 896 Écus et 800 bijou.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 5 unless score @s i.s_bijou matches 800.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 6 : il faut 800 bijou au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 5 run scoreboard players remove @s i.s_bijou 800
execute if score @s i.b1 matches 5 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 15460896
execute if score @s i.b1 matches 5 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 15460896
execute if score @s i.b1 matches 6 unless score @s c.ecus matches 34013971.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 7 : 34 013 971 Écus et 1 600 bijou.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 6 unless score @s i.s_bijou matches 1600.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 7 : il faut 1 600 bijou au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 6 run scoreboard players remove @s i.s_bijou 1600
execute if score @s i.b1 matches 6 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 34013971
execute if score @s i.b1 matches 6 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 34013971
execute if score @s i.b1 matches 7 unless score @s c.ecus matches 74830736.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 8 : 74 830 736 Écus et 3 200 bijou.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 7 unless score @s i.s_bijou matches 3200.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 8 : il faut 3 200 bijou au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 7 run scoreboard players remove @s i.s_bijou 3200
execute if score @s i.b1 matches 7 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 74830736
execute if score @s i.b1 matches 7 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 74830736
execute if score @s i.b1 matches 8 unless score @s c.ecus matches 164627620.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 9 : 164 627 620 Écus et 6 400 bijou.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 8 unless score @s i.s_bijou matches 6400.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 9 : il faut 6 400 bijou au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 8 run scoreboard players remove @s i.s_bijou 6400
execute if score @s i.b1 matches 8 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 164627620
execute if score @s i.b1 matches 8 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 164627620
execute if score @s i.b1 matches 9 unless score @s c.ecus matches 362180765.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 10 : 362 180 765 Écus et 12 800 bijou.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 9 unless score @s i.s_bijou matches 12800.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 10 : il faut 12 800 bijou au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b1 matches 9 run scoreboard players remove @s i.s_bijou 12800
execute if score @s i.b1 matches 9 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 362180765
execute if score @s i.b1 matches 9 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 362180765
scoreboard players set @s i.rb 1
scoreboard players operation @s i.rt = #now i.g
scoreboard players add @s i.rt 72000
playsound minecraft:block.brewing_stand.brew master @s ~ ~ ~ 1 1
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Recherche lancée : Réseau commercial, prête dans 1 heure de jeu.",color:"aqua",bold:false,italic:false}]
function industrie:menu/labo
