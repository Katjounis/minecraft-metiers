execute unless score @s i.rang matches 2.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Le Laboratoire s'ouvre au rang Manufacture.",color:"red",bold:false,italic:false}]
execute if score @s i.rb matches 1.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Une recherche est déjà en cours.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 10.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Cadence est au maximum.",color:"gray",bold:false,italic:false}]
execute if score @s i.b2 matches 5.. unless score @s i.rang matches 4.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Les niveaux 6 à 10 demandent le rang Consortium.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 0 unless score @s c.ecus matches 200000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 1 : 200 000 Écus et 5 000 fer.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 0 unless score @s i.s_fer matches 5000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 1 : il faut 5 000 fer au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 0 run scoreboard players remove @s i.s_fer 5000
execute if score @s i.b2 matches 0 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 200000
execute if score @s i.b2 matches 0 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 200000
execute if score @s i.b2 matches 1 unless score @s c.ecus matches 440000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 2 : 440 000 Écus et 10 000 fer.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 1 unless score @s i.s_fer matches 10000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 2 : il faut 10 000 fer au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 1 run scoreboard players remove @s i.s_fer 10000
execute if score @s i.b2 matches 1 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 440000
execute if score @s i.b2 matches 1 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 440000
execute if score @s i.b2 matches 2 unless score @s c.ecus matches 968000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 3 : 968 000 Écus et 20 000 fer.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 2 unless score @s i.s_fer matches 20000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 3 : il faut 20 000 fer au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 2 run scoreboard players remove @s i.s_fer 20000
execute if score @s i.b2 matches 2 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 968000
execute if score @s i.b2 matches 2 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 968000
execute if score @s i.b2 matches 3 unless score @s c.ecus matches 2129600.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 4 : 2 129 600 Écus et 40 000 fer.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 3 unless score @s i.s_fer matches 40000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 4 : il faut 40 000 fer au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 3 run scoreboard players remove @s i.s_fer 40000
execute if score @s i.b2 matches 3 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 2129600
execute if score @s i.b2 matches 3 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 2129600
execute if score @s i.b2 matches 4 unless score @s c.ecus matches 4685120.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 5 : 4 685 120 Écus et 80 000 fer.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 4 unless score @s i.s_fer matches 80000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 5 : il faut 80 000 fer au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 4 run scoreboard players remove @s i.s_fer 80000
execute if score @s i.b2 matches 4 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 4685120
execute if score @s i.b2 matches 4 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 4685120
execute if score @s i.b2 matches 5 unless score @s c.ecus matches 10307264.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 6 : 10 307 264 Écus et 4 000 acier.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 5 unless score @s i.s_acier matches 4000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 6 : il faut 4 000 acier au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 5 run scoreboard players remove @s i.s_acier 4000
execute if score @s i.b2 matches 5 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 10307264
execute if score @s i.b2 matches 5 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 10307264
execute if score @s i.b2 matches 6 unless score @s c.ecus matches 22675980.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 7 : 22 675 980 Écus et 8 000 acier.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 6 unless score @s i.s_acier matches 8000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 7 : il faut 8 000 acier au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 6 run scoreboard players remove @s i.s_acier 8000
execute if score @s i.b2 matches 6 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 22675980
execute if score @s i.b2 matches 6 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 22675980
execute if score @s i.b2 matches 7 unless score @s c.ecus matches 49887157.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 8 : 49 887 157 Écus et 16 000 acier.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 7 unless score @s i.s_acier matches 16000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 8 : il faut 16 000 acier au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 7 run scoreboard players remove @s i.s_acier 16000
execute if score @s i.b2 matches 7 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 49887157
execute if score @s i.b2 matches 7 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 49887157
execute if score @s i.b2 matches 8 unless score @s c.ecus matches 109751747.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 9 : 109 751 747 Écus et 32 000 acier.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 8 unless score @s i.s_acier matches 32000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 9 : il faut 32 000 acier au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 8 run scoreboard players remove @s i.s_acier 32000
execute if score @s i.b2 matches 8 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 109751747
execute if score @s i.b2 matches 8 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 109751747
execute if score @s i.b2 matches 9 unless score @s c.ecus matches 241453843.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 10 : 241 453 843 Écus et 64 000 acier.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 9 unless score @s i.s_acier matches 64000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 10 : il faut 64 000 acier au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b2 matches 9 run scoreboard players remove @s i.s_acier 64000
execute if score @s i.b2 matches 9 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 241453843
execute if score @s i.b2 matches 9 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 241453843
scoreboard players set @s i.rb 2
scoreboard players operation @s i.rt = #now i.g
scoreboard players add @s i.rt 72000
playsound minecraft:block.brewing_stand.brew master @s ~ ~ ~ 1 1
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Recherche lancée : Cadence, prête dans 1 heure de jeu.",color:"aqua",bold:false,italic:false}]
function industrie:menu/labo
