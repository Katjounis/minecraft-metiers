execute unless score @s i.rang matches 2.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Le Laboratoire s'ouvre au rang Manufacture.",color:"red",bold:false,italic:false}]
execute if score @s i.rb matches 1.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Une recherche est déjà en cours.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 10.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Logistique est au maximum.",color:"gray",bold:false,italic:false}]
execute if score @s i.b3 matches 5.. unless score @s i.rang matches 4.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Les niveaux 6 à 10 demandent le rang Consortium.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 0 unless score @s c.ecus matches 150000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 1 : 150 000 Écus et 2 000 cuivre.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 0 unless score @s i.s_cuivre matches 2000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 1 : il faut 2 000 cuivre au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 0 run scoreboard players remove @s i.s_cuivre 2000
execute if score @s i.b3 matches 0 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 150000
execute if score @s i.b3 matches 0 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 150000
execute if score @s i.b3 matches 1 unless score @s c.ecus matches 330000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 2 : 330 000 Écus et 4 000 cuivre.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 1 unless score @s i.s_cuivre matches 4000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 2 : il faut 4 000 cuivre au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 1 run scoreboard players remove @s i.s_cuivre 4000
execute if score @s i.b3 matches 1 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 330000
execute if score @s i.b3 matches 1 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 330000
execute if score @s i.b3 matches 2 unless score @s c.ecus matches 726000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 3 : 726 000 Écus et 8 000 cuivre.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 2 unless score @s i.s_cuivre matches 8000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 3 : il faut 8 000 cuivre au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 2 run scoreboard players remove @s i.s_cuivre 8000
execute if score @s i.b3 matches 2 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 726000
execute if score @s i.b3 matches 2 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 726000
execute if score @s i.b3 matches 3 unless score @s c.ecus matches 1597200.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 4 : 1 597 200 Écus et 16 000 cuivre.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 3 unless score @s i.s_cuivre matches 16000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 4 : il faut 16 000 cuivre au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 3 run scoreboard players remove @s i.s_cuivre 16000
execute if score @s i.b3 matches 3 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 1597200
execute if score @s i.b3 matches 3 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 1597200
execute if score @s i.b3 matches 4 unless score @s c.ecus matches 3513840.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 5 : 3 513 840 Écus et 32 000 cuivre.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 4 unless score @s i.s_cuivre matches 32000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 5 : il faut 32 000 cuivre au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 4 run scoreboard players remove @s i.s_cuivre 32000
execute if score @s i.b3 matches 4 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 3513840
execute if score @s i.b3 matches 4 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 3513840
execute if score @s i.b3 matches 5 unless score @s c.ecus matches 7730448.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 6 : 7 730 448 Écus et 1 600 mécanisme.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 5 unless score @s i.s_mecanisme matches 1600.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 6 : il faut 1 600 mécanisme au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 5 run scoreboard players remove @s i.s_mecanisme 1600
execute if score @s i.b3 matches 5 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 7730448
execute if score @s i.b3 matches 5 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 7730448
execute if score @s i.b3 matches 6 unless score @s c.ecus matches 17006985.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 7 : 17 006 985 Écus et 3 200 mécanisme.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 6 unless score @s i.s_mecanisme matches 3200.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 7 : il faut 3 200 mécanisme au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 6 run scoreboard players remove @s i.s_mecanisme 3200
execute if score @s i.b3 matches 6 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 17006985
execute if score @s i.b3 matches 6 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 17006985
execute if score @s i.b3 matches 7 unless score @s c.ecus matches 37415368.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 8 : 37 415 368 Écus et 6 400 mécanisme.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 7 unless score @s i.s_mecanisme matches 6400.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 8 : il faut 6 400 mécanisme au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 7 run scoreboard players remove @s i.s_mecanisme 6400
execute if score @s i.b3 matches 7 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 37415368
execute if score @s i.b3 matches 7 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 37415368
execute if score @s i.b3 matches 8 unless score @s c.ecus matches 82313810.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 9 : 82 313 810 Écus et 12 800 mécanisme.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 8 unless score @s i.s_mecanisme matches 12800.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 9 : il faut 12 800 mécanisme au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 8 run scoreboard players remove @s i.s_mecanisme 12800
execute if score @s i.b3 matches 8 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 82313810
execute if score @s i.b3 matches 8 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 82313810
execute if score @s i.b3 matches 9 unless score @s c.ecus matches 181090382.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 10 : 181 090 382 Écus et 25 600 mécanisme.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 9 unless score @s i.s_mecanisme matches 25600.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Niveau 10 : il faut 25 600 mécanisme au Nexus.",color:"red",bold:false,italic:false}]
execute if score @s i.b3 matches 9 run scoreboard players remove @s i.s_mecanisme 25600
execute if score @s i.b3 matches 9 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 181090382
execute if score @s i.b3 matches 9 if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 181090382
scoreboard players set @s i.rb 3
scoreboard players operation @s i.rt = #now i.g
scoreboard players add @s i.rt 72000
playsound minecraft:block.brewing_stand.brew master @s ~ ~ ~ 1 1
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Recherche lancée : Logistique, prête dans 1 heure de jeu.",color:"aqua",bold:false,italic:false}]
function industrie:menu/labo
