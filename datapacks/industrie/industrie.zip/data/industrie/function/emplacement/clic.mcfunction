scoreboard players operation #co i.t = @s i.own
scoreboard players operation #cs i.t = @s i.sid
execute on target run function industrie:emplacement/clic_j
data remove entity @s interaction
data remove entity @s attack
