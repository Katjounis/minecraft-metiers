execute unless score @s m.id = #co i.t run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Cet emplacement appartient à une autre île.",color:"gray",bold:false,italic:false}]
scoreboard players operation @s i.psl = #cs i.t
execute store result score @s i.pst run time query gametime
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.6 1.6
title @s actionbar [{"text":"Emplacement choisi : ","color":"#4cd964"},{"text":"la machine achetée dans la minute sera posée ici","color":"white"}]
function industrie:menu/comptoir
