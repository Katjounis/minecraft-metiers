$give @s minecraft:wither_skeleton_skull[minecraft:custom_data={industrie:1b},minecraft:lore=[{text:"Sorti du Nexus",color:"dark_gray",italic:false}]] $(q)
