execute if score @s i.pret matches 2 run scoreboard players set @s i.pban 30
scoreboard players set @s i.pret 0
scoreboard players set @s i.dette 0
scoreboard players set @s i.pj 0
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Prêt remboursé.",color:"green",bold:false,italic:false}]
