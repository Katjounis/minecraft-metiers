execute if score @s i.o_viande matches 2 run scoreboard players add @s i.x_viande 10
execute if score @s i.o_viande matches 2 if score @s i.x_viande matches 151.. run scoreboard players set @s i.x_viande 150
execute if score @s i.o_viande matches 3..4 if score @s i.x_viande matches ..500000000 run scoreboard players operation @s i.x_viande *= #2 i.g
function industrie:menu/produit_viande
