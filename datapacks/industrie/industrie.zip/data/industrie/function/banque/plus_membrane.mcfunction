execute if score @s i.o_membrane matches 2 run scoreboard players add @s i.x_membrane 10
execute if score @s i.o_membrane matches 2 if score @s i.x_membrane matches 151.. run scoreboard players set @s i.x_membrane 150
execute if score @s i.o_membrane matches 3..4 if score @s i.x_membrane matches ..500000000 run scoreboard players operation @s i.x_membrane *= #2 i.g
function industrie:menu/produit_membrane
