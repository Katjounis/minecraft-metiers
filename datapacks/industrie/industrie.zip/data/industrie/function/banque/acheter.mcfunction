execute if score @s i.bq matches 1 run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Tu as déjà ta Banque.",color:"gray",bold:false,italic:false}]
execute unless score @s i.rang matches 2.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"La Banque s'ouvre au rang Manufacture.",color:"red",bold:false,italic:false}]
execute unless score @s c.ecus matches 250000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Il te faut 250 000 Écus.",color:"red",bold:false,italic:false}]
execute if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.ecus 250000
execute if score @s c.ecus matches -2147483648.. run scoreboard players remove @s c.a_ind 250000
scoreboard players set @s i.bq 1
data modify storage industrie:t b set value {nom:"banque",old:"aucun",dx:25,dz:25,h:3.0,ech:2.0,code:92,lw:5.2,lh:4.8}
execute if dimension industrie:archipel run function industrie:batiment/poser
playsound minecraft:block.iron_door.close master @s ~ ~ ~ 1 0.6
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"La Banque de l'Archipel est à toi : choisis produit par produit ce que tu gardes ou vends.",color:"gold",bold:false,italic:false}]
function industrie:menu/banque
