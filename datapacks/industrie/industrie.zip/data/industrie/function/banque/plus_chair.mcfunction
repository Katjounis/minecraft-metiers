execute if score @s i.o_chair matches 2 run scoreboard players add @s i.x_chair 10
execute if score @s i.o_chair matches 2 if score @s i.x_chair matches 151.. run scoreboard players set @s i.x_chair 150
execute if score @s i.o_chair matches 3..4 if score @s i.x_chair matches ..500000000 run scoreboard players operation @s i.x_chair *= #2 i.g
function industrie:menu/produit_chair
