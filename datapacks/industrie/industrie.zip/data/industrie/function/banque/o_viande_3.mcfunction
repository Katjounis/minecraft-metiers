execute unless score @s i.bq matches 1 run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Il te faut la Banque.",color:"red",bold:false,italic:false}]
scoreboard players set @s i.o_viande 2
execute unless score @s i.x_viande matches 10..150 run scoreboard players set @s i.x_viande 70
function industrie:menu/produit_viande
