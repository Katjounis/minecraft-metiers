execute if score @s i.o_charbon matches 2 run scoreboard players add @s i.x_charbon 10
execute if score @s i.o_charbon matches 2 if score @s i.x_charbon matches 151.. run scoreboard players set @s i.x_charbon 150
execute if score @s i.o_charbon matches 3..4 if score @s i.x_charbon matches ..500000000 run scoreboard players operation @s i.x_charbon *= #2 i.g
function industrie:menu/produit_charbon
