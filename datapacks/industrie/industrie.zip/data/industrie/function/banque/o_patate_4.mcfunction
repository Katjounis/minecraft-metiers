execute unless score @s i.bq matches 1 run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Il te faut la Banque.",color:"red",bold:false,italic:false}]
scoreboard players set @s i.o_patate 3
execute if score @s i.x_patate matches ..999 run scoreboard players set @s i.x_patate 1000
function industrie:menu/produit_patate
