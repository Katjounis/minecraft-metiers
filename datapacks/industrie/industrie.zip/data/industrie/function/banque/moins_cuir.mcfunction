execute if score @s i.o_cuir matches 2 run scoreboard players remove @s i.x_cuir 10
execute if score @s i.o_cuir matches 2 if score @s i.x_cuir matches ..9 run scoreboard players set @s i.x_cuir 10
execute if score @s i.o_cuir matches 3..4 run scoreboard players operation @s i.x_cuir /= #2 i.g
execute if score @s i.o_cuir matches 3..4 if score @s i.x_cuir matches ..63 run scoreboard players set @s i.x_cuir 64
function industrie:menu/produit_cuir
