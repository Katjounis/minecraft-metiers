execute if score @s i.o_totem matches 2 run scoreboard players remove @s i.x_totem 10
execute if score @s i.o_totem matches 2 if score @s i.x_totem matches ..9 run scoreboard players set @s i.x_totem 10
execute if score @s i.o_totem matches 3..4 run scoreboard players operation @s i.x_totem /= #2 i.g
execute if score @s i.o_totem matches 3..4 if score @s i.x_totem matches ..63 run scoreboard players set @s i.x_totem 64
function industrie:menu/produit_totem
