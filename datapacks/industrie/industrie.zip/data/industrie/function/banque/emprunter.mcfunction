execute unless score @s i.bq matches 1 run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Il te faut la Banque (rang Manufacture).",color:"red",bold:false,italic:false}]
execute if score @s i.dette matches 1.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Un seul prêt à la fois.",color:"red",bold:false,italic:false}]
execute if score @s i.pban matches 1.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Après un retard, pas de nouveau prêt pendant 30 jours.",color:"red",bold:false,italic:false}]
scoreboard players operation #max i.t = @s i.r7
scoreboard players operation #max i.t *= #3 i.g
scoreboard players set #pm i.t 0
execute if score @s i.rang matches 1 run scoreboard players set #pm i.t 0
execute if score @s i.rang matches 2 run scoreboard players set #pm i.t 500000
execute if score @s i.rang matches 3 run scoreboard players set #pm i.t 5000000
execute if score @s i.rang matches 4 run scoreboard players set #pm i.t 30000000
execute if score @s i.rang matches 5 run scoreboard players set #pm i.t 100000000
execute if score #max i.t > #pm i.t run scoreboard players operation #max i.t = #pm i.t
execute unless score #max i.t matches 10000.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Tes recettes sont encore trop faibles pour un prêt (3 jours de recettes, 10 000 Écus au moins).",color:"red",bold:false,italic:false}]
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus += #max i.t
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.a_ind += #max i.t
scoreboard players operation @s i.dette = #max i.t
scoreboard players operation #x i.t = #max i.t
scoreboard players operation #x i.t /= #10 i.g
scoreboard players operation @s i.dette += #x i.t
scoreboard players set @s i.pret 1
scoreboard players set @s i.pj 0
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 0.8
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Prêt accordé : remboursé tout seul par une part de tes ventes.",color:"green",bold:false,italic:false}]
function industrie:menu/banque
