scoreboard players set #fg i.t 0
execute unless score @s i.o_pierre matches 0 if score @s i.s_pierre matches 1.. run function industrie:banque/garde_pierre
execute unless score @s i.o_charbon matches 0 if score @s i.s_charbon matches 1.. run function industrie:banque/garde_charbon
execute unless score @s i.o_cuivre matches 0 if score @s i.s_cuivre matches 1.. run function industrie:banque/garde_cuivre
execute unless score @s i.o_canne matches 0 if score @s i.s_canne matches 1.. run function industrie:banque/garde_canne
execute unless score @s i.o_verrue matches 0 if score @s i.s_verrue matches 1.. run function industrie:banque/garde_verrue
execute unless score @s i.o_citrouille matches 0 if score @s i.s_citrouille matches 1.. run function industrie:banque/garde_citrouille
execute unless score @s i.o_ble matches 0 if score @s i.s_ble matches 1.. run function industrie:banque/garde_ble
execute unless score @s i.o_carotte matches 0 if score @s i.s_carotte matches 1.. run function industrie:banque/garde_carotte
execute unless score @s i.o_patate matches 0 if score @s i.s_patate matches 1.. run function industrie:banque/garde_patate
execute unless score @s i.o_betterave matches 0 if score @s i.s_betterave matches 1.. run function industrie:banque/garde_betterave
execute unless score @s i.o_pasteque matches 0 if score @s i.s_pasteque matches 1.. run function industrie:banque/garde_pasteque
execute unless score @s i.o_fer matches 0 if score @s i.s_fer matches 1.. run function industrie:banque/garde_fer
execute unless score @s i.o_or matches 0 if score @s i.s_or matches 1.. run function industrie:banque/garde_or
execute unless score @s i.o_emeraude matches 0 if score @s i.s_emeraude matches 1.. run function industrie:banque/garde_emeraude
execute unless score @s i.o_diamant matches 0 if score @s i.s_diamant matches 1.. run function industrie:banque/garde_diamant
execute unless score @s i.o_netherite matches 0 if score @s i.s_netherite matches 1.. run function industrie:banque/garde_netherite
execute unless score @s i.o_acier matches 0 if score @s i.s_acier matches 1.. run function industrie:banque/garde_acier
execute unless score @s i.o_elixir matches 0 if score @s i.s_elixir matches 1.. run function industrie:banque/garde_elixir
execute unless score @s i.o_mecanisme matches 0 if score @s i.s_mecanisme matches 1.. run function industrie:banque/garde_mecanisme
execute unless score @s i.o_bijou matches 0 if score @s i.s_bijou matches 1.. run function industrie:banque/garde_bijou
execute unless score @s i.o_relique matches 0 if score @s i.s_relique matches 1.. run function industrie:banque/garde_relique
execute unless score @s i.o_chair matches 0 if score @s i.s_chair matches 1.. run function industrie:banque/garde_chair
execute unless score @s i.o_os matches 0 if score @s i.s_os matches 1.. run function industrie:banque/garde_os
execute unless score @s i.o_ficelle matches 0 if score @s i.s_ficelle matches 1.. run function industrie:banque/garde_ficelle
execute unless score @s i.o_oeil matches 0 if score @s i.s_oeil matches 1.. run function industrie:banque/garde_oeil
execute unless score @s i.o_viande matches 0 if score @s i.s_viande matches 1.. run function industrie:banque/garde_viande
execute unless score @s i.o_plume matches 0 if score @s i.s_plume matches 1.. run function industrie:banque/garde_plume
execute unless score @s i.o_laine matches 0 if score @s i.s_laine matches 1.. run function industrie:banque/garde_laine
execute unless score @s i.o_cuir matches 0 if score @s i.s_cuir matches 1.. run function industrie:banque/garde_cuir
execute unless score @s i.o_slime matches 0 if score @s i.s_slime matches 1.. run function industrie:banque/garde_slime
execute unless score @s i.o_creme matches 0 if score @s i.s_creme matches 1.. run function industrie:banque/garde_creme
execute unless score @s i.o_poudre matches 0 if score @s i.s_poudre matches 1.. run function industrie:banque/garde_poudre
execute unless score @s i.o_membrane matches 0 if score @s i.s_membrane matches 1.. run function industrie:banque/garde_membrane
execute unless score @s i.o_prisma matches 0 if score @s i.s_prisma matches 1.. run function industrie:banque/garde_prisma
execute unless score @s i.o_perle matches 0 if score @s i.s_perle matches 1.. run function industrie:banque/garde_perle
execute unless score @s i.o_blaze matches 0 if score @s i.s_blaze matches 1.. run function industrie:banque/garde_blaze
execute unless score @s i.o_larme matches 0 if score @s i.s_larme matches 1.. run function industrie:banque/garde_larme
execute unless score @s i.o_breeze matches 0 if score @s i.s_breeze matches 1.. run function industrie:banque/garde_breeze
execute unless score @s i.o_crane matches 0 if score @s i.s_crane matches 1.. run function industrie:banque/garde_crane
execute unless score @s i.o_carapace matches 0 if score @s i.s_carapace matches 1.. run function industrie:banque/garde_carapace
execute unless score @s i.o_totem matches 0 if score @s i.s_totem matches 1.. run function industrie:banque/garde_totem
scoreboard players operation #fg i.t /= #100 i.g
execute if score #fg i.t matches 1.. if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus -= #fg i.t
execute if score #fg i.t matches 1.. if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.a_ind -= #fg i.t
execute if score #fg i.t matches 1.. run scoreboard players operation @s i.jn -= #fg i.t
