execute if score @s i.o_breeze matches 2 run scoreboard players add @s i.x_breeze 10
execute if score @s i.o_breeze matches 2 if score @s i.x_breeze matches 151.. run scoreboard players set @s i.x_breeze 150
execute if score @s i.o_breeze matches 3..4 if score @s i.x_breeze matches ..500000000 run scoreboard players operation @s i.x_breeze *= #2 i.g
function industrie:menu/produit_breeze
