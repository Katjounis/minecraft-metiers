execute if score @s i.o_relique matches 2 run scoreboard players add @s i.x_relique 10
execute if score @s i.o_relique matches 2 if score @s i.x_relique matches 151.. run scoreboard players set @s i.x_relique 150
execute if score @s i.o_relique matches 3..4 if score @s i.x_relique matches ..500000000 run scoreboard players operation @s i.x_relique *= #2 i.g
function industrie:menu/produit_relique
