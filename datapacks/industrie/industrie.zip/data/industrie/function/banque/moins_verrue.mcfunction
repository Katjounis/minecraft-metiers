execute if score @s i.o_verrue matches 2 run scoreboard players remove @s i.x_verrue 10
execute if score @s i.o_verrue matches 2 if score @s i.x_verrue matches ..9 run scoreboard players set @s i.x_verrue 10
execute if score @s i.o_verrue matches 3..4 run scoreboard players operation @s i.x_verrue /= #2 i.g
execute if score @s i.o_verrue matches 3..4 if score @s i.x_verrue matches ..63 run scoreboard players set @s i.x_verrue 64
function industrie:menu/produit_verrue
