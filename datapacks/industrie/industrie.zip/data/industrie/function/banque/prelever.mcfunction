scoreboard players set #y i.t 25
execute if score @s i.pret matches 2 run scoreboard players set #y i.t 50
scoreboard players operation #r i.t = #N i.t
scoreboard players operation #r i.t /= #100 i.g
scoreboard players operation #r i.t *= #y i.t
scoreboard players operation #r i.t /= #100 i.g
execute if score #r i.t > @s i.dette run scoreboard players operation #r i.t = @s i.dette
scoreboard players operation @s i.dette -= #r i.t
scoreboard players operation #r i.t *= #100 i.g
scoreboard players operation #N i.t -= #r i.t
execute if score @s i.dette matches ..0 run function industrie:banque/solde
