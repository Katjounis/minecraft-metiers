scoreboard players set @s i.pret 2
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Prêt en retard : 50 % de tes ventes partent au remboursement et ta réputation est gelée jusqu'au solde.",color:"red",bold:false,italic:false}]
