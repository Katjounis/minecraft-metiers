execute if score @s i.o_betterave matches 2 run scoreboard players add @s i.x_betterave 10
execute if score @s i.o_betterave matches 2 if score @s i.x_betterave matches 151.. run scoreboard players set @s i.x_betterave 150
execute if score @s i.o_betterave matches 3..4 if score @s i.x_betterave matches ..500000000 run scoreboard players operation @s i.x_betterave *= #2 i.g
function industrie:menu/produit_betterave
