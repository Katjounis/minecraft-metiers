execute if score @s i.o_totem matches 2 run scoreboard players add @s i.x_totem 10
execute if score @s i.o_totem matches 2 if score @s i.x_totem matches 151.. run scoreboard players set @s i.x_totem 150
execute if score @s i.o_totem matches 3..4 if score @s i.x_totem matches ..500000000 run scoreboard players operation @s i.x_totem *= #2 i.g
function industrie:menu/produit_totem
