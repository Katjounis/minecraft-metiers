$give @s minecraft:blaze_rod[minecraft:custom_data={industrie:1b},minecraft:lore=[{text:"Sorti du Nexus",color:"dark_gray",italic:false}]] $(q)
