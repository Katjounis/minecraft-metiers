scoreboard players set #q i.t 64
execute if score @s i.s_cuivre < #q i.t run scoreboard players operation #q i.t = @s i.s_cuivre
execute unless score #q i.t matches 1.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Rien en stock.",color:"gray",bold:false,italic:false}]
scoreboard players set #cout i.t 0
execute if score @s i.w_cuivre matches 64.. run scoreboard players operation #cout i.t = #q i.t
scoreboard players set #y i.t 800
scoreboard players operation #cout i.t *= #y i.t
scoreboard players operation #cout i.t /= #100 i.g
execute unless score @s c.ecus >= #cout i.t run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Au-delà de 64 par jour, le retrait coûte 4 fois le prix du Commerce : pas assez d'Écus.",color:"red",bold:false,italic:false}]
execute if score #cout i.t matches 1.. if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus -= #cout i.t
execute if score #cout i.t matches 1.. if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.a_ind -= #cout i.t
scoreboard players operation @s i.s_cuivre -= #q i.t
scoreboard players operation @s i.w_cuivre += #q i.t
execute store result storage industrie:t g.q int 1 run scoreboard players get #q i.t
function industrie:banque/donner_cuivre with storage industrie:t g
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Sorti du Nexus. Ces objets portent la marque du Nexus : le Commerce ne les rachète pas.",color:"gray",bold:false,italic:false}]
function industrie:menu/produit_cuivre
