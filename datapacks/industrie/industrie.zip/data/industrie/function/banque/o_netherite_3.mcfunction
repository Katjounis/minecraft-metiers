execute unless score @s i.bq matches 1 run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Il te faut la Banque.",color:"red",bold:false,italic:false}]
scoreboard players set @s i.o_netherite 2
execute unless score @s i.x_netherite matches 10..150 run scoreboard players set @s i.x_netherite 70
function industrie:menu/produit_netherite
