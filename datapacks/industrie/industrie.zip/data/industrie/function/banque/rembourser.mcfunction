execute unless score @s i.dette matches 1.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Aucun prêt en cours.",color:"gray",bold:false,italic:false}]
scoreboard players operation #r i.t = @s i.dette
execute if score #r i.t > @s c.ecus run scoreboard players operation #r i.t = @s c.ecus
execute unless score #r i.t matches 1.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Pas d'Écus sur ton compte.",color:"red",bold:false,italic:false}]
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus -= #r i.t
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.a_ind -= #r i.t
scoreboard players operation @s i.dette -= #r i.t
execute if score @s i.dette matches ..0 run function industrie:banque/solde
function industrie:menu/banque
