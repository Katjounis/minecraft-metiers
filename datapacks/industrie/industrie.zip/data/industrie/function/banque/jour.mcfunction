scoreboard players add @s i.pj 1
execute if score @s i.pj matches 15.. if score @s i.pret matches 1 run function industrie:banque/retard
