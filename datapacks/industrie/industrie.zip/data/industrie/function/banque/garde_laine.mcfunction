scoreboard players operation #x i.t = @s i.s_laine
scoreboard players operation #x i.t /= #24 i.g
scoreboard players set #y i.t 400
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation #x i.t /= #1000 i.g
scoreboard players operation #fg i.t += #x i.t
