execute unless data storage industrie:file l[0] run return 0
data modify storage industrie:t k set from storage industrie:file l[0]
data remove storage industrie:file l[0]
function industrie:chantier_m with storage industrie:t k
execute if data storage industrie:file l[0] run schedule function industrie:chantier 5t append
