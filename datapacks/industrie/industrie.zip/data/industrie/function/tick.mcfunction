scoreboard players enable @a industrie
execute as @a[scores={industrie=1..}] at @s run function industrie:trigger
execute as @a[scores={industrie=..-1}] at @s run function industrie:saisie
execute as @e[type=minecraft:interaction,tag=ind.mi] at @s if data entity @s interaction run function industrie:machine/clic
execute as @e[type=minecraft:interaction,tag=ind.bi] at @s if data entity @s interaction run function industrie:batiment/clic
scoreboard players add #sec i.g 1
execute if score #sec i.g matches 20.. run function industrie:seconde
