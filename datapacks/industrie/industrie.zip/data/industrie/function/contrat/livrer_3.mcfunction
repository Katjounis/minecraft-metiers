execute unless score @s i.c3p matches 1.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Pas de contrat ici aujourd'hui.",color:"gray",bold:false,italic:false}]
execute if score @s i.c3f matches 1 run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Contrat déjà livré.",color:"gray",bold:false,italic:false}]
scoreboard players set #ok i.t 0
execute if score @s i.c3p matches 1 if score @s i.s_pierre >= @s i.c3q run scoreboard players set #ok i.t 1
execute if score @s i.c3p matches 2 if score @s i.s_charbon >= @s i.c3q run scoreboard players set #ok i.t 2
execute if score @s i.c3p matches 3 if score @s i.s_cuivre >= @s i.c3q run scoreboard players set #ok i.t 3
execute if score @s i.c3p matches 4 if score @s i.s_canne >= @s i.c3q run scoreboard players set #ok i.t 4
execute if score @s i.c3p matches 5 if score @s i.s_verrue >= @s i.c3q run scoreboard players set #ok i.t 5
execute if score @s i.c3p matches 6 if score @s i.s_citrouille >= @s i.c3q run scoreboard players set #ok i.t 6
execute if score @s i.c3p matches 7 if score @s i.s_ble >= @s i.c3q run scoreboard players set #ok i.t 7
execute if score @s i.c3p matches 8 if score @s i.s_carotte >= @s i.c3q run scoreboard players set #ok i.t 8
execute if score @s i.c3p matches 9 if score @s i.s_patate >= @s i.c3q run scoreboard players set #ok i.t 9
execute if score @s i.c3p matches 10 if score @s i.s_betterave >= @s i.c3q run scoreboard players set #ok i.t 10
execute if score @s i.c3p matches 11 if score @s i.s_pasteque >= @s i.c3q run scoreboard players set #ok i.t 11
execute if score @s i.c3p matches 12 if score @s i.s_fer >= @s i.c3q run scoreboard players set #ok i.t 12
execute if score @s i.c3p matches 13 if score @s i.s_or >= @s i.c3q run scoreboard players set #ok i.t 13
execute if score @s i.c3p matches 14 if score @s i.s_emeraude >= @s i.c3q run scoreboard players set #ok i.t 14
execute if score @s i.c3p matches 15 if score @s i.s_diamant >= @s i.c3q run scoreboard players set #ok i.t 15
execute if score @s i.c3p matches 16 if score @s i.s_netherite >= @s i.c3q run scoreboard players set #ok i.t 16
execute if score @s i.c3p matches 17 if score @s i.s_acier >= @s i.c3q run scoreboard players set #ok i.t 17
execute if score @s i.c3p matches 18 if score @s i.s_elixir >= @s i.c3q run scoreboard players set #ok i.t 18
execute if score @s i.c3p matches 19 if score @s i.s_mecanisme >= @s i.c3q run scoreboard players set #ok i.t 19
execute if score @s i.c3p matches 20 if score @s i.s_bijou >= @s i.c3q run scoreboard players set #ok i.t 20
execute if score @s i.c3p matches 21 if score @s i.s_relique >= @s i.c3q run scoreboard players set #ok i.t 21
execute if score @s i.c3p matches 22 if score @s i.s_chair >= @s i.c3q run scoreboard players set #ok i.t 22
execute if score @s i.c3p matches 23 if score @s i.s_os >= @s i.c3q run scoreboard players set #ok i.t 23
execute if score @s i.c3p matches 24 if score @s i.s_ficelle >= @s i.c3q run scoreboard players set #ok i.t 24
execute if score @s i.c3p matches 25 if score @s i.s_oeil >= @s i.c3q run scoreboard players set #ok i.t 25
execute if score @s i.c3p matches 26 if score @s i.s_viande >= @s i.c3q run scoreboard players set #ok i.t 26
execute if score @s i.c3p matches 27 if score @s i.s_plume >= @s i.c3q run scoreboard players set #ok i.t 27
execute if score @s i.c3p matches 28 if score @s i.s_laine >= @s i.c3q run scoreboard players set #ok i.t 28
execute if score @s i.c3p matches 29 if score @s i.s_cuir >= @s i.c3q run scoreboard players set #ok i.t 29
execute if score @s i.c3p matches 30 if score @s i.s_slime >= @s i.c3q run scoreboard players set #ok i.t 30
execute if score @s i.c3p matches 31 if score @s i.s_creme >= @s i.c3q run scoreboard players set #ok i.t 31
execute if score @s i.c3p matches 32 if score @s i.s_poudre >= @s i.c3q run scoreboard players set #ok i.t 32
execute if score @s i.c3p matches 33 if score @s i.s_membrane >= @s i.c3q run scoreboard players set #ok i.t 33
execute if score @s i.c3p matches 34 if score @s i.s_prisma >= @s i.c3q run scoreboard players set #ok i.t 34
execute if score @s i.c3p matches 35 if score @s i.s_perle >= @s i.c3q run scoreboard players set #ok i.t 35
execute if score @s i.c3p matches 36 if score @s i.s_blaze >= @s i.c3q run scoreboard players set #ok i.t 36
execute if score @s i.c3p matches 37 if score @s i.s_larme >= @s i.c3q run scoreboard players set #ok i.t 37
execute if score @s i.c3p matches 38 if score @s i.s_breeze >= @s i.c3q run scoreboard players set #ok i.t 38
execute if score @s i.c3p matches 39 if score @s i.s_crane >= @s i.c3q run scoreboard players set #ok i.t 39
execute if score @s i.c3p matches 40 if score @s i.s_carapace >= @s i.c3q run scoreboard players set #ok i.t 40
execute if score @s i.c3p matches 41 if score @s i.s_totem >= @s i.c3q run scoreboard players set #ok i.t 41
execute if score #ok i.t matches 0 run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Pas assez de marchandise au Nexus pour ce contrat.",color:"red",bold:false,italic:false}]
execute if score #ok i.t matches 1 run scoreboard players operation @s i.s_pierre -= @s i.c3q
execute if score #ok i.t matches 2 run scoreboard players operation @s i.s_charbon -= @s i.c3q
execute if score #ok i.t matches 3 run scoreboard players operation @s i.s_cuivre -= @s i.c3q
execute if score #ok i.t matches 4 run scoreboard players operation @s i.s_canne -= @s i.c3q
execute if score #ok i.t matches 5 run scoreboard players operation @s i.s_verrue -= @s i.c3q
execute if score #ok i.t matches 6 run scoreboard players operation @s i.s_citrouille -= @s i.c3q
execute if score #ok i.t matches 7 run scoreboard players operation @s i.s_ble -= @s i.c3q
execute if score #ok i.t matches 8 run scoreboard players operation @s i.s_carotte -= @s i.c3q
execute if score #ok i.t matches 9 run scoreboard players operation @s i.s_patate -= @s i.c3q
execute if score #ok i.t matches 10 run scoreboard players operation @s i.s_betterave -= @s i.c3q
execute if score #ok i.t matches 11 run scoreboard players operation @s i.s_pasteque -= @s i.c3q
execute if score #ok i.t matches 12 run scoreboard players operation @s i.s_fer -= @s i.c3q
execute if score #ok i.t matches 13 run scoreboard players operation @s i.s_or -= @s i.c3q
execute if score #ok i.t matches 14 run scoreboard players operation @s i.s_emeraude -= @s i.c3q
execute if score #ok i.t matches 15 run scoreboard players operation @s i.s_diamant -= @s i.c3q
execute if score #ok i.t matches 16 run scoreboard players operation @s i.s_netherite -= @s i.c3q
execute if score #ok i.t matches 17 run scoreboard players operation @s i.s_acier -= @s i.c3q
execute if score #ok i.t matches 18 run scoreboard players operation @s i.s_elixir -= @s i.c3q
execute if score #ok i.t matches 19 run scoreboard players operation @s i.s_mecanisme -= @s i.c3q
execute if score #ok i.t matches 20 run scoreboard players operation @s i.s_bijou -= @s i.c3q
execute if score #ok i.t matches 21 run scoreboard players operation @s i.s_relique -= @s i.c3q
execute if score #ok i.t matches 22 run scoreboard players operation @s i.s_chair -= @s i.c3q
execute if score #ok i.t matches 23 run scoreboard players operation @s i.s_os -= @s i.c3q
execute if score #ok i.t matches 24 run scoreboard players operation @s i.s_ficelle -= @s i.c3q
execute if score #ok i.t matches 25 run scoreboard players operation @s i.s_oeil -= @s i.c3q
execute if score #ok i.t matches 26 run scoreboard players operation @s i.s_viande -= @s i.c3q
execute if score #ok i.t matches 27 run scoreboard players operation @s i.s_plume -= @s i.c3q
execute if score #ok i.t matches 28 run scoreboard players operation @s i.s_laine -= @s i.c3q
execute if score #ok i.t matches 29 run scoreboard players operation @s i.s_cuir -= @s i.c3q
execute if score #ok i.t matches 30 run scoreboard players operation @s i.s_slime -= @s i.c3q
execute if score #ok i.t matches 31 run scoreboard players operation @s i.s_creme -= @s i.c3q
execute if score #ok i.t matches 32 run scoreboard players operation @s i.s_poudre -= @s i.c3q
execute if score #ok i.t matches 33 run scoreboard players operation @s i.s_membrane -= @s i.c3q
execute if score #ok i.t matches 34 run scoreboard players operation @s i.s_prisma -= @s i.c3q
execute if score #ok i.t matches 35 run scoreboard players operation @s i.s_perle -= @s i.c3q
execute if score #ok i.t matches 36 run scoreboard players operation @s i.s_blaze -= @s i.c3q
execute if score #ok i.t matches 37 run scoreboard players operation @s i.s_larme -= @s i.c3q
execute if score #ok i.t matches 38 run scoreboard players operation @s i.s_breeze -= @s i.c3q
execute if score #ok i.t matches 39 run scoreboard players operation @s i.s_crane -= @s i.c3q
execute if score #ok i.t matches 40 run scoreboard players operation @s i.s_carapace -= @s i.c3q
execute if score #ok i.t matches 41 run scoreboard players operation @s i.s_totem -= @s i.c3q
scoreboard players set @s i.c3f 1
scoreboard players add @s i.ctr 1
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus += @s i.c3r
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.a_ind += @s i.c3r
scoreboard players operation @s i.jn += @s i.c3r
scoreboard players operation #x i.t = @s i.rang
scoreboard players set #y i.t 200
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation @s i.ri += #x i.t
execute if score @s i.rang matches 3.. run scoreboard players add @s m.ecl 1
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.2
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Contrat livré : payé sans dégressif, réputation en plus.",color:"green",bold:false,italic:false}]
function industrie:menu/halle
