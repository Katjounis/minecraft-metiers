execute store result score #r i.t run random value 0..100000
scoreboard players operation #r i.t %= #ne i.t
execute store result storage industrie:t r.r int 1 run scoreboard players get #r i.t
$data modify storage industrie:t r.c set value $(c)
function industrie:contrat/tirer_m with storage industrie:t r
