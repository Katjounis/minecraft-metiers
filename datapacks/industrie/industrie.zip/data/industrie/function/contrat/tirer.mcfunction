scoreboard players set #nc i.t 0
execute if score @s i.rang matches 1 run scoreboard players set #nc i.t 1
execute if score @s i.rang matches 2 run scoreboard players set #nc i.t 2
execute if score @s i.rang matches 3 run scoreboard players set #nc i.t 3
execute if score @s i.rang matches 4 run scoreboard players set #nc i.t 3
execute if score @s i.rang matches 5 run scoreboard players set #nc i.t 3
scoreboard players set @s i.c1p 0
scoreboard players set @s i.c2p 0
scoreboard players set @s i.c3p 0
scoreboard players set @s i.c1f 0
scoreboard players set @s i.c2f 0
scoreboard players set @s i.c3f 0
data modify storage industrie:t el set value []
execute if score @s i.s_pierre matches 1.. run data modify storage industrie:t el append value 0
execute if score @s i.s_charbon matches 1.. run data modify storage industrie:t el append value 1
execute if score @s i.s_cuivre matches 1.. run data modify storage industrie:t el append value 2
execute if score @s i.s_canne matches 1.. run data modify storage industrie:t el append value 3
execute if score @s i.s_verrue matches 1.. run data modify storage industrie:t el append value 4
execute if score @s i.s_citrouille matches 1.. run data modify storage industrie:t el append value 5
execute if score @s i.s_ble matches 1.. run data modify storage industrie:t el append value 6
execute if score @s i.s_carotte matches 1.. run data modify storage industrie:t el append value 7
execute if score @s i.s_patate matches 1.. run data modify storage industrie:t el append value 8
execute if score @s i.s_betterave matches 1.. run data modify storage industrie:t el append value 9
execute if score @s i.s_pasteque matches 1.. run data modify storage industrie:t el append value 10
execute if score @s i.s_fer matches 1.. run data modify storage industrie:t el append value 11
execute if score @s i.s_or matches 1.. run data modify storage industrie:t el append value 12
execute if score @s i.s_emeraude matches 1.. run data modify storage industrie:t el append value 13
execute if score @s i.s_diamant matches 1.. run data modify storage industrie:t el append value 14
execute if score @s i.s_netherite matches 1.. run data modify storage industrie:t el append value 15
execute if score @s i.s_acier matches 1.. run data modify storage industrie:t el append value 16
execute if score @s i.s_elixir matches 1.. run data modify storage industrie:t el append value 17
execute if score @s i.s_mecanisme matches 1.. run data modify storage industrie:t el append value 18
execute if score @s i.s_bijou matches 1.. run data modify storage industrie:t el append value 19
execute if score @s i.s_relique matches 1.. run data modify storage industrie:t el append value 20
execute if score @s i.s_chair matches 1.. run data modify storage industrie:t el append value 21
execute if score @s i.s_os matches 1.. run data modify storage industrie:t el append value 22
execute if score @s i.s_ficelle matches 1.. run data modify storage industrie:t el append value 23
execute if score @s i.s_oeil matches 1.. run data modify storage industrie:t el append value 24
execute if score @s i.s_viande matches 1.. run data modify storage industrie:t el append value 25
execute if score @s i.s_plume matches 1.. run data modify storage industrie:t el append value 26
execute if score @s i.s_laine matches 1.. run data modify storage industrie:t el append value 27
execute if score @s i.s_cuir matches 1.. run data modify storage industrie:t el append value 28
execute if score @s i.s_slime matches 1.. run data modify storage industrie:t el append value 29
execute if score @s i.s_creme matches 1.. run data modify storage industrie:t el append value 30
execute if score @s i.s_poudre matches 1.. run data modify storage industrie:t el append value 31
execute if score @s i.s_membrane matches 1.. run data modify storage industrie:t el append value 32
execute if score @s i.s_prisma matches 1.. run data modify storage industrie:t el append value 33
execute if score @s i.s_perle matches 1.. run data modify storage industrie:t el append value 34
execute if score @s i.s_blaze matches 1.. run data modify storage industrie:t el append value 35
execute if score @s i.s_larme matches 1.. run data modify storage industrie:t el append value 36
execute if score @s i.s_breeze matches 1.. run data modify storage industrie:t el append value 37
execute if score @s i.s_crane matches 1.. run data modify storage industrie:t el append value 38
execute if score @s i.s_carapace matches 1.. run data modify storage industrie:t el append value 39
execute if score @s i.s_totem matches 1.. run data modify storage industrie:t el append value 40
execute unless data storage industrie:t el[0] run data modify storage industrie:t el append value 0
execute store result score #ne i.t run data get storage industrie:t el
execute if score #nc i.t matches 1.. run function industrie:contrat/tirer_un {c:1}
execute if score #nc i.t matches 2.. run function industrie:contrat/tirer_un {c:2}
execute if score #nc i.t matches 3.. run function industrie:contrat/tirer_un {c:3}
