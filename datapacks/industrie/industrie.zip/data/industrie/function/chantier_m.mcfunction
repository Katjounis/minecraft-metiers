$execute in industrie:archipel positioned $(ox) 63 $(oz) run function industrie:parcelle/batir_$(ring)
$execute in industrie:archipel positioned $(ox) 64 $(oz) run function industrie:parcelle/slots {idx:$(idx),own:$(own)}
$execute in industrie:archipel run forceload remove $(ox) $(oz) $(ox2) $(oz2)
$execute in industrie:archipel positioned $(ox) 64 $(oz) run particle minecraft:happy_villager ~16 ~1 ~16 10 1 10 0 200 force
