tellraw @a[scores={i.ile=0..}] [{text:"[Bourse de l'Archipel] ",color:"#F7C843",bold:true},{storage:"industrie:g",nbt:"ev",color:"yellow",bold:false}]
