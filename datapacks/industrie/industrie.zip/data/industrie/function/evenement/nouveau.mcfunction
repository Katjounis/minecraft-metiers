scoreboard players set #evt i.g 0
scoreboard players set #evp i.g 0
scoreboard players set #evm i.g 100
scoreboard players set #foire i.g 100
execute store result score #ev i.g run random value 0..4
execute store result score #r i.t run random value 0..1000
scoreboard players set #y i.t 12
scoreboard players operation #r i.t %= #y i.t
execute if score #r i.t matches 0 run scoreboard players set #evp i.g 12
execute if score #r i.t matches 1 run scoreboard players set #evp i.g 13
execute if score #r i.t matches 2 run scoreboard players set #evp i.g 15
execute if score #r i.t matches 3 run scoreboard players set #evp i.g 14
execute if score #r i.t matches 4 run scoreboard players set #evp i.g 17
execute if score #r i.t matches 5 run scoreboard players set #evp i.g 19
execute if score #r i.t matches 6 run scoreboard players set #evp i.g 20
execute if score #r i.t matches 7 run scoreboard players set #evp i.g 18
execute if score #r i.t matches 8 run scoreboard players set #evp i.g 7
execute if score #r i.t matches 9 run scoreboard players set #evp i.g 16
execute if score #r i.t matches 10 run scoreboard players set #evp i.g 35
execute if score #r i.t matches 11 run scoreboard players set #evp i.g 36
execute if score #ev i.g matches 0 run scoreboard players set #evp i.g 0
execute if score #ev i.g matches 1 run scoreboard players set #evm i.g 160
execute if score #ev i.g matches 2 run scoreboard players set #evm i.g 50
execute if score #ev i.g matches 3 run scoreboard players set #evp i.g 13
execute if score #ev i.g matches 3 run scoreboard players set #evm i.g 150
execute if score #ev i.g matches 4 run scoreboard players set #evp i.g 0
execute if score #ev i.g matches 4 run scoreboard players set #foire i.g 150
data modify storage industrie:g ev set value "Marché calme."
execute if score #ev i.g matches 1 if score #evp i.g matches 1 run data modify storage industrie:g ev set value "Pénurie de pierre : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 1 run data modify storage industrie:g ev set value "Krach : pierre à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 2 run data modify storage industrie:g ev set value "Pénurie de charbon : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 2 run data modify storage industrie:g ev set value "Krach : charbon à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 3 run data modify storage industrie:g ev set value "Pénurie de cuivre : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 3 run data modify storage industrie:g ev set value "Krach : cuivre à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 4 run data modify storage industrie:g ev set value "Pénurie de canne à sucre : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 4 run data modify storage industrie:g ev set value "Krach : canne à sucre à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 5 run data modify storage industrie:g ev set value "Pénurie de verrues du nether : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 5 run data modify storage industrie:g ev set value "Krach : verrues du nether à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 6 run data modify storage industrie:g ev set value "Pénurie de citrouille : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 6 run data modify storage industrie:g ev set value "Krach : citrouille à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 7 run data modify storage industrie:g ev set value "Pénurie de blé : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 7 run data modify storage industrie:g ev set value "Krach : blé à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 8 run data modify storage industrie:g ev set value "Pénurie de carotte : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 8 run data modify storage industrie:g ev set value "Krach : carotte à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 9 run data modify storage industrie:g ev set value "Pénurie de pomme de terre : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 9 run data modify storage industrie:g ev set value "Krach : pomme de terre à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 10 run data modify storage industrie:g ev set value "Pénurie de betterave : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 10 run data modify storage industrie:g ev set value "Krach : betterave à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 11 run data modify storage industrie:g ev set value "Pénurie de pastèque : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 11 run data modify storage industrie:g ev set value "Krach : pastèque à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 12 run data modify storage industrie:g ev set value "Pénurie de fer : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 12 run data modify storage industrie:g ev set value "Krach : fer à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 13 run data modify storage industrie:g ev set value "Pénurie de or : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 13 run data modify storage industrie:g ev set value "Krach : or à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 14 run data modify storage industrie:g ev set value "Pénurie de émeraude : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 14 run data modify storage industrie:g ev set value "Krach : émeraude à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 15 run data modify storage industrie:g ev set value "Pénurie de diamant : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 15 run data modify storage industrie:g ev set value "Krach : diamant à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 16 run data modify storage industrie:g ev set value "Pénurie de netherite : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 16 run data modify storage industrie:g ev set value "Krach : netherite à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 17 run data modify storage industrie:g ev set value "Pénurie de acier : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 17 run data modify storage industrie:g ev set value "Krach : acier à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 18 run data modify storage industrie:g ev set value "Pénurie de élixir : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 18 run data modify storage industrie:g ev set value "Krach : élixir à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 19 run data modify storage industrie:g ev set value "Pénurie de mécanisme : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 19 run data modify storage industrie:g ev set value "Krach : mécanisme à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 20 run data modify storage industrie:g ev set value "Pénurie de bijou : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 20 run data modify storage industrie:g ev set value "Krach : bijou à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 21 run data modify storage industrie:g ev set value "Pénurie de relique : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 21 run data modify storage industrie:g ev set value "Krach : relique à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 22 run data modify storage industrie:g ev set value "Pénurie de chair putréfiée : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 22 run data modify storage industrie:g ev set value "Krach : chair putréfiée à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 23 run data modify storage industrie:g ev set value "Pénurie de os : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 23 run data modify storage industrie:g ev set value "Krach : os à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 24 run data modify storage industrie:g ev set value "Pénurie de ficelle : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 24 run data modify storage industrie:g ev set value "Krach : ficelle à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 25 run data modify storage industrie:g ev set value "Pénurie de œil d'araignée : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 25 run data modify storage industrie:g ev set value "Krach : œil d'araignée à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 26 run data modify storage industrie:g ev set value "Pénurie de viande : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 26 run data modify storage industrie:g ev set value "Krach : viande à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 27 run data modify storage industrie:g ev set value "Pénurie de plume : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 27 run data modify storage industrie:g ev set value "Krach : plume à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 28 run data modify storage industrie:g ev set value "Pénurie de laine : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 28 run data modify storage industrie:g ev set value "Krach : laine à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 29 run data modify storage industrie:g ev set value "Pénurie de cuir : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 29 run data modify storage industrie:g ev set value "Krach : cuir à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 30 run data modify storage industrie:g ev set value "Pénurie de boule de slime : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 30 run data modify storage industrie:g ev set value "Krach : boule de slime à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 31 run data modify storage industrie:g ev set value "Pénurie de crème de magma : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 31 run data modify storage industrie:g ev set value "Krach : crème de magma à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 32 run data modify storage industrie:g ev set value "Pénurie de poudre à canon : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 32 run data modify storage industrie:g ev set value "Krach : poudre à canon à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 33 run data modify storage industrie:g ev set value "Pénurie de membrane de phantom : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 33 run data modify storage industrie:g ev set value "Krach : membrane de phantom à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 34 run data modify storage industrie:g ev set value "Pénurie de éclat de prismarine : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 34 run data modify storage industrie:g ev set value "Krach : éclat de prismarine à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 35 run data modify storage industrie:g ev set value "Pénurie de perle de l'ender : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 35 run data modify storage industrie:g ev set value "Krach : perle de l'ender à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 36 run data modify storage industrie:g ev set value "Pénurie de bâton de blaze : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 36 run data modify storage industrie:g ev set value "Krach : bâton de blaze à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 37 run data modify storage industrie:g ev set value "Pénurie de larme de ghast : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 37 run data modify storage industrie:g ev set value "Krach : larme de ghast à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 38 run data modify storage industrie:g ev set value "Pénurie de bâton de breeze : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 38 run data modify storage industrie:g ev set value "Krach : bâton de breeze à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 39 run data modify storage industrie:g ev set value "Pénurie de crâne de wither squelette : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 39 run data modify storage industrie:g ev set value "Krach : crâne de wither squelette à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 40 run data modify storage industrie:g ev set value "Pénurie de carapace de shulker : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 40 run data modify storage industrie:g ev set value "Krach : carapace de shulker à moitié prix pendant 2 h."
execute if score #ev i.g matches 1 if score #evp i.g matches 41 run data modify storage industrie:g ev set value "Pénurie de totem d'immortalité : prix x1,6 pendant 2 h."
execute if score #ev i.g matches 2 if score #evp i.g matches 41 run data modify storage industrie:g ev set value "Krach : totem d'immortalité à moitié prix pendant 2 h."
execute if score #ev i.g matches 3 run data modify storage industrie:g ev set value "Ruée vers l'or : or x1,5 pendant 2 h."
execute if score #ev i.g matches 4 run data modify storage industrie:g ev set value "Foire impériale : les acheteurs affluent, saturation +50 % pendant 2 h."
execute unless score #ev i.g matches 0 run function industrie:evenement/annonce
