scoreboard players add #evt i.g 1
execute if score #evt i.g matches 7200.. run function industrie:evenement/nouveau
