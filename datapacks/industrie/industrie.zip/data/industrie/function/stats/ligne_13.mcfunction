execute store result storage industrie:m n int 1 run scoreboard players get @s i.n_puits_net
scoreboard players operation #v i.t = @s i.q_puits_net
scoreboard players set #y i.t 30
scoreboard players operation #v i.t *= #y i.t
scoreboard players operation #v i.t /= #100 i.g
execute store result storage industrie:m v0 int 1 run scoreboard players get #v i.t
function industrie:stats/ligne_13_m with storage industrie:m
