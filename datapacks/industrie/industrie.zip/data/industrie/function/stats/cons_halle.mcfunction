$data modify storage industrie:m l append value {text:"\n• Halle pleine : $(po) objets/h produits, $(cap) vendus. Agrandis-la.",color:"white",bold:false,italic:false}
