$data modify storage industrie:m l append value {text:"\nCarrière automatique x$(n) : $(v0) pierre, $(v1) charbon, $(v2) cuivre par heure",color:"white",bold:false,italic:false}
