scoreboard players operation #v16 i.t = @s i.q_forge
scoreboard players set #y i.t 4320
scoreboard players operation #v16 i.t *= #y i.t
execute if score #v16 i.t > #mx i.t run scoreboard players operation #mx i.t = #v16 i.t
