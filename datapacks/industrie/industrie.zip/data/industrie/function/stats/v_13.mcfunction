scoreboard players operation #v13 i.t = @s i.q_puits_net
scoreboard players set #y i.t 1560
scoreboard players operation #v13 i.t *= #y i.t
execute if score #v13 i.t > #mx i.t run scoreboard players operation #mx i.t = #v13 i.t
