$data modify storage industrie:m l append value {text:" Forge des reliques x$(n) : $(v)",color:"white",bold:false,italic:false}
