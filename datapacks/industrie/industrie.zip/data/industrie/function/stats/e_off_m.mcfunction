$data modify storage industrie:m l append value {text:" fournie : $(v) kW",color:"white",bold:false,italic:false}
