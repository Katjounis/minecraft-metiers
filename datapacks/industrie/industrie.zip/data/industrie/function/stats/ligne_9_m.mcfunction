$data modify storage industrie:m l append value {text:"\nCentrale à lave x$(n) : +$(v0) kW",color:"white",bold:false,italic:false}
