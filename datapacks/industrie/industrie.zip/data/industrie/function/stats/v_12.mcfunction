scoreboard players operation #v12 i.t = @s i.q_atelier
scoreboard players set #y i.t 880
scoreboard players operation #v12 i.t *= #y i.t
execute if score #v12 i.t > #mx i.t run scoreboard players operation #mx i.t = #v12 i.t
