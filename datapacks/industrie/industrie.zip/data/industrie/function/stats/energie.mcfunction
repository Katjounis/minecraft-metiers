scoreboard players operation #mx i.t = @s i.off
execute if score @s i.dem > #mx i.t run scoreboard players operation #mx i.t = @s i.dem
execute if score #mx i.t matches ..0 run scoreboard players set #mx i.t 1
scoreboard players operation #x i.t = @s i.off
scoreboard players operation #x i.t /= #10 i.g
execute store result storage industrie:m eo int 1 run scoreboard players get #x i.t
scoreboard players operation #x i.t = @s i.dem
scoreboard players operation #x i.t /= #10 i.g
execute store result storage industrie:m ed int 1 run scoreboard players get #x i.t
function industrie:stats/e_titre with storage industrie:m
scoreboard players operation #ec i.t = @s i.off
execute if score @s i.dem < #ec i.t run scoreboard players operation #ec i.t = @s i.dem
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 1
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 2
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 3
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 4
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 5
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 6
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 7
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 8
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 9
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 10
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 11
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 12
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 13
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 14
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 15
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 16
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 17
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 18
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 19
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 20
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 21
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 22
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 23
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 24
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 25
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 26
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 27
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 28
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 29
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 30
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 31
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 32
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 33
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 34
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 35
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 36
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 37
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 38
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 39
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 40
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #ec i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#ff5a3a",bold:false,italic:false}
execute if score @s i.dem <= @s i.off run data modify storage industrie:m l append value {text:"\n(tout est couvert : la barre rouge serait ce qui manque)",color:"dark_gray",bold:false,italic:false}
