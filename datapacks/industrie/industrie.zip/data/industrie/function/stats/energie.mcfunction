scoreboard players operation #mx i.t = @s i.off
execute if score @s i.dem > #mx i.t run scoreboard players operation #mx i.t = @s i.dem
execute if score #mx i.t matches ..0 run scoreboard players set #mx i.t 1
data modify storage industrie:m l append value {text:"\n",color:"white",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 1
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 2
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 3
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 4
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 5
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 6
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 7
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 8
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 9
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 10
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 11
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 12
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 13
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 14
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 15
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 16
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.off
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#5ff0e6",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #x i.t = @s i.off
scoreboard players operation #x i.t /= #10 i.g
execute store result storage industrie:m v int 1 run scoreboard players get #x i.t
function industrie:stats/e_off_m with storage industrie:m
data modify storage industrie:m l append value {text:"\n",color:"white",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 1
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 2
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 3
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 4
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 5
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 6
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 7
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 8
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 9
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 10
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 11
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 12
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 13
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 14
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 15
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 16
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = @s i.dem
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#ff7a3a",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #x i.t = @s i.dem
scoreboard players operation #x i.t /= #10 i.g
execute store result storage industrie:m v int 1 run scoreboard players get #x i.t
function industrie:stats/e_dem_m with storage industrie:m
