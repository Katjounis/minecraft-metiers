$data modify storage industrie:m l append value {text:" Fonderie x$(n) : $(v)",color:"white",bold:false,italic:false}
