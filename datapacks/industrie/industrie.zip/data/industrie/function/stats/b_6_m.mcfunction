$data modify storage industrie:m l append value {text:"\nFonderie x$(n)  ·  $(v)\n",color:"#ff9a40",bold:false,italic:false}
