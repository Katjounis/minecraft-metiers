$data modify storage industrie:m l append value {text:"\nChaudière à charbon x$(n) : +$(v0) kW",color:"white",bold:false,italic:false}
