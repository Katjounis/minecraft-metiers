execute store result storage industrie:m n int 1 run scoreboard players get @s i.n_joaillerie
execute store result storage industrie:m v int 1 run scoreboard players get #v14 i.t
function industrie:stats/b_14_m with storage industrie:m
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 1
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 2
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 3
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 4
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 5
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 6
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 7
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 8
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 9
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 10
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 11
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 12
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 13
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 14
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 15
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 16
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 17
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 18
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 19
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 20
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 21
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 22
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 23
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 24
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 25
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 26
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 27
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 28
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 29
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 30
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 31
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 32
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 33
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 34
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 35
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 36
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 37
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 38
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 39
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 40
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v14 i.t
scoreboard players set #y i.t 40
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"|",color:"#3a3a3a",bold:false,italic:false}
