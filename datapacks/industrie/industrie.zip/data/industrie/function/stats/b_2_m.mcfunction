$data modify storage industrie:m l append value {text:"\nSerre cultures x$(n)  ·  $(v)\n",color:"#7ad050",bold:false,italic:false}
