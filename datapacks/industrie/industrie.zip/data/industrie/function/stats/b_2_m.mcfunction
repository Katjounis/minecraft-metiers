$data modify storage industrie:m l append value {text:" Serre de cultures x$(n) : $(v)",color:"white",bold:false,italic:false}
