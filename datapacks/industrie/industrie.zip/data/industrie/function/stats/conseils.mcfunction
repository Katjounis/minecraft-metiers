scoreboard players set #po i.t 0
scoreboard players operation #x i.t = @s i.q_carriere
scoreboard players set #y i.t 5100
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation #x i.t /= #100 i.g
scoreboard players operation #po i.t += #x i.t
scoreboard players operation #x i.t = @s i.q_serre
scoreboard players set #y i.t 4500
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation #x i.t /= #100 i.g
scoreboard players operation #po i.t += #x i.t
scoreboard players operation #x i.t = @s i.q_cultures
scoreboard players set #y i.t 9300
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation #x i.t /= #100 i.g
scoreboard players operation #po i.t += #x i.t
scoreboard players operation #x i.t = @s i.q_fourneau
scoreboard players set #y i.t 400
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation #x i.t /= #100 i.g
scoreboard players operation #po i.t += #x i.t
scoreboard players operation #x i.t = @s i.q_puits_or
scoreboard players set #y i.t 1500
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation #x i.t /= #100 i.g
scoreboard players operation #po i.t += #x i.t
scoreboard players operation #x i.t = @s i.q_fonderie
scoreboard players set #y i.t 600
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation #x i.t /= #100 i.g
scoreboard players operation #po i.t += #x i.t
scoreboard players operation #x i.t = @s i.q_distill
scoreboard players set #y i.t 400
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation #x i.t /= #100 i.g
scoreboard players operation #po i.t += #x i.t
scoreboard players operation #x i.t = @s i.q_puits_dia
scoreboard players set #y i.t 300
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation #x i.t /= #100 i.g
scoreboard players operation #po i.t += #x i.t
scoreboard players operation #x i.t = @s i.q_puits_eme
scoreboard players set #y i.t 2000
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation #x i.t /= #100 i.g
scoreboard players operation #po i.t += #x i.t
scoreboard players operation #x i.t = @s i.q_atelier
scoreboard players set #y i.t 200
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation #x i.t /= #100 i.g
scoreboard players operation #po i.t += #x i.t
scoreboard players operation #x i.t = @s i.q_puits_net
scoreboard players set #y i.t 30
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation #x i.t /= #100 i.g
scoreboard players operation #po i.t += #x i.t
scoreboard players operation #x i.t = @s i.q_joaillerie
scoreboard players set #y i.t 200
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation #x i.t /= #100 i.g
scoreboard players operation #po i.t += #x i.t
scoreboard players operation #x i.t = @s i.q_forge
scoreboard players set #y i.t 12
scoreboard players operation #x i.t *= #y i.t
scoreboard players operation #x i.t /= #100 i.g
scoreboard players operation #po i.t += #x i.t
execute if score @s i.halle matches 0 run scoreboard players set #cap i.t 10000
execute if score @s i.halle matches 1 run scoreboard players set #cap i.t 25000
execute if score @s i.halle matches 2 run scoreboard players set #cap i.t 60000
execute if score @s i.halle matches 3 run scoreboard players set #cap i.t 200000
execute store result storage industrie:m po int 1 run scoreboard players get #po i.t
execute store result storage industrie:m cap int 1 run scoreboard players get #cap i.t
data modify storage industrie:m l append value {text:"\n\nCE QUI FREINE TES REVENUS",color:"red",bold:false,italic:false}
scoreboard players set #ok i.t 0
execute if score @s i.fe matches ..999 run scoreboard players set #ok i.t 1
execute if score @s i.fe matches ..999 run data modify storage industrie:m l append value {text:"\nÉnergie insuffisante : toutes tes machines tournent moins vite. Achète une Chaudière à charbon (+150 kW).",color:"white",bold:false,italic:false}
execute if score #po i.t > #cap i.t run scoreboard players set #ok i.t 1
execute if score #po i.t > #cap i.t run function industrie:stats/cons_halle with storage industrie:m
execute if score #ok i.t matches 0 run data modify storage industrie:m l append value {text:"\nRien : tout tourne à plein.",color:"green",bold:false,italic:false}
