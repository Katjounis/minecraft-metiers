$data modify storage industrie:m l append value {text:"\nDistillerie x$(n) : $(v0) élixir par heure",color:"white",bold:false,italic:false}
