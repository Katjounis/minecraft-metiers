$data modify storage industrie:m l append value {text:"\nSerre hydroponique x$(n) : $(v0) canne à sucre, $(v1) verrues du nether, $(v2) citrouille par heure",color:"white",bold:false,italic:false}
