$data modify storage industrie:m l append value {text:" Puits émeraude x$(n) : $(v)",color:"white",bold:false,italic:false}
