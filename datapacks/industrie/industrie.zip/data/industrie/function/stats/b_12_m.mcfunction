$data modify storage industrie:m l append value {text:"\nAtelier méca x$(n)  ·  $(v)\n",color:"#b878ff",bold:false,italic:false}
