$data modify storage industrie:m l append value {text:" Atelier mécanique x$(n) : $(v)",color:"white",bold:false,italic:false}
