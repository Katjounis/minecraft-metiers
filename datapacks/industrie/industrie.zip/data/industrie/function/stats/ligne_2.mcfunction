execute store result storage industrie:m n int 1 run scoreboard players get @s i.n_cultures
scoreboard players operation #v i.t = @s i.q_cultures
scoreboard players set #y i.t 1500
scoreboard players operation #v i.t *= #y i.t
scoreboard players operation #v i.t /= #100 i.g
execute store result storage industrie:m v0 int 1 run scoreboard players get #v i.t
scoreboard players operation #v i.t = @s i.q_cultures
scoreboard players set #y i.t 2000
scoreboard players operation #v i.t *= #y i.t
scoreboard players operation #v i.t /= #100 i.g
execute store result storage industrie:m v1 int 1 run scoreboard players get #v i.t
scoreboard players operation #v i.t = @s i.q_cultures
scoreboard players set #y i.t 2000
scoreboard players operation #v i.t *= #y i.t
scoreboard players operation #v i.t /= #100 i.g
execute store result storage industrie:m v2 int 1 run scoreboard players get #v i.t
scoreboard players operation #v i.t = @s i.q_cultures
scoreboard players set #y i.t 800
scoreboard players operation #v i.t *= #y i.t
scoreboard players operation #v i.t /= #100 i.g
execute store result storage industrie:m v3 int 1 run scoreboard players get #v i.t
scoreboard players operation #v i.t = @s i.q_cultures
scoreboard players set #y i.t 3000
scoreboard players operation #v i.t *= #y i.t
scoreboard players operation #v i.t /= #100 i.g
execute store result storage industrie:m v4 int 1 run scoreboard players get #v i.t
function industrie:stats/ligne_2_m with storage industrie:m
