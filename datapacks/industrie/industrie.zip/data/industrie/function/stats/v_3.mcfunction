scoreboard players operation #v3 i.t = @s i.q_fourneau
scoreboard players set #y i.t 64
scoreboard players operation #v3 i.t *= #y i.t
execute if score #v3 i.t > #mx i.t run scoreboard players operation #mx i.t = #v3 i.t
