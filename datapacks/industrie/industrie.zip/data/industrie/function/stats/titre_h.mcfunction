$data modify storage industrie:m l append value {text:"\nmeilleure heure : $(mx) Écus",color:"gray",bold:false,italic:false}
