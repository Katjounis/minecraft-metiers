$data modify storage industrie:m l append value {text:"   (max $(mx) Écus)\n",color:"gray",bold:false,italic:false}
