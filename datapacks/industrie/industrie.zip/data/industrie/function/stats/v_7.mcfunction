scoreboard players operation #v7 i.t = @s i.q_distill
scoreboard players set #y i.t 320
scoreboard players operation #v7 i.t *= #y i.t
execute if score #v7 i.t > #mx i.t run scoreboard players operation #mx i.t = #v7 i.t
