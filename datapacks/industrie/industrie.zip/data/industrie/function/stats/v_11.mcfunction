scoreboard players operation #v11 i.t = @s i.q_puits_eme
scoreboard players set #y i.t 600
scoreboard players operation #v11 i.t *= #y i.t
execute if score #v11 i.t > #mx i.t run scoreboard players operation #mx i.t = #v11 i.t
