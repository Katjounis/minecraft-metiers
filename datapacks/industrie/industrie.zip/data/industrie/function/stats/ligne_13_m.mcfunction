$data modify storage industrie:m l append value {text:"\nPuits netherite x$(n) : $(v0) netherite par heure",color:"white",bold:false,italic:false}
