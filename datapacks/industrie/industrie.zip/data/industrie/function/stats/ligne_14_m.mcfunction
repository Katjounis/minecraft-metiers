$data modify storage industrie:m l append value {text:"\nJoaillerie x$(n) : $(v0) bijou par heure",color:"white",bold:false,italic:false}
