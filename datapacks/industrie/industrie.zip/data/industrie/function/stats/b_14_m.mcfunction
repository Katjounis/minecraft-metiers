$data modify storage industrie:m l append value {text:" Joaillerie x$(n) : $(v)",color:"white",bold:false,italic:false}
