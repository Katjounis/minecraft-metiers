$data modify storage industrie:m l append value {text:"\nPuits diamant x$(n) : $(v0) diamant par heure",color:"white",bold:false,italic:false}
