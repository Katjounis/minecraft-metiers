scoreboard players operation #v6 i.t = @s i.q_fonderie
scoreboard players set #y i.t 360
scoreboard players operation #v6 i.t *= #y i.t
execute if score #v6 i.t > #mx i.t run scoreboard players operation #mx i.t = #v6 i.t
