$data modify storage industrie:m l append value {text:"\nPuits or x$(n) : $(v0) or par heure",color:"white",bold:false,italic:false}
