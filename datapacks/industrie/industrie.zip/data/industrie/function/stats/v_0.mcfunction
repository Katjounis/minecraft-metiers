scoreboard players operation #v0 i.t = @s i.q_carriere
scoreboard players set #y i.t 36
scoreboard players operation #v0 i.t *= #y i.t
execute if score #v0 i.t > #mx i.t run scoreboard players operation #mx i.t = #v0 i.t
