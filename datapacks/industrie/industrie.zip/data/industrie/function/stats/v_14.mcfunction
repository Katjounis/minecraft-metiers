scoreboard players operation #v14 i.t = @s i.q_joaillerie
scoreboard players set #y i.t 1800
scoreboard players operation #v14 i.t *= #y i.t
execute if score #v14 i.t > #mx i.t run scoreboard players operation #mx i.t = #v14 i.t
