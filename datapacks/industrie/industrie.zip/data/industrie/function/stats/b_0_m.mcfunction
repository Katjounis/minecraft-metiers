$data modify storage industrie:m l append value {text:" Carrière automatique x$(n) : $(v)",color:"white",bold:false,italic:false}
