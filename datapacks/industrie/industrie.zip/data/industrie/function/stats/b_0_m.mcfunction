$data modify storage industrie:m l append value {text:"\nCarrière x$(n)  ·  $(v)\n",color:"#c8c8d0",bold:false,italic:false}
