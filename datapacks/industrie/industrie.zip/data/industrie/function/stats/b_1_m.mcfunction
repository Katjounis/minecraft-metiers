$data modify storage industrie:m l append value {text:" Serre hydroponique x$(n) : $(v)",color:"white",bold:false,italic:false}
