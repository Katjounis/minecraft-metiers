execute store result storage industrie:m n int 1 run scoreboard players get @s i.n_spawner
function industrie:stats/ligne_8_m with storage industrie:m
