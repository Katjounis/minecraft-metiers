scoreboard players operation #v5 i.t = @s i.q_puits_or
scoreboard players set #y i.t 360
scoreboard players operation #v5 i.t *= #y i.t
execute if score #v5 i.t > #mx i.t run scoreboard players operation #mx i.t = #v5 i.t
