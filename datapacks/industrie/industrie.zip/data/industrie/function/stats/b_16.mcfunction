data modify storage industrie:m l append value {text:"\n",color:"white",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 1
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 2
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 3
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 4
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 5
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 6
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 7
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 8
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 9
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 10
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 11
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 12
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 13
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 14
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 15
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
scoreboard players operation #u i.t = #mx i.t
scoreboard players set #y i.t 16
scoreboard players operation #u i.t *= #y i.t
scoreboard players operation #t i.t = #v16 i.t
scoreboard players set #y i.t 16
scoreboard players operation #t i.t *= #y i.t
execute if score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#b878ff",bold:false,italic:false}
execute unless score #t i.t >= #u i.t run data modify storage industrie:m l append value {text:"█",color:"#2b2b2b",bold:false,italic:false}
execute store result storage industrie:m n int 1 run scoreboard players get @s i.n_forge
execute store result storage industrie:m v int 1 run scoreboard players get #v16 i.t
function industrie:stats/b_16_m with storage industrie:m
