$data modify storage industrie:m l append value {text:"\nPuits diamant x$(n)  ·  $(v)\n",color:"#5ff0e6",bold:false,italic:false}
