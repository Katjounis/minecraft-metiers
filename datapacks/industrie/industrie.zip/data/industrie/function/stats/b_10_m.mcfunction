$data modify storage industrie:m l append value {text:" Puits diamant x$(n) : $(v)",color:"white",bold:false,italic:false}
