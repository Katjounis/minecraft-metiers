execute store result storage industrie:m n int 1 run scoreboard players get @s i.n_forge
scoreboard players operation #v i.t = @s i.q_forge
scoreboard players set #y i.t 12
scoreboard players operation #v i.t *= #y i.t
scoreboard players operation #v i.t /= #100 i.g
execute store result storage industrie:m v0 int 1 run scoreboard players get #v i.t
function industrie:stats/ligne_16_m with storage industrie:m
