$data modify storage industrie:m l append value {text:"\nPuits émeraude x$(n) : $(v0) émeraude par heure",color:"white",bold:false,italic:false}
