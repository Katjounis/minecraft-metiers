execute store result storage industrie:m n int 1 run scoreboard players get @s i.n_carriere
scoreboard players operation #v i.t = @s i.q_carriere
scoreboard players set #y i.t 4000
scoreboard players operation #v i.t *= #y i.t
scoreboard players operation #v i.t /= #100 i.g
execute store result storage industrie:m v0 int 1 run scoreboard players get #v i.t
scoreboard players operation #v i.t = @s i.q_carriere
scoreboard players set #y i.t 800
scoreboard players operation #v i.t *= #y i.t
scoreboard players operation #v i.t /= #100 i.g
execute store result storage industrie:m v1 int 1 run scoreboard players get #v i.t
scoreboard players operation #v i.t = @s i.q_carriere
scoreboard players set #y i.t 300
scoreboard players operation #v i.t *= #y i.t
scoreboard players operation #v i.t /= #100 i.g
execute store result storage industrie:m v2 int 1 run scoreboard players get #v i.t
function industrie:stats/ligne_0_m with storage industrie:m
