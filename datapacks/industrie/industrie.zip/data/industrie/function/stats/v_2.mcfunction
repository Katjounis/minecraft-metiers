scoreboard players operation #v2 i.t = @s i.q_cultures
scoreboard players set #y i.t 86
scoreboard players operation #v2 i.t *= #y i.t
execute if score #v2 i.t > #mx i.t run scoreboard players operation #mx i.t = #v2 i.t
