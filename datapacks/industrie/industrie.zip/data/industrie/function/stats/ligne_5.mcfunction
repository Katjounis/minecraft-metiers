execute store result storage industrie:m n int 1 run scoreboard players get @s i.n_puits_or
scoreboard players operation #v i.t = @s i.q_puits_or
scoreboard players set #y i.t 1500
scoreboard players operation #v i.t *= #y i.t
scoreboard players operation #v i.t /= #100 i.g
execute store result storage industrie:m v0 int 1 run scoreboard players get #v i.t
function industrie:stats/ligne_5_m with storage industrie:m
