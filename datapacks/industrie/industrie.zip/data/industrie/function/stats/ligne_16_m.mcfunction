$data modify storage industrie:m l append value {text:"\nForge des reliques x$(n) : $(v0) relique par heure",color:"white",bold:false,italic:false}
