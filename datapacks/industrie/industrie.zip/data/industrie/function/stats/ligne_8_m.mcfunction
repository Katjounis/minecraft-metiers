$data modify storage industrie:m l append value {text:"\nUsine à spawner x$(n) : butin de tes spawners",color:"white",bold:false,italic:false}
