$data modify storage industrie:m l append value {text:"\nHaut-fourneau x$(n) : $(v0) fer par heure",color:"white",bold:false,italic:false}
