$data modify storage industrie:m l append value {text:"\n\nÉNERGIE  $(eo) kW fournis / $(ed) kW demandés\n",color:"aqua",bold:false,italic:false}
