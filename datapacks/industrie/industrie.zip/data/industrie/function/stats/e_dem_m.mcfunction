$data modify storage industrie:m l append value {text:" demandée : $(v) kW",color:"white",bold:false,italic:false}
