scoreboard players operation #v1 i.t = @s i.q_serre
scoreboard players set #y i.t 46
scoreboard players operation #v1 i.t *= #y i.t
execute if score #v1 i.t > #mx i.t run scoreboard players operation #mx i.t = #v1 i.t
