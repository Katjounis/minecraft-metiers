scoreboard players operation #v10 i.t = @s i.q_puits_dia
scoreboard players set #y i.t 720
scoreboard players operation #v10 i.t *= #y i.t
execute if score #v10 i.t > #mx i.t run scoreboard players operation #mx i.t = #v10 i.t
