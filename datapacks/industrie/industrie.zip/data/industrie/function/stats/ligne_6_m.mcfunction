$data modify storage industrie:m l append value {text:"\nFonderie x$(n) : $(v0) acier par heure",color:"white",bold:false,italic:false}
