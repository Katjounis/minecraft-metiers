$data modify storage industrie:m l append value {text:"\nDistillerie x$(n)  ·  $(v)\n",color:"#b878ff",bold:false,italic:false}
