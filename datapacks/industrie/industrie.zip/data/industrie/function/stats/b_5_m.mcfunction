$data modify storage industrie:m l append value {text:" Puits or x$(n) : $(v)",color:"white",bold:false,italic:false}
