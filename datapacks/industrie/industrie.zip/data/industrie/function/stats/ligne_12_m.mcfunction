$data modify storage industrie:m l append value {text:"\nAtelier mécanique x$(n) : $(v0) mécanisme par heure",color:"white",bold:false,italic:false}
