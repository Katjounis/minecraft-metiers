$data modify storage industrie:m l append value {text:"\nCœur stellaire x$(n) : +$(v0) kW",color:"white",bold:false,italic:false}
