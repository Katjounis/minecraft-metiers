$data modify storage industrie:m l append value {text:" Haut-fourneau x$(n) : $(v)",color:"white",bold:false,italic:false}
