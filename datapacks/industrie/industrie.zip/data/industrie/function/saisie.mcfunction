scoreboard players operation #v i.t = @s industrie
scoreboard players set @s industrie 0
scoreboard players operation #v i.t *= #-1 i.g
execute if score @s i.pend matches 1 run function industrie:parts/offre
scoreboard players set @s i.pend 0
