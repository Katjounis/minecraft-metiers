scoreboard players set #sec i.g 0
execute store result score #now i.g run time query gametime
execute as @a at @s run function industrie:joueur/seconde
execute as @a[scores={i.ile=0..}] unless score @s i.tuto matches 7.. at @s run function industrie:tuto/verif
execute as @a[scores={i.cin=1..39}] at @s run function industrie:cine/pas
execute as @a at @s if dimension industrie:archipel run function industrie:ile/garde
execute as @a[tag=ind.adv] at @s unless dimension industrie:archipel run function industrie:ile/hors
scoreboard players add #bar i.g 1
execute if score #bar i.g matches 5.. as @a at @s if dimension industrie:archipel run function industrie:ile/barrieres
execute if score #bar i.g matches 5.. run scoreboard players set #bar i.g 0
execute as @a at @s if dimension industrie:archipel as @e[type=minecraft:item_display,tag=ind.pq,distance=..80] run function industrie:tube/anim
function industrie:evenement/seconde
