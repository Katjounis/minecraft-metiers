scoreboard players set #sec i.g 0
execute store result score #now i.g run time query gametime
execute as @a at @s run function industrie:joueur/seconde
execute as @a at @s if dimension industrie:archipel run function industrie:ile/garde
execute as @a[tag=ind.adv] at @s unless dimension industrie:archipel run function industrie:ile/hors
execute as @a at @s if dimension industrie:archipel as @e[type=minecraft:item_display,tag=ind.pq,distance=..80] run function industrie:tube/anim
function industrie:evenement/seconde
