function industrie:ile/position
execute if score #ok i.t matches 0 run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Va sur une de tes parcelles, près d'un emplacement libre (dalle noire à coins dorés).",color:"red",bold:false,italic:false}]
execute unless score @s i.rang matches 2.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Centrale à lave : il faut le rang Manufacture.",color:"red",bold:false,italic:false}]
scoreboard players set #max i.t 0
execute if score @s i.rang matches 1 run scoreboard players set #max i.t 5
execute if score @s i.rang matches 2 run scoreboard players set #max i.t 6
execute if score @s i.rang matches 3 run scoreboard players set #max i.t 7
execute if score @s i.rang matches 4 run scoreboard players set #max i.t 8
execute if score @s i.rang matches 5 run scoreboard players set #max i.t 9
execute if score @s i.n_lave >= #max i.t run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Tu as déjà le maximum de Centrale à lave pour ton rang.",color:"red",bold:false,italic:false}]
scoreboard players set #prix i.t 350000
execute if score @s m.k_lvl matches 50.. run scoreboard players set #prix i.t 315000
execute unless score @s c.ecus >= #prix i.t run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Il te faut 350 000 Écus.",color:"red",bold:false,italic:false}]
scoreboard players operation #me i.t = @s m.id
scoreboard players operation #own i.t = @s m.id
execute as @e[type=minecraft:marker,tag=ind.slot,tag=!ind.occ,distance=..48] if score @s i.own = #me i.t run tag @s add ind.cand
execute unless entity @e[type=minecraft:marker,tag=ind.cand] run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Aucun emplacement libre à moins de 48 blocs : achète une parcelle (Cadastre) ou rapproche-toi.",color:"red",bold:false,italic:false}]
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus -= #prix i.t
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.a_ind -= #prix i.t
scoreboard players set #sf i.t 100
scoreboard players set #mob i.t 0
scoreboard players set #spv i.t 0
scoreboard players set #spq i.t 0
scoreboard players add @s i.q_lave 100
scoreboard players add @s i.n_lave 1
scoreboard players add @s i.k_lave 10
scoreboard players set #pm i.t 9
scoreboard players set #pl i.t 1
scoreboard players operation #tt i.t = @s i.tube
execute as @e[type=minecraft:marker,tag=ind.cand,limit=1,sort=nearest] at @s run function industrie:machine/poser_ici
tag @e[type=minecraft:marker,tag=ind.cand] remove ind.cand
playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.8 1.2
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.4
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Centrale à lave posée et reliée au Nexus. Clic droit dessus pour sa fiche.",color:"green",bold:false,italic:false}]
