scoreboard players add @s i.ml 1
execute if score @s i.ml matches 2 run data merge entity @s {transformation:{scale:[2.438f,2.438f,2.438f]}}
execute if score @s i.ml matches 3 run data merge entity @s {transformation:{scale:[2.576f,2.576f,2.576f]}}
execute if score @s i.ml matches 4 run data merge entity @s {transformation:{scale:[2.714f,2.714f,2.714f]}}
execute if score @s i.ml matches 5 run data merge entity @s {transformation:{scale:[2.852f,2.852f,2.852f]}}
particle minecraft:totem_of_undying ~ ~2 ~ 1.5 2 1.5 0.3 80 force
