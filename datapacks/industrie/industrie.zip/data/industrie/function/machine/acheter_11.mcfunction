function industrie:ile/position
execute if score #ok i.t matches 0 run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Va sur une de tes parcelles, près d'un emplacement libre (dalle noire à coins dorés).",color:"red",bold:false,italic:false}]
execute unless score @s i.rang matches 3.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Puits de cristal : émeraude : il faut le rang Industrie.",color:"red",bold:false,italic:false}]
scoreboard players set #max i.t 0
execute if score @s i.rang matches 1 run scoreboard players set #max i.t 0
execute if score @s i.rang matches 2 run scoreboard players set #max i.t 1
execute if score @s i.rang matches 3 run scoreboard players set #max i.t 2
execute if score @s i.rang matches 4 run scoreboard players set #max i.t 3
execute if score @s i.rang matches 5 run scoreboard players set #max i.t 4
execute if score @s i.n_puits_eme >= #max i.t run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Tu as déjà le maximum de Puits de cristal : émeraude pour ton rang.",color:"red",bold:false,italic:false}]
scoreboard players set #prix i.t 2500000
execute if score @s m.k_lvl matches 50.. run scoreboard players set #prix i.t 2250000
execute unless score @s c.ecus >= #prix i.t run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Il te faut 2 500 000 Écus.",color:"red",bold:false,italic:false}]
execute unless score @s m.ecl matches 10.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Il te faut 10 éclats de boss.",color:"red",bold:false,italic:false}]
scoreboard players operation #me i.t = @s m.id
scoreboard players operation #own i.t = @s m.id
execute store result score #now i.t run time query gametime
scoreboard players operation #now i.t -= @s i.pst
scoreboard players operation #ps i.t = @s i.psl
execute unless score #now i.t matches 0..1200 run scoreboard players set #ps i.t -1
execute if score #ps i.t matches 0.. as @e[type=minecraft:marker,tag=ind.slot,tag=!ind.occ,distance=..48] if score @s i.own = #me i.t if score @s i.sid = #ps i.t run tag @s add ind.cand
execute unless entity @e[type=minecraft:marker,tag=ind.cand] as @e[type=minecraft:marker,tag=ind.slot,tag=!ind.occ,distance=..48] if score @s i.own = #me i.t run tag @s add ind.cand
scoreboard players set @s i.psl -1
execute unless entity @e[type=minecraft:marker,tag=ind.cand] run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Aucun emplacement libre à moins de 48 blocs : achète une parcelle (Cadastre) ou rapproche-toi.",color:"red",bold:false,italic:false}]
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus -= #prix i.t
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.a_ind -= #prix i.t
scoreboard players remove @s m.ecl 10
scoreboard players set #sf i.t 100
scoreboard players set #mob i.t 0
scoreboard players set #spv i.t 0
scoreboard players set #spq i.t 0
scoreboard players add @s i.q_puits_eme 100
scoreboard players add @s i.n_puits_eme 1
scoreboard players add @s i.k_puits_eme 10
scoreboard players set #pm i.t 11
scoreboard players set #pl i.t 1
scoreboard players operation #tt i.t = @s i.tube
execute as @e[type=minecraft:marker,tag=ind.cand,limit=1,sort=nearest] at @s run function industrie:machine/poser_ici
tag @e[type=minecraft:marker,tag=ind.cand] remove ind.cand
playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.8 1.2
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.4
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Puits de cristal : émeraude posée et reliée au Nexus. Clic droit dessus pour sa fiche.",color:"green",bold:false,italic:false}]
