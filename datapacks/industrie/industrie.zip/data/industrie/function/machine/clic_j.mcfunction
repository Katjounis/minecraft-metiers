execute unless score @s m.id = #co i.t run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Cette machine appartient à une autre île.",color:"gray",bold:false,italic:false}]
scoreboard players operation @s i.sel = #cs i.t
function industrie:machine/fiche
