scoreboard players operation #sf i.t = @s i.sf
scoreboard players operation #spv i.t = @s i.spv
scoreboard players operation #spq i.t = @s i.spq
