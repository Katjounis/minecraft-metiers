scoreboard players operation #psid i.t = @s i.sid
tag @s add ind.occ
function industrie:machine/visuel_ici
