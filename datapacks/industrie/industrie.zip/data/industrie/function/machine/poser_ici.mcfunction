scoreboard players operation #psid i.t = @s i.sid
tag @s add ind.occ
kill @e[type=minecraft:interaction,tag=ind.si,distance=..1]
kill @e[type=minecraft:text_display,tag=ind.sl,distance=..3]
function industrie:machine/visuel_ici
