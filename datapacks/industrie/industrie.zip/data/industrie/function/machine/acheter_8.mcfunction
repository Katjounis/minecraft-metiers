function industrie:ile/position
execute if score #ok i.t matches 0 run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Va sur une de tes parcelles, près d'un emplacement libre (dalle noire à coins dorés).",color:"red",bold:false,italic:false}]
execute unless score @s i.rang matches 2.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Usine à spawner : il faut le rang Manufacture.",color:"red",bold:false,italic:false}]
scoreboard players set #max i.t 0
execute if score @s i.rang matches 1 run scoreboard players set #max i.t 1
execute if score @s i.rang matches 2 run scoreboard players set #max i.t 2
execute if score @s i.rang matches 3 run scoreboard players set #max i.t 3
execute if score @s i.rang matches 4 run scoreboard players set #max i.t 4
execute if score @s i.rang matches 5 run scoreboard players set #max i.t 5
execute if score @s i.n_spawner >= #max i.t run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Tu as déjà le maximum de Usine à spawner pour ton rang.",color:"red",bold:false,italic:false}]
scoreboard players set #prix i.t 300000
execute if score @s m.k_lvl matches 50.. run scoreboard players set #prix i.t 270000
execute unless score @s c.ecus >= #prix i.t run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Il te faut 300 000 Écus.",color:"red",bold:false,italic:false}]
execute unless score @s m.ecl matches 5.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Il te faut 5 éclats de boss.",color:"red",bold:false,italic:false}]
execute unless items entity @s weapon.mainhand minecraft:spawner[minecraft:custom_data~{commerce_sp:{}}] run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Tiens en main un spawner du Commerce : l'usine le prend et produit le butin de sa créature.",color:"red",bold:false,italic:false}]
execute store result score #mob i.t run data get entity @s SelectedItem.components."minecraft:custom_data".commerce_sp.m
execute store result score #spv i.t run data get entity @s SelectedItem.components."minecraft:custom_data".commerce_sp.v
execute store result score #spq i.t run data get entity @s SelectedItem.components."minecraft:custom_data".commerce_sp.q
scoreboard players remove #mob i.t 1
execute unless score #mob i.t matches 0..34 run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Spawner inconnu.",color:"red",bold:false,italic:false}]
scoreboard players operation #me i.t = @s m.id
scoreboard players operation #own i.t = @s m.id
execute store result score #now i.t run time query gametime
scoreboard players operation #now i.t -= @s i.pst
scoreboard players operation #ps i.t = @s i.psl
execute unless score #now i.t matches 0..1200 run scoreboard players set #ps i.t -1
execute if score #ps i.t matches 0.. as @e[type=minecraft:marker,tag=ind.slot,tag=!ind.occ,distance=..48] if score @s i.own = #me i.t if score @s i.sid = #ps i.t run tag @s add ind.cand
execute unless entity @e[type=minecraft:marker,tag=ind.cand] as @e[type=minecraft:marker,tag=ind.slot,tag=!ind.occ,distance=..48] if score @s i.own = #me i.t run tag @s add ind.cand
scoreboard players set @s i.psl -1
execute unless entity @e[type=minecraft:marker,tag=ind.cand] run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Aucun emplacement libre à moins de 48 blocs : achète une parcelle (Cadastre) ou rapproche-toi.",color:"red",bold:false,italic:false}]
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus -= #prix i.t
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.a_ind -= #prix i.t
scoreboard players remove @s m.ecl 5
item replace entity @s weapon.mainhand with minecraft:air
scoreboard players operation #sf i.t = #spv i.t
scoreboard players operation #sf i.t += #spq i.t
scoreboard players set #y i.t 25
scoreboard players operation #sf i.t *= #y i.t
scoreboard players add #sf i.t 100
execute if score #mob i.t matches 0 run scoreboard players operation @s i.qs0 += #sf i.t
execute if score #mob i.t matches 1 run scoreboard players operation @s i.qs1 += #sf i.t
execute if score #mob i.t matches 2 run scoreboard players operation @s i.qs2 += #sf i.t
execute if score #mob i.t matches 3 run scoreboard players operation @s i.qs3 += #sf i.t
execute if score #mob i.t matches 4 run scoreboard players operation @s i.qs4 += #sf i.t
execute if score #mob i.t matches 5 run scoreboard players operation @s i.qs5 += #sf i.t
execute if score #mob i.t matches 6 run scoreboard players operation @s i.qs6 += #sf i.t
execute if score #mob i.t matches 7 run scoreboard players operation @s i.qs7 += #sf i.t
execute if score #mob i.t matches 8 run scoreboard players operation @s i.qs8 += #sf i.t
execute if score #mob i.t matches 9 run scoreboard players operation @s i.qs9 += #sf i.t
execute if score #mob i.t matches 10 run scoreboard players operation @s i.qs10 += #sf i.t
execute if score #mob i.t matches 11 run scoreboard players operation @s i.qs11 += #sf i.t
execute if score #mob i.t matches 12 run scoreboard players operation @s i.qs12 += #sf i.t
execute if score #mob i.t matches 13 run scoreboard players operation @s i.qs13 += #sf i.t
execute if score #mob i.t matches 14 run scoreboard players operation @s i.qs14 += #sf i.t
execute if score #mob i.t matches 15 run scoreboard players operation @s i.qs15 += #sf i.t
execute if score #mob i.t matches 16 run scoreboard players operation @s i.qs16 += #sf i.t
execute if score #mob i.t matches 17 run scoreboard players operation @s i.qs17 += #sf i.t
execute if score #mob i.t matches 18 run scoreboard players operation @s i.qs18 += #sf i.t
execute if score #mob i.t matches 19 run scoreboard players operation @s i.qs19 += #sf i.t
execute if score #mob i.t matches 20 run scoreboard players operation @s i.qs20 += #sf i.t
execute if score #mob i.t matches 21 run scoreboard players operation @s i.qs21 += #sf i.t
execute if score #mob i.t matches 22 run scoreboard players operation @s i.qs22 += #sf i.t
execute if score #mob i.t matches 23 run scoreboard players operation @s i.qs23 += #sf i.t
execute if score #mob i.t matches 24 run scoreboard players operation @s i.qs24 += #sf i.t
execute if score #mob i.t matches 25 run scoreboard players operation @s i.qs25 += #sf i.t
execute if score #mob i.t matches 26 run scoreboard players operation @s i.qs26 += #sf i.t
execute if score #mob i.t matches 27 run scoreboard players operation @s i.qs27 += #sf i.t
execute if score #mob i.t matches 28 run scoreboard players operation @s i.qs28 += #sf i.t
execute if score #mob i.t matches 29 run scoreboard players operation @s i.qs29 += #sf i.t
execute if score #mob i.t matches 30 run scoreboard players operation @s i.qs30 += #sf i.t
execute if score #mob i.t matches 31 run scoreboard players operation @s i.qs31 += #sf i.t
execute if score #mob i.t matches 32 run scoreboard players operation @s i.qs32 += #sf i.t
execute if score #mob i.t matches 33 run scoreboard players operation @s i.qs33 += #sf i.t
execute if score #mob i.t matches 34 run scoreboard players operation @s i.qs34 += #sf i.t
scoreboard players add @s i.q_spawner 100
scoreboard players add @s i.n_spawner 1
scoreboard players add @s i.k_spawner 10
scoreboard players set #pm i.t 8
scoreboard players set #pl i.t 1
scoreboard players operation #tt i.t = @s i.tube
execute as @e[type=minecraft:marker,tag=ind.cand,limit=1,sort=nearest] at @s run function industrie:machine/poser_ici
tag @e[type=minecraft:marker,tag=ind.cand] remove ind.cand
playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.8 1.2
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.4
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Usine à spawner posée et reliée au Nexus. Clic droit dessus pour sa fiche.",color:"green",bold:false,italic:false}]
