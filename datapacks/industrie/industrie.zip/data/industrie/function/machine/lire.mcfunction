scoreboard players operation #cm i.t = @s i.mt
scoreboard players operation #cl i.t = @s i.ml
scoreboard players operation #cmob i.t = @s i.mob
