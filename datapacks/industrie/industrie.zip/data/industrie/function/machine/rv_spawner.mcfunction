execute as @e[type=minecraft:item_display,tag=ind.m,distance=..96] if score @s i.own = #me i.t if score @s i.sid = #sel i.t run function industrie:machine/rv_sp_lire
scoreboard players operation #dq i.t *= #sf i.t
scoreboard players operation #dq i.t /= #100 i.g
execute if score #cmob i.t matches 0 run scoreboard players operation @s i.qs0 -= #dq i.t
execute if score #cmob i.t matches 1 run scoreboard players operation @s i.qs1 -= #dq i.t
execute if score #cmob i.t matches 2 run scoreboard players operation @s i.qs2 -= #dq i.t
execute if score #cmob i.t matches 3 run scoreboard players operation @s i.qs3 -= #dq i.t
execute if score #cmob i.t matches 4 run scoreboard players operation @s i.qs4 -= #dq i.t
execute if score #cmob i.t matches 5 run scoreboard players operation @s i.qs5 -= #dq i.t
execute if score #cmob i.t matches 6 run scoreboard players operation @s i.qs6 -= #dq i.t
execute if score #cmob i.t matches 7 run scoreboard players operation @s i.qs7 -= #dq i.t
execute if score #cmob i.t matches 8 run scoreboard players operation @s i.qs8 -= #dq i.t
execute if score #cmob i.t matches 9 run scoreboard players operation @s i.qs9 -= #dq i.t
execute if score #cmob i.t matches 10 run scoreboard players operation @s i.qs10 -= #dq i.t
execute if score #cmob i.t matches 11 run scoreboard players operation @s i.qs11 -= #dq i.t
execute if score #cmob i.t matches 12 run scoreboard players operation @s i.qs12 -= #dq i.t
execute if score #cmob i.t matches 13 run scoreboard players operation @s i.qs13 -= #dq i.t
execute if score #cmob i.t matches 14 run scoreboard players operation @s i.qs14 -= #dq i.t
execute if score #cmob i.t matches 15 run scoreboard players operation @s i.qs15 -= #dq i.t
execute if score #cmob i.t matches 16 run scoreboard players operation @s i.qs16 -= #dq i.t
execute if score #cmob i.t matches 17 run scoreboard players operation @s i.qs17 -= #dq i.t
execute if score #cmob i.t matches 18 run scoreboard players operation @s i.qs18 -= #dq i.t
execute if score #cmob i.t matches 19 run scoreboard players operation @s i.qs19 -= #dq i.t
execute if score #cmob i.t matches 20 run scoreboard players operation @s i.qs20 -= #dq i.t
execute if score #cmob i.t matches 21 run scoreboard players operation @s i.qs21 -= #dq i.t
execute if score #cmob i.t matches 22 run scoreboard players operation @s i.qs22 -= #dq i.t
execute if score #cmob i.t matches 23 run scoreboard players operation @s i.qs23 -= #dq i.t
execute if score #cmob i.t matches 24 run scoreboard players operation @s i.qs24 -= #dq i.t
execute if score #cmob i.t matches 25 run scoreboard players operation @s i.qs25 -= #dq i.t
execute if score #cmob i.t matches 26 run scoreboard players operation @s i.qs26 -= #dq i.t
execute if score #cmob i.t matches 27 run scoreboard players operation @s i.qs27 -= #dq i.t
execute if score #cmob i.t matches 28 run scoreboard players operation @s i.qs28 -= #dq i.t
execute if score #cmob i.t matches 29 run scoreboard players operation @s i.qs29 -= #dq i.t
execute if score #cmob i.t matches 30 run scoreboard players operation @s i.qs30 -= #dq i.t
execute if score #cmob i.t matches 31 run scoreboard players operation @s i.qs31 -= #dq i.t
execute if score #cmob i.t matches 32 run scoreboard players operation @s i.qs32 -= #dq i.t
execute if score #cmob i.t matches 33 run scoreboard players operation @s i.qs33 -= #dq i.t
execute if score #cmob i.t matches 34 run scoreboard players operation @s i.qs34 -= #dq i.t
execute if score #cmob i.t matches 0 run data modify storage industrie:t sp.nom set value "Poulet"
execute if score #cmob i.t matches 1 run data modify storage industrie:t sp.nom set value "Cochon"
execute if score #cmob i.t matches 2 run data modify storage industrie:t sp.nom set value "Lapin"
execute if score #cmob i.t matches 3 run data modify storage industrie:t sp.nom set value "Mouton"
execute if score #cmob i.t matches 4 run data modify storage industrie:t sp.nom set value "Vache"
execute if score #cmob i.t matches 5 run data modify storage industrie:t sp.nom set value "Chèvre"
execute if score #cmob i.t matches 6 run data modify storage industrie:t sp.nom set value "Champimeuh"
execute if score #cmob i.t matches 7 run data modify storage industrie:t sp.nom set value "Poisson d’argent"
execute if score #cmob i.t matches 8 run data modify storage industrie:t sp.nom set value "Zombie"
execute if score #cmob i.t matches 9 run data modify storage industrie:t sp.nom set value "Araignée"
execute if score #cmob i.t matches 10 run data modify storage industrie:t sp.nom set value "Zombie momifié"
execute if score #cmob i.t matches 11 run data modify storage industrie:t sp.nom set value "Noyé"
execute if score #cmob i.t matches 12 run data modify storage industrie:t sp.nom set value "Squelette"
execute if score #cmob i.t matches 13 run data modify storage industrie:t sp.nom set value "Araignée venimeuse"
execute if score #cmob i.t matches 14 run data modify storage industrie:t sp.nom set value "Vagabond"
execute if score #cmob i.t matches 15 run data modify storage industrie:t sp.nom set value "Embourbé"
execute if score #cmob i.t matches 16 run data modify storage industrie:t sp.nom set value "Slime"
execute if score #cmob i.t matches 17 run data modify storage industrie:t sp.nom set value "Piglin zombifié"
execute if score #cmob i.t matches 18 run data modify storage industrie:t sp.nom set value "Cube de magma"
execute if score #cmob i.t matches 19 run data modify storage industrie:t sp.nom set value "Creeper"
execute if score #cmob i.t matches 20 run data modify storage industrie:t sp.nom set value "Piglin"
execute if score #cmob i.t matches 21 run data modify storage industrie:t sp.nom set value "Phantom"
execute if score #cmob i.t matches 22 run data modify storage industrie:t sp.nom set value "Sorcière"
execute if score #cmob i.t matches 23 run data modify storage industrie:t sp.nom set value "Hoglin"
execute if score #cmob i.t matches 24 run data modify storage industrie:t sp.nom set value "Pillard"
execute if score #cmob i.t matches 25 run data modify storage industrie:t sp.nom set value "Gardien"
execute if score #cmob i.t matches 26 run data modify storage industrie:t sp.nom set value "Enderman"
execute if score #cmob i.t matches 27 run data modify storage industrie:t sp.nom set value "Blaze"
execute if score #cmob i.t matches 28 run data modify storage industrie:t sp.nom set value "Vindicateur"
execute if score #cmob i.t matches 29 run data modify storage industrie:t sp.nom set value "Ghast"
execute if score #cmob i.t matches 30 run data modify storage industrie:t sp.nom set value "Breeze"
execute if score #cmob i.t matches 31 run data modify storage industrie:t sp.nom set value "Wither squelette"
execute if score #cmob i.t matches 32 run data modify storage industrie:t sp.nom set value "Ravageur"
execute if score #cmob i.t matches 33 run data modify storage industrie:t sp.nom set value "Shulker"
execute if score #cmob i.t matches 34 run data modify storage industrie:t sp.nom set value "Évocateur"
scoreboard players operation #x i.t = #cmob i.t
scoreboard players add #x i.t 1
execute store result storage industrie:t sp.m int 1 run scoreboard players get #x i.t
execute store result storage industrie:t sp.v int 1 run scoreboard players get #spv i.t
execute store result storage industrie:t sp.q int 1 run scoreboard players get #spq i.t
data modify storage industrie:t sp.p set value 0
data modify storage industrie:t sp.c set value 0
function commerce:spawner/donner with storage industrie:t sp
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Le spawner te revient, avec ses améliorations de vitesse et de quantité.",color:"light_purple",bold:false,italic:false}]
