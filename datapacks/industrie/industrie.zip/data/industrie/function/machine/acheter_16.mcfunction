function industrie:ile/position
execute if score #ok i.t matches 0 run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Va sur une de tes parcelles, près d'un emplacement libre (dalle noire à coins dorés).",color:"red",bold:false,italic:false}]
execute unless score @s i.rang matches 5.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Forge des reliques : il faut le rang Empire.",color:"red",bold:false,italic:false}]
scoreboard players set #max i.t 0
execute if score @s i.rang matches 1 run scoreboard players set #max i.t 0
execute if score @s i.rang matches 2 run scoreboard players set #max i.t 0
execute if score @s i.rang matches 3 run scoreboard players set #max i.t 0
execute if score @s i.rang matches 4 run scoreboard players set #max i.t 1
execute if score @s i.rang matches 5 run scoreboard players set #max i.t 2
execute if score @s i.n_forge >= #max i.t run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Tu as déjà le maximum de Forge des reliques pour ton rang.",color:"red",bold:false,italic:false}]
scoreboard players set #prix i.t 40000000
execute if score @s m.k_lvl matches 50.. run scoreboard players set #prix i.t 36000000
execute unless score @s c.ecus >= #prix i.t run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Il te faut 40 000 000 Écus.",color:"red",bold:false,italic:false}]
execute unless score @s m.ecl matches 60.. run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Il te faut 60 éclats de boss.",color:"red",bold:false,italic:false}]
scoreboard players operation #me i.t = @s m.id
scoreboard players operation #own i.t = @s m.id
execute as @e[type=minecraft:marker,tag=ind.slot,tag=!ind.occ,distance=..48] if score @s i.own = #me i.t run tag @s add ind.cand
execute unless entity @e[type=minecraft:marker,tag=ind.cand] run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Aucun emplacement libre à moins de 48 blocs : achète une parcelle (Cadastre) ou rapproche-toi.",color:"red",bold:false,italic:false}]
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus -= #prix i.t
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.a_ind -= #prix i.t
scoreboard players remove @s m.ecl 60
scoreboard players set #sf i.t 100
scoreboard players set #mob i.t 0
scoreboard players set #spv i.t 0
scoreboard players set #spq i.t 0
scoreboard players add @s i.q_forge 100
scoreboard players add @s i.n_forge 1
scoreboard players add @s i.k_forge 10
scoreboard players set #pm i.t 16
scoreboard players set #pl i.t 1
scoreboard players operation #tt i.t = @s i.tube
execute as @e[type=minecraft:marker,tag=ind.cand,limit=1,sort=nearest] at @s run function industrie:machine/poser_ici
tag @e[type=minecraft:marker,tag=ind.cand] remove ind.cand
playsound minecraft:block.anvil.use master @s ~ ~ ~ 0.8 1.2
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.4
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Forge des reliques posée et reliée au Nexus. Clic droit dessus pour sa fiche.",color:"green",bold:false,italic:false}]
