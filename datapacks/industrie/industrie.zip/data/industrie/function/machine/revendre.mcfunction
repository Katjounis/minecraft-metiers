scoreboard players operation #me i.t = @s m.id
scoreboard players operation #sel i.t = @s i.sel
scoreboard players set #cm i.t -1
execute as @e[type=minecraft:item_display,tag=ind.m,distance=..96] if score @s i.own = #me i.t if score @s i.sid = #sel i.t run function industrie:machine/lire
execute if score #cm i.t matches -1 run return run tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Approche-toi de ta machine.",color:"red",bold:false,italic:false}]
scoreboard players set #rv i.t 0
execute if score #cm i.t matches 0 if score #cl i.t matches 1 run scoreboard players set #rv i.t 15000
execute if score #cm i.t matches 0 if score #cl i.t matches 1 run scoreboard players remove @s i.q_carriere 100
execute if score #cm i.t matches 0 if score #cl i.t matches 1 run scoreboard players remove @s i.k_carriere 10
execute if score #cm i.t matches 0 if score #cl i.t matches 2 run scoreboard players set #rv i.t 45000
execute if score #cm i.t matches 0 if score #cl i.t matches 2 run scoreboard players remove @s i.q_carriere 150
execute if score #cm i.t matches 0 if score #cl i.t matches 2 run scoreboard players remove @s i.k_carriere 13
execute if score #cm i.t matches 0 if score #cl i.t matches 3 run scoreboard players set #rv i.t 120000
execute if score #cm i.t matches 0 if score #cl i.t matches 3 run scoreboard players remove @s i.q_carriere 220
execute if score #cm i.t matches 0 if score #cl i.t matches 3 run scoreboard players remove @s i.k_carriere 17
execute if score #cm i.t matches 0 if score #cl i.t matches 4 run scoreboard players set #rv i.t 300000
execute if score #cm i.t matches 0 if score #cl i.t matches 4 run scoreboard players remove @s i.q_carriere 320
execute if score #cm i.t matches 0 if score #cl i.t matches 4 run scoreboard players remove @s i.k_carriere 22
execute if score #cm i.t matches 0 if score #cl i.t matches 5 run scoreboard players set #rv i.t 750000
execute if score #cm i.t matches 0 if score #cl i.t matches 5 run scoreboard players remove @s i.q_carriere 450
execute if score #cm i.t matches 0 if score #cl i.t matches 5 run scoreboard players remove @s i.k_carriere 28
execute if score #cm i.t matches 0 run scoreboard players remove @s i.n_carriere 1
execute if score #cm i.t matches 1 if score #cl i.t matches 1 run scoreboard players set #rv i.t 22500
execute if score #cm i.t matches 1 if score #cl i.t matches 1 run scoreboard players remove @s i.q_serre 100
execute if score #cm i.t matches 1 if score #cl i.t matches 1 run scoreboard players remove @s i.k_serre 10
execute if score #cm i.t matches 1 if score #cl i.t matches 2 run scoreboard players set #rv i.t 67500
execute if score #cm i.t matches 1 if score #cl i.t matches 2 run scoreboard players remove @s i.q_serre 150
execute if score #cm i.t matches 1 if score #cl i.t matches 2 run scoreboard players remove @s i.k_serre 13
execute if score #cm i.t matches 1 if score #cl i.t matches 3 run scoreboard players set #rv i.t 180000
execute if score #cm i.t matches 1 if score #cl i.t matches 3 run scoreboard players remove @s i.q_serre 220
execute if score #cm i.t matches 1 if score #cl i.t matches 3 run scoreboard players remove @s i.k_serre 17
execute if score #cm i.t matches 1 if score #cl i.t matches 4 run scoreboard players set #rv i.t 450000
execute if score #cm i.t matches 1 if score #cl i.t matches 4 run scoreboard players remove @s i.q_serre 320
execute if score #cm i.t matches 1 if score #cl i.t matches 4 run scoreboard players remove @s i.k_serre 22
execute if score #cm i.t matches 1 if score #cl i.t matches 5 run scoreboard players set #rv i.t 1125000
execute if score #cm i.t matches 1 if score #cl i.t matches 5 run scoreboard players remove @s i.q_serre 450
execute if score #cm i.t matches 1 if score #cl i.t matches 5 run scoreboard players remove @s i.k_serre 28
execute if score #cm i.t matches 1 run scoreboard players remove @s i.n_serre 1
execute if score #cm i.t matches 2 if score #cl i.t matches 1 run scoreboard players set #rv i.t 17500
execute if score #cm i.t matches 2 if score #cl i.t matches 1 run scoreboard players remove @s i.q_cultures 100
execute if score #cm i.t matches 2 if score #cl i.t matches 1 run scoreboard players remove @s i.k_cultures 10
execute if score #cm i.t matches 2 if score #cl i.t matches 2 run scoreboard players set #rv i.t 52500
execute if score #cm i.t matches 2 if score #cl i.t matches 2 run scoreboard players remove @s i.q_cultures 150
execute if score #cm i.t matches 2 if score #cl i.t matches 2 run scoreboard players remove @s i.k_cultures 13
execute if score #cm i.t matches 2 if score #cl i.t matches 3 run scoreboard players set #rv i.t 140000
execute if score #cm i.t matches 2 if score #cl i.t matches 3 run scoreboard players remove @s i.q_cultures 220
execute if score #cm i.t matches 2 if score #cl i.t matches 3 run scoreboard players remove @s i.k_cultures 17
execute if score #cm i.t matches 2 if score #cl i.t matches 4 run scoreboard players set #rv i.t 350000
execute if score #cm i.t matches 2 if score #cl i.t matches 4 run scoreboard players remove @s i.q_cultures 320
execute if score #cm i.t matches 2 if score #cl i.t matches 4 run scoreboard players remove @s i.k_cultures 22
execute if score #cm i.t matches 2 if score #cl i.t matches 5 run scoreboard players set #rv i.t 875000
execute if score #cm i.t matches 2 if score #cl i.t matches 5 run scoreboard players remove @s i.q_cultures 450
execute if score #cm i.t matches 2 if score #cl i.t matches 5 run scoreboard players remove @s i.k_cultures 28
execute if score #cm i.t matches 2 run scoreboard players remove @s i.n_cultures 1
execute if score #cm i.t matches 3 if score #cl i.t matches 1 run scoreboard players set #rv i.t 60000
execute if score #cm i.t matches 3 if score #cl i.t matches 1 run scoreboard players remove @s i.q_fourneau 100
execute if score #cm i.t matches 3 if score #cl i.t matches 1 run scoreboard players remove @s i.k_fourneau 10
execute if score #cm i.t matches 3 if score #cl i.t matches 2 run scoreboard players set #rv i.t 180000
execute if score #cm i.t matches 3 if score #cl i.t matches 2 run scoreboard players remove @s i.q_fourneau 150
execute if score #cm i.t matches 3 if score #cl i.t matches 2 run scoreboard players remove @s i.k_fourneau 13
execute if score #cm i.t matches 3 if score #cl i.t matches 3 run scoreboard players set #rv i.t 480000
execute if score #cm i.t matches 3 if score #cl i.t matches 3 run scoreboard players remove @s i.q_fourneau 220
execute if score #cm i.t matches 3 if score #cl i.t matches 3 run scoreboard players remove @s i.k_fourneau 17
execute if score #cm i.t matches 3 if score #cl i.t matches 4 run scoreboard players set #rv i.t 1200000
execute if score #cm i.t matches 3 if score #cl i.t matches 4 run scoreboard players remove @s i.q_fourneau 320
execute if score #cm i.t matches 3 if score #cl i.t matches 4 run scoreboard players remove @s i.k_fourneau 22
execute if score #cm i.t matches 3 if score #cl i.t matches 5 run scoreboard players set #rv i.t 3000000
execute if score #cm i.t matches 3 if score #cl i.t matches 5 run scoreboard players remove @s i.q_fourneau 450
execute if score #cm i.t matches 3 if score #cl i.t matches 5 run scoreboard players remove @s i.k_fourneau 28
execute if score #cm i.t matches 3 run scoreboard players remove @s i.n_fourneau 1
execute if score #cm i.t matches 4 if score #cl i.t matches 1 run scoreboard players set #rv i.t 10000
execute if score #cm i.t matches 4 if score #cl i.t matches 1 run scoreboard players remove @s i.q_chaudiere 100
execute if score #cm i.t matches 4 if score #cl i.t matches 1 run scoreboard players remove @s i.k_chaudiere 10
execute if score #cm i.t matches 4 if score #cl i.t matches 2 run scoreboard players set #rv i.t 30000
execute if score #cm i.t matches 4 if score #cl i.t matches 2 run scoreboard players remove @s i.q_chaudiere 150
execute if score #cm i.t matches 4 if score #cl i.t matches 2 run scoreboard players remove @s i.k_chaudiere 13
execute if score #cm i.t matches 4 if score #cl i.t matches 3 run scoreboard players set #rv i.t 80000
execute if score #cm i.t matches 4 if score #cl i.t matches 3 run scoreboard players remove @s i.q_chaudiere 220
execute if score #cm i.t matches 4 if score #cl i.t matches 3 run scoreboard players remove @s i.k_chaudiere 17
execute if score #cm i.t matches 4 if score #cl i.t matches 4 run scoreboard players set #rv i.t 200000
execute if score #cm i.t matches 4 if score #cl i.t matches 4 run scoreboard players remove @s i.q_chaudiere 320
execute if score #cm i.t matches 4 if score #cl i.t matches 4 run scoreboard players remove @s i.k_chaudiere 22
execute if score #cm i.t matches 4 if score #cl i.t matches 5 run scoreboard players set #rv i.t 500000
execute if score #cm i.t matches 4 if score #cl i.t matches 5 run scoreboard players remove @s i.q_chaudiere 450
execute if score #cm i.t matches 4 if score #cl i.t matches 5 run scoreboard players remove @s i.k_chaudiere 28
execute if score #cm i.t matches 4 run scoreboard players remove @s i.n_chaudiere 1
execute if score #cm i.t matches 5 if score #cl i.t matches 1 run scoreboard players set #rv i.t 250000
execute if score #cm i.t matches 5 if score #cl i.t matches 1 run scoreboard players remove @s i.q_puits_or 100
execute if score #cm i.t matches 5 if score #cl i.t matches 1 run scoreboard players remove @s i.k_puits_or 10
execute if score #cm i.t matches 5 if score #cl i.t matches 2 run scoreboard players set #rv i.t 750000
execute if score #cm i.t matches 5 if score #cl i.t matches 2 run scoreboard players remove @s i.q_puits_or 150
execute if score #cm i.t matches 5 if score #cl i.t matches 2 run scoreboard players remove @s i.k_puits_or 13
execute if score #cm i.t matches 5 if score #cl i.t matches 3 run scoreboard players set #rv i.t 2000000
execute if score #cm i.t matches 5 if score #cl i.t matches 3 run scoreboard players remove @s i.q_puits_or 220
execute if score #cm i.t matches 5 if score #cl i.t matches 3 run scoreboard players remove @s i.k_puits_or 17
execute if score #cm i.t matches 5 if score #cl i.t matches 4 run scoreboard players set #rv i.t 5000000
execute if score #cm i.t matches 5 if score #cl i.t matches 4 run scoreboard players remove @s i.q_puits_or 320
execute if score #cm i.t matches 5 if score #cl i.t matches 4 run scoreboard players remove @s i.k_puits_or 22
execute if score #cm i.t matches 5 if score #cl i.t matches 5 run scoreboard players set #rv i.t 12500000
execute if score #cm i.t matches 5 if score #cl i.t matches 5 run scoreboard players remove @s i.q_puits_or 450
execute if score #cm i.t matches 5 if score #cl i.t matches 5 run scoreboard players remove @s i.k_puits_or 28
execute if score #cm i.t matches 5 run scoreboard players remove @s i.n_puits_or 1
execute if score #cm i.t matches 6 if score #cl i.t matches 1 run scoreboard players set #rv i.t 200000
execute if score #cm i.t matches 6 if score #cl i.t matches 1 run scoreboard players remove @s i.q_fonderie 100
execute if score #cm i.t matches 6 if score #cl i.t matches 1 run scoreboard players remove @s i.k_fonderie 10
execute if score #cm i.t matches 6 if score #cl i.t matches 2 run scoreboard players set #rv i.t 600000
execute if score #cm i.t matches 6 if score #cl i.t matches 2 run scoreboard players remove @s i.q_fonderie 150
execute if score #cm i.t matches 6 if score #cl i.t matches 2 run scoreboard players remove @s i.k_fonderie 13
execute if score #cm i.t matches 6 if score #cl i.t matches 3 run scoreboard players set #rv i.t 1600000
execute if score #cm i.t matches 6 if score #cl i.t matches 3 run scoreboard players remove @s i.q_fonderie 220
execute if score #cm i.t matches 6 if score #cl i.t matches 3 run scoreboard players remove @s i.k_fonderie 17
execute if score #cm i.t matches 6 if score #cl i.t matches 4 run scoreboard players set #rv i.t 4000000
execute if score #cm i.t matches 6 if score #cl i.t matches 4 run scoreboard players remove @s i.q_fonderie 320
execute if score #cm i.t matches 6 if score #cl i.t matches 4 run scoreboard players remove @s i.k_fonderie 22
execute if score #cm i.t matches 6 if score #cl i.t matches 5 run scoreboard players set #rv i.t 10000000
execute if score #cm i.t matches 6 if score #cl i.t matches 5 run scoreboard players remove @s i.q_fonderie 450
execute if score #cm i.t matches 6 if score #cl i.t matches 5 run scoreboard players remove @s i.k_fonderie 28
execute if score #cm i.t matches 6 run scoreboard players remove @s i.n_fonderie 1
execute if score #cm i.t matches 7 if score #cl i.t matches 1 run scoreboard players set #rv i.t 250000
execute if score #cm i.t matches 7 if score #cl i.t matches 1 run scoreboard players remove @s i.q_distill 100
execute if score #cm i.t matches 7 if score #cl i.t matches 1 run scoreboard players remove @s i.k_distill 10
execute if score #cm i.t matches 7 if score #cl i.t matches 2 run scoreboard players set #rv i.t 750000
execute if score #cm i.t matches 7 if score #cl i.t matches 2 run scoreboard players remove @s i.q_distill 150
execute if score #cm i.t matches 7 if score #cl i.t matches 2 run scoreboard players remove @s i.k_distill 13
execute if score #cm i.t matches 7 if score #cl i.t matches 3 run scoreboard players set #rv i.t 2000000
execute if score #cm i.t matches 7 if score #cl i.t matches 3 run scoreboard players remove @s i.q_distill 220
execute if score #cm i.t matches 7 if score #cl i.t matches 3 run scoreboard players remove @s i.k_distill 17
execute if score #cm i.t matches 7 if score #cl i.t matches 4 run scoreboard players set #rv i.t 5000000
execute if score #cm i.t matches 7 if score #cl i.t matches 4 run scoreboard players remove @s i.q_distill 320
execute if score #cm i.t matches 7 if score #cl i.t matches 4 run scoreboard players remove @s i.k_distill 22
execute if score #cm i.t matches 7 if score #cl i.t matches 5 run scoreboard players set #rv i.t 12500000
execute if score #cm i.t matches 7 if score #cl i.t matches 5 run scoreboard players remove @s i.q_distill 450
execute if score #cm i.t matches 7 if score #cl i.t matches 5 run scoreboard players remove @s i.k_distill 28
execute if score #cm i.t matches 7 run scoreboard players remove @s i.n_distill 1
execute if score #cm i.t matches 8 if score #cl i.t matches 1 run scoreboard players set #rv i.t 150000
execute if score #cm i.t matches 8 if score #cl i.t matches 1 run scoreboard players remove @s i.q_spawner 100
execute if score #cm i.t matches 8 if score #cl i.t matches 1 run scoreboard players remove @s i.k_spawner 10
execute if score #cm i.t matches 8 if score #cl i.t matches 1 run scoreboard players set #dq i.t 100
execute if score #cm i.t matches 8 if score #cl i.t matches 2 run scoreboard players set #rv i.t 450000
execute if score #cm i.t matches 8 if score #cl i.t matches 2 run scoreboard players remove @s i.q_spawner 150
execute if score #cm i.t matches 8 if score #cl i.t matches 2 run scoreboard players remove @s i.k_spawner 13
execute if score #cm i.t matches 8 if score #cl i.t matches 2 run scoreboard players set #dq i.t 150
execute if score #cm i.t matches 8 if score #cl i.t matches 3 run scoreboard players set #rv i.t 1200000
execute if score #cm i.t matches 8 if score #cl i.t matches 3 run scoreboard players remove @s i.q_spawner 220
execute if score #cm i.t matches 8 if score #cl i.t matches 3 run scoreboard players remove @s i.k_spawner 17
execute if score #cm i.t matches 8 if score #cl i.t matches 3 run scoreboard players set #dq i.t 220
execute if score #cm i.t matches 8 if score #cl i.t matches 4 run scoreboard players set #rv i.t 3000000
execute if score #cm i.t matches 8 if score #cl i.t matches 4 run scoreboard players remove @s i.q_spawner 320
execute if score #cm i.t matches 8 if score #cl i.t matches 4 run scoreboard players remove @s i.k_spawner 22
execute if score #cm i.t matches 8 if score #cl i.t matches 4 run scoreboard players set #dq i.t 320
execute if score #cm i.t matches 8 if score #cl i.t matches 5 run scoreboard players set #rv i.t 7500000
execute if score #cm i.t matches 8 if score #cl i.t matches 5 run scoreboard players remove @s i.q_spawner 450
execute if score #cm i.t matches 8 if score #cl i.t matches 5 run scoreboard players remove @s i.k_spawner 28
execute if score #cm i.t matches 8 if score #cl i.t matches 5 run scoreboard players set #dq i.t 450
execute if score #cm i.t matches 8 run scoreboard players remove @s i.n_spawner 1
execute if score #cm i.t matches 9 if score #cl i.t matches 1 run scoreboard players set #rv i.t 175000
execute if score #cm i.t matches 9 if score #cl i.t matches 1 run scoreboard players remove @s i.q_lave 100
execute if score #cm i.t matches 9 if score #cl i.t matches 1 run scoreboard players remove @s i.k_lave 10
execute if score #cm i.t matches 9 if score #cl i.t matches 2 run scoreboard players set #rv i.t 525000
execute if score #cm i.t matches 9 if score #cl i.t matches 2 run scoreboard players remove @s i.q_lave 150
execute if score #cm i.t matches 9 if score #cl i.t matches 2 run scoreboard players remove @s i.k_lave 13
execute if score #cm i.t matches 9 if score #cl i.t matches 3 run scoreboard players set #rv i.t 1400000
execute if score #cm i.t matches 9 if score #cl i.t matches 3 run scoreboard players remove @s i.q_lave 220
execute if score #cm i.t matches 9 if score #cl i.t matches 3 run scoreboard players remove @s i.k_lave 17
execute if score #cm i.t matches 9 if score #cl i.t matches 4 run scoreboard players set #rv i.t 3500000
execute if score #cm i.t matches 9 if score #cl i.t matches 4 run scoreboard players remove @s i.q_lave 320
execute if score #cm i.t matches 9 if score #cl i.t matches 4 run scoreboard players remove @s i.k_lave 22
execute if score #cm i.t matches 9 if score #cl i.t matches 5 run scoreboard players set #rv i.t 8750000
execute if score #cm i.t matches 9 if score #cl i.t matches 5 run scoreboard players remove @s i.q_lave 450
execute if score #cm i.t matches 9 if score #cl i.t matches 5 run scoreboard players remove @s i.k_lave 28
execute if score #cm i.t matches 9 run scoreboard players remove @s i.n_lave 1
execute if score #cm i.t matches 10 if score #cl i.t matches 1 run scoreboard players set #rv i.t 1500000
execute if score #cm i.t matches 10 if score #cl i.t matches 1 run scoreboard players remove @s i.q_puits_dia 100
execute if score #cm i.t matches 10 if score #cl i.t matches 1 run scoreboard players remove @s i.k_puits_dia 10
execute if score #cm i.t matches 10 if score #cl i.t matches 2 run scoreboard players set #rv i.t 4500000
execute if score #cm i.t matches 10 if score #cl i.t matches 2 run scoreboard players remove @s i.q_puits_dia 150
execute if score #cm i.t matches 10 if score #cl i.t matches 2 run scoreboard players remove @s i.k_puits_dia 13
execute if score #cm i.t matches 10 if score #cl i.t matches 3 run scoreboard players set #rv i.t 12000000
execute if score #cm i.t matches 10 if score #cl i.t matches 3 run scoreboard players remove @s i.q_puits_dia 220
execute if score #cm i.t matches 10 if score #cl i.t matches 3 run scoreboard players remove @s i.k_puits_dia 17
execute if score #cm i.t matches 10 if score #cl i.t matches 4 run scoreboard players set #rv i.t 30000000
execute if score #cm i.t matches 10 if score #cl i.t matches 4 run scoreboard players remove @s i.q_puits_dia 320
execute if score #cm i.t matches 10 if score #cl i.t matches 4 run scoreboard players remove @s i.k_puits_dia 22
execute if score #cm i.t matches 10 if score #cl i.t matches 5 run scoreboard players set #rv i.t 75000000
execute if score #cm i.t matches 10 if score #cl i.t matches 5 run scoreboard players remove @s i.q_puits_dia 450
execute if score #cm i.t matches 10 if score #cl i.t matches 5 run scoreboard players remove @s i.k_puits_dia 28
execute if score #cm i.t matches 10 run scoreboard players remove @s i.n_puits_dia 1
execute if score #cm i.t matches 11 if score #cl i.t matches 1 run scoreboard players set #rv i.t 1250000
execute if score #cm i.t matches 11 if score #cl i.t matches 1 run scoreboard players remove @s i.q_puits_eme 100
execute if score #cm i.t matches 11 if score #cl i.t matches 1 run scoreboard players remove @s i.k_puits_eme 10
execute if score #cm i.t matches 11 if score #cl i.t matches 2 run scoreboard players set #rv i.t 3750000
execute if score #cm i.t matches 11 if score #cl i.t matches 2 run scoreboard players remove @s i.q_puits_eme 150
execute if score #cm i.t matches 11 if score #cl i.t matches 2 run scoreboard players remove @s i.k_puits_eme 13
execute if score #cm i.t matches 11 if score #cl i.t matches 3 run scoreboard players set #rv i.t 10000000
execute if score #cm i.t matches 11 if score #cl i.t matches 3 run scoreboard players remove @s i.q_puits_eme 220
execute if score #cm i.t matches 11 if score #cl i.t matches 3 run scoreboard players remove @s i.k_puits_eme 17
execute if score #cm i.t matches 11 if score #cl i.t matches 4 run scoreboard players set #rv i.t 25000000
execute if score #cm i.t matches 11 if score #cl i.t matches 4 run scoreboard players remove @s i.q_puits_eme 320
execute if score #cm i.t matches 11 if score #cl i.t matches 4 run scoreboard players remove @s i.k_puits_eme 22
execute if score #cm i.t matches 11 if score #cl i.t matches 5 run scoreboard players set #rv i.t 62500000
execute if score #cm i.t matches 11 if score #cl i.t matches 5 run scoreboard players remove @s i.q_puits_eme 450
execute if score #cm i.t matches 11 if score #cl i.t matches 5 run scoreboard players remove @s i.k_puits_eme 28
execute if score #cm i.t matches 11 run scoreboard players remove @s i.n_puits_eme 1
execute if score #cm i.t matches 12 if score #cl i.t matches 1 run scoreboard players set #rv i.t 1500000
execute if score #cm i.t matches 12 if score #cl i.t matches 1 run scoreboard players remove @s i.q_atelier 100
execute if score #cm i.t matches 12 if score #cl i.t matches 1 run scoreboard players remove @s i.k_atelier 10
execute if score #cm i.t matches 12 if score #cl i.t matches 2 run scoreboard players set #rv i.t 4500000
execute if score #cm i.t matches 12 if score #cl i.t matches 2 run scoreboard players remove @s i.q_atelier 150
execute if score #cm i.t matches 12 if score #cl i.t matches 2 run scoreboard players remove @s i.k_atelier 13
execute if score #cm i.t matches 12 if score #cl i.t matches 3 run scoreboard players set #rv i.t 12000000
execute if score #cm i.t matches 12 if score #cl i.t matches 3 run scoreboard players remove @s i.q_atelier 220
execute if score #cm i.t matches 12 if score #cl i.t matches 3 run scoreboard players remove @s i.k_atelier 17
execute if score #cm i.t matches 12 if score #cl i.t matches 4 run scoreboard players set #rv i.t 30000000
execute if score #cm i.t matches 12 if score #cl i.t matches 4 run scoreboard players remove @s i.q_atelier 320
execute if score #cm i.t matches 12 if score #cl i.t matches 4 run scoreboard players remove @s i.k_atelier 22
execute if score #cm i.t matches 12 if score #cl i.t matches 5 run scoreboard players set #rv i.t 75000000
execute if score #cm i.t matches 12 if score #cl i.t matches 5 run scoreboard players remove @s i.q_atelier 450
execute if score #cm i.t matches 12 if score #cl i.t matches 5 run scoreboard players remove @s i.k_atelier 28
execute if score #cm i.t matches 12 run scoreboard players remove @s i.n_atelier 1
execute if score #cm i.t matches 13 if score #cl i.t matches 1 run scoreboard players set #rv i.t 9000000
execute if score #cm i.t matches 13 if score #cl i.t matches 1 run scoreboard players remove @s i.q_puits_net 100
execute if score #cm i.t matches 13 if score #cl i.t matches 1 run scoreboard players remove @s i.k_puits_net 10
execute if score #cm i.t matches 13 if score #cl i.t matches 2 run scoreboard players set #rv i.t 27000000
execute if score #cm i.t matches 13 if score #cl i.t matches 2 run scoreboard players remove @s i.q_puits_net 150
execute if score #cm i.t matches 13 if score #cl i.t matches 2 run scoreboard players remove @s i.k_puits_net 13
execute if score #cm i.t matches 13 if score #cl i.t matches 3 run scoreboard players set #rv i.t 72000000
execute if score #cm i.t matches 13 if score #cl i.t matches 3 run scoreboard players remove @s i.q_puits_net 220
execute if score #cm i.t matches 13 if score #cl i.t matches 3 run scoreboard players remove @s i.k_puits_net 17
execute if score #cm i.t matches 13 if score #cl i.t matches 4 run scoreboard players set #rv i.t 180000000
execute if score #cm i.t matches 13 if score #cl i.t matches 4 run scoreboard players remove @s i.q_puits_net 320
execute if score #cm i.t matches 13 if score #cl i.t matches 4 run scoreboard players remove @s i.k_puits_net 22
execute if score #cm i.t matches 13 if score #cl i.t matches 5 run scoreboard players set #rv i.t 450000000
execute if score #cm i.t matches 13 if score #cl i.t matches 5 run scoreboard players remove @s i.q_puits_net 450
execute if score #cm i.t matches 13 if score #cl i.t matches 5 run scoreboard players remove @s i.k_puits_net 28
execute if score #cm i.t matches 13 run scoreboard players remove @s i.n_puits_net 1
execute if score #cm i.t matches 14 if score #cl i.t matches 1 run scoreboard players set #rv i.t 6000000
execute if score #cm i.t matches 14 if score #cl i.t matches 1 run scoreboard players remove @s i.q_joaillerie 100
execute if score #cm i.t matches 14 if score #cl i.t matches 1 run scoreboard players remove @s i.k_joaillerie 10
execute if score #cm i.t matches 14 if score #cl i.t matches 2 run scoreboard players set #rv i.t 18000000
execute if score #cm i.t matches 14 if score #cl i.t matches 2 run scoreboard players remove @s i.q_joaillerie 150
execute if score #cm i.t matches 14 if score #cl i.t matches 2 run scoreboard players remove @s i.k_joaillerie 13
execute if score #cm i.t matches 14 if score #cl i.t matches 3 run scoreboard players set #rv i.t 48000000
execute if score #cm i.t matches 14 if score #cl i.t matches 3 run scoreboard players remove @s i.q_joaillerie 220
execute if score #cm i.t matches 14 if score #cl i.t matches 3 run scoreboard players remove @s i.k_joaillerie 17
execute if score #cm i.t matches 14 if score #cl i.t matches 4 run scoreboard players set #rv i.t 120000000
execute if score #cm i.t matches 14 if score #cl i.t matches 4 run scoreboard players remove @s i.q_joaillerie 320
execute if score #cm i.t matches 14 if score #cl i.t matches 4 run scoreboard players remove @s i.k_joaillerie 22
execute if score #cm i.t matches 14 if score #cl i.t matches 5 run scoreboard players set #rv i.t 300000000
execute if score #cm i.t matches 14 if score #cl i.t matches 5 run scoreboard players remove @s i.q_joaillerie 450
execute if score #cm i.t matches 14 if score #cl i.t matches 5 run scoreboard players remove @s i.k_joaillerie 28
execute if score #cm i.t matches 14 run scoreboard players remove @s i.n_joaillerie 1
execute if score #cm i.t matches 15 if score #cl i.t matches 1 run scoreboard players set #rv i.t 6000000
execute if score #cm i.t matches 15 if score #cl i.t matches 1 run scoreboard players remove @s i.q_coeur 100
execute if score #cm i.t matches 15 if score #cl i.t matches 1 run scoreboard players remove @s i.k_coeur 10
execute if score #cm i.t matches 15 if score #cl i.t matches 2 run scoreboard players set #rv i.t 18000000
execute if score #cm i.t matches 15 if score #cl i.t matches 2 run scoreboard players remove @s i.q_coeur 150
execute if score #cm i.t matches 15 if score #cl i.t matches 2 run scoreboard players remove @s i.k_coeur 13
execute if score #cm i.t matches 15 if score #cl i.t matches 3 run scoreboard players set #rv i.t 48000000
execute if score #cm i.t matches 15 if score #cl i.t matches 3 run scoreboard players remove @s i.q_coeur 220
execute if score #cm i.t matches 15 if score #cl i.t matches 3 run scoreboard players remove @s i.k_coeur 17
execute if score #cm i.t matches 15 if score #cl i.t matches 4 run scoreboard players set #rv i.t 120000000
execute if score #cm i.t matches 15 if score #cl i.t matches 4 run scoreboard players remove @s i.q_coeur 320
execute if score #cm i.t matches 15 if score #cl i.t matches 4 run scoreboard players remove @s i.k_coeur 22
execute if score #cm i.t matches 15 if score #cl i.t matches 5 run scoreboard players set #rv i.t 300000000
execute if score #cm i.t matches 15 if score #cl i.t matches 5 run scoreboard players remove @s i.q_coeur 450
execute if score #cm i.t matches 15 if score #cl i.t matches 5 run scoreboard players remove @s i.k_coeur 28
execute if score #cm i.t matches 15 run scoreboard players remove @s i.n_coeur 1
execute if score #cm i.t matches 16 if score #cl i.t matches 1 run scoreboard players set #rv i.t 20000000
execute if score #cm i.t matches 16 if score #cl i.t matches 1 run scoreboard players remove @s i.q_forge 100
execute if score #cm i.t matches 16 if score #cl i.t matches 1 run scoreboard players remove @s i.k_forge 10
execute if score #cm i.t matches 16 if score #cl i.t matches 2 run scoreboard players set #rv i.t 60000000
execute if score #cm i.t matches 16 if score #cl i.t matches 2 run scoreboard players remove @s i.q_forge 150
execute if score #cm i.t matches 16 if score #cl i.t matches 2 run scoreboard players remove @s i.k_forge 13
execute if score #cm i.t matches 16 if score #cl i.t matches 3 run scoreboard players set #rv i.t 160000000
execute if score #cm i.t matches 16 if score #cl i.t matches 3 run scoreboard players remove @s i.q_forge 220
execute if score #cm i.t matches 16 if score #cl i.t matches 3 run scoreboard players remove @s i.k_forge 17
execute if score #cm i.t matches 16 if score #cl i.t matches 4 run scoreboard players set #rv i.t 400000000
execute if score #cm i.t matches 16 if score #cl i.t matches 4 run scoreboard players remove @s i.q_forge 320
execute if score #cm i.t matches 16 if score #cl i.t matches 4 run scoreboard players remove @s i.k_forge 22
execute if score #cm i.t matches 16 if score #cl i.t matches 5 run scoreboard players set #rv i.t 1000000000
execute if score #cm i.t matches 16 if score #cl i.t matches 5 run scoreboard players remove @s i.q_forge 450
execute if score #cm i.t matches 16 if score #cl i.t matches 5 run scoreboard players remove @s i.k_forge 28
execute if score #cm i.t matches 16 run scoreboard players remove @s i.n_forge 1
execute if score #cm i.t matches 8 run function industrie:machine/rv_spawner
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus += #rv i.t
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.a_ind += #rv i.t
execute as @e[tag=ind.mi,distance=..96] if score @s i.own = #me i.t if score @s i.sid = #sel i.t at @s run fill ~-2 ~ ~-2 ~2 ~4 ~2 minecraft:air replace minecraft:barrier
execute as @e[tag=ind.m,distance=..96] if score @s i.own = #me i.t if score @s i.sid = #sel i.t run kill @s
execute as @e[tag=ind.mi,distance=..96] if score @s i.own = #me i.t if score @s i.sid = #sel i.t run kill @s
execute as @e[tag=ind.tube,distance=..400] if score @s i.own = #me i.t if score @s i.sid = #sel i.t run kill @s
execute as @e[type=minecraft:marker,tag=ind.slot,distance=..96] if score @s i.own = #me i.t if score @s i.sid = #sel i.t run tag @s remove ind.occ
playsound minecraft:block.anvil.destroy master @s ~ ~ ~ 0.7 1.2
tellraw @s [{text:""},{text:"[Industrie] ",color:"#F7C843",bold:false,italic:false},{text:"Machine revendue. L'emplacement est libre.",color:"yellow",bold:false,italic:false}]
