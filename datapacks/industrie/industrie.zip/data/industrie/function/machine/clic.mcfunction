scoreboard players operation #co i.t = @s i.own
scoreboard players operation #cs i.t = @s i.sid
scoreboard players operation #cm i.t = @s i.mt
execute on target run function industrie:machine/clic_j
data remove entity @s interaction
data remove entity @s attack
