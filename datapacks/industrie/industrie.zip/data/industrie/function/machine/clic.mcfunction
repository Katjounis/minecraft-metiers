scoreboard players operation #co i.t = @s i.own
scoreboard players operation #cs i.t = @s i.sid
scoreboard players operation #cm i.t = @s i.mt
data remove entity @s interaction
data remove entity @s attack
execute on target run function industrie:machine/clic_j
