execute if entity @s[tag=hr.c.croque] if score #nuit hr.tmp matches 1 run return 0
scoreboard players add @s hr.age 1
execute if score @s hr.age matches 900.. run return run function horreur:c/disparaitre
execute if entity @s[tag=hr.nuit] if score #nuit hr.tmp matches 0 run return run function horreur:c/disparaitre
execute if entity @a[distance=..20,gamemode=!spectator] run return 0
scoreboard players remove @s hr.vie 1
execute if score @s hr.vie matches ..0 run function horreur:c/disparaitre
