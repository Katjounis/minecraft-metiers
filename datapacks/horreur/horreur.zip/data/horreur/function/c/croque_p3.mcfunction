scoreboard players set @s hr.ph 2
summon minecraft:vex ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Ombre","color":"dark_gray"},DeathLootTable:"minecraft:empty",attributes:[{id:"minecraft:max_health",base:10d}],Health:10f}
summon minecraft:vex ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Ombre","color":"dark_gray"},DeathLootTable:"minecraft:empty",attributes:[{id:"minecraft:max_health",base:10d}],Health:10f}
summon minecraft:vex ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Ombre","color":"dark_gray"},DeathLootTable:"minecraft:empty",attributes:[{id:"minecraft:max_health",base:10d}],Health:10f}
summon minecraft:vex ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Ombre","color":"dark_gray"},DeathLootTable:"minecraft:empty",attributes:[{id:"minecraft:max_health",base:10d}],Health:10f}
effect give @a[distance=..48,gamemode=!spectator] minecraft:darkness 15 0 true
effect give @s minecraft:resistance 10 1 true
playsound horreur:croque.grondement hostile @a[distance=..64] ~ ~ ~ 3 1
tellraw @a[distance=..96] {"text":"Le Croque-mitaine éteint la nuit... ses ombres sortent de partout.","color":"dark_red","bold":true}
