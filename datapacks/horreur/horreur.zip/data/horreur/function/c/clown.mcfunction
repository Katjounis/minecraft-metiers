execute store result score #r hr.tmp run random value 1..30
execute if score #r hr.tmp matches 1 run playsound minecraft:entity.witch.celebrate hostile @a[distance=..32] ~ ~ ~ 1.5 1.4
execute if score #r hr.tmp matches 2 run playsound minecraft:entity.witch.ambient hostile @a[distance=..32] ~ ~ ~ 1 1.6
