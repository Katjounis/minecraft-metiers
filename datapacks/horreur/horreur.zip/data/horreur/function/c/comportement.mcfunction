execute if entity @s[tag=hr.c.slender] run return run function horreur:c/slender
execute if entity @s[tag=hr.c.herobrine] run return run function horreur:c/herobrine
execute if entity @s[tag=hr.c.siren] run return run function horreur:c/siren
execute if entity @s[tag=hr.c.nonne] run return run function horreur:c/nonne
execute if entity @s[tag=hr.c.clown] run return run function horreur:c/clown
execute if entity @s[tag=hr.c.pinhead] run return run function horreur:c/pinhead
