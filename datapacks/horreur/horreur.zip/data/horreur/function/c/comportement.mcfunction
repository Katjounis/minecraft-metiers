function horreur:c/commun
execute if entity @s[tag=hr.c.slender] run return run function horreur:c/slender
execute if entity @s[tag=hr.c.herobrine] run return run function horreur:c/herobrine
execute if entity @s[tag=hr.c.siren] run return run function horreur:c/siren
execute if entity @s[tag=hr.c.nonne] run return run function horreur:c/nonne
execute if entity @s[tag=hr.c.clown] run return run function horreur:c/clown
execute if entity @s[tag=hr.c.pinhead] run return run function horreur:c/pinhead
execute if entity @s[tag=hr.c.dame] run return run function horreur:c/dame
execute if entity @s[tag=hr.c.loup] run return run function horreur:c/loup
execute if entity @s[tag=hr.c.feu] run return run function horreur:c/feu
execute if entity @s[tag=hr.c.rodeur] run return run function horreur:c/rodeur
execute if entity @s[tag=hr.c.croque] run return run function horreur:c/croque
