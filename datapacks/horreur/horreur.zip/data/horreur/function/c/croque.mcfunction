particle minecraft:smoke ~ ~2 ~ 0.6 1.5 0.6 0.01 6
execute store result bossbar horreur:boss value run data get entity @s Health
bossbar set horreur:boss players @a[distance=..96]
# 26/11/2026 : ses attaques passent par les sorts (sort/croque) ; deux phases, à 50 % et 25 % de sa vie
function horreur:c/pct
execute if score @s hr.ph matches 0 if score #hp hr.tmp matches ..50 run function horreur:c/croque_p2
execute if score @s hr.ph matches 1 if score #hp hr.tmp matches ..25 run function horreur:c/croque_p3
