particle minecraft:smoke ~ ~2 ~ 0.6 1.5 0.6 0.01 6
execute store result bossbar horreur:boss value run data get entity @s Health
bossbar set horreur:boss players @a[distance=..96]
scoreboard players add @s hr.t 5
execute if score @s hr.t matches 120.. run function horreur:c/croque_attaque
