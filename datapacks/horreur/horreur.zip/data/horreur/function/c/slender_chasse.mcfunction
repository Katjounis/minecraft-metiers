scoreboard players add @s hr.t 5
execute if score @s hr.t matches 80.. unless entity @a[distance=..8,gamemode=!spectator] run function horreur:c/slender_approche
