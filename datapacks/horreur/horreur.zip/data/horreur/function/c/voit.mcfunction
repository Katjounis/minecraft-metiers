tag @s add hr.voit
scoreboard players set #vu hr.tmp 1
