particle minecraft:portal ~ ~1.6 ~ 0.3 1 0.3 0.4 4
execute unless entity @a[distance=..64,gamemode=!spectator] run return 0
execute if score @s hr.etat matches 2 run return run function horreur:c/slender_chasse
execute if entity @a[distance=..64,gamemode=!spectator,predicate=horreur:regarde/slender] run return run function horreur:c/slender_fixe
scoreboard players set @s hr.r 0
scoreboard players add @s hr.t 5
execute if score @s hr.t matches 60.. run function horreur:c/slender_approche
