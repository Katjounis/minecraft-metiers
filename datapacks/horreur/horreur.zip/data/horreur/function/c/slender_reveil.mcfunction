scoreboard players set @s hr.etat 2
scoreboard players set @s hr.t 0
attribute @s minecraft:movement_speed base set 0.34
playsound horreur:slender.reveil hostile @a[distance=..48] ~ ~ ~ 2 1
effect give @a[distance=..24,gamemode=!spectator] minecraft:darkness 10 0 true
