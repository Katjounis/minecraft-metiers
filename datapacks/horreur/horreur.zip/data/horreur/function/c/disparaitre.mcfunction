particle minecraft:large_smoke ~ ~1 ~ 0.4 0.9 0.4 0.02 40
playsound minecraft:entity.enderman.teleport hostile @a[distance=..32] ~ ~ ~ 1 0.5
execute on passengers run kill @s
tp @s ~ -1000 ~
kill @s
