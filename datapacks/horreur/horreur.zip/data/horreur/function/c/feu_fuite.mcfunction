particle minecraft:soul ~ ~ ~ 0.2 0.2 0.2 0.02 10
tp @s ~ ~ ~
playsound minecraft:block.amethyst_block.chime hostile @a[distance=..16] ~ ~ ~ 1 1.4
