particle minecraft:soul ~ ~ ~ 0.2 0.2 0.2 0.02 10
tp @s ~ ~ ~
playsound horreur:feu.crepitement hostile @a[distance=..16] ~ ~ ~ 1 1
