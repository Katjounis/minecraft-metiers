execute store result score #hp hr.tmp run data get entity @s Health
scoreboard players operation #hp hr.tmp *= #k100 hr.cfg
scoreboard players operation #hp hr.tmp /= @s hr.pv
