execute anchored eyes facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] eyes run particle minecraft:dust{color:[0.42,0.42,0.48],scale:1.1} ^ ^ ^1 0 0 0 0 1
execute anchored eyes facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] eyes run particle minecraft:dust{color:[0.42,0.42,0.48],scale:1.1} ^ ^ ^2 0 0 0 0 1
execute anchored eyes facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] eyes run particle minecraft:dust{color:[0.42,0.42,0.48],scale:1.1} ^ ^ ^3 0 0 0 0 1
execute anchored eyes facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] eyes run particle minecraft:dust{color:[0.42,0.42,0.48],scale:1.1} ^ ^ ^4 0 0 0 0 1
execute anchored eyes facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] eyes run particle minecraft:dust{color:[0.42,0.42,0.48],scale:1.1} ^ ^ ^5 0 0 0 0 1
execute anchored eyes facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] eyes run particle minecraft:dust{color:[0.42,0.42,0.48],scale:1.1} ^ ^ ^6 0 0 0 0 1
execute anchored eyes facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] eyes run particle minecraft:dust{color:[0.42,0.42,0.48],scale:1.1} ^ ^ ^7 0 0 0 0 1
execute anchored eyes facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] eyes run particle minecraft:dust{color:[0.42,0.42,0.48],scale:1.1} ^ ^ ^8 0 0 0 0 1
execute anchored eyes facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] eyes run particle minecraft:dust{color:[0.42,0.42,0.48],scale:1.1} ^ ^ ^9 0 0 0 0 1
execute anchored eyes facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] eyes run particle minecraft:dust{color:[0.42,0.42,0.48],scale:1.1} ^ ^ ^10 0 0 0 0 1
execute anchored eyes facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] eyes run particle minecraft:dust{color:[0.42,0.42,0.48],scale:1.1} ^ ^ ^11 0 0 0 0 1
execute anchored eyes facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] eyes run particle minecraft:dust{color:[0.42,0.42,0.48],scale:1.1} ^ ^ ^12 0 0 0 0 1
execute anchored eyes facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] eyes run particle minecraft:dust{color:[0.42,0.42,0.48],scale:1.1} ^ ^ ^13 0 0 0 0 1
execute anchored eyes facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] eyes run particle minecraft:dust{color:[0.42,0.42,0.48],scale:1.1} ^ ^ ^14 0 0 0 0 1
effect give @s minecraft:slowness 2 2 true
execute facing entity @e[tag=hr.c.pinhead,sort=nearest,limit=1] feet rotated ~ 0 positioned ^ ^ ^1.5 if block ~ ~ ~ #horreur:passable if block ~ ~1 ~ #horreur:passable run tp @s ~ ~ ~
