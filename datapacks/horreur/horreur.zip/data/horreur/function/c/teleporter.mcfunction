particle minecraft:portal ~ ~1.5 ~ 0.3 1 0.3 0.6 30
tp @s @e[type=minecraft:marker,tag=hr.pt2,limit=1]
execute at @s run rotate @s facing entity @p[gamemode=!spectator] feet
execute at @s run particle minecraft:portal ~ ~1.5 ~ 0.3 1 0.3 0.6 30
