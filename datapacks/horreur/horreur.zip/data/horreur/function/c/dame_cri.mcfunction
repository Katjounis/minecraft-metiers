scoreboard players add @s hr.t 5
execute if score @s hr.t matches ..39 run return 0
execute store result score #r hr.tmp run random value 1..2
execute if score #r hr.tmp matches 1 run return run function horreur:c/disparaitre
scoreboard players set @s hr.etat 2
attribute @s minecraft:movement_speed base set 0.33
playsound minecraft:entity.vex.charge hostile @a[distance=..32] ~ ~ ~ 2 0.5
