scoreboard players set @s hr.t 0
execute if score @s hr.etat matches 0 if entity @a[distance=..7,gamemode=!spectator] run return run function horreur:c/slender_reveil
execute if entity @a[distance=..20,gamemode=!spectator] run playsound horreur:slender.presence hostile @a[distance=..20] ~ ~ ~ 0.8 1
scoreboard players set #lim hr.tmp 10
scoreboard players set #h hr.tmp 3
summon minecraft:marker ~ ~ ~ {Tags:["hr.pt2"]}
execute facing entity @p[gamemode=!spectator] feet rotated ~ 0 positioned ^ ^ ^6 run tp @e[type=minecraft:marker,tag=hr.pt2,limit=1] ~ ~ ~
execute as @e[type=minecraft:marker,tag=hr.pt2,limit=1] at @s run function horreur:sol/trouver
execute if score #ok hr.tmp matches 1 run function horreur:c/teleporter
kill @e[type=minecraft:marker,tag=hr.pt2]
