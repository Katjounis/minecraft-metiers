execute store result score #r hr.tmp run random value 1..40
execute if score #r hr.tmp matches 1 run playsound minecraft:entity.vex.ambient hostile @a[distance=..20] ~ ~ ~ 1 0.5
execute if score #r hr.tmp matches 2 run playsound minecraft:ambient.cave hostile @a[distance=..20] ~ ~ ~ 0.8 1.2
