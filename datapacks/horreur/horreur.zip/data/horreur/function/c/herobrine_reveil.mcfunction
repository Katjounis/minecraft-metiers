scoreboard players set @s hr.etat 2
attribute @s minecraft:movement_speed base set 0.36
scoreboard players set #lim hr.tmp 4
scoreboard players set #h hr.tmp 2
summon minecraft:marker ~ ~ ~ {Tags:["hr.pt2"]}
execute as @p[gamemode=!spectator] at @s rotated ~180 0 positioned ^ ^ ^2 run tp @e[type=minecraft:marker,tag=hr.pt2,limit=1] ~ ~ ~
execute as @e[type=minecraft:marker,tag=hr.pt2,limit=1] at @s run function horreur:sol/trouver
execute if score #ok hr.tmp matches 1 run function horreur:c/teleporter
kill @e[type=minecraft:marker,tag=hr.pt2]
execute at @s run playsound horreur:herobrine.apparition hostile @a[distance=..32] ~ ~ ~ 1.5 1
execute at @s run effect give @a[distance=..6,gamemode=!spectator] minecraft:blindness 2 0 true
