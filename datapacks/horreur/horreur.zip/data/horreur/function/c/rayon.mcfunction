scoreboard players set #p hr.tmp 0
function horreur:c/rayon_pas
