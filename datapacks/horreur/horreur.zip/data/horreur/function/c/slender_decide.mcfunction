execute store result score #r hr.tmp run random value 1..2
execute if score #r hr.tmp matches 1 run return run function horreur:c/slender_reveil
function horreur:c/disparaitre
