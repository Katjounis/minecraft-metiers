scoreboard players set @s hr.ph 1
effect give @s minecraft:strength infinite 0 true
effect give @s minecraft:speed infinite 0 true
scoreboard players operation @s hr.scd *= #k2 hr.cfg
scoreboard players operation @s hr.scd /= #k3 hr.cfg
particle minecraft:large_smoke ~ ~2 ~ 1.5 2 1.5 0.05 120
playsound horreur:croque.grondement hostile @a[distance=..64] ~ ~ ~ 3 1
tellraw @a[distance=..96] {"text":"Le Croque-mitaine enrage !","color":"dark_red","bold":true}
