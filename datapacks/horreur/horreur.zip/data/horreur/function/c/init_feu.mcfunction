tag @s remove hr.neuf
scoreboard players set @s hr.vie 120
scoreboard players set @s hr.age 0
scoreboard players set @s hr.etat 0
scoreboard players set @s hr.t 0
scoreboard players set @s hr.r 0
playsound minecraft:block.amethyst_block.chime hostile @a[distance=..24] ~ ~ ~ 1 0.6
