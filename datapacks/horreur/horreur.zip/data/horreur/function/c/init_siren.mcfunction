tag @s remove hr.neuf
scoreboard players set @s hr.vie 120
scoreboard players set @s hr.age 0
scoreboard players set @s hr.s 0
scoreboard players set @s hr.au 0
scoreboard players set @s hr.ph 0
function horreur:rang/appliquer_siren
scoreboard players set @s hr.etat 0
scoreboard players set @s hr.t 0
scoreboard players set @s hr.r 0
function horreur:c/siren_cri
