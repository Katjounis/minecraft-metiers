# toutes les 5 ticks, en tant que créature : rang posé sur les joueurs proches (récompenses), ensorcellements, sorts
scoreboard players operation @a[distance=..48,gamemode=!spectator] hr.rgk = @s hr.rg
execute if entity @s[tag=hr.aura] run function horreur:sort/aura
execute if entity @s[tag=hr.rage,tag=!hr.enrage] run function horreur:sort/rage
execute unless entity @a[distance=..24,gamemode=!spectator] run return 0
execute if entity @s[tag=hr.c.slender] unless score @s hr.etat matches 2 run return 0
execute if entity @s[tag=hr.c.herobrine] unless score @s hr.etat matches 2 run return 0
execute if entity @s[tag=hr.c.dame] unless score @s hr.etat matches 2 run return 0
scoreboard players add @s hr.s 5
execute if score @s hr.s >= @s hr.scd run function horreur:sort/lancer
