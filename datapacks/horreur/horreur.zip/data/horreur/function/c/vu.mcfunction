tag @a remove hr.voit
scoreboard players set #vu hr.tmp 0
tag @s add hr.cible
execute as @a[distance=..64,gamemode=!spectator] at @s anchored eyes positioned ^ ^ ^1 run function horreur:c/rayon
tag @s remove hr.cible
