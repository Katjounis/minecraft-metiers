scoreboard players set @s hr.t 0
playsound horreur:pinhead.chaines hostile @a[distance=..24] ~ ~ ~ 1.5 1
execute as @a[distance=..16,gamemode=!spectator,limit=2,sort=nearest] at @s run function horreur:c/pinhead_tirer
