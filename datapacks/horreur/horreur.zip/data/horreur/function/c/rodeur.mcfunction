execute unless entity @a[distance=..48,gamemode=!spectator] run return 0
rotate @s facing entity @p[gamemode=!spectator] feet
function horreur:c/vu
execute unless score #vu hr.tmp matches 1 run scoreboard players set @s hr.r 0
execute if score #vu hr.tmp matches 1 run scoreboard players add @s hr.r 5
execute if score @s hr.r matches 10.. run function horreur:c/rodeur_cache
execute store result score #r hr.tmp run random value 1..30
execute if score #r hr.tmp matches 1 run playsound horreur:rodeur.pas hostile @a[distance=..12] ~ ~ ~ 0.7 1
