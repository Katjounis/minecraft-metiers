tag @s remove hr.neuf
scoreboard players set @s hr.vie 120
scoreboard players set @s hr.age 0
scoreboard players set @s hr.etat 0
scoreboard players set @s hr.t 0
scoreboard players set @s hr.r 0
playsound horreur:loup.hurlement hostile @a[distance=..96] ~ ~ ~ 3 1
