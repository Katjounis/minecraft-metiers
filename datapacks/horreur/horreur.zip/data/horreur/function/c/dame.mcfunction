particle minecraft:end_rod ~ ~1.2 ~ 0.3 0.8 0.3 0.01 2
execute if score @s hr.etat matches 2 run return 0
execute if score @s hr.etat matches 1 run return run function horreur:c/dame_cri
rotate @s facing entity @p[gamemode=!spectator] feet
execute if entity @a[distance=..10,gamemode=!spectator] run function horreur:c/dame_hurle
