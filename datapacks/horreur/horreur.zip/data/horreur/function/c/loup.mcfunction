execute store result score #r hr.tmp run random value 1..60
execute if score #r hr.tmp matches 1 run playsound minecraft:entity.wolf.howl hostile @a[distance=..96] ~ ~ ~ 3 0.6
execute if score #r hr.tmp matches 2 run playsound minecraft:entity.wolf.growl hostile @a[distance=..24] ~ ~ ~ 1.5 0.6
