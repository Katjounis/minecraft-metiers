scoreboard players set @s hr.etat 1
scoreboard players set @s hr.t 0
playsound minecraft:entity.ghast.scream hostile @a[distance=..48] ~ ~ ~ 2 0.5
effect give @a[distance=..16,gamemode=!spectator] minecraft:darkness 6 0 true
particle minecraft:sonic_boom ~ ~1.4 ~ 0 0 0 0 1
