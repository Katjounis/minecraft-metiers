execute if entity @e[tag=hr.cible,distance=..1.8] run return run function horreur:c/voit
execute positioned ~ ~-1.6 ~ if entity @e[tag=hr.cible,distance=..1.4] run return run function horreur:c/voit
execute unless block ~ ~ ~ #horreur:passable run return 0
scoreboard players add #p hr.tmp 1
execute if score #p hr.tmp matches ..63 positioned ^ ^ ^1 run function horreur:c/rayon_pas
