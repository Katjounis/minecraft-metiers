scoreboard players set @s hr.etat 1
playsound horreur:pinhead.cloche hostile @a[distance=..32] ~ ~ ~ 1.5 1.3
particle minecraft:soul ~ ~1 ~ 1 0.5 1 0.02 30
summon minecraft:zombie ~1.5 ~ ~0 {Tags:["hr.e","hr.serv"],PersistenceRequired:1b,CanPickUpLoot:0b,IsBaby:0b,CustomName:{"text":"Cénobite","color":"gray"},DeathLootTable:"minecraft:empty",attributes:[{id:"minecraft:spawn_reinforcements",base:0d},{id:"minecraft:movement_speed",base:0.26d}],equipment:{head:{id:"minecraft:chainmail_helmet",count:1},chest:{id:"minecraft:chainmail_chestplate",count:1},legs:{id:"minecraft:chainmail_leggings",count:1}},drop_chances:{head:0f,chest:0f,legs:0f}}
summon minecraft:zombie ~-1.5 ~ ~0 {Tags:["hr.e","hr.serv"],PersistenceRequired:1b,CanPickUpLoot:0b,IsBaby:0b,CustomName:{"text":"Cénobite","color":"gray"},DeathLootTable:"minecraft:empty",attributes:[{id:"minecraft:spawn_reinforcements",base:0d},{id:"minecraft:movement_speed",base:0.26d}],equipment:{head:{id:"minecraft:chainmail_helmet",count:1},chest:{id:"minecraft:chainmail_chestplate",count:1},legs:{id:"minecraft:chainmail_leggings",count:1}},drop_chances:{head:0f,chest:0f,legs:0f}}
scoreboard players set @e[tag=hr.serv,distance=..3] hr.age 0
