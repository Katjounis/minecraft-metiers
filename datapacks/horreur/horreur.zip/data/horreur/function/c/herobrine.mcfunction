execute unless entity @a[distance=..64,gamemode=!spectator] run return 0
execute if score @s hr.etat matches 2 run return 0
execute if entity @a[distance=..14,gamemode=!spectator] run return run function horreur:c/herobrine_decide
execute if entity @a[distance=..64,gamemode=!spectator,predicate=horreur:regarde/herobrine] run scoreboard players add @s hr.r 5
execute if score @s hr.r matches 60.. run function horreur:c/herobrine_decide
