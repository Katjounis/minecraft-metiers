scoreboard players set @s hr.r 0
particle minecraft:large_smoke ~ ~1 ~ 0.3 0.8 0.3 0.02 15
scoreboard players set #lim hr.tmp 4
scoreboard players set #h hr.tmp 2
summon minecraft:marker ~ ~ ~ {Tags:["hr.pt2"]}
execute as @p[gamemode=!spectator] at @s rotated ~180 0 positioned ^ ^ ^4 run tp @e[type=minecraft:marker,tag=hr.pt2,limit=1] ~ ~ ~
execute as @e[type=minecraft:marker,tag=hr.pt2,limit=1] at @s run function horreur:sol/trouver
execute if score #ok hr.tmp matches 1 run function horreur:c/teleporter
kill @e[type=minecraft:marker,tag=hr.pt2]
