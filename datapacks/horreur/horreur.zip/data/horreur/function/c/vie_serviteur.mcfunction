scoreboard players add @s hr.age 1
execute if score @s hr.age matches 90.. run function horreur:c/disparaitre
