particle minecraft:soul_fire_flame ~ ~0.5 ~ 0.15 0.15 0.15 0.01 3
execute if entity @a[distance=..5,gamemode=!spectator] store result score #r hr.tmp run random value 1..6
execute if entity @a[distance=..5,gamemode=!spectator] if score #r hr.tmp matches 1 facing entity @p[gamemode=!spectator] feet rotated ~180 0 positioned ^ ^1 ^6 run function horreur:c/feu_fuite
