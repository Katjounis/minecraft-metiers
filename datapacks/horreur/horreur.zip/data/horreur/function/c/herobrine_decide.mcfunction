execute store result score #r hr.tmp run random value 1..4
execute if score #r hr.tmp matches 1 run return run function horreur:c/herobrine_reveil
playsound horreur:herobrine.apparition hostile @a[distance=..48] ~ ~ ~ 1.5 1
function horreur:c/disparaitre
