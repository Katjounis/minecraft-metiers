scoreboard players set @s hr.t 0
playsound horreur:siren.sirene hostile @a[distance=..160] ~ ~6 ~ 10 1
