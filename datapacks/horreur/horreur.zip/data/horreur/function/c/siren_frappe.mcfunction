scoreboard players set @s hr.r 0
particle minecraft:explosion ~ ~0.5 ~ 2 0.2 2 0 6
playsound minecraft:entity.ravager.attack hostile @a[distance=..32] ~ ~ ~ 2 0.5
execute as @a[distance=..6.5,gamemode=!spectator] run damage @s 14 minecraft:mob_attack by @e[tag=hr.c.siren,sort=nearest,limit=1]
execute as @a[distance=..6.5,gamemode=!spectator] at @s facing entity @e[tag=hr.c.siren,sort=nearest,limit=1] feet rotated ~180 0 positioned ^ ^0.6 ^1.5 if block ~ ~ ~ #horreur:passable if block ~ ~1 ~ #horreur:passable run tp @s ~ ~ ~
effect give @a[distance=..6.5,gamemode=!spectator] minecraft:nausea 5 0 true
