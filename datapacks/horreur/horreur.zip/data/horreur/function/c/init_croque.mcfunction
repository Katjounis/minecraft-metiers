tag @s remove hr.neuf
scoreboard players set @s hr.vie 120
scoreboard players set @s hr.age 0
scoreboard players set @s hr.s 0
scoreboard players set @s hr.au 0
scoreboard players set @s hr.ph 0
function horreur:rang/appliquer_croque
scoreboard players set @s hr.etat 0
scoreboard players set @s hr.t 0
scoreboard players set @s hr.r 0
playsound horreur:croque.grondement hostile @a[distance=..64] ~ ~ ~ 2.5 1
bossbar set horreur:boss visible true
bossbar set horreur:boss players @a[distance=..96]
tellraw @a {"text":"Le Croque-mitaine est sorti de l'ombre...","color":"dark_red","bold":true}
