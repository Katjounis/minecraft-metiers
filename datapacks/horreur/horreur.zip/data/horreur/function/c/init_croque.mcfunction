tag @s remove hr.neuf
scoreboard players set @s hr.vie 120
scoreboard players set @s hr.age 0
scoreboard players set @s hr.etat 0
scoreboard players set @s hr.t 0
scoreboard players set @s hr.r 0
playsound minecraft:entity.warden.emerge hostile @a[distance=..64] ~ ~ ~ 2 0.7
bossbar set horreur:boss visible true
bossbar set horreur:boss players @a[distance=..96]
tellraw @a {"text":"Le Croque-mitaine est sorti de l'ombre...","color":"dark_red","bold":true}
