scoreboard players set @s hr.t 0
execute store result score #r hr.tmp run random value 1..3
execute if score #r hr.tmp matches 1 run function horreur:c/rodeur_cache
execute if score #r hr.tmp matches 1 run effect give @a[distance=..8,gamemode=!spectator] minecraft:blindness 2 0 true
execute if score #r hr.tmp matches 2 run summon minecraft:vex ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Ombre","color":"dark_gray"},DeathLootTable:"minecraft:empty",attributes:[{id:"minecraft:max_health",base:10d}],Health:10f}
execute if score #r hr.tmp matches 2 run summon minecraft:vex ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Ombre","color":"dark_gray"},DeathLootTable:"minecraft:empty",attributes:[{id:"minecraft:max_health",base:10d}],Health:10f}
execute if score #r hr.tmp matches 2 run tellraw @a[distance=..48] {"text":"Le Croque-mitaine appelle ses ombres !","color":"dark_red"}
execute if score #r hr.tmp matches 3 run effect give @a[distance=..24,gamemode=!spectator] minecraft:darkness 8 0 true
execute if score #r hr.tmp matches 3 run effect give @a[distance=..24,gamemode=!spectator] minecraft:slowness 4 1 true
execute if score #r hr.tmp matches 3 run playsound horreur:croque.grondement hostile @a[distance=..48] ~ ~ ~ 2.5 1
