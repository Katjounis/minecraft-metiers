scoreboard players add @s hr.r 5
execute if score @s hr.r matches 20 as @a[tag=hr.voit] run effect give @s minecraft:darkness 8 0 true
execute if score @s hr.r matches 20 as @a[tag=hr.voit] at @s run playsound horreur:slender.statique hostile @s ~ ~ ~ 0.8 1
execute if score @s hr.r matches 40 as @a[tag=hr.voit] at @s run playsound horreur:slender.statique hostile @s ~ ~ ~ 1 0.8
execute if score @s hr.r matches 40 as @a[tag=hr.voit] run effect give @s minecraft:nausea 8 0 true
execute if score @s hr.r matches 60.. run function horreur:c/slender_decide
