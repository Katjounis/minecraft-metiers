# vitesse : il accélère quand personne n'est près de lui (on le fuit), ralentit au contact
execute if entity @a[distance=..12,gamemode=!spectator] run attribute @s minecraft:movement_speed base set 0.26
execute unless entity @a[distance=..12,gamemode=!spectator] run attribute @s minecraft:movement_speed base set 0.34
# frappe : son attaque de zombie géant porte mal, il écrase tout autour de lui toutes les 2 s
scoreboard players add @s hr.r 5
execute if score @s hr.r matches 40.. if entity @a[distance=..6.5,gamemode=!spectator] run function horreur:c/siren_frappe
scoreboard players add @s hr.t 5
execute store result score #r hr.tmp run random value 1..30
execute if score #r hr.tmp matches 1 if entity @a[distance=..32,gamemode=!spectator] run playsound horreur:siren.voix hostile @a[distance=..40] ~ ~6 ~ 2.5 1
execute if score @s hr.t matches 120.. run function horreur:c/siren_cri
