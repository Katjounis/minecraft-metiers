scoreboard players add @s hr.t 5
execute store result score #r hr.tmp run random value 1..30
execute if score #r hr.tmp matches 1 if entity @a[distance=..32,gamemode=!spectator] run playsound horreur:siren.voix hostile @a[distance=..40] ~ ~6 ~ 2.5 1
execute if score @s hr.t matches 120.. run function horreur:c/siren_cri
