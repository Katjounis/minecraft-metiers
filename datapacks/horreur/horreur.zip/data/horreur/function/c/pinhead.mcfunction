scoreboard players add @s hr.t 5
execute if score @s hr.t matches 80.. if entity @a[distance=..16,gamemode=!spectator] run function horreur:c/pinhead_chaines
execute if score @s hr.etat matches 0 store result score #hp hr.tmp run data get entity @s Health
execute if score @s hr.etat matches 0 if score #hp hr.tmp matches ..60 run function horreur:c/pinhead_cenobites
