scoreboard players add @s hr.t 5
execute if score @s hr.t matches 80.. if entity @a[distance=..16,gamemode=!spectator] run function horreur:c/pinhead_chaines
execute if score @s hr.etat matches 0 store result score #hp hr.tmp run data get entity @s Health
# 26/11/2026 : seuil en pourcentage de la vie max (la vie dépend du rang)
execute if score @s hr.etat matches 0 run function horreur:c/pct
execute if score @s hr.etat matches 0 if score #hp hr.tmp matches ..50 run function horreur:c/pinhead_cenobites
