scoreboard players operation @s hr.cw = #cw hr.cfg
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.ecus 1000
tellraw @a [{"text":"[Bestiaire] ","color":"dark_red"},{"selector":"@s","color":"white"},{"text":" remplit le contrat de la semaine : ","color":"gray"},{"text":"La Dame blanche","color":"#f4f4ff","bold":true},{"text":" (+1250 Écus)","color":"gold"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
