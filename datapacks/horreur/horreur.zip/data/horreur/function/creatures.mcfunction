# Apparences : une statue sans son mob est retiree, et suit la rotation de son mob
tag @e[type=item_display,tag=hr.vis] remove hr.ok
execute as @e[tag=hr.c] on passengers run tag @s add hr.ok
execute as @e[type=item_display,tag=hr.vis,tag=!hr.ok] at @s run function horreur:vis/orphelin
execute as @e[type=item_display,tag=hr.envol] at @s run function horreur:vis/envol
execute as @e[tag=hr.statue] run function horreur:vis/tourner
# Comportements toutes les 5 ticks
scoreboard players add #t5 hr.tmp 1
execute if score #t5 hr.tmp matches 5.. run scoreboard players set #t5 hr.tmp 0
execute if score #t5 hr.tmp matches 0 as @e[tag=hr.c] at @s run function horreur:c/comportement
