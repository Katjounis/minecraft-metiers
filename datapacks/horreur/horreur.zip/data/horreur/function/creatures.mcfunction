# Apparences : une statue sans son mob est retiree, et suit la rotation de son mob
tag @e[type=item_display,tag=hr.vis] remove hr.ok
execute as @e[tag=hr.c] on passengers run tag @s add hr.ok
execute as @e[type=item_display,tag=hr.vis,tag=!hr.ok] at @s run function horreur:vis/orphelin
execute as @e[type=item_display,tag=hr.envol] at @s run function horreur:vis/envol
execute as @e[tag=hr.statue] run function horreur:vis/tourner
execute as @e[tag=hr.c] run function horreur:rig/tick
# Statues animees : 4 poses par cycle de 4 s, le jeu interpole entre elles (balancement, respiration, rotation)
scoreboard players add #anim hr.tmp 1
execute if score #anim hr.tmp matches 80.. run scoreboard players set #anim hr.tmp 0
execute if score #anim hr.tmp matches 0 run function horreur:vis/anim_0
execute if score #anim hr.tmp matches 20 run function horreur:vis/anim_1
execute if score #anim hr.tmp matches 40 run function horreur:vis/anim_2
execute if score #anim hr.tmp matches 60 run function horreur:vis/anim_3
# Comportements toutes les 5 ticks
scoreboard players add #t5 hr.tmp 1
execute if score #t5 hr.tmp matches 5.. run scoreboard players set #t5 hr.tmp 0
execute if score #t5 hr.tmp matches 0 as @e[tag=hr.c] at @s run function horreur:c/comportement
execute if score #t5 hr.tmp matches 0 as @e[type=minecraft:marker,tag=hr.zone] at @s run function horreur:zone/tick
