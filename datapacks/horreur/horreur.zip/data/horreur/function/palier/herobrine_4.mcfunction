tellraw @a [{"text":"[Bestiaire] ","color":"dark_red"},{"selector":"@s","color":"gold"},{"text":" a vaincu 100 fois ","color":"gray"},{"text":"Herobrine","color":"#ffffff","bold":true},{"text":" et reçoit une prime de 5 000 Écus !","color":"gold"}]
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.ecus 5000
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.a_hor 5000
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 0.5
