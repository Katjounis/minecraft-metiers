tellraw @a [{"text":"[Bestiaire] ","color":"dark_red"},{"selector":"@s","color":"gold"},{"text":" a vaincu 50 fois ","color":"gray"},{"text":"Le Loup-garou","color":"#7a6a58","bold":true},{"text":" et devient « Chasseur de pleine lune » !","color":"gold"}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 0.6
