tellraw @a [{"text":"[Bestiaire] ","color":"dark_red"},{"selector":"@s","color":"gold"},{"text":" a vaincu 50 fois ","color":"gray"},{"text":"Siren Head","color":"#a08a6a","bold":true},{"text":" et devient « Tueur de géants » !","color":"gold"}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 0.6
