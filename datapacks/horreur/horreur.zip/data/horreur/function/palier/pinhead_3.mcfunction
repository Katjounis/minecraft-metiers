tellraw @a [{"text":"[Bestiaire] ","color":"dark_red"},{"selector":"@s","color":"gold"},{"text":" a vaincu 50 fois ","color":"gray"},{"text":"Pinhead","color":"#9a9aa8","bold":true},{"text":" et devient « Celui qui a résolu la boîte » !","color":"gold"}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 0.6
