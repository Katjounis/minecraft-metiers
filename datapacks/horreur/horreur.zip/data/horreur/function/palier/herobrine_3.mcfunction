tellraw @a [{"text":"[Bestiaire] ","color":"dark_red"},{"selector":"@s","color":"gold"},{"text":" a vaincu 50 fois ","color":"gray"},{"text":"Herobrine","color":"#ffffff","bold":true},{"text":" et devient « Chasseur de légendes » !","color":"gold"}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 0.6
