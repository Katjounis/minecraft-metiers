tellraw @a [{"text":"[Bestiaire] ","color":"dark_red"},{"selector":"@s","color":"gold"},{"text":" a vaincu 50 fois ","color":"gray"},{"text":"SlenderMan","color":"#c8c8c8","bold":true},{"text":" et devient « Celui qui ne détourne pas les yeux » !","color":"gold"}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 0.6
