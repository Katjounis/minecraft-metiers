tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"10 victoires contre ","color":"gray"},{"text":"Le Croque-mitaine","color":"#5a1020","bold":true},{"text":" : +25 cristaux dans chaque métier !","color":"aqua"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 0.7
execute if score @s m.cr_b matches -2147483648.. run scoreboard players add @s m.cr_b 25
execute if score @s m.cr_f matches -2147483648.. run scoreboard players add @s m.cr_f 25
execute if score @s m.cr_m matches -2147483648.. run scoreboard players add @s m.cr_m 25
execute if score @s m.cr_c matches -2147483648.. run scoreboard players add @s m.cr_c 25
execute if score @s m.cr_p matches -2147483648.. run scoreboard players add @s m.cr_p 25
execute if score @s m.cr_e matches -2147483648.. run scoreboard players add @s m.cr_e 25
execute if score @s m.cr_n matches -2147483648.. run scoreboard players add @s m.cr_n 25
execute if score @s m.cr_x matches -2147483648.. run scoreboard players add @s m.cr_x 25
execute if score @s m.cr_t matches -2147483648.. run scoreboard players add @s m.cr_t 25
execute if score @s m.cr_k matches -2147483648.. run scoreboard players add @s m.cr_k 25
