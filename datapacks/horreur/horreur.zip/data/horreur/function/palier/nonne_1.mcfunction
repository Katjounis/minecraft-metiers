tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"Nouvelle créature découverte : ","color":"gray"},{"text":"La Nonne","color":"#d0c8a0","bold":true},{"text":" ! (touche G ou /trigger bestiaire)","color":"gray"}]
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 0.8
xp add @s 50 points
