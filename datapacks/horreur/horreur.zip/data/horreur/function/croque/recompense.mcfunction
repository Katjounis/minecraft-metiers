scoreboard players set #m hr.tmp 0
scoreboard players operation #m hr.tmp = @s hr.rgk
scoreboard players operation #m hr.tmp *= #k15 hr.cfg
scoreboard players add #m hr.tmp 100
scoreboard players set #cr hr.tmp 10
scoreboard players operation #cr hr.tmp *= #m hr.tmp
scoreboard players operation #cr hr.tmp /= #k100 hr.cfg
execute if score @s m.cr_b matches -2147483648.. run scoreboard players operation @s m.cr_b += #cr hr.tmp
execute if score @s m.cr_f matches -2147483648.. run scoreboard players operation @s m.cr_f += #cr hr.tmp
execute if score @s m.cr_m matches -2147483648.. run scoreboard players operation @s m.cr_m += #cr hr.tmp
execute if score @s m.cr_c matches -2147483648.. run scoreboard players operation @s m.cr_c += #cr hr.tmp
execute if score @s m.cr_p matches -2147483648.. run scoreboard players operation @s m.cr_p += #cr hr.tmp
execute if score @s m.cr_e matches -2147483648.. run scoreboard players operation @s m.cr_e += #cr hr.tmp
execute if score @s m.cr_n matches -2147483648.. run scoreboard players operation @s m.cr_n += #cr hr.tmp
execute if score @s m.cr_x matches -2147483648.. run scoreboard players operation @s m.cr_x += #cr hr.tmp
execute if score @s m.cr_t matches -2147483648.. run scoreboard players operation @s m.cr_t += #cr hr.tmp
execute if score @s m.cr_k matches -2147483648.. run scoreboard players operation @s m.cr_k += #cr hr.tmp
xp add @s 300 points
execute if entity @s[tag=hr.tueur] run return run function horreur:croque/message
scoreboard players set #pr hr.tmp 10000
execute if score #sang hr.cfg matches 1 run scoreboard players operation #pr hr.tmp += #pr hr.tmp
scoreboard players operation #pr hr.tmp *= #m hr.tmp
scoreboard players operation #pr hr.tmp /= #k100 hr.cfg
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus += #pr hr.tmp
scoreboard players set #x hr.tmp 300
scoreboard players operation #x hr.tmp *= #m hr.tmp
scoreboard players operation #x hr.tmp /= #k100 hr.cfg
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players operation @s m.c_bal += #x hr.tmp
function horreur:croque/message
