tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"Croque-mitaine vaincu : +","color":"gold"},{"score":{"name":"#cr","objective":"hr.tmp"},"color":"aqua"},{"text":" cristaux dans chaque métier, de l'XP","color":"aqua"},{"text":" et la prime en Écus.","color":"gold"}]
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.4 60
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.7
