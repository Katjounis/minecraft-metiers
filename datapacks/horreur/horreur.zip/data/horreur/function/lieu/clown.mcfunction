execute if predicate horreur:lieu/sous_terre run return 1
return fail
