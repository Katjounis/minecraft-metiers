execute if predicate horreur:lieu/grotte run return 1
return fail
