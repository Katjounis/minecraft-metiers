execute if score #nuit hr.tmp matches 1 if predicate horreur:pleine_lune if predicate horreur:lieu/surface run return 1
return fail
