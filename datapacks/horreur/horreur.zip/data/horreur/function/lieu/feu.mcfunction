execute if score #nuit hr.tmp matches 1 if predicate horreur:lieu/marais run return 1
return fail
