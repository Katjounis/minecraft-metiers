execute if predicate horreur:lieu/nether run return 1
execute if score #nuit hr.tmp matches 1 if predicate horreur:lieu/surface run return 1
return fail
