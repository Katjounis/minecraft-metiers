execute if entity @s[tag=hr.complet] run return 0
execute unless score @s hr.k.slender matches 1.. run return 0
execute unless score @s hr.k.herobrine matches 1.. run return 0
execute unless score @s hr.k.siren matches 1.. run return 0
execute unless score @s hr.k.nonne matches 1.. run return 0
execute unless score @s hr.k.clown matches 1.. run return 0
execute unless score @s hr.k.pinhead matches 1.. run return 0
execute unless score @s hr.k.dame matches 1.. run return 0
execute unless score @s hr.k.loup matches 1.. run return 0
execute unless score @s hr.k.feu matches 1.. run return 0
execute unless score @s hr.k.rodeur matches 1.. run return 0
tag @s add hr.complet
tellraw @a [{"text":"[Bestiaire] ","color":"dark_red"},{"selector":"@s","color":"gold","bold":true},{"text":" a complété le bestiaire et devient « Chasseur de mythes » !","color":"gold"}]
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.ecus 20000
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.a_hor 20000
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.6
