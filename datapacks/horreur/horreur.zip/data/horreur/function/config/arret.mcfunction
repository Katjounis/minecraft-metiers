scoreboard players set #actif hr.cfg 0
tellraw @s {"text":"[Horreur] Apparitions désactivées (horreur:config/marche pour relancer).","color":"gray"}
