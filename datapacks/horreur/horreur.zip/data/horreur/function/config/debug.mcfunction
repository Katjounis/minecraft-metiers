# Test : apparitions tres frequentes (toutes les 30 s, sans delai). Revenir avec horreur:config/defaut
scoreboard players set #ch_slender hr.cfg 500
scoreboard players set #ch_herobrine hr.cfg 500
scoreboard players set #ch_siren hr.cfg 500
scoreboard players set #ch_nonne hr.cfg 500
scoreboard players set #ch_clown hr.cfg 500
scoreboard players set #ch_pinhead hr.cfg 500
scoreboard players set #cd hr.cfg 0
scoreboard players set @a hr.cd 0
tellraw @s {"text":"[Horreur] Mode test : apparitions très fréquentes.","color":"red"}
