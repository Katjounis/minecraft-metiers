scoreboard players set #actif hr.cfg 1
tellraw @s {"text":"[Horreur] Apparitions activées.","color":"gray"}
