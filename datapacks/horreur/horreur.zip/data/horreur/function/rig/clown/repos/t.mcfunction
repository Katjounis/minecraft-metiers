execute if score @s hr.af matches 22 run function horreur:rig/clown/repos/k1
execute if score @s hr.af matches 44.. run scoreboard players set @s hr.af 0
execute if score @s hr.af matches 0 run function horreur:rig/clown/repos/k0
