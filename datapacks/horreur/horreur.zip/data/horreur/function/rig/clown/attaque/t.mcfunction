execute if score @s hr.af matches 5 run function horreur:rig/clown/attaque/k1
execute if score @s hr.af matches 8 run function horreur:rig/clown/attaque/k2
execute if score @s hr.af matches 18.. run function horreur:rig/clown/jouer_repos
