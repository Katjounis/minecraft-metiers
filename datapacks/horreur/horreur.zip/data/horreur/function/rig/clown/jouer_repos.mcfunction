scoreboard players set @s hr.an 1
scoreboard players set @s hr.af 0
function horreur:rig/clown/repos/k0
