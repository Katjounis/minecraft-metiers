execute if score @s hr.af matches 8 run function horreur:rig/loup/marche/k1
execute if score @s hr.af matches 12 run function horreur:rig/loup/marche/k2
execute if score @s hr.af matches 20 run function horreur:rig/loup/marche/k3
execute if score @s hr.af matches 24.. run scoreboard players set @s hr.af 0
execute if score @s hr.af matches 0 run function horreur:rig/loup/marche/k0
