execute if score @s hr.af matches 26 run function horreur:rig/loup/repos/k1
execute if score @s hr.af matches 52.. run scoreboard players set @s hr.af 0
execute if score @s hr.af matches 0 run function horreur:rig/loup/repos/k0
