execute if score @s hr.af matches 5 run function horreur:rig/herobrine/attaque/k1
execute if score @s hr.af matches 8 run function horreur:rig/herobrine/attaque/k2
execute if score @s hr.af matches 16.. run function horreur:rig/herobrine/jouer_repos
