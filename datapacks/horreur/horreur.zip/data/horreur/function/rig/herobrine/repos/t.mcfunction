execute if score @s hr.af matches 30 run function horreur:rig/herobrine/repos/k1
execute if score @s hr.af matches 60.. run scoreboard players set @s hr.af 0
execute if score @s hr.af matches 0 run function horreur:rig/herobrine/repos/k0
