scoreboard players set @s hr.an 3
scoreboard players set @s hr.af 0
function horreur:rig/slender/attaque/k0
