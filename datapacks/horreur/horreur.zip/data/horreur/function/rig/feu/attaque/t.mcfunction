execute if score @s hr.af matches 4 run function horreur:rig/feu/attaque/k1
execute if score @s hr.af matches 10 run function horreur:rig/feu/attaque/k2
execute if score @s hr.af matches 16.. run function horreur:rig/feu/jouer_repos
