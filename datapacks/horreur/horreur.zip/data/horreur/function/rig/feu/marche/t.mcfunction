execute if score @s hr.af matches 10 run function horreur:rig/feu/marche/k1
execute if score @s hr.af matches 20 run function horreur:rig/feu/marche/k2
execute if score @s hr.af matches 30 run function horreur:rig/feu/marche/k3
execute if score @s hr.af matches 40.. run scoreboard players set @s hr.af 0
execute if score @s hr.af matches 0 run function horreur:rig/feu/marche/k0
