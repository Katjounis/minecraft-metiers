execute if score @s hr.af matches 6 run function horreur:rig/pinhead/attaque/k1
execute if score @s hr.af matches 10 run function horreur:rig/pinhead/attaque/k2
execute if score @s hr.af matches 20.. run function horreur:rig/pinhead/jouer_repos
