execute if score @s hr.an matches 3 run return 0
execute if predicate horreur:bouge unless score @s hr.an matches 2 run function horreur:rig/dame/jouer_marche
execute unless predicate horreur:bouge unless score @s hr.an matches 1 run function horreur:rig/dame/jouer_repos
scoreboard players add @s hr.af 1
execute if score @s hr.an matches 1 run function horreur:rig/dame/repos/t
execute if score @s hr.an matches 2 run function horreur:rig/dame/marche/t
execute if score @s hr.an matches 3 run function horreur:rig/dame/attaque/t
