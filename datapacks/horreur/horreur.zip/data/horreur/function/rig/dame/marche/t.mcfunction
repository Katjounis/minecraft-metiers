execute if score @s hr.af matches 10 run function horreur:rig/dame/marche/k1
execute if score @s hr.af matches 20.. run scoreboard players set @s hr.af 0
execute if score @s hr.af matches 0 run function horreur:rig/dame/marche/k0
