execute if score @s hr.af matches 6 run function horreur:rig/dame/attaque/k1
execute if score @s hr.af matches 10 run function horreur:rig/dame/attaque/k2
execute if score @s hr.af matches 22.. run function horreur:rig/dame/jouer_repos
