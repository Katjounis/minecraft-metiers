scoreboard players set @s hr.an 2
scoreboard players set @s hr.af 0
function horreur:rig/dame/marche/k0
