execute if score @s hr.af matches 24 run function horreur:rig/dame/repos/k1
execute if score @s hr.af matches 48.. run scoreboard players set @s hr.af 0
execute if score @s hr.af matches 0 run function horreur:rig/dame/repos/k0
