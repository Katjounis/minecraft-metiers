execute if score @s hr.af matches 20 run function horreur:rig/nonne/repos/k1
execute if score @s hr.af matches 40.. run scoreboard players set @s hr.af 0
execute if score @s hr.af matches 0 run function horreur:rig/nonne/repos/k0
