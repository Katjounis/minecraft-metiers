execute if score @s hr.af matches 5 run function horreur:rig/nonne/attaque/k1
execute if score @s hr.af matches 9 run function horreur:rig/nonne/attaque/k2
execute if score @s hr.af matches 19.. run function horreur:rig/nonne/jouer_repos
