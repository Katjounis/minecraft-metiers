execute if score @s hr.af matches 6 run function horreur:rig/croque/attaque/k1
execute if score @s hr.af matches 10 run function horreur:rig/croque/attaque/k2
execute if score @s hr.af matches 22.. run function horreur:rig/croque/jouer_repos
