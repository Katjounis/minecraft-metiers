execute unless score @s hr.an matches 3 if predicate horreur:bouge unless score @s hr.an matches 2 run function horreur:rig/croque/jouer_marche
execute unless score @s hr.an matches 3 unless predicate horreur:bouge unless score @s hr.an matches 1 run function horreur:rig/croque/jouer_repos
scoreboard players add @s hr.af 1
execute if score @s hr.an matches 1 run function horreur:rig/croque/repos/t
execute if score @s hr.an matches 2 run function horreur:rig/croque/marche/t
execute if score @s hr.an matches 3 run function horreur:rig/croque/attaque/t
