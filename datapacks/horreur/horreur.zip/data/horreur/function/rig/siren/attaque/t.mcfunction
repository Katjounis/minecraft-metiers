execute if score @s hr.af matches 8 run function horreur:rig/siren/attaque/k1
execute if score @s hr.af matches 12 run function horreur:rig/siren/attaque/k2
execute if score @s hr.af matches 24.. run function horreur:rig/siren/jouer_repos
