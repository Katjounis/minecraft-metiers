execute if score @s hr.af matches 40 run function horreur:rig/siren/repos/k1
execute if score @s hr.af matches 80.. run scoreboard players set @s hr.af 0
execute if score @s hr.af matches 0 run function horreur:rig/siren/repos/k0
