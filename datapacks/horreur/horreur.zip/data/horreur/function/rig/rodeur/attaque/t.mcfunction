execute if score @s hr.af matches 4 run function horreur:rig/rodeur/attaque/k1
execute if score @s hr.af matches 7 run function horreur:rig/rodeur/attaque/k2
execute if score @s hr.af matches 15.. run function horreur:rig/rodeur/jouer_repos
