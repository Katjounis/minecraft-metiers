execute unless score @s hr.an matches 3 if predicate horreur:bouge unless score @s hr.an matches 2 run function horreur:rig/rodeur/jouer_marche
execute unless score @s hr.an matches 3 unless predicate horreur:bouge unless score @s hr.an matches 1 run function horreur:rig/rodeur/jouer_repos
scoreboard players add @s hr.af 1
execute if score @s hr.an matches 1 run function horreur:rig/rodeur/repos/t
execute if score @s hr.an matches 2 run function horreur:rig/rodeur/marche/t
execute if score @s hr.an matches 3 run function horreur:rig/rodeur/attaque/t
