execute as @a[scores={bestiaire=1..}] run function horreur:ui/trigger
execute if entity @e[tag=hr.e,limit=1] run function horreur:creatures
