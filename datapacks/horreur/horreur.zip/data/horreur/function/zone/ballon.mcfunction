execute if score @s hr.t matches 1.. run return run function horreur:zone/ballon_annonce
function horreur:zone/ballon_coup
kill @s
