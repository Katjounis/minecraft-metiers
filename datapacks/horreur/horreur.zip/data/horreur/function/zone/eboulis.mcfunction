execute if score @s hr.t matches 1.. run return run function horreur:zone/eboulis_annonce
function horreur:zone/eboulis_coup
kill @s
