particle minecraft:large_smoke ~ ~0.5 ~ 1.5 0.4 1.5 0.02 60
playsound horreur:croque.grondement hostile @a[distance=..32] ~ ~ ~ 1.5 1
scoreboard players set #d hr.tmp 8
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:magic"
execute as @a[distance=..3.5,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
effect give @a[distance=..3.5,gamemode=!spectator] minecraft:wither 4 1 true
