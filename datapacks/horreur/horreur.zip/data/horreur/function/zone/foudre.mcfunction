execute if score @s hr.t matches 1.. run return run function horreur:zone/foudre_annonce
function horreur:zone/foudre_coup
kill @s
