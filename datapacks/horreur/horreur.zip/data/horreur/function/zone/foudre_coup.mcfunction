particle minecraft:end_rod ~ ~4 ~ 0.1 4 0.1 0 60
particle minecraft:explosion ~ ~0.5 ~ 0.5 0.2 0.5 0 3
playsound minecraft:entity.lightning_bolt.thunder hostile @a[distance=..48] ~ ~ ~ 1.5 1.2
playsound minecraft:entity.lightning_bolt.impact hostile @a[distance=..16] ~ ~ ~ 2 1
scoreboard players set #d hr.tmp 7
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:lightning_bolt"
execute as @a[distance=..2.5,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
effect give @a[distance=..2.5,gamemode=!spectator] minecraft:slowness 2 1 true
