particle minecraft:crit ~ ~1 ~ 0.6 1 0.6 0.4 30
playsound horreur:pinhead.chaines hostile @a[distance=..24] ~ ~ ~ 1.5 1
scoreboard players set #d hr.tmp 6
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:mob_attack"
execute as @a[distance=..2,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
effect give @a[distance=..2,gamemode=!spectator] minecraft:wither 3 1 true
effect give @a[distance=..2,gamemode=!spectator] minecraft:slowness 3 3 true
