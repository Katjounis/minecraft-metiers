execute if score @s hr.t matches 1.. run return run function horreur:zone/crochet_annonce
function horreur:zone/crochet_coup
kill @s
