particle minecraft:block{block_state:"minecraft:gravel"} ~ ~1.5 ~ 1 1 1 0 60
playsound minecraft:block.gravel.break hostile @a[distance=..24] ~ ~ ~ 2 0.5
scoreboard players set #d hr.tmp 6
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:falling_block"
execute as @a[distance=..2,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
effect give @a[distance=..2,gamemode=!spectator] minecraft:mining_fatigue 6 1 true
