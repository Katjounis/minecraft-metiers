execute if score @s hr.t matches 1.. run return run function horreur:zone/cauchemar_annonce
function horreur:zone/cauchemar_coup
kill @s
