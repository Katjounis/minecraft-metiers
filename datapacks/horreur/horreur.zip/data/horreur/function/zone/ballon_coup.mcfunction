particle minecraft:explosion ~ ~0.5 ~ 0.8 0.3 0.8 0 4
playsound minecraft:entity.generic.explode hostile @a[distance=..24] ~ ~ ~ 1 1.4
playsound minecraft:entity.witch.celebrate hostile @a[distance=..24] ~ ~ ~ 1 1.6
scoreboard players set #d hr.tmp 6
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:explosion"
execute as @a[distance=..2.5,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
