scoreboard players remove @s hr.t 5
execute if entity @s[tag=hr.z.foudre] run return run function horreur:zone/foudre
execute if entity @s[tag=hr.z.ballon] run return run function horreur:zone/ballon
execute if entity @s[tag=hr.z.crochet] run return run function horreur:zone/crochet
execute if entity @s[tag=hr.z.eboulis] run return run function horreur:zone/eboulis
execute if entity @s[tag=hr.z.cauchemar] run return run function horreur:zone/cauchemar
kill @s
