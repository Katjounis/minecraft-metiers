# /function horreur:desinstaller  puis  /datapack disable "file/horreur.zip"
execute as @e[tag=hr.e] run tp @s ~ -1000 ~
kill @e[tag=hr.e]
schedule clear horreur:seconde
scoreboard objectives remove hr.tmp
scoreboard objectives remove hr.cfg
scoreboard objectives remove hr.cd
scoreboard objectives remove hr.vie
scoreboard objectives remove hr.age
scoreboard objectives remove hr.etat
scoreboard objectives remove hr.t
scoreboard objectives remove hr.r
scoreboard objectives remove hr.k.slender
scoreboard objectives remove hr.k.herobrine
scoreboard objectives remove hr.k.siren
scoreboard objectives remove hr.k.nonne
scoreboard objectives remove hr.k.clown
scoreboard objectives remove hr.k.pinhead
scoreboard objectives remove bestiaire
data remove storage horreur:t s
data remove storage horreur:t r
data remove storage horreur:ui m
data remove storage horreur:ui f
tellraw @s {"text":"[Horreur] Désinstallé. Désactive maintenant le pack : /datapack disable \"file/horreur.zip\"","color":"gray"}
