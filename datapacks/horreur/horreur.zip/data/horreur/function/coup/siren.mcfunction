advancement revoke @s only horreur:coup/siren
execute as @e[tag=hr.c.siren,sort=nearest,limit=1] run function horreur:rig/siren/jouer_attaque
execute as @e[tag=hr.c.siren,tag=hr.vamp,sort=nearest,limit=1] at @s run function horreur:sort/vampire
effect give @s minecraft:nausea 5 0 true
