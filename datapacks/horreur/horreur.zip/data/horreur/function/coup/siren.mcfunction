advancement revoke @s only horreur:coup/siren
effect give @s minecraft:nausea 5 0 true
