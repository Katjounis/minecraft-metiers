advancement revoke @s only horreur:coup/siren
execute as @e[tag=hr.c.siren,sort=nearest,limit=1] run function horreur:rig/siren/jouer_attaque
effect give @s minecraft:nausea 5 0 true
