advancement revoke @s only horreur:coup/pinhead
execute as @e[tag=hr.c.pinhead,sort=nearest,limit=1] run function horreur:rig/pinhead/jouer_attaque
execute as @e[tag=hr.c.pinhead,tag=hr.vamp,sort=nearest,limit=1] at @s run function horreur:sort/vampire
effect give @s minecraft:slowness 2 1 true
