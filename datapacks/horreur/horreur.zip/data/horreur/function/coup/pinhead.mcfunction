advancement revoke @s only horreur:coup/pinhead
effect give @s minecraft:slowness 2 1 true
