advancement revoke @s only horreur:coup/pinhead
execute as @e[tag=hr.c.pinhead,sort=nearest,limit=1] run function horreur:rig/pinhead/jouer_attaque
effect give @s minecraft:slowness 2 1 true
