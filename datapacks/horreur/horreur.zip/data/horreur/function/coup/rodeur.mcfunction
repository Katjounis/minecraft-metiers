advancement revoke @s only horreur:coup/rodeur
effect give @s minecraft:blindness 1 0 true
