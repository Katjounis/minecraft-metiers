advancement revoke @s only horreur:coup/rodeur
execute as @e[tag=hr.c.rodeur,sort=nearest,limit=1] run function horreur:rig/rodeur/jouer_attaque
effect give @s minecraft:blindness 1 0 true
