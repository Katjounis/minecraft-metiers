advancement revoke @s only horreur:coup/loup
effect give @s minecraft:wither 3 0 true
