advancement revoke @s only horreur:coup/loup
execute as @e[tag=hr.c.loup,sort=nearest,limit=1] run function horreur:rig/loup/jouer_attaque
execute as @e[tag=hr.c.loup,tag=hr.vamp,sort=nearest,limit=1] at @s run function horreur:sort/vampire
effect give @s minecraft:wither 3 0 true
