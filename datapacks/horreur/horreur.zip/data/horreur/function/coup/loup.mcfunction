advancement revoke @s only horreur:coup/loup
execute as @e[tag=hr.c.loup,sort=nearest,limit=1] run function horreur:rig/loup/jouer_attaque
effect give @s minecraft:wither 3 0 true
