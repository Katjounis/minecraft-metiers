advancement revoke @s only horreur:coup/croque
execute as @e[tag=hr.c.croque,sort=nearest,limit=1] run function horreur:rig/croque/jouer_attaque
execute as @e[tag=hr.c.croque,tag=hr.vamp,sort=nearest,limit=1] at @s run function horreur:sort/vampire
effect give @s minecraft:darkness 4 0 true
effect give @s minecraft:slowness 2 1 true
