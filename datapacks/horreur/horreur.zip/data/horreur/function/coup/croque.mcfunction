advancement revoke @s only horreur:coup/croque
effect give @s minecraft:darkness 4 0 true
effect give @s minecraft:slowness 2 1 true
