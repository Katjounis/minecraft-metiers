advancement revoke @s only horreur:coup/croque
execute as @e[tag=hr.c.croque,sort=nearest,limit=1] run function horreur:rig/croque/jouer_attaque
effect give @s minecraft:darkness 4 0 true
effect give @s minecraft:slowness 2 1 true
