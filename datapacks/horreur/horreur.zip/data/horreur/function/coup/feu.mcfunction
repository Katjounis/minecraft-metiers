advancement revoke @s only horreur:coup/feu
effect give @s minecraft:slowness 3 1 true
effect give @s minecraft:mining_fatigue 4 0 true
