advancement revoke @s only horreur:coup/feu
execute as @e[tag=hr.c.feu,sort=nearest,limit=1] run function horreur:rig/feu/jouer_attaque
effect give @s minecraft:slowness 3 1 true
effect give @s minecraft:mining_fatigue 4 0 true
