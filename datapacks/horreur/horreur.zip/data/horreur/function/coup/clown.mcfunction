advancement revoke @s only horreur:coup/clown
execute as @e[tag=hr.c.clown,sort=nearest,limit=1] run function horreur:rig/clown/jouer_attaque
execute as @e[tag=hr.c.clown,tag=hr.vamp,sort=nearest,limit=1] at @s run function horreur:sort/vampire
effect give @s minecraft:slowness 3 1 true
