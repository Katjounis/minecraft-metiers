advancement revoke @s only horreur:coup/clown
execute as @e[tag=hr.c.clown,sort=nearest,limit=1] run function horreur:rig/clown/jouer_attaque
effect give @s minecraft:slowness 3 1 true
