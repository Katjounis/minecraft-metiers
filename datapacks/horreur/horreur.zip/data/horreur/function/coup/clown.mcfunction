advancement revoke @s only horreur:coup/clown
effect give @s minecraft:slowness 3 1 true
