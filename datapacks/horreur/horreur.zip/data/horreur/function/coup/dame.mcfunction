advancement revoke @s only horreur:coup/dame
execute as @e[tag=hr.c.dame,sort=nearest,limit=1] run function horreur:rig/dame/jouer_attaque
execute as @e[tag=hr.c.dame,tag=hr.vamp,sort=nearest,limit=1] at @s run function horreur:sort/vampire
effect give @s minecraft:darkness 4 0 true
