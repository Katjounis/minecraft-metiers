advancement revoke @s only horreur:coup/dame
effect give @s minecraft:darkness 4 0 true
