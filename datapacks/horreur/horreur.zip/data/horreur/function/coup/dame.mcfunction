advancement revoke @s only horreur:coup/dame
execute as @e[tag=hr.c.dame,sort=nearest,limit=1] run function horreur:rig/dame/jouer_attaque
effect give @s minecraft:darkness 4 0 true
