advancement revoke @s only horreur:coup/nonne
execute as @e[tag=hr.c.nonne,sort=nearest,limit=1] run function horreur:rig/nonne/jouer_attaque
execute as @e[tag=hr.c.nonne,tag=hr.vamp,sort=nearest,limit=1] at @s run function horreur:sort/vampire
effect give @s minecraft:blindness 3 0 true
effect give @s minecraft:weakness 5 0 true
