advancement revoke @s only horreur:coup/nonne
effect give @s minecraft:blindness 3 0 true
effect give @s minecraft:weakness 5 0 true
