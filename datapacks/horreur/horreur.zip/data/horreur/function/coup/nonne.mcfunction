advancement revoke @s only horreur:coup/nonne
execute as @e[tag=hr.c.nonne,sort=nearest,limit=1] run function horreur:rig/nonne/jouer_attaque
effect give @s minecraft:blindness 3 0 true
effect give @s minecraft:weakness 5 0 true
