advancement revoke @s only horreur:coup/slender
execute as @e[tag=hr.c.slender,sort=nearest,limit=1] run function horreur:rig/slender/jouer_attaque
effect give @s minecraft:darkness 6 0 true
