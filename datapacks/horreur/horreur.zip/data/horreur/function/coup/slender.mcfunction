advancement revoke @s only horreur:coup/slender
execute as @e[tag=hr.c.slender,sort=nearest,limit=1] run function horreur:rig/slender/jouer_attaque
execute as @e[tag=hr.c.slender,tag=hr.vamp,sort=nearest,limit=1] at @s run function horreur:sort/vampire
effect give @s minecraft:darkness 6 0 true
