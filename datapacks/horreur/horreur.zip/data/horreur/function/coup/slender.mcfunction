advancement revoke @s only horreur:coup/slender
effect give @s minecraft:darkness 6 0 true
