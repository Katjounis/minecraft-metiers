advancement revoke @s only horreur:tue/clown
scoreboard players add @s hr.k.clown 1
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 22
execute if score @s hr.k.clown matches 1 run function horreur:palier/clown_1
execute if score @s hr.k.clown matches 10 run function horreur:palier/clown_2
execute if score @s hr.k.clown matches 50 run function horreur:palier/clown_3
execute if score @s hr.k.clown matches 100 run function horreur:palier/clown_4
scoreboard players add @s hr.tot 1
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.ecus 150
execute if score @s c.ecus matches -2147483648.. run tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"Prime : +150 Écus","color":"gold"}]
execute if score #contrat hr.cfg matches 5 unless score @s hr.cw = #cw hr.cfg run function horreur:contrat/paye_clown
execute if score #sang hr.cfg matches 1 run loot give @s loot horreur:bonus/clown
