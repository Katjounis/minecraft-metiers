advancement revoke @s only horreur:tue/clown
scoreboard players add @s hr.k.clown 1
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 22
execute if score @s hr.k.clown matches 1 run function horreur:palier/clown_1
execute if score @s hr.k.clown matches 10 run function horreur:palier/clown_2
execute if score @s hr.k.clown matches 50 run function horreur:palier/clown_3
