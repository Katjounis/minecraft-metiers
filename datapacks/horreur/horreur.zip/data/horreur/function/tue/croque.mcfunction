advancement revoke @s only horreur:tue/croque
scoreboard players add @s hr.k.croque 1
# 26/11/2026 : récompenses proportionnelles au rang de la créature (hr.rgk, posé par la créature sur les joueurs proches)
scoreboard players set #m hr.tmp 0
scoreboard players operation #m hr.tmp = @s hr.rgk
scoreboard players operation #m hr.tmp *= #k15 hr.cfg
scoreboard players add #m hr.tmp 100
scoreboard players set #x hr.tmp 297
scoreboard players operation #x hr.tmp *= #m hr.tmp
scoreboard players operation #x hr.tmp /= #k100 hr.cfg
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players operation @s m.c_bal += #x hr.tmp
execute if score @s hr.k.croque matches 1 run function horreur:palier/croque_1
execute if score @s hr.k.croque matches 10 run function horreur:palier/croque_2
execute if score @s hr.k.croque matches 50 run function horreur:palier/croque_3
execute if score @s hr.k.croque matches 100 run function horreur:palier/croque_4
scoreboard players add @s hr.tot 1
scoreboard players set #pr hr.tmp 10000
execute if score @s hr.k.croque matches 10..49 run scoreboard players add #pr hr.tmp 2500
execute if score @s hr.k.croque matches 50..99 run scoreboard players add #pr hr.tmp 5000
execute if score @s hr.k.croque matches 100.. run scoreboard players add #pr hr.tmp 10000
execute if score #sang hr.cfg matches 1 run scoreboard players operation #pr hr.tmp += #pr hr.tmp
scoreboard players operation #pr hr.tmp *= #m hr.tmp
scoreboard players operation #pr hr.tmp /= #k100 hr.cfg
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus += #pr hr.tmp
execute if score @s c.ecus matches -2147483648.. run tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"Prime : +","color":"gold"},{"score":{"name":"#pr","objective":"hr.tmp"},"color":"gold"},{"text":" Écus","color":"gold"}]
tag @s add hr.tueur
execute at @s as @a[distance=..48,gamemode=!spectator] run function horreur:croque/recompense
tag @s remove hr.tueur
