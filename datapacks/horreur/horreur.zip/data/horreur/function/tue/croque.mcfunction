advancement revoke @s only horreur:tue/croque
scoreboard players add @s hr.k.croque 1
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 297
execute if score @s hr.k.croque matches 1 run function horreur:palier/croque_1
execute if score @s hr.k.croque matches 10 run function horreur:palier/croque_2
execute if score @s hr.k.croque matches 50 run function horreur:palier/croque_3
execute if score @s hr.k.croque matches 100 run function horreur:palier/croque_4
scoreboard players add @s hr.tot 1
scoreboard players set #pr hr.tmp 10000
execute if score @s hr.k.croque matches 10..49 run scoreboard players add #pr hr.tmp 2500
execute if score @s hr.k.croque matches 50..99 run scoreboard players add #pr hr.tmp 5000
execute if score @s hr.k.croque matches 100.. run scoreboard players add #pr hr.tmp 10000
execute if score #sang hr.cfg matches 1 run scoreboard players operation #pr hr.tmp += #pr hr.tmp
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus += #pr hr.tmp
execute if score @s c.ecus matches -2147483648.. run tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"Prime : +","color":"gold"},{"score":{"name":"#pr","objective":"hr.tmp"},"color":"gold"},{"text":" Écus","color":"gold"}]
execute if score #sang hr.cfg matches 1 run loot give @s loot horreur:bonus/croque
