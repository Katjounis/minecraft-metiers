advancement revoke @s only horreur:tue/siren
scoreboard players add @s hr.k.siren 1
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 77
execute if score @s hr.k.siren matches 1 run function horreur:palier/siren_1
execute if score @s hr.k.siren matches 10 run function horreur:palier/siren_2
execute if score @s hr.k.siren matches 50 run function horreur:palier/siren_3
