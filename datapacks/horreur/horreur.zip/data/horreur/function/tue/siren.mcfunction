advancement revoke @s only horreur:tue/siren
scoreboard players add @s hr.k.siren 1
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 77
execute if score @s hr.k.siren matches 1 run function horreur:palier/siren_1
execute if score @s hr.k.siren matches 10 run function horreur:palier/siren_2
execute if score @s hr.k.siren matches 50 run function horreur:palier/siren_3
execute if score @s hr.k.siren matches 100 run function horreur:palier/siren_4
scoreboard players add @s hr.tot 1
scoreboard players set #pr hr.tmp 1200
execute if score @s hr.k.siren matches 10..49 run scoreboard players add #pr hr.tmp 300
execute if score @s hr.k.siren matches 50..99 run scoreboard players add #pr hr.tmp 600
execute if score @s hr.k.siren matches 100.. run scoreboard players add #pr hr.tmp 1200
execute if score #sang hr.cfg matches 1 run scoreboard players operation #pr hr.tmp += #pr hr.tmp
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus += #pr hr.tmp
execute if score @s c.ecus matches -2147483648.. run tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"Prime : +","color":"gold"},{"score":{"name":"#pr","objective":"hr.tmp"},"color":"gold"},{"text":" Écus","color":"gold"}]
execute if score #contrat hr.cfg matches 3 unless score @s hr.cw = #cw hr.cfg run function horreur:contrat/paye_siren
execute if score #sang hr.cfg matches 1 run loot give @s loot horreur:bonus/siren
