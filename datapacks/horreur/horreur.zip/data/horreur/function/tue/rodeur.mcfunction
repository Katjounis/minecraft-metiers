advancement revoke @s only horreur:tue/rodeur
scoreboard players add @s hr.k.rodeur 1
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 32
execute if score @s hr.k.rodeur matches 1 run function horreur:palier/rodeur_1
execute if score @s hr.k.rodeur matches 10 run function horreur:palier/rodeur_2
execute if score @s hr.k.rodeur matches 50 run function horreur:palier/rodeur_3
execute if score @s hr.k.rodeur matches 100 run function horreur:palier/rodeur_4
scoreboard players add @s hr.tot 1
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.ecus 200
execute if score @s c.ecus matches -2147483648.. run tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"Prime : +200 Écus","color":"gold"}]
execute if score #contrat hr.cfg matches 10 unless score @s hr.cw = #cw hr.cfg run function horreur:contrat/paye_rodeur
execute if score #sang hr.cfg matches 1 run loot give @s loot horreur:bonus/rodeur
