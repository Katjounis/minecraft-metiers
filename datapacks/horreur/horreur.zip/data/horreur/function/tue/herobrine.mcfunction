advancement revoke @s only horreur:tue/herobrine
scoreboard players add @s hr.k.herobrine 1
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 27
execute if score @s hr.k.herobrine matches 1 run function horreur:palier/herobrine_1
execute if score @s hr.k.herobrine matches 10 run function horreur:palier/herobrine_2
execute if score @s hr.k.herobrine matches 50 run function horreur:palier/herobrine_3
