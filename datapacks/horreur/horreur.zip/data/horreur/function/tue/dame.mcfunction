advancement revoke @s only horreur:tue/dame
scoreboard players add @s hr.k.dame 1
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 32
execute if score @s hr.k.dame matches 1 run function horreur:palier/dame_1
execute if score @s hr.k.dame matches 10 run function horreur:palier/dame_2
execute if score @s hr.k.dame matches 50 run function horreur:palier/dame_3
execute if score @s hr.k.dame matches 100 run function horreur:palier/dame_4
scoreboard players add @s hr.tot 1
scoreboard players set #pr hr.tmp 500
execute if score @s hr.k.dame matches 10..49 run scoreboard players add #pr hr.tmp 125
execute if score @s hr.k.dame matches 50..99 run scoreboard players add #pr hr.tmp 250
execute if score @s hr.k.dame matches 100.. run scoreboard players add #pr hr.tmp 500
execute if score #sang hr.cfg matches 1 run scoreboard players operation #pr hr.tmp += #pr hr.tmp
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus += #pr hr.tmp
execute if score @s c.ecus matches -2147483648.. run tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"Prime : +","color":"gold"},{"score":{"name":"#pr","objective":"hr.tmp"},"color":"gold"},{"text":" Écus","color":"gold"}]
execute if score #contrat hr.cfg matches 7 unless score @s hr.cw = #cw hr.cfg run function horreur:contrat/paye_dame
execute if score #sang hr.cfg matches 1 run loot give @s loot horreur:bonus/dame
