advancement revoke @s only horreur:tue/dame
scoreboard players add @s hr.k.dame 1
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 32
execute if score @s hr.k.dame matches 1 run function horreur:palier/dame_1
execute if score @s hr.k.dame matches 10 run function horreur:palier/dame_2
execute if score @s hr.k.dame matches 50 run function horreur:palier/dame_3
execute if score @s hr.k.dame matches 100 run function horreur:palier/dame_4
scoreboard players add @s hr.tot 1
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.ecus 250
execute if score @s c.ecus matches -2147483648.. run tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"Prime : +250 Écus","color":"gold"}]
execute if score #contrat hr.cfg matches 7 unless score @s hr.cw = #cw hr.cfg run function horreur:contrat/paye_dame
execute if score #sang hr.cfg matches 1 run loot give @s loot horreur:bonus/dame
