advancement revoke @s only horreur:tue/pinhead
scoreboard players add @s hr.k.pinhead 1
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 57
execute if score @s hr.k.pinhead matches 1 run function horreur:palier/pinhead_1
execute if score @s hr.k.pinhead matches 10 run function horreur:palier/pinhead_2
execute if score @s hr.k.pinhead matches 50 run function horreur:palier/pinhead_3
execute if score @s hr.k.pinhead matches 100 run function horreur:palier/pinhead_4
scoreboard players add @s hr.tot 1
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.ecus 500
execute if score @s c.ecus matches -2147483648.. run tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"Prime : +500 Écus","color":"gold"}]
execute if score #contrat hr.cfg matches 6 unless score @s hr.cw = #cw hr.cfg run function horreur:contrat/paye_pinhead
execute if score #sang hr.cfg matches 1 run loot give @s loot horreur:bonus/pinhead
