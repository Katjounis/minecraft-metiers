advancement revoke @s only horreur:tue/pinhead
scoreboard players add @s hr.k.pinhead 1
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 57
execute if score @s hr.k.pinhead matches 1 run function horreur:palier/pinhead_1
execute if score @s hr.k.pinhead matches 10 run function horreur:palier/pinhead_2
execute if score @s hr.k.pinhead matches 50 run function horreur:palier/pinhead_3
