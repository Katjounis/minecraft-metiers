advancement revoke @s only horreur:tue/feu
scoreboard players add @s hr.k.feu 1
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 16
execute if score @s hr.k.feu matches 1 run function horreur:palier/feu_1
execute if score @s hr.k.feu matches 10 run function horreur:palier/feu_2
execute if score @s hr.k.feu matches 50 run function horreur:palier/feu_3
execute if score @s hr.k.feu matches 100 run function horreur:palier/feu_4
scoreboard players add @s hr.tot 1
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.ecus 100
execute if score @s c.ecus matches -2147483648.. run tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"Prime : +100 Écus","color":"gold"}]
execute if score #contrat hr.cfg matches 9 unless score @s hr.cw = #cw hr.cfg run function horreur:contrat/paye_feu
execute if score #sang hr.cfg matches 1 run loot give @s loot horreur:bonus/feu
