advancement revoke @s only horreur:tue/slender
scoreboard players add @s hr.k.slender 1
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 37
execute if score @s hr.k.slender matches 1 run function horreur:palier/slender_1
execute if score @s hr.k.slender matches 10 run function horreur:palier/slender_2
execute if score @s hr.k.slender matches 50 run function horreur:palier/slender_3
