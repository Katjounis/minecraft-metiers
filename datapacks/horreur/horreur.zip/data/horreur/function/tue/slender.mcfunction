advancement revoke @s only horreur:tue/slender
scoreboard players add @s hr.k.slender 1
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 37
execute if score @s hr.k.slender matches 1 run function horreur:palier/slender_1
execute if score @s hr.k.slender matches 10 run function horreur:palier/slender_2
execute if score @s hr.k.slender matches 50 run function horreur:palier/slender_3
execute if score @s hr.k.slender matches 100 run function horreur:palier/slender_4
scoreboard players add @s hr.tot 1
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.ecus 300
execute if score @s c.ecus matches -2147483648.. run tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"Prime : +300 Écus","color":"gold"}]
execute if score #contrat hr.cfg matches 1 unless score @s hr.cw = #cw hr.cfg run function horreur:contrat/paye_slender
execute if score #sang hr.cfg matches 1 run loot give @s loot horreur:bonus/slender
