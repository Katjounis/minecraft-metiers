scoreboard players add #n hr.tmp 1
execute if score #n hr.tmp > #lim hr.tmp run return fail
tp @s ~ ~1 ~
execute at @s unless block ~ ~ ~ #horreur:passable run return run function horreur:sol/monter
execute at @s run function horreur:sol/valider
