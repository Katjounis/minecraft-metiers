execute unless block ~ ~1 ~ #horreur:passable run return fail
execute if block ~ ~-1 ~ #minecraft:leaves run return fail
execute if block ~ ~-1 ~ minecraft:water run return fail
execute if block ~ ~-1 ~ minecraft:lava run return fail
execute if block ~ ~-1 ~ minecraft:powder_snow run return fail
execute if score #h hr.tmp matches 3.. unless block ~ ~2 ~ #horreur:passable run return fail
execute if score #h hr.tmp matches 5.. unless block ~ ~4 ~ #horreur:passable run return fail
execute if score #h hr.tmp matches 8.. unless block ~ ~7 ~ #horreur:passable run return fail
scoreboard players set #ok hr.tmp 1
