scoreboard players set #n hr.tmp 0
scoreboard players set #ok hr.tmp 0
execute unless block ~ ~ ~ #horreur:passable run return run function horreur:sol/monter
function horreur:sol/descendre
