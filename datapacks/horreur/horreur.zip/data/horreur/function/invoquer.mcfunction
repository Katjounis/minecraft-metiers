# Admin : /function horreur:invoquer {c:"slender"}  (slender, herobrine, siren, nonne, clown, pinhead)
# 4 blocs devant soi a l'horizontale (le regard vers le bas ne compte pas), pose au sol ; sinon aux pieds
scoreboard players set #lim hr.tmp 6
scoreboard players set #h hr.tmp 2
summon minecraft:marker ~ ~ ~ {Tags:["hr.pt"]}
execute rotated ~ 0 positioned ^ ^ ^4 align y run tp @e[type=minecraft:marker,tag=hr.pt,limit=1] ~ ~ ~
execute as @e[type=minecraft:marker,tag=hr.pt,limit=1] at @s run function horreur:sol/trouver
execute unless score #ok hr.tmp matches 1 run tp @e[type=minecraft:marker,tag=hr.pt,limit=1] ~ ~ ~
$execute at @e[type=minecraft:marker,tag=hr.pt,limit=1] align xz positioned ~0.5 ~ ~0.5 run function horreur:invoquer/$(c)
kill @e[type=minecraft:marker,tag=hr.pt]
