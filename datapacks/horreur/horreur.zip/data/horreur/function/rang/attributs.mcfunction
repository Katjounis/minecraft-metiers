$attribute @s minecraft:max_health base set $(hp)
$data modify entity @s Health set value $(hp)f
$attribute @s minecraft:attack_damage base set $(dg)
$attribute @s minecraft:armor base set $(ar)
$attribute @s minecraft:armor_toughness base set $(ro)
