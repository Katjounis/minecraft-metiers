# en tant que joueur : #rg = score de métiers / 50 (plafonné), 0 sans le pack Métiers
scoreboard players set #rg hr.tmp 0
execute if score @s m.total matches 1.. run scoreboard players operation #rg hr.tmp = @s m.total
scoreboard players operation #rg hr.tmp /= #k50 hr.cfg
execute if score #rg hr.tmp matches 25.. run scoreboard players set #rg hr.tmp 24
