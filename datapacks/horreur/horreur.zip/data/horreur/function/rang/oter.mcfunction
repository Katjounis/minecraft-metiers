$data remove storage horreur:r L[{nom:"$(nom)"}]
