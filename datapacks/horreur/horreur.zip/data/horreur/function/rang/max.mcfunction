execute unless data storage horreur:r W[0] run return 0
execute store result score #x hr.tmp run data get storage horreur:r W[0].e
execute if score #x hr.tmp > #m hr.tmp run data modify storage horreur:r best set from storage horreur:r W[0]
execute if score #x hr.tmp > #m hr.tmp run scoreboard players operation #m hr.tmp = #x hr.tmp
data remove storage horreur:r W[0]
function horreur:rang/max
