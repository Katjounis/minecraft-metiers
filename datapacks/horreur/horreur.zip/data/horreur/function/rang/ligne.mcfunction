$data modify storage horreur:r C append value {"text":"$(r). ","color":"gray"}
$data modify storage horreur:r C append value {"text":"$(nom)","color":"white"}
$data modify storage horreur:r C append value {"text":"   $(e) créatures\n","color":"red"}
