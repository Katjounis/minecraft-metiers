data modify storage horreur:r L set value []
data modify storage horreur:r W set from storage commerce:j l
function horreur:rang/remplir
data modify storage horreur:r C set value [{"text":""}]
scoreboard players set #rk hr.tmp 0
function horreur:rang/extraire
execute unless data storage horreur:r C[1] run data modify storage horreur:r C append value {"text":"Personne pour l'instant.","color":"gray"}
