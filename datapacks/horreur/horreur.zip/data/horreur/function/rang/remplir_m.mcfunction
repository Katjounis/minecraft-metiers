scoreboard players set #e hr.tmp 0
$execute store result score #e hr.tmp run scoreboard players get $(nom) hr.tot
execute if score #e hr.tmp matches ..0 run return 0
$data modify storage horreur:r L append value {nom:"$(nom)",e:0}
execute store result storage horreur:r L[-1].e int 1 run scoreboard players get #e hr.tmp
