execute if score #rk hr.tmp matches 5.. run return 0
execute unless data storage horreur:r L[0] run return 0
scoreboard players set #m hr.tmp -1
data modify storage horreur:r W set from storage horreur:r L
function horreur:rang/max
scoreboard players add #rk hr.tmp 1
execute store result storage horreur:r best.r int 1 run scoreboard players get #rk hr.tmp
function horreur:rang/ligne with storage horreur:r best
function horreur:rang/oter with storage horreur:r best
function horreur:rang/extraire
