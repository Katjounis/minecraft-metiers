scoreboard players operation @s hr.rg = #rg hr.tmp
scoreboard players operation @s hr.pw = @s hr.rg
scoreboard players operation @s hr.pw *= #k8 hr.cfg
scoreboard players add @s hr.pw 100
scoreboard players operation #m hr.tmp = @s hr.rg
scoreboard players operation #m hr.tmp *= #k15 hr.cfg
scoreboard players add #m hr.tmp 100
scoreboard players set #hp hr.tmp 20
scoreboard players operation #hp hr.tmp *= #m hr.tmp
scoreboard players operation #hp hr.tmp /= #k100 hr.cfg
scoreboard players set #res hr.tmp 0
execute if score #hp hr.tmp matches 1300.. run scoreboard players set #res hr.tmp 1
execute if score #hp hr.tmp matches 1800.. run scoreboard players set #res hr.tmp 2
execute if score #hp hr.tmp matches 2600.. run scoreboard players set #res hr.tmp 3
execute if score #hp hr.tmp matches 1025.. run scoreboard players set #hp hr.tmp 1024
scoreboard players operation @s hr.pv = #hp hr.tmp
execute store result storage horreur:t g.hp int 1 run scoreboard players get #hp hr.tmp
scoreboard players set #x hr.tmp 4
scoreboard players operation #x hr.tmp *= @s hr.pw
scoreboard players operation #x hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t g.dg int 1 run scoreboard players get #x hr.tmp
scoreboard players set #x hr.tmp 0
scoreboard players operation #x hr.tmp += @s hr.rg
execute if score #x hr.tmp matches 31.. run scoreboard players set #x hr.tmp 30
execute store result storage horreur:t g.ar int 1 run scoreboard players get #x hr.tmp
scoreboard players operation #x hr.tmp = @s hr.rg
scoreboard players operation #x hr.tmp /= #k2 hr.cfg
execute store result storage horreur:t g.ro int 1 run scoreboard players get #x hr.tmp
function horreur:rang/attributs with storage horreur:t g
execute if score #res hr.tmp matches 1 run effect give @s minecraft:resistance infinite 0 true
execute if score #res hr.tmp matches 2 run effect give @s minecraft:resistance infinite 1 true
execute if score #res hr.tmp matches 3 run effect give @s minecraft:resistance infinite 2 true
scoreboard players set @s hr.scd 100
scoreboard players set #x hr.tmp 100
scoreboard players operation #x hr.tmp *= @s hr.rg
scoreboard players operation #x hr.tmp /= #k40 hr.cfg
scoreboard players operation @s hr.scd -= #x hr.tmp
execute if score @s hr.scd matches ..50 run scoreboard players set @s hr.scd 50
scoreboard players set @s hr.s 33
execute if score @s hr.rg matches 3.. run tag @s add hr.regen
execute if score @s hr.rg matches 6.. run tag @s add hr.ronce
execute if score @s hr.rg matches 10.. run tag @s add hr.vamp
execute if score @s hr.rg matches 14.. run tag @s add hr.aura
execute if score @s hr.rg matches 18.. run tag @s add hr.rage
execute if entity @s[tag=hr.regen] run effect give @s minecraft:regeneration infinite 0 true
