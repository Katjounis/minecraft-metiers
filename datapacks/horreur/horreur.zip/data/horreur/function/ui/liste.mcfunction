scoreboard players set #d hr.tmp 0
data modify storage horreur:ui m.l1 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.slender matches 1.. run data modify storage horreur:ui m.l1 set value {"text":"SlenderMan","color":"#c8c8c8"}
execute if score @s hr.k.slender matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l2 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.herobrine matches 1.. run data modify storage horreur:ui m.l2 set value {"text":"Herobrine","color":"#ffffff"}
execute if score @s hr.k.herobrine matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l3 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.siren matches 1.. run data modify storage horreur:ui m.l3 set value {"text":"Siren Head","color":"#a08a6a"}
execute if score @s hr.k.siren matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l4 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.nonne matches 1.. run data modify storage horreur:ui m.l4 set value {"text":"La Nonne","color":"#d0c8a0"}
execute if score @s hr.k.nonne matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l5 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.clown matches 1.. run data modify storage horreur:ui m.l5 set value {"text":"Le Clown","color":"#e03030"}
execute if score @s hr.k.clown matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l6 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.pinhead matches 1.. run data modify storage horreur:ui m.l6 set value {"text":"Pinhead","color":"#9a9aa8"}
execute if score @s hr.k.pinhead matches 1.. run scoreboard players add #d hr.tmp 1
execute store result storage horreur:ui m.d int 1 run scoreboard players get #d hr.tmp
function horreur:ui/liste_m with storage horreur:ui m
