scoreboard players set #d hr.tmp 0
data modify storage horreur:ui m.l1 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.slender matches 1.. run data modify storage horreur:ui m.l1 set value {"text":"SlenderMan","color":"#c8c8c8"}
execute if score @s hr.k.slender matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l2 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.herobrine matches 1.. run data modify storage horreur:ui m.l2 set value {"text":"Herobrine","color":"#ffffff"}
execute if score @s hr.k.herobrine matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l3 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.siren matches 1.. run data modify storage horreur:ui m.l3 set value {"text":"Siren Head","color":"#a08a6a"}
execute if score @s hr.k.siren matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l4 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.nonne matches 1.. run data modify storage horreur:ui m.l4 set value {"text":"La Nonne","color":"#d0c8a0"}
execute if score @s hr.k.nonne matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l5 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.clown matches 1.. run data modify storage horreur:ui m.l5 set value {"text":"Le Clown","color":"#e03030"}
execute if score @s hr.k.clown matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l6 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.pinhead matches 1.. run data modify storage horreur:ui m.l6 set value {"text":"Pinhead","color":"#9a9aa8"}
execute if score @s hr.k.pinhead matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l7 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.dame matches 1.. run data modify storage horreur:ui m.l7 set value {"text":"La Dame blanche","color":"#f4f4ff"}
execute if score @s hr.k.dame matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l8 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.loup matches 1.. run data modify storage horreur:ui m.l8 set value {"text":"Le Loup-garou","color":"#7a6a58"}
execute if score @s hr.k.loup matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l9 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.feu matches 1.. run data modify storage horreur:ui m.l9 set value {"text":"Le Feu follet","color":"#7fd8ff"}
execute if score @s hr.k.feu matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l10 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.rodeur matches 1.. run data modify storage horreur:ui m.l10 set value {"text":"Le Rôdeur des grottes","color":"#b8b2a8"}
execute if score @s hr.k.rodeur matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.l11 set value {"text":"???","color":"dark_gray"}
execute if score @s hr.k.croque matches 1.. run data modify storage horreur:ui m.l11 set value {"text":"Le Croque-mitaine","color":"#5a1020"}
execute if score @s hr.k.croque matches 1.. run scoreboard players add #d hr.tmp 1
data modify storage horreur:ui m.ct set value "aucun"
execute if score #contrat hr.cfg matches 1 run data modify storage horreur:ui m.ct set value "SlenderMan (prime 3000 Écus)"
execute if score #contrat hr.cfg matches 2 run data modify storage horreur:ui m.ct set value "Herobrine (prime 2500 Écus)"
execute if score #contrat hr.cfg matches 3 run data modify storage horreur:ui m.ct set value "Siren Head (prime 6000 Écus)"
execute if score #contrat hr.cfg matches 4 run data modify storage horreur:ui m.ct set value "La Nonne (prime 1500 Écus)"
execute if score #contrat hr.cfg matches 5 run data modify storage horreur:ui m.ct set value "Le Clown (prime 1500 Écus)"
execute if score #contrat hr.cfg matches 6 run data modify storage horreur:ui m.ct set value "Pinhead (prime 5000 Écus)"
execute if score #contrat hr.cfg matches 7 run data modify storage horreur:ui m.ct set value "La Dame blanche (prime 2500 Écus)"
execute if score #contrat hr.cfg matches 8 run data modify storage horreur:ui m.ct set value "Le Loup-garou (prime 4500 Écus)"
execute if score #contrat hr.cfg matches 9 run data modify storage horreur:ui m.ct set value "Le Feu follet (prime 1000 Écus)"
execute if score #contrat hr.cfg matches 10 run data modify storage horreur:ui m.ct set value "Le Rôdeur des grottes (prime 2000 Écus)"
data modify storage horreur:ui m.ok set value ""
execute if score @s hr.cw = #cw hr.cfg run data modify storage horreur:ui m.ok set value " ✔ rempli"
data modify storage horreur:ui m.sg set value ""
execute if score #sang hr.cfg matches 1 run data modify storage horreur:ui m.sg set value "\n☠ Nuit de sang en cours : créatures x4, butin doublé."
execute store result storage horreur:ui m.tot int 1 run scoreboard players get @s hr.tot
execute store result storage horreur:ui m.d int 1 run scoreboard players get #d hr.tmp
function horreur:ui/liste_m with storage horreur:ui m
