execute unless score @s hr.k.siren matches 1.. run return run dialog show @s {"type":"minecraft:multi_action","title":{"text":"???","color":"dark_gray","bold":true},"can_close_with_escape":true,"pause":false,"body":[{"type":"minecraft:plain_message","width":300,"contents":{"text":"Tu n'as encore jamais vaincu cette créature.","color":"gray"}},{"type":"minecraft:plain_message","width":300,"contents":[{"text":"Indice : ","color":"dark_red"},{"text":"La surface la nuit, surtout les plaines, prairies et savanes. Rare.","color":"gray"}]}],"actions":[{"label":{"text":"◀ Retour"},"width":120,"action":{"type":"minecraft:run_command","command":"trigger bestiaire set 1"}}],"exit_action":{"label":{"text":"Fermer"}}}
execute store result storage horreur:ui f.n int 1 run scoreboard players get @s hr.k.siren
data modify storage horreur:ui f merge value {p2:"✖",c2:"dark_gray",p3:"✖",c3:"dark_gray",p4:"✖",c4:"dark_gray"}
execute if score @s hr.k.siren matches 100.. run data modify storage horreur:ui f merge value {p4:"✔",c4:"light_purple"}
execute if score @s hr.k.siren matches 10.. run data modify storage horreur:ui f merge value {p2:"✔",c2:"green"}
execute if score @s hr.k.siren matches 50.. run data modify storage horreur:ui f merge value {p3:"✔",c3:"gold"}
function horreur:ui/fiche/siren_m with storage horreur:ui f
