execute unless data storage commerce:j l run return run tellraw @s {"text":"[Bestiaire] Le classement a besoin du pack Commerce (registre des pseudos).","color":"gray"}
function horreur:rang/calcul
function horreur:ui/classement_m with storage horreur:r
