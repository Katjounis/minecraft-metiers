scoreboard players set #tot hr.tmp 0
execute store result score #n hr.tmp run clear @s minecraft:paper[minecraft:item_model="horreur:trophee_slender"]
scoreboard players set #p hr.tmp 3000
scoreboard players operation #n hr.tmp *= #p hr.tmp
scoreboard players operation #tot hr.tmp += #n hr.tmp
execute store result score #n hr.tmp run clear @s minecraft:paper[minecraft:item_model="horreur:trophee_herobrine"]
scoreboard players set #p hr.tmp 2500
scoreboard players operation #n hr.tmp *= #p hr.tmp
scoreboard players operation #tot hr.tmp += #n hr.tmp
execute store result score #n hr.tmp run clear @s minecraft:paper[minecraft:item_model="horreur:trophee_siren"]
scoreboard players set #p hr.tmp 6000
scoreboard players operation #n hr.tmp *= #p hr.tmp
scoreboard players operation #tot hr.tmp += #n hr.tmp
execute store result score #n hr.tmp run clear @s minecraft:paper[minecraft:item_model="horreur:trophee_nonne"]
scoreboard players set #p hr.tmp 1500
scoreboard players operation #n hr.tmp *= #p hr.tmp
scoreboard players operation #tot hr.tmp += #n hr.tmp
execute store result score #n hr.tmp run clear @s minecraft:paper[minecraft:item_model="horreur:trophee_clown"]
scoreboard players set #p hr.tmp 1500
scoreboard players operation #n hr.tmp *= #p hr.tmp
scoreboard players operation #tot hr.tmp += #n hr.tmp
execute store result score #n hr.tmp run clear @s minecraft:paper[minecraft:item_model="horreur:trophee_pinhead"]
scoreboard players set #p hr.tmp 5000
scoreboard players operation #n hr.tmp *= #p hr.tmp
scoreboard players operation #tot hr.tmp += #n hr.tmp
execute store result score #n hr.tmp run clear @s minecraft:paper[minecraft:item_model="horreur:trophee_dame"]
scoreboard players set #p hr.tmp 2500
scoreboard players operation #n hr.tmp *= #p hr.tmp
scoreboard players operation #tot hr.tmp += #n hr.tmp
execute store result score #n hr.tmp run clear @s minecraft:paper[minecraft:item_model="horreur:trophee_loup"]
scoreboard players set #p hr.tmp 4500
scoreboard players operation #n hr.tmp *= #p hr.tmp
scoreboard players operation #tot hr.tmp += #n hr.tmp
execute store result score #n hr.tmp run clear @s minecraft:paper[minecraft:item_model="horreur:trophee_feu"]
scoreboard players set #p hr.tmp 1000
scoreboard players operation #n hr.tmp *= #p hr.tmp
scoreboard players operation #tot hr.tmp += #n hr.tmp
execute store result score #n hr.tmp run clear @s minecraft:paper[minecraft:item_model="horreur:trophee_rodeur"]
scoreboard players set #p hr.tmp 2000
scoreboard players operation #n hr.tmp *= #p hr.tmp
scoreboard players operation #tot hr.tmp += #n hr.tmp
execute store result score #n hr.tmp run clear @s minecraft:paper[minecraft:item_model="horreur:trophee_croque"]
scoreboard players set #p hr.tmp 50000
scoreboard players operation #n hr.tmp *= #p hr.tmp
scoreboard players operation #tot hr.tmp += #n hr.tmp
execute if score #tot hr.tmp matches 0 run return run tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"Tu n'as aucun trophée sur toi.","color":"gray"}]
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus += #tot hr.tmp
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.a_hor += #tot hr.tmp
tellraw @s [{"text":"[Bestiaire] ","color":"dark_red"},{"text":"Trophées vendus : +","color":"gold"},{"score":{"name":"#tot","objective":"hr.tmp"},"color":"gold"},{"text":" Écus.","color":"gold"}]
playsound minecraft:entity.villager.trade master @s ~ ~ ~ 1 1
