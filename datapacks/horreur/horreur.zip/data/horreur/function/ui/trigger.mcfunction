scoreboard players operation #v hr.tmp = @s bestiaire
scoreboard players set @s bestiaire 0
scoreboard players enable @s bestiaire
execute if score #v hr.tmp matches 1 run return run function horreur:ui/liste
execute if score #v hr.tmp matches 11 run return run function horreur:ui/fiche/slender
execute if score #v hr.tmp matches 12 run return run function horreur:ui/fiche/herobrine
execute if score #v hr.tmp matches 13 run return run function horreur:ui/fiche/siren
execute if score #v hr.tmp matches 14 run return run function horreur:ui/fiche/nonne
execute if score #v hr.tmp matches 15 run return run function horreur:ui/fiche/clown
execute if score #v hr.tmp matches 16 run return run function horreur:ui/fiche/pinhead
