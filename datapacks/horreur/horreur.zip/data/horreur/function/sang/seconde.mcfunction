execute as @a[gamemode=!spectator] at @s if dimension minecraft:overworld run particle minecraft:dust{color:[0.7,0.02,0.02],scale:1.6} ~ ~6 ~ 10 3 10 0 25
execute if score #minuit hr.tmp matches 1 if score #bossfait hr.cfg matches 0 as @r[gamemode=!spectator] at @s if dimension minecraft:overworld run function horreur:sang/boss
