function horreur:spawn/croque
execute if entity @e[tag=hr.c.croque] run scoreboard players set #bossfait hr.cfg 1
