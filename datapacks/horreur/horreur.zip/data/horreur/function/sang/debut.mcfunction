scoreboard players set #sang hr.cfg 1
scoreboard players set #bossfait hr.cfg 0
scoreboard players set @a hr.cd 0
tellraw @a [{"text":"☠ La Nuit de sang commence... ","color":"dark_red","bold":true},{"text":"Les créatures sont quatre fois plus nombreuses et leur butin est doublé. Vers minuit, le Croque-mitaine sortira de l'ombre.","color":"red","bold":false}]
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.6 0.5
