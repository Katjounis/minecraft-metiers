execute store result score #r hr.tmp run random value 1..8
execute if score #r hr.tmp matches 1 run function horreur:sang/debut
