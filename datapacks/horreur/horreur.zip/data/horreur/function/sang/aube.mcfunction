execute unless score #sang hr.cfg matches 1 run return 0
scoreboard players set #sang hr.cfg 0
tellraw @a {"text":"L'aube chasse la Nuit de sang.","color":"gray","italic":true}
