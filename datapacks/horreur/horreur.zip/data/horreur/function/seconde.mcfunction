schedule function horreur:seconde 20t replace
scoreboard players enable @a bestiaire
scoreboard players remove @a[scores={hr.cd=1..}] hr.cd 1
scoreboard players set #nuit hr.tmp 0
execute if predicate horreur:nuit run scoreboard players set #nuit hr.tmp 1
scoreboard players set #minuit hr.tmp 0
execute if predicate horreur:minuit run scoreboard players set #minuit hr.tmp 1
execute as @e[tag=hr.c] at @s run function horreur:c/vie
execute as @e[tag=hr.serv] at @s run function horreur:c/vie_serviteur
scoreboard players add #s hr.tmp 1
execute if score #s hr.tmp matches 30.. run function horreur:spawn/cycle
scoreboard players operation #np hr.tmp = #nuitp hr.cfg
scoreboard players operation #nuitp hr.cfg = #nuit hr.tmp
execute if score #nuit hr.tmp matches 1 if score #np hr.tmp matches 0 run function horreur:sang/crepuscule
execute if score #nuit hr.tmp matches 0 if score #np hr.tmp matches 1 run function horreur:sang/aube
execute if score #sang hr.cfg matches 1 run function horreur:sang/seconde
execute if entity @a run scoreboard players add #semh hr.cfg 1
execute if score #semh hr.cfg matches 10080.. run function horreur:contrat/nouveau
execute unless entity @e[tag=hr.c.croque] run bossbar set horreur:boss visible false
