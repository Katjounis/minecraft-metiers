schedule function horreur:seconde 20t replace
scoreboard players enable @a bestiaire
scoreboard players remove @a[scores={hr.cd=1..}] hr.cd 1
scoreboard players set #nuit hr.tmp 0
execute if predicate horreur:nuit run scoreboard players set #nuit hr.tmp 1
scoreboard players set #minuit hr.tmp 0
execute if predicate horreur:minuit run scoreboard players set #minuit hr.tmp 1
execute as @e[tag=hr.c] at @s run function horreur:c/vie
execute as @e[tag=hr.serv] at @s run function horreur:c/vie_serviteur
scoreboard players add #s hr.tmp 1
execute if score #s hr.tmp matches 30.. run function horreur:spawn/cycle
