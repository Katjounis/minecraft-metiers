# Admin : lance une Nuit de sang (la nuit en cours)
function horreur:sang/debut
