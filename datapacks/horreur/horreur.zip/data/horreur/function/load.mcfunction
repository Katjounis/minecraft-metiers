scoreboard objectives add hr.tmp dummy
scoreboard objectives add hr.cfg dummy
scoreboard objectives add hr.cd dummy
scoreboard objectives add hr.vie dummy
scoreboard objectives add hr.age dummy
scoreboard objectives add hr.etat dummy
scoreboard objectives add hr.t dummy
scoreboard objectives add hr.r dummy
scoreboard objectives add hr.tot dummy
scoreboard objectives add hr.cw dummy
scoreboard objectives add hr.an dummy
scoreboard objectives add hr.af dummy
scoreboard objectives add hr.k.slender dummy
scoreboard objectives add hr.k.herobrine dummy
scoreboard objectives add hr.k.siren dummy
scoreboard objectives add hr.k.nonne dummy
scoreboard objectives add hr.k.clown dummy
scoreboard objectives add hr.k.pinhead dummy
scoreboard objectives add hr.k.dame dummy
scoreboard objectives add hr.k.loup dummy
scoreboard objectives add hr.k.feu dummy
scoreboard objectives add hr.k.rodeur dummy
scoreboard objectives add hr.k.croque dummy
scoreboard objectives add bestiaire trigger
execute unless score #init hr.cfg matches 1 run function horreur:config/defaut
execute unless score #ver hr.cfg matches 2.. run function horreur:config/defaut
bossbar add horreur:boss {"text":"Le Croque-mitaine","color":"dark_red","bold":true}
bossbar set horreur:boss color red
bossbar set horreur:boss style notched_10
bossbar set horreur:boss max 800
execute unless entity @e[tag=hr.c.croque] run bossbar set horreur:boss visible false
scoreboard players add #sang hr.cfg 0
scoreboard players add #contrat hr.cfg 0
scoreboard players add #cw hr.cfg 0
scoreboard players add #semh hr.cfg 0
execute unless score #contrat hr.cfg matches 1.. run function horreur:contrat/nouveau
schedule function horreur:seconde 20t replace
