scoreboard objectives add hr.tmp dummy
scoreboard objectives add hr.cfg dummy
scoreboard objectives add hr.cd dummy
scoreboard objectives add hr.vie dummy
scoreboard objectives add hr.age dummy
scoreboard objectives add hr.etat dummy
scoreboard objectives add hr.t dummy
scoreboard objectives add hr.r dummy
scoreboard objectives add hr.k.slender dummy
scoreboard objectives add hr.k.herobrine dummy
scoreboard objectives add hr.k.siren dummy
scoreboard objectives add hr.k.nonne dummy
scoreboard objectives add hr.k.clown dummy
scoreboard objectives add hr.k.pinhead dummy
scoreboard objectives add bestiaire trigger
execute unless score #init hr.cfg matches 1 run function horreur:config/defaut
execute unless score #ver hr.cfg matches 2.. run function horreur:config/defaut
schedule function horreur:seconde 20t replace
