data modify storage horreur:t s set value {c:"nonne",a0:160,a1:200,d0:3,d1:3}
scoreboard players set #lim hr.tmp 4
scoreboard players set #h hr.tmp 2
scoreboard players set #surf hr.tmp 0
function horreur:spawn/placer
