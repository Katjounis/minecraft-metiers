data modify storage horreur:t s set value {c:"loup",a0:0,a1:359,d0:24,d1:36}
scoreboard players set #lim hr.tmp 24
scoreboard players set #h hr.tmp 3
scoreboard players set #surf hr.tmp 0
function horreur:spawn/placer
