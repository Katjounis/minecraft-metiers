data modify storage horreur:t s set value {c:"feu",a0:0,a1:359,d0:12,d1:20}
scoreboard players set #lim hr.tmp 24
scoreboard players set #h hr.tmp 2
scoreboard players set #surf hr.tmp 0
function horreur:spawn/placer
