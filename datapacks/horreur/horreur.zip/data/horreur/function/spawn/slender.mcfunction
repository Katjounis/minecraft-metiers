data modify storage horreur:t s set value {c:"slender",a0:0,a1:359,d0:26,d1:42}
scoreboard players set #lim hr.tmp 24
scoreboard players set #h hr.tmp 3
scoreboard players set #surf hr.tmp 1
function horreur:spawn/placer
