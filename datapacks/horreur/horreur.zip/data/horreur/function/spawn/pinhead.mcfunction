data modify storage horreur:t s set value {c:"pinhead",a0:0,a1:359,d0:8,d1:14}
scoreboard players set #lim hr.tmp 8
scoreboard players set #h hr.tmp 3
scoreboard players set #surf hr.tmp 0
function horreur:spawn/placer
