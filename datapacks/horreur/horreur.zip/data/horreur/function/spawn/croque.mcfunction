data modify storage horreur:t s set value {c:"croque",a0:0,a1:359,d0:14,d1:20}
scoreboard players set #lim hr.tmp 24
scoreboard players set #h hr.tmp 5
scoreboard players set #surf hr.tmp 0
function horreur:spawn/placer
