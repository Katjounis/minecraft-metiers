$execute rotated ~$(a) 0 positioned ^ ^ ^$(d) run tp @e[type=minecraft:marker,tag=hr.pt,limit=1] ~ ~ ~
execute if score #surf hr.tmp matches 1 as @e[type=minecraft:marker,tag=hr.pt,limit=1] at @s positioned over motion_blocking_no_leaves run tp @s ~ ~ ~
execute as @e[type=minecraft:marker,tag=hr.pt,limit=1] at @s run function horreur:sol/trouver
execute unless score #ok hr.tmp matches 1 run return run function horreur:spawn/essai with storage horreur:t s
scoreboard players operation @s hr.cd = #cd hr.cfg
$execute at @e[type=minecraft:marker,tag=hr.pt,limit=1] run function horreur:invoquer/$(c)
