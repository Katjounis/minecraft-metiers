data modify storage horreur:t s set value {c:"dame",a0:-60,a1:60,d0:20,d1:30}
scoreboard players set #lim hr.tmp 24
scoreboard players set #h hr.tmp 2
scoreboard players set #surf hr.tmp 1
function horreur:spawn/placer
