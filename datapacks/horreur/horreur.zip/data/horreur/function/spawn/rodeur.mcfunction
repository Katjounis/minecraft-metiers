data modify storage horreur:t s set value {c:"rodeur",a0:150,a1:210,d0:12,d1:16}
scoreboard players set #lim hr.tmp 8
scoreboard players set #h hr.tmp 2
scoreboard players set #surf hr.tmp 0
function horreur:spawn/placer
