scoreboard players add #essai hr.tmp 1
execute if score #essai hr.tmp matches 9.. run return fail
$execute store result storage horreur:t s.a int 1 run random value $(a0)..$(a1)
$execute store result storage horreur:t s.d int 1 run random value $(d0)..$(d1)
function horreur:spawn/viser with storage horreur:t s
