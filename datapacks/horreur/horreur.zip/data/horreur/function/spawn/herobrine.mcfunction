data modify storage horreur:t s set value {c:"herobrine",a0:-45,a1:45,d0:22,d1:36}
scoreboard players set #lim hr.tmp 24
scoreboard players set #h hr.tmp 2
scoreboard players set #surf hr.tmp 1
function horreur:spawn/placer
