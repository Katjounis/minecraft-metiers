summon minecraft:marker ~ ~ ~ {Tags:["hr.pt"]}
scoreboard players set #essai hr.tmp 0
function horreur:spawn/essai with storage horreur:t s
kill @e[type=minecraft:marker,tag=hr.pt]
