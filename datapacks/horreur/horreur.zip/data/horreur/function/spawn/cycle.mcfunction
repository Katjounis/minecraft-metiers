scoreboard players set #s hr.tmp 0
execute if score #actif hr.cfg matches 1 as @a[gamemode=!spectator] at @s unless score @s hr.cd matches 1.. run function horreur:spawn/tenter
