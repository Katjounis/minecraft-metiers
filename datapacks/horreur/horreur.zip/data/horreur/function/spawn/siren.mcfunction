data modify storage horreur:t s set value {c:"siren",a0:0,a1:359,d0:40,d1:56}
scoreboard players set #lim hr.tmp 24
scoreboard players set #h hr.tmp 8
scoreboard players set #surf hr.tmp 1
function horreur:spawn/placer
