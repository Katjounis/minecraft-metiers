data modify storage horreur:t s set value {c:"clown",a0:0,a1:359,d0:10,d1:18}
scoreboard players set #lim hr.tmp 6
scoreboard players set #h hr.tmp 2
scoreboard players set #surf hr.tmp 0
function horreur:spawn/placer
