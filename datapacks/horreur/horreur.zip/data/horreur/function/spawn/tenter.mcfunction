# Une seule creature a la fois autour d'un joueur
execute if entity @e[tag=hr.c,distance=..128] run return 0
execute store result score #r hr.tmp run random value 1..1000
scoreboard players set #c4 hr.tmp 4
execute if score #sang hr.cfg matches 1 run scoreboard players operation #r hr.tmp /= #c4 hr.tmp
execute if function horreur:lieu/slender if predicate horreur:lieu/foret run scoreboard players remove #r hr.tmp 30
execute if function horreur:lieu/slender run scoreboard players operation #r hr.tmp -= #ch_slender hr.cfg
execute if score #r hr.tmp matches ..0 run return run function horreur:spawn/slender
execute if function horreur:lieu/herobrine run scoreboard players operation #r hr.tmp -= #ch_herobrine hr.cfg
execute if score #r hr.tmp matches ..0 run return run function horreur:spawn/herobrine
execute if function horreur:lieu/siren if predicate horreur:lieu/plaine run scoreboard players remove #r hr.tmp 20
execute if function horreur:lieu/siren run scoreboard players operation #r hr.tmp -= #ch_siren hr.cfg
execute if score #r hr.tmp matches ..0 run return run function horreur:spawn/siren
execute if function horreur:lieu/nonne run scoreboard players operation #r hr.tmp -= #ch_nonne hr.cfg
execute if score #r hr.tmp matches ..0 run return run function horreur:spawn/nonne
execute if function horreur:lieu/clown run scoreboard players operation #r hr.tmp -= #ch_clown hr.cfg
execute if score #r hr.tmp matches ..0 run return run function horreur:spawn/clown
execute if function horreur:lieu/pinhead run scoreboard players operation #r hr.tmp -= #ch_pinhead hr.cfg
execute if score #r hr.tmp matches ..0 run return run function horreur:spawn/pinhead
execute if function horreur:lieu/dame if predicate horreur:lieu/route run scoreboard players remove #r hr.tmp 30
execute if function horreur:lieu/dame run scoreboard players operation #r hr.tmp -= #ch_dame hr.cfg
execute if score #r hr.tmp matches ..0 run return run function horreur:spawn/dame
execute if function horreur:lieu/loup run scoreboard players operation #r hr.tmp -= #ch_loup hr.cfg
execute if score #r hr.tmp matches ..0 run return run function horreur:spawn/loup
execute if function horreur:lieu/feu run scoreboard players operation #r hr.tmp -= #ch_feu hr.cfg
execute if score #r hr.tmp matches ..0 run return run function horreur:spawn/feu
execute if function horreur:lieu/rodeur run scoreboard players operation #r hr.tmp -= #ch_rodeur hr.cfg
execute if score #r hr.tmp matches ..0 run return run function horreur:spawn/rodeur
