playsound minecraft:entity.witch.celebrate hostile @a[distance=..24] ~ ~ ~ 1.5 1.7
execute as @p[distance=..20,gamemode=!spectator] at @s run summon minecraft:marker ~ ~0.1 ~ {Tags:["hr.e","hr.zone","hr.z.ballon","hr.zneuf"]}
execute if score @s hr.rg matches 6.. as @p[distance=..20,gamemode=!spectator] at @s positioned ~3 ~ ~1 run summon minecraft:marker ~ ~0.1 ~ {Tags:["hr.e","hr.zone","hr.z.ballon","hr.zneuf"]}
execute if score @s hr.rg matches 6.. as @p[distance=..20,gamemode=!spectator] at @s positioned ~-2 ~ ~-3 run summon minecraft:marker ~ ~0.1 ~ {Tags:["hr.e","hr.zone","hr.z.ballon","hr.zneuf"]}
scoreboard players operation @e[type=minecraft:marker,tag=hr.zneuf] hr.pw = @s hr.pw
scoreboard players set @e[type=minecraft:marker,tag=hr.zneuf] hr.t 35
tag @e[type=minecraft:marker,tag=hr.zneuf] remove hr.zneuf
