scoreboard players set #d hr.tmp 4
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:magic"
execute as @a[distance=..20,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
effect give @s minecraft:regeneration 5 3 true
execute as @a[distance=..20,gamemode=!spectator] at @s run particle minecraft:soul ~ ~1 ~ 0.3 0.6 0.3 0.05 10
tellraw @a[distance=..48] {"text":"Le Croque-mitaine dévore vos âmes !","color":"dark_red"}
