effect give @a[distance=..8,gamemode=!spectator] minecraft:levitation 2 1 true
effect give @a[distance=..8,gamemode=!spectator] minecraft:blindness 3 0 true
playsound minecraft:block.amethyst_block.chime hostile @a[distance=..16] ~ ~ ~ 1.5 0.5
