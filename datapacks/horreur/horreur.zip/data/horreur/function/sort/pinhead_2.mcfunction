effect give @a[distance=..10,gamemode=!spectator] minecraft:slowness 3 6 true
execute as @a[distance=..10,gamemode=!spectator] at @s run function horreur:sort/attirer
execute as @a[distance=..10,gamemode=!spectator] at @s run particle minecraft:dust{color:[0.45,0.45,0.52],scale:1.2} ~ ~1 ~ 0.6 1 0.6 0 30
playsound minecraft:block.chain.place hostile @a[distance=..24] ~ ~ ~ 2 0.5
scoreboard players set #d hr.tmp 4
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:magic"
execute as @a[distance=..10,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
