summon minecraft:vex ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Sœur damnée","color":"#d0c8a0"},DeathLootTable:"minecraft:empty",PersistenceRequired:1b,attributes:[{id:"minecraft:max_health",base:8d}],Health:8f}
summon minecraft:vex ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Sœur damnée","color":"#d0c8a0"},DeathLootTable:"minecraft:empty",PersistenceRequired:1b,attributes:[{id:"minecraft:max_health",base:8d}],Health:8f}
playsound minecraft:entity.vex.charge hostile @a[distance=..24] ~ ~ ~ 1.5 0.5
scoreboard players set @e[tag=hr.serv,distance=..4] hr.age 0
