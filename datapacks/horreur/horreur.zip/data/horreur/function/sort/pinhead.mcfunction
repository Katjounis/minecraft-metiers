function horreur:rig/pinhead/jouer_attaque
execute if score #r hr.tmp matches 1 run return run function horreur:sort/pinhead_1
execute if score #r hr.tmp matches 2 run return run function horreur:sort/pinhead_2
execute if score #r hr.tmp matches 3 run return run function horreur:sort/pinhead_3
