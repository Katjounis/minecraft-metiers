execute anchored eyes facing entity @e[tag=hr.lanceur,limit=1] eyes run particle minecraft:dust{color:[0.15,0.15,0.15],scale:1} ^ ^ ^1 0.2 0.2 0.2 0 6
execute facing entity @e[tag=hr.lanceur,limit=1] feet rotated ~ 0 positioned ^ ^ ^2 if block ~ ~ ~ #horreur:passable if block ~ ~1 ~ #horreur:passable run tp @s ~ ~ ~
