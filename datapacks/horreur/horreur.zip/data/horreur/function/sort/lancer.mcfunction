scoreboard players set @s hr.s 0
execute store result score #r hr.tmp run random value 1..3
execute if score #r hr.tmp matches 3 unless score @s hr.rg matches 6.. run scoreboard players set #r hr.tmp 2
execute if score #r hr.tmp matches 2 unless score @s hr.rg matches 2.. run scoreboard players set #r hr.tmp 1
tag @s add hr.lanceur
execute if entity @s[tag=hr.c.slender] run function horreur:sort/slender
execute if entity @s[tag=hr.c.herobrine] run function horreur:sort/herobrine
execute if entity @s[tag=hr.c.siren] run function horreur:sort/siren
execute if entity @s[tag=hr.c.nonne] run function horreur:sort/nonne
execute if entity @s[tag=hr.c.clown] run function horreur:sort/clown
execute if entity @s[tag=hr.c.pinhead] run function horreur:sort/pinhead
execute if entity @s[tag=hr.c.dame] run function horreur:sort/dame
execute if entity @s[tag=hr.c.loup] run function horreur:sort/loup
execute if entity @s[tag=hr.c.feu] run function horreur:sort/feu
execute if entity @s[tag=hr.c.rodeur] run function horreur:sort/rodeur
execute if entity @s[tag=hr.c.croque] run function horreur:sort/croque
tag @s remove hr.lanceur
