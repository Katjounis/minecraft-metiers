execute as @a[distance=..12,gamemode=!spectator] at @s run function horreur:sort/attirer
effect give @a[distance=..12,gamemode=!spectator] minecraft:wither 4 1 true
effect give @a[distance=..12,gamemode=!spectator] minecraft:slowness 3 1 true
playsound minecraft:entity.enderman.scream hostile @a[distance=..24] ~ ~ ~ 1.5 0.5
scoreboard players set #d hr.tmp 3
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:magic"
execute as @a[distance=..12,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
