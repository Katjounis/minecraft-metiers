function horreur:rig/rodeur/jouer_attaque
execute if score #r hr.tmp matches 1 run return run function horreur:sort/rodeur_1
execute if score #r hr.tmp matches 2 run return run function horreur:sort/rodeur_2
execute if score #r hr.tmp matches 3 run return run function horreur:sort/rodeur_3
