scoreboard players set #h hr.tmp 8
function horreur:sort/bond
execute if score #ok hr.tmp matches 1 at @s run function horreur:c/siren_frappe
