function horreur:rig/croque/jouer_attaque
execute store result score #r hr.tmp run random value 1..7
execute if score #r hr.tmp matches 7 unless score @s hr.rg matches 8.. run scoreboard players set #r hr.tmp 4
execute if score #r hr.tmp matches 6 unless score @s hr.rg matches 4.. run scoreboard players set #r hr.tmp 5
execute if score #r hr.tmp matches 1 run return run function horreur:sort/croque_1
execute if score #r hr.tmp matches 2 run return run function horreur:sort/croque_2
execute if score #r hr.tmp matches 3 run return run function horreur:sort/croque_3
execute if score #r hr.tmp matches 4 run return run function horreur:sort/croque_4
execute if score #r hr.tmp matches 5 run return run function horreur:sort/croque_5
execute if score #r hr.tmp matches 6 run return run function horreur:sort/croque_6
execute if score #r hr.tmp matches 7 run return run function horreur:sort/croque_7
