particle minecraft:enchanted_hit ~ ~1.2 ~ 0.5 0.6 0.5 0.1 12
scoreboard players set #d hr.tmp 3
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:thorns"
execute as @a[tag=hr.rip] run function horreur:sort/frapper with storage horreur:t d
