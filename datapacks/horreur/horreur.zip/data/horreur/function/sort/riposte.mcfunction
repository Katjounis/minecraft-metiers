advancement revoke @s only horreur:riposte
execute store result score #r hr.tmp run random value 1..3
execute unless score #r hr.tmp matches 1 run return 0
tag @s add hr.rip
execute as @e[tag=hr.ronce,sort=nearest,limit=1,distance=..48] at @s run function horreur:sort/riposte_c
tag @s remove hr.rip
