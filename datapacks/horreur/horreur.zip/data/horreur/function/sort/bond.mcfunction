scoreboard players set #ok hr.tmp 0
scoreboard players set #lim hr.tmp 6
summon minecraft:marker ~ ~ ~ {Tags:["hr.pt2"]}
execute as @p[distance=5..30,gamemode=!spectator] at @s facing entity @e[tag=hr.lanceur,limit=1] feet rotated ~ 0 positioned ^ ^ ^2 run tp @e[type=minecraft:marker,tag=hr.pt2,limit=1] ~ ~ ~
execute as @e[type=minecraft:marker,tag=hr.pt2,limit=1] at @s run function horreur:sol/trouver
execute if score #ok hr.tmp matches 1 run particle minecraft:cloud ~ ~0.5 ~ 0.6 0.3 0.6 0.05 20
execute if score #ok hr.tmp matches 1 run function horreur:c/teleporter
kill @e[type=minecraft:marker,tag=hr.pt2]
