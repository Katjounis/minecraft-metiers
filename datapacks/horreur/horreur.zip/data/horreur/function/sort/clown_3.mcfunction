execute as @a[distance=..12,gamemode=!spectator] at @s run tp @s ~ ~ ~ ~180 ~
effect give @a[distance=..12,gamemode=!spectator] minecraft:nausea 10 0 true
effect give @a[distance=..12,gamemode=!spectator] minecraft:slowness 4 2 true
playsound horreur:clown.rire hostile @a[distance=..32] ~ ~ ~ 2 1
scoreboard players set #d hr.tmp 3
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:magic"
execute as @a[distance=..12,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
