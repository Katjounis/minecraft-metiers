function horreur:c/rodeur_cache
execute at @s run effect give @a[distance=..8,gamemode=!spectator] minecraft:blindness 2 0 true
