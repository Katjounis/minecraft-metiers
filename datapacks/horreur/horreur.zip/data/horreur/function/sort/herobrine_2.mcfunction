effect give @a[distance=..16,gamemode=!spectator] minecraft:weakness 8 1 true
effect give @a[distance=..16,gamemode=!spectator] minecraft:hunger 8 2 true
effect give @a[distance=..16,gamemode=!spectator] minecraft:mining_fatigue 8 1 true
execute as @a[distance=..16,gamemode=!spectator] at @s run particle minecraft:witch ~ ~1 ~ 0.4 0.8 0.4 0 20
playsound minecraft:entity.illusioner.cast_spell hostile @a[distance=..24] ~ ~ ~ 1.5 0.6
scoreboard players set #d hr.tmp 3
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:magic"
execute as @a[distance=..16,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
