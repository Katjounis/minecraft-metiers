$execute if entity @e[tag=hr.c,distance=..96] run return run damage @s $(n) $(t) by @e[tag=hr.c,sort=nearest,limit=1]
$damage @s $(n) $(t)
