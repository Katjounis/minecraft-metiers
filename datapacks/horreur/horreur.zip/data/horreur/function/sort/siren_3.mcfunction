summon minecraft:husk ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Écho de la sirène","color":"#a08a6a"},DeathLootTable:"minecraft:empty",PersistenceRequired:1b,attributes:[{id:"minecraft:max_health",base:24d},{id:"minecraft:spawn_reinforcements",base:0d}],Health:24f,Silent:1b}
summon minecraft:husk ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Écho de la sirène","color":"#a08a6a"},DeathLootTable:"minecraft:empty",PersistenceRequired:1b,attributes:[{id:"minecraft:max_health",base:24d},{id:"minecraft:spawn_reinforcements",base:0d}],Health:24f,Silent:1b}
playsound minecraft:entity.warden.ambient hostile @a[distance=..32] ~ ~ ~ 2 0.6
scoreboard players set @e[tag=hr.serv,distance=..4] hr.age 0
