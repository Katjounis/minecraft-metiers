effect give @a[distance=..10,gamemode=!spectator] minecraft:wither 5 1 true
effect give @a[distance=..10,gamemode=!spectator] minecraft:blindness 2 0 true
particle minecraft:soul ~ ~1 ~ 2 1 2 0.02 30
playsound minecraft:entity.evoker.prepare_wololo hostile @a[distance=..24] ~ ~ ~ 1 0.5
scoreboard players set #d hr.tmp 4
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:magic"
execute as @a[distance=..10,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
