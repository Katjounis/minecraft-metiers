playsound minecraft:entity.ghast.scream hostile @a[distance=..32] ~ ~ ~ 2 0.6
effect give @a[distance=..14,gamemode=!spectator] minecraft:darkness 5 0 true
particle minecraft:sonic_boom ~ ~1.4 ~ 0 0 0 0 1
scoreboard players set #d hr.tmp 5
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:magic"
execute as @a[distance=..14,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
