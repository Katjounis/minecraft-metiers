summon minecraft:vex ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Lueur","color":"#7fd8ff"},DeathLootTable:"minecraft:empty",PersistenceRequired:1b,attributes:[{id:"minecraft:max_health",base:6d}],Health:6f}
summon minecraft:vex ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Lueur","color":"#7fd8ff"},DeathLootTable:"minecraft:empty",PersistenceRequired:1b,attributes:[{id:"minecraft:max_health",base:6d}],Health:6f}
particle minecraft:soul_fire_flame ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
scoreboard players set @e[tag=hr.serv,distance=..4] hr.age 0
