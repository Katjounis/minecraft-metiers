function horreur:c/pct
execute if score #hp hr.tmp matches 31.. run return 0
tag @s add hr.enrage
effect give @s minecraft:strength infinite 0 true
effect give @s minecraft:speed infinite 0 true
scoreboard players operation @s hr.scd *= #k2 hr.cfg
scoreboard players operation @s hr.scd /= #k3 hr.cfg
particle minecraft:angry_villager ~ ~2 ~ 0.6 0.6 0.6 0 12
playsound minecraft:entity.ravager.roar hostile @a[distance=..32] ~ ~ ~ 1.5 0.7
