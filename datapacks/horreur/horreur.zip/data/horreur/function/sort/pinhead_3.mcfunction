function horreur:c/pct
execute if score #hp hr.tmp matches 26.. run return run function horreur:sort/pinhead_1
execute if score @s hr.etat matches 2.. run return run function horreur:sort/pinhead_1
function horreur:c/pinhead_cenobites
scoreboard players set @s hr.etat 2
