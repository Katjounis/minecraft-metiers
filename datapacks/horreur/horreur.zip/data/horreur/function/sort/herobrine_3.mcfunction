playsound minecraft:block.beacon.power_select hostile @a[distance=..24] ~ ~ ~ 1 1.4
execute as @p[distance=..20,gamemode=!spectator] at @s run summon minecraft:marker ~ ~0.1 ~ {Tags:["hr.e","hr.zone","hr.z.foudre","hr.zneuf"]}
execute as @p[distance=..20,gamemode=!spectator] at @s positioned ~3 ~ ~0 run summon minecraft:marker ~ ~0.1 ~ {Tags:["hr.e","hr.zone","hr.z.foudre","hr.zneuf"]}
execute as @p[distance=..20,gamemode=!spectator] at @s positioned ~-3 ~ ~0 run summon minecraft:marker ~ ~0.1 ~ {Tags:["hr.e","hr.zone","hr.z.foudre","hr.zneuf"]}
execute as @p[distance=..20,gamemode=!spectator] at @s positioned ~0 ~ ~3 run summon minecraft:marker ~ ~0.1 ~ {Tags:["hr.e","hr.zone","hr.z.foudre","hr.zneuf"]}
execute as @p[distance=..20,gamemode=!spectator] at @s positioned ~0 ~ ~-3 run summon minecraft:marker ~ ~0.1 ~ {Tags:["hr.e","hr.zone","hr.z.foudre","hr.zneuf"]}
scoreboard players operation @e[type=minecraft:marker,tag=hr.zneuf] hr.pw = @s hr.pw
scoreboard players set @e[type=minecraft:marker,tag=hr.zneuf] hr.t 30
tag @e[type=minecraft:marker,tag=hr.zneuf] remove hr.zneuf
