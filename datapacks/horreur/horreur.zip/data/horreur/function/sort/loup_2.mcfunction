effect give @s minecraft:speed 8 1 true
effect give @s minecraft:strength 8 1 true
particle minecraft:angry_villager ~ ~2 ~ 0.5 0.5 0.5 0 8
playsound horreur:loup.hurlement hostile @a[distance=..64] ~ ~ ~ 2.5 1
