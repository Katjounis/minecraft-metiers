execute as @a[distance=..16,gamemode=!spectator,sort=nearest,limit=2] at @s run summon minecraft:marker ~ ~0.1 ~ {Tags:["hr.e","hr.zone","hr.z.crochet","hr.zneuf"]}
scoreboard players operation @e[type=minecraft:marker,tag=hr.zneuf] hr.pw = @s hr.pw
scoreboard players set @e[type=minecraft:marker,tag=hr.zneuf] hr.t 20
tag @e[type=minecraft:marker,tag=hr.zneuf] remove hr.zneuf
