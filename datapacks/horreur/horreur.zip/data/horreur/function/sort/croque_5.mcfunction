particle minecraft:sweep_attack ~ ~1.5 ~ 2.5 0.3 2.5 0 12
playsound minecraft:entity.player.attack.sweep hostile @a[distance=..24] ~ ~ ~ 2 0.5
scoreboard players set #d hr.tmp 10
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:mob_attack"
execute as @a[distance=..5,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
