tellraw @a[distance=..48] {"text":"Le sol saigne sous vos pieds...","color":"dark_red"}
execute as @a[distance=..24,gamemode=!spectator] at @s run summon minecraft:marker ~ ~0.1 ~ {Tags:["hr.e","hr.zone","hr.z.cauchemar","hr.zneuf"]}
scoreboard players operation @e[type=minecraft:marker,tag=hr.zneuf] hr.pw = @s hr.pw
scoreboard players set @e[type=minecraft:marker,tag=hr.zneuf] hr.t 30
tag @e[type=minecraft:marker,tag=hr.zneuf] remove hr.zneuf
