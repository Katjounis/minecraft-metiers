effect give @a[distance=..20,gamemode=!spectator] minecraft:darkness 8 0 true
effect give @s minecraft:speed 6 1 true
playsound minecraft:ambient.cave hostile @a[distance=..24] ~ ~ ~ 2 0.5
