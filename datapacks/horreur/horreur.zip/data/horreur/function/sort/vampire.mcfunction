effect give @s minecraft:regeneration 3 2 true
particle minecraft:damage_indicator ~ ~1.5 ~ 0.4 0.6 0.4 0.1 6
