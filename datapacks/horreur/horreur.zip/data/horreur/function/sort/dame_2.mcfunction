effect give @a[distance=..8,gamemode=!spectator] minecraft:slowness 4 3 true
execute as @a[distance=..8,gamemode=!spectator] at @s run particle minecraft:snowflake ~ ~1 ~ 0.5 1 0.5 0.02 30
playsound minecraft:block.powder_snow.break hostile @a[distance=..24] ~ ~ ~ 2 0.5
scoreboard players set #d hr.tmp 4
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:freeze"
execute as @a[distance=..8,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
