effect give @a[distance=..16,gamemode=!spectator] minecraft:slowness 3 6 true
effect give @a[distance=..16,gamemode=!spectator] minecraft:darkness 6 0 true
execute as @a[distance=..16,gamemode=!spectator] at @s run particle minecraft:dust{color:[0.3,0.0,0.05],scale:1.5} ~ ~1 ~ 0.7 1 0.7 0 30
tellraw @a[distance=..48] {"text":"La terreur vous cloue sur place !","color":"dark_red"}
