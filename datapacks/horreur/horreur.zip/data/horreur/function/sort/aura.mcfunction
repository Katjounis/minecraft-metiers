scoreboard players add @s hr.au 5
execute if score @s hr.au matches ..19 run return 0
scoreboard players set @s hr.au 0
execute if entity @a[distance=..4,gamemode=!spectator] run particle minecraft:soul ~ ~1 ~ 2 0.5 2 0.01 12
scoreboard players set #d hr.tmp 2
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:wither"
execute as @a[distance=..4,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
