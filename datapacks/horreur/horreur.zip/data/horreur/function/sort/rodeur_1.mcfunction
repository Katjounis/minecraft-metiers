scoreboard players set #d hr.tmp 5
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:mob_attack"
execute as @a[distance=..4,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
effect give @a[distance=..4,gamemode=!spectator] minecraft:wither 4 0 true
particle minecraft:sweep_attack ~ ~1 ~ 1 0.3 1 0 3
