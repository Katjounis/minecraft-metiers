summon minecraft:vex ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Ombre","color":"dark_gray"},DeathLootTable:"minecraft:empty",attributes:[{id:"minecraft:max_health",base:10d}],Health:10f}
summon minecraft:vex ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Ombre","color":"dark_gray"},DeathLootTable:"minecraft:empty",attributes:[{id:"minecraft:max_health",base:10d}],Health:10f}
execute if score @s hr.rg matches 8.. run summon minecraft:vex ~ ~1 ~ {Tags:["hr.e","hr.serv"],CustomName:{"text":"Ombre","color":"dark_gray"},DeathLootTable:"minecraft:empty",attributes:[{id:"minecraft:max_health",base:10d}],Health:10f}
tellraw @a[distance=..48] {"text":"Le Croque-mitaine appelle ses ombres !","color":"dark_red"}
