scoreboard players set #h hr.tmp 2
function horreur:sort/bond
execute if score #ok hr.tmp matches 1 at @s run function horreur:sort/loup_1b
