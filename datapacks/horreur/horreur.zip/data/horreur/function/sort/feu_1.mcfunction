scoreboard players set #d hr.tmp 3
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:freeze"
execute as @a[distance=..7,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
effect give @a[distance=..7,gamemode=!spectator] minecraft:slowness 4 1 true
particle minecraft:snowflake ~ ~0.5 ~ 2 1 2 0.02 40
