effect give @a[distance=..24,gamemode=!spectator] minecraft:darkness 8 0 true
effect give @a[distance=..24,gamemode=!spectator] minecraft:slowness 4 1 true
playsound horreur:croque.grondement hostile @a[distance=..48] ~ ~ ~ 2.5 1
