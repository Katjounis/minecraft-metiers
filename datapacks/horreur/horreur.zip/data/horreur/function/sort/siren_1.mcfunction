playsound horreur:siren.sirene hostile @a[distance=..64] ~ ~6 ~ 4 1.3
execute as @a[distance=..20,gamemode=!spectator] at @s run particle minecraft:sonic_boom ~ ~1 ~ 0 0 0 0 1
effect give @a[distance=..20,gamemode=!spectator] minecraft:nausea 6 0 true
effect give @a[distance=..20,gamemode=!spectator] minecraft:slowness 3 1 true
scoreboard players set #d hr.tmp 6
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:sonic_boom"
execute as @a[distance=..20,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
