effect give @s minecraft:regeneration 4 2 true
particle minecraft:enchant ~ ~1.5 ~ 0.5 0.8 0.5 0.5 40
effect give @a[distance=..12,gamemode=!spectator] minecraft:weakness 6 0 true
playsound horreur:nonne.murmure hostile @a[distance=..20] ~ ~ ~ 1.5 0.8
