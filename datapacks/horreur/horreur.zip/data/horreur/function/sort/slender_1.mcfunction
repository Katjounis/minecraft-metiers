execute as @a[distance=..20,gamemode=!spectator] at @s run playsound horreur:slender.statique hostile @s ~ ~ ~ 1 0.7
effect give @a[distance=..20,gamemode=!spectator] minecraft:nausea 6 0 true
execute as @a[distance=..20,gamemode=!spectator] at @s run particle minecraft:glow ~ ~1.5 ~ 0.4 0.4 0.4 0 10
scoreboard players set #d hr.tmp 4
scoreboard players operation #d hr.tmp *= @s hr.pw
scoreboard players operation #d hr.tmp /= #k100 hr.cfg
execute store result storage horreur:t d.n int 1 run scoreboard players get #d hr.tmp
data modify storage horreur:t d.t set value "minecraft:magic"
execute as @a[distance=..20,gamemode=!spectator] run function horreur:sort/frapper with storage horreur:t d
