execute on vehicle run function horreur:vis/ancien_mob
kill @s
