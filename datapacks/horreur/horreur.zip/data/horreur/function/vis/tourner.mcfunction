data modify storage horreur:t r set from entity @s Rotation[0]
execute on passengers if entity @s[tag=hr.vis] run data modify entity @s Rotation[0] set from storage horreur:t r
