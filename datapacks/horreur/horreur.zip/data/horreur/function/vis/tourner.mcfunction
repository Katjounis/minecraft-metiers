data modify storage horreur:t r set value [0f,0f]
data modify storage horreur:t r[0] set from entity @s Rotation[0]
execute on passengers if entity @s[tag=hr.vis] run data modify entity @s Rotation set from storage horreur:t r
