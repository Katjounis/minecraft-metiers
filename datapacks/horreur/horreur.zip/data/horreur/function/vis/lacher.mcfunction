tag @s remove hr.vis
tag @s add hr.envol
scoreboard players set @s hr.t 0
