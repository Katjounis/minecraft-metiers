execute on passengers run kill @s
execute at @s run tp @s ~ -1000 ~
kill @s
