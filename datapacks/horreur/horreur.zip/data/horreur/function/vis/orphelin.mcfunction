execute if entity @s[tag=hr.ballon] run return run function horreur:vis/lacher
particle minecraft:large_smoke ~ ~1 ~ 0.3 0.8 0.3 0.02 25
kill @s
