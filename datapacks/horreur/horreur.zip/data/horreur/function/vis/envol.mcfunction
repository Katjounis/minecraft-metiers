tp @s ~ ~0.12 ~
scoreboard players add @s hr.t 1
execute if score @s hr.t matches 100.. run kill @s
