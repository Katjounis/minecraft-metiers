execute unless score @s c.vu matches 1 run function commerce:joueur/arrivee
execute unless score @s c.nom matches 1 run function commerce:joueur/inscrire
execute unless score @s c.init matches 1 run function commerce:joueur/init_paliers
function commerce:joueur/paliers
