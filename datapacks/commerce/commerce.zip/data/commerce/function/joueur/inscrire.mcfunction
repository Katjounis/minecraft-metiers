summon minecraft:item_display ~ ~ ~ {Tags:["commerce.tete"]}
loot replace entity @e[type=minecraft:item_display,tag=commerce.tete,limit=1,sort=nearest] contents loot commerce:tete
data modify storage commerce:t nom set value "Joueur"
data modify storage commerce:t nom set from entity @e[type=minecraft:item_display,tag=commerce.tete,limit=1,sort=nearest] item.components."minecraft:profile".name
kill @e[type=minecraft:item_display,tag=commerce.tete]
scoreboard players set @s c.nom 1
execute if data storage commerce:t {nom:"Joueur"} run return 0
execute store result storage commerce:t nj.id int 1 run scoreboard players get @s m.id
data modify storage commerce:t nj.nom set from storage commerce:t nom
function commerce:joueur/registre with storage commerce:t nj
