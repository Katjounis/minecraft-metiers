scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.b_lvl
scoreboard players operation #k c.t /= #10 c.g
execute if score #k c.t > @s c.pp_b run function commerce:prime/palier_b
execute if score #k c.t < @s c.pp_b run scoreboard players operation @s c.pp_b = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.f_lvl
scoreboard players operation #k c.t /= #10 c.g
execute if score #k c.t > @s c.pp_f run function commerce:prime/palier_f
execute if score #k c.t < @s c.pp_f run scoreboard players operation @s c.pp_f = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.m_lvl
scoreboard players operation #k c.t /= #10 c.g
execute if score #k c.t > @s c.pp_m run function commerce:prime/palier_m
execute if score #k c.t < @s c.pp_m run scoreboard players operation @s c.pp_m = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.c_lvl
scoreboard players operation #k c.t /= #10 c.g
execute if score #k c.t > @s c.pp_c run function commerce:prime/palier_c
execute if score #k c.t < @s c.pp_c run scoreboard players operation @s c.pp_c = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.p_lvl
scoreboard players operation #k c.t /= #10 c.g
execute if score #k c.t > @s c.pp_p run function commerce:prime/palier_p
execute if score #k c.t < @s c.pp_p run scoreboard players operation @s c.pp_p = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.e_lvl
scoreboard players operation #k c.t /= #10 c.g
execute if score #k c.t > @s c.pp_e run function commerce:prime/palier_e
execute if score #k c.t < @s c.pp_e run scoreboard players operation @s c.pp_e = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.n_lvl
scoreboard players operation #k c.t /= #10 c.g
execute if score #k c.t > @s c.pp_n run function commerce:prime/palier_n
execute if score #k c.t < @s c.pp_n run scoreboard players operation @s c.pp_n = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.x_lvl
scoreboard players operation #k c.t /= #10 c.g
execute if score #k c.t > @s c.pp_x run function commerce:prime/palier_x
execute if score #k c.t < @s c.pp_x run scoreboard players operation @s c.pp_x = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.t_lvl
scoreboard players operation #k c.t /= #10 c.g
execute if score #k c.t > @s c.pp_t run function commerce:prime/palier_t
execute if score #k c.t < @s c.pp_t run scoreboard players operation @s c.pp_t = #k c.t
