scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.b_lvl
scoreboard players operation #k c.t /= #10 c.g
scoreboard players operation @s c.pp_b = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.f_lvl
scoreboard players operation #k c.t /= #10 c.g
scoreboard players operation @s c.pp_f = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.m_lvl
scoreboard players operation #k c.t /= #10 c.g
scoreboard players operation @s c.pp_m = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.c_lvl
scoreboard players operation #k c.t /= #10 c.g
scoreboard players operation @s c.pp_c = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.p_lvl
scoreboard players operation #k c.t /= #10 c.g
scoreboard players operation @s c.pp_p = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.e_lvl
scoreboard players operation #k c.t /= #10 c.g
scoreboard players operation @s c.pp_e = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.n_lvl
scoreboard players operation #k c.t /= #10 c.g
scoreboard players operation @s c.pp_n = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.x_lvl
scoreboard players operation #k c.t /= #10 c.g
scoreboard players operation @s c.pp_x = #k c.t
scoreboard players set #k c.t 0
scoreboard players operation #k c.t = @s m.t_lvl
scoreboard players operation #k c.t /= #10 c.g
scoreboard players operation @s c.pp_t = #k c.t
scoreboard players set @s c.init 1
