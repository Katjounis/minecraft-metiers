$data remove storage commerce:j l[{nom:"$(nom)"}]
$data modify storage commerce:j l append value {id:$(id),nom:"$(nom)"}
