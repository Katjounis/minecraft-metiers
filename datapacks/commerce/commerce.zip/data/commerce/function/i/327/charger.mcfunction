scoreboard players set #b c.t 2700
scoreboard players set #V c.t 64
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"slime_block",n:"Bloc de slime",i3:"327",cn:"Élevage et chasse",cb:111}
scoreboard players operation #p c.t = #slime_block c.p
scoreboard players operation #h c.t = #slime_block c.h
scoreboard players operation #vs c.t = #slime_block c.vs
scoreboard players operation #as c.t = #slime_block c.as
scoreboard players operation #e c.t = #slime_block c.ev
scoreboard players add #e c.t 1000
