scoreboard players operation #cooked_chicken c.p = #p c.t
scoreboard players operation #cooked_chicken c.h = #h c.t
scoreboard players operation #cooked_chicken c.vs = #vs c.t
scoreboard players operation #cooked_chicken c.as = #as c.t
scoreboard players operation #cooked_chicken c.ev = #e c.t
scoreboard players remove #cooked_chicken c.ev 1000
