scoreboard players operation #acacia_sapling c.p = #p c.t
scoreboard players operation #acacia_sapling c.h = #h c.t
scoreboard players operation #acacia_sapling c.vs = #vs c.t
scoreboard players operation #acacia_sapling c.as = #as c.t
scoreboard players operation #acacia_sapling c.ev = #e c.t
scoreboard players remove #acacia_sapling c.ev 1000
