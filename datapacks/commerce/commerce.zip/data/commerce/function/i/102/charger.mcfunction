scoreboard players set #b c.t 180
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cooked_chicken",n:"Poulet rôti",i3:"102",cn:"Cuisine",cb:17}
scoreboard players operation #p c.t = #cooked_chicken c.p
scoreboard players operation #h c.t = #cooked_chicken c.h
scoreboard players operation #vs c.t = #cooked_chicken c.vs
scoreboard players operation #as c.t = #cooked_chicken c.as
scoreboard players operation #e c.t = #cooked_chicken c.ev
scoreboard players add #e c.t 1000
