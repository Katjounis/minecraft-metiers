scoreboard players set #b c.t 20
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"acacia_sapling",n:"Pousse d'acacia",i3:"102",cn:"Planches et feuillage",cb:1041}
scoreboard players operation #p c.t = #acacia_sapling c.p
scoreboard players operation #h c.t = #acacia_sapling c.h
scoreboard players operation #vs c.t = #acacia_sapling c.vs
scoreboard players operation #as c.t = #acacia_sapling c.as
scoreboard players operation #e c.t = #acacia_sapling c.ev
scoreboard players add #e c.t 1000
