scoreboard players operation #cooked_mutton c.p = #p c.t
scoreboard players operation #cooked_mutton c.h = #h c.t
scoreboard players operation #cooked_mutton c.vs = #vs c.t
scoreboard players operation #cooked_mutton c.as = #as c.t
scoreboard players operation #cooked_mutton c.ev = #e c.t
scoreboard players remove #cooked_mutton c.ev 1000
