scoreboard players set #b c.t 130
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cooked_mutton",n:"Mouton cuit",i3:"356",cn:"Cuisine",cb:1130}
scoreboard players operation #p c.t = #cooked_mutton c.p
scoreboard players operation #h c.t = #cooked_mutton c.h
scoreboard players operation #vs c.t = #cooked_mutton c.vs
scoreboard players operation #as c.t = #cooked_mutton c.as
scoreboard players operation #e c.t = #cooked_mutton c.ev
scoreboard players add #e c.t 1000
