scoreboard players set #b c.t 8
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"diorite",n:"Diorite",i3:"011",cn:"Pierres",cb:101}
scoreboard players operation #p c.t = #diorite c.p
scoreboard players operation #h c.t = #diorite c.h
scoreboard players operation #vs c.t = #diorite c.vs
scoreboard players operation #as c.t = #diorite c.as
scoreboard players operation #e c.t = #diorite c.ev
scoreboard players add #e c.t 1000
