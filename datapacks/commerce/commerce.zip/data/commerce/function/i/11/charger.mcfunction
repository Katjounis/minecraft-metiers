scoreboard players set #b c.t 8
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"basalt",n:"Basalte",i3:"011",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #basalt c.p
scoreboard players operation #h c.t = #basalt c.h
scoreboard players operation #vs c.t = #basalt c.vs
scoreboard players operation #as c.t = #basalt c.as
scoreboard players operation #e c.t = #basalt c.ev
scoreboard players add #e c.t 1000
