scoreboard players operation #diorite c.p = #p c.t
scoreboard players operation #diorite c.h = #h c.t
scoreboard players operation #diorite c.vs = #vs c.t
scoreboard players operation #diorite c.as = #as c.t
scoreboard players operation #diorite c.ev = #e c.t
scoreboard players remove #diorite c.ev 1000
