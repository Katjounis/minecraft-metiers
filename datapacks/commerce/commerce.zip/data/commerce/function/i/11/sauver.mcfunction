scoreboard players operation #basalt c.p = #p c.t
scoreboard players operation #basalt c.h = #h c.t
scoreboard players operation #basalt c.vs = #vs c.t
scoreboard players operation #basalt c.as = #as c.t
scoreboard players operation #basalt c.ev = #e c.t
scoreboard players remove #basalt c.ev 1000
