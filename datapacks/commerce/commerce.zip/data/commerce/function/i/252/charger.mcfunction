scoreboard players set #b c.t 8
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"nether_bricks",n:"Briques du Nether",i3:"252",cn:"Nether et End",cb:109}
scoreboard players operation #p c.t = #nether_bricks c.p
scoreboard players operation #h c.t = #nether_bricks c.h
scoreboard players operation #vs c.t = #nether_bricks c.vs
scoreboard players operation #as c.t = #nether_bricks c.as
scoreboard players operation #e c.t = #nether_bricks c.ev
scoreboard players add #e c.t 1000
