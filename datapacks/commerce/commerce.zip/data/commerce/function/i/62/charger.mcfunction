scoreboard players set #b c.t 10
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"soul_sand",n:"Sable des âmes",i3:"062",cn:"Terre et glace",cb:1021}
scoreboard players operation #p c.t = #soul_sand c.p
scoreboard players operation #h c.t = #soul_sand c.h
scoreboard players operation #vs c.t = #soul_sand c.vs
scoreboard players operation #as c.t = #soul_sand c.as
scoreboard players operation #e c.t = #soul_sand c.ev
scoreboard players add #e c.t 1000
