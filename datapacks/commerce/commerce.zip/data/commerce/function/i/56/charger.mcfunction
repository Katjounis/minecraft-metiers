scoreboard players set #b c.t 120
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"clay",n:"Bloc d'argile",i3:"056",cn:"Terre et glace",cb:102}
scoreboard players operation #p c.t = #clay c.p
scoreboard players operation #h c.t = #clay c.h
scoreboard players operation #vs c.t = #clay c.vs
scoreboard players operation #as c.t = #clay c.as
scoreboard players operation #e c.t = #clay c.ev
scoreboard players add #e c.t 1000
