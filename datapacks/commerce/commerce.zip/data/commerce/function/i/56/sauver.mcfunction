scoreboard players operation #clay c.p = #p c.t
scoreboard players operation #clay c.h = #h c.t
scoreboard players operation #clay c.vs = #vs c.t
scoreboard players operation #clay c.as = #as c.t
scoreboard players operation #clay c.ev = #e c.t
scoreboard players remove #clay c.ev 1000
