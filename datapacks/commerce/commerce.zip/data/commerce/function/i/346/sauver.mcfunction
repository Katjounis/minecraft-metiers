scoreboard players operation #sea_pickle c.p = #p c.t
scoreboard players operation #sea_pickle c.h = #h c.t
scoreboard players operation #sea_pickle c.vs = #vs c.t
scoreboard players operation #sea_pickle c.as = #as c.t
scoreboard players operation #sea_pickle c.ev = #e c.t
scoreboard players remove #sea_pickle c.ev 1000
