scoreboard players set #b c.t 30
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 0
data modify storage commerce:t it set value {id:"sea_pickle",n:"Cornichon de mer",i3:"346",cn:"Pêche",cb:1121}
scoreboard players operation #p c.t = #sea_pickle c.p
scoreboard players operation #h c.t = #sea_pickle c.h
scoreboard players operation #vs c.t = #sea_pickle c.vs
scoreboard players operation #as c.t = #sea_pickle c.as
scoreboard players operation #e c.t = #sea_pickle c.ev
scoreboard players add #e c.t 1000
