scoreboard players set #b c.t 250
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"warped_stem",n:"Tige biscornue",i3:"084",cn:"Bûches",cb:1032}
scoreboard players operation #p c.t = #warped_stem c.p
scoreboard players operation #h c.t = #warped_stem c.h
scoreboard players operation #vs c.t = #warped_stem c.vs
scoreboard players operation #as c.t = #warped_stem c.as
scoreboard players operation #e c.t = #warped_stem c.ev
scoreboard players add #e c.t 1000
