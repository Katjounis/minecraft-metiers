scoreboard players set #b c.t 800
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"blaze_rod",n:"Bâton de blaze",i3:"084",cn:"Élevage et chasse",cb:15}
scoreboard players operation #p c.t = #blaze_rod c.p
scoreboard players operation #h c.t = #blaze_rod c.h
scoreboard players operation #vs c.t = #blaze_rod c.vs
scoreboard players operation #as c.t = #blaze_rod c.as
scoreboard players operation #e c.t = #blaze_rod c.ev
scoreboard players add #e c.t 1000
