scoreboard players operation #warped_stem c.p = #p c.t
scoreboard players operation #warped_stem c.h = #h c.t
scoreboard players operation #warped_stem c.vs = #vs c.t
scoreboard players operation #warped_stem c.as = #as c.t
scoreboard players operation #warped_stem c.ev = #e c.t
scoreboard players remove #warped_stem c.ev 1000
