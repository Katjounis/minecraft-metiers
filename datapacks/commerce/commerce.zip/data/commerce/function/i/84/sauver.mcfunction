scoreboard players operation #blaze_rod c.p = #p c.t
scoreboard players operation #blaze_rod c.h = #h c.t
scoreboard players operation #blaze_rod c.vs = #vs c.t
scoreboard players operation #blaze_rod c.as = #as c.t
scoreboard players operation #blaze_rod c.ev = #e c.t
scoreboard players remove #blaze_rod c.ev 1000
