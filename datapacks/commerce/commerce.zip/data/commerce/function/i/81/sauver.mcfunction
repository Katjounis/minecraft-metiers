scoreboard players operation #spider_eye c.p = #p c.t
scoreboard players operation #spider_eye c.h = #h c.t
scoreboard players operation #spider_eye c.vs = #vs c.t
scoreboard players operation #spider_eye c.as = #as c.t
scoreboard players operation #spider_eye c.ev = #e c.t
scoreboard players remove #spider_eye c.ev 1000
