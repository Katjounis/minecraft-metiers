scoreboard players set #b c.t 123
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cyan_terracotta",n:"Terre cuite cyan",i3:"180",cn:"Béton et terre cuite",cb:106}
scoreboard players operation #p c.t = #cyan_terracotta c.p
scoreboard players operation #h c.t = #cyan_terracotta c.h
scoreboard players operation #vs c.t = #cyan_terracotta c.vs
scoreboard players operation #as c.t = #cyan_terracotta c.as
scoreboard players operation #e c.t = #cyan_terracotta c.ev
scoreboard players add #e c.t 1000
