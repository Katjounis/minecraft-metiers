scoreboard players set #b c.t 10
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"bamboo",n:"Bambou",i3:"066",cn:"Agriculture",cb:14}
scoreboard players operation #p c.t = #bamboo c.p
scoreboard players operation #h c.t = #bamboo c.h
scoreboard players operation #vs c.t = #bamboo c.vs
scoreboard players operation #as c.t = #bamboo c.as
scoreboard players operation #e c.t = #bamboo c.ev
scoreboard players add #e c.t 1000
