scoreboard players set #b c.t 30
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"end_stone_bricks",n:"Briques de l'End",i3:"274",cn:"Nether et End",cb:1092}
scoreboard players operation #p c.t = #end_stone_bricks c.p
scoreboard players operation #h c.t = #end_stone_bricks c.h
scoreboard players operation #vs c.t = #end_stone_bricks c.vs
scoreboard players operation #as c.t = #end_stone_bricks c.as
scoreboard players operation #e c.t = #end_stone_bricks c.ev
scoreboard players add #e c.t 1000
