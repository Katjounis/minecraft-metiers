scoreboard players set #b c.t 10
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"tuff",n:"Tuf",i3:"021",cn:"Pierres",cb:1012}
scoreboard players operation #p c.t = #tuff c.p
scoreboard players operation #h c.t = #tuff c.h
scoreboard players operation #vs c.t = #tuff c.vs
scoreboard players operation #as c.t = #tuff c.as
scoreboard players operation #e c.t = #tuff c.ev
scoreboard players add #e c.t 1000
