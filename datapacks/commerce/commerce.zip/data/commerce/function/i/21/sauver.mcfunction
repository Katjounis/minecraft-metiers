scoreboard players operation #tuff c.p = #p c.t
scoreboard players operation #tuff c.h = #h c.t
scoreboard players operation #tuff c.vs = #vs c.t
scoreboard players operation #tuff c.as = #as c.t
scoreboard players operation #tuff c.ev = #e c.t
scoreboard players remove #tuff c.ev 1000
