scoreboard players set #b c.t 28
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cyan_dye",n:"Teinture cyan",i3:"147",cn:"Laines et teintures",cb:1052}
scoreboard players operation #p c.t = #cyan_dye c.p
scoreboard players operation #h c.t = #cyan_dye c.h
scoreboard players operation #vs c.t = #cyan_dye c.vs
scoreboard players operation #as c.t = #cyan_dye c.as
scoreboard players operation #e c.t = #cyan_dye c.ev
scoreboard players add #e c.t 1000
