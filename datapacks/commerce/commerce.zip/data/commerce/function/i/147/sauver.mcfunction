scoreboard players operation #cyan_dye c.p = #p c.t
scoreboard players operation #cyan_dye c.h = #h c.t
scoreboard players operation #cyan_dye c.vs = #vs c.t
scoreboard players operation #cyan_dye c.as = #as c.t
scoreboard players operation #cyan_dye c.ev = #e c.t
scoreboard players remove #cyan_dye c.ev 1000
