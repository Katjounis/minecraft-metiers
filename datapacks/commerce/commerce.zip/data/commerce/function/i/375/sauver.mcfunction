scoreboard players operation #flower_pot c.p = #p c.t
scoreboard players operation #flower_pot c.h = #h c.t
scoreboard players operation #flower_pot c.vs = #vs c.t
scoreboard players operation #flower_pot c.as = #as c.t
scoreboard players operation #flower_pot c.ev = #e c.t
scoreboard players remove #flower_pot c.ev 1000
