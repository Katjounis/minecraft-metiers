scoreboard players set #b c.t 90
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"flower_pot",n:"Pot de fleurs",i3:"375",cn:"Utilitaires",cb:114}
scoreboard players operation #p c.t = #flower_pot c.p
scoreboard players operation #h c.t = #flower_pot c.h
scoreboard players operation #vs c.t = #flower_pot c.vs
scoreboard players operation #as c.t = #flower_pot c.as
scoreboard players operation #e c.t = #flower_pot c.ev
scoreboard players add #e c.t 1000
