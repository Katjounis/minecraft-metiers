scoreboard players operation #pumpkin c.p = #p c.t
scoreboard players operation #pumpkin c.h = #h c.t
scoreboard players operation #pumpkin c.vs = #vs c.t
scoreboard players operation #pumpkin c.as = #as c.t
scoreboard players operation #pumpkin c.ev = #e c.t
scoreboard players remove #pumpkin c.ev 1000
