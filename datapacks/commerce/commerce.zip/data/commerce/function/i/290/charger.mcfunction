scoreboard players set #b c.t 120
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"pumpkin",n:"Citrouille",i3:"290",cn:"Agriculture",cb:1101}
scoreboard players operation #p c.t = #pumpkin c.p
scoreboard players operation #h c.t = #pumpkin c.h
scoreboard players operation #vs c.t = #pumpkin c.vs
scoreboard players operation #as c.t = #pumpkin c.as
scoreboard players operation #e c.t = #pumpkin c.ev
scoreboard players add #e c.t 1000
