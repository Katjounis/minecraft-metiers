scoreboard players set #b c.t 100
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"white_wool",n:"Laine blanche",i3:"067",cn:"Élevage et chasse",cb:15}
scoreboard players operation #p c.t = #white_wool c.p
scoreboard players operation #h c.t = #white_wool c.h
scoreboard players operation #vs c.t = #white_wool c.vs
scoreboard players operation #as c.t = #white_wool c.as
scoreboard players operation #e c.t = #white_wool c.ev
scoreboard players add #e c.t 1000
