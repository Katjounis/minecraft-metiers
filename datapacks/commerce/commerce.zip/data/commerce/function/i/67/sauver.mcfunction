scoreboard players operation #white_wool c.p = #p c.t
scoreboard players operation #white_wool c.h = #h c.t
scoreboard players operation #white_wool c.vs = #vs c.t
scoreboard players operation #white_wool c.as = #as c.t
scoreboard players operation #white_wool c.ev = #e c.t
scoreboard players remove #white_wool c.ev 1000
