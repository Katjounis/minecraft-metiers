scoreboard players set #b c.t 117
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"purple_wool",n:"Laine violette",i3:"132",cn:"Laines et teintures",cb:1051}
scoreboard players operation #p c.t = #purple_wool c.p
scoreboard players operation #h c.t = #purple_wool c.h
scoreboard players operation #vs c.t = #purple_wool c.vs
scoreboard players operation #as c.t = #purple_wool c.as
scoreboard players operation #e c.t = #purple_wool c.ev
scoreboard players add #e c.t 1000
