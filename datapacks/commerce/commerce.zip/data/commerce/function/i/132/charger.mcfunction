scoreboard players set #b c.t 200000
scoreboard players set #V c.t 2
scoreboard players set #mj c.t 8
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"elytra",n:"Élytres",i3:"132",cn:"Trésors",cb:19}
scoreboard players operation #p c.t = #elytra c.p
scoreboard players operation #h c.t = #elytra c.h
scoreboard players operation #vs c.t = #elytra c.vs
scoreboard players operation #as c.t = #elytra c.as
scoreboard players operation #e c.t = #elytra c.ev
scoreboard players add #e c.t 1000
