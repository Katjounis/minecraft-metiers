scoreboard players operation #purple_wool c.p = #p c.t
scoreboard players operation #purple_wool c.h = #h c.t
scoreboard players operation #purple_wool c.vs = #vs c.t
scoreboard players operation #purple_wool c.as = #as c.t
scoreboard players operation #purple_wool c.ev = #e c.t
scoreboard players remove #purple_wool c.ev 1000
