scoreboard players operation #elytra c.p = #p c.t
scoreboard players operation #elytra c.h = #h c.t
scoreboard players operation #elytra c.vs = #vs c.t
scoreboard players operation #elytra c.as = #as c.t
scoreboard players operation #elytra c.ev = #e c.t
scoreboard players remove #elytra c.ev 1000
