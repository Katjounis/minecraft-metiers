scoreboard players operation #trident c.p = #p c.t
scoreboard players operation #trident c.h = #h c.t
scoreboard players operation #trident c.vs = #vs c.t
scoreboard players operation #trident c.as = #as c.t
scoreboard players operation #trident c.ev = #e c.t
scoreboard players remove #trident c.ev 1000
