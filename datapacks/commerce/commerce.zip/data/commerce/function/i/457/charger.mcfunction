scoreboard players set #b c.t 40000
scoreboard players set #V c.t 4
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"trident",n:"Trident",i3:"457",cn:"Trésors",cb:1152}
scoreboard players operation #p c.t = #trident c.p
scoreboard players operation #h c.t = #trident c.h
scoreboard players operation #vs c.t = #trident c.vs
scoreboard players operation #as c.t = #trident c.as
scoreboard players operation #e c.t = #trident c.ev
scoreboard players add #e c.t 1000
