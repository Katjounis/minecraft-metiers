scoreboard players set #b c.t 100
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"redstone_torch",n:"Torche de redstone",i3:"388",cn:"Utilitaires",cb:1142}
scoreboard players operation #p c.t = #redstone_torch c.p
scoreboard players operation #h c.t = #redstone_torch c.h
scoreboard players operation #vs c.t = #redstone_torch c.vs
scoreboard players operation #as c.t = #redstone_torch c.as
scoreboard players operation #e c.t = #redstone_torch c.ev
scoreboard players add #e c.t 1000
