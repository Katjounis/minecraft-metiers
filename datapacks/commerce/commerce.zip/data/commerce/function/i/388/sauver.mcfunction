scoreboard players operation #redstone_torch c.p = #p c.t
scoreboard players operation #redstone_torch c.h = #h c.t
scoreboard players operation #redstone_torch c.vs = #vs c.t
scoreboard players operation #redstone_torch c.as = #as c.t
scoreboard players operation #redstone_torch c.ev = #e c.t
scoreboard players remove #redstone_torch c.ev 1000
