scoreboard players set #b c.t 100
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"amethyst_shard",n:"Éclat d'améthyste",i3:"051",cn:"Minerais",cb:13}
scoreboard players operation #p c.t = #amethyst_shard c.p
scoreboard players operation #h c.t = #amethyst_shard c.h
scoreboard players operation #vs c.t = #amethyst_shard c.vs
scoreboard players operation #as c.t = #amethyst_shard c.as
scoreboard players operation #e c.t = #amethyst_shard c.ev
scoreboard players add #e c.t 1000
