scoreboard players operation #amethyst_shard c.p = #p c.t
scoreboard players operation #amethyst_shard c.h = #h c.t
scoreboard players operation #amethyst_shard c.vs = #vs c.t
scoreboard players operation #amethyst_shard c.as = #as c.t
scoreboard players operation #amethyst_shard c.ev = #e c.t
scoreboard players remove #amethyst_shard c.ev 1000
