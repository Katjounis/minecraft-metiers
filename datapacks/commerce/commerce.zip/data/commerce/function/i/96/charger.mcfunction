scoreboard players set #b c.t 300
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"bread",n:"Pain",i3:"096",cn:"Cuisine",cb:17}
scoreboard players operation #p c.t = #bread c.p
scoreboard players operation #h c.t = #bread c.h
scoreboard players operation #vs c.t = #bread c.vs
scoreboard players operation #as c.t = #bread c.as
scoreboard players operation #e c.t = #bread c.ev
scoreboard players add #e c.t 1000
