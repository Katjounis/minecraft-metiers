scoreboard players operation #bread c.p = #p c.t
scoreboard players operation #bread c.h = #h c.t
scoreboard players operation #bread c.vs = #vs c.t
scoreboard players operation #bread c.as = #as c.t
scoreboard players operation #bread c.ev = #e c.t
scoreboard players remove #bread c.ev 1000
