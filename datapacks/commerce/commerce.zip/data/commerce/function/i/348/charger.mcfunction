scoreboard players set #b c.t 50
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 0
scoreboard players set #cher c.t 0
data modify storage commerce:t it set value {id:"baked_potato",n:"Pomme de terre cuite",i3:"348",cn:"Cuisine",cb:1130}
scoreboard players operation #p c.t = #baked_potato c.p
scoreboard players operation #h c.t = #baked_potato c.h
scoreboard players operation #vs c.t = #baked_potato c.vs
scoreboard players operation #as c.t = #baked_potato c.as
scoreboard players operation #e c.t = #baked_potato c.ev
scoreboard players add #e c.t 1000
