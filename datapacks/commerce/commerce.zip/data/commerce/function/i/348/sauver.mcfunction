scoreboard players operation #baked_potato c.p = #p c.t
scoreboard players operation #baked_potato c.h = #h c.t
scoreboard players operation #baked_potato c.vs = #vs c.t
scoreboard players operation #baked_potato c.as = #as c.t
scoreboard players operation #baked_potato c.ev = #e c.t
scoreboard players remove #baked_potato c.ev 1000
