scoreboard players set #b c.t 100
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"prismarine_shard",n:"Éclat de prismarine",i3:"092",cn:"Pêche",cb:16}
scoreboard players operation #p c.t = #prismarine_shard c.p
scoreboard players operation #h c.t = #prismarine_shard c.h
scoreboard players operation #vs c.t = #prismarine_shard c.vs
scoreboard players operation #as c.t = #prismarine_shard c.as
scoreboard players operation #e c.t = #prismarine_shard c.ev
scoreboard players add #e c.t 1000
