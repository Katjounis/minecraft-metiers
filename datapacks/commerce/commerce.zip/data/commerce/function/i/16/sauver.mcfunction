scoreboard players operation #sand c.p = #p c.t
scoreboard players operation #sand c.h = #h c.t
scoreboard players operation #sand c.vs = #vs c.t
scoreboard players operation #sand c.as = #as c.t
scoreboard players operation #sand c.ev = #e c.t
scoreboard players remove #sand c.ev 1000
