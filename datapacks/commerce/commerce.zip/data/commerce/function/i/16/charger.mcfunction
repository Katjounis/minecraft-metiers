scoreboard players set #b c.t 8
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"sand",n:"Sable",i3:"016",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #sand c.p
scoreboard players operation #h c.t = #sand c.h
scoreboard players operation #vs c.t = #sand c.vs
scoreboard players operation #as c.t = #sand c.as
scoreboard players operation #e c.t = #sand c.ev
scoreboard players add #e c.t 1000
