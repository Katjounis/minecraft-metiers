scoreboard players operation #poppy c.p = #p c.t
scoreboard players operation #poppy c.h = #h c.t
scoreboard players operation #poppy c.vs = #vs c.t
scoreboard players operation #poppy c.as = #as c.t
scoreboard players operation #poppy c.ev = #e c.t
scoreboard players remove #poppy c.ev 1000
