scoreboard players set #b c.t 122
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"pink_terracotta",n:"Terre cuite rose",i3:"177",cn:"Béton et terre cuite",cb:106}
scoreboard players operation #p c.t = #pink_terracotta c.p
scoreboard players operation #h c.t = #pink_terracotta c.h
scoreboard players operation #vs c.t = #pink_terracotta c.vs
scoreboard players operation #as c.t = #pink_terracotta c.as
scoreboard players operation #e c.t = #pink_terracotta c.ev
scoreboard players add #e c.t 1000
