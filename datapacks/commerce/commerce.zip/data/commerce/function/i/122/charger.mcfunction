scoreboard players set #b c.t 260000
scoreboard players set #V c.t 4
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"netherite_ingot",n:"Lingot de netherite",i3:"122",cn:"Trésors",cb:19}
scoreboard players operation #p c.t = #netherite_ingot c.p
scoreboard players operation #h c.t = #netherite_ingot c.h
scoreboard players operation #vs c.t = #netherite_ingot c.vs
scoreboard players operation #as c.t = #netherite_ingot c.as
scoreboard players operation #e c.t = #netherite_ingot c.ev
scoreboard players add #e c.t 1000
