scoreboard players operation #netherite_ingot c.p = #p c.t
scoreboard players operation #netherite_ingot c.h = #h c.t
scoreboard players operation #netherite_ingot c.vs = #vs c.t
scoreboard players operation #netherite_ingot c.as = #as c.t
scoreboard players operation #netherite_ingot c.ev = #e c.t
scoreboard players remove #netherite_ingot c.ev 1000
