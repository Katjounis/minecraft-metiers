scoreboard players operation #chest c.p = #p c.t
scoreboard players operation #chest c.h = #h c.t
scoreboard players operation #chest c.vs = #vs c.t
scoreboard players operation #chest c.as = #as c.t
scoreboard players operation #chest c.ev = #e c.t
scoreboard players remove #chest c.ev 1000
