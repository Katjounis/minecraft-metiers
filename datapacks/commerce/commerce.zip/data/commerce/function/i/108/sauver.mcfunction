scoreboard players operation #mangrove_propagule c.p = #p c.t
scoreboard players operation #mangrove_propagule c.h = #h c.t
scoreboard players operation #mangrove_propagule c.vs = #vs c.t
scoreboard players operation #mangrove_propagule c.as = #as c.t
scoreboard players operation #mangrove_propagule c.ev = #e c.t
scoreboard players remove #mangrove_propagule c.ev 1000
