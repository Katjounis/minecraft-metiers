scoreboard players set #b c.t 20
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"mangrove_propagule",n:"Propagule de palétuvier",i3:"108",cn:"Planches et feuillage",cb:1042}
scoreboard players operation #p c.t = #mangrove_propagule c.p
scoreboard players operation #h c.t = #mangrove_propagule c.h
scoreboard players operation #vs c.t = #mangrove_propagule c.vs
scoreboard players operation #as c.t = #mangrove_propagule c.as
scoreboard players operation #e c.t = #mangrove_propagule c.ev
scoreboard players add #e c.t 1000
