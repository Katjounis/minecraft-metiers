scoreboard players set #b c.t 100
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"chest",n:"Coffre",i3:"108",cn:"Utilitaires",cb:18}
scoreboard players operation #p c.t = #chest c.p
scoreboard players operation #h c.t = #chest c.h
scoreboard players operation #vs c.t = #chest c.vs
scoreboard players operation #as c.t = #chest c.as
scoreboard players operation #e c.t = #chest c.ev
scoreboard players add #e c.t 1000
