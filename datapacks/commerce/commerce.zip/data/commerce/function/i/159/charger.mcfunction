scoreboard players set #b c.t 23
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"lime_concrete",n:"Béton vert clair",i3:"159",cn:"Béton et terre cuite",cb:1060}
scoreboard players operation #p c.t = #lime_concrete c.p
scoreboard players operation #h c.t = #lime_concrete c.h
scoreboard players operation #vs c.t = #lime_concrete c.vs
scoreboard players operation #as c.t = #lime_concrete c.as
scoreboard players operation #e c.t = #lime_concrete c.ev
scoreboard players add #e c.t 1000
