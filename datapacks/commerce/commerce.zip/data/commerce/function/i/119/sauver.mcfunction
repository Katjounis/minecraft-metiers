scoreboard players operation #emerald c.p = #p c.t
scoreboard players operation #emerald c.h = #h c.t
scoreboard players operation #emerald c.vs = #vs c.t
scoreboard players operation #emerald c.as = #as c.t
scoreboard players operation #emerald c.ev = #e c.t
scoreboard players remove #emerald c.ev 1000
