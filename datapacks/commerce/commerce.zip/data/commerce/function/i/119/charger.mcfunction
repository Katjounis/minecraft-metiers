scoreboard players set #b c.t 45
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"bamboo_planks",n:"Planches de bambou",i3:"119",cn:"Planches et feuillage",cb:104}
scoreboard players operation #p c.t = #bamboo_planks c.p
scoreboard players operation #h c.t = #bamboo_planks c.h
scoreboard players operation #vs c.t = #bamboo_planks c.vs
scoreboard players operation #as c.t = #bamboo_planks c.as
scoreboard players operation #e c.t = #bamboo_planks c.ev
scoreboard players add #e c.t 1000
