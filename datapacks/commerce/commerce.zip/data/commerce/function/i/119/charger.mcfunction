scoreboard players set #b c.t 1500
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 9
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"emerald",n:"Émeraude",i3:"119",cn:"Trésors",cb:19}
scoreboard players operation #p c.t = #emerald c.p
scoreboard players operation #h c.t = #emerald c.h
scoreboard players operation #vs c.t = #emerald c.vs
scoreboard players operation #as c.t = #emerald c.as
scoreboard players operation #e c.t = #emerald c.ev
scoreboard players add #e c.t 1000
