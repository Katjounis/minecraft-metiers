scoreboard players set #b c.t 800
scoreboard players set #V c.t 64
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"honey_block",n:"Bloc de miel",i3:"316",cn:"Élevage et chasse",cb:111}
scoreboard players operation #p c.t = #honey_block c.p
scoreboard players operation #h c.t = #honey_block c.h
scoreboard players operation #vs c.t = #honey_block c.vs
scoreboard players operation #as c.t = #honey_block c.as
scoreboard players operation #e c.t = #honey_block c.ev
scoreboard players add #e c.t 1000
