scoreboard players set #b c.t 10
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"tuff_bricks",n:"Briques de tuf",i3:"023",cn:"Pierres",cb:1012}
scoreboard players operation #p c.t = #tuff_bricks c.p
scoreboard players operation #h c.t = #tuff_bricks c.h
scoreboard players operation #vs c.t = #tuff_bricks c.vs
scoreboard players operation #as c.t = #tuff_bricks c.as
scoreboard players operation #e c.t = #tuff_bricks c.ev
scoreboard players add #e c.t 1000
