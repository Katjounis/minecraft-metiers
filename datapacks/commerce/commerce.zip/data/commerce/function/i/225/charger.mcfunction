scoreboard players set #b c.t 1800
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"copper_block",n:"Bloc de cuivre",i3:"225",cn:"Minerais et métaux",cb:1080}
scoreboard players operation #p c.t = #copper_block c.p
scoreboard players operation #h c.t = #copper_block c.h
scoreboard players operation #vs c.t = #copper_block c.vs
scoreboard players operation #as c.t = #copper_block c.as
scoreboard players operation #e c.t = #copper_block c.ev
scoreboard players add #e c.t 1000
