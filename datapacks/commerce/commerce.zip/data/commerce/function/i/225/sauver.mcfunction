scoreboard players operation #copper_block c.p = #p c.t
scoreboard players operation #copper_block c.h = #h c.t
scoreboard players operation #copper_block c.vs = #vs c.t
scoreboard players operation #copper_block c.as = #as c.t
scoreboard players operation #copper_block c.ev = #e c.t
scoreboard players remove #copper_block c.ev 1000
