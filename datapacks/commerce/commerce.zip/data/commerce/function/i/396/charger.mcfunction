scoreboard players set #b c.t 130
scoreboard players set #V c.t 64
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"lead",n:"Laisse",i3:"396",cn:"Utilitaires",cb:114}
scoreboard players operation #p c.t = #lead c.p
scoreboard players operation #h c.t = #lead c.h
scoreboard players operation #vs c.t = #lead c.vs
scoreboard players operation #as c.t = #lead c.as
scoreboard players operation #e c.t = #lead c.ev
scoreboard players add #e c.t 1000
