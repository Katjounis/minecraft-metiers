scoreboard players set #b c.t 1400
scoreboard players set #V c.t 32
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 0
scoreboard players set #cher c.t 0
data modify storage commerce:t it set value {id:"saddle",n:"Selle",i3:"396",cn:"Utilitaires",cb:1143}
scoreboard players operation #p c.t = #saddle c.p
scoreboard players operation #h c.t = #saddle c.h
scoreboard players operation #vs c.t = #saddle c.vs
scoreboard players operation #as c.t = #saddle c.as
scoreboard players operation #e c.t = #saddle c.ev
scoreboard players add #e c.t 1000
