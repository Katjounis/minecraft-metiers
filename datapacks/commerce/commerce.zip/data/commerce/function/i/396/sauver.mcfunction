scoreboard players operation #lead c.p = #p c.t
scoreboard players operation #lead c.h = #h c.t
scoreboard players operation #lead c.vs = #vs c.t
scoreboard players operation #lead c.as = #as c.t
scoreboard players operation #lead c.ev = #e c.t
scoreboard players remove #lead c.ev 1000
