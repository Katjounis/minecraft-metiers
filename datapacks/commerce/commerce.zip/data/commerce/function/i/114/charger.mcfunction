scoreboard players set #b c.t 3500
scoreboard players set #V c.t 64
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"hopper",n:"Entonnoir",i3:"114",cn:"Utilitaires",cb:18}
scoreboard players operation #p c.t = #hopper c.p
scoreboard players operation #h c.t = #hopper c.h
scoreboard players operation #vs c.t = #hopper c.vs
scoreboard players operation #as c.t = #hopper c.as
scoreboard players operation #e c.t = #hopper c.ev
scoreboard players add #e c.t 1000
