scoreboard players operation #hopper c.p = #p c.t
scoreboard players operation #hopper c.h = #h c.t
scoreboard players operation #hopper c.vs = #vs c.t
scoreboard players operation #hopper c.as = #as c.t
scoreboard players operation #hopper c.ev = #e c.t
scoreboard players remove #hopper c.ev 1000
