scoreboard players operation #pumpkin_pie c.p = #p c.t
scoreboard players operation #pumpkin_pie c.h = #h c.t
scoreboard players operation #pumpkin_pie c.vs = #vs c.t
scoreboard players operation #pumpkin_pie c.as = #as c.t
scoreboard players operation #pumpkin_pie c.ev = #e c.t
scoreboard players remove #pumpkin_pie c.ev 1000
