scoreboard players set #b c.t 250
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"pumpkin_pie",n:"Tarte à la citrouille",i3:"098",cn:"Cuisine",cb:17}
scoreboard players operation #p c.t = #pumpkin_pie c.p
scoreboard players operation #h c.t = #pumpkin_pie c.h
scoreboard players operation #vs c.t = #pumpkin_pie c.vs
scoreboard players operation #as c.t = #pumpkin_pie c.as
scoreboard players operation #e c.t = #pumpkin_pie c.ev
scoreboard players add #e c.t 1000
