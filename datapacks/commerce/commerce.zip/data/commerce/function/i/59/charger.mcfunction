scoreboard players set #b c.t 20
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"melon_slice",n:"Tranche de pastèque",i3:"059",cn:"Agriculture",cb:14}
scoreboard players operation #p c.t = #melon_slice c.p
scoreboard players operation #h c.t = #melon_slice c.h
scoreboard players operation #vs c.t = #melon_slice c.vs
scoreboard players operation #as c.t = #melon_slice c.as
scoreboard players operation #e c.t = #melon_slice c.ev
scoreboard players add #e c.t 1000
