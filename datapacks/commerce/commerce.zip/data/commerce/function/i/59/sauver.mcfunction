scoreboard players operation #melon_slice c.p = #p c.t
scoreboard players operation #melon_slice c.h = #h c.t
scoreboard players operation #melon_slice c.vs = #vs c.t
scoreboard players operation #melon_slice c.as = #as c.t
scoreboard players operation #melon_slice c.ev = #e c.t
scoreboard players remove #melon_slice c.ev 1000
