scoreboard players set #b c.t 100
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"bricks",n:"Briques",i3:"024",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #bricks c.p
scoreboard players operation #h c.t = #bricks c.h
scoreboard players operation #vs c.t = #bricks c.vs
scoreboard players operation #as c.t = #bricks c.as
scoreboard players operation #e c.t = #bricks c.ev
scoreboard players add #e c.t 1000
