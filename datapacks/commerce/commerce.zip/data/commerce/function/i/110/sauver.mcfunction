scoreboard players operation #ladder c.p = #p c.t
scoreboard players operation #ladder c.h = #h c.t
scoreboard players operation #ladder c.vs = #vs c.t
scoreboard players operation #ladder c.as = #as c.t
scoreboard players operation #ladder c.ev = #e c.t
scoreboard players remove #ladder c.ev 1000
