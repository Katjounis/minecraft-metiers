scoreboard players operation #wildflowers c.p = #p c.t
scoreboard players operation #wildflowers c.h = #h c.t
scoreboard players operation #wildflowers c.vs = #vs c.t
scoreboard players operation #wildflowers c.as = #as c.t
scoreboard players operation #wildflowers c.ev = #e c.t
scoreboard players remove #wildflowers c.ev 1000
