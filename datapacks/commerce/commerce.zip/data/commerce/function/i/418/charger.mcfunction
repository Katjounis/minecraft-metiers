scoreboard players set #b c.t 20
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"wildflowers",n:"Fleurs sauvages",i3:"418",cn:"Fleurs et plantes",cb:116}
scoreboard players operation #p c.t = #wildflowers c.p
scoreboard players operation #h c.t = #wildflowers c.h
scoreboard players operation #vs c.t = #wildflowers c.vs
scoreboard players operation #as c.t = #wildflowers c.as
scoreboard players operation #e c.t = #wildflowers c.ev
scoreboard players add #e c.t 1000
