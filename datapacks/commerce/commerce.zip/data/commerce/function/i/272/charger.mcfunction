scoreboard players set #b c.t 120
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"bone_block",n:"Bloc d'os",i3:"272",cn:"Nether et End",cb:109}
scoreboard players operation #p c.t = #bone_block c.p
scoreboard players operation #h c.t = #bone_block c.h
scoreboard players operation #vs c.t = #bone_block c.vs
scoreboard players operation #as c.t = #bone_block c.as
scoreboard players operation #e c.t = #bone_block c.ev
scoreboard players add #e c.t 1000
