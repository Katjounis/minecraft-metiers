scoreboard players operation #cooked_salmon c.p = #p c.t
scoreboard players operation #cooked_salmon c.h = #h c.t
scoreboard players operation #cooked_salmon c.vs = #vs c.t
scoreboard players operation #cooked_salmon c.as = #as c.t
scoreboard players operation #cooked_salmon c.ev = #e c.t
scoreboard players remove #cooked_salmon c.ev 1000
