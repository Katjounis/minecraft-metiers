scoreboard players set #b c.t 250
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cooked_salmon",n:"Saumon cuit",i3:"103",cn:"Cuisine",cb:17}
scoreboard players operation #p c.t = #cooked_salmon c.p
scoreboard players operation #h c.t = #cooked_salmon c.h
scoreboard players operation #vs c.t = #cooked_salmon c.vs
scoreboard players operation #as c.t = #cooked_salmon c.as
scoreboard players operation #e c.t = #cooked_salmon c.ev
scoreboard players add #e c.t 1000
