scoreboard players set #b c.t 18
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"scaffolding",n:"Échafaudage",i3:"371",cn:"Utilitaires",cb:1141}
scoreboard players operation #p c.t = #scaffolding c.p
scoreboard players operation #h c.t = #scaffolding c.h
scoreboard players operation #vs c.t = #scaffolding c.vs
scoreboard players operation #as c.t = #scaffolding c.as
scoreboard players operation #e c.t = #scaffolding c.ev
scoreboard players add #e c.t 1000
