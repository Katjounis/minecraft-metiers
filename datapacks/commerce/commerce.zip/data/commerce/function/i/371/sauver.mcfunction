scoreboard players operation #scaffolding c.p = #p c.t
scoreboard players operation #scaffolding c.h = #h c.t
scoreboard players operation #scaffolding c.vs = #vs c.t
scoreboard players operation #scaffolding c.as = #as c.t
scoreboard players operation #scaffolding c.ev = #e c.t
scoreboard players remove #scaffolding c.ev 1000
