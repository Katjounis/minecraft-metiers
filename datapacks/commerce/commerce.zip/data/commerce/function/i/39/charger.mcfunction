scoreboard players set #b c.t 100
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"apple",n:"Pomme",i3:"039",cn:"Bois",cb:12}
scoreboard players operation #p c.t = #apple c.p
scoreboard players operation #h c.t = #apple c.h
scoreboard players operation #vs c.t = #apple c.vs
scoreboard players operation #as c.t = #apple c.as
scoreboard players operation #e c.t = #apple c.ev
scoreboard players add #e c.t 1000
