scoreboard players set #b c.t 400
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
scoreboard players set #cher c.t 1
data modify storage commerce:t it set value {id:"prismarine",n:"Prismarine",i3:"039",cn:"Pierres",cb:1013}
scoreboard players operation #p c.t = #prismarine c.p
scoreboard players operation #h c.t = #prismarine c.h
scoreboard players operation #vs c.t = #prismarine c.vs
scoreboard players operation #as c.t = #prismarine c.as
scoreboard players operation #e c.t = #prismarine c.ev
scoreboard players add #e c.t 1000
