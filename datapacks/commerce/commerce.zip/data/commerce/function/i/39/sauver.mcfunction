scoreboard players operation #prismarine c.p = #p c.t
scoreboard players operation #prismarine c.h = #h c.t
scoreboard players operation #prismarine c.vs = #vs c.t
scoreboard players operation #prismarine c.as = #as c.t
scoreboard players operation #prismarine c.ev = #e c.t
scoreboard players remove #prismarine c.ev 1000
