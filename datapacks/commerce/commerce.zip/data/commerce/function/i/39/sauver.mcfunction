scoreboard players operation #apple c.p = #p c.t
scoreboard players operation #apple c.h = #h c.t
scoreboard players operation #apple c.vs = #vs c.t
scoreboard players operation #apple c.as = #as c.t
scoreboard players operation #apple c.ev = #e c.t
scoreboard players remove #apple c.ev 1000
