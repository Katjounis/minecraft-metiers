scoreboard players set #b c.t 15000
scoreboard players set #V c.t 4
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 1
scoreboard players set #blk c.t 0
data modify storage commerce:t it set value {id:"music_disc_cat",n:"Disque cat",i3:"472",cn:"Butin de boss",cb:1171}
scoreboard players operation #p c.t = #music_disc_cat c.p
scoreboard players operation #h c.t = #music_disc_cat c.h
scoreboard players operation #vs c.t = #music_disc_cat c.vs
scoreboard players operation #as c.t = #music_disc_cat c.as
scoreboard players operation #e c.t = #music_disc_cat c.ev
scoreboard players add #e c.t 1000
