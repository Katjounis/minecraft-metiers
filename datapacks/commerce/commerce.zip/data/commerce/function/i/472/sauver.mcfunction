scoreboard players operation #music_disc_strad c.p = #p c.t
scoreboard players operation #music_disc_strad c.h = #h c.t
scoreboard players operation #music_disc_strad c.vs = #vs c.t
scoreboard players operation #music_disc_strad c.as = #as c.t
scoreboard players operation #music_disc_strad c.ev = #e c.t
scoreboard players remove #music_disc_strad c.ev 1000
