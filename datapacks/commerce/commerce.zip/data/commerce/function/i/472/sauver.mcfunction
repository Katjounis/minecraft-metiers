scoreboard players operation #music_disc_cat c.p = #p c.t
scoreboard players operation #music_disc_cat c.h = #h c.t
scoreboard players operation #music_disc_cat c.vs = #vs c.t
scoreboard players operation #music_disc_cat c.as = #as c.t
scoreboard players operation #music_disc_cat c.ev = #e c.t
scoreboard players remove #music_disc_cat c.ev 1000
