scoreboard players operation #music_disc_blocks c.p = #p c.t
scoreboard players operation #music_disc_blocks c.h = #h c.t
scoreboard players operation #music_disc_blocks c.vs = #vs c.t
scoreboard players operation #music_disc_blocks c.as = #as c.t
scoreboard players operation #music_disc_blocks c.ev = #e c.t
scoreboard players remove #music_disc_blocks c.ev 1000
