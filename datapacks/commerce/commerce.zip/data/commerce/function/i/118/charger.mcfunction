scoreboard players set #b c.t 12000
scoreboard players set #V c.t 32
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"diamond",n:"Diamant",i3:"118",cn:"Trésors",cb:19}
scoreboard players operation #p c.t = #diamond c.p
scoreboard players operation #h c.t = #diamond c.h
scoreboard players operation #vs c.t = #diamond c.vs
scoreboard players operation #as c.t = #diamond c.as
scoreboard players operation #e c.t = #diamond c.ev
scoreboard players add #e c.t 1000
