scoreboard players operation #diamond c.p = #p c.t
scoreboard players operation #diamond c.h = #h c.t
scoreboard players operation #diamond c.vs = #vs c.t
scoreboard players operation #diamond c.as = #as c.t
scoreboard players operation #diamond c.ev = #e c.t
scoreboard players remove #diamond c.ev 1000
