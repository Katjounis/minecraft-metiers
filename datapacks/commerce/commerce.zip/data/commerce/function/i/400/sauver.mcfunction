scoreboard players operation #anvil c.p = #p c.t
scoreboard players operation #anvil c.h = #h c.t
scoreboard players operation #anvil c.vs = #vs c.t
scoreboard players operation #anvil c.as = #as c.t
scoreboard players operation #anvil c.ev = #e c.t
scoreboard players remove #anvil c.ev 1000
