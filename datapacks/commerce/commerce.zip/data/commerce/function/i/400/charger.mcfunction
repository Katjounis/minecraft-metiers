scoreboard players set #b c.t 24000
scoreboard players set #V c.t 8
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"anvil",n:"Enclume",i3:"400",cn:"Utilitaires",cb:1143}
scoreboard players operation #p c.t = #anvil c.p
scoreboard players operation #h c.t = #anvil c.h
scoreboard players operation #vs c.t = #anvil c.vs
scoreboard players operation #as c.t = #anvil c.as
scoreboard players operation #e c.t = #anvil c.ev
scoreboard players add #e c.t 1000
