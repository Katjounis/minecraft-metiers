scoreboard players operation #wither_skeleton_skull c.p = #p c.t
scoreboard players operation #wither_skeleton_skull c.h = #h c.t
scoreboard players operation #wither_skeleton_skull c.vs = #vs c.t
scoreboard players operation #wither_skeleton_skull c.as = #as c.t
scoreboard players operation #wither_skeleton_skull c.ev = #e c.t
scoreboard players remove #wither_skeleton_skull c.ev 1000
