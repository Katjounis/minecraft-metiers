scoreboard players operation #ender_pearl c.p = #p c.t
scoreboard players operation #ender_pearl c.h = #h c.t
scoreboard players operation #ender_pearl c.vs = #vs c.t
scoreboard players operation #ender_pearl c.as = #as c.t
scoreboard players operation #ender_pearl c.ev = #e c.t
scoreboard players remove #ender_pearl c.ev 1000
