scoreboard players set #b c.t 600
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"ender_pearl",n:"Perle de l'Ender",i3:"083",cn:"Élevage et chasse",cb:15}
scoreboard players operation #p c.t = #ender_pearl c.p
scoreboard players operation #h c.t = #ender_pearl c.h
scoreboard players operation #vs c.t = #ender_pearl c.vs
scoreboard players operation #as c.t = #ender_pearl c.as
scoreboard players operation #e c.t = #ender_pearl c.ev
scoreboard players add #e c.t 1000
