scoreboard players set #b c.t 250
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"stripped_crimson_stem",n:"Tige carmin écorcée",i3:"083",cn:"Bûches",cb:1031}
scoreboard players operation #p c.t = #stripped_crimson_stem c.p
scoreboard players operation #h c.t = #stripped_crimson_stem c.h
scoreboard players operation #vs c.t = #stripped_crimson_stem c.vs
scoreboard players operation #as c.t = #stripped_crimson_stem c.as
scoreboard players operation #e c.t = #stripped_crimson_stem c.ev
scoreboard players add #e c.t 1000
