scoreboard players operation #prismarine_crystals c.p = #p c.t
scoreboard players operation #prismarine_crystals c.h = #h c.t
scoreboard players operation #prismarine_crystals c.vs = #vs c.t
scoreboard players operation #prismarine_crystals c.as = #as c.t
scoreboard players operation #prismarine_crystals c.ev = #e c.t
scoreboard players remove #prismarine_crystals c.ev 1000
