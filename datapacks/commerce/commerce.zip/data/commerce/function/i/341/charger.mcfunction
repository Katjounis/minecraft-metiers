scoreboard players set #b c.t 150
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"prismarine_crystals",n:"Cristaux de prismarine",i3:"341",cn:"Pêche",cb:112}
scoreboard players operation #p c.t = #prismarine_crystals c.p
scoreboard players operation #h c.t = #prismarine_crystals c.h
scoreboard players operation #vs c.t = #prismarine_crystals c.vs
scoreboard players operation #as c.t = #prismarine_crystals c.as
scoreboard players operation #e c.t = #prismarine_crystals c.ev
scoreboard players add #e c.t 1000
