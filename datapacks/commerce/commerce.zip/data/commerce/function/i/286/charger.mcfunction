scoreboard players set #b c.t 5
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"beetroot_seeds",n:"Graines de betterave",i3:"286",cn:"Agriculture",cb:1100}
scoreboard players operation #p c.t = #beetroot_seeds c.p
scoreboard players operation #h c.t = #beetroot_seeds c.h
scoreboard players operation #vs c.t = #beetroot_seeds c.vs
scoreboard players operation #as c.t = #beetroot_seeds c.as
scoreboard players operation #e c.t = #beetroot_seeds c.ev
scoreboard players add #e c.t 1000
