scoreboard players operation #beetroot_seeds c.p = #p c.t
scoreboard players operation #beetroot_seeds c.h = #h c.t
scoreboard players operation #beetroot_seeds c.vs = #vs c.t
scoreboard players operation #beetroot_seeds c.as = #as c.t
scoreboard players operation #beetroot_seeds c.ev = #e c.t
scoreboard players remove #beetroot_seeds c.ev 1000
