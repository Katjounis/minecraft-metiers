scoreboard players set #b c.t 30
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
scoreboard players set #cher c.t 1
data modify storage commerce:t it set value {id:"lilac",n:"Lilas",i3:"412",cn:"Fleurs et plantes",cb:1161}
scoreboard players operation #p c.t = #lilac c.p
scoreboard players operation #h c.t = #lilac c.h
scoreboard players operation #vs c.t = #lilac c.vs
scoreboard players operation #as c.t = #lilac c.as
scoreboard players operation #e c.t = #lilac c.ev
scoreboard players add #e c.t 1000
