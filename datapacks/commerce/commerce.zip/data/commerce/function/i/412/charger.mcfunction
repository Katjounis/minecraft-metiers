scoreboard players set #b c.t 30
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"lily_of_the_valley",n:"Muguet",i3:"412",cn:"Fleurs et plantes",cb:1161}
scoreboard players operation #p c.t = #lily_of_the_valley c.p
scoreboard players operation #h c.t = #lily_of_the_valley c.h
scoreboard players operation #vs c.t = #lily_of_the_valley c.vs
scoreboard players operation #as c.t = #lily_of_the_valley c.as
scoreboard players operation #e c.t = #lily_of_the_valley c.ev
scoreboard players add #e c.t 1000
