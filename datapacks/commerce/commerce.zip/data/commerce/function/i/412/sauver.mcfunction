scoreboard players operation #lily_of_the_valley c.p = #p c.t
scoreboard players operation #lily_of_the_valley c.h = #h c.t
scoreboard players operation #lily_of_the_valley c.vs = #vs c.t
scoreboard players operation #lily_of_the_valley c.as = #as c.t
scoreboard players operation #lily_of_the_valley c.ev = #e c.t
scoreboard players remove #lily_of_the_valley c.ev 1000
