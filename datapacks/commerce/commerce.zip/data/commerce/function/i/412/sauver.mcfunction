scoreboard players operation #lilac c.p = #p c.t
scoreboard players operation #lilac c.h = #h c.t
scoreboard players operation #lilac c.vs = #vs c.t
scoreboard players operation #lilac c.as = #as c.t
scoreboard players operation #lilac c.ev = #e c.t
scoreboard players remove #lilac c.ev 1000
