scoreboard players operation #beetroot c.p = #p c.t
scoreboard players operation #beetroot c.h = #h c.t
scoreboard players operation #beetroot c.vs = #vs c.t
scoreboard players operation #beetroot c.as = #as c.t
scoreboard players operation #beetroot c.ev = #e c.t
scoreboard players remove #beetroot c.ev 1000
