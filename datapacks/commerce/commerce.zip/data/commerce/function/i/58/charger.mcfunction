scoreboard players set #b c.t 80
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"beetroot",n:"Betterave",i3:"058",cn:"Agriculture",cb:14}
scoreboard players operation #p c.t = #beetroot c.p
scoreboard players operation #h c.t = #beetroot c.h
scoreboard players operation #vs c.t = #beetroot c.vs
scoreboard players operation #as c.t = #beetroot c.as
scoreboard players operation #e c.t = #beetroot c.ev
scoreboard players add #e c.t 1000
