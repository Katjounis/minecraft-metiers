scoreboard players set #b c.t 5
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"pumpkin_seeds",n:"Graines de citrouille",i3:"292",cn:"Agriculture",cb:110}
scoreboard players operation #p c.t = #pumpkin_seeds c.p
scoreboard players operation #h c.t = #pumpkin_seeds c.h
scoreboard players operation #vs c.t = #pumpkin_seeds c.vs
scoreboard players operation #as c.t = #pumpkin_seeds c.as
scoreboard players operation #e c.t = #pumpkin_seeds c.ev
scoreboard players add #e c.t 1000
