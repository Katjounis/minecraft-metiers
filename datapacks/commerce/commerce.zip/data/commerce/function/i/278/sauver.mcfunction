scoreboard players operation #purpur_pillar c.p = #p c.t
scoreboard players operation #purpur_pillar c.h = #h c.t
scoreboard players operation #purpur_pillar c.vs = #vs c.t
scoreboard players operation #purpur_pillar c.as = #as c.t
scoreboard players operation #purpur_pillar c.ev = #e c.t
scoreboard players remove #purpur_pillar c.ev 1000
