scoreboard players operation #carrot c.p = #p c.t
scoreboard players operation #carrot c.h = #h c.t
scoreboard players operation #carrot c.vs = #vs c.t
scoreboard players operation #carrot c.as = #as c.t
scoreboard players operation #carrot c.ev = #e c.t
scoreboard players remove #carrot c.ev 1000
