scoreboard players set #b c.t 40
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"carrot",n:"Carotte",i3:"282",cn:"Agriculture",cb:1100}
scoreboard players operation #p c.t = #carrot c.p
scoreboard players operation #h c.t = #carrot c.h
scoreboard players operation #vs c.t = #carrot c.vs
scoreboard players operation #as c.t = #carrot c.as
scoreboard players operation #e c.t = #carrot c.ev
scoreboard players add #e c.t 1000
