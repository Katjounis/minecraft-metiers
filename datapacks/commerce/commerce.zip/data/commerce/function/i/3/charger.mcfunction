scoreboard players set #b c.t 10
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"stone",n:"Roche",i3:"003",cn:"Pierres",cb:101}
scoreboard players operation #p c.t = #stone c.p
scoreboard players operation #h c.t = #stone c.h
scoreboard players operation #vs c.t = #stone c.vs
scoreboard players operation #as c.t = #stone c.as
scoreboard players operation #e c.t = #stone c.ev
scoreboard players add #e c.t 1000
