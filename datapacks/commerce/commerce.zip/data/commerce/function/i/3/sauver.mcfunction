scoreboard players operation #stone c.p = #p c.t
scoreboard players operation #stone c.h = #h c.t
scoreboard players operation #stone c.vs = #vs c.t
scoreboard players operation #stone c.as = #as c.t
scoreboard players operation #stone c.ev = #e c.t
scoreboard players remove #stone c.ev 1000
