scoreboard players operation #rail c.p = #p c.t
scoreboard players operation #rail c.h = #h c.t
scoreboard players operation #rail c.vs = #vs c.t
scoreboard players operation #rail c.as = #as c.t
scoreboard players operation #rail c.ev = #e c.t
scoreboard players remove #rail c.ev 1000
