scoreboard players set #b c.t 200
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"rail",n:"Rail",i3:"111",cn:"Utilitaires",cb:18}
scoreboard players operation #p c.t = #rail c.p
scoreboard players operation #h c.t = #rail c.h
scoreboard players operation #vs c.t = #rail c.vs
scoreboard players operation #as c.t = #rail c.as
scoreboard players operation #e c.t = #rail c.ev
scoreboard players add #e c.t 1000
