scoreboard players set #b c.t 22
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
scoreboard players set #cher c.t 1
data modify storage commerce:t it set value {id:"yellow_concrete",n:"Béton jaune",i3:"158",cn:"Béton et terre cuite",cb:1060}
scoreboard players operation #p c.t = #yellow_concrete c.p
scoreboard players operation #h c.t = #yellow_concrete c.h
scoreboard players operation #vs c.t = #yellow_concrete c.vs
scoreboard players operation #as c.t = #yellow_concrete c.as
scoreboard players operation #e c.t = #yellow_concrete c.ev
scoreboard players add #e c.t 1000
