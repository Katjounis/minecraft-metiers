scoreboard players set #b c.t 300
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"tropical_fish",n:"Poisson tropical",i3:"336",cn:"Pêche",cb:112}
scoreboard players operation #p c.t = #tropical_fish c.p
scoreboard players operation #h c.t = #tropical_fish c.h
scoreboard players operation #vs c.t = #tropical_fish c.vs
scoreboard players operation #as c.t = #tropical_fish c.as
scoreboard players operation #e c.t = #tropical_fish c.ev
scoreboard players add #e c.t 1000
