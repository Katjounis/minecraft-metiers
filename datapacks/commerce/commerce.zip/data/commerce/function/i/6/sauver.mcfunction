scoreboard players operation #mossy_stone_bricks c.p = #p c.t
scoreboard players operation #mossy_stone_bricks c.h = #h c.t
scoreboard players operation #mossy_stone_bricks c.vs = #vs c.t
scoreboard players operation #mossy_stone_bricks c.as = #as c.t
scoreboard players operation #mossy_stone_bricks c.ev = #e c.t
scoreboard players remove #mossy_stone_bricks c.ev 1000
