scoreboard players set #b c.t 600
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"raw_iron",n:"Fer brut",i3:"044",cn:"Minerais",cb:13}
scoreboard players operation #p c.t = #raw_iron c.p
scoreboard players operation #h c.t = #raw_iron c.h
scoreboard players operation #vs c.t = #raw_iron c.vs
scoreboard players operation #as c.t = #raw_iron c.as
scoreboard players operation #e c.t = #raw_iron c.ev
scoreboard players add #e c.t 1000
