scoreboard players operation #raw_iron c.p = #p c.t
scoreboard players operation #raw_iron c.h = #h c.t
scoreboard players operation #raw_iron c.vs = #vs c.t
scoreboard players operation #raw_iron c.as = #as c.t
scoreboard players operation #raw_iron c.ev = #e c.t
scoreboard players remove #raw_iron c.ev 1000
