scoreboard players set #b c.t 400
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"blaze_powder",n:"Poudre de blaze",i3:"330",cn:"Élevage et chasse",cb:111}
scoreboard players operation #p c.t = #blaze_powder c.p
scoreboard players operation #h c.t = #blaze_powder c.h
scoreboard players operation #vs c.t = #blaze_powder c.vs
scoreboard players operation #as c.t = #blaze_powder c.as
scoreboard players operation #e c.t = #blaze_powder c.ev
scoreboard players add #e c.t 1000
