scoreboard players operation #blaze_powder c.p = #p c.t
scoreboard players operation #blaze_powder c.h = #h c.t
scoreboard players operation #blaze_powder c.vs = #vs c.t
scoreboard players operation #blaze_powder c.as = #as c.t
scoreboard players operation #blaze_powder c.ev = #e c.t
scoreboard players remove #blaze_powder c.ev 1000
