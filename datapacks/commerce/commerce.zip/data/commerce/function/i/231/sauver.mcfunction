scoreboard players operation #iron_nugget c.p = #p c.t
scoreboard players operation #iron_nugget c.h = #h c.t
scoreboard players operation #iron_nugget c.vs = #vs c.t
scoreboard players operation #iron_nugget c.as = #as c.t
scoreboard players operation #iron_nugget c.ev = #e c.t
scoreboard players remove #iron_nugget c.ev 1000
