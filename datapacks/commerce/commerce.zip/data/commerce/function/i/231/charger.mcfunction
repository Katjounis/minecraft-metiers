scoreboard players set #b c.t 88
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"iron_nugget",n:"Pépite de fer",i3:"231",cn:"Minerais et métaux",cb:1081}
scoreboard players operation #p c.t = #iron_nugget c.p
scoreboard players operation #h c.t = #iron_nugget c.h
scoreboard players operation #vs c.t = #iron_nugget c.vs
scoreboard players operation #as c.t = #iron_nugget c.as
scoreboard players operation #e c.t = #iron_nugget c.ev
scoreboard players add #e c.t 1000
