scoreboard players operation #feather c.p = #p c.t
scoreboard players operation #feather c.h = #h c.t
scoreboard players operation #feather c.vs = #vs c.t
scoreboard players operation #feather c.as = #as c.t
scoreboard players operation #feather c.ev = #e c.t
scoreboard players remove #feather c.ev 1000
