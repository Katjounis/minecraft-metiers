scoreboard players set #b c.t 30
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 0
data modify storage commerce:t it set value {id:"feather",n:"Plume",i3:"308",cn:"Élevage et chasse",cb:1110}
scoreboard players operation #p c.t = #feather c.p
scoreboard players operation #h c.t = #feather c.h
scoreboard players operation #vs c.t = #feather c.vs
scoreboard players operation #as c.t = #feather c.as
scoreboard players operation #e c.t = #feather c.ev
scoreboard players add #e c.t 1000
