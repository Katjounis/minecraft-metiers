scoreboard players operation #tropical_fish c.p = #p c.t
scoreboard players operation #tropical_fish c.h = #h c.t
scoreboard players operation #tropical_fish c.vs = #vs c.t
scoreboard players operation #tropical_fish c.as = #as c.t
scoreboard players operation #tropical_fish c.ev = #e c.t
scoreboard players remove #tropical_fish c.ev 1000
