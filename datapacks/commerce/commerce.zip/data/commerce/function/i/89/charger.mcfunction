scoreboard players set #b c.t 300
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"pufferfish",n:"Poisson-globe",i3:"089",cn:"Pêche",cb:16}
scoreboard players operation #p c.t = #pufferfish c.p
scoreboard players operation #h c.t = #pufferfish c.h
scoreboard players operation #vs c.t = #pufferfish c.vs
scoreboard players operation #as c.t = #pufferfish c.as
scoreboard players operation #e c.t = #pufferfish c.ev
scoreboard players add #e c.t 1000
