scoreboard players operation #pufferfish c.p = #p c.t
scoreboard players operation #pufferfish c.h = #h c.t
scoreboard players operation #pufferfish c.vs = #vs c.t
scoreboard players operation #pufferfish c.as = #as c.t
scoreboard players operation #pufferfish c.ev = #e c.t
scoreboard players remove #pufferfish c.ev 1000
