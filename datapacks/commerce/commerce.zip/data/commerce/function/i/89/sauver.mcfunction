scoreboard players operation #oak_leaves c.p = #p c.t
scoreboard players operation #oak_leaves c.h = #h c.t
scoreboard players operation #oak_leaves c.vs = #vs c.t
scoreboard players operation #oak_leaves c.as = #as c.t
scoreboard players operation #oak_leaves c.ev = #e c.t
scoreboard players remove #oak_leaves c.ev 1000
