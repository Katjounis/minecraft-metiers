scoreboard players set #b c.t 800
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"iron_ingot",n:"Lingot de fer",i3:"230",cn:"Minerais et métaux",cb:108}
scoreboard players operation #p c.t = #iron_ingot c.p
scoreboard players operation #h c.t = #iron_ingot c.h
scoreboard players operation #vs c.t = #iron_ingot c.vs
scoreboard players operation #as c.t = #iron_ingot c.as
scoreboard players operation #e c.t = #iron_ingot c.ev
scoreboard players add #e c.t 1000
