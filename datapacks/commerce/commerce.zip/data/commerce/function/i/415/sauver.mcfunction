scoreboard players operation #rose_bush c.p = #p c.t
scoreboard players operation #rose_bush c.h = #h c.t
scoreboard players operation #rose_bush c.vs = #vs c.t
scoreboard players operation #rose_bush c.as = #as c.t
scoreboard players operation #rose_bush c.ev = #e c.t
scoreboard players remove #rose_bush c.ev 1000
