scoreboard players set #b c.t 30
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"rose_bush",n:"Rosier",i3:"415",cn:"Fleurs et plantes",cb:116}
scoreboard players operation #p c.t = #rose_bush c.p
scoreboard players operation #h c.t = #rose_bush c.h
scoreboard players operation #vs c.t = #rose_bush c.vs
scoreboard players operation #as c.t = #rose_bush c.as
scoreboard players operation #e c.t = #rose_bush c.ev
scoreboard players add #e c.t 1000
