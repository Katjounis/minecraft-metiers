scoreboard players set #b c.t 200
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"glow_ink_sac",n:"Poche d'encre lumineuse",i3:"091",cn:"Pêche",cb:16}
scoreboard players operation #p c.t = #glow_ink_sac c.p
scoreboard players operation #h c.t = #glow_ink_sac c.h
scoreboard players operation #vs c.t = #glow_ink_sac c.vs
scoreboard players operation #as c.t = #glow_ink_sac c.as
scoreboard players operation #e c.t = #glow_ink_sac c.ev
scoreboard players add #e c.t 1000
