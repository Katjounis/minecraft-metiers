scoreboard players operation #ominous_bottle c.p = #p c.t
scoreboard players operation #ominous_bottle c.h = #h c.t
scoreboard players operation #ominous_bottle c.vs = #vs c.t
scoreboard players operation #ominous_bottle c.as = #as c.t
scoreboard players operation #ominous_bottle c.ev = #e c.t
scoreboard players remove #ominous_bottle c.ev 1000
