scoreboard players set #b c.t 6000
scoreboard players set #V c.t 16
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 1
scoreboard players set #blk c.t 0
data modify storage commerce:t it set value {id:"ominous_bottle",n:"Fiole sinistre",i3:"462",cn:"Butin de boss",cb:1170}
scoreboard players operation #p c.t = #ominous_bottle c.p
scoreboard players operation #h c.t = #ominous_bottle c.h
scoreboard players operation #vs c.t = #ominous_bottle c.vs
scoreboard players operation #as c.t = #ominous_bottle c.as
scoreboard players operation #e c.t = #ominous_bottle c.ev
scoreboard players add #e c.t 1000
