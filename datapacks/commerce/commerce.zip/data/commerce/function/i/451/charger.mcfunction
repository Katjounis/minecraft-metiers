scoreboard players set #b c.t 150000
scoreboard players set #V c.t 4
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"nether_star",n:"Étoile du Nether",i3:"451",cn:"Trésors",cb:115}
scoreboard players operation #p c.t = #nether_star c.p
scoreboard players operation #h c.t = #nether_star c.h
scoreboard players operation #vs c.t = #nether_star c.vs
scoreboard players operation #as c.t = #nether_star c.as
scoreboard players operation #e c.t = #nether_star c.ev
scoreboard players add #e c.t 1000
