scoreboard players set #b c.t 50
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"birch_planks",n:"Planches de bouleau",i3:"094",cn:"Planches et feuillage",cb:104}
scoreboard players operation #p c.t = #birch_planks c.p
scoreboard players operation #h c.t = #birch_planks c.h
scoreboard players operation #vs c.t = #birch_planks c.vs
scoreboard players operation #as c.t = #birch_planks c.as
scoreboard players operation #e c.t = #birch_planks c.ev
scoreboard players add #e c.t 1000
