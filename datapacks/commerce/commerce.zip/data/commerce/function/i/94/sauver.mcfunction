scoreboard players operation #birch_planks c.p = #p c.t
scoreboard players operation #birch_planks c.h = #h c.t
scoreboard players operation #birch_planks c.vs = #vs c.t
scoreboard players operation #birch_planks c.as = #as c.t
scoreboard players operation #birch_planks c.ev = #e c.t
scoreboard players remove #birch_planks c.ev 1000
