scoreboard players operation #lily_pad c.p = #p c.t
scoreboard players operation #lily_pad c.h = #h c.t
scoreboard players operation #lily_pad c.vs = #vs c.t
scoreboard players operation #lily_pad c.as = #as c.t
scoreboard players operation #lily_pad c.ev = #e c.t
scoreboard players remove #lily_pad c.ev 1000
