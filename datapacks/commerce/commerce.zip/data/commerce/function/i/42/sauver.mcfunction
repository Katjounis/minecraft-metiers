scoreboard players operation #sea_lantern c.p = #p c.t
scoreboard players operation #sea_lantern c.h = #h c.t
scoreboard players operation #sea_lantern c.vs = #vs c.t
scoreboard players operation #sea_lantern c.as = #as c.t
scoreboard players operation #sea_lantern c.ev = #e c.t
scoreboard players remove #sea_lantern c.ev 1000
