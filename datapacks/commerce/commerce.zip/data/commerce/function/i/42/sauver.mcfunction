scoreboard players operation #raw_copper c.p = #p c.t
scoreboard players operation #raw_copper c.h = #h c.t
scoreboard players operation #raw_copper c.vs = #vs c.t
scoreboard players operation #raw_copper c.as = #as c.t
scoreboard players operation #raw_copper c.ev = #e c.t
scoreboard players remove #raw_copper c.ev 1000
