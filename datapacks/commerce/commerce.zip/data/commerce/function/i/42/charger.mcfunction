scoreboard players set #b c.t 1100
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"sea_lantern",n:"Lanterne aquatique",i3:"042",cn:"Pierres",cb:101}
scoreboard players operation #p c.t = #sea_lantern c.p
scoreboard players operation #h c.t = #sea_lantern c.h
scoreboard players operation #vs c.t = #sea_lantern c.vs
scoreboard players operation #as c.t = #sea_lantern c.as
scoreboard players operation #e c.t = #sea_lantern c.ev
scoreboard players add #e c.t 1000
