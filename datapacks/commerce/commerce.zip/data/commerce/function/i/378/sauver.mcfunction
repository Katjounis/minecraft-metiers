scoreboard players operation #minecart c.p = #p c.t
scoreboard players operation #minecart c.h = #h c.t
scoreboard players operation #minecart c.vs = #vs c.t
scoreboard players operation #minecart c.as = #as c.t
scoreboard players operation #minecart c.ev = #e c.t
scoreboard players remove #minecart c.ev 1000
