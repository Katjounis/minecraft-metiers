scoreboard players set #b c.t 4000
scoreboard players set #V c.t 64
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"minecart",n:"Wagonnet",i3:"378",cn:"Utilitaires",cb:114}
scoreboard players operation #p c.t = #minecart c.p
scoreboard players operation #h c.t = #minecart c.h
scoreboard players operation #vs c.t = #minecart c.vs
scoreboard players operation #as c.t = #minecart c.as
scoreboard players operation #e c.t = #minecart c.ev
scoreboard players add #e c.t 1000
