scoreboard players set #b c.t 1800
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cut_copper",n:"Cuivre taillé",i3:"227",cn:"Minerais et métaux",cb:108}
scoreboard players operation #p c.t = #cut_copper c.p
scoreboard players operation #h c.t = #cut_copper c.h
scoreboard players operation #vs c.t = #cut_copper c.vs
scoreboard players operation #as c.t = #cut_copper c.as
scoreboard players operation #e c.t = #cut_copper c.ev
scoreboard players add #e c.t 1000
