scoreboard players operation #cut_copper c.p = #p c.t
scoreboard players operation #cut_copper c.h = #h c.t
scoreboard players operation #cut_copper c.vs = #vs c.t
scoreboard players operation #cut_copper c.as = #as c.t
scoreboard players operation #cut_copper c.ev = #e c.t
scoreboard players remove #cut_copper c.ev 1000
