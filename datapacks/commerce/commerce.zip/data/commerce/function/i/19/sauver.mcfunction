scoreboard players operation #deepslate_tiles c.p = #p c.t
scoreboard players operation #deepslate_tiles c.h = #h c.t
scoreboard players operation #deepslate_tiles c.vs = #vs c.t
scoreboard players operation #deepslate_tiles c.as = #as c.t
scoreboard players operation #deepslate_tiles c.ev = #e c.t
scoreboard players remove #deepslate_tiles c.ev 1000
