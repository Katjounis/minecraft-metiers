scoreboard players operation #clay_ball c.p = #p c.t
scoreboard players operation #clay_ball c.h = #h c.t
scoreboard players operation #clay_ball c.vs = #vs c.t
scoreboard players operation #clay_ball c.as = #as c.t
scoreboard players operation #clay_ball c.ev = #e c.t
scoreboard players remove #clay_ball c.ev 1000
