scoreboard players set #b c.t 6
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"deepslate_tiles",n:"Carreaux d'ardoise",i3:"019",cn:"Pierres",cb:101}
scoreboard players operation #p c.t = #deepslate_tiles c.p
scoreboard players operation #h c.t = #deepslate_tiles c.h
scoreboard players operation #vs c.t = #deepslate_tiles c.vs
scoreboard players operation #as c.t = #deepslate_tiles c.as
scoreboard players operation #e c.t = #deepslate_tiles c.ev
scoreboard players add #e c.t 1000
