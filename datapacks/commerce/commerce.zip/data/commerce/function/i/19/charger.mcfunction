scoreboard players set #b c.t 30
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"clay_ball",n:"Argile",i3:"019",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #clay_ball c.p
scoreboard players operation #h c.t = #clay_ball c.h
scoreboard players operation #vs c.t = #clay_ball c.vs
scoreboard players operation #as c.t = #clay_ball c.as
scoreboard players operation #e c.t = #clay_ball c.ev
scoreboard players add #e c.t 1000
