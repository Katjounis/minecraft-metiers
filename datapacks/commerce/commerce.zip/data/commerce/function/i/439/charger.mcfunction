scoreboard players set #b c.t 4000
scoreboard players set #V c.t 32
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"nautilus_shell",n:"Coquille de nautile",i3:"439",cn:"Trésors",cb:1150}
scoreboard players operation #p c.t = #nautilus_shell c.p
scoreboard players operation #h c.t = #nautilus_shell c.h
scoreboard players operation #vs c.t = #nautilus_shell c.vs
scoreboard players operation #as c.t = #nautilus_shell c.as
scoreboard players operation #e c.t = #nautilus_shell c.ev
scoreboard players add #e c.t 1000
