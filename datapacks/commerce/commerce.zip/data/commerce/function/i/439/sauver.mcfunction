scoreboard players operation #nautilus_shell c.p = #p c.t
scoreboard players operation #nautilus_shell c.h = #h c.t
scoreboard players operation #nautilus_shell c.vs = #vs c.t
scoreboard players operation #nautilus_shell c.as = #as c.t
scoreboard players operation #nautilus_shell c.ev = #e c.t
scoreboard players remove #nautilus_shell c.ev 1000
