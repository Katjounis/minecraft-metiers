scoreboard players set #b c.t 30
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"brown_egg",n:"Oeuf brun",i3:"306",cn:"Élevage et chasse",cb:111}
scoreboard players operation #p c.t = #brown_egg c.p
scoreboard players operation #h c.t = #brown_egg c.h
scoreboard players operation #vs c.t = #brown_egg c.vs
scoreboard players operation #as c.t = #brown_egg c.as
scoreboard players operation #e c.t = #brown_egg c.ev
scoreboard players add #e c.t 1000
