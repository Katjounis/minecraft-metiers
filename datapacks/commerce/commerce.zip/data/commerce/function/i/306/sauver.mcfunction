scoreboard players operation #brown_egg c.p = #p c.t
scoreboard players operation #brown_egg c.h = #h c.t
scoreboard players operation #brown_egg c.vs = #vs c.t
scoreboard players operation #brown_egg c.as = #as c.t
scoreboard players operation #brown_egg c.ev = #e c.t
scoreboard players remove #brown_egg c.ev 1000
