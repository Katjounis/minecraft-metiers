scoreboard players operation #dead_bush c.p = #p c.t
scoreboard players operation #dead_bush c.h = #h c.t
scoreboard players operation #dead_bush c.vs = #vs c.t
scoreboard players operation #dead_bush c.as = #as c.t
scoreboard players operation #dead_bush c.ev = #e c.t
scoreboard players remove #dead_bush c.ev 1000
