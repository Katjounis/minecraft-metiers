scoreboard players set #b c.t 30
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"azalea",n:"Azalée",i3:"429",cn:"Fleurs et plantes",cb:1162}
scoreboard players operation #p c.t = #azalea c.p
scoreboard players operation #h c.t = #azalea c.h
scoreboard players operation #vs c.t = #azalea c.vs
scoreboard players operation #as c.t = #azalea c.as
scoreboard players operation #e c.t = #azalea c.ev
scoreboard players add #e c.t 1000
