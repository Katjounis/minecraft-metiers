scoreboard players operation #azalea c.p = #p c.t
scoreboard players operation #azalea c.h = #h c.t
scoreboard players operation #azalea c.vs = #vs c.t
scoreboard players operation #azalea c.as = #as c.t
scoreboard players operation #azalea c.ev = #e c.t
scoreboard players remove #azalea c.ev 1000
