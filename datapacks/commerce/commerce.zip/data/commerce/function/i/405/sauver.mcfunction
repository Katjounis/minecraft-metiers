scoreboard players operation #azure_bluet c.p = #p c.t
scoreboard players operation #azure_bluet c.h = #h c.t
scoreboard players operation #azure_bluet c.vs = #vs c.t
scoreboard players operation #azure_bluet c.as = #as c.t
scoreboard players operation #azure_bluet c.ev = #e c.t
scoreboard players remove #azure_bluet c.ev 1000
