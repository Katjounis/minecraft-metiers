scoreboard players set #b c.t 20
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"azure_bluet",n:"Houstonie bleue",i3:"405",cn:"Fleurs et plantes",cb:116}
scoreboard players operation #p c.t = #azure_bluet c.p
scoreboard players operation #h c.t = #azure_bluet c.h
scoreboard players operation #vs c.t = #azure_bluet c.vs
scoreboard players operation #as c.t = #azure_bluet c.as
scoreboard players operation #e c.t = #azure_bluet c.ev
scoreboard players add #e c.t 1000
