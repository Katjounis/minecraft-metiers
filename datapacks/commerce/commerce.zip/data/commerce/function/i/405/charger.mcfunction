scoreboard players set #b c.t 20
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
scoreboard players set #cher c.t 1
data modify storage commerce:t it set value {id:"orange_tulip",n:"Tulipe orange",i3:"405",cn:"Fleurs et plantes",cb:1160}
scoreboard players operation #p c.t = #orange_tulip c.p
scoreboard players operation #h c.t = #orange_tulip c.h
scoreboard players operation #vs c.t = #orange_tulip c.vs
scoreboard players operation #as c.t = #orange_tulip c.as
scoreboard players operation #e c.t = #orange_tulip c.ev
scoreboard players add #e c.t 1000
