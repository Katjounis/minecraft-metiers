scoreboard players set #b c.t 22
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"pink_concrete",n:"Béton rose",i3:"160",cn:"Béton et terre cuite",cb:106}
scoreboard players operation #p c.t = #pink_concrete c.p
scoreboard players operation #h c.t = #pink_concrete c.h
scoreboard players operation #vs c.t = #pink_concrete c.vs
scoreboard players operation #as c.t = #pink_concrete c.as
scoreboard players operation #e c.t = #pink_concrete c.ev
scoreboard players add #e c.t 1000
