scoreboard players operation #pink_concrete c.p = #p c.t
scoreboard players operation #pink_concrete c.h = #h c.t
scoreboard players operation #pink_concrete c.vs = #vs c.t
scoreboard players operation #pink_concrete c.as = #as c.t
scoreboard players operation #pink_concrete c.ev = #e c.t
scoreboard players remove #pink_concrete c.ev 1000
