scoreboard players set #b c.t 50
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"ink_sac",n:"Poche d'encre",i3:"090",cn:"Pêche",cb:16}
scoreboard players operation #p c.t = #ink_sac c.p
scoreboard players operation #h c.t = #ink_sac c.h
scoreboard players operation #vs c.t = #ink_sac c.vs
scoreboard players operation #as c.t = #ink_sac c.as
scoreboard players operation #e c.t = #ink_sac c.ev
scoreboard players add #e c.t 1000
