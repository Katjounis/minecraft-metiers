scoreboard players operation #oak_sapling c.p = #p c.t
scoreboard players operation #oak_sapling c.h = #h c.t
scoreboard players operation #oak_sapling c.vs = #vs c.t
scoreboard players operation #oak_sapling c.as = #as c.t
scoreboard players operation #oak_sapling c.ev = #e c.t
scoreboard players remove #oak_sapling c.ev 1000
