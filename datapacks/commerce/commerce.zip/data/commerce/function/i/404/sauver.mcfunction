scoreboard players operation #allium c.p = #p c.t
scoreboard players operation #allium c.h = #h c.t
scoreboard players operation #allium c.vs = #vs c.t
scoreboard players operation #allium c.as = #as c.t
scoreboard players operation #allium c.ev = #e c.t
scoreboard players remove #allium c.ev 1000
