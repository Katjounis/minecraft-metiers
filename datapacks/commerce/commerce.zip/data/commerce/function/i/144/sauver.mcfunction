scoreboard players operation #pink_dye c.p = #p c.t
scoreboard players operation #pink_dye c.h = #h c.t
scoreboard players operation #pink_dye c.vs = #vs c.t
scoreboard players operation #pink_dye c.as = #as c.t
scoreboard players operation #pink_dye c.ev = #e c.t
scoreboard players remove #pink_dye c.ev 1000
