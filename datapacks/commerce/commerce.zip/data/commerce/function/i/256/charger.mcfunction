scoreboard players set #b c.t 8
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"smooth_basalt",n:"Basalte lisse",i3:"256",cn:"Nether et End",cb:109}
scoreboard players operation #p c.t = #smooth_basalt c.p
scoreboard players operation #h c.t = #smooth_basalt c.h
scoreboard players operation #vs c.t = #smooth_basalt c.vs
scoreboard players operation #as c.t = #smooth_basalt c.as
scoreboard players operation #e c.t = #smooth_basalt c.ev
scoreboard players add #e c.t 1000
