scoreboard players operation #smooth_basalt c.p = #p c.t
scoreboard players operation #smooth_basalt c.h = #h c.t
scoreboard players operation #smooth_basalt c.vs = #vs c.t
scoreboard players operation #smooth_basalt c.as = #as c.t
scoreboard players operation #smooth_basalt c.ev = #e c.t
scoreboard players remove #smooth_basalt c.ev 1000
