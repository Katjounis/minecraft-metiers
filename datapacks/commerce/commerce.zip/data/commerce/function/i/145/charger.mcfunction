scoreboard players set #b c.t 26
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"gray_dye",n:"Teinture grise",i3:"145",cn:"Laines et teintures",cb:105}
scoreboard players operation #p c.t = #gray_dye c.p
scoreboard players operation #h c.t = #gray_dye c.h
scoreboard players operation #vs c.t = #gray_dye c.vs
scoreboard players operation #as c.t = #gray_dye c.as
scoreboard players operation #e c.t = #gray_dye c.ev
scoreboard players add #e c.t 1000
