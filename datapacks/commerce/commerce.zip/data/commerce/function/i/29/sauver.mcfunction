scoreboard players operation #cut_sandstone c.p = #p c.t
scoreboard players operation #cut_sandstone c.h = #h c.t
scoreboard players operation #cut_sandstone c.vs = #vs c.t
scoreboard players operation #cut_sandstone c.as = #as c.t
scoreboard players operation #cut_sandstone c.ev = #e c.t
scoreboard players remove #cut_sandstone c.ev 1000
