scoreboard players set #b c.t 30
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cut_sandstone",n:"Grès taillé",i3:"029",cn:"Pierres",cb:101}
scoreboard players operation #p c.t = #cut_sandstone c.p
scoreboard players operation #h c.t = #cut_sandstone c.h
scoreboard players operation #vs c.t = #cut_sandstone c.vs
scoreboard players operation #as c.t = #cut_sandstone c.as
scoreboard players operation #e c.t = #cut_sandstone c.ev
scoreboard players add #e c.t 1000
