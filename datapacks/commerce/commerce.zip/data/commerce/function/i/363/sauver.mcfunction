scoreboard players operation #lantern c.p = #p c.t
scoreboard players operation #lantern c.h = #h c.t
scoreboard players operation #lantern c.vs = #vs c.t
scoreboard players operation #lantern c.as = #as c.t
scoreboard players operation #lantern c.ev = #e c.t
scoreboard players remove #lantern c.ev 1000
