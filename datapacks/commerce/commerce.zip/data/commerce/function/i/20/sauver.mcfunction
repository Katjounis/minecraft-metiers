scoreboard players operation #glass c.p = #p c.t
scoreboard players operation #glass c.h = #h c.t
scoreboard players operation #glass c.vs = #vs c.t
scoreboard players operation #glass c.as = #as c.t
scoreboard players operation #glass c.ev = #e c.t
scoreboard players remove #glass c.ev 1000
