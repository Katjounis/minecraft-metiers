scoreboard players set #b c.t 20
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"pink_tulip",n:"Tulipe rose",i3:"409",cn:"Fleurs et plantes",cb:1160}
scoreboard players operation #p c.t = #pink_tulip c.p
scoreboard players operation #h c.t = #pink_tulip c.h
scoreboard players operation #vs c.t = #pink_tulip c.vs
scoreboard players operation #as c.t = #pink_tulip c.as
scoreboard players operation #e c.t = #pink_tulip c.ev
scoreboard players add #e c.t 1000
