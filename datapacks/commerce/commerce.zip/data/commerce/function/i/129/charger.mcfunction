scoreboard players set #b c.t 15000
scoreboard players set #V c.t 8
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"wither_skeleton_skull",n:"Crâne de wither squelette",i3:"129",cn:"Trésors",cb:19}
scoreboard players operation #p c.t = #wither_skeleton_skull c.p
scoreboard players operation #h c.t = #wither_skeleton_skull c.h
scoreboard players operation #vs c.t = #wither_skeleton_skull c.vs
scoreboard players operation #as c.t = #wither_skeleton_skull c.as
scoreboard players operation #e c.t = #wither_skeleton_skull c.ev
scoreboard players add #e c.t 1000
