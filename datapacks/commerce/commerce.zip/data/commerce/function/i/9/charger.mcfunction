scoreboard players set #b c.t 8
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"granite",n:"Granite",i3:"009",cn:"Pierres",cb:1010}
scoreboard players operation #p c.t = #granite c.p
scoreboard players operation #h c.t = #granite c.h
scoreboard players operation #vs c.t = #granite c.vs
scoreboard players operation #as c.t = #granite c.as
scoreboard players operation #e c.t = #granite c.ev
scoreboard players add #e c.t 1000
