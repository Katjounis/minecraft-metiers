scoreboard players set #b c.t 20
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"calcite",n:"Calcite",i3:"009",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #calcite c.p
scoreboard players operation #h c.t = #calcite c.h
scoreboard players operation #vs c.t = #calcite c.vs
scoreboard players operation #as c.t = #calcite c.as
scoreboard players operation #e c.t = #calcite c.ev
scoreboard players add #e c.t 1000
