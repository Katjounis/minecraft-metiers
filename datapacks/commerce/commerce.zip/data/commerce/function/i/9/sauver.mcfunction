scoreboard players operation #granite c.p = #p c.t
scoreboard players operation #granite c.h = #h c.t
scoreboard players operation #granite c.vs = #vs c.t
scoreboard players operation #granite c.as = #as c.t
scoreboard players operation #granite c.ev = #e c.t
scoreboard players remove #granite c.ev 1000
