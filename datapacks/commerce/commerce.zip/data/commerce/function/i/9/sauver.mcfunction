scoreboard players operation #calcite c.p = #p c.t
scoreboard players operation #calcite c.h = #h c.t
scoreboard players operation #calcite c.vs = #vs c.t
scoreboard players operation #calcite c.as = #as c.t
scoreboard players operation #calcite c.ev = #e c.t
scoreboard players remove #calcite c.ev 1000
