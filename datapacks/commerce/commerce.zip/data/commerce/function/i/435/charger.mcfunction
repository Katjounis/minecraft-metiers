scoreboard players set #b c.t 60000
scoreboard players set #V c.t 8
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"ancient_debris",n:"Débris antiques",i3:"435",cn:"Trésors",cb:1150}
scoreboard players operation #p c.t = #ancient_debris c.p
scoreboard players operation #h c.t = #ancient_debris c.h
scoreboard players operation #vs c.t = #ancient_debris c.vs
scoreboard players operation #as c.t = #ancient_debris c.as
scoreboard players operation #e c.t = #ancient_debris c.ev
scoreboard players add #e c.t 1000
