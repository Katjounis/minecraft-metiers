scoreboard players operation #ancient_debris c.p = #p c.t
scoreboard players operation #ancient_debris c.h = #h c.t
scoreboard players operation #ancient_debris c.vs = #vs c.t
scoreboard players operation #ancient_debris c.as = #as c.t
scoreboard players operation #ancient_debris c.ev = #e c.t
scoreboard players remove #ancient_debris c.ev 1000
