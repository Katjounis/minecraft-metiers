scoreboard players operation #shroomlight c.p = #p c.t
scoreboard players operation #shroomlight c.h = #h c.t
scoreboard players operation #shroomlight c.vs = #vs c.t
scoreboard players operation #shroomlight c.as = #as c.t
scoreboard players operation #shroomlight c.ev = #e c.t
scoreboard players remove #shroomlight c.ev 1000
