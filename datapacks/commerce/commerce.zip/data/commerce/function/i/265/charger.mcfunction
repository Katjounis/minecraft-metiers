scoreboard players set #b c.t 100
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"shroomlight",n:"Champilampe",i3:"265",cn:"Nether et End",cb:109}
scoreboard players operation #p c.t = #shroomlight c.p
scoreboard players operation #h c.t = #shroomlight c.h
scoreboard players operation #vs c.t = #shroomlight c.vs
scoreboard players operation #as c.t = #shroomlight c.as
scoreboard players operation #e c.t = #shroomlight c.ev
scoreboard players add #e c.t 1000
