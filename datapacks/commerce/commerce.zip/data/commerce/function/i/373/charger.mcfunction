scoreboard players set #b c.t 1200
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 7
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"bookshelf",n:"Bibliothèque",i3:"373",cn:"Utilitaires",cb:114}
scoreboard players operation #p c.t = #bookshelf c.p
scoreboard players operation #h c.t = #bookshelf c.h
scoreboard players operation #vs c.t = #bookshelf c.vs
scoreboard players operation #as c.t = #bookshelf c.as
scoreboard players operation #e c.t = #bookshelf c.ev
scoreboard players add #e c.t 1000
