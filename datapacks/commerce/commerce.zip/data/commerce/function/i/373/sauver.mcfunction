scoreboard players operation #bookshelf c.p = #p c.t
scoreboard players operation #bookshelf c.h = #h c.t
scoreboard players operation #bookshelf c.vs = #vs c.t
scoreboard players operation #bookshelf c.as = #as c.t
scoreboard players operation #bookshelf c.ev = #e c.t
scoreboard players remove #bookshelf c.ev 1000
