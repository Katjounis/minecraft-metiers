scoreboard players operation #terracotta c.p = #p c.t
scoreboard players operation #terracotta c.h = #h c.t
scoreboard players operation #terracotta c.vs = #vs c.t
scoreboard players operation #terracotta c.as = #as c.t
scoreboard players operation #terracotta c.ev = #e c.t
scoreboard players remove #terracotta c.ev 1000
