scoreboard players set #b c.t 50
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"terracotta",n:"Terre cuite",i3:"025",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #terracotta c.p
scoreboard players operation #h c.t = #terracotta c.h
scoreboard players operation #vs c.t = #terracotta c.vs
scoreboard players operation #as c.t = #terracotta c.as
scoreboard players operation #e c.t = #terracotta c.ev
scoreboard players add #e c.t 1000
