scoreboard players set #b c.t 20
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"dripstone_block",n:"Bloc de spéléothème",i3:"025",cn:"Pierres",cb:1012}
scoreboard players operation #p c.t = #dripstone_block c.p
scoreboard players operation #h c.t = #dripstone_block c.h
scoreboard players operation #vs c.t = #dripstone_block c.vs
scoreboard players operation #as c.t = #dripstone_block c.as
scoreboard players operation #e c.t = #dripstone_block c.ev
scoreboard players add #e c.t 1000
