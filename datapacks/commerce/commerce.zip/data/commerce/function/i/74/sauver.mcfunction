scoreboard players operation #mutton c.p = #p c.t
scoreboard players operation #mutton c.h = #h c.t
scoreboard players operation #mutton c.vs = #vs c.t
scoreboard players operation #mutton c.as = #as c.t
scoreboard players operation #mutton c.ev = #e c.t
scoreboard players remove #mutton c.ev 1000
