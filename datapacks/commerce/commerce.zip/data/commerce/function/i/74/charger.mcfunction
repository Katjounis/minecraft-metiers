scoreboard players set #b c.t 120
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"mutton",n:"Mouton cru",i3:"074",cn:"Élevage et chasse",cb:15}
scoreboard players operation #p c.t = #mutton c.p
scoreboard players operation #h c.t = #mutton c.h
scoreboard players operation #vs c.t = #mutton c.vs
scoreboard players operation #as c.t = #mutton c.as
scoreboard players operation #e c.t = #mutton c.ev
scoreboard players add #e c.t 1000
