scoreboard players set #b c.t 200
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"acacia_log",n:"Bûche d'acacia",i3:"031",cn:"Bois",cb:12}
scoreboard players operation #p c.t = #acacia_log c.p
scoreboard players operation #h c.t = #acacia_log c.h
scoreboard players operation #vs c.t = #acacia_log c.vs
scoreboard players operation #as c.t = #acacia_log c.as
scoreboard players operation #e c.t = #acacia_log c.ev
scoreboard players add #e c.t 1000
