scoreboard players set #b c.t 150
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"lapis_lazuli",n:"Lapis-lazuli",i3:"049",cn:"Minerais",cb:13}
scoreboard players operation #p c.t = #lapis_lazuli c.p
scoreboard players operation #h c.t = #lapis_lazuli c.h
scoreboard players operation #vs c.t = #lapis_lazuli c.vs
scoreboard players operation #as c.t = #lapis_lazuli c.as
scoreboard players operation #e c.t = #lapis_lazuli c.ev
scoreboard players add #e c.t 1000
