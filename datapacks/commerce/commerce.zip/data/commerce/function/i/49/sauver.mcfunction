scoreboard players operation #lapis_lazuli c.p = #p c.t
scoreboard players operation #lapis_lazuli c.h = #h c.t
scoreboard players operation #lapis_lazuli c.vs = #vs c.t
scoreboard players operation #lapis_lazuli c.as = #as c.t
scoreboard players operation #lapis_lazuli c.ev = #e c.t
scoreboard players remove #lapis_lazuli c.ev 1000
