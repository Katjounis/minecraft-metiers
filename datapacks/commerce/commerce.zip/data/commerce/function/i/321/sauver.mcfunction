scoreboard players operation #bone_meal c.p = #p c.t
scoreboard players operation #bone_meal c.h = #h c.t
scoreboard players operation #bone_meal c.vs = #vs c.t
scoreboard players operation #bone_meal c.as = #as c.t
scoreboard players operation #bone_meal c.ev = #e c.t
scoreboard players remove #bone_meal c.ev 1000
