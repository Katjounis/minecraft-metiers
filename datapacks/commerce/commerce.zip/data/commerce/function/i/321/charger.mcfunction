scoreboard players set #b c.t 13
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"bone_meal",n:"Poudre d'os",i3:"321",cn:"Élevage et chasse",cb:111}
scoreboard players operation #p c.t = #bone_meal c.p
scoreboard players operation #h c.t = #bone_meal c.h
scoreboard players operation #vs c.t = #bone_meal c.vs
scoreboard players operation #as c.t = #bone_meal c.as
scoreboard players operation #e c.t = #bone_meal c.ev
scoreboard players add #e c.t 1000
