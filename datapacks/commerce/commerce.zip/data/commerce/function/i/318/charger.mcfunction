scoreboard players set #b c.t 300
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"armadillo_scute",n:"Écaille de tatou",i3:"318",cn:"Élevage et chasse",cb:1111}
scoreboard players operation #p c.t = #armadillo_scute c.p
scoreboard players operation #h c.t = #armadillo_scute c.h
scoreboard players operation #vs c.t = #armadillo_scute c.vs
scoreboard players operation #as c.t = #armadillo_scute c.as
scoreboard players operation #e c.t = #armadillo_scute c.ev
scoreboard players add #e c.t 1000
