scoreboard players operation #armadillo_scute c.p = #p c.t
scoreboard players operation #armadillo_scute c.h = #h c.t
scoreboard players operation #armadillo_scute c.vs = #vs c.t
scoreboard players operation #armadillo_scute c.as = #as c.t
scoreboard players operation #armadillo_scute c.ev = #e c.t
scoreboard players remove #armadillo_scute c.ev 1000
