scoreboard players set #b c.t 20
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"white_tulip",n:"Tulipe blanche",i3:"408",cn:"Fleurs et plantes",cb:1160}
scoreboard players operation #p c.t = #white_tulip c.p
scoreboard players operation #h c.t = #white_tulip c.h
scoreboard players operation #vs c.t = #white_tulip c.vs
scoreboard players operation #as c.t = #white_tulip c.as
scoreboard players operation #e c.t = #white_tulip c.ev
scoreboard players add #e c.t 1000
