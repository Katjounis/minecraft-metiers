scoreboard players set #b c.t 20
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
scoreboard players set #cher c.t 1
data modify storage commerce:t it set value {id:"oxeye_daisy",n:"Marguerite",i3:"408",cn:"Fleurs et plantes",cb:1160}
scoreboard players operation #p c.t = #oxeye_daisy c.p
scoreboard players operation #h c.t = #oxeye_daisy c.h
scoreboard players operation #vs c.t = #oxeye_daisy c.vs
scoreboard players operation #as c.t = #oxeye_daisy c.as
scoreboard players operation #e c.t = #oxeye_daisy c.ev
scoreboard players add #e c.t 1000
