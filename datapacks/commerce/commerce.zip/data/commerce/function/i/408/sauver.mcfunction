scoreboard players operation #oxeye_daisy c.p = #p c.t
scoreboard players operation #oxeye_daisy c.h = #h c.t
scoreboard players operation #oxeye_daisy c.vs = #vs c.t
scoreboard players operation #oxeye_daisy c.as = #as c.t
scoreboard players operation #oxeye_daisy c.ev = #e c.t
scoreboard players remove #oxeye_daisy c.ev 1000
