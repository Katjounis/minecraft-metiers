scoreboard players operation #white_tulip c.p = #p c.t
scoreboard players operation #white_tulip c.h = #h c.t
scoreboard players operation #white_tulip c.vs = #vs c.t
scoreboard players operation #white_tulip c.as = #as c.t
scoreboard players operation #white_tulip c.ev = #e c.t
scoreboard players remove #white_tulip c.ev 1000
