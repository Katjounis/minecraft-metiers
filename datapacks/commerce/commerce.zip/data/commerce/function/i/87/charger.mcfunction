scoreboard players set #b c.t 90
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
scoreboard players set #cher c.t 1
data modify storage commerce:t it set value {id:"stripped_bamboo_block",n:"Bloc de bambou écorcé",i3:"087",cn:"Bûches",cb:1032}
scoreboard players operation #p c.t = #stripped_bamboo_block c.p
scoreboard players operation #h c.t = #stripped_bamboo_block c.h
scoreboard players operation #vs c.t = #stripped_bamboo_block c.vs
scoreboard players operation #as c.t = #stripped_bamboo_block c.as
scoreboard players operation #e c.t = #stripped_bamboo_block c.ev
scoreboard players add #e c.t 1000
