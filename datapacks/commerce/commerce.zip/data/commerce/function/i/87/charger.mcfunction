scoreboard players set #b c.t 150
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"salmon",n:"Saumon cru",i3:"087",cn:"Pêche",cb:16}
scoreboard players operation #p c.t = #salmon c.p
scoreboard players operation #h c.t = #salmon c.h
scoreboard players operation #vs c.t = #salmon c.vs
scoreboard players operation #as c.t = #salmon c.as
scoreboard players operation #e c.t = #salmon c.ev
scoreboard players add #e c.t 1000
