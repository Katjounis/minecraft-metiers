scoreboard players operation #salmon c.p = #p c.t
scoreboard players operation #salmon c.h = #h c.t
scoreboard players operation #salmon c.vs = #vs c.t
scoreboard players operation #salmon c.as = #as c.t
scoreboard players operation #salmon c.ev = #e c.t
scoreboard players remove #salmon c.ev 1000
