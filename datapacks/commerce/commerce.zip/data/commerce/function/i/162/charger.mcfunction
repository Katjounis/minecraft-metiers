scoreboard players set #b c.t 22
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"light_gray_concrete",n:"Béton gris clair",i3:"162",cn:"Béton et terre cuite",cb:106}
scoreboard players operation #p c.t = #light_gray_concrete c.p
scoreboard players operation #h c.t = #light_gray_concrete c.h
scoreboard players operation #vs c.t = #light_gray_concrete c.vs
scoreboard players operation #as c.t = #light_gray_concrete c.as
scoreboard players operation #e c.t = #light_gray_concrete c.ev
scoreboard players add #e c.t 1000
