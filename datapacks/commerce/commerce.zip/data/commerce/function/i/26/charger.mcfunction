scoreboard players set #b c.t 20
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"white_concrete",n:"Béton blanc",i3:"026",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #white_concrete c.p
scoreboard players operation #h c.t = #white_concrete c.h
scoreboard players operation #vs c.t = #white_concrete c.vs
scoreboard players operation #as c.t = #white_concrete c.as
scoreboard players operation #e c.t = #white_concrete c.ev
scoreboard players add #e c.t 1000
