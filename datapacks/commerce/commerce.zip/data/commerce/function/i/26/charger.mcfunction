scoreboard players set #b c.t 5
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"pointed_dripstone",n:"Spéléothème",i3:"026",cn:"Pierres",cb:101}
scoreboard players operation #p c.t = #pointed_dripstone c.p
scoreboard players operation #h c.t = #pointed_dripstone c.h
scoreboard players operation #vs c.t = #pointed_dripstone c.vs
scoreboard players operation #as c.t = #pointed_dripstone c.as
scoreboard players operation #e c.t = #pointed_dripstone c.ev
scoreboard players add #e c.t 1000
