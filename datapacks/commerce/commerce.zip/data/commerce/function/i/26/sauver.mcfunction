scoreboard players operation #pointed_dripstone c.p = #p c.t
scoreboard players operation #pointed_dripstone c.h = #h c.t
scoreboard players operation #pointed_dripstone c.vs = #vs c.t
scoreboard players operation #pointed_dripstone c.as = #as c.t
scoreboard players operation #pointed_dripstone c.ev = #e c.t
scoreboard players remove #pointed_dripstone c.ev 1000
