scoreboard players operation #white_concrete c.p = #p c.t
scoreboard players operation #white_concrete c.h = #h c.t
scoreboard players operation #white_concrete c.vs = #vs c.t
scoreboard players operation #white_concrete c.as = #as c.t
scoreboard players operation #white_concrete c.ev = #e c.t
scoreboard players remove #white_concrete c.ev 1000
