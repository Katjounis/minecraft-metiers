scoreboard players set #b c.t 1000
scoreboard players set #V c.t 64
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"turtle_scute",n:"Écaille de tortue",i3:"317",cn:"Élevage et chasse",cb:1111}
scoreboard players operation #p c.t = #turtle_scute c.p
scoreboard players operation #h c.t = #turtle_scute c.h
scoreboard players operation #vs c.t = #turtle_scute c.vs
scoreboard players operation #as c.t = #turtle_scute c.as
scoreboard players operation #e c.t = #turtle_scute c.ev
scoreboard players add #e c.t 1000
