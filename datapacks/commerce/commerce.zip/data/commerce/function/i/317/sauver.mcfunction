scoreboard players operation #turtle_scute c.p = #p c.t
scoreboard players operation #turtle_scute c.h = #h c.t
scoreboard players operation #turtle_scute c.vs = #vs c.t
scoreboard players operation #turtle_scute c.as = #as c.t
scoreboard players operation #turtle_scute c.ev = #e c.t
scoreboard players remove #turtle_scute c.ev 1000
