scoreboard players set #b c.t 26
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"black_concrete",n:"Béton noir",i3:"169",cn:"Béton et terre cuite",cb:1061}
scoreboard players operation #p c.t = #black_concrete c.p
scoreboard players operation #h c.t = #black_concrete c.h
scoreboard players operation #vs c.t = #black_concrete c.vs
scoreboard players operation #as c.t = #black_concrete c.as
scoreboard players operation #e c.t = #black_concrete c.ev
scoreboard players add #e c.t 1000
