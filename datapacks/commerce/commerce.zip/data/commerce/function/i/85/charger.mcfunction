scoreboard players set #b c.t 400
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"phantom_membrane",n:"Membrane de Phantom",i3:"085",cn:"Élevage et chasse",cb:15}
scoreboard players operation #p c.t = #phantom_membrane c.p
scoreboard players operation #h c.t = #phantom_membrane c.h
scoreboard players operation #vs c.t = #phantom_membrane c.vs
scoreboard players operation #as c.t = #phantom_membrane c.as
scoreboard players operation #e c.t = #phantom_membrane c.ev
scoreboard players add #e c.t 1000
