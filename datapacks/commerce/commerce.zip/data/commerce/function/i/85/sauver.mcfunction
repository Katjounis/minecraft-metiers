scoreboard players operation #phantom_membrane c.p = #p c.t
scoreboard players operation #phantom_membrane c.h = #h c.t
scoreboard players operation #phantom_membrane c.vs = #vs c.t
scoreboard players operation #phantom_membrane c.as = #as c.t
scoreboard players operation #phantom_membrane c.ev = #e c.t
scoreboard players remove #phantom_membrane c.ev 1000
