scoreboard players set #b c.t 20
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"ladder",n:"Échelle",i3:"370",cn:"Utilitaires",cb:114}
scoreboard players operation #p c.t = #ladder c.p
scoreboard players operation #h c.t = #ladder c.h
scoreboard players operation #vs c.t = #ladder c.vs
scoreboard players operation #as c.t = #ladder c.as
scoreboard players operation #e c.t = #ladder c.ev
scoreboard players add #e c.t 1000
