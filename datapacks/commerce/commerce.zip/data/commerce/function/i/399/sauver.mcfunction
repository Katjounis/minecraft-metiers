scoreboard players operation #cauldron c.p = #p c.t
scoreboard players operation #cauldron c.h = #h c.t
scoreboard players operation #cauldron c.vs = #vs c.t
scoreboard players operation #cauldron c.as = #as c.t
scoreboard players operation #cauldron c.ev = #e c.t
scoreboard players remove #cauldron c.ev 1000
