scoreboard players set #b c.t 20
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"poppy",n:"Coquelicot",i3:"399",cn:"Fleurs et plantes",cb:1160}
scoreboard players operation #p c.t = #poppy c.p
scoreboard players operation #h c.t = #poppy c.h
scoreboard players operation #vs c.t = #poppy c.vs
scoreboard players operation #as c.t = #poppy c.as
scoreboard players operation #e c.t = #poppy c.ev
scoreboard players add #e c.t 1000
