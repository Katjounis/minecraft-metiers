scoreboard players set #b c.t 5600
scoreboard players set #V c.t 32
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cauldron",n:"Chaudron",i3:"399",cn:"Utilitaires",cb:1143}
scoreboard players operation #p c.t = #cauldron c.p
scoreboard players operation #h c.t = #cauldron c.h
scoreboard players operation #vs c.t = #cauldron c.vs
scoreboard players operation #as c.t = #cauldron c.as
scoreboard players operation #e c.t = #cauldron c.ev
scoreboard players add #e c.t 1000
