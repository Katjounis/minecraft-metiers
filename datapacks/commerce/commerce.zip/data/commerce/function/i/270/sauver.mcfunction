scoreboard players operation #quartz_bricks c.p = #p c.t
scoreboard players operation #quartz_bricks c.h = #h c.t
scoreboard players operation #quartz_bricks c.vs = #vs c.t
scoreboard players operation #quartz_bricks c.as = #as c.t
scoreboard players operation #quartz_bricks c.ev = #e c.t
scoreboard players remove #quartz_bricks c.ev 1000
