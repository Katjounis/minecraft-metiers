scoreboard players operation #campfire c.p = #p c.t
scoreboard players operation #campfire c.h = #h c.t
scoreboard players operation #campfire c.vs = #vs c.t
scoreboard players operation #campfire c.as = #as c.t
scoreboard players operation #campfire c.ev = #e c.t
scoreboard players remove #campfire c.ev 1000
