scoreboard players set #b c.t 200
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"campfire",n:"Feu de camp",i3:"365",cn:"Utilitaires",cb:114}
scoreboard players operation #p c.t = #campfire c.p
scoreboard players operation #h c.t = #campfire c.h
scoreboard players operation #vs c.t = #campfire c.vs
scoreboard players operation #as c.t = #campfire c.as
scoreboard players operation #e c.t = #campfire c.ev
scoreboard players add #e c.t 1000
