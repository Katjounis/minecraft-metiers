scoreboard players operation #enchanted_golden_apple c.p = #p c.t
scoreboard players operation #enchanted_golden_apple c.h = #h c.t
scoreboard players operation #enchanted_golden_apple c.vs = #vs c.t
scoreboard players operation #enchanted_golden_apple c.as = #as c.t
scoreboard players operation #enchanted_golden_apple c.ev = #e c.t
scoreboard players remove #enchanted_golden_apple c.ev 1000
