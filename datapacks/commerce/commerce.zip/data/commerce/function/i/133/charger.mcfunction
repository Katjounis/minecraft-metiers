scoreboard players set #b c.t 100000
scoreboard players set #V c.t 4
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"enchanted_golden_apple",n:"Pomme de Notch",i3:"133",cn:"Trésors",cb:19}
scoreboard players operation #p c.t = #enchanted_golden_apple c.p
scoreboard players operation #h c.t = #enchanted_golden_apple c.h
scoreboard players operation #vs c.t = #enchanted_golden_apple c.vs
scoreboard players operation #as c.t = #enchanted_golden_apple c.as
scoreboard players operation #e c.t = #enchanted_golden_apple c.ev
scoreboard players add #e c.t 1000
