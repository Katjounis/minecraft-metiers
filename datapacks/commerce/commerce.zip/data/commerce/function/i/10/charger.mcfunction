scoreboard players set #b c.t 10
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"blackstone",n:"Roche noire",i3:"010",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #blackstone c.p
scoreboard players operation #h c.t = #blackstone c.h
scoreboard players operation #vs c.t = #blackstone c.vs
scoreboard players operation #as c.t = #blackstone c.as
scoreboard players operation #e c.t = #blackstone c.ev
scoreboard players add #e c.t 1000
