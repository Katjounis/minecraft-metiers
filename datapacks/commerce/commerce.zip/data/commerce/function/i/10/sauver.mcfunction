scoreboard players operation #blackstone c.p = #p c.t
scoreboard players operation #blackstone c.h = #h c.t
scoreboard players operation #blackstone c.vs = #vs c.t
scoreboard players operation #blackstone c.as = #as c.t
scoreboard players operation #blackstone c.ev = #e c.t
scoreboard players remove #blackstone c.ev 1000
