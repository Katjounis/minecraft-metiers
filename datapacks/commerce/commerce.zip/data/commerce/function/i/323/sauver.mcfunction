scoreboard players operation #gunpowder c.p = #p c.t
scoreboard players operation #gunpowder c.h = #h c.t
scoreboard players operation #gunpowder c.vs = #vs c.t
scoreboard players operation #gunpowder c.as = #as c.t
scoreboard players operation #gunpowder c.ev = #e c.t
scoreboard players remove #gunpowder c.ev 1000
