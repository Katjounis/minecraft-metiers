scoreboard players set #b c.t 200
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"gunpowder",n:"Poudre à canon",i3:"323",cn:"Élevage et chasse",cb:111}
scoreboard players operation #p c.t = #gunpowder c.p
scoreboard players operation #h c.t = #gunpowder c.h
scoreboard players operation #vs c.t = #gunpowder c.vs
scoreboard players operation #as c.t = #gunpowder c.as
scoreboard players operation #e c.t = #gunpowder c.ev
scoreboard players add #e c.t 1000
