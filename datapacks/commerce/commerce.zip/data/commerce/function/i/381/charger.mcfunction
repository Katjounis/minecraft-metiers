scoreboard players set #b c.t 380
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
scoreboard players set #cher c.t 1
data modify storage commerce:t it set value {id:"observer",n:"Observateur",i3:"381",cn:"Utilitaires",cb:1142}
scoreboard players operation #p c.t = #observer c.p
scoreboard players operation #h c.t = #observer c.h
scoreboard players operation #vs c.t = #observer c.vs
scoreboard players operation #as c.t = #observer c.as
scoreboard players operation #e c.t = #observer c.ev
scoreboard players add #e c.t 1000
