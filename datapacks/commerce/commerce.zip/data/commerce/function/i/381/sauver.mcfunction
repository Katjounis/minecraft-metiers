scoreboard players operation #observer c.p = #p c.t
scoreboard players operation #observer c.h = #h c.t
scoreboard players operation #observer c.vs = #vs c.t
scoreboard players operation #observer c.as = #as c.t
scoreboard players operation #observer c.ev = #e c.t
scoreboard players remove #observer c.ev 1000
