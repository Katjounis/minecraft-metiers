scoreboard players operation #rabbit c.p = #p c.t
scoreboard players operation #rabbit c.h = #h c.t
scoreboard players operation #rabbit c.vs = #vs c.t
scoreboard players operation #rabbit c.as = #as c.t
scoreboard players operation #rabbit c.ev = #e c.t
scoreboard players remove #rabbit c.ev 1000
