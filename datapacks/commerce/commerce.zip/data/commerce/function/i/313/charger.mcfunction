scoreboard players set #b c.t 150
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"rabbit",n:"Lapin cru",i3:"313",cn:"Élevage et chasse",cb:1111}
scoreboard players operation #p c.t = #rabbit c.p
scoreboard players operation #h c.t = #rabbit c.h
scoreboard players operation #vs c.t = #rabbit c.vs
scoreboard players operation #as c.t = #rabbit c.as
scoreboard players operation #e c.t = #rabbit c.ev
scoreboard players add #e c.t 1000
