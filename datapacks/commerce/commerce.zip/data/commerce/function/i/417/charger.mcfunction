scoreboard players set #b c.t 20
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"pink_petals",n:"Pétales roses",i3:"417",cn:"Fleurs et plantes",cb:1161}
scoreboard players operation #p c.t = #pink_petals c.p
scoreboard players operation #h c.t = #pink_petals c.h
scoreboard players operation #vs c.t = #pink_petals c.vs
scoreboard players operation #as c.t = #pink_petals c.as
scoreboard players operation #e c.t = #pink_petals c.ev
scoreboard players add #e c.t 1000
