scoreboard players operation #cactus_flower c.p = #p c.t
scoreboard players operation #cactus_flower c.h = #h c.t
scoreboard players operation #cactus_flower c.vs = #vs c.t
scoreboard players operation #cactus_flower c.as = #as c.t
scoreboard players operation #cactus_flower c.ev = #e c.t
scoreboard players remove #cactus_flower c.ev 1000
