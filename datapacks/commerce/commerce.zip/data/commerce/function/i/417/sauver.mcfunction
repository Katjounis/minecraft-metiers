scoreboard players operation #pink_petals c.p = #p c.t
scoreboard players operation #pink_petals c.h = #h c.t
scoreboard players operation #pink_petals c.vs = #vs c.t
scoreboard players operation #pink_petals c.as = #as c.t
scoreboard players operation #pink_petals c.ev = #e c.t
scoreboard players remove #pink_petals c.ev 1000
