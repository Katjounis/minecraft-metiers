scoreboard players set #b c.t 190
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"raw_copper",n:"Cuivre brut",i3:"223",cn:"Minerais et métaux",cb:108}
scoreboard players operation #p c.t = #raw_copper c.p
scoreboard players operation #h c.t = #raw_copper c.h
scoreboard players operation #vs c.t = #raw_copper c.vs
scoreboard players operation #as c.t = #raw_copper c.as
scoreboard players operation #e c.t = #raw_copper c.ev
scoreboard players add #e c.t 1000
