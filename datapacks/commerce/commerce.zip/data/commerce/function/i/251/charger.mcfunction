scoreboard players set #b c.t 2
scoreboard players set #V c.t 4096
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"nether_brick",n:"Brique du Nether",i3:"251",cn:"Nether et End",cb:109}
scoreboard players operation #p c.t = #nether_brick c.p
scoreboard players operation #h c.t = #nether_brick c.h
scoreboard players operation #vs c.t = #nether_brick c.vs
scoreboard players operation #as c.t = #nether_brick c.as
scoreboard players operation #e c.t = #nether_brick c.ev
scoreboard players add #e c.t 1000
