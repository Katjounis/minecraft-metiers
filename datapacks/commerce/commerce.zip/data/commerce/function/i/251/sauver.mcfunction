scoreboard players operation #nether_brick c.p = #p c.t
scoreboard players operation #nether_brick c.h = #h c.t
scoreboard players operation #nether_brick c.vs = #vs c.t
scoreboard players operation #nether_brick c.as = #as c.t
scoreboard players operation #nether_brick c.ev = #e c.t
scoreboard players remove #nether_brick c.ev 1000
