scoreboard players set #b c.t 50
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"string",n:"Ficelle",i3:"079",cn:"Élevage et chasse",cb:15}
scoreboard players operation #p c.t = #string c.p
scoreboard players operation #h c.t = #string c.h
scoreboard players operation #vs c.t = #string c.vs
scoreboard players operation #as c.t = #string c.as
scoreboard players operation #e c.t = #string c.ev
scoreboard players add #e c.t 1000
