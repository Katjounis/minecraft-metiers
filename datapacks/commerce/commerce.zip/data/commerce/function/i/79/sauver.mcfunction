scoreboard players operation #string c.p = #p c.t
scoreboard players operation #string c.h = #h c.t
scoreboard players operation #string c.vs = #vs c.t
scoreboard players operation #string c.as = #as c.t
scoreboard players operation #string c.ev = #e c.t
scoreboard players remove #string c.ev 1000
