scoreboard players operation #honeycomb c.p = #p c.t
scoreboard players operation #honeycomb c.h = #h c.t
scoreboard players operation #honeycomb c.vs = #vs c.t
scoreboard players operation #honeycomb c.as = #as c.t
scoreboard players operation #honeycomb c.ev = #e c.t
scoreboard players remove #honeycomb c.ev 1000
