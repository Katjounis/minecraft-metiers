scoreboard players set #b c.t 200
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"honeycomb",n:"Rayon de miel",i3:"076",cn:"Élevage et chasse",cb:15}
scoreboard players operation #p c.t = #honeycomb c.p
scoreboard players operation #h c.t = #honeycomb c.h
scoreboard players operation #vs c.t = #honeycomb c.vs
scoreboard players operation #as c.t = #honeycomb c.as
scoreboard players operation #e c.t = #honeycomb c.ev
scoreboard players add #e c.t 1000
