scoreboard players set #b c.t 400
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"amethyst_block",n:"Bloc d'améthyste",i3:"245",cn:"Minerais et métaux",cb:1082}
scoreboard players operation #p c.t = #amethyst_block c.p
scoreboard players operation #h c.t = #amethyst_block c.h
scoreboard players operation #vs c.t = #amethyst_block c.vs
scoreboard players operation #as c.t = #amethyst_block c.as
scoreboard players operation #e c.t = #amethyst_block c.ev
scoreboard players add #e c.t 1000
