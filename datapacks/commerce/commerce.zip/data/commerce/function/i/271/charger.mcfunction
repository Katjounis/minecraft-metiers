scoreboard players set #b c.t 600
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"quartz_pillar",n:"Pilier de quartz",i3:"271",cn:"Nether et End",cb:1092}
scoreboard players operation #p c.t = #quartz_pillar c.p
scoreboard players operation #h c.t = #quartz_pillar c.h
scoreboard players operation #vs c.t = #quartz_pillar c.vs
scoreboard players operation #as c.t = #quartz_pillar c.as
scoreboard players operation #e c.t = #quartz_pillar c.ev
scoreboard players add #e c.t 1000
