scoreboard players set #b c.t 250
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"pale_oak_log",n:"Bûche de chêne pâle",i3:"080",cn:"Bûches",cb:103}
scoreboard players operation #p c.t = #pale_oak_log c.p
scoreboard players operation #h c.t = #pale_oak_log c.h
scoreboard players operation #vs c.t = #pale_oak_log c.vs
scoreboard players operation #as c.t = #pale_oak_log c.as
scoreboard players operation #e c.t = #pale_oak_log c.ev
scoreboard players add #e c.t 1000
