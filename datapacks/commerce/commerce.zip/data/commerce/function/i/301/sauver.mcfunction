scoreboard players operation #bamboo c.p = #p c.t
scoreboard players operation #bamboo c.h = #h c.t
scoreboard players operation #bamboo c.vs = #vs c.t
scoreboard players operation #bamboo c.as = #as c.t
scoreboard players operation #bamboo c.ev = #e c.t
scoreboard players remove #bamboo c.ev 1000
