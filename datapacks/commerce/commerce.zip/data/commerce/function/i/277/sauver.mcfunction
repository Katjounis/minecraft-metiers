scoreboard players operation #purpur_block c.p = #p c.t
scoreboard players operation #purpur_block c.h = #h c.t
scoreboard players operation #purpur_block c.vs = #vs c.t
scoreboard players operation #purpur_block c.as = #as c.t
scoreboard players operation #purpur_block c.ev = #e c.t
scoreboard players remove #purpur_block c.ev 1000
