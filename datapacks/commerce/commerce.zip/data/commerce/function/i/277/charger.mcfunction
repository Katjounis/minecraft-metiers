scoreboard players set #b c.t 30
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"purpur_block",n:"Bloc de purpur",i3:"277",cn:"Nether et End",cb:1092}
scoreboard players operation #p c.t = #purpur_block c.p
scoreboard players operation #h c.t = #purpur_block c.h
scoreboard players operation #vs c.t = #purpur_block c.vs
scoreboard players operation #as c.t = #purpur_block c.as
scoreboard players operation #e c.t = #purpur_block c.ev
scoreboard players add #e c.t 1000
