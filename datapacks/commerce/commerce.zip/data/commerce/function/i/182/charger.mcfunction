scoreboard players set #b c.t 122
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"blue_terracotta",n:"Terre cuite bleue",i3:"182",cn:"Béton et terre cuite",cb:106}
scoreboard players operation #p c.t = #blue_terracotta c.p
scoreboard players operation #h c.t = #blue_terracotta c.h
scoreboard players operation #vs c.t = #blue_terracotta c.vs
scoreboard players operation #as c.t = #blue_terracotta c.as
scoreboard players operation #e c.t = #blue_terracotta c.ev
scoreboard players add #e c.t 1000
