scoreboard players set #b c.t 300
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"lantern",n:"Lanterne",i3:"107",cn:"Utilitaires",cb:18}
scoreboard players operation #p c.t = #lantern c.p
scoreboard players operation #h c.t = #lantern c.h
scoreboard players operation #vs c.t = #lantern c.vs
scoreboard players operation #as c.t = #lantern c.as
scoreboard players operation #e c.t = #lantern c.ev
scoreboard players add #e c.t 1000
