scoreboard players set #b c.t 10800
scoreboard players set #V c.t 32
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"gold_block",n:"Bloc d'or",i3:"237",cn:"Minerais et métaux",cb:108}
scoreboard players operation #p c.t = #gold_block c.p
scoreboard players operation #h c.t = #gold_block c.h
scoreboard players operation #vs c.t = #gold_block c.vs
scoreboard players operation #as c.t = #gold_block c.as
scoreboard players operation #e c.t = #gold_block c.ev
scoreboard players add #e c.t 1000
