scoreboard players operation #shield c.p = #p c.t
scoreboard players operation #shield c.h = #h c.t
scoreboard players operation #shield c.vs = #vs c.t
scoreboard players operation #shield c.as = #as c.t
scoreboard players operation #shield c.ev = #e c.t
scoreboard players remove #shield c.ev 1000
