scoreboard players set #b c.t 1000
scoreboard players set #V c.t 64
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"shield",n:"Bouclier",i3:"395",cn:"Utilitaires",cb:1143}
scoreboard players operation #p c.t = #shield c.p
scoreboard players operation #h c.t = #shield c.h
scoreboard players operation #vs c.t = #shield c.vs
scoreboard players operation #as c.t = #shield c.as
scoreboard players operation #e c.t = #shield c.ev
scoreboard players add #e c.t 1000
