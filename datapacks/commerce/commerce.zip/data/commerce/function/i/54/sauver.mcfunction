scoreboard players operation #gravel c.p = #p c.t
scoreboard players operation #gravel c.h = #h c.t
scoreboard players operation #gravel c.vs = #vs c.t
scoreboard players operation #gravel c.as = #as c.t
scoreboard players operation #gravel c.ev = #e c.t
scoreboard players remove #gravel c.ev 1000
