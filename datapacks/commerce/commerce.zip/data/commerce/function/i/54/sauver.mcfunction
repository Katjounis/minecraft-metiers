scoreboard players operation #wheat c.p = #p c.t
scoreboard players operation #wheat c.h = #h c.t
scoreboard players operation #wheat c.vs = #vs c.t
scoreboard players operation #wheat c.as = #as c.t
scoreboard players operation #wheat c.ev = #e c.t
scoreboard players remove #wheat c.ev 1000
