scoreboard players set #b c.t 6
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"gravel",n:"Gravier",i3:"054",cn:"Terre et glace",cb:102}
scoreboard players operation #p c.t = #gravel c.p
scoreboard players operation #h c.t = #gravel c.h
scoreboard players operation #vs c.t = #gravel c.vs
scoreboard players operation #as c.t = #gravel c.as
scoreboard players operation #e c.t = #gravel c.ev
scoreboard players add #e c.t 1000
