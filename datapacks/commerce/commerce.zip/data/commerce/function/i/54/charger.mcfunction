scoreboard players set #b c.t 100
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"wheat",n:"Blé",i3:"054",cn:"Agriculture",cb:14}
scoreboard players operation #p c.t = #wheat c.p
scoreboard players operation #h c.t = #wheat c.h
scoreboard players operation #vs c.t = #wheat c.vs
scoreboard players operation #as c.t = #wheat c.as
scoreboard players operation #e c.t = #wheat c.ev
scoreboard players add #e c.t 1000
