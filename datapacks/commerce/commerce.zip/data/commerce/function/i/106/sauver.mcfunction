scoreboard players operation #torch c.p = #p c.t
scoreboard players operation #torch c.h = #h c.t
scoreboard players operation #torch c.vs = #vs c.t
scoreboard players operation #torch c.as = #as c.t
scoreboard players operation #torch c.ev = #e c.t
scoreboard players remove #torch c.ev 1000
