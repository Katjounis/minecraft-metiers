scoreboard players set #b c.t 30
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"torch",n:"Torche",i3:"106",cn:"Utilitaires",cb:18}
scoreboard players operation #p c.t = #torch c.p
scoreboard players operation #h c.t = #torch c.h
scoreboard players operation #vs c.t = #torch c.vs
scoreboard players operation #as c.t = #torch c.as
scoreboard players operation #e c.t = #torch c.ev
scoreboard players add #e c.t 1000
