scoreboard players set #b c.t 50
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
scoreboard players set #cher c.t 1
data modify storage commerce:t it set value {id:"mangrove_planks",n:"Planches de palétuvier",i3:"106",cn:"Planches et feuillage",cb:1041}
scoreboard players operation #p c.t = #mangrove_planks c.p
scoreboard players operation #h c.t = #mangrove_planks c.h
scoreboard players operation #vs c.t = #mangrove_planks c.vs
scoreboard players operation #as c.t = #mangrove_planks c.as
scoreboard players operation #e c.t = #mangrove_planks c.ev
scoreboard players add #e c.t 1000
