scoreboard players operation #lever c.p = #p c.t
scoreboard players operation #lever c.h = #h c.t
scoreboard players operation #lever c.vs = #vs c.t
scoreboard players operation #lever c.as = #as c.t
scoreboard players operation #lever c.ev = #e c.t
scoreboard players remove #lever c.ev 1000
