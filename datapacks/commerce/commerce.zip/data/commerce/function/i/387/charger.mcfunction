scoreboard players set #b c.t 10
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"lever",n:"Levier",i3:"387",cn:"Utilitaires",cb:114}
scoreboard players operation #p c.t = #lever c.p
scoreboard players operation #h c.t = #lever c.h
scoreboard players operation #vs c.t = #lever c.vs
scoreboard players operation #as c.t = #lever c.as
scoreboard players operation #e c.t = #lever c.ev
scoreboard players add #e c.t 1000
