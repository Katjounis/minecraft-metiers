scoreboard players set #b c.t 122
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
scoreboard players set #cher c.t 1
data modify storage commerce:t it set value {id:"yellow_terracotta",n:"Terre cuite jaune",i3:"175",cn:"Béton et terre cuite",cb:1062}
scoreboard players operation #p c.t = #yellow_terracotta c.p
scoreboard players operation #h c.t = #yellow_terracotta c.h
scoreboard players operation #vs c.t = #yellow_terracotta c.vs
scoreboard players operation #as c.t = #yellow_terracotta c.as
scoreboard players operation #e c.t = #yellow_terracotta c.ev
scoreboard players add #e c.t 1000
