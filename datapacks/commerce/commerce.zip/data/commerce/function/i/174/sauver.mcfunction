scoreboard players operation #light_blue_terracotta c.p = #p c.t
scoreboard players operation #light_blue_terracotta c.h = #h c.t
scoreboard players operation #light_blue_terracotta c.vs = #vs c.t
scoreboard players operation #light_blue_terracotta c.as = #as c.t
scoreboard players operation #light_blue_terracotta c.ev = #e c.t
scoreboard players remove #light_blue_terracotta c.ev 1000
