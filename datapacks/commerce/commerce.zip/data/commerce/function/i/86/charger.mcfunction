scoreboard players set #b c.t 100
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cod",n:"Morue crue",i3:"086",cn:"Pêche",cb:16}
scoreboard players operation #p c.t = #cod c.p
scoreboard players operation #h c.t = #cod c.h
scoreboard players operation #vs c.t = #cod c.vs
scoreboard players operation #as c.t = #cod c.as
scoreboard players operation #e c.t = #cod c.ev
scoreboard players add #e c.t 1000
