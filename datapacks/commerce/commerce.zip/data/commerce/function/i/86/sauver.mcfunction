scoreboard players operation #cod c.p = #p c.t
scoreboard players operation #cod c.h = #h c.t
scoreboard players operation #cod c.vs = #vs c.t
scoreboard players operation #cod c.as = #as c.t
scoreboard players operation #cod c.ev = #e c.t
scoreboard players remove #cod c.ev 1000
