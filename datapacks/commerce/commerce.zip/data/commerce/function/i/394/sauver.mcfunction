scoreboard players operation #arrow c.p = #p c.t
scoreboard players operation #arrow c.h = #h c.t
scoreboard players operation #arrow c.vs = #vs c.t
scoreboard players operation #arrow c.as = #as c.t
scoreboard players operation #arrow c.ev = #e c.t
scoreboard players remove #arrow c.ev 1000
