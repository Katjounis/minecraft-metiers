scoreboard players set #b c.t 18
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"arrow",n:"Flèche",i3:"394",cn:"Utilitaires",cb:114}
scoreboard players operation #p c.t = #arrow c.p
scoreboard players operation #h c.t = #arrow c.h
scoreboard players operation #vs c.t = #arrow c.vs
scoreboard players operation #as c.t = #arrow c.as
scoreboard players operation #e c.t = #arrow c.ev
scoreboard players add #e c.t 1000
