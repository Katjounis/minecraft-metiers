scoreboard players operation #cactus c.p = #p c.t
scoreboard players operation #cactus c.h = #h c.t
scoreboard players operation #cactus c.vs = #vs c.t
scoreboard players operation #cactus c.as = #as c.t
scoreboard players operation #cactus c.ev = #e c.t
scoreboard players remove #cactus c.ev 1000
