scoreboard players set #b c.t 20
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"jungle_sapling",n:"Pousse d'acajou",i3:"099",cn:"Planches et feuillage",cb:104}
scoreboard players operation #p c.t = #jungle_sapling c.p
scoreboard players operation #h c.t = #jungle_sapling c.h
scoreboard players operation #vs c.t = #jungle_sapling c.vs
scoreboard players operation #as c.t = #jungle_sapling c.as
scoreboard players operation #e c.t = #jungle_sapling c.ev
scoreboard players add #e c.t 1000
