scoreboard players set #b c.t 30
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cookie",n:"Cookie",i3:"099",cn:"Cuisine",cb:17}
scoreboard players operation #p c.t = #cookie c.p
scoreboard players operation #h c.t = #cookie c.h
scoreboard players operation #vs c.t = #cookie c.vs
scoreboard players operation #as c.t = #cookie c.as
scoreboard players operation #e c.t = #cookie c.ev
scoreboard players add #e c.t 1000
