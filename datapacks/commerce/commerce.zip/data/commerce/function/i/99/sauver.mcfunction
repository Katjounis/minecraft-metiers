scoreboard players operation #cookie c.p = #p c.t
scoreboard players operation #cookie c.h = #h c.t
scoreboard players operation #cookie c.vs = #vs c.t
scoreboard players operation #cookie c.as = #as c.t
scoreboard players operation #cookie c.ev = #e c.t
scoreboard players remove #cookie c.ev 1000
