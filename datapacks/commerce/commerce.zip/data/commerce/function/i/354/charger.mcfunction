scoreboard players set #b c.t 160
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cooked_porkchop",n:"Côtelette de porc cuite",i3:"354",cn:"Cuisine",cb:113}
scoreboard players operation #p c.t = #cooked_porkchop c.p
scoreboard players operation #h c.t = #cooked_porkchop c.h
scoreboard players operation #vs c.t = #cooked_porkchop c.vs
scoreboard players operation #as c.t = #cooked_porkchop c.as
scoreboard players operation #e c.t = #cooked_porkchop c.ev
scoreboard players add #e c.t 1000
