scoreboard players operation #cooked_porkchop c.p = #p c.t
scoreboard players operation #cooked_porkchop c.h = #h c.t
scoreboard players operation #cooked_porkchop c.vs = #vs c.t
scoreboard players operation #cooked_porkchop c.as = #as c.t
scoreboard players operation #cooked_porkchop c.ev = #e c.t
scoreboard players remove #cooked_porkchop c.ev 1000
