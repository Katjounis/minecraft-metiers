scoreboard players operation #peony c.p = #p c.t
scoreboard players operation #peony c.h = #h c.t
scoreboard players operation #peony c.vs = #vs c.t
scoreboard players operation #peony c.as = #as c.t
scoreboard players operation #peony c.ev = #e c.t
scoreboard players remove #peony c.ev 1000
