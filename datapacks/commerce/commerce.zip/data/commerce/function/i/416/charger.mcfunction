scoreboard players set #b c.t 30
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"peony",n:"Pivoine",i3:"416",cn:"Fleurs et plantes",cb:116}
scoreboard players operation #p c.t = #peony c.p
scoreboard players operation #h c.t = #peony c.h
scoreboard players operation #vs c.t = #peony c.vs
scoreboard players operation #as c.t = #peony c.as
scoreboard players operation #e c.t = #peony c.ev
scoreboard players add #e c.t 1000
