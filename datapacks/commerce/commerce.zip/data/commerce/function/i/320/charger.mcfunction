scoreboard players set #b c.t 40
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"bone",n:"Os",i3:"320",cn:"Élevage et chasse",cb:111}
scoreboard players operation #p c.t = #bone c.p
scoreboard players operation #h c.t = #bone c.h
scoreboard players operation #vs c.t = #bone c.vs
scoreboard players operation #as c.t = #bone c.as
scoreboard players operation #e c.t = #bone c.ev
scoreboard players add #e c.t 1000
