scoreboard players operation #bone c.p = #p c.t
scoreboard players operation #bone c.h = #h c.t
scoreboard players operation #bone c.vs = #vs c.t
scoreboard players operation #bone c.as = #as c.t
scoreboard players operation #bone c.ev = #e c.t
scoreboard players remove #bone c.ev 1000
