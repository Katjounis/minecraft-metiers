scoreboard players operation #mossy_cobblestone c.p = #p c.t
scoreboard players operation #mossy_cobblestone c.h = #h c.t
scoreboard players operation #mossy_cobblestone c.vs = #vs c.t
scoreboard players operation #mossy_cobblestone c.as = #as c.t
scoreboard players operation #mossy_cobblestone c.ev = #e c.t
scoreboard players remove #mossy_cobblestone c.ev 1000
