scoreboard players operation #cobbled_deepslate c.p = #p c.t
scoreboard players operation #cobbled_deepslate c.h = #h c.t
scoreboard players operation #cobbled_deepslate c.vs = #vs c.t
scoreboard players operation #cobbled_deepslate c.as = #as c.t
scoreboard players operation #cobbled_deepslate c.ev = #e c.t
scoreboard players remove #cobbled_deepslate c.ev 1000
