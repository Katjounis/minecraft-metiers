scoreboard players set #b c.t 6
scoreboard players set #V c.t 4096
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cobbled_deepslate",n:"Ardoise taillée",i3:"002",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #cobbled_deepslate c.p
scoreboard players operation #h c.t = #cobbled_deepslate c.h
scoreboard players operation #vs c.t = #cobbled_deepslate c.vs
scoreboard players operation #as c.t = #cobbled_deepslate c.as
scoreboard players operation #e c.t = #cobbled_deepslate c.ev
scoreboard players add #e c.t 1000
