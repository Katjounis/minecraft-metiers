scoreboard players set #b c.t 15
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"mossy_cobblestone",n:"Pierre taillée moussue",i3:"002",cn:"Pierres",cb:101}
scoreboard players operation #p c.t = #mossy_cobblestone c.p
scoreboard players operation #h c.t = #mossy_cobblestone c.h
scoreboard players operation #vs c.t = #mossy_cobblestone c.vs
scoreboard players operation #as c.t = #mossy_cobblestone c.as
scoreboard players operation #e c.t = #mossy_cobblestone c.ev
scoreboard players add #e c.t 1000
