scoreboard players set #b c.t 122
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"magenta_glazed_terracotta",n:"Terre cuite émaillée magenta",i3:"207",cn:"Verre",cb:107}
scoreboard players operation #p c.t = #magenta_glazed_terracotta c.p
scoreboard players operation #h c.t = #magenta_glazed_terracotta c.h
scoreboard players operation #vs c.t = #magenta_glazed_terracotta c.vs
scoreboard players operation #as c.t = #magenta_glazed_terracotta c.as
scoreboard players operation #e c.t = #magenta_glazed_terracotta c.ev
scoreboard players add #e c.t 1000
