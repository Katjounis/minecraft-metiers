scoreboard players set #b c.t 100
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"chicken",n:"Poulet cru",i3:"073",cn:"Élevage et chasse",cb:15}
scoreboard players operation #p c.t = #chicken c.p
scoreboard players operation #h c.t = #chicken c.h
scoreboard players operation #vs c.t = #chicken c.vs
scoreboard players operation #as c.t = #chicken c.as
scoreboard players operation #e c.t = #chicken c.ev
scoreboard players add #e c.t 1000
