scoreboard players operation #chicken c.p = #p c.t
scoreboard players operation #chicken c.h = #h c.t
scoreboard players operation #chicken c.vs = #vs c.t
scoreboard players operation #chicken c.as = #as c.t
scoreboard players operation #chicken c.ev = #e c.t
scoreboard players remove #chicken c.ev 1000
