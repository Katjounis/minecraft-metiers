scoreboard players set #b c.t 5
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"wheat_seeds",n:"Graines de blé",i3:"055",cn:"Agriculture",cb:14}
scoreboard players operation #p c.t = #wheat_seeds c.p
scoreboard players operation #h c.t = #wheat_seeds c.h
scoreboard players operation #vs c.t = #wheat_seeds c.vs
scoreboard players operation #as c.t = #wheat_seeds c.as
scoreboard players operation #e c.t = #wheat_seeds c.ev
scoreboard players add #e c.t 1000
