scoreboard players set #b c.t 8
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"andesite",n:"Andésite",i3:"005",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #andesite c.p
scoreboard players operation #h c.t = #andesite c.h
scoreboard players operation #vs c.t = #andesite c.vs
scoreboard players operation #as c.t = #andesite c.as
scoreboard players operation #e c.t = #andesite c.ev
scoreboard players add #e c.t 1000
