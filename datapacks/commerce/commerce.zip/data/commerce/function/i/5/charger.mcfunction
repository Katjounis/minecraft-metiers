scoreboard players set #b c.t 10
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"stone_bricks",n:"Briques de pierre",i3:"005",cn:"Pierres",cb:1010}
scoreboard players operation #p c.t = #stone_bricks c.p
scoreboard players operation #h c.t = #stone_bricks c.h
scoreboard players operation #vs c.t = #stone_bricks c.vs
scoreboard players operation #as c.t = #stone_bricks c.as
scoreboard players operation #e c.t = #stone_bricks c.ev
scoreboard players add #e c.t 1000
