scoreboard players operation #spruce_sapling c.p = #p c.t
scoreboard players operation #spruce_sapling c.h = #h c.t
scoreboard players operation #spruce_sapling c.vs = #vs c.t
scoreboard players operation #spruce_sapling c.as = #as c.t
scoreboard players operation #spruce_sapling c.ev = #e c.t
scoreboard players remove #spruce_sapling c.ev 1000
