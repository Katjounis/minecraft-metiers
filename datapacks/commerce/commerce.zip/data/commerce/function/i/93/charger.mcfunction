scoreboard players set #b c.t 20
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"spruce_sapling",n:"Pousse de sapin",i3:"093",cn:"Planches et feuillage",cb:1040}
scoreboard players operation #p c.t = #spruce_sapling c.p
scoreboard players operation #h c.t = #spruce_sapling c.h
scoreboard players operation #vs c.t = #spruce_sapling c.vs
scoreboard players operation #as c.t = #spruce_sapling c.as
scoreboard players operation #e c.t = #spruce_sapling c.ev
scoreboard players add #e c.t 1000
