scoreboard players set #b c.t 12
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"deepslate",n:"Ardoise des abîmes",i3:"004",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #deepslate c.p
scoreboard players operation #h c.t = #deepslate c.h
scoreboard players operation #vs c.t = #deepslate c.vs
scoreboard players operation #as c.t = #deepslate c.as
scoreboard players operation #e c.t = #deepslate c.ev
scoreboard players add #e c.t 1000
