scoreboard players operation #deepslate c.p = #p c.t
scoreboard players operation #deepslate c.h = #h c.t
scoreboard players operation #deepslate c.vs = #vs c.t
scoreboard players operation #deepslate c.as = #as c.t
scoreboard players operation #deepslate c.ev = #e c.t
scoreboard players remove #deepslate c.ev 1000
