scoreboard players operation #ink_sac c.p = #p c.t
scoreboard players operation #ink_sac c.h = #h c.t
scoreboard players operation #ink_sac c.vs = #vs c.t
scoreboard players operation #ink_sac c.as = #as c.t
scoreboard players operation #ink_sac c.ev = #e c.t
scoreboard players remove #ink_sac c.ev 1000
