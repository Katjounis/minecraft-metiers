scoreboard players set #b c.t 8
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"polished_basalt",n:"Basalte poli",i3:"255",cn:"Nether et End",cb:1090}
scoreboard players operation #p c.t = #polished_basalt c.p
scoreboard players operation #h c.t = #polished_basalt c.h
scoreboard players operation #vs c.t = #polished_basalt c.vs
scoreboard players operation #as c.t = #polished_basalt c.as
scoreboard players operation #e c.t = #polished_basalt c.ev
scoreboard players add #e c.t 1000
