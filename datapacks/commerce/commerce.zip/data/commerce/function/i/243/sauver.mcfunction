scoreboard players operation #quartz c.p = #p c.t
scoreboard players operation #quartz c.h = #h c.t
scoreboard players operation #quartz c.vs = #vs c.t
scoreboard players operation #quartz c.as = #as c.t
scoreboard players operation #quartz c.ev = #e c.t
scoreboard players remove #quartz c.ev 1000
