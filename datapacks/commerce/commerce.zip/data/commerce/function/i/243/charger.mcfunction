scoreboard players set #b c.t 150
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"quartz",n:"Quartz du Nether",i3:"243",cn:"Minerais et métaux",cb:1082}
scoreboard players operation #p c.t = #quartz c.p
scoreboard players operation #h c.t = #quartz c.h
scoreboard players operation #vs c.t = #quartz c.vs
scoreboard players operation #as c.t = #quartz c.as
scoreboard players operation #e c.t = #quartz c.ev
scoreboard players add #e c.t 1000
