scoreboard players operation #book c.p = #p c.t
scoreboard players operation #book c.h = #h c.t
scoreboard players operation #book c.vs = #vs c.t
scoreboard players operation #book c.as = #as c.t
scoreboard players operation #book c.ev = #e c.t
scoreboard players remove #book c.ev 1000
