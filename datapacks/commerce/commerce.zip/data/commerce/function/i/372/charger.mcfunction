scoreboard players set #b c.t 300
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 7
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"book",n:"Livre",i3:"372",cn:"Utilitaires",cb:1141}
scoreboard players operation #p c.t = #book c.p
scoreboard players operation #h c.t = #book c.h
scoreboard players operation #vs c.t = #book c.vs
scoreboard players operation #as c.t = #book c.as
scoreboard players operation #e c.t = #book c.ev
scoreboard players add #e c.t 1000
