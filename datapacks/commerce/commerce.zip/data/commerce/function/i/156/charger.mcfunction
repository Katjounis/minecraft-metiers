scoreboard players set #b c.t 22
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"magenta_concrete",n:"Béton magenta",i3:"156",cn:"Béton et terre cuite",cb:1060}
scoreboard players operation #p c.t = #magenta_concrete c.p
scoreboard players operation #h c.t = #magenta_concrete c.h
scoreboard players operation #vs c.t = #magenta_concrete c.vs
scoreboard players operation #as c.t = #magenta_concrete c.as
scoreboard players operation #e c.t = #magenta_concrete c.ev
scoreboard players add #e c.t 1000
