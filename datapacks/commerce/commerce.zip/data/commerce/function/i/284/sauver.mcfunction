scoreboard players operation #poisonous_potato c.p = #p c.t
scoreboard players operation #poisonous_potato c.h = #h c.t
scoreboard players operation #poisonous_potato c.vs = #vs c.t
scoreboard players operation #poisonous_potato c.as = #as c.t
scoreboard players operation #poisonous_potato c.ev = #e c.t
scoreboard players remove #poisonous_potato c.ev 1000
