scoreboard players set #b c.t 5
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 0
data modify storage commerce:t it set value {id:"poisonous_potato",n:"Pomme de terre empoisonnée",i3:"284",cn:"Agriculture",cb:1100}
scoreboard players operation #p c.t = #poisonous_potato c.p
scoreboard players operation #h c.t = #poisonous_potato c.h
scoreboard players operation #vs c.t = #poisonous_potato c.vs
scoreboard players operation #as c.t = #poisonous_potato c.as
scoreboard players operation #e c.t = #poisonous_potato c.ev
scoreboard players add #e c.t 1000
