scoreboard players operation #egg c.p = #p c.t
scoreboard players operation #egg c.h = #h c.t
scoreboard players operation #egg c.vs = #vs c.t
scoreboard players operation #egg c.as = #as c.t
scoreboard players operation #egg c.ev = #e c.t
scoreboard players remove #egg c.ev 1000
