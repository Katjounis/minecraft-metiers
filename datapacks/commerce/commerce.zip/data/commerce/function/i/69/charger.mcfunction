scoreboard players set #b c.t 200
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"stripped_birch_log",n:"Bûche écorcée de bouleau",i3:"069",cn:"Bûches",cb:1030}
scoreboard players operation #p c.t = #stripped_birch_log c.p
scoreboard players operation #h c.t = #stripped_birch_log c.h
scoreboard players operation #vs c.t = #stripped_birch_log c.vs
scoreboard players operation #as c.t = #stripped_birch_log c.as
scoreboard players operation #e c.t = #stripped_birch_log c.ev
scoreboard players add #e c.t 1000
