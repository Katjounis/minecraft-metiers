scoreboard players set #b c.t 30
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"egg",n:"Œuf",i3:"069",cn:"Élevage et chasse",cb:15}
scoreboard players operation #p c.t = #egg c.p
scoreboard players operation #h c.t = #egg c.h
scoreboard players operation #vs c.t = #egg c.vs
scoreboard players operation #as c.t = #egg c.as
scoreboard players operation #e c.t = #egg c.ev
scoreboard players add #e c.t 1000
