scoreboard players set #b c.t 3
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"coarse_dirt",n:"Terre stérile",i3:"046",cn:"Terre et glace",cb:1020}
scoreboard players operation #p c.t = #coarse_dirt c.p
scoreboard players operation #h c.t = #coarse_dirt c.h
scoreboard players operation #vs c.t = #coarse_dirt c.vs
scoreboard players operation #as c.t = #coarse_dirt c.as
scoreboard players operation #e c.t = #coarse_dirt c.ev
scoreboard players add #e c.t 1000
