scoreboard players set #b c.t 900
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"raw_gold",n:"Or brut",i3:"046",cn:"Minerais",cb:13}
scoreboard players operation #p c.t = #raw_gold c.p
scoreboard players operation #h c.t = #raw_gold c.h
scoreboard players operation #vs c.t = #raw_gold c.vs
scoreboard players operation #as c.t = #raw_gold c.as
scoreboard players operation #e c.t = #raw_gold c.ev
scoreboard players add #e c.t 1000
