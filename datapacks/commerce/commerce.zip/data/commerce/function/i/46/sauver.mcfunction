scoreboard players operation #coarse_dirt c.p = #p c.t
scoreboard players operation #coarse_dirt c.h = #h c.t
scoreboard players operation #coarse_dirt c.vs = #vs c.t
scoreboard players operation #coarse_dirt c.as = #as c.t
scoreboard players operation #coarse_dirt c.ev = #e c.t
scoreboard players remove #coarse_dirt c.ev 1000
