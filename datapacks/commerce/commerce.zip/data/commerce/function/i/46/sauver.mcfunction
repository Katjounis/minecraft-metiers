scoreboard players operation #raw_gold c.p = #p c.t
scoreboard players operation #raw_gold c.h = #h c.t
scoreboard players operation #raw_gold c.vs = #vs c.t
scoreboard players operation #raw_gold c.as = #as c.t
scoreboard players operation #raw_gold c.ev = #e c.t
scoreboard players remove #raw_gold c.ev 1000
