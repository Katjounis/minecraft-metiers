scoreboard players operation #potato c.p = #p c.t
scoreboard players operation #potato c.h = #h c.t
scoreboard players operation #potato c.vs = #vs c.t
scoreboard players operation #potato c.as = #as c.t
scoreboard players operation #potato c.ev = #e c.t
scoreboard players remove #potato c.ev 1000
