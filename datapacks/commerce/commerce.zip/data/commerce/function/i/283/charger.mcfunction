scoreboard players set #b c.t 40
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 0
data modify storage commerce:t it set value {id:"potato",n:"Pomme de terre",i3:"283",cn:"Agriculture",cb:1100}
scoreboard players operation #p c.t = #potato c.p
scoreboard players operation #h c.t = #potato c.h
scoreboard players operation #vs c.t = #potato c.vs
scoreboard players operation #as c.t = #potato c.as
scoreboard players operation #e c.t = #potato c.ev
scoreboard players add #e c.t 1000
