scoreboard players set #b c.t 30
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 0
scoreboard players set #cher c.t 0
data modify storage commerce:t it set value {id:"sweet_berries",n:"Baies sucrées",i3:"298",cn:"Agriculture",cb:1101}
scoreboard players operation #p c.t = #sweet_berries c.p
scoreboard players operation #h c.t = #sweet_berries c.h
scoreboard players operation #vs c.t = #sweet_berries c.vs
scoreboard players operation #as c.t = #sweet_berries c.as
scoreboard players operation #e c.t = #sweet_berries c.ev
scoreboard players add #e c.t 1000
