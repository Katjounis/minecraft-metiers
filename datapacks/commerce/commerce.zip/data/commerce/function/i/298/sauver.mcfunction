scoreboard players operation #sweet_berries c.p = #p c.t
scoreboard players operation #sweet_berries c.h = #h c.t
scoreboard players operation #sweet_berries c.vs = #vs c.t
scoreboard players operation #sweet_berries c.as = #as c.t
scoreboard players operation #sweet_berries c.ev = #e c.t
scoreboard players remove #sweet_berries c.ev 1000
