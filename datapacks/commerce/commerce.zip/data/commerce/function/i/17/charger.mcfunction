scoreboard players set #b c.t 6
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"polished_deepslate",n:"Ardoise polie",i3:"017",cn:"Pierres",cb:1011}
scoreboard players operation #p c.t = #polished_deepslate c.p
scoreboard players operation #h c.t = #polished_deepslate c.h
scoreboard players operation #vs c.t = #polished_deepslate c.vs
scoreboard players operation #as c.t = #polished_deepslate c.as
scoreboard players operation #e c.t = #polished_deepslate c.ev
scoreboard players add #e c.t 1000
