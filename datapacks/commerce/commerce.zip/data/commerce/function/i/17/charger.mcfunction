scoreboard players set #b c.t 10
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"red_sand",n:"Sable rouge",i3:"017",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #red_sand c.p
scoreboard players operation #h c.t = #red_sand c.h
scoreboard players operation #vs c.t = #red_sand c.vs
scoreboard players operation #as c.t = #red_sand c.as
scoreboard players operation #e c.t = #red_sand c.ev
scoreboard players add #e c.t 1000
