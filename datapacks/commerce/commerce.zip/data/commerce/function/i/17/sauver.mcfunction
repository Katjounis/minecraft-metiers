scoreboard players operation #red_sand c.p = #p c.t
scoreboard players operation #red_sand c.h = #h c.t
scoreboard players operation #red_sand c.vs = #vs c.t
scoreboard players operation #red_sand c.as = #as c.t
scoreboard players operation #red_sand c.ev = #e c.t
scoreboard players remove #red_sand c.ev 1000
