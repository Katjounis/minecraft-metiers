scoreboard players operation #polished_deepslate c.p = #p c.t
scoreboard players operation #polished_deepslate c.h = #h c.t
scoreboard players operation #polished_deepslate c.vs = #vs c.t
scoreboard players operation #polished_deepslate c.as = #as c.t
scoreboard players operation #polished_deepslate c.ev = #e c.t
scoreboard players remove #polished_deepslate c.ev 1000
