scoreboard players set #b c.t 300
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"soul_lantern",n:"Lanterne des âmes",i3:"364",cn:"Utilitaires",cb:1140}
scoreboard players operation #p c.t = #soul_lantern c.p
scoreboard players operation #h c.t = #soul_lantern c.h
scoreboard players operation #vs c.t = #soul_lantern c.vs
scoreboard players operation #as c.t = #soul_lantern c.as
scoreboard players operation #e c.t = #soul_lantern c.ev
scoreboard players add #e c.t 1000
