scoreboard players operation #soul_lantern c.p = #p c.t
scoreboard players operation #soul_lantern c.h = #h c.t
scoreboard players operation #soul_lantern c.vs = #vs c.t
scoreboard players operation #soul_lantern c.as = #as c.t
scoreboard players operation #soul_lantern c.ev = #e c.t
scoreboard players remove #soul_lantern c.ev 1000
