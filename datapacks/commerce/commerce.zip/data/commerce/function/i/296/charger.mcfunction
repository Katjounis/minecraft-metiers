scoreboard players set #b c.t 50
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 0
data modify storage commerce:t it set value {id:"cocoa_beans",n:"Fèves de cacao",i3:"296",cn:"Agriculture",cb:1101}
scoreboard players operation #p c.t = #cocoa_beans c.p
scoreboard players operation #h c.t = #cocoa_beans c.h
scoreboard players operation #vs c.t = #cocoa_beans c.vs
scoreboard players operation #as c.t = #cocoa_beans c.as
scoreboard players operation #e c.t = #cocoa_beans c.ev
scoreboard players add #e c.t 1000
