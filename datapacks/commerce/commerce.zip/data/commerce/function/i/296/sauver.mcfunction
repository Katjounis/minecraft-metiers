scoreboard players operation #cocoa_beans c.p = #p c.t
scoreboard players operation #cocoa_beans c.h = #h c.t
scoreboard players operation #cocoa_beans c.vs = #vs c.t
scoreboard players operation #cocoa_beans c.as = #as c.t
scoreboard players operation #cocoa_beans c.ev = #e c.t
scoreboard players remove #cocoa_beans c.ev 1000
