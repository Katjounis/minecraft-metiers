scoreboard players operation #netherrack c.p = #p c.t
scoreboard players operation #netherrack c.h = #h c.t
scoreboard players operation #netherrack c.vs = #vs c.t
scoreboard players operation #netherrack c.as = #as c.t
scoreboard players operation #netherrack c.ev = #e c.t
scoreboard players remove #netherrack c.ev 1000
