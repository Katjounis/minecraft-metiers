scoreboard players set #b c.t 2
scoreboard players set #V c.t 8192
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"netherrack",n:"Netherrack",i3:"012",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #netherrack c.p
scoreboard players operation #h c.t = #netherrack c.h
scoreboard players operation #vs c.t = #netherrack c.vs
scoreboard players operation #as c.t = #netherrack c.as
scoreboard players operation #e c.t = #netherrack c.ev
scoreboard players add #e c.t 1000
