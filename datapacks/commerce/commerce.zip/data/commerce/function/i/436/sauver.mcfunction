scoreboard players operation #netherite_scrap c.p = #p c.t
scoreboard players operation #netherite_scrap c.h = #h c.t
scoreboard players operation #netherite_scrap c.vs = #vs c.t
scoreboard players operation #netherite_scrap c.as = #as c.t
scoreboard players operation #netherite_scrap c.ev = #e c.t
scoreboard players remove #netherite_scrap c.ev 1000
