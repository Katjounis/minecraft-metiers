scoreboard players operation #smooth_stone c.p = #p c.t
scoreboard players operation #smooth_stone c.h = #h c.t
scoreboard players operation #smooth_stone c.vs = #vs c.t
scoreboard players operation #smooth_stone c.as = #as c.t
scoreboard players operation #smooth_stone c.ev = #e c.t
scoreboard players remove #smooth_stone c.ev 1000
