scoreboard players set #b c.t 30
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"smooth_stone",n:"Roche lisse",i3:"022",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #smooth_stone c.p
scoreboard players operation #h c.t = #smooth_stone c.h
scoreboard players operation #vs c.t = #smooth_stone c.vs
scoreboard players operation #as c.t = #smooth_stone c.as
scoreboard players operation #e c.t = #smooth_stone c.ev
scoreboard players add #e c.t 1000
