scoreboard players set #b c.t 5
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"rotten_flesh",n:"Chair putréfiée",i3:"319",cn:"Élevage et chasse",cb:111}
scoreboard players operation #p c.t = #rotten_flesh c.p
scoreboard players operation #h c.t = #rotten_flesh c.h
scoreboard players operation #vs c.t = #rotten_flesh c.vs
scoreboard players operation #as c.t = #rotten_flesh c.as
scoreboard players operation #e c.t = #rotten_flesh c.ev
scoreboard players add #e c.t 1000
