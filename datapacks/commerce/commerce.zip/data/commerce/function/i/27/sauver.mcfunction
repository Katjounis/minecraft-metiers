scoreboard players operation #sandstone c.p = #p c.t
scoreboard players operation #sandstone c.h = #h c.t
scoreboard players operation #sandstone c.vs = #vs c.t
scoreboard players operation #sandstone c.as = #as c.t
scoreboard players operation #sandstone c.ev = #e c.t
scoreboard players remove #sandstone c.ev 1000
