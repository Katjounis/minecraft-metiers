scoreboard players operation #redstone c.p = #p c.t
scoreboard players operation #redstone c.h = #h c.t
scoreboard players operation #redstone c.vs = #vs c.t
scoreboard players operation #redstone c.as = #as c.t
scoreboard players operation #redstone c.ev = #e c.t
scoreboard players remove #redstone c.ev 1000
