scoreboard players operation #lime_glazed_terracotta c.p = #p c.t
scoreboard players operation #lime_glazed_terracotta c.h = #h c.t
scoreboard players operation #lime_glazed_terracotta c.vs = #vs c.t
scoreboard players operation #lime_glazed_terracotta c.as = #as c.t
scoreboard players operation #lime_glazed_terracotta c.ev = #e c.t
scoreboard players remove #lime_glazed_terracotta c.ev 1000
