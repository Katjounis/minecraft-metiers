scoreboard players set #b c.t 100
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"red_nether_bricks",n:"Briques rouges du Nether",i3:"253",cn:"Nether et End",cb:109}
scoreboard players operation #p c.t = #red_nether_bricks c.p
scoreboard players operation #h c.t = #red_nether_bricks c.h
scoreboard players operation #vs c.t = #red_nether_bricks c.vs
scoreboard players operation #as c.t = #red_nether_bricks c.as
scoreboard players operation #e c.t = #red_nether_bricks c.ev
scoreboard players add #e c.t 1000
