scoreboard players operation #blue_orchid c.p = #p c.t
scoreboard players operation #blue_orchid c.h = #h c.t
scoreboard players operation #blue_orchid c.vs = #vs c.t
scoreboard players operation #blue_orchid c.as = #as c.t
scoreboard players operation #blue_orchid c.ev = #e c.t
scoreboard players remove #blue_orchid c.ev 1000
