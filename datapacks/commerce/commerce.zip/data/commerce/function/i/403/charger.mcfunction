scoreboard players set #b c.t 30
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"blue_orchid",n:"Orchidée bleue",i3:"403",cn:"Fleurs et plantes",cb:116}
scoreboard players operation #p c.t = #blue_orchid c.p
scoreboard players operation #h c.t = #blue_orchid c.h
scoreboard players operation #vs c.t = #blue_orchid c.vs
scoreboard players operation #as c.t = #blue_orchid c.as
scoreboard players operation #e c.t = #blue_orchid c.ev
scoreboard players add #e c.t 1000
