scoreboard players operation #rotten_flesh c.p = #p c.t
scoreboard players operation #rotten_flesh c.h = #h c.t
scoreboard players operation #rotten_flesh c.vs = #vs c.t
scoreboard players operation #rotten_flesh c.as = #as c.t
scoreboard players operation #rotten_flesh c.ev = #e c.t
scoreboard players remove #rotten_flesh c.ev 1000
