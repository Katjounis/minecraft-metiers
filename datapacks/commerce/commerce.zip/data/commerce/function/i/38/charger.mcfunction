scoreboard players set #b c.t 80
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"bamboo_block",n:"Bloc de bambou",i3:"038",cn:"Bois",cb:12}
scoreboard players operation #p c.t = #bamboo_block c.p
scoreboard players operation #h c.t = #bamboo_block c.h
scoreboard players operation #vs c.t = #bamboo_block c.vs
scoreboard players operation #as c.t = #bamboo_block c.as
scoreboard players operation #e c.t = #bamboo_block c.ev
scoreboard players add #e c.t 1000
