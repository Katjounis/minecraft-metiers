scoreboard players set #b c.t 300
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"slime_ball",n:"Boule de slime",i3:"082",cn:"Élevage et chasse",cb:15}
scoreboard players operation #p c.t = #slime_ball c.p
scoreboard players operation #h c.t = #slime_ball c.h
scoreboard players operation #vs c.t = #slime_ball c.vs
scoreboard players operation #as c.t = #slime_ball c.as
scoreboard players operation #e c.t = #slime_ball c.ev
scoreboard players add #e c.t 1000
