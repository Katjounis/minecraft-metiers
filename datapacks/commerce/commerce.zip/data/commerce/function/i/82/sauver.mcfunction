scoreboard players operation #slime_ball c.p = #p c.t
scoreboard players operation #slime_ball c.h = #h c.t
scoreboard players operation #slime_ball c.vs = #vs c.t
scoreboard players operation #slime_ball c.as = #as c.t
scoreboard players operation #slime_ball c.ev = #e c.t
scoreboard players remove #slime_ball c.ev 1000
