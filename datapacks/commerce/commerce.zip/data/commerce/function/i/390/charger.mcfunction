scoreboard players set #b c.t 2400
scoreboard players set #V c.t 64
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"bucket",n:"Seau",i3:"390",cn:"Utilitaires",cb:1142}
scoreboard players operation #p c.t = #bucket c.p
scoreboard players operation #h c.t = #bucket c.h
scoreboard players operation #vs c.t = #bucket c.vs
scoreboard players operation #as c.t = #bucket c.as
scoreboard players operation #e c.t = #bucket c.ev
scoreboard players add #e c.t 1000
