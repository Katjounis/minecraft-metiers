scoreboard players operation #bucket c.p = #p c.t
scoreboard players operation #bucket c.h = #h c.t
scoreboard players operation #bucket c.vs = #vs c.t
scoreboard players operation #bucket c.as = #as c.t
scoreboard players operation #bucket c.ev = #e c.t
scoreboard players remove #bucket c.ev 1000
