scoreboard players operation #pale_oak_planks c.p = #p c.t
scoreboard players operation #pale_oak_planks c.h = #h c.t
scoreboard players operation #pale_oak_planks c.vs = #vs c.t
scoreboard players operation #pale_oak_planks c.as = #as c.t
scoreboard players operation #pale_oak_planks c.ev = #e c.t
scoreboard players remove #pale_oak_planks c.ev 1000
