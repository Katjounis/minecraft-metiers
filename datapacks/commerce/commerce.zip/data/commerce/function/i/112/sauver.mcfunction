scoreboard players operation #piston c.p = #p c.t
scoreboard players operation #piston c.h = #h c.t
scoreboard players operation #piston c.vs = #vs c.t
scoreboard players operation #piston c.as = #as c.t
scoreboard players operation #piston c.ev = #e c.t
scoreboard players remove #piston c.ev 1000
