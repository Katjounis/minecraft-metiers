scoreboard players set #b c.t 62
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"pale_oak_planks",n:"Planches de chêne pâle",i3:"112",cn:"Planches et feuillage",cb:104}
scoreboard players operation #p c.t = #pale_oak_planks c.p
scoreboard players operation #h c.t = #pale_oak_planks c.h
scoreboard players operation #vs c.t = #pale_oak_planks c.vs
scoreboard players operation #as c.t = #pale_oak_planks c.as
scoreboard players operation #e c.t = #pale_oak_planks c.ev
scoreboard players add #e c.t 1000
