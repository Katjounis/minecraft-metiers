scoreboard players set #b c.t 500
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"piston",n:"Piston",i3:"112",cn:"Utilitaires",cb:18}
scoreboard players operation #p c.t = #piston c.p
scoreboard players operation #h c.t = #piston c.h
scoreboard players operation #vs c.t = #piston c.vs
scoreboard players operation #as c.t = #piston c.as
scoreboard players operation #e c.t = #piston c.ev
scoreboard players add #e c.t 1000
