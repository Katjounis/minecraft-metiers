scoreboard players set #b c.t 40
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"sugar_cane",n:"Canne à sucre",i3:"061",cn:"Agriculture",cb:14}
scoreboard players operation #p c.t = #sugar_cane c.p
scoreboard players operation #h c.t = #sugar_cane c.h
scoreboard players operation #vs c.t = #sugar_cane c.vs
scoreboard players operation #as c.t = #sugar_cane c.as
scoreboard players operation #e c.t = #sugar_cane c.ev
scoreboard players add #e c.t 1000
