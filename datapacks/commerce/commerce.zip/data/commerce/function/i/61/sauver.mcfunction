scoreboard players operation #sugar_cane c.p = #p c.t
scoreboard players operation #sugar_cane c.h = #h c.t
scoreboard players operation #sugar_cane c.vs = #vs c.t
scoreboard players operation #sugar_cane c.as = #as c.t
scoreboard players operation #sugar_cane c.ev = #e c.t
scoreboard players remove #sugar_cane c.ev 1000
