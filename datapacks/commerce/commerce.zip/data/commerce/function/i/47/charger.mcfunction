scoreboard players set #b c.t 1200
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"gold_ingot",n:"Lingot d'or",i3:"047",cn:"Minerais",cb:13}
scoreboard players operation #p c.t = #gold_ingot c.p
scoreboard players operation #h c.t = #gold_ingot c.h
scoreboard players operation #vs c.t = #gold_ingot c.vs
scoreboard players operation #as c.t = #gold_ingot c.as
scoreboard players operation #e c.t = #gold_ingot c.ev
scoreboard players add #e c.t 1000
