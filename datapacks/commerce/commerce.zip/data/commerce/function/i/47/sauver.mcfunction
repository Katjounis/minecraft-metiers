scoreboard players operation #gold_ingot c.p = #p c.t
scoreboard players operation #gold_ingot c.h = #h c.t
scoreboard players operation #gold_ingot c.vs = #vs c.t
scoreboard players operation #gold_ingot c.as = #as c.t
scoreboard players operation #gold_ingot c.ev = #e c.t
scoreboard players remove #gold_ingot c.ev 1000
