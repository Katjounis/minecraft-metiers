scoreboard players set #b c.t 200
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"spruce_log",n:"Bûche de sapin",i3:"028",cn:"Bois",cb:12}
scoreboard players operation #p c.t = #spruce_log c.p
scoreboard players operation #h c.t = #spruce_log c.h
scoreboard players operation #vs c.t = #spruce_log c.vs
scoreboard players operation #as c.t = #spruce_log c.as
scoreboard players operation #e c.t = #spruce_log c.ev
scoreboard players add #e c.t 1000
