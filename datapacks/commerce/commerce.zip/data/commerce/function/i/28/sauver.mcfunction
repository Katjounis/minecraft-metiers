scoreboard players operation #spruce_log c.p = #p c.t
scoreboard players operation #spruce_log c.h = #h c.t
scoreboard players operation #spruce_log c.vs = #vs c.t
scoreboard players operation #spruce_log c.as = #as c.t
scoreboard players operation #spruce_log c.ev = #e c.t
scoreboard players remove #spruce_log c.ev 1000
