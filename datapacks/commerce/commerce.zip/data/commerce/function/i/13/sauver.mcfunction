scoreboard players operation #andesite c.p = #p c.t
scoreboard players operation #andesite c.h = #h c.t
scoreboard players operation #andesite c.vs = #vs c.t
scoreboard players operation #andesite c.as = #as c.t
scoreboard players operation #andesite c.ev = #e c.t
scoreboard players remove #andesite c.ev 1000
