scoreboard players operation #end_stone c.p = #p c.t
scoreboard players operation #end_stone c.h = #h c.t
scoreboard players operation #end_stone c.vs = #vs c.t
scoreboard players operation #end_stone c.as = #as c.t
scoreboard players operation #end_stone c.ev = #e c.t
scoreboard players remove #end_stone c.ev 1000
