scoreboard players set #b c.t 30
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"end_stone",n:"Pierre de l'End",i3:"013",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #end_stone c.p
scoreboard players operation #h c.t = #end_stone c.h
scoreboard players operation #vs c.t = #end_stone c.vs
scoreboard players operation #as c.t = #end_stone c.as
scoreboard players operation #e c.t = #end_stone c.ev
scoreboard players add #e c.t 1000
