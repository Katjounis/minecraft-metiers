scoreboard players set #b c.t 150
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"beef",n:"Bœuf cru",i3:"071",cn:"Élevage et chasse",cb:15}
scoreboard players operation #p c.t = #beef c.p
scoreboard players operation #h c.t = #beef c.h
scoreboard players operation #vs c.t = #beef c.vs
scoreboard players operation #as c.t = #beef c.as
scoreboard players operation #e c.t = #beef c.ev
scoreboard players add #e c.t 1000
