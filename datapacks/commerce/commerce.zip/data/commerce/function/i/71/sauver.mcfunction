scoreboard players operation #beef c.p = #p c.t
scoreboard players operation #beef c.h = #h c.t
scoreboard players operation #beef c.vs = #vs c.t
scoreboard players operation #beef c.as = #as c.t
scoreboard players operation #beef c.ev = #e c.t
scoreboard players remove #beef c.ev 1000
