scoreboard players set #b c.t 5
scoreboard players set #V c.t 4096
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cobblestone",n:"Pierre taillée",i3:"001",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #cobblestone c.p
scoreboard players operation #h c.t = #cobblestone c.h
scoreboard players operation #vs c.t = #cobblestone c.vs
scoreboard players operation #as c.t = #cobblestone c.as
scoreboard players operation #e c.t = #cobblestone c.ev
scoreboard players add #e c.t 1000
