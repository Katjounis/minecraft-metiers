scoreboard players operation #cobblestone c.p = #p c.t
scoreboard players operation #cobblestone c.h = #h c.t
scoreboard players operation #cobblestone c.vs = #vs c.t
scoreboard players operation #cobblestone c.as = #as c.t
scoreboard players operation #cobblestone c.ev = #e c.t
scoreboard players remove #cobblestone c.ev 1000
