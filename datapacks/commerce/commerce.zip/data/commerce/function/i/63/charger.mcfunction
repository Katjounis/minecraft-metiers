scoreboard players set #b c.t 50
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"nether_wart",n:"Verrues du Nether",i3:"063",cn:"Agriculture",cb:14}
scoreboard players operation #p c.t = #nether_wart c.p
scoreboard players operation #h c.t = #nether_wart c.h
scoreboard players operation #vs c.t = #nether_wart c.vs
scoreboard players operation #as c.t = #nether_wart c.as
scoreboard players operation #e c.t = #nether_wart c.ev
scoreboard players add #e c.t 1000
