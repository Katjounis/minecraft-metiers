scoreboard players operation #soul_soil c.p = #p c.t
scoreboard players operation #soul_soil c.h = #h c.t
scoreboard players operation #soul_soil c.vs = #vs c.t
scoreboard players operation #soul_soil c.as = #as c.t
scoreboard players operation #soul_soil c.ev = #e c.t
scoreboard players remove #soul_soil c.ev 1000
