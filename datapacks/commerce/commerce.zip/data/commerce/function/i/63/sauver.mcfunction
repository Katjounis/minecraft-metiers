scoreboard players operation #nether_wart c.p = #p c.t
scoreboard players operation #nether_wart c.h = #h c.t
scoreboard players operation #nether_wart c.vs = #vs c.t
scoreboard players operation #nether_wart c.as = #as c.t
scoreboard players operation #nether_wart c.ev = #e c.t
scoreboard players remove #nether_wart c.ev 1000
