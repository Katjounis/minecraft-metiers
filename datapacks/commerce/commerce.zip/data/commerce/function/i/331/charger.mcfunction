scoreboard players set #b c.t 1000
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 0
scoreboard players set #cher c.t 0
data modify storage commerce:t it set value {id:"ender_eye",n:"Oeil de l'Ender",i3:"331",cn:"Élevage et chasse",cb:1112}
scoreboard players operation #p c.t = #ender_eye c.p
scoreboard players operation #h c.t = #ender_eye c.h
scoreboard players operation #vs c.t = #ender_eye c.vs
scoreboard players operation #as c.t = #ender_eye c.as
scoreboard players operation #e c.t = #ender_eye c.ev
scoreboard players add #e c.t 1000
