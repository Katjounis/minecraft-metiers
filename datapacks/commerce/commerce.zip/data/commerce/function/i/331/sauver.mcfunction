scoreboard players operation #ender_eye c.p = #p c.t
scoreboard players operation #ender_eye c.h = #h c.t
scoreboard players operation #ender_eye c.vs = #vs c.t
scoreboard players operation #ender_eye c.as = #as c.t
scoreboard players operation #ender_eye c.ev = #e c.t
scoreboard players remove #ender_eye c.ev 1000
