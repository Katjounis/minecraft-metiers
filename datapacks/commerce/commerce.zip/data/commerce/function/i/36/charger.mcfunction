scoreboard players set #b c.t 250
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"crimson_stem",n:"Tige carmin",i3:"036",cn:"Bois",cb:12}
scoreboard players operation #p c.t = #crimson_stem c.p
scoreboard players operation #h c.t = #crimson_stem c.h
scoreboard players operation #vs c.t = #crimson_stem c.vs
scoreboard players operation #as c.t = #crimson_stem c.as
scoreboard players operation #e c.t = #crimson_stem c.ev
scoreboard players add #e c.t 1000
