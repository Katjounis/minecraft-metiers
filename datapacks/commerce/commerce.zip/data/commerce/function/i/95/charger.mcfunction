scoreboard players set #b c.t 10
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"birch_leaves",n:"Feuilles de bouleau",i3:"095",cn:"Planches et feuillage",cb:1040}
scoreboard players operation #p c.t = #birch_leaves c.p
scoreboard players operation #h c.t = #birch_leaves c.h
scoreboard players operation #vs c.t = #birch_leaves c.vs
scoreboard players operation #as c.t = #birch_leaves c.as
scoreboard players operation #e c.t = #birch_leaves c.ev
scoreboard players add #e c.t 1000
