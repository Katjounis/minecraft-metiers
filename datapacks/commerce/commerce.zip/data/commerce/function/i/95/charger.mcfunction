scoreboard players set #b c.t 10
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"kelp",n:"Algue",i3:"095",cn:"Pêche",cb:16}
scoreboard players operation #p c.t = #kelp c.p
scoreboard players operation #h c.t = #kelp c.h
scoreboard players operation #vs c.t = #kelp c.vs
scoreboard players operation #as c.t = #kelp c.as
scoreboard players operation #e c.t = #kelp c.ev
scoreboard players add #e c.t 1000
