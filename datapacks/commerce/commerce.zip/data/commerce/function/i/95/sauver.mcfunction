scoreboard players operation #kelp c.p = #p c.t
scoreboard players operation #kelp c.h = #h c.t
scoreboard players operation #kelp c.vs = #vs c.t
scoreboard players operation #kelp c.as = #as c.t
scoreboard players operation #kelp c.ev = #e c.t
scoreboard players remove #kelp c.ev 1000
