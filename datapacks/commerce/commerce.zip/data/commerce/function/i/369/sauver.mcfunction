scoreboard players operation #barrel c.p = #p c.t
scoreboard players operation #barrel c.h = #h c.t
scoreboard players operation #barrel c.vs = #vs c.t
scoreboard players operation #barrel c.as = #as c.t
scoreboard players operation #barrel c.ev = #e c.t
scoreboard players remove #barrel c.ev 1000
