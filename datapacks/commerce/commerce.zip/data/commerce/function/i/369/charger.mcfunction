scoreboard players set #b c.t 360
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
scoreboard players set #cher c.t 1
data modify storage commerce:t it set value {id:"barrel",n:"Tonneau",i3:"369",cn:"Utilitaires",cb:1140}
scoreboard players operation #p c.t = #barrel c.p
scoreboard players operation #h c.t = #barrel c.h
scoreboard players operation #vs c.t = #barrel c.vs
scoreboard players operation #as c.t = #barrel c.as
scoreboard players operation #e c.t = #barrel c.ev
scoreboard players add #e c.t 1000
