scoreboard players set #b c.t 200
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"leather",n:"Cuir",i3:"068",cn:"Élevage et chasse",cb:15}
scoreboard players operation #p c.t = #leather c.p
scoreboard players operation #h c.t = #leather c.h
scoreboard players operation #vs c.t = #leather c.vs
scoreboard players operation #as c.t = #leather c.as
scoreboard players operation #e c.t = #leather c.ev
scoreboard players add #e c.t 1000
