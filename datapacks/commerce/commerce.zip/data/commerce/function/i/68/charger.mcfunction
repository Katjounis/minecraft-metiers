scoreboard players set #b c.t 200
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"birch_log",n:"Bûche de bouleau",i3:"068",cn:"Bûches",cb:1030}
scoreboard players operation #p c.t = #birch_log c.p
scoreboard players operation #h c.t = #birch_log c.h
scoreboard players operation #vs c.t = #birch_log c.vs
scoreboard players operation #as c.t = #birch_log c.as
scoreboard players operation #e c.t = #birch_log c.ev
scoreboard players add #e c.t 1000
