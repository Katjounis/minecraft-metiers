scoreboard players operation #birch_log c.p = #p c.t
scoreboard players operation #birch_log c.h = #h c.t
scoreboard players operation #birch_log c.vs = #vs c.t
scoreboard players operation #birch_log c.as = #as c.t
scoreboard players operation #birch_log c.ev = #e c.t
scoreboard players remove #birch_log c.ev 1000
