scoreboard players operation #leather c.p = #p c.t
scoreboard players operation #leather c.h = #h c.t
scoreboard players operation #leather c.vs = #vs c.t
scoreboard players operation #leather c.as = #as c.t
scoreboard players operation #leather c.ev = #e c.t
scoreboard players remove #leather c.ev 1000
