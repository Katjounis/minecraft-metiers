scoreboard players set #b c.t 80000
scoreboard players set #V c.t 4
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 1
scoreboard players set #blk c.t 0
scoreboard players set #cher c.t 0
data modify storage commerce:t it set value {id:"heart_of_the_sea",n:"Coeur de la mer",i3:"438",cn:"Trésors",cb:1150}
scoreboard players operation #p c.t = #heart_of_the_sea c.p
scoreboard players operation #h c.t = #heart_of_the_sea c.h
scoreboard players operation #vs c.t = #heart_of_the_sea c.vs
scoreboard players operation #as c.t = #heart_of_the_sea c.as
scoreboard players operation #e c.t = #heart_of_the_sea c.ev
scoreboard players add #e c.t 1000
