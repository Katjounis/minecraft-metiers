scoreboard players set #b c.t 5000
scoreboard players set #V c.t 32
scoreboard players set #mj c.t 8
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"echo_shard",n:"Éclat d'écho",i3:"438",cn:"Trésors",cb:115}
scoreboard players operation #p c.t = #echo_shard c.p
scoreboard players operation #h c.t = #echo_shard c.h
scoreboard players operation #vs c.t = #echo_shard c.vs
scoreboard players operation #as c.t = #echo_shard c.as
scoreboard players operation #e c.t = #echo_shard c.ev
scoreboard players add #e c.t 1000
