scoreboard players operation #heart_of_the_sea c.p = #p c.t
scoreboard players operation #heart_of_the_sea c.h = #h c.t
scoreboard players operation #heart_of_the_sea c.vs = #vs c.t
scoreboard players operation #heart_of_the_sea c.as = #as c.t
scoreboard players operation #heart_of_the_sea c.ev = #e c.t
scoreboard players remove #heart_of_the_sea c.ev 1000
