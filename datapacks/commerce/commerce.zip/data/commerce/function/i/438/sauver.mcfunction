scoreboard players operation #echo_shard c.p = #p c.t
scoreboard players operation #echo_shard c.h = #h c.t
scoreboard players operation #echo_shard c.vs = #vs c.t
scoreboard players operation #echo_shard c.as = #as c.t
scoreboard players operation #echo_shard c.ev = #e c.t
scoreboard players remove #echo_shard c.ev 1000
