scoreboard players operation #cooked_beef c.p = #p c.t
scoreboard players operation #cooked_beef c.h = #h c.t
scoreboard players operation #cooked_beef c.vs = #vs c.t
scoreboard players operation #cooked_beef c.as = #as c.t
scoreboard players operation #cooked_beef c.ev = #e c.t
scoreboard players remove #cooked_beef c.ev 1000
