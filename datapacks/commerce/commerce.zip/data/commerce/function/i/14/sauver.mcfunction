scoreboard players operation #obsidian c.p = #p c.t
scoreboard players operation #obsidian c.h = #h c.t
scoreboard players operation #obsidian c.vs = #vs c.t
scoreboard players operation #obsidian c.as = #as c.t
scoreboard players operation #obsidian c.ev = #e c.t
scoreboard players remove #obsidian c.ev 1000
