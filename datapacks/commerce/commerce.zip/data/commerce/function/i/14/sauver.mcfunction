scoreboard players operation #polished_andesite c.p = #p c.t
scoreboard players operation #polished_andesite c.h = #h c.t
scoreboard players operation #polished_andesite c.vs = #vs c.t
scoreboard players operation #polished_andesite c.as = #as c.t
scoreboard players operation #polished_andesite c.ev = #e c.t
scoreboard players remove #polished_andesite c.ev 1000
