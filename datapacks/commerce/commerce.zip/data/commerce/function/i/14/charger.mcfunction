scoreboard players set #b c.t 6
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"polished_andesite",n:"Andésite polie",i3:"014",cn:"Pierres",cb:101}
scoreboard players operation #p c.t = #polished_andesite c.p
scoreboard players operation #h c.t = #polished_andesite c.h
scoreboard players operation #vs c.t = #polished_andesite c.vs
scoreboard players operation #as c.t = #polished_andesite c.as
scoreboard players operation #e c.t = #polished_andesite c.ev
scoreboard players add #e c.t 1000
