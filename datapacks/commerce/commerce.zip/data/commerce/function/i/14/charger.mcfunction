scoreboard players set #b c.t 300
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"obsidian",n:"Obsidienne",i3:"014",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #obsidian c.p
scoreboard players operation #h c.t = #obsidian c.h
scoreboard players operation #vs c.t = #obsidian c.vs
scoreboard players operation #as c.t = #obsidian c.as
scoreboard players operation #e c.t = #obsidian c.ev
scoreboard players add #e c.t 1000
