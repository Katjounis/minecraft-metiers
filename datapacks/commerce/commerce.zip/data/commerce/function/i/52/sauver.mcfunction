scoreboard players operation #glowstone_dust c.p = #p c.t
scoreboard players operation #glowstone_dust c.h = #h c.t
scoreboard players operation #glowstone_dust c.vs = #vs c.t
scoreboard players operation #glowstone_dust c.as = #as c.t
scoreboard players operation #glowstone_dust c.ev = #e c.t
scoreboard players remove #glowstone_dust c.ev 1000
