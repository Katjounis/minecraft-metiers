scoreboard players set #b c.t 100
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"glowstone_dust",n:"Poudre lumineuse",i3:"052",cn:"Minerais",cb:13}
scoreboard players operation #p c.t = #glowstone_dust c.p
scoreboard players operation #h c.t = #glowstone_dust c.h
scoreboard players operation #vs c.t = #glowstone_dust c.vs
scoreboard players operation #as c.t = #glowstone_dust c.as
scoreboard players operation #e c.t = #glowstone_dust c.ev
scoreboard players add #e c.t 1000
