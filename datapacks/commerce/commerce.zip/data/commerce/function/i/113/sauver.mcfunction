scoreboard players operation #pale_oak_leaves c.p = #p c.t
scoreboard players operation #pale_oak_leaves c.h = #h c.t
scoreboard players operation #pale_oak_leaves c.vs = #vs c.t
scoreboard players operation #pale_oak_leaves c.as = #as c.t
scoreboard players operation #pale_oak_leaves c.ev = #e c.t
scoreboard players remove #pale_oak_leaves c.ev 1000
