scoreboard players set #b c.t 36
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"green_dye",n:"Teinture verte",i3:"151",cn:"Laines et teintures",cb:1052}
scoreboard players operation #p c.t = #green_dye c.p
scoreboard players operation #h c.t = #green_dye c.h
scoreboard players operation #vs c.t = #green_dye c.vs
scoreboard players operation #as c.t = #green_dye c.as
scoreboard players operation #e c.t = #green_dye c.ev
scoreboard players add #e c.t 1000
