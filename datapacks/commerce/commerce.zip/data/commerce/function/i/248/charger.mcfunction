scoreboard players set #b c.t 900
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"iron_chain",n:"Chaîne de fer",i3:"248",cn:"Minerais et métaux",cb:1082}
scoreboard players operation #p c.t = #iron_chain c.p
scoreboard players operation #h c.t = #iron_chain c.h
scoreboard players operation #vs c.t = #iron_chain c.vs
scoreboard players operation #as c.t = #iron_chain c.as
scoreboard players operation #e c.t = #iron_chain c.ev
scoreboard players add #e c.t 1000
