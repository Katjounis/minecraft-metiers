scoreboard players operation #iron_chain c.p = #p c.t
scoreboard players operation #iron_chain c.h = #h c.t
scoreboard players operation #iron_chain c.vs = #vs c.t
scoreboard players operation #iron_chain c.as = #as c.t
scoreboard players operation #iron_chain c.ev = #e c.t
scoreboard players remove #iron_chain c.ev 1000
