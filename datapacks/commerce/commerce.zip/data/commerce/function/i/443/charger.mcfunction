scoreboard players set #b c.t 2000
scoreboard players set #V c.t 64
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"ghast_tear",n:"Larme de ghast",i3:"443",cn:"Trésors",cb:115}
scoreboard players operation #p c.t = #ghast_tear c.p
scoreboard players operation #h c.t = #ghast_tear c.h
scoreboard players operation #vs c.t = #ghast_tear c.vs
scoreboard players operation #as c.t = #ghast_tear c.as
scoreboard players operation #e c.t = #ghast_tear c.ev
scoreboard players add #e c.t 1000
