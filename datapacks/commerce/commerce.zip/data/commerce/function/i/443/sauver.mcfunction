scoreboard players operation #ghast_tear c.p = #p c.t
scoreboard players operation #ghast_tear c.h = #h c.t
scoreboard players operation #ghast_tear c.vs = #vs c.t
scoreboard players operation #ghast_tear c.as = #as c.t
scoreboard players operation #ghast_tear c.ev = #e c.t
scoreboard players remove #ghast_tear c.ev 1000
