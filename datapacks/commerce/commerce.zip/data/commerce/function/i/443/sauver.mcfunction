scoreboard players operation #totem_of_undying c.p = #p c.t
scoreboard players operation #totem_of_undying c.h = #h c.t
scoreboard players operation #totem_of_undying c.vs = #vs c.t
scoreboard players operation #totem_of_undying c.as = #as c.t
scoreboard players operation #totem_of_undying c.ev = #e c.t
scoreboard players remove #totem_of_undying c.ev 1000
