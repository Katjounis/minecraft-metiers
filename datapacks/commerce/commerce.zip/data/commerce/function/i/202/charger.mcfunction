scoreboard players set #b c.t 22
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"green_stained_glass",n:"Verre teinté vert",i3:"202",cn:"Verre",cb:1071}
scoreboard players operation #p c.t = #green_stained_glass c.p
scoreboard players operation #h c.t = #green_stained_glass c.h
scoreboard players operation #vs c.t = #green_stained_glass c.vs
scoreboard players operation #as c.t = #green_stained_glass c.as
scoreboard players operation #e c.t = #green_stained_glass c.ev
scoreboard players add #e c.t 1000
