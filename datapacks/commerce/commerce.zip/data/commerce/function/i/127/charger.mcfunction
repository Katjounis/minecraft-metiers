scoreboard players set #b c.t 10000
scoreboard players set #V c.t 16
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"shulker_shell",n:"Carapace de shulker",i3:"127",cn:"Trésors",cb:19}
scoreboard players operation #p c.t = #shulker_shell c.p
scoreboard players operation #h c.t = #shulker_shell c.h
scoreboard players operation #vs c.t = #shulker_shell c.vs
scoreboard players operation #as c.t = #shulker_shell c.as
scoreboard players operation #e c.t = #shulker_shell c.ev
scoreboard players add #e c.t 1000
