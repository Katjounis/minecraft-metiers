scoreboard players set #b c.t 3000
scoreboard players set #V c.t 32
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"wet_sponge",n:"Éponge mouillée",i3:"442",cn:"Trésors",cb:115}
scoreboard players operation #p c.t = #wet_sponge c.p
scoreboard players operation #h c.t = #wet_sponge c.h
scoreboard players operation #vs c.t = #wet_sponge c.vs
scoreboard players operation #as c.t = #wet_sponge c.as
scoreboard players operation #e c.t = #wet_sponge c.ev
scoreboard players add #e c.t 1000
