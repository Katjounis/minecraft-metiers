scoreboard players operation #wet_sponge c.p = #p c.t
scoreboard players operation #wet_sponge c.h = #h c.t
scoreboard players operation #wet_sponge c.vs = #vs c.t
scoreboard players operation #wet_sponge c.as = #as c.t
scoreboard players operation #wet_sponge c.ev = #e c.t
scoreboard players remove #wet_sponge c.ev 1000
