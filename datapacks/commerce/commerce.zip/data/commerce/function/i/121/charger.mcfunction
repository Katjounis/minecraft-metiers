scoreboard players set #b c.t 62000
scoreboard players set #V c.t 8
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"netherite_scrap",n:"Fragment de netherite",i3:"121",cn:"Trésors",cb:19}
scoreboard players operation #p c.t = #netherite_scrap c.p
scoreboard players operation #h c.t = #netherite_scrap c.h
scoreboard players operation #vs c.t = #netherite_scrap c.vs
scoreboard players operation #as c.t = #netherite_scrap c.as
scoreboard players operation #e c.t = #netherite_scrap c.ev
scoreboard players add #e c.t 1000
