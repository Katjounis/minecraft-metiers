scoreboard players operation #golden_carrot c.p = #p c.t
scoreboard players operation #golden_carrot c.h = #h c.t
scoreboard players operation #golden_carrot c.vs = #vs c.t
scoreboard players operation #golden_carrot c.as = #as c.t
scoreboard players operation #golden_carrot c.ev = #e c.t
scoreboard players remove #golden_carrot c.ev 1000
