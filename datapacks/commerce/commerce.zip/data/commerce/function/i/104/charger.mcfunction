scoreboard players set #b c.t 1200
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"golden_carrot",n:"Carotte dorée",i3:"104",cn:"Cuisine",cb:17}
scoreboard players operation #p c.t = #golden_carrot c.p
scoreboard players operation #h c.t = #golden_carrot c.h
scoreboard players operation #vs c.t = #golden_carrot c.vs
scoreboard players operation #as c.t = #golden_carrot c.as
scoreboard players operation #e c.t = #golden_carrot c.ev
scoreboard players add #e c.t 1000
