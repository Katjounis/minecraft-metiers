scoreboard players operation #copper_ingot c.p = #p c.t
scoreboard players operation #copper_ingot c.h = #h c.t
scoreboard players operation #copper_ingot c.vs = #vs c.t
scoreboard players operation #copper_ingot c.as = #as c.t
scoreboard players operation #copper_ingot c.ev = #e c.t
scoreboard players remove #copper_ingot c.ev 1000
