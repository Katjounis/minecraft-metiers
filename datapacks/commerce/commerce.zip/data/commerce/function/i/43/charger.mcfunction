scoreboard players set #b c.t 200
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"copper_ingot",n:"Lingot de cuivre",i3:"043",cn:"Minerais",cb:13}
scoreboard players operation #p c.t = #copper_ingot c.p
scoreboard players operation #h c.t = #copper_ingot c.h
scoreboard players operation #vs c.t = #copper_ingot c.vs
scoreboard players operation #as c.t = #copper_ingot c.as
scoreboard players operation #e c.t = #copper_ingot c.ev
scoreboard players add #e c.t 1000
