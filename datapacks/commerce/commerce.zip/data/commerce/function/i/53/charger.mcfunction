scoreboard players set #b c.t 30
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"flint",n:"Silex",i3:"053",cn:"Minerais",cb:13}
scoreboard players operation #p c.t = #flint c.p
scoreboard players operation #h c.t = #flint c.h
scoreboard players operation #vs c.t = #flint c.vs
scoreboard players operation #as c.t = #flint c.as
scoreboard players operation #e c.t = #flint c.ev
scoreboard players add #e c.t 1000
