scoreboard players operation #flint c.p = #p c.t
scoreboard players operation #flint c.h = #h c.t
scoreboard players operation #flint c.vs = #vs c.t
scoreboard players operation #flint c.as = #as c.t
scoreboard players operation #flint c.ev = #e c.t
scoreboard players remove #flint c.ev 1000
