scoreboard players operation #green_terracotta c.p = #p c.t
scoreboard players operation #green_terracotta c.h = #h c.t
scoreboard players operation #green_terracotta c.vs = #vs c.t
scoreboard players operation #green_terracotta c.as = #as c.t
scoreboard players operation #green_terracotta c.ev = #e c.t
scoreboard players remove #green_terracotta c.ev 1000
