scoreboard players set #b c.t 124
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"green_terracotta",n:"Terre cuite verte",i3:"184",cn:"Béton et terre cuite",cb:1063}
scoreboard players operation #p c.t = #green_terracotta c.p
scoreboard players operation #h c.t = #green_terracotta c.h
scoreboard players operation #vs c.t = #green_terracotta c.vs
scoreboard players operation #as c.t = #green_terracotta c.as
scoreboard players operation #e c.t = #green_terracotta c.ev
scoreboard players add #e c.t 1000
