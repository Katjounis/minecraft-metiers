scoreboard players operation #bricks c.p = #p c.t
scoreboard players operation #bricks c.h = #h c.t
scoreboard players operation #bricks c.vs = #vs c.t
scoreboard players operation #bricks c.as = #as c.t
scoreboard players operation #bricks c.ev = #e c.t
scoreboard players remove #bricks c.ev 1000
