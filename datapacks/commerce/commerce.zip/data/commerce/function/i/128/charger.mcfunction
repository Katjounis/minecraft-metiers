scoreboard players set #b c.t 114
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"pink_wool",n:"Laine rose",i3:"128",cn:"Laines et teintures",cb:105}
scoreboard players operation #p c.t = #pink_wool c.p
scoreboard players operation #h c.t = #pink_wool c.h
scoreboard players operation #vs c.t = #pink_wool c.vs
scoreboard players operation #as c.t = #pink_wool c.as
scoreboard players operation #e c.t = #pink_wool c.ev
scoreboard players add #e c.t 1000
