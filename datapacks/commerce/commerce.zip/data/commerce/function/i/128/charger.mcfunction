scoreboard players set #b c.t 30000
scoreboard players set #V c.t 8
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 1
data modify storage commerce:t it set value {id:"totem_of_undying",n:"Totem d'immortalité",i3:"128",cn:"Trésors",cb:19}
scoreboard players operation #p c.t = #totem_of_undying c.p
scoreboard players operation #h c.t = #totem_of_undying c.h
scoreboard players operation #vs c.t = #totem_of_undying c.vs
scoreboard players operation #as c.t = #totem_of_undying c.as
scoreboard players operation #e c.t = #totem_of_undying c.ev
scoreboard players add #e c.t 1000
