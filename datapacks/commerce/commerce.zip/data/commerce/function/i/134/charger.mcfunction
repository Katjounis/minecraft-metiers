scoreboard players set #b c.t 145
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"brown_wool",n:"Laine marron",i3:"134",cn:"Laines et teintures",cb:1051}
scoreboard players operation #p c.t = #brown_wool c.p
scoreboard players operation #h c.t = #brown_wool c.h
scoreboard players operation #vs c.t = #brown_wool c.vs
scoreboard players operation #as c.t = #brown_wool c.as
scoreboard players operation #e c.t = #brown_wool c.ev
scoreboard players add #e c.t 1000
