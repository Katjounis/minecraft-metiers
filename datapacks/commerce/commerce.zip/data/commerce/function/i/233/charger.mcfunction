scoreboard players set #b c.t 7110
scoreboard players set #V c.t 64
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"raw_iron_block",n:"Bloc de fer brut",i3:"233",cn:"Minerais et métaux",cb:108}
scoreboard players operation #p c.t = #raw_iron_block c.p
scoreboard players operation #h c.t = #raw_iron_block c.h
scoreboard players operation #vs c.t = #raw_iron_block c.vs
scoreboard players operation #as c.t = #raw_iron_block c.as
scoreboard players operation #e c.t = #raw_iron_block c.ev
scoreboard players add #e c.t 1000
