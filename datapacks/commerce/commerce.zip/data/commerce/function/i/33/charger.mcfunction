scoreboard players set #b c.t 38
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"cut_red_sandstone",n:"Grès rouge taillé",i3:"033",cn:"Pierres",cb:1013}
scoreboard players operation #p c.t = #cut_red_sandstone c.p
scoreboard players operation #h c.t = #cut_red_sandstone c.h
scoreboard players operation #vs c.t = #cut_red_sandstone c.vs
scoreboard players operation #as c.t = #cut_red_sandstone c.as
scoreboard players operation #e c.t = #cut_red_sandstone c.ev
scoreboard players add #e c.t 1000
