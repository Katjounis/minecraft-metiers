scoreboard players set #b c.t 100
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"redstone",n:"Poudre de redstone",i3:"048",cn:"Minerais",cb:13}
scoreboard players operation #p c.t = #redstone c.p
scoreboard players operation #h c.t = #redstone c.h
scoreboard players operation #vs c.t = #redstone c.vs
scoreboard players operation #as c.t = #redstone c.as
scoreboard players operation #e c.t = #redstone c.ev
scoreboard players add #e c.t 1000
