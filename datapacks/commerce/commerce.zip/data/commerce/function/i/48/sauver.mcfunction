scoreboard players operation #podzol c.p = #p c.t
scoreboard players operation #podzol c.h = #h c.t
scoreboard players operation #podzol c.vs = #vs c.t
scoreboard players operation #podzol c.as = #as c.t
scoreboard players operation #podzol c.ev = #e c.t
scoreboard players remove #podzol c.ev 1000
