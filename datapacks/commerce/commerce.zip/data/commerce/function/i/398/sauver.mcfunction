scoreboard players operation #saddle c.p = #p c.t
scoreboard players operation #saddle c.h = #h c.t
scoreboard players operation #saddle c.vs = #vs c.t
scoreboard players operation #saddle c.as = #as c.t
scoreboard players operation #saddle c.ev = #e c.t
scoreboard players remove #saddle c.ev 1000
