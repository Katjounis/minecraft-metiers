scoreboard players set #b c.t 30
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"sunflower",n:"Tournesol",i3:"413",cn:"Fleurs et plantes",cb:116}
scoreboard players operation #p c.t = #sunflower c.p
scoreboard players operation #h c.t = #sunflower c.h
scoreboard players operation #vs c.t = #sunflower c.vs
scoreboard players operation #as c.t = #sunflower c.as
scoreboard players operation #e c.t = #sunflower c.ev
scoreboard players add #e c.t 1000
