scoreboard players operation #sunflower c.p = #p c.t
scoreboard players operation #sunflower c.h = #h c.t
scoreboard players operation #sunflower c.vs = #vs c.t
scoreboard players operation #sunflower c.as = #as c.t
scoreboard players operation #sunflower c.ev = #e c.t
scoreboard players remove #sunflower c.ev 1000
