scoreboard players set #b c.t 12
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 0
scoreboard players set #cher c.t 0
data modify storage commerce:t it set value {id:"white_dye",n:"Teinture blanche",i3:"138",cn:"Laines et teintures",cb:1051}
scoreboard players operation #p c.t = #white_dye c.p
scoreboard players operation #h c.t = #white_dye c.h
scoreboard players operation #vs c.t = #white_dye c.vs
scoreboard players operation #as c.t = #white_dye c.as
scoreboard players operation #e c.t = #white_dye c.ev
scoreboard players add #e c.t 1000
