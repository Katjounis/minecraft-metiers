scoreboard players operation #porkchop c.p = #p c.t
scoreboard players operation #porkchop c.h = #h c.t
scoreboard players operation #porkchop c.vs = #vs c.t
scoreboard players operation #porkchop c.as = #as c.t
scoreboard players operation #porkchop c.ev = #e c.t
scoreboard players remove #porkchop c.ev 1000
