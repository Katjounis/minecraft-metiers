scoreboard players set #b c.t 150
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"porkchop",n:"Côtelette de porc crue",i3:"072",cn:"Élevage et chasse",cb:15}
scoreboard players operation #p c.t = #porkchop c.p
scoreboard players operation #h c.t = #porkchop c.h
scoreboard players operation #vs c.t = #porkchop c.vs
scoreboard players operation #as c.t = #porkchop c.as
scoreboard players operation #e c.t = #porkchop c.ev
scoreboard players add #e c.t 1000
