scoreboard players set #b c.t 1500
scoreboard players set #V c.t 32
scoreboard players set #mj c.t 9
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"name_tag",n:"Étiquette",i3:"116",cn:"Utilitaires",cb:18}
scoreboard players operation #p c.t = #name_tag c.p
scoreboard players operation #h c.t = #name_tag c.h
scoreboard players operation #vs c.t = #name_tag c.vs
scoreboard players operation #as c.t = #name_tag c.as
scoreboard players operation #e c.t = #name_tag c.ev
scoreboard players add #e c.t 1000
