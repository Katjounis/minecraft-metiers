scoreboard players operation #name_tag c.p = #p c.t
scoreboard players operation #name_tag c.h = #h c.t
scoreboard players operation #name_tag c.vs = #vs c.t
scoreboard players operation #name_tag c.as = #as c.t
scoreboard players operation #name_tag c.ev = #e c.t
scoreboard players remove #name_tag c.ev 1000
