scoreboard players operation #fern c.p = #p c.t
scoreboard players operation #fern c.h = #h c.t
scoreboard players operation #fern c.vs = #vs c.t
scoreboard players operation #fern c.as = #as c.t
scoreboard players operation #fern c.ev = #e c.t
scoreboard players remove #fern c.ev 1000
