scoreboard players set #b c.t 5
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"fern",n:"Fougère",i3:"422",cn:"Fleurs et plantes",cb:1162}
scoreboard players operation #p c.t = #fern c.p
scoreboard players operation #h c.t = #fern c.h
scoreboard players operation #vs c.t = #fern c.vs
scoreboard players operation #as c.t = #fern c.as
scoreboard players operation #e c.t = #fern c.ev
scoreboard players add #e c.t 1000
