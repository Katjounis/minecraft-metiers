scoreboard players set #b c.t 30
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"magma_block",n:"Bloc de magma",i3:"261",cn:"Nether et End",cb:109}
scoreboard players operation #p c.t = #magma_block c.p
scoreboard players operation #h c.t = #magma_block c.h
scoreboard players operation #vs c.t = #magma_block c.vs
scoreboard players operation #as c.t = #magma_block c.as
scoreboard players operation #e c.t = #magma_block c.ev
scoreboard players add #e c.t 1000
