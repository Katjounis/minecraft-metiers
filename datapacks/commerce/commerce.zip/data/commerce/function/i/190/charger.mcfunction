scoreboard players set #b c.t 20
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"orange_stained_glass",n:"Verre teinté orange",i3:"190",cn:"Verre",cb:107}
scoreboard players operation #p c.t = #orange_stained_glass c.p
scoreboard players operation #h c.t = #orange_stained_glass c.h
scoreboard players operation #vs c.t = #orange_stained_glass c.vs
scoreboard players operation #as c.t = #orange_stained_glass c.as
scoreboard players operation #e c.t = #orange_stained_glass c.ev
scoreboard players add #e c.t 1000
