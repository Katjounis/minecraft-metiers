scoreboard players operation #nether_star c.p = #p c.t
scoreboard players operation #nether_star c.h = #h c.t
scoreboard players operation #nether_star c.vs = #vs c.t
scoreboard players operation #nether_star c.as = #as c.t
scoreboard players operation #nether_star c.ev = #e c.t
scoreboard players remove #nether_star c.ev 1000
