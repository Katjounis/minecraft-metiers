scoreboard players set #b c.t 400
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 1
data modify storage commerce:t it set value {id:"glowstone",n:"Pierre lumineuse",i3:"264",cn:"Nether et End",cb:1091}
scoreboard players operation #p c.t = #glowstone c.p
scoreboard players operation #h c.t = #glowstone c.h
scoreboard players operation #vs c.t = #glowstone c.vs
scoreboard players operation #as c.t = #glowstone c.as
scoreboard players operation #e c.t = #glowstone c.ev
scoreboard players add #e c.t 1000
