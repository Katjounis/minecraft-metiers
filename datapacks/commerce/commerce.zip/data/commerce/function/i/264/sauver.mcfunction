scoreboard players operation #glowstone c.p = #p c.t
scoreboard players operation #glowstone c.h = #h c.t
scoreboard players operation #glowstone c.vs = #vs c.t
scoreboard players operation #glowstone c.as = #as c.t
scoreboard players operation #glowstone c.ev = #e c.t
scoreboard players remove #glowstone c.ev 1000
