scoreboard players set #b c.t 300
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 4
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"magma_cream",n:"Crème de magma",i3:"262",cn:"Nether et End",cb:109}
scoreboard players operation #p c.t = #magma_cream c.p
scoreboard players operation #h c.t = #magma_cream c.h
scoreboard players operation #vs c.t = #magma_cream c.vs
scoreboard players operation #as c.t = #magma_cream c.as
scoreboard players operation #e c.t = #magma_cream c.ev
scoreboard players add #e c.t 1000
