scoreboard players operation #magma_cream c.p = #p c.t
scoreboard players operation #magma_cream c.h = #h c.t
scoreboard players operation #magma_cream c.vs = #vs c.t
scoreboard players operation #magma_cream c.as = #as c.t
scoreboard players operation #magma_cream c.ev = #e c.t
scoreboard players remove #magma_cream c.ev 1000
