scoreboard players operation #cooked_rabbit c.p = #p c.t
scoreboard players operation #cooked_rabbit c.h = #h c.t
scoreboard players operation #cooked_rabbit c.vs = #vs c.t
scoreboard players operation #cooked_rabbit c.as = #as c.t
scoreboard players operation #cooked_rabbit c.ev = #e c.t
scoreboard players remove #cooked_rabbit c.ev 1000
