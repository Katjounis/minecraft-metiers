scoreboard players set #b c.t 160
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 6
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cooked_rabbit",n:"Lapin cuit",i3:"357",cn:"Cuisine",cb:1131}
scoreboard players operation #p c.t = #cooked_rabbit c.p
scoreboard players operation #h c.t = #cooked_rabbit c.h
scoreboard players operation #vs c.t = #cooked_rabbit c.vs
scoreboard players operation #as c.t = #cooked_rabbit c.as
scoreboard players operation #e c.t = #cooked_rabbit c.ev
scoreboard players add #e c.t 1000
