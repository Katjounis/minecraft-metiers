scoreboard players set #b c.t 2500
scoreboard players set #V c.t 32
scoreboard players set #mj c.t 7
scoreboard players set #rare c.t 1
scoreboard players set #blk c.t 0
data modify storage commerce:t it set value {id:"enchanted_book",n:"Livre enchanté",i3:"460",cn:"Butin de boss",cb:1170}
scoreboard players operation #p c.t = #enchanted_book c.p
scoreboard players operation #h c.t = #enchanted_book c.h
scoreboard players operation #vs c.t = #enchanted_book c.vs
scoreboard players operation #as c.t = #enchanted_book c.as
scoreboard players operation #e c.t = #enchanted_book c.ev
scoreboard players add #e c.t 1000
