scoreboard players set #b c.t 300
scoreboard players set #V c.t 256
scoreboard players set #mj c.t 7
scoreboard players set #rare c.t 1
scoreboard players set #blk c.t 0
data modify storage commerce:t it set value {id:"experience_bottle",n:"Fiole d'expérience",i3:"460",cn:"Butin de boss",cb:1170}
scoreboard players operation #p c.t = #experience_bottle c.p
scoreboard players operation #h c.t = #experience_bottle c.h
scoreboard players operation #vs c.t = #experience_bottle c.vs
scoreboard players operation #as c.t = #experience_bottle c.as
scoreboard players operation #e c.t = #experience_bottle c.ev
scoreboard players add #e c.t 1000
