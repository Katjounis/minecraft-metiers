scoreboard players set #b c.t 25000
scoreboard players set #V c.t 8
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 1
scoreboard players set #blk c.t 0
scoreboard players set #cher c.t 0
data modify storage commerce:t it set value {id:"diamond_pickaxe",n:"Pioche en diamant",i3:"460",cn:"Butin de boss",cb:1170}
scoreboard players operation #p c.t = #diamond_pickaxe c.p
scoreboard players operation #h c.t = #diamond_pickaxe c.h
scoreboard players operation #vs c.t = #diamond_pickaxe c.vs
scoreboard players operation #as c.t = #diamond_pickaxe c.as
scoreboard players operation #e c.t = #diamond_pickaxe c.ev
scoreboard players add #e c.t 1000
