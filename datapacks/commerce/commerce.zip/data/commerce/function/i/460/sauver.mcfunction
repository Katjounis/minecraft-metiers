scoreboard players operation #enchanted_book c.p = #p c.t
scoreboard players operation #enchanted_book c.h = #h c.t
scoreboard players operation #enchanted_book c.vs = #vs c.t
scoreboard players operation #enchanted_book c.as = #as c.t
scoreboard players operation #enchanted_book c.ev = #e c.t
scoreboard players remove #enchanted_book c.ev 1000
