scoreboard players operation #experience_bottle c.p = #p c.t
scoreboard players operation #experience_bottle c.h = #h c.t
scoreboard players operation #experience_bottle c.vs = #vs c.t
scoreboard players operation #experience_bottle c.as = #as c.t
scoreboard players operation #experience_bottle c.ev = #e c.t
scoreboard players remove #experience_bottle c.ev 1000
