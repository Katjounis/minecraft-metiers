scoreboard players operation #diamond_pickaxe c.p = #p c.t
scoreboard players operation #diamond_pickaxe c.h = #h c.t
scoreboard players operation #diamond_pickaxe c.vs = #vs c.t
scoreboard players operation #diamond_pickaxe c.as = #as c.t
scoreboard players operation #diamond_pickaxe c.ev = #e c.t
scoreboard players remove #diamond_pickaxe c.ev 1000
