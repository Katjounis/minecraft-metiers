scoreboard players set #b c.t 3
scoreboard players set #V c.t 4096
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"dirt",n:"Terre",i3:"015",cn:"Construction",cb:11}
scoreboard players operation #p c.t = #dirt c.p
scoreboard players operation #h c.t = #dirt c.h
scoreboard players operation #vs c.t = #dirt c.vs
scoreboard players operation #as c.t = #dirt c.as
scoreboard players operation #e c.t = #dirt c.ev
scoreboard players add #e c.t 1000
