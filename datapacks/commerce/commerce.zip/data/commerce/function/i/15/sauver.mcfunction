scoreboard players operation #dirt c.p = #p c.t
scoreboard players operation #dirt c.h = #h c.t
scoreboard players operation #dirt c.vs = #vs c.t
scoreboard players operation #dirt c.as = #as c.t
scoreboard players operation #dirt c.ev = #e c.t
scoreboard players remove #dirt c.ev 1000
