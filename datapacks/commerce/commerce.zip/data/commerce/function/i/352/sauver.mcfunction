scoreboard players operation #mushroom_stew c.p = #p c.t
scoreboard players operation #mushroom_stew c.h = #h c.t
scoreboard players operation #mushroom_stew c.vs = #vs c.t
scoreboard players operation #mushroom_stew c.as = #as c.t
scoreboard players operation #mushroom_stew c.ev = #e c.t
scoreboard players remove #mushroom_stew c.ev 1000
