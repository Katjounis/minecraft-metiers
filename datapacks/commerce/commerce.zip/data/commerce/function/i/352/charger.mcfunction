scoreboard players set #b c.t 60
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"mushroom_stew",n:"Ragoût de champignons",i3:"352",cn:"Cuisine",cb:1130}
scoreboard players operation #p c.t = #mushroom_stew c.p
scoreboard players operation #h c.t = #mushroom_stew c.h
scoreboard players operation #vs c.t = #mushroom_stew c.vs
scoreboard players operation #as c.t = #mushroom_stew c.as
scoreboard players operation #e c.t = #mushroom_stew c.ev
scoreboard players add #e c.t 1000
