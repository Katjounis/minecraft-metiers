scoreboard players operation #short_grass c.p = #p c.t
scoreboard players operation #short_grass c.h = #h c.t
scoreboard players operation #short_grass c.vs = #vs c.t
scoreboard players operation #short_grass c.as = #as c.t
scoreboard players operation #short_grass c.ev = #e c.t
scoreboard players remove #short_grass c.ev 1000
