scoreboard players set #b c.t 3
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"short_grass",n:"Herbe",i3:"423",cn:"Fleurs et plantes",cb:1162}
scoreboard players operation #p c.t = #short_grass c.p
scoreboard players operation #h c.t = #short_grass c.h
scoreboard players operation #vs c.t = #short_grass c.vs
scoreboard players operation #as c.t = #short_grass c.as
scoreboard players operation #e c.t = #short_grass c.ev
scoreboard players add #e c.t 1000
