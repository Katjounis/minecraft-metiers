scoreboard players set #b c.t 100
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 3
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"coal",n:"Charbon",i3:"041",cn:"Minerais",cb:13}
scoreboard players operation #p c.t = #coal c.p
scoreboard players operation #h c.t = #coal c.h
scoreboard players operation #vs c.t = #coal c.vs
scoreboard players operation #as c.t = #coal c.as
scoreboard players operation #e c.t = #coal c.ev
scoreboard players add #e c.t 1000
