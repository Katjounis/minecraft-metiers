scoreboard players operation #coal c.p = #p c.t
scoreboard players operation #coal c.h = #h c.t
scoreboard players operation #coal c.vs = #vs c.t
scoreboard players operation #coal c.as = #as c.t
scoreboard players operation #coal c.ev = #e c.t
scoreboard players remove #coal c.ev 1000
