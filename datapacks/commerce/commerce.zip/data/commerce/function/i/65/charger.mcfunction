scoreboard players set #b c.t 40
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 2
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"cactus",n:"Cactus",i3:"065",cn:"Agriculture",cb:14}
scoreboard players operation #p c.t = #cactus c.p
scoreboard players operation #h c.t = #cactus c.h
scoreboard players operation #vs c.t = #cactus c.vs
scoreboard players operation #as c.t = #cactus c.as
scoreboard players operation #e c.t = #cactus c.ev
scoreboard players add #e c.t 1000
