scoreboard players set #b c.t 110
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
scoreboard players set #blk c.t 0
scoreboard players set #cher c.t 0
data modify storage commerce:t it set value {id:"cooked_cod",n:"Morue cuite",i3:"358",cn:"Cuisine",cb:1131}
scoreboard players operation #p c.t = #cooked_cod c.p
scoreboard players operation #h c.t = #cooked_cod c.h
scoreboard players operation #vs c.t = #cooked_cod c.vs
scoreboard players operation #as c.t = #cooked_cod c.as
scoreboard players operation #e c.t = #cooked_cod c.ev
scoreboard players add #e c.t 1000
