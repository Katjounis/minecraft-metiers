scoreboard players operation #cooked_cod c.p = #p c.t
scoreboard players operation #cooked_cod c.h = #h c.t
scoreboard players operation #cooked_cod c.vs = #vs c.t
scoreboard players operation #cooked_cod c.as = #as c.t
scoreboard players operation #cooked_cod c.ev = #e c.t
scoreboard players remove #cooked_cod c.ev 1000
