scoreboard players set #b c.t 90
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 5
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"dried_kelp_block",n:"Bloc d'algues séchées",i3:"345",cn:"Pêche",cb:1121}
scoreboard players operation #p c.t = #dried_kelp_block c.p
scoreboard players operation #h c.t = #dried_kelp_block c.h
scoreboard players operation #vs c.t = #dried_kelp_block c.vs
scoreboard players operation #as c.t = #dried_kelp_block c.as
scoreboard players operation #e c.t = #dried_kelp_block c.ev
scoreboard players add #e c.t 1000
