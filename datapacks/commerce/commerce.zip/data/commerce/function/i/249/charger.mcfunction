scoreboard players set #b c.t 600
scoreboard players set #V c.t 128
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"lightning_rod",n:"Paratonnerre",i3:"249",cn:"Minerais et métaux",cb:108}
scoreboard players operation #p c.t = #lightning_rod c.p
scoreboard players operation #h c.t = #lightning_rod c.h
scoreboard players operation #vs c.t = #lightning_rod c.vs
scoreboard players operation #as c.t = #lightning_rod c.as
scoreboard players operation #e c.t = #lightning_rod c.ev
scoreboard players add #e c.t 1000
