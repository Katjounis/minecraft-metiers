scoreboard players operation #red_stained_glass c.p = #p c.t
scoreboard players operation #red_stained_glass c.h = #h c.t
scoreboard players operation #red_stained_glass c.vs = #vs c.t
scoreboard players operation #red_stained_glass c.as = #as c.t
scoreboard players operation #red_stained_glass c.ev = #e c.t
scoreboard players remove #red_stained_glass c.ev 1000
