scoreboard players operation #leaf_litter c.p = #p c.t
scoreboard players operation #leaf_litter c.h = #h c.t
scoreboard players operation #leaf_litter c.vs = #vs c.t
scoreboard players operation #leaf_litter c.as = #as c.t
scoreboard players operation #leaf_litter c.ev = #e c.t
scoreboard players remove #leaf_litter c.ev 1000
