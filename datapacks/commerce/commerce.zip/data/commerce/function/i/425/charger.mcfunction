scoreboard players set #b c.t 5
scoreboard players set #V c.t 1024
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"leaf_litter",n:"Litière de feuilles",i3:"425",cn:"Fleurs et plantes",cb:116}
scoreboard players operation #p c.t = #leaf_litter c.p
scoreboard players operation #h c.t = #leaf_litter c.h
scoreboard players operation #vs c.t = #leaf_litter c.vs
scoreboard players operation #as c.t = #leaf_litter c.as
scoreboard players operation #e c.t = #leaf_litter c.ev
scoreboard players add #e c.t 1000
