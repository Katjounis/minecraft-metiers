scoreboard players operation #snowball c.p = #p c.t
scoreboard players operation #snowball c.h = #h c.t
scoreboard players operation #snowball c.vs = #vs c.t
scoreboard players operation #snowball c.as = #as c.t
scoreboard players operation #snowball c.ev = #e c.t
scoreboard players remove #snowball c.ev 1000
