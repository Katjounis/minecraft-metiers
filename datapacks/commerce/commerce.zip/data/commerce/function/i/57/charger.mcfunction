scoreboard players set #b c.t 2
scoreboard players set #V c.t 2048
scoreboard players set #mj c.t 0
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"snowball",n:"Boule de neige",i3:"057",cn:"Terre et glace",cb:102}
scoreboard players operation #p c.t = #snowball c.p
scoreboard players operation #h c.t = #snowball c.h
scoreboard players operation #vs c.t = #snowball c.vs
scoreboard players operation #as c.t = #snowball c.as
scoreboard players operation #e c.t = #snowball c.ev
scoreboard players add #e c.t 1000
