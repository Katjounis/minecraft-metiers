scoreboard players set #b c.t 20
scoreboard players set #V c.t 512
scoreboard players set #mj c.t 1
scoreboard players set #rare c.t 0
data modify storage commerce:t it set value {id:"oak_sapling",n:"Pousse de chêne",i3:"040",cn:"Bois",cb:12}
scoreboard players operation #p c.t = #oak_sapling c.p
scoreboard players operation #h c.t = #oak_sapling c.h
scoreboard players operation #vs c.t = #oak_sapling c.vs
scoreboard players operation #as c.t = #oak_sapling c.as
scoreboard players operation #e c.t = #oak_sapling c.ev
scoreboard players add #e c.t 1000
