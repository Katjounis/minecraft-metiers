scoreboard players operation #music_disc_wait c.p = #p c.t
scoreboard players operation #music_disc_wait c.h = #h c.t
scoreboard players operation #music_disc_wait c.vs = #vs c.t
scoreboard players operation #music_disc_wait c.as = #as c.t
scoreboard players operation #music_disc_wait c.ev = #e c.t
scoreboard players remove #music_disc_wait c.ev 1000
