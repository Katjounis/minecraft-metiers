scoreboard players operation #music_disc_chirp c.p = #p c.t
scoreboard players operation #music_disc_chirp c.h = #h c.t
scoreboard players operation #music_disc_chirp c.vs = #vs c.t
scoreboard players operation #music_disc_chirp c.as = #as c.t
scoreboard players operation #music_disc_chirp c.ev = #e c.t
scoreboard players remove #music_disc_chirp c.ev 1000
