scoreboard players operation #music_disc_far c.p = #p c.t
scoreboard players operation #music_disc_far c.h = #h c.t
scoreboard players operation #music_disc_far c.vs = #vs c.t
scoreboard players operation #music_disc_far c.as = #as c.t
scoreboard players operation #music_disc_far c.ev = #e c.t
scoreboard players remove #music_disc_far c.ev 1000
