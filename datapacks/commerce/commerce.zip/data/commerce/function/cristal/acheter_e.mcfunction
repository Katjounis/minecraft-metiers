function commerce:cristal/prix
execute store result storage commerce:t m.e int 1 run scoreboard players get #cp c.t
execute if score @s c.ecus < #cp c.t run return run function commerce:cristal/msg_pauvre with storage commerce:t m
scoreboard players operation @s c.ecus -= #cp c.t
scoreboard players operation @s c.ta += #cp c.t
scoreboard players add @s m.cr_e 1
scoreboard players add @s c.ncr 1
data modify storage commerce:t msg set value "Cristal de Éleveur acheté. Le suivant coûte 5 % de plus."
playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1 1.2
