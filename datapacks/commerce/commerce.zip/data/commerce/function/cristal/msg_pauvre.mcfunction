$data modify storage commerce:t msg set value "Pas assez d'Écus : un cristal coûte $(e) ¤."
playsound minecraft:entity.villager.no master @s ~ ~ ~ 0.8 1
