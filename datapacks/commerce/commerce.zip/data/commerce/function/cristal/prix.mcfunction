scoreboard players set #cp c.t 2500
scoreboard players operation #n c.t = @s c.ncr
execute if score #n c.t matches 201.. run scoreboard players set #n c.t 200
function commerce:cristal/prix_boucle
