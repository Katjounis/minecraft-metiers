execute if score #n c.t matches ..0 run return 0
scoreboard players operation #cp c.t *= #105 c.g
scoreboard players operation #cp c.t /= #100 c.g
scoreboard players remove #n c.t 1
function commerce:cristal/prix_boucle
