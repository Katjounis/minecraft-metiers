execute unless score @s c.ecv matches -2147483648.. run return run function commerce:journal/init
execute unless score @s c.ecus matches -2147483648.. run return 0
scoreboard players operation #jd c.t = @s c.ecus
scoreboard players operation #jd c.t -= @s c.ecv
scoreboard players add @s c.a_com 0
execute unless score @s c.a_com matches 0 run function commerce:journal/cat_com
scoreboard players add @s c.a_met 0
execute unless score @s c.a_met matches 0 run function commerce:journal/cat_met
scoreboard players add @s c.a_cmp 0
execute unless score @s c.a_cmp matches 0 run function commerce:journal/cat_cmp
scoreboard players add @s c.a_bos 0
execute unless score @s c.a_bos matches 0 run function commerce:journal/cat_bos
scoreboard players add @s c.a_hor 0
execute unless score @s c.a_hor matches 0 run function commerce:journal/cat_hor
scoreboard players add @s c.a_ind 0
execute unless score @s c.a_ind matches 0 run function commerce:journal/cat_ind
execute unless score #jd c.t matches 0 run function commerce:journal/inexplique
scoreboard players operation @s c.ecv = @s c.ecus
