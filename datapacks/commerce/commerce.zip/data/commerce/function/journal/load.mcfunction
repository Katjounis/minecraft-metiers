scoreboard objectives add c.ecv dummy
scoreboard objectives add c.a_com dummy
scoreboard objectives add c.a_met dummy
scoreboard objectives add c.a_cmp dummy
scoreboard objectives add c.a_bos dummy
scoreboard objectives add c.a_hor dummy
scoreboard objectives add c.a_ind dummy
execute unless data storage commerce:journal anomalies run data modify storage commerce:journal anomalies set value []
