scoreboard players operation #jd c.t -= @s c.a_met
scoreboard players operation #jv c.t = @s c.a_met
execute if score #jv c.t matches -49..49 run return run scoreboard players set @s c.a_met 0
data modify storage commerce:t m.l set value "Métiers"
function commerce:journal/ligne
scoreboard players set @s c.a_met 0
