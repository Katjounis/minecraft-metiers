scoreboard players operation @s c.ecv = @s c.ecus
scoreboard players set @s c.a_com 0
scoreboard players set @s c.a_met 0
scoreboard players set @s c.a_cmp 0
scoreboard players set @s c.a_bos 0
scoreboard players set @s c.a_hor 0
scoreboard players set @s c.a_ind 0
