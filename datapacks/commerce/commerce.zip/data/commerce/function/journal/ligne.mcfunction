execute store result storage commerce:t m.v int 1 run scoreboard players get #jv c.t
data modify storage commerce:t m.s set value ""
execute if score #jv c.t matches 1.. run data modify storage commerce:t m.s set value "+"
data modify storage commerce:t hl.col set value "green"
execute if score #jv c.t matches ..-1 run data modify storage commerce:t hl.col set value "red"
execute store result storage commerce:t hl.id int 1 run scoreboard players get @s m.id
data modify storage commerce:t hl.src set from storage commerce:t m
function commerce:journal/ligne_m with storage commerce:t hl.src
