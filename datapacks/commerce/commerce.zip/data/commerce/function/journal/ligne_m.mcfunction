$data modify storage commerce:t hl.txt set value "$(l) : $(s)$(v) Écus"
function commerce:banque/hist with storage commerce:t hl
