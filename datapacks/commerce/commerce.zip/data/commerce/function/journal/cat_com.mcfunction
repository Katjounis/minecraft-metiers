scoreboard players operation #jd c.t -= @s c.a_com
scoreboard players set @s c.a_com 0
