scoreboard players operation #jv c.t = #jd c.t
data modify storage commerce:t m.l set value "Mouvement non enregistré"
function commerce:journal/ligne
execute store result storage commerce:t ja.v int 1 run scoreboard players get #jd c.t
execute store result storage commerce:t ja.s int 1 run scoreboard players get @s c.ecus
execute store result storage commerce:t ja.t int 1 run time query gametime
function commerce:joueur/nom_moi
data modify storage commerce:t ja.nom set from storage commerce:t moi
data modify storage commerce:journal anomalies prepend from storage commerce:t ja
execute if data storage commerce:journal anomalies[50] run data remove storage commerce:journal anomalies[50]
function commerce:journal/msg with storage commerce:t m
