scoreboard players operation #jd c.t -= @s c.a_ind
scoreboard players set @s c.a_ind 0
