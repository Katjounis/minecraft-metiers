execute if score @s c.deb matches 1 run return 0
scoreboard players set @s c.deb 1
tellraw @a [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{selector:"@s",color:"white"},{text:" ouvre son comptoir : le Commerce est débloqué !",color:"gold",bold:true,italic:false}]
tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Pose l'oeuf à ta base. Touche G, Commerce : marché, bourse, banque et cristaux, depuis n'importe où.",color:"yellow",bold:false,italic:false}]
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
