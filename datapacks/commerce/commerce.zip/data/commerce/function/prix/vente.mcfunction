scoreboard players set #f c.t 1000
scoreboard players operation #f c.t -= #pm c.t
scoreboard players operation #u c.t = #b c.t
scoreboard players operation #u c.t *= #f c.t
scoreboard players operation #u c.t /= #1000 c.g
scoreboard players operation #u c.t *= #e c.t
scoreboard players operation #u c.t /= #1000 c.g
execute if score #u c.t matches ..0 run scoreboard players set #u c.t 1
scoreboard players operation #u0 c.t = #u c.t
scoreboard players operation #u c.t *= #bon c.t
scoreboard players operation #u c.t /= #1000 c.g
execute if score #u c.t matches ..0 run scoreboard players set #u c.t 1
scoreboard players operation #a c.t = #u0 c.t
scoreboard players operation #a c.t *= #achat c.g
