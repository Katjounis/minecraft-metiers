scoreboard players set #bon c.t 1000
