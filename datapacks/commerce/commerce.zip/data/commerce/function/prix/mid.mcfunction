scoreboard players operation #pm c.t = #d c.t
scoreboard players operation #pm c.t /= #2 c.g
scoreboard players operation #pm c.t += #p c.t
execute if score #pm c.t matches 701.. run scoreboard players set #pm c.t 700
execute if score #pm c.t matches ..-301 run scoreboard players set #pm c.t -300
