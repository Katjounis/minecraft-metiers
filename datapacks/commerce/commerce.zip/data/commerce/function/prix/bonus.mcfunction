scoreboard players set #bon c.t 1000
scoreboard players set #lv c.t 0
execute if score #mj c.t matches 1 run scoreboard players operation #lv c.t = @s m.b_lvl
execute if score #mj c.t matches 2 run scoreboard players operation #lv c.t = @s m.f_lvl
execute if score #mj c.t matches 3 run scoreboard players operation #lv c.t = @s m.m_lvl
execute if score #mj c.t matches 4 run scoreboard players operation #lv c.t = @s m.c_lvl
execute if score #mj c.t matches 5 run scoreboard players operation #lv c.t = @s m.p_lvl
execute if score #mj c.t matches 6 run scoreboard players operation #lv c.t = @s m.e_lvl
execute if score #mj c.t matches 7 run scoreboard players operation #lv c.t = @s m.n_lvl
execute if score #mj c.t matches 8 run scoreboard players operation #lv c.t = @s m.x_lvl
execute if score #mj c.t matches 9 run scoreboard players operation #lv c.t = @s m.t_lvl
execute if score #lv c.t matches 101.. run scoreboard players set #lv c.t 100
execute if score #lv c.t matches ..-1 run scoreboard players set #lv c.t 0
scoreboard players operation #lv c.t *= #5 c.g
scoreboard players operation #bon c.t += #lv c.t
execute if score #mj c.t matches 1.. if score #mj c.t = #job m.heure run scoreboard players add #bon c.t 250
