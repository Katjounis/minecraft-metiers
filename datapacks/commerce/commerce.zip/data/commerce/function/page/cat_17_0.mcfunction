function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 459
function commerce:page/ligne
data modify storage commerce:cp ve459 set from storage commerce:l ve
data modify storage commerce:cp vz459 set from storage commerce:l vz
data modify storage commerce:cp vc459 set from storage commerce:l vc
data modify storage commerce:cp ae459 set from storage commerce:l ae
data modify storage commerce:cp az459 set from storage commerce:l az
data modify storage commerce:cp ac459 set from storage commerce:l ac
data modify storage commerce:cp t459 set from storage commerce:l t
scoreboard players set #i c.t 460
function commerce:page/ligne
data modify storage commerce:cp ve460 set from storage commerce:l ve
data modify storage commerce:cp vz460 set from storage commerce:l vz
data modify storage commerce:cp vc460 set from storage commerce:l vc
data modify storage commerce:cp ae460 set from storage commerce:l ae
data modify storage commerce:cp az460 set from storage commerce:l az
data modify storage commerce:cp ac460 set from storage commerce:l ac
data modify storage commerce:cp t460 set from storage commerce:l t
scoreboard players set #i c.t 461
function commerce:page/ligne
data modify storage commerce:cp ve461 set from storage commerce:l ve
data modify storage commerce:cp vz461 set from storage commerce:l vz
data modify storage commerce:cp vc461 set from storage commerce:l vc
data modify storage commerce:cp ae461 set from storage commerce:l ae
data modify storage commerce:cp az461 set from storage commerce:l az
data modify storage commerce:cp ac461 set from storage commerce:l ac
data modify storage commerce:cp t461 set from storage commerce:l t
scoreboard players set #i c.t 462
function commerce:page/ligne
data modify storage commerce:cp ve462 set from storage commerce:l ve
data modify storage commerce:cp vz462 set from storage commerce:l vz
data modify storage commerce:cp vc462 set from storage commerce:l vc
data modify storage commerce:cp ae462 set from storage commerce:l ae
data modify storage commerce:cp az462 set from storage commerce:l az
data modify storage commerce:cp ac462 set from storage commerce:l ac
data modify storage commerce:cp t462 set from storage commerce:l t
scoreboard players set #i c.t 463
function commerce:page/ligne
data modify storage commerce:cp ve463 set from storage commerce:l ve
data modify storage commerce:cp vz463 set from storage commerce:l vz
data modify storage commerce:cp vc463 set from storage commerce:l vc
data modify storage commerce:cp ae463 set from storage commerce:l ae
data modify storage commerce:cp az463 set from storage commerce:l az
data modify storage commerce:cp ac463 set from storage commerce:l ac
data modify storage commerce:cp t463 set from storage commerce:l t
scoreboard players set #i c.t 464
function commerce:page/ligne
data modify storage commerce:cp ve464 set from storage commerce:l ve
data modify storage commerce:cp vz464 set from storage commerce:l vz
data modify storage commerce:cp vc464 set from storage commerce:l vc
data modify storage commerce:cp ae464 set from storage commerce:l ae
data modify storage commerce:cp az464 set from storage commerce:l az
data modify storage commerce:cp ac464 set from storage commerce:l ac
data modify storage commerce:cp t464 set from storage commerce:l t
scoreboard players set #i c.t 465
function commerce:page/ligne
data modify storage commerce:cp ve465 set from storage commerce:l ve
data modify storage commerce:cp vz465 set from storage commerce:l vz
data modify storage commerce:cp vc465 set from storage commerce:l vc
data modify storage commerce:cp ae465 set from storage commerce:l ae
data modify storage commerce:cp az465 set from storage commerce:l az
data modify storage commerce:cp ac465 set from storage commerce:l ac
data modify storage commerce:cp t465 set from storage commerce:l t
scoreboard players set #i c.t 466
function commerce:page/ligne
data modify storage commerce:cp ve466 set from storage commerce:l ve
data modify storage commerce:cp vz466 set from storage commerce:l vz
data modify storage commerce:cp vc466 set from storage commerce:l vc
data modify storage commerce:cp ae466 set from storage commerce:l ae
data modify storage commerce:cp az466 set from storage commerce:l az
data modify storage commerce:cp ac466 set from storage commerce:l ac
data modify storage commerce:cp t466 set from storage commerce:l t
scoreboard players set #i c.t 467
function commerce:page/ligne
data modify storage commerce:cp ve467 set from storage commerce:l ve
data modify storage commerce:cp vz467 set from storage commerce:l vz
data modify storage commerce:cp vc467 set from storage commerce:l vc
data modify storage commerce:cp ae467 set from storage commerce:l ae
data modify storage commerce:cp az467 set from storage commerce:l az
data modify storage commerce:cp ac467 set from storage commerce:l ac
data modify storage commerce:cp t467 set from storage commerce:l t
scoreboard players set #i c.t 468
function commerce:page/ligne
data modify storage commerce:cp ve468 set from storage commerce:l ve
data modify storage commerce:cp vz468 set from storage commerce:l vz
data modify storage commerce:cp vc468 set from storage commerce:l vc
data modify storage commerce:cp ae468 set from storage commerce:l ae
data modify storage commerce:cp az468 set from storage commerce:l az
data modify storage commerce:cp ac468 set from storage commerce:l ac
data modify storage commerce:cp t468 set from storage commerce:l t
function commerce:page/cat_17_0_d with storage commerce:cp
