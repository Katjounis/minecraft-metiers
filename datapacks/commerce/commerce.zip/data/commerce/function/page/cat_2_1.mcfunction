function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 55
function commerce:page/ligne
data modify storage commerce:cp ve55 set from storage commerce:l ve
data modify storage commerce:cp vz55 set from storage commerce:l vz
data modify storage commerce:cp vc55 set from storage commerce:l vc
data modify storage commerce:cp ae55 set from storage commerce:l ae
data modify storage commerce:cp az55 set from storage commerce:l az
data modify storage commerce:cp ac55 set from storage commerce:l ac
data modify storage commerce:cp t55 set from storage commerce:l t
scoreboard players set #i c.t 56
function commerce:page/ligne
data modify storage commerce:cp ve56 set from storage commerce:l ve
data modify storage commerce:cp vz56 set from storage commerce:l vz
data modify storage commerce:cp vc56 set from storage commerce:l vc
data modify storage commerce:cp ae56 set from storage commerce:l ae
data modify storage commerce:cp az56 set from storage commerce:l az
data modify storage commerce:cp ac56 set from storage commerce:l ac
data modify storage commerce:cp t56 set from storage commerce:l t
scoreboard players set #i c.t 57
function commerce:page/ligne
data modify storage commerce:cp ve57 set from storage commerce:l ve
data modify storage commerce:cp vz57 set from storage commerce:l vz
data modify storage commerce:cp vc57 set from storage commerce:l vc
data modify storage commerce:cp ae57 set from storage commerce:l ae
data modify storage commerce:cp az57 set from storage commerce:l az
data modify storage commerce:cp ac57 set from storage commerce:l ac
data modify storage commerce:cp t57 set from storage commerce:l t
scoreboard players set #i c.t 58
function commerce:page/ligne
data modify storage commerce:cp ve58 set from storage commerce:l ve
data modify storage commerce:cp vz58 set from storage commerce:l vz
data modify storage commerce:cp vc58 set from storage commerce:l vc
data modify storage commerce:cp ae58 set from storage commerce:l ae
data modify storage commerce:cp az58 set from storage commerce:l az
data modify storage commerce:cp ac58 set from storage commerce:l ac
data modify storage commerce:cp t58 set from storage commerce:l t
scoreboard players set #i c.t 59
function commerce:page/ligne
data modify storage commerce:cp ve59 set from storage commerce:l ve
data modify storage commerce:cp vz59 set from storage commerce:l vz
data modify storage commerce:cp vc59 set from storage commerce:l vc
data modify storage commerce:cp ae59 set from storage commerce:l ae
data modify storage commerce:cp az59 set from storage commerce:l az
data modify storage commerce:cp ac59 set from storage commerce:l ac
data modify storage commerce:cp t59 set from storage commerce:l t
scoreboard players set #i c.t 60
function commerce:page/ligne
data modify storage commerce:cp ve60 set from storage commerce:l ve
data modify storage commerce:cp vz60 set from storage commerce:l vz
data modify storage commerce:cp vc60 set from storage commerce:l vc
data modify storage commerce:cp ae60 set from storage commerce:l ae
data modify storage commerce:cp az60 set from storage commerce:l az
data modify storage commerce:cp ac60 set from storage commerce:l ac
data modify storage commerce:cp t60 set from storage commerce:l t
scoreboard players set #i c.t 61
function commerce:page/ligne
data modify storage commerce:cp ve61 set from storage commerce:l ve
data modify storage commerce:cp vz61 set from storage commerce:l vz
data modify storage commerce:cp vc61 set from storage commerce:l vc
data modify storage commerce:cp ae61 set from storage commerce:l ae
data modify storage commerce:cp az61 set from storage commerce:l az
data modify storage commerce:cp ac61 set from storage commerce:l ac
data modify storage commerce:cp t61 set from storage commerce:l t
scoreboard players set #i c.t 62
function commerce:page/ligne
data modify storage commerce:cp ve62 set from storage commerce:l ve
data modify storage commerce:cp vz62 set from storage commerce:l vz
data modify storage commerce:cp vc62 set from storage commerce:l vc
data modify storage commerce:cp ae62 set from storage commerce:l ae
data modify storage commerce:cp az62 set from storage commerce:l az
data modify storage commerce:cp ac62 set from storage commerce:l ac
data modify storage commerce:cp t62 set from storage commerce:l t
scoreboard players set #i c.t 63
function commerce:page/ligne
data modify storage commerce:cp ve63 set from storage commerce:l ve
data modify storage commerce:cp vz63 set from storage commerce:l vz
data modify storage commerce:cp vc63 set from storage commerce:l vc
data modify storage commerce:cp ae63 set from storage commerce:l ae
data modify storage commerce:cp az63 set from storage commerce:l az
data modify storage commerce:cp ac63 set from storage commerce:l ac
data modify storage commerce:cp t63 set from storage commerce:l t
function commerce:page/cat_2_1_d with storage commerce:cp
