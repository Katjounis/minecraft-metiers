function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 274
function commerce:page/ligne
data modify storage commerce:cp ve274 set from storage commerce:l ve
data modify storage commerce:cp vz274 set from storage commerce:l vz
data modify storage commerce:cp vc274 set from storage commerce:l vc
data modify storage commerce:cp ae274 set from storage commerce:l ae
data modify storage commerce:cp az274 set from storage commerce:l az
data modify storage commerce:cp ac274 set from storage commerce:l ac
data modify storage commerce:cp t274 set from storage commerce:l t
scoreboard players set #i c.t 5
function commerce:page/ligne
data modify storage commerce:cp ve5 set from storage commerce:l ve
data modify storage commerce:cp vz5 set from storage commerce:l vz
data modify storage commerce:cp vc5 set from storage commerce:l vc
data modify storage commerce:cp ae5 set from storage commerce:l ae
data modify storage commerce:cp az5 set from storage commerce:l az
data modify storage commerce:cp ac5 set from storage commerce:l ac
data modify storage commerce:cp t5 set from storage commerce:l t
scoreboard players set #i c.t 7
function commerce:page/ligne
data modify storage commerce:cp ve7 set from storage commerce:l ve
data modify storage commerce:cp vz7 set from storage commerce:l vz
data modify storage commerce:cp vc7 set from storage commerce:l vc
data modify storage commerce:cp ae7 set from storage commerce:l ae
data modify storage commerce:cp az7 set from storage commerce:l az
data modify storage commerce:cp ac7 set from storage commerce:l ac
data modify storage commerce:cp t7 set from storage commerce:l t
scoreboard players set #i c.t 6
function commerce:page/ligne
data modify storage commerce:cp ve6 set from storage commerce:l ve
data modify storage commerce:cp vz6 set from storage commerce:l vz
data modify storage commerce:cp vc6 set from storage commerce:l vc
data modify storage commerce:cp ae6 set from storage commerce:l ae
data modify storage commerce:cp az6 set from storage commerce:l az
data modify storage commerce:cp ac6 set from storage commerce:l ac
data modify storage commerce:cp t6 set from storage commerce:l t
scoreboard players set #i c.t 8
function commerce:page/ligne
data modify storage commerce:cp ve8 set from storage commerce:l ve
data modify storage commerce:cp vz8 set from storage commerce:l vz
data modify storage commerce:cp vc8 set from storage commerce:l vc
data modify storage commerce:cp ae8 set from storage commerce:l ae
data modify storage commerce:cp az8 set from storage commerce:l az
data modify storage commerce:cp ac8 set from storage commerce:l ac
data modify storage commerce:cp t8 set from storage commerce:l t
scoreboard players set #i c.t 40
function commerce:page/ligne
data modify storage commerce:cp ve40 set from storage commerce:l ve
data modify storage commerce:cp vz40 set from storage commerce:l vz
data modify storage commerce:cp vc40 set from storage commerce:l vc
data modify storage commerce:cp ae40 set from storage commerce:l ae
data modify storage commerce:cp az40 set from storage commerce:l az
data modify storage commerce:cp ac40 set from storage commerce:l ac
data modify storage commerce:cp t40 set from storage commerce:l t
scoreboard players set #i c.t 270
function commerce:page/ligne
data modify storage commerce:cp ve270 set from storage commerce:l ve
data modify storage commerce:cp vz270 set from storage commerce:l vz
data modify storage commerce:cp vc270 set from storage commerce:l vc
data modify storage commerce:cp ae270 set from storage commerce:l ae
data modify storage commerce:cp az270 set from storage commerce:l az
data modify storage commerce:cp ac270 set from storage commerce:l ac
data modify storage commerce:cp t270 set from storage commerce:l t
scoreboard players set #i c.t 259
function commerce:page/ligne
data modify storage commerce:cp ve259 set from storage commerce:l ve
data modify storage commerce:cp vz259 set from storage commerce:l vz
data modify storage commerce:cp vc259 set from storage commerce:l vc
data modify storage commerce:cp ae259 set from storage commerce:l ae
data modify storage commerce:cp az259 set from storage commerce:l az
data modify storage commerce:cp ac259 set from storage commerce:l ac
data modify storage commerce:cp t259 set from storage commerce:l t
scoreboard players set #i c.t 23
function commerce:page/ligne
data modify storage commerce:cp ve23 set from storage commerce:l ve
data modify storage commerce:cp vz23 set from storage commerce:l vz
data modify storage commerce:cp vc23 set from storage commerce:l vc
data modify storage commerce:cp ae23 set from storage commerce:l ae
data modify storage commerce:cp az23 set from storage commerce:l az
data modify storage commerce:cp ac23 set from storage commerce:l ac
data modify storage commerce:cp t23 set from storage commerce:l t
scoreboard players set #i c.t 252
function commerce:page/ligne
data modify storage commerce:cp ve252 set from storage commerce:l ve
data modify storage commerce:cp vz252 set from storage commerce:l vz
data modify storage commerce:cp vc252 set from storage commerce:l vc
data modify storage commerce:cp ae252 set from storage commerce:l ae
data modify storage commerce:cp az252 set from storage commerce:l az
data modify storage commerce:cp ac252 set from storage commerce:l ac
data modify storage commerce:cp t252 set from storage commerce:l t
function commerce:page/lettre_b_7_d with storage commerce:cp
