function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 74
function commerce:page/ligne
data modify storage commerce:cp ve74 set from storage commerce:l ve
data modify storage commerce:cp vz74 set from storage commerce:l vz
data modify storage commerce:cp vc74 set from storage commerce:l vc
data modify storage commerce:cp ae74 set from storage commerce:l ae
data modify storage commerce:cp az74 set from storage commerce:l az
data modify storage commerce:cp ac74 set from storage commerce:l ac
data modify storage commerce:cp t74 set from storage commerce:l t
scoreboard players set #i c.t 75
function commerce:page/ligne
data modify storage commerce:cp ve75 set from storage commerce:l ve
data modify storage commerce:cp vz75 set from storage commerce:l vz
data modify storage commerce:cp vc75 set from storage commerce:l vc
data modify storage commerce:cp ae75 set from storage commerce:l ae
data modify storage commerce:cp az75 set from storage commerce:l az
data modify storage commerce:cp ac75 set from storage commerce:l ac
data modify storage commerce:cp t75 set from storage commerce:l t
scoreboard players set #i c.t 76
function commerce:page/ligne
data modify storage commerce:cp ve76 set from storage commerce:l ve
data modify storage commerce:cp vz76 set from storage commerce:l vz
data modify storage commerce:cp vc76 set from storage commerce:l vc
data modify storage commerce:cp ae76 set from storage commerce:l ae
data modify storage commerce:cp az76 set from storage commerce:l az
data modify storage commerce:cp ac76 set from storage commerce:l ac
data modify storage commerce:cp t76 set from storage commerce:l t
scoreboard players set #i c.t 77
function commerce:page/ligne
data modify storage commerce:cp ve77 set from storage commerce:l ve
data modify storage commerce:cp vz77 set from storage commerce:l vz
data modify storage commerce:cp vc77 set from storage commerce:l vc
data modify storage commerce:cp ae77 set from storage commerce:l ae
data modify storage commerce:cp az77 set from storage commerce:l az
data modify storage commerce:cp ac77 set from storage commerce:l ac
data modify storage commerce:cp t77 set from storage commerce:l t
scoreboard players set #i c.t 78
function commerce:page/ligne
data modify storage commerce:cp ve78 set from storage commerce:l ve
data modify storage commerce:cp vz78 set from storage commerce:l vz
data modify storage commerce:cp vc78 set from storage commerce:l vc
data modify storage commerce:cp ae78 set from storage commerce:l ae
data modify storage commerce:cp az78 set from storage commerce:l az
data modify storage commerce:cp ac78 set from storage commerce:l ac
data modify storage commerce:cp t78 set from storage commerce:l t
scoreboard players set #i c.t 79
function commerce:page/ligne
data modify storage commerce:cp ve79 set from storage commerce:l ve
data modify storage commerce:cp vz79 set from storage commerce:l vz
data modify storage commerce:cp vc79 set from storage commerce:l vc
data modify storage commerce:cp ae79 set from storage commerce:l ae
data modify storage commerce:cp az79 set from storage commerce:l az
data modify storage commerce:cp ac79 set from storage commerce:l ac
data modify storage commerce:cp t79 set from storage commerce:l t
scoreboard players set #i c.t 80
function commerce:page/ligne
data modify storage commerce:cp ve80 set from storage commerce:l ve
data modify storage commerce:cp vz80 set from storage commerce:l vz
data modify storage commerce:cp vc80 set from storage commerce:l vc
data modify storage commerce:cp ae80 set from storage commerce:l ae
data modify storage commerce:cp az80 set from storage commerce:l az
data modify storage commerce:cp ac80 set from storage commerce:l ac
data modify storage commerce:cp t80 set from storage commerce:l t
scoreboard players set #i c.t 81
function commerce:page/ligne
data modify storage commerce:cp ve81 set from storage commerce:l ve
data modify storage commerce:cp vz81 set from storage commerce:l vz
data modify storage commerce:cp vc81 set from storage commerce:l vc
data modify storage commerce:cp ae81 set from storage commerce:l ae
data modify storage commerce:cp az81 set from storage commerce:l az
data modify storage commerce:cp ac81 set from storage commerce:l ac
data modify storage commerce:cp t81 set from storage commerce:l t
scoreboard players set #i c.t 82
function commerce:page/ligne
data modify storage commerce:cp ve82 set from storage commerce:l ve
data modify storage commerce:cp vz82 set from storage commerce:l vz
data modify storage commerce:cp vc82 set from storage commerce:l vc
data modify storage commerce:cp ae82 set from storage commerce:l ae
data modify storage commerce:cp az82 set from storage commerce:l az
data modify storage commerce:cp ac82 set from storage commerce:l ac
data modify storage commerce:cp t82 set from storage commerce:l t
scoreboard players set #i c.t 83
function commerce:page/ligne
data modify storage commerce:cp ve83 set from storage commerce:l ve
data modify storage commerce:cp vz83 set from storage commerce:l vz
data modify storage commerce:cp vc83 set from storage commerce:l vc
data modify storage commerce:cp ae83 set from storage commerce:l ae
data modify storage commerce:cp az83 set from storage commerce:l az
data modify storage commerce:cp ac83 set from storage commerce:l ac
data modify storage commerce:cp t83 set from storage commerce:l t
function commerce:page/cat_3_1_d with storage commerce:cp
