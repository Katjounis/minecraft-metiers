function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 181
function commerce:page/ligne
data modify storage commerce:cp ve181 set from storage commerce:l ve
data modify storage commerce:cp vz181 set from storage commerce:l vz
data modify storage commerce:cp vc181 set from storage commerce:l vc
data modify storage commerce:cp ae181 set from storage commerce:l ae
data modify storage commerce:cp az181 set from storage commerce:l az
data modify storage commerce:cp ac181 set from storage commerce:l ac
data modify storage commerce:cp t181 set from storage commerce:l t
scoreboard players set #i c.t 63
function commerce:page/ligne
data modify storage commerce:cp ve63 set from storage commerce:l ve
data modify storage commerce:cp vz63 set from storage commerce:l vz
data modify storage commerce:cp vc63 set from storage commerce:l vc
data modify storage commerce:cp ae63 set from storage commerce:l ae
data modify storage commerce:cp az63 set from storage commerce:l az
data modify storage commerce:cp ac63 set from storage commerce:l ac
data modify storage commerce:cp t63 set from storage commerce:l t
scoreboard players set #i c.t 47
function commerce:page/ligne
data modify storage commerce:cp ve47 set from storage commerce:l ve
data modify storage commerce:cp vz47 set from storage commerce:l vz
data modify storage commerce:cp vc47 set from storage commerce:l vc
data modify storage commerce:cp ae47 set from storage commerce:l ae
data modify storage commerce:cp az47 set from storage commerce:l az
data modify storage commerce:cp ac47 set from storage commerce:l ac
data modify storage commerce:cp t47 set from storage commerce:l t
scoreboard players set #i c.t 46
function commerce:page/ligne
data modify storage commerce:cp ve46 set from storage commerce:l ve
data modify storage commerce:cp vz46 set from storage commerce:l vz
data modify storage commerce:cp vc46 set from storage commerce:l vc
data modify storage commerce:cp ae46 set from storage commerce:l ae
data modify storage commerce:cp az46 set from storage commerce:l az
data modify storage commerce:cp ac46 set from storage commerce:l ac
data modify storage commerce:cp t46 set from storage commerce:l t
scoreboard players set #i c.t 447
function commerce:page/ligne
data modify storage commerce:cp ve447 set from storage commerce:l ve
data modify storage commerce:cp vz447 set from storage commerce:l vz
data modify storage commerce:cp vc447 set from storage commerce:l vc
data modify storage commerce:cp ae447 set from storage commerce:l ae
data modify storage commerce:cp az447 set from storage commerce:l az
data modify storage commerce:cp ac447 set from storage commerce:l ac
data modify storage commerce:cp t447 set from storage commerce:l t
scoreboard players set #i c.t 451
function commerce:page/ligne
data modify storage commerce:cp ve451 set from storage commerce:l ve
data modify storage commerce:cp vz451 set from storage commerce:l vz
data modify storage commerce:cp vc451 set from storage commerce:l vc
data modify storage commerce:cp ae451 set from storage commerce:l ae
data modify storage commerce:cp az451 set from storage commerce:l az
data modify storage commerce:cp ac451 set from storage commerce:l ac
data modify storage commerce:cp t451 set from storage commerce:l t
scoreboard players set #i c.t 448
function commerce:page/ligne
data modify storage commerce:cp ve448 set from storage commerce:l ve
data modify storage commerce:cp vz448 set from storage commerce:l vz
data modify storage commerce:cp vc448 set from storage commerce:l vc
data modify storage commerce:cp ae448 set from storage commerce:l ae
data modify storage commerce:cp az448 set from storage commerce:l az
data modify storage commerce:cp ac448 set from storage commerce:l ac
data modify storage commerce:cp t448 set from storage commerce:l t
scoreboard players set #i c.t 446
function commerce:page/ligne
data modify storage commerce:cp ve446 set from storage commerce:l ve
data modify storage commerce:cp vz446 set from storage commerce:l vz
data modify storage commerce:cp vc446 set from storage commerce:l vc
data modify storage commerce:cp ae446 set from storage commerce:l ae
data modify storage commerce:cp az446 set from storage commerce:l az
data modify storage commerce:cp ac446 set from storage commerce:l ac
data modify storage commerce:cp t446 set from storage commerce:l t
scoreboard players set #i c.t 84
function commerce:page/ligne
data modify storage commerce:cp ve84 set from storage commerce:l ve
data modify storage commerce:cp vz84 set from storage commerce:l vz
data modify storage commerce:cp vc84 set from storage commerce:l vc
data modify storage commerce:cp ae84 set from storage commerce:l ae
data modify storage commerce:cp az84 set from storage commerce:l az
data modify storage commerce:cp ac84 set from storage commerce:l ac
data modify storage commerce:cp t84 set from storage commerce:l t
scoreboard players set #i c.t 85
function commerce:page/ligne
data modify storage commerce:cp ve85 set from storage commerce:l ve
data modify storage commerce:cp vz85 set from storage commerce:l vz
data modify storage commerce:cp vc85 set from storage commerce:l vc
data modify storage commerce:cp ae85 set from storage commerce:l ae
data modify storage commerce:cp az85 set from storage commerce:l az
data modify storage commerce:cp ac85 set from storage commerce:l ac
data modify storage commerce:cp t85 set from storage commerce:l t
function commerce:page/lettre_t_5_d with storage commerce:cp
