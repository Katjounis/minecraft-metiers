function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 181
function commerce:page/ligne
data modify storage commerce:cp ve181 set from storage commerce:l ve
data modify storage commerce:cp vz181 set from storage commerce:l vz
data modify storage commerce:cp vc181 set from storage commerce:l vc
data modify storage commerce:cp ae181 set from storage commerce:l ae
data modify storage commerce:cp az181 set from storage commerce:l az
data modify storage commerce:cp ac181 set from storage commerce:l ac
data modify storage commerce:cp t181 set from storage commerce:l t
scoreboard players set #i c.t 63
function commerce:page/ligne
data modify storage commerce:cp ve63 set from storage commerce:l ve
data modify storage commerce:cp vz63 set from storage commerce:l vz
data modify storage commerce:cp vc63 set from storage commerce:l vc
data modify storage commerce:cp ae63 set from storage commerce:l ae
data modify storage commerce:cp az63 set from storage commerce:l az
data modify storage commerce:cp ac63 set from storage commerce:l ac
data modify storage commerce:cp t63 set from storage commerce:l t
scoreboard players set #i c.t 47
function commerce:page/ligne
data modify storage commerce:cp ve47 set from storage commerce:l ve
data modify storage commerce:cp vz47 set from storage commerce:l vz
data modify storage commerce:cp vc47 set from storage commerce:l vc
data modify storage commerce:cp ae47 set from storage commerce:l ae
data modify storage commerce:cp az47 set from storage commerce:l az
data modify storage commerce:cp ac47 set from storage commerce:l ac
data modify storage commerce:cp t47 set from storage commerce:l t
scoreboard players set #i c.t 46
function commerce:page/ligne
data modify storage commerce:cp ve46 set from storage commerce:l ve
data modify storage commerce:cp vz46 set from storage commerce:l vz
data modify storage commerce:cp vc46 set from storage commerce:l vc
data modify storage commerce:cp ae46 set from storage commerce:l ae
data modify storage commerce:cp az46 set from storage commerce:l az
data modify storage commerce:cp ac46 set from storage commerce:l ac
data modify storage commerce:cp t46 set from storage commerce:l t
scoreboard players set #i c.t 449
function commerce:page/ligne
data modify storage commerce:cp ve449 set from storage commerce:l ve
data modify storage commerce:cp vz449 set from storage commerce:l vz
data modify storage commerce:cp vc449 set from storage commerce:l vc
data modify storage commerce:cp ae449 set from storage commerce:l ae
data modify storage commerce:cp az449 set from storage commerce:l az
data modify storage commerce:cp ac449 set from storage commerce:l ac
data modify storage commerce:cp t449 set from storage commerce:l t
scoreboard players set #i c.t 453
function commerce:page/ligne
data modify storage commerce:cp ve453 set from storage commerce:l ve
data modify storage commerce:cp vz453 set from storage commerce:l vz
data modify storage commerce:cp vc453 set from storage commerce:l vc
data modify storage commerce:cp ae453 set from storage commerce:l ae
data modify storage commerce:cp az453 set from storage commerce:l az
data modify storage commerce:cp ac453 set from storage commerce:l ac
data modify storage commerce:cp t453 set from storage commerce:l t
scoreboard players set #i c.t 450
function commerce:page/ligne
data modify storage commerce:cp ve450 set from storage commerce:l ve
data modify storage commerce:cp vz450 set from storage commerce:l vz
data modify storage commerce:cp vc450 set from storage commerce:l vc
data modify storage commerce:cp ae450 set from storage commerce:l ae
data modify storage commerce:cp az450 set from storage commerce:l az
data modify storage commerce:cp ac450 set from storage commerce:l ac
data modify storage commerce:cp t450 set from storage commerce:l t
scoreboard players set #i c.t 448
function commerce:page/ligne
data modify storage commerce:cp ve448 set from storage commerce:l ve
data modify storage commerce:cp vz448 set from storage commerce:l vz
data modify storage commerce:cp vc448 set from storage commerce:l vc
data modify storage commerce:cp ae448 set from storage commerce:l ae
data modify storage commerce:cp az448 set from storage commerce:l az
data modify storage commerce:cp ac448 set from storage commerce:l ac
data modify storage commerce:cp t448 set from storage commerce:l t
scoreboard players set #i c.t 84
function commerce:page/ligne
data modify storage commerce:cp ve84 set from storage commerce:l ve
data modify storage commerce:cp vz84 set from storage commerce:l vz
data modify storage commerce:cp vc84 set from storage commerce:l vc
data modify storage commerce:cp ae84 set from storage commerce:l ae
data modify storage commerce:cp az84 set from storage commerce:l az
data modify storage commerce:cp ac84 set from storage commerce:l ac
data modify storage commerce:cp t84 set from storage commerce:l t
scoreboard players set #i c.t 85
function commerce:page/ligne
data modify storage commerce:cp ve85 set from storage commerce:l ve
data modify storage commerce:cp vz85 set from storage commerce:l vz
data modify storage commerce:cp vc85 set from storage commerce:l vc
data modify storage commerce:cp ae85 set from storage commerce:l ae
data modify storage commerce:cp az85 set from storage commerce:l az
data modify storage commerce:cp ac85 set from storage commerce:l ac
data modify storage commerce:cp t85 set from storage commerce:l t
function commerce:page/lettre_t_5_d with storage commerce:cp
