function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 64
function commerce:page/ligne
data modify storage commerce:cp ve64 set from storage commerce:l ve
data modify storage commerce:cp vz64 set from storage commerce:l vz
data modify storage commerce:cp vc64 set from storage commerce:l vc
data modify storage commerce:cp ae64 set from storage commerce:l ae
data modify storage commerce:cp az64 set from storage commerce:l az
data modify storage commerce:cp ac64 set from storage commerce:l ac
data modify storage commerce:cp t64 set from storage commerce:l t
scoreboard players set #i c.t 65
function commerce:page/ligne
data modify storage commerce:cp ve65 set from storage commerce:l ve
data modify storage commerce:cp vz65 set from storage commerce:l vz
data modify storage commerce:cp vc65 set from storage commerce:l vc
data modify storage commerce:cp ae65 set from storage commerce:l ae
data modify storage commerce:cp az65 set from storage commerce:l az
data modify storage commerce:cp ac65 set from storage commerce:l ac
data modify storage commerce:cp t65 set from storage commerce:l t
scoreboard players set #i c.t 66
function commerce:page/ligne
data modify storage commerce:cp ve66 set from storage commerce:l ve
data modify storage commerce:cp vz66 set from storage commerce:l vz
data modify storage commerce:cp vc66 set from storage commerce:l vc
data modify storage commerce:cp ae66 set from storage commerce:l ae
data modify storage commerce:cp az66 set from storage commerce:l az
data modify storage commerce:cp ac66 set from storage commerce:l ac
data modify storage commerce:cp t66 set from storage commerce:l t
scoreboard players set #i c.t 67
function commerce:page/ligne
data modify storage commerce:cp ve67 set from storage commerce:l ve
data modify storage commerce:cp vz67 set from storage commerce:l vz
data modify storage commerce:cp vc67 set from storage commerce:l vc
data modify storage commerce:cp ae67 set from storage commerce:l ae
data modify storage commerce:cp az67 set from storage commerce:l az
data modify storage commerce:cp ac67 set from storage commerce:l ac
data modify storage commerce:cp t67 set from storage commerce:l t
scoreboard players set #i c.t 68
function commerce:page/ligne
data modify storage commerce:cp ve68 set from storage commerce:l ve
data modify storage commerce:cp vz68 set from storage commerce:l vz
data modify storage commerce:cp vc68 set from storage commerce:l vc
data modify storage commerce:cp ae68 set from storage commerce:l ae
data modify storage commerce:cp az68 set from storage commerce:l az
data modify storage commerce:cp ac68 set from storage commerce:l ac
data modify storage commerce:cp t68 set from storage commerce:l t
scoreboard players set #i c.t 69
function commerce:page/ligne
data modify storage commerce:cp ve69 set from storage commerce:l ve
data modify storage commerce:cp vz69 set from storage commerce:l vz
data modify storage commerce:cp vc69 set from storage commerce:l vc
data modify storage commerce:cp ae69 set from storage commerce:l ae
data modify storage commerce:cp az69 set from storage commerce:l az
data modify storage commerce:cp ac69 set from storage commerce:l ac
data modify storage commerce:cp t69 set from storage commerce:l t
scoreboard players set #i c.t 70
function commerce:page/ligne
data modify storage commerce:cp ve70 set from storage commerce:l ve
data modify storage commerce:cp vz70 set from storage commerce:l vz
data modify storage commerce:cp vc70 set from storage commerce:l vc
data modify storage commerce:cp ae70 set from storage commerce:l ae
data modify storage commerce:cp az70 set from storage commerce:l az
data modify storage commerce:cp ac70 set from storage commerce:l ac
data modify storage commerce:cp t70 set from storage commerce:l t
scoreboard players set #i c.t 71
function commerce:page/ligne
data modify storage commerce:cp ve71 set from storage commerce:l ve
data modify storage commerce:cp vz71 set from storage commerce:l vz
data modify storage commerce:cp vc71 set from storage commerce:l vc
data modify storage commerce:cp ae71 set from storage commerce:l ae
data modify storage commerce:cp az71 set from storage commerce:l az
data modify storage commerce:cp ac71 set from storage commerce:l ac
data modify storage commerce:cp t71 set from storage commerce:l t
scoreboard players set #i c.t 72
function commerce:page/ligne
data modify storage commerce:cp ve72 set from storage commerce:l ve
data modify storage commerce:cp vz72 set from storage commerce:l vz
data modify storage commerce:cp vc72 set from storage commerce:l vc
data modify storage commerce:cp ae72 set from storage commerce:l ae
data modify storage commerce:cp az72 set from storage commerce:l az
data modify storage commerce:cp ac72 set from storage commerce:l ac
data modify storage commerce:cp t72 set from storage commerce:l t
scoreboard players set #i c.t 73
function commerce:page/ligne
data modify storage commerce:cp ve73 set from storage commerce:l ve
data modify storage commerce:cp vz73 set from storage commerce:l vz
data modify storage commerce:cp vc73 set from storage commerce:l vc
data modify storage commerce:cp ae73 set from storage commerce:l ae
data modify storage commerce:cp az73 set from storage commerce:l az
data modify storage commerce:cp ac73 set from storage commerce:l ac
data modify storage commerce:cp t73 set from storage commerce:l t
function commerce:page/cat_3_0_d with storage commerce:cp
