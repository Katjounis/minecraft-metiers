function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 234
function commerce:page/ligne
data modify storage commerce:cp ve234 set from storage commerce:l ve
data modify storage commerce:cp vz234 set from storage commerce:l vz
data modify storage commerce:cp vc234 set from storage commerce:l vc
data modify storage commerce:cp ae234 set from storage commerce:l ae
data modify storage commerce:cp az234 set from storage commerce:l az
data modify storage commerce:cp ac234 set from storage commerce:l ac
data modify storage commerce:cp t234 set from storage commerce:l t
scoreboard players set #i c.t 401
function commerce:page/ligne
data modify storage commerce:cp ve401 set from storage commerce:l ve
data modify storage commerce:cp vz401 set from storage commerce:l vz
data modify storage commerce:cp vc401 set from storage commerce:l vc
data modify storage commerce:cp ae401 set from storage commerce:l ae
data modify storage commerce:cp az401 set from storage commerce:l az
data modify storage commerce:cp ac401 set from storage commerce:l ac
data modify storage commerce:cp t401 set from storage commerce:l t
scoreboard players set #i c.t 320
function commerce:page/ligne
data modify storage commerce:cp ve320 set from storage commerce:l ve
data modify storage commerce:cp vz320 set from storage commerce:l vz
data modify storage commerce:cp vc320 set from storage commerce:l vc
data modify storage commerce:cp ae320 set from storage commerce:l ae
data modify storage commerce:cp az320 set from storage commerce:l az
data modify storage commerce:cp ac320 set from storage commerce:l ac
data modify storage commerce:cp t320 set from storage commerce:l t
function commerce:page/lettre_o_1_d with storage commerce:cp
