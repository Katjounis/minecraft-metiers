function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 250
function commerce:page/ligne
data modify storage commerce:cp ve250 set from storage commerce:l ve
data modify storage commerce:cp vz250 set from storage commerce:l vz
data modify storage commerce:cp vc250 set from storage commerce:l vc
data modify storage commerce:cp ae250 set from storage commerce:l ae
data modify storage commerce:cp az250 set from storage commerce:l az
data modify storage commerce:cp ac250 set from storage commerce:l ac
data modify storage commerce:cp t250 set from storage commerce:l t
scoreboard players set #i c.t 251
function commerce:page/ligne
data modify storage commerce:cp ve251 set from storage commerce:l ve
data modify storage commerce:cp vz251 set from storage commerce:l vz
data modify storage commerce:cp vc251 set from storage commerce:l vc
data modify storage commerce:cp ae251 set from storage commerce:l ae
data modify storage commerce:cp az251 set from storage commerce:l az
data modify storage commerce:cp ac251 set from storage commerce:l ac
data modify storage commerce:cp t251 set from storage commerce:l t
scoreboard players set #i c.t 252
function commerce:page/ligne
data modify storage commerce:cp ve252 set from storage commerce:l ve
data modify storage commerce:cp vz252 set from storage commerce:l vz
data modify storage commerce:cp vc252 set from storage commerce:l vc
data modify storage commerce:cp ae252 set from storage commerce:l ae
data modify storage commerce:cp az252 set from storage commerce:l az
data modify storage commerce:cp ac252 set from storage commerce:l ac
data modify storage commerce:cp t252 set from storage commerce:l t
scoreboard players set #i c.t 253
function commerce:page/ligne
data modify storage commerce:cp ve253 set from storage commerce:l ve
data modify storage commerce:cp vz253 set from storage commerce:l vz
data modify storage commerce:cp vc253 set from storage commerce:l vc
data modify storage commerce:cp ae253 set from storage commerce:l ae
data modify storage commerce:cp az253 set from storage commerce:l az
data modify storage commerce:cp ac253 set from storage commerce:l ac
data modify storage commerce:cp t253 set from storage commerce:l t
scoreboard players set #i c.t 254
function commerce:page/ligne
data modify storage commerce:cp ve254 set from storage commerce:l ve
data modify storage commerce:cp vz254 set from storage commerce:l vz
data modify storage commerce:cp vc254 set from storage commerce:l vc
data modify storage commerce:cp ae254 set from storage commerce:l ae
data modify storage commerce:cp az254 set from storage commerce:l az
data modify storage commerce:cp ac254 set from storage commerce:l ac
data modify storage commerce:cp t254 set from storage commerce:l t
scoreboard players set #i c.t 255
function commerce:page/ligne
data modify storage commerce:cp ve255 set from storage commerce:l ve
data modify storage commerce:cp vz255 set from storage commerce:l vz
data modify storage commerce:cp vc255 set from storage commerce:l vc
data modify storage commerce:cp ae255 set from storage commerce:l ae
data modify storage commerce:cp az255 set from storage commerce:l az
data modify storage commerce:cp ac255 set from storage commerce:l ac
data modify storage commerce:cp t255 set from storage commerce:l t
scoreboard players set #i c.t 256
function commerce:page/ligne
data modify storage commerce:cp ve256 set from storage commerce:l ve
data modify storage commerce:cp vz256 set from storage commerce:l vz
data modify storage commerce:cp vc256 set from storage commerce:l vc
data modify storage commerce:cp ae256 set from storage commerce:l ae
data modify storage commerce:cp az256 set from storage commerce:l az
data modify storage commerce:cp ac256 set from storage commerce:l ac
data modify storage commerce:cp t256 set from storage commerce:l t
scoreboard players set #i c.t 257
function commerce:page/ligne
data modify storage commerce:cp ve257 set from storage commerce:l ve
data modify storage commerce:cp vz257 set from storage commerce:l vz
data modify storage commerce:cp vc257 set from storage commerce:l vc
data modify storage commerce:cp ae257 set from storage commerce:l ae
data modify storage commerce:cp az257 set from storage commerce:l az
data modify storage commerce:cp ac257 set from storage commerce:l ac
data modify storage commerce:cp t257 set from storage commerce:l t
scoreboard players set #i c.t 258
function commerce:page/ligne
data modify storage commerce:cp ve258 set from storage commerce:l ve
data modify storage commerce:cp vz258 set from storage commerce:l vz
data modify storage commerce:cp vc258 set from storage commerce:l vc
data modify storage commerce:cp ae258 set from storage commerce:l ae
data modify storage commerce:cp az258 set from storage commerce:l az
data modify storage commerce:cp ac258 set from storage commerce:l ac
data modify storage commerce:cp t258 set from storage commerce:l t
scoreboard players set #i c.t 259
function commerce:page/ligne
data modify storage commerce:cp ve259 set from storage commerce:l ve
data modify storage commerce:cp vz259 set from storage commerce:l vz
data modify storage commerce:cp vc259 set from storage commerce:l vc
data modify storage commerce:cp ae259 set from storage commerce:l ae
data modify storage commerce:cp az259 set from storage commerce:l az
data modify storage commerce:cp ac259 set from storage commerce:l ac
data modify storage commerce:cp t259 set from storage commerce:l t
function commerce:page/cat_9_0_d with storage commerce:cp
