function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 222
function commerce:page/ligne
data modify storage commerce:cp ve222 set from storage commerce:l ve
data modify storage commerce:cp vz222 set from storage commerce:l vz
data modify storage commerce:cp vc222 set from storage commerce:l vc
data modify storage commerce:cp ae222 set from storage commerce:l ae
data modify storage commerce:cp az222 set from storage commerce:l az
data modify storage commerce:cp ac222 set from storage commerce:l ac
data modify storage commerce:cp t222 set from storage commerce:l t
scoreboard players set #i c.t 225
function commerce:page/ligne
data modify storage commerce:cp ve225 set from storage commerce:l ve
data modify storage commerce:cp vz225 set from storage commerce:l vz
data modify storage commerce:cp vc225 set from storage commerce:l vc
data modify storage commerce:cp ae225 set from storage commerce:l ae
data modify storage commerce:cp az225 set from storage commerce:l az
data modify storage commerce:cp ac225 set from storage commerce:l ac
data modify storage commerce:cp t225 set from storage commerce:l t
scoreboard players set #i c.t 226
function commerce:page/ligne
data modify storage commerce:cp ve226 set from storage commerce:l ve
data modify storage commerce:cp vz226 set from storage commerce:l vz
data modify storage commerce:cp vc226 set from storage commerce:l vc
data modify storage commerce:cp ae226 set from storage commerce:l ae
data modify storage commerce:cp az226 set from storage commerce:l az
data modify storage commerce:cp ac226 set from storage commerce:l ac
data modify storage commerce:cp t226 set from storage commerce:l t
scoreboard players set #i c.t 430
function commerce:page/ligne
data modify storage commerce:cp ve430 set from storage commerce:l ve
data modify storage commerce:cp vz430 set from storage commerce:l vz
data modify storage commerce:cp vc430 set from storage commerce:l vc
data modify storage commerce:cp ae430 set from storage commerce:l ae
data modify storage commerce:cp az430 set from storage commerce:l az
data modify storage commerce:cp ac430 set from storage commerce:l ac
data modify storage commerce:cp t430 set from storage commerce:l t
scoreboard players set #i c.t 232
function commerce:page/ligne
data modify storage commerce:cp ve232 set from storage commerce:l ve
data modify storage commerce:cp vz232 set from storage commerce:l vz
data modify storage commerce:cp vc232 set from storage commerce:l vc
data modify storage commerce:cp ae232 set from storage commerce:l ae
data modify storage commerce:cp az232 set from storage commerce:l az
data modify storage commerce:cp ac232 set from storage commerce:l ac
data modify storage commerce:cp t232 set from storage commerce:l t
scoreboard players set #i c.t 233
function commerce:page/ligne
data modify storage commerce:cp ve233 set from storage commerce:l ve
data modify storage commerce:cp vz233 set from storage commerce:l vz
data modify storage commerce:cp vc233 set from storage commerce:l vc
data modify storage commerce:cp ae233 set from storage commerce:l ae
data modify storage commerce:cp az233 set from storage commerce:l az
data modify storage commerce:cp ac233 set from storage commerce:l ac
data modify storage commerce:cp t233 set from storage commerce:l t
scoreboard players set #i c.t 242
function commerce:page/ligne
data modify storage commerce:cp ve242 set from storage commerce:l ve
data modify storage commerce:cp vz242 set from storage commerce:l vz
data modify storage commerce:cp vc242 set from storage commerce:l vc
data modify storage commerce:cp ae242 set from storage commerce:l ae
data modify storage commerce:cp az242 set from storage commerce:l az
data modify storage commerce:cp ac242 set from storage commerce:l ac
data modify storage commerce:cp t242 set from storage commerce:l t
scoreboard players set #i c.t 261
function commerce:page/ligne
data modify storage commerce:cp ve261 set from storage commerce:l ve
data modify storage commerce:cp vz261 set from storage commerce:l vz
data modify storage commerce:cp vc261 set from storage commerce:l vc
data modify storage commerce:cp ae261 set from storage commerce:l ae
data modify storage commerce:cp az261 set from storage commerce:l az
data modify storage commerce:cp ac261 set from storage commerce:l ac
data modify storage commerce:cp t261 set from storage commerce:l t
scoreboard players set #i c.t 316
function commerce:page/ligne
data modify storage commerce:cp ve316 set from storage commerce:l ve
data modify storage commerce:cp vz316 set from storage commerce:l vz
data modify storage commerce:cp vc316 set from storage commerce:l vc
data modify storage commerce:cp ae316 set from storage commerce:l ae
data modify storage commerce:cp az316 set from storage commerce:l az
data modify storage commerce:cp ac316 set from storage commerce:l ac
data modify storage commerce:cp t316 set from storage commerce:l t
scoreboard players set #i c.t 51
function commerce:page/ligne
data modify storage commerce:cp ve51 set from storage commerce:l ve
data modify storage commerce:cp vz51 set from storage commerce:l vz
data modify storage commerce:cp vc51 set from storage commerce:l vc
data modify storage commerce:cp ae51 set from storage commerce:l ae
data modify storage commerce:cp az51 set from storage commerce:l az
data modify storage commerce:cp ac51 set from storage commerce:l ac
data modify storage commerce:cp t51 set from storage commerce:l t
function commerce:page/lettre_b_4_d with storage commerce:cp
