function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 118
function commerce:page/ligne
data modify storage commerce:cp ve118 set from storage commerce:l ve
data modify storage commerce:cp vz118 set from storage commerce:l vz
data modify storage commerce:cp vc118 set from storage commerce:l vc
data modify storage commerce:cp ae118 set from storage commerce:l ae
data modify storage commerce:cp az118 set from storage commerce:l az
data modify storage commerce:cp ac118 set from storage commerce:l ac
data modify storage commerce:cp t118 set from storage commerce:l t
scoreboard players set #i c.t 119
function commerce:page/ligne
data modify storage commerce:cp ve119 set from storage commerce:l ve
data modify storage commerce:cp vz119 set from storage commerce:l vz
data modify storage commerce:cp vc119 set from storage commerce:l vc
data modify storage commerce:cp ae119 set from storage commerce:l ae
data modify storage commerce:cp az119 set from storage commerce:l az
data modify storage commerce:cp ac119 set from storage commerce:l ac
data modify storage commerce:cp t119 set from storage commerce:l t
scoreboard players set #i c.t 120
function commerce:page/ligne
data modify storage commerce:cp ve120 set from storage commerce:l ve
data modify storage commerce:cp vz120 set from storage commerce:l vz
data modify storage commerce:cp vc120 set from storage commerce:l vc
data modify storage commerce:cp ae120 set from storage commerce:l ae
data modify storage commerce:cp az120 set from storage commerce:l az
data modify storage commerce:cp ac120 set from storage commerce:l ac
data modify storage commerce:cp t120 set from storage commerce:l t
scoreboard players set #i c.t 121
function commerce:page/ligne
data modify storage commerce:cp ve121 set from storage commerce:l ve
data modify storage commerce:cp vz121 set from storage commerce:l vz
data modify storage commerce:cp vc121 set from storage commerce:l vc
data modify storage commerce:cp ae121 set from storage commerce:l ae
data modify storage commerce:cp az121 set from storage commerce:l az
data modify storage commerce:cp ac121 set from storage commerce:l ac
data modify storage commerce:cp t121 set from storage commerce:l t
function commerce:page/cat_4_3_d with storage commerce:cp
