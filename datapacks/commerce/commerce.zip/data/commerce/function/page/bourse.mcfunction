scoreboard players reset * c.x
scoreboard players set #m c.t 0
scoreboard players set #best c.t 0
function commerce:bourse/tv_passe
data modify storage commerce:r tv1n set value "·"
data modify storage commerce:r tv1q set value ""
execute if score #best c.t matches 1.. run function commerce:bourse/tv_retenir_1
scoreboard players set #m c.t 0
scoreboard players set #best c.t 0
function commerce:bourse/tv_passe
data modify storage commerce:r tv2n set value "·"
data modify storage commerce:r tv2q set value ""
execute if score #best c.t matches 1.. run function commerce:bourse/tv_retenir_2
scoreboard players set #m c.t 0
scoreboard players set #best c.t 0
function commerce:bourse/tv_passe
data modify storage commerce:r tv3n set value "·"
data modify storage commerce:r tv3q set value ""
execute if score #best c.t matches 1.. run function commerce:bourse/tv_retenir_3
scoreboard players reset * c.x
scoreboard players set #m c.t 0
scoreboard players set #best c.t 0
function commerce:bourse/ta_passe
data modify storage commerce:r ta1n set value "·"
data modify storage commerce:r ta1q set value ""
execute if score #best c.t matches 1.. run function commerce:bourse/ta_retenir_1
scoreboard players set #m c.t 0
scoreboard players set #best c.t 0
function commerce:bourse/ta_passe
data modify storage commerce:r ta2n set value "·"
data modify storage commerce:r ta2q set value ""
execute if score #best c.t matches 1.. run function commerce:bourse/ta_retenir_2
scoreboard players set #m c.t 0
scoreboard players set #best c.t 0
function commerce:bourse/ta_passe
data modify storage commerce:r ta3n set value "·"
data modify storage commerce:r ta3q set value ""
execute if score #best c.t matches 1.. run function commerce:bourse/ta_retenir_3
scoreboard players reset * c.x
function commerce:rang/calcul {obj:"c.tv",n:3}
data modify storage commerce:r ev set from storage commerce:g evtxt
execute if data storage commerce:r {ev:""} run data modify storage commerce:r ev set value "Pas d’évènement en cours."
function commerce:page/bourse_d with storage commerce:r
