function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 347
function commerce:page/ligne
data modify storage commerce:cp ve347 set from storage commerce:l ve
data modify storage commerce:cp vz347 set from storage commerce:l vz
data modify storage commerce:cp vc347 set from storage commerce:l vc
data modify storage commerce:cp ae347 set from storage commerce:l ae
data modify storage commerce:cp az347 set from storage commerce:l az
data modify storage commerce:cp ac347 set from storage commerce:l ac
data modify storage commerce:cp t347 set from storage commerce:l t
data modify storage commerce:cp tc347 set from storage commerce:l tc
scoreboard players set #i c.t 348
function commerce:page/ligne
data modify storage commerce:cp ve348 set from storage commerce:l ve
data modify storage commerce:cp vz348 set from storage commerce:l vz
data modify storage commerce:cp vc348 set from storage commerce:l vc
data modify storage commerce:cp ae348 set from storage commerce:l ae
data modify storage commerce:cp az348 set from storage commerce:l az
data modify storage commerce:cp ac348 set from storage commerce:l ac
data modify storage commerce:cp t348 set from storage commerce:l t
data modify storage commerce:cp tc348 set from storage commerce:l tc
scoreboard players set #i c.t 349
function commerce:page/ligne
data modify storage commerce:cp ve349 set from storage commerce:l ve
data modify storage commerce:cp vz349 set from storage commerce:l vz
data modify storage commerce:cp vc349 set from storage commerce:l vc
data modify storage commerce:cp ae349 set from storage commerce:l ae
data modify storage commerce:cp az349 set from storage commerce:l az
data modify storage commerce:cp ac349 set from storage commerce:l ac
data modify storage commerce:cp t349 set from storage commerce:l t
data modify storage commerce:cp tc349 set from storage commerce:l tc
scoreboard players set #i c.t 350
function commerce:page/ligne
data modify storage commerce:cp ve350 set from storage commerce:l ve
data modify storage commerce:cp vz350 set from storage commerce:l vz
data modify storage commerce:cp vc350 set from storage commerce:l vc
data modify storage commerce:cp ae350 set from storage commerce:l ae
data modify storage commerce:cp az350 set from storage commerce:l az
data modify storage commerce:cp ac350 set from storage commerce:l ac
data modify storage commerce:cp t350 set from storage commerce:l t
data modify storage commerce:cp tc350 set from storage commerce:l tc
scoreboard players set #i c.t 351
function commerce:page/ligne
data modify storage commerce:cp ve351 set from storage commerce:l ve
data modify storage commerce:cp vz351 set from storage commerce:l vz
data modify storage commerce:cp vc351 set from storage commerce:l vc
data modify storage commerce:cp ae351 set from storage commerce:l ae
data modify storage commerce:cp az351 set from storage commerce:l az
data modify storage commerce:cp ac351 set from storage commerce:l ac
data modify storage commerce:cp t351 set from storage commerce:l t
data modify storage commerce:cp tc351 set from storage commerce:l tc
scoreboard players set #i c.t 352
function commerce:page/ligne
data modify storage commerce:cp ve352 set from storage commerce:l ve
data modify storage commerce:cp vz352 set from storage commerce:l vz
data modify storage commerce:cp vc352 set from storage commerce:l vc
data modify storage commerce:cp ae352 set from storage commerce:l ae
data modify storage commerce:cp az352 set from storage commerce:l az
data modify storage commerce:cp ac352 set from storage commerce:l ac
data modify storage commerce:cp t352 set from storage commerce:l t
data modify storage commerce:cp tc352 set from storage commerce:l tc
scoreboard players set #i c.t 353
function commerce:page/ligne
data modify storage commerce:cp ve353 set from storage commerce:l ve
data modify storage commerce:cp vz353 set from storage commerce:l vz
data modify storage commerce:cp vc353 set from storage commerce:l vc
data modify storage commerce:cp ae353 set from storage commerce:l ae
data modify storage commerce:cp az353 set from storage commerce:l az
data modify storage commerce:cp ac353 set from storage commerce:l ac
data modify storage commerce:cp t353 set from storage commerce:l t
data modify storage commerce:cp tc353 set from storage commerce:l tc
scoreboard players set #i c.t 354
function commerce:page/ligne
data modify storage commerce:cp ve354 set from storage commerce:l ve
data modify storage commerce:cp vz354 set from storage commerce:l vz
data modify storage commerce:cp vc354 set from storage commerce:l vc
data modify storage commerce:cp ae354 set from storage commerce:l ae
data modify storage commerce:cp az354 set from storage commerce:l az
data modify storage commerce:cp ac354 set from storage commerce:l ac
data modify storage commerce:cp t354 set from storage commerce:l t
data modify storage commerce:cp tc354 set from storage commerce:l tc
scoreboard players set #i c.t 355
function commerce:page/ligne
data modify storage commerce:cp ve355 set from storage commerce:l ve
data modify storage commerce:cp vz355 set from storage commerce:l vz
data modify storage commerce:cp vc355 set from storage commerce:l vc
data modify storage commerce:cp ae355 set from storage commerce:l ae
data modify storage commerce:cp az355 set from storage commerce:l az
data modify storage commerce:cp ac355 set from storage commerce:l ac
data modify storage commerce:cp t355 set from storage commerce:l t
data modify storage commerce:cp tc355 set from storage commerce:l tc
scoreboard players set #i c.t 356
function commerce:page/ligne
data modify storage commerce:cp ve356 set from storage commerce:l ve
data modify storage commerce:cp vz356 set from storage commerce:l vz
data modify storage commerce:cp vc356 set from storage commerce:l vc
data modify storage commerce:cp ae356 set from storage commerce:l ae
data modify storage commerce:cp az356 set from storage commerce:l az
data modify storage commerce:cp ac356 set from storage commerce:l ac
data modify storage commerce:cp t356 set from storage commerce:l t
data modify storage commerce:cp tc356 set from storage commerce:l tc
scoreboard players set #i c.t 357
function commerce:page/ligne
data modify storage commerce:cp ve357 set from storage commerce:l ve
data modify storage commerce:cp vz357 set from storage commerce:l vz
data modify storage commerce:cp vc357 set from storage commerce:l vc
data modify storage commerce:cp ae357 set from storage commerce:l ae
data modify storage commerce:cp az357 set from storage commerce:l az
data modify storage commerce:cp ac357 set from storage commerce:l ac
data modify storage commerce:cp t357 set from storage commerce:l t
data modify storage commerce:cp tc357 set from storage commerce:l tc
scoreboard players set #i c.t 358
function commerce:page/ligne
data modify storage commerce:cp ve358 set from storage commerce:l ve
data modify storage commerce:cp vz358 set from storage commerce:l vz
data modify storage commerce:cp vc358 set from storage commerce:l vc
data modify storage commerce:cp ae358 set from storage commerce:l ae
data modify storage commerce:cp az358 set from storage commerce:l az
data modify storage commerce:cp ac358 set from storage commerce:l ac
data modify storage commerce:cp t358 set from storage commerce:l t
data modify storage commerce:cp tc358 set from storage commerce:l tc
scoreboard players set #i c.t 359
function commerce:page/ligne
data modify storage commerce:cp ve359 set from storage commerce:l ve
data modify storage commerce:cp vz359 set from storage commerce:l vz
data modify storage commerce:cp vc359 set from storage commerce:l vc
data modify storage commerce:cp ae359 set from storage commerce:l ae
data modify storage commerce:cp az359 set from storage commerce:l az
data modify storage commerce:cp ac359 set from storage commerce:l ac
data modify storage commerce:cp t359 set from storage commerce:l t
data modify storage commerce:cp tc359 set from storage commerce:l tc
scoreboard players set #i c.t 360
function commerce:page/ligne
data modify storage commerce:cp ve360 set from storage commerce:l ve
data modify storage commerce:cp vz360 set from storage commerce:l vz
data modify storage commerce:cp vc360 set from storage commerce:l vc
data modify storage commerce:cp ae360 set from storage commerce:l ae
data modify storage commerce:cp az360 set from storage commerce:l az
data modify storage commerce:cp ac360 set from storage commerce:l ac
data modify storage commerce:cp t360 set from storage commerce:l t
data modify storage commerce:cp tc360 set from storage commerce:l tc
function commerce:page/cat_13_d with storage commerce:cp
