function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 361
function commerce:page/ligne
data modify storage commerce:cp ve361 set from storage commerce:l ve
data modify storage commerce:cp vz361 set from storage commerce:l vz
data modify storage commerce:cp vc361 set from storage commerce:l vc
data modify storage commerce:cp ae361 set from storage commerce:l ae
data modify storage commerce:cp az361 set from storage commerce:l az
data modify storage commerce:cp ac361 set from storage commerce:l ac
data modify storage commerce:cp t361 set from storage commerce:l t
scoreboard players set #i c.t 362
function commerce:page/ligne
data modify storage commerce:cp ve362 set from storage commerce:l ve
data modify storage commerce:cp vz362 set from storage commerce:l vz
data modify storage commerce:cp vc362 set from storage commerce:l vc
data modify storage commerce:cp ae362 set from storage commerce:l ae
data modify storage commerce:cp az362 set from storage commerce:l az
data modify storage commerce:cp ac362 set from storage commerce:l ac
data modify storage commerce:cp t362 set from storage commerce:l t
scoreboard players set #i c.t 363
function commerce:page/ligne
data modify storage commerce:cp ve363 set from storage commerce:l ve
data modify storage commerce:cp vz363 set from storage commerce:l vz
data modify storage commerce:cp vc363 set from storage commerce:l vc
data modify storage commerce:cp ae363 set from storage commerce:l ae
data modify storage commerce:cp az363 set from storage commerce:l az
data modify storage commerce:cp ac363 set from storage commerce:l ac
data modify storage commerce:cp t363 set from storage commerce:l t
scoreboard players set #i c.t 364
function commerce:page/ligne
data modify storage commerce:cp ve364 set from storage commerce:l ve
data modify storage commerce:cp vz364 set from storage commerce:l vz
data modify storage commerce:cp vc364 set from storage commerce:l vc
data modify storage commerce:cp ae364 set from storage commerce:l ae
data modify storage commerce:cp az364 set from storage commerce:l az
data modify storage commerce:cp ac364 set from storage commerce:l ac
data modify storage commerce:cp t364 set from storage commerce:l t
scoreboard players set #i c.t 365
function commerce:page/ligne
data modify storage commerce:cp ve365 set from storage commerce:l ve
data modify storage commerce:cp vz365 set from storage commerce:l vz
data modify storage commerce:cp vc365 set from storage commerce:l vc
data modify storage commerce:cp ae365 set from storage commerce:l ae
data modify storage commerce:cp az365 set from storage commerce:l az
data modify storage commerce:cp ac365 set from storage commerce:l ac
data modify storage commerce:cp t365 set from storage commerce:l t
scoreboard players set #i c.t 366
function commerce:page/ligne
data modify storage commerce:cp ve366 set from storage commerce:l ve
data modify storage commerce:cp vz366 set from storage commerce:l vz
data modify storage commerce:cp vc366 set from storage commerce:l vc
data modify storage commerce:cp ae366 set from storage commerce:l ae
data modify storage commerce:cp az366 set from storage commerce:l az
data modify storage commerce:cp ac366 set from storage commerce:l ac
data modify storage commerce:cp t366 set from storage commerce:l t
scoreboard players set #i c.t 367
function commerce:page/ligne
data modify storage commerce:cp ve367 set from storage commerce:l ve
data modify storage commerce:cp vz367 set from storage commerce:l vz
data modify storage commerce:cp vc367 set from storage commerce:l vc
data modify storage commerce:cp ae367 set from storage commerce:l ae
data modify storage commerce:cp az367 set from storage commerce:l az
data modify storage commerce:cp ac367 set from storage commerce:l ac
data modify storage commerce:cp t367 set from storage commerce:l t
scoreboard players set #i c.t 368
function commerce:page/ligne
data modify storage commerce:cp ve368 set from storage commerce:l ve
data modify storage commerce:cp vz368 set from storage commerce:l vz
data modify storage commerce:cp vc368 set from storage commerce:l vc
data modify storage commerce:cp ae368 set from storage commerce:l ae
data modify storage commerce:cp az368 set from storage commerce:l az
data modify storage commerce:cp ac368 set from storage commerce:l ac
data modify storage commerce:cp t368 set from storage commerce:l t
scoreboard players set #i c.t 369
function commerce:page/ligne
data modify storage commerce:cp ve369 set from storage commerce:l ve
data modify storage commerce:cp vz369 set from storage commerce:l vz
data modify storage commerce:cp vc369 set from storage commerce:l vc
data modify storage commerce:cp ae369 set from storage commerce:l ae
data modify storage commerce:cp az369 set from storage commerce:l az
data modify storage commerce:cp ac369 set from storage commerce:l ac
data modify storage commerce:cp t369 set from storage commerce:l t
scoreboard players set #i c.t 370
function commerce:page/ligne
data modify storage commerce:cp ve370 set from storage commerce:l ve
data modify storage commerce:cp vz370 set from storage commerce:l vz
data modify storage commerce:cp vc370 set from storage commerce:l vc
data modify storage commerce:cp ae370 set from storage commerce:l ae
data modify storage commerce:cp az370 set from storage commerce:l az
data modify storage commerce:cp ac370 set from storage commerce:l ac
data modify storage commerce:cp t370 set from storage commerce:l t
function commerce:page/cat_14_0_d with storage commerce:cp
