function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 241
function commerce:page/ligne
data modify storage commerce:cp ve241 set from storage commerce:l ve
data modify storage commerce:cp vz241 set from storage commerce:l vz
data modify storage commerce:cp vc241 set from storage commerce:l vc
data modify storage commerce:cp ae241 set from storage commerce:l ae
data modify storage commerce:cp az241 set from storage commerce:l az
data modify storage commerce:cp ac241 set from storage commerce:l ac
data modify storage commerce:cp t241 set from storage commerce:l t
scoreboard players set #i c.t 242
function commerce:page/ligne
data modify storage commerce:cp ve242 set from storage commerce:l ve
data modify storage commerce:cp vz242 set from storage commerce:l vz
data modify storage commerce:cp vc242 set from storage commerce:l vc
data modify storage commerce:cp ae242 set from storage commerce:l ae
data modify storage commerce:cp az242 set from storage commerce:l az
data modify storage commerce:cp ac242 set from storage commerce:l ac
data modify storage commerce:cp t242 set from storage commerce:l t
scoreboard players set #i c.t 243
function commerce:page/ligne
data modify storage commerce:cp ve243 set from storage commerce:l ve
data modify storage commerce:cp vz243 set from storage commerce:l vz
data modify storage commerce:cp vc243 set from storage commerce:l vc
data modify storage commerce:cp ae243 set from storage commerce:l ae
data modify storage commerce:cp az243 set from storage commerce:l az
data modify storage commerce:cp ac243 set from storage commerce:l ac
data modify storage commerce:cp t243 set from storage commerce:l t
scoreboard players set #i c.t 244
function commerce:page/ligne
data modify storage commerce:cp ve244 set from storage commerce:l ve
data modify storage commerce:cp vz244 set from storage commerce:l vz
data modify storage commerce:cp vc244 set from storage commerce:l vc
data modify storage commerce:cp ae244 set from storage commerce:l ae
data modify storage commerce:cp az244 set from storage commerce:l az
data modify storage commerce:cp ac244 set from storage commerce:l ac
data modify storage commerce:cp t244 set from storage commerce:l t
scoreboard players set #i c.t 245
function commerce:page/ligne
data modify storage commerce:cp ve245 set from storage commerce:l ve
data modify storage commerce:cp vz245 set from storage commerce:l vz
data modify storage commerce:cp vc245 set from storage commerce:l vc
data modify storage commerce:cp ae245 set from storage commerce:l ae
data modify storage commerce:cp az245 set from storage commerce:l az
data modify storage commerce:cp ac245 set from storage commerce:l ac
data modify storage commerce:cp t245 set from storage commerce:l t
scoreboard players set #i c.t 246
function commerce:page/ligne
data modify storage commerce:cp ve246 set from storage commerce:l ve
data modify storage commerce:cp vz246 set from storage commerce:l vz
data modify storage commerce:cp vc246 set from storage commerce:l vc
data modify storage commerce:cp ae246 set from storage commerce:l ae
data modify storage commerce:cp az246 set from storage commerce:l az
data modify storage commerce:cp ac246 set from storage commerce:l ac
data modify storage commerce:cp t246 set from storage commerce:l t
scoreboard players set #i c.t 247
function commerce:page/ligne
data modify storage commerce:cp ve247 set from storage commerce:l ve
data modify storage commerce:cp vz247 set from storage commerce:l vz
data modify storage commerce:cp vc247 set from storage commerce:l vc
data modify storage commerce:cp ae247 set from storage commerce:l ae
data modify storage commerce:cp az247 set from storage commerce:l az
data modify storage commerce:cp ac247 set from storage commerce:l ac
data modify storage commerce:cp t247 set from storage commerce:l t
scoreboard players set #i c.t 248
function commerce:page/ligne
data modify storage commerce:cp ve248 set from storage commerce:l ve
data modify storage commerce:cp vz248 set from storage commerce:l vz
data modify storage commerce:cp vc248 set from storage commerce:l vc
data modify storage commerce:cp ae248 set from storage commerce:l ae
data modify storage commerce:cp az248 set from storage commerce:l az
data modify storage commerce:cp ac248 set from storage commerce:l ac
data modify storage commerce:cp t248 set from storage commerce:l t
scoreboard players set #i c.t 249
function commerce:page/ligne
data modify storage commerce:cp ve249 set from storage commerce:l ve
data modify storage commerce:cp vz249 set from storage commerce:l vz
data modify storage commerce:cp vc249 set from storage commerce:l vc
data modify storage commerce:cp ae249 set from storage commerce:l ae
data modify storage commerce:cp az249 set from storage commerce:l az
data modify storage commerce:cp ac249 set from storage commerce:l ac
data modify storage commerce:cp t249 set from storage commerce:l t
function commerce:page/cat_8_2_d with storage commerce:cp
