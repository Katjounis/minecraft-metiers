function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 310
function commerce:page/ligne
data modify storage commerce:cp ve310 set from storage commerce:l ve
data modify storage commerce:cp vz310 set from storage commerce:l vz
data modify storage commerce:cp vc310 set from storage commerce:l vc
data modify storage commerce:cp ae310 set from storage commerce:l ae
data modify storage commerce:cp az310 set from storage commerce:l az
data modify storage commerce:cp ac310 set from storage commerce:l ac
data modify storage commerce:cp t310 set from storage commerce:l t
scoreboard players set #i c.t 354
function commerce:page/ligne
data modify storage commerce:cp ve354 set from storage commerce:l ve
data modify storage commerce:cp vz354 set from storage commerce:l vz
data modify storage commerce:cp vc354 set from storage commerce:l vc
data modify storage commerce:cp ae354 set from storage commerce:l ae
data modify storage commerce:cp az354 set from storage commerce:l az
data modify storage commerce:cp ac354 set from storage commerce:l ac
data modify storage commerce:cp t354 set from storage commerce:l t
scoreboard players set #i c.t 445
function commerce:page/ligne
data modify storage commerce:cp ve445 set from storage commerce:l ve
data modify storage commerce:cp vz445 set from storage commerce:l vz
data modify storage commerce:cp vc445 set from storage commerce:l vc
data modify storage commerce:cp ae445 set from storage commerce:l ae
data modify storage commerce:cp az445 set from storage commerce:l az
data modify storage commerce:cp ac445 set from storage commerce:l ac
data modify storage commerce:cp t445 set from storage commerce:l t
scoreboard players set #i c.t 444
function commerce:page/ligne
data modify storage commerce:cp ve444 set from storage commerce:l ve
data modify storage commerce:cp vz444 set from storage commerce:l vz
data modify storage commerce:cp vc444 set from storage commerce:l vc
data modify storage commerce:cp ae444 set from storage commerce:l ae
data modify storage commerce:cp az444 set from storage commerce:l az
data modify storage commerce:cp ac444 set from storage commerce:l ac
data modify storage commerce:cp t444 set from storage commerce:l t
scoreboard players set #i c.t 262
function commerce:page/ligne
data modify storage commerce:cp ve262 set from storage commerce:l ve
data modify storage commerce:cp vz262 set from storage commerce:l vz
data modify storage commerce:cp vc262 set from storage commerce:l vc
data modify storage commerce:cp ae262 set from storage commerce:l ae
data modify storage commerce:cp az262 set from storage commerce:l az
data modify storage commerce:cp ac262 set from storage commerce:l ac
data modify storage commerce:cp t262 set from storage commerce:l t
scoreboard players set #i c.t 341
function commerce:page/ligne
data modify storage commerce:cp ve341 set from storage commerce:l ve
data modify storage commerce:cp vz341 set from storage commerce:l vz
data modify storage commerce:cp vc341 set from storage commerce:l vc
data modify storage commerce:cp ae341 set from storage commerce:l ae
data modify storage commerce:cp az341 set from storage commerce:l az
data modify storage commerce:cp ac341 set from storage commerce:l ac
data modify storage commerce:cp t341 set from storage commerce:l t
scoreboard players set #i c.t 302
function commerce:page/ligne
data modify storage commerce:cp ve302 set from storage commerce:l ve
data modify storage commerce:cp vz302 set from storage commerce:l vz
data modify storage commerce:cp vc302 set from storage commerce:l vc
data modify storage commerce:cp ae302 set from storage commerce:l ae
data modify storage commerce:cp az302 set from storage commerce:l az
data modify storage commerce:cp ac302 set from storage commerce:l ac
data modify storage commerce:cp t302 set from storage commerce:l t
scoreboard players set #i c.t 223
function commerce:page/ligne
data modify storage commerce:cp ve223 set from storage commerce:l ve
data modify storage commerce:cp vz223 set from storage commerce:l vz
data modify storage commerce:cp vc223 set from storage commerce:l vc
data modify storage commerce:cp ae223 set from storage commerce:l ae
data modify storage commerce:cp az223 set from storage commerce:l az
data modify storage commerce:cp ac223 set from storage commerce:l ac
data modify storage commerce:cp t223 set from storage commerce:l t
scoreboard players set #i c.t 227
function commerce:page/ligne
data modify storage commerce:cp ve227 set from storage commerce:l ve
data modify storage commerce:cp vz227 set from storage commerce:l vz
data modify storage commerce:cp vc227 set from storage commerce:l vc
data modify storage commerce:cp ae227 set from storage commerce:l ae
data modify storage commerce:cp az227 set from storage commerce:l az
data modify storage commerce:cp ac227 set from storage commerce:l ac
data modify storage commerce:cp t227 set from storage commerce:l t
function commerce:page/lettre_c_3_d with storage commerce:cp
