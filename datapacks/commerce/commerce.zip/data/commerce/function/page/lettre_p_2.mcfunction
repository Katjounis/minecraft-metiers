function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 380
function commerce:page/ligne
data modify storage commerce:cp ve380 set from storage commerce:l ve
data modify storage commerce:cp vz380 set from storage commerce:l vz
data modify storage commerce:cp vc380 set from storage commerce:l vc
data modify storage commerce:cp ae380 set from storage commerce:l ae
data modify storage commerce:cp az380 set from storage commerce:l az
data modify storage commerce:cp ac380 set from storage commerce:l ac
data modify storage commerce:cp t380 set from storage commerce:l t
scoreboard players set #i c.t 416
function commerce:page/ligne
data modify storage commerce:cp ve416 set from storage commerce:l ve
data modify storage commerce:cp vz416 set from storage commerce:l vz
data modify storage commerce:cp vc416 set from storage commerce:l vc
data modify storage commerce:cp ae416 set from storage commerce:l ae
data modify storage commerce:cp az416 set from storage commerce:l az
data modify storage commerce:cp ac416 set from storage commerce:l ac
data modify storage commerce:cp t416 set from storage commerce:l t
scoreboard players set #i c.t 117
function commerce:page/ligne
data modify storage commerce:cp ve117 set from storage commerce:l ve
data modify storage commerce:cp vz117 set from storage commerce:l vz
data modify storage commerce:cp vc117 set from storage commerce:l vc
data modify storage commerce:cp ae117 set from storage commerce:l ae
data modify storage commerce:cp az117 set from storage commerce:l az
data modify storage commerce:cp ac117 set from storage commerce:l ac
data modify storage commerce:cp t117 set from storage commerce:l t
scoreboard players set #i c.t 115
function commerce:page/ligne
data modify storage commerce:cp ve115 set from storage commerce:l ve
data modify storage commerce:cp vz115 set from storage commerce:l vz
data modify storage commerce:cp vc115 set from storage commerce:l vc
data modify storage commerce:cp ae115 set from storage commerce:l ae
data modify storage commerce:cp az115 set from storage commerce:l az
data modify storage commerce:cp ac115 set from storage commerce:l ac
data modify storage commerce:cp t115 set from storage commerce:l t
scoreboard players set #i c.t 119
function commerce:page/ligne
data modify storage commerce:cp ve119 set from storage commerce:l ve
data modify storage commerce:cp vz119 set from storage commerce:l vz
data modify storage commerce:cp vc119 set from storage commerce:l vc
data modify storage commerce:cp ae119 set from storage commerce:l ae
data modify storage commerce:cp az119 set from storage commerce:l az
data modify storage commerce:cp ac119 set from storage commerce:l ac
data modify storage commerce:cp t119 set from storage commerce:l t
scoreboard players set #i c.t 94
function commerce:page/ligne
data modify storage commerce:cp ve94 set from storage commerce:l ve
data modify storage commerce:cp vz94 set from storage commerce:l vz
data modify storage commerce:cp vc94 set from storage commerce:l vc
data modify storage commerce:cp ae94 set from storage commerce:l ae
data modify storage commerce:cp az94 set from storage commerce:l az
data modify storage commerce:cp ac94 set from storage commerce:l ac
data modify storage commerce:cp t94 set from storage commerce:l t
scoreboard players set #i c.t 109
function commerce:page/ligne
data modify storage commerce:cp ve109 set from storage commerce:l ve
data modify storage commerce:cp vz109 set from storage commerce:l vz
data modify storage commerce:cp vc109 set from storage commerce:l vc
data modify storage commerce:cp ae109 set from storage commerce:l ae
data modify storage commerce:cp az109 set from storage commerce:l az
data modify storage commerce:cp ac109 set from storage commerce:l ac
data modify storage commerce:cp t109 set from storage commerce:l t
scoreboard players set #i c.t 88
function commerce:page/ligne
data modify storage commerce:cp ve88 set from storage commerce:l ve
data modify storage commerce:cp vz88 set from storage commerce:l vz
data modify storage commerce:cp vc88 set from storage commerce:l vc
data modify storage commerce:cp ae88 set from storage commerce:l ae
data modify storage commerce:cp az88 set from storage commerce:l az
data modify storage commerce:cp ac88 set from storage commerce:l ac
data modify storage commerce:cp t88 set from storage commerce:l t
scoreboard players set #i c.t 103
function commerce:page/ligne
data modify storage commerce:cp ve103 set from storage commerce:l ve
data modify storage commerce:cp vz103 set from storage commerce:l vz
data modify storage commerce:cp vc103 set from storage commerce:l vc
data modify storage commerce:cp ae103 set from storage commerce:l ae
data modify storage commerce:cp az103 set from storage commerce:l az
data modify storage commerce:cp ac103 set from storage commerce:l ac
data modify storage commerce:cp t103 set from storage commerce:l t
scoreboard players set #i c.t 112
function commerce:page/ligne
data modify storage commerce:cp ve112 set from storage commerce:l ve
data modify storage commerce:cp vz112 set from storage commerce:l vz
data modify storage commerce:cp vc112 set from storage commerce:l vc
data modify storage commerce:cp ae112 set from storage commerce:l ae
data modify storage commerce:cp az112 set from storage commerce:l az
data modify storage commerce:cp ac112 set from storage commerce:l ac
data modify storage commerce:cp t112 set from storage commerce:l t
function commerce:page/lettre_p_2_d with storage commerce:cp
