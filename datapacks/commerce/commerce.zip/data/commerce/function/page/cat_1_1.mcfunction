function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 11
function commerce:page/ligne
data modify storage commerce:cp ve11 set from storage commerce:l ve
data modify storage commerce:cp vz11 set from storage commerce:l vz
data modify storage commerce:cp vc11 set from storage commerce:l vc
data modify storage commerce:cp ae11 set from storage commerce:l ae
data modify storage commerce:cp az11 set from storage commerce:l az
data modify storage commerce:cp ac11 set from storage commerce:l ac
data modify storage commerce:cp t11 set from storage commerce:l t
scoreboard players set #i c.t 12
function commerce:page/ligne
data modify storage commerce:cp ve12 set from storage commerce:l ve
data modify storage commerce:cp vz12 set from storage commerce:l vz
data modify storage commerce:cp vc12 set from storage commerce:l vc
data modify storage commerce:cp ae12 set from storage commerce:l ae
data modify storage commerce:cp az12 set from storage commerce:l az
data modify storage commerce:cp ac12 set from storage commerce:l ac
data modify storage commerce:cp t12 set from storage commerce:l t
scoreboard players set #i c.t 13
function commerce:page/ligne
data modify storage commerce:cp ve13 set from storage commerce:l ve
data modify storage commerce:cp vz13 set from storage commerce:l vz
data modify storage commerce:cp vc13 set from storage commerce:l vc
data modify storage commerce:cp ae13 set from storage commerce:l ae
data modify storage commerce:cp az13 set from storage commerce:l az
data modify storage commerce:cp ac13 set from storage commerce:l ac
data modify storage commerce:cp t13 set from storage commerce:l t
scoreboard players set #i c.t 14
function commerce:page/ligne
data modify storage commerce:cp ve14 set from storage commerce:l ve
data modify storage commerce:cp vz14 set from storage commerce:l vz
data modify storage commerce:cp vc14 set from storage commerce:l vc
data modify storage commerce:cp ae14 set from storage commerce:l ae
data modify storage commerce:cp az14 set from storage commerce:l az
data modify storage commerce:cp ac14 set from storage commerce:l ac
data modify storage commerce:cp t14 set from storage commerce:l t
scoreboard players set #i c.t 15
function commerce:page/ligne
data modify storage commerce:cp ve15 set from storage commerce:l ve
data modify storage commerce:cp vz15 set from storage commerce:l vz
data modify storage commerce:cp vc15 set from storage commerce:l vc
data modify storage commerce:cp ae15 set from storage commerce:l ae
data modify storage commerce:cp az15 set from storage commerce:l az
data modify storage commerce:cp ac15 set from storage commerce:l ac
data modify storage commerce:cp t15 set from storage commerce:l t
scoreboard players set #i c.t 16
function commerce:page/ligne
data modify storage commerce:cp ve16 set from storage commerce:l ve
data modify storage commerce:cp vz16 set from storage commerce:l vz
data modify storage commerce:cp vc16 set from storage commerce:l vc
data modify storage commerce:cp ae16 set from storage commerce:l ae
data modify storage commerce:cp az16 set from storage commerce:l az
data modify storage commerce:cp ac16 set from storage commerce:l ac
data modify storage commerce:cp t16 set from storage commerce:l t
scoreboard players set #i c.t 17
function commerce:page/ligne
data modify storage commerce:cp ve17 set from storage commerce:l ve
data modify storage commerce:cp vz17 set from storage commerce:l vz
data modify storage commerce:cp vc17 set from storage commerce:l vc
data modify storage commerce:cp ae17 set from storage commerce:l ae
data modify storage commerce:cp az17 set from storage commerce:l az
data modify storage commerce:cp ac17 set from storage commerce:l ac
data modify storage commerce:cp t17 set from storage commerce:l t
scoreboard players set #i c.t 18
function commerce:page/ligne
data modify storage commerce:cp ve18 set from storage commerce:l ve
data modify storage commerce:cp vz18 set from storage commerce:l vz
data modify storage commerce:cp vc18 set from storage commerce:l vc
data modify storage commerce:cp ae18 set from storage commerce:l ae
data modify storage commerce:cp az18 set from storage commerce:l az
data modify storage commerce:cp ac18 set from storage commerce:l ac
data modify storage commerce:cp t18 set from storage commerce:l t
scoreboard players set #i c.t 19
function commerce:page/ligne
data modify storage commerce:cp ve19 set from storage commerce:l ve
data modify storage commerce:cp vz19 set from storage commerce:l vz
data modify storage commerce:cp vc19 set from storage commerce:l vc
data modify storage commerce:cp ae19 set from storage commerce:l ae
data modify storage commerce:cp az19 set from storage commerce:l az
data modify storage commerce:cp ac19 set from storage commerce:l ac
data modify storage commerce:cp t19 set from storage commerce:l t
scoreboard players set #i c.t 20
function commerce:page/ligne
data modify storage commerce:cp ve20 set from storage commerce:l ve
data modify storage commerce:cp vz20 set from storage commerce:l vz
data modify storage commerce:cp vc20 set from storage commerce:l vc
data modify storage commerce:cp ae20 set from storage commerce:l ae
data modify storage commerce:cp az20 set from storage commerce:l az
data modify storage commerce:cp ac20 set from storage commerce:l ac
data modify storage commerce:cp t20 set from storage commerce:l t
function commerce:page/cat_1_1_d with storage commerce:cp
