function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 435
function commerce:page/ligne
data modify storage commerce:cp ve435 set from storage commerce:l ve
data modify storage commerce:cp vz435 set from storage commerce:l vz
data modify storage commerce:cp vc435 set from storage commerce:l vc
data modify storage commerce:cp ae435 set from storage commerce:l ae
data modify storage commerce:cp az435 set from storage commerce:l az
data modify storage commerce:cp ac435 set from storage commerce:l ac
data modify storage commerce:cp t435 set from storage commerce:l t
scoreboard players set #i c.t 431
function commerce:page/ligne
data modify storage commerce:cp ve431 set from storage commerce:l ve
data modify storage commerce:cp vz431 set from storage commerce:l vz
data modify storage commerce:cp vc431 set from storage commerce:l vc
data modify storage commerce:cp ae431 set from storage commerce:l ae
data modify storage commerce:cp az431 set from storage commerce:l az
data modify storage commerce:cp ac431 set from storage commerce:l ac
data modify storage commerce:cp t431 set from storage commerce:l t
scoreboard players set #i c.t 11
function commerce:page/ligne
data modify storage commerce:cp ve11 set from storage commerce:l ve
data modify storage commerce:cp vz11 set from storage commerce:l vz
data modify storage commerce:cp vc11 set from storage commerce:l vc
data modify storage commerce:cp ae11 set from storage commerce:l ae
data modify storage commerce:cp az11 set from storage commerce:l az
data modify storage commerce:cp ac11 set from storage commerce:l ac
data modify storage commerce:cp t11 set from storage commerce:l t
scoreboard players set #i c.t 12
function commerce:page/ligne
data modify storage commerce:cp ve12 set from storage commerce:l ve
data modify storage commerce:cp vz12 set from storage commerce:l vz
data modify storage commerce:cp vc12 set from storage commerce:l vc
data modify storage commerce:cp ae12 set from storage commerce:l ae
data modify storage commerce:cp az12 set from storage commerce:l az
data modify storage commerce:cp ac12 set from storage commerce:l ac
data modify storage commerce:cp t12 set from storage commerce:l t
scoreboard players set #i c.t 473
function commerce:page/ligne
data modify storage commerce:cp ve473 set from storage commerce:l ve
data modify storage commerce:cp vz473 set from storage commerce:l vz
data modify storage commerce:cp vc473 set from storage commerce:l vc
data modify storage commerce:cp ae473 set from storage commerce:l ae
data modify storage commerce:cp az473 set from storage commerce:l az
data modify storage commerce:cp ac473 set from storage commerce:l ac
data modify storage commerce:cp t473 set from storage commerce:l t
scoreboard players set #i c.t 472
function commerce:page/ligne
data modify storage commerce:cp ve472 set from storage commerce:l ve
data modify storage commerce:cp vz472 set from storage commerce:l vz
data modify storage commerce:cp vc472 set from storage commerce:l vc
data modify storage commerce:cp ae472 set from storage commerce:l ae
data modify storage commerce:cp az472 set from storage commerce:l az
data modify storage commerce:cp ac472 set from storage commerce:l ac
data modify storage commerce:cp t472 set from storage commerce:l t
scoreboard players set #i c.t 474
function commerce:page/ligne
data modify storage commerce:cp ve474 set from storage commerce:l ve
data modify storage commerce:cp vz474 set from storage commerce:l vz
data modify storage commerce:cp vc474 set from storage commerce:l vc
data modify storage commerce:cp ae474 set from storage commerce:l ae
data modify storage commerce:cp az474 set from storage commerce:l az
data modify storage commerce:cp ac474 set from storage commerce:l ac
data modify storage commerce:cp t474 set from storage commerce:l t
scoreboard players set #i c.t 475
function commerce:page/ligne
data modify storage commerce:cp ve475 set from storage commerce:l ve
data modify storage commerce:cp vz475 set from storage commerce:l vz
data modify storage commerce:cp vc475 set from storage commerce:l vc
data modify storage commerce:cp ae475 set from storage commerce:l ae
data modify storage commerce:cp az475 set from storage commerce:l az
data modify storage commerce:cp ac475 set from storage commerce:l ac
data modify storage commerce:cp t475 set from storage commerce:l t
scoreboard players set #i c.t 476
function commerce:page/ligne
data modify storage commerce:cp ve476 set from storage commerce:l ve
data modify storage commerce:cp vz476 set from storage commerce:l vz
data modify storage commerce:cp vc476 set from storage commerce:l vc
data modify storage commerce:cp ae476 set from storage commerce:l ae
data modify storage commerce:cp az476 set from storage commerce:l az
data modify storage commerce:cp ac476 set from storage commerce:l ac
data modify storage commerce:cp t476 set from storage commerce:l t
scoreboard players set #i c.t 477
function commerce:page/ligne
data modify storage commerce:cp ve477 set from storage commerce:l ve
data modify storage commerce:cp vz477 set from storage commerce:l vz
data modify storage commerce:cp vc477 set from storage commerce:l vc
data modify storage commerce:cp ae477 set from storage commerce:l ae
data modify storage commerce:cp az477 set from storage commerce:l az
data modify storage commerce:cp ac477 set from storage commerce:l ac
data modify storage commerce:cp t477 set from storage commerce:l t
function commerce:page/lettre_d_0_d with storage commerce:cp
