function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 433
function commerce:page/ligne
data modify storage commerce:cp ve433 set from storage commerce:l ve
data modify storage commerce:cp vz433 set from storage commerce:l vz
data modify storage commerce:cp vc433 set from storage commerce:l vc
data modify storage commerce:cp ae433 set from storage commerce:l ae
data modify storage commerce:cp az433 set from storage commerce:l az
data modify storage commerce:cp ac433 set from storage commerce:l ac
data modify storage commerce:cp t433 set from storage commerce:l t
scoreboard players set #i c.t 429
function commerce:page/ligne
data modify storage commerce:cp ve429 set from storage commerce:l ve
data modify storage commerce:cp vz429 set from storage commerce:l vz
data modify storage commerce:cp vc429 set from storage commerce:l vc
data modify storage commerce:cp ae429 set from storage commerce:l ae
data modify storage commerce:cp az429 set from storage commerce:l az
data modify storage commerce:cp ac429 set from storage commerce:l ac
data modify storage commerce:cp t429 set from storage commerce:l t
scoreboard players set #i c.t 11
function commerce:page/ligne
data modify storage commerce:cp ve11 set from storage commerce:l ve
data modify storage commerce:cp vz11 set from storage commerce:l vz
data modify storage commerce:cp vc11 set from storage commerce:l vc
data modify storage commerce:cp ae11 set from storage commerce:l ae
data modify storage commerce:cp az11 set from storage commerce:l az
data modify storage commerce:cp ac11 set from storage commerce:l ac
data modify storage commerce:cp t11 set from storage commerce:l t
scoreboard players set #i c.t 12
function commerce:page/ligne
data modify storage commerce:cp ve12 set from storage commerce:l ve
data modify storage commerce:cp vz12 set from storage commerce:l vz
data modify storage commerce:cp vc12 set from storage commerce:l vc
data modify storage commerce:cp ae12 set from storage commerce:l ae
data modify storage commerce:cp az12 set from storage commerce:l az
data modify storage commerce:cp ac12 set from storage commerce:l ac
data modify storage commerce:cp t12 set from storage commerce:l t
scoreboard players set #i c.t 466
function commerce:page/ligne
data modify storage commerce:cp ve466 set from storage commerce:l ve
data modify storage commerce:cp vz466 set from storage commerce:l vz
data modify storage commerce:cp vc466 set from storage commerce:l vc
data modify storage commerce:cp ae466 set from storage commerce:l ae
data modify storage commerce:cp az466 set from storage commerce:l az
data modify storage commerce:cp ac466 set from storage commerce:l ac
data modify storage commerce:cp t466 set from storage commerce:l t
scoreboard players set #i c.t 465
function commerce:page/ligne
data modify storage commerce:cp ve465 set from storage commerce:l ve
data modify storage commerce:cp vz465 set from storage commerce:l vz
data modify storage commerce:cp vc465 set from storage commerce:l vc
data modify storage commerce:cp ae465 set from storage commerce:l ae
data modify storage commerce:cp az465 set from storage commerce:l az
data modify storage commerce:cp ac465 set from storage commerce:l ac
data modify storage commerce:cp t465 set from storage commerce:l t
scoreboard players set #i c.t 467
function commerce:page/ligne
data modify storage commerce:cp ve467 set from storage commerce:l ve
data modify storage commerce:cp vz467 set from storage commerce:l vz
data modify storage commerce:cp vc467 set from storage commerce:l vc
data modify storage commerce:cp ae467 set from storage commerce:l ae
data modify storage commerce:cp az467 set from storage commerce:l az
data modify storage commerce:cp ac467 set from storage commerce:l ac
data modify storage commerce:cp t467 set from storage commerce:l t
scoreboard players set #i c.t 468
function commerce:page/ligne
data modify storage commerce:cp ve468 set from storage commerce:l ve
data modify storage commerce:cp vz468 set from storage commerce:l vz
data modify storage commerce:cp vc468 set from storage commerce:l vc
data modify storage commerce:cp ae468 set from storage commerce:l ae
data modify storage commerce:cp az468 set from storage commerce:l az
data modify storage commerce:cp ac468 set from storage commerce:l ac
data modify storage commerce:cp t468 set from storage commerce:l t
scoreboard players set #i c.t 469
function commerce:page/ligne
data modify storage commerce:cp ve469 set from storage commerce:l ve
data modify storage commerce:cp vz469 set from storage commerce:l vz
data modify storage commerce:cp vc469 set from storage commerce:l vc
data modify storage commerce:cp ae469 set from storage commerce:l ae
data modify storage commerce:cp az469 set from storage commerce:l az
data modify storage commerce:cp ac469 set from storage commerce:l ac
data modify storage commerce:cp t469 set from storage commerce:l t
scoreboard players set #i c.t 470
function commerce:page/ligne
data modify storage commerce:cp ve470 set from storage commerce:l ve
data modify storage commerce:cp vz470 set from storage commerce:l vz
data modify storage commerce:cp vc470 set from storage commerce:l vc
data modify storage commerce:cp ae470 set from storage commerce:l ae
data modify storage commerce:cp az470 set from storage commerce:l az
data modify storage commerce:cp ac470 set from storage commerce:l ac
data modify storage commerce:cp t470 set from storage commerce:l t
function commerce:page/lettre_d_0_d with storage commerce:cp
