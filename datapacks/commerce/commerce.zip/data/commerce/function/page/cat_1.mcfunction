function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 1
function commerce:page/ligne
data modify storage commerce:cp ve1 set from storage commerce:l ve
data modify storage commerce:cp vz1 set from storage commerce:l vz
data modify storage commerce:cp vc1 set from storage commerce:l vc
data modify storage commerce:cp ae1 set from storage commerce:l ae
data modify storage commerce:cp az1 set from storage commerce:l az
data modify storage commerce:cp ac1 set from storage commerce:l ac
data modify storage commerce:cp t1 set from storage commerce:l t
data modify storage commerce:cp tc1 set from storage commerce:l tc
scoreboard players set #i c.t 2
function commerce:page/ligne
data modify storage commerce:cp ve2 set from storage commerce:l ve
data modify storage commerce:cp vz2 set from storage commerce:l vz
data modify storage commerce:cp vc2 set from storage commerce:l vc
data modify storage commerce:cp ae2 set from storage commerce:l ae
data modify storage commerce:cp az2 set from storage commerce:l az
data modify storage commerce:cp ac2 set from storage commerce:l ac
data modify storage commerce:cp t2 set from storage commerce:l t
data modify storage commerce:cp tc2 set from storage commerce:l tc
scoreboard players set #i c.t 3
function commerce:page/ligne
data modify storage commerce:cp ve3 set from storage commerce:l ve
data modify storage commerce:cp vz3 set from storage commerce:l vz
data modify storage commerce:cp vc3 set from storage commerce:l vc
data modify storage commerce:cp ae3 set from storage commerce:l ae
data modify storage commerce:cp az3 set from storage commerce:l az
data modify storage commerce:cp ac3 set from storage commerce:l ac
data modify storage commerce:cp t3 set from storage commerce:l t
data modify storage commerce:cp tc3 set from storage commerce:l tc
scoreboard players set #i c.t 4
function commerce:page/ligne
data modify storage commerce:cp ve4 set from storage commerce:l ve
data modify storage commerce:cp vz4 set from storage commerce:l vz
data modify storage commerce:cp vc4 set from storage commerce:l vc
data modify storage commerce:cp ae4 set from storage commerce:l ae
data modify storage commerce:cp az4 set from storage commerce:l az
data modify storage commerce:cp ac4 set from storage commerce:l ac
data modify storage commerce:cp t4 set from storage commerce:l t
data modify storage commerce:cp tc4 set from storage commerce:l tc
scoreboard players set #i c.t 5
function commerce:page/ligne
data modify storage commerce:cp ve5 set from storage commerce:l ve
data modify storage commerce:cp vz5 set from storage commerce:l vz
data modify storage commerce:cp vc5 set from storage commerce:l vc
data modify storage commerce:cp ae5 set from storage commerce:l ae
data modify storage commerce:cp az5 set from storage commerce:l az
data modify storage commerce:cp ac5 set from storage commerce:l ac
data modify storage commerce:cp t5 set from storage commerce:l t
data modify storage commerce:cp tc5 set from storage commerce:l tc
scoreboard players set #i c.t 6
function commerce:page/ligne
data modify storage commerce:cp ve6 set from storage commerce:l ve
data modify storage commerce:cp vz6 set from storage commerce:l vz
data modify storage commerce:cp vc6 set from storage commerce:l vc
data modify storage commerce:cp ae6 set from storage commerce:l ae
data modify storage commerce:cp az6 set from storage commerce:l az
data modify storage commerce:cp ac6 set from storage commerce:l ac
data modify storage commerce:cp t6 set from storage commerce:l t
data modify storage commerce:cp tc6 set from storage commerce:l tc
scoreboard players set #i c.t 7
function commerce:page/ligne
data modify storage commerce:cp ve7 set from storage commerce:l ve
data modify storage commerce:cp vz7 set from storage commerce:l vz
data modify storage commerce:cp vc7 set from storage commerce:l vc
data modify storage commerce:cp ae7 set from storage commerce:l ae
data modify storage commerce:cp az7 set from storage commerce:l az
data modify storage commerce:cp ac7 set from storage commerce:l ac
data modify storage commerce:cp t7 set from storage commerce:l t
data modify storage commerce:cp tc7 set from storage commerce:l tc
scoreboard players set #i c.t 8
function commerce:page/ligne
data modify storage commerce:cp ve8 set from storage commerce:l ve
data modify storage commerce:cp vz8 set from storage commerce:l vz
data modify storage commerce:cp vc8 set from storage commerce:l vc
data modify storage commerce:cp ae8 set from storage commerce:l ae
data modify storage commerce:cp az8 set from storage commerce:l az
data modify storage commerce:cp ac8 set from storage commerce:l ac
data modify storage commerce:cp t8 set from storage commerce:l t
data modify storage commerce:cp tc8 set from storage commerce:l tc
scoreboard players set #i c.t 9
function commerce:page/ligne
data modify storage commerce:cp ve9 set from storage commerce:l ve
data modify storage commerce:cp vz9 set from storage commerce:l vz
data modify storage commerce:cp vc9 set from storage commerce:l vc
data modify storage commerce:cp ae9 set from storage commerce:l ae
data modify storage commerce:cp az9 set from storage commerce:l az
data modify storage commerce:cp ac9 set from storage commerce:l ac
data modify storage commerce:cp t9 set from storage commerce:l t
data modify storage commerce:cp tc9 set from storage commerce:l tc
scoreboard players set #i c.t 10
function commerce:page/ligne
data modify storage commerce:cp ve10 set from storage commerce:l ve
data modify storage commerce:cp vz10 set from storage commerce:l vz
data modify storage commerce:cp vc10 set from storage commerce:l vc
data modify storage commerce:cp ae10 set from storage commerce:l ae
data modify storage commerce:cp az10 set from storage commerce:l az
data modify storage commerce:cp ac10 set from storage commerce:l ac
data modify storage commerce:cp t10 set from storage commerce:l t
data modify storage commerce:cp tc10 set from storage commerce:l tc
scoreboard players set #i c.t 11
function commerce:page/ligne
data modify storage commerce:cp ve11 set from storage commerce:l ve
data modify storage commerce:cp vz11 set from storage commerce:l vz
data modify storage commerce:cp vc11 set from storage commerce:l vc
data modify storage commerce:cp ae11 set from storage commerce:l ae
data modify storage commerce:cp az11 set from storage commerce:l az
data modify storage commerce:cp ac11 set from storage commerce:l ac
data modify storage commerce:cp t11 set from storage commerce:l t
data modify storage commerce:cp tc11 set from storage commerce:l tc
scoreboard players set #i c.t 12
function commerce:page/ligne
data modify storage commerce:cp ve12 set from storage commerce:l ve
data modify storage commerce:cp vz12 set from storage commerce:l vz
data modify storage commerce:cp vc12 set from storage commerce:l vc
data modify storage commerce:cp ae12 set from storage commerce:l ae
data modify storage commerce:cp az12 set from storage commerce:l az
data modify storage commerce:cp ac12 set from storage commerce:l ac
data modify storage commerce:cp t12 set from storage commerce:l t
data modify storage commerce:cp tc12 set from storage commerce:l tc
scoreboard players set #i c.t 13
function commerce:page/ligne
data modify storage commerce:cp ve13 set from storage commerce:l ve
data modify storage commerce:cp vz13 set from storage commerce:l vz
data modify storage commerce:cp vc13 set from storage commerce:l vc
data modify storage commerce:cp ae13 set from storage commerce:l ae
data modify storage commerce:cp az13 set from storage commerce:l az
data modify storage commerce:cp ac13 set from storage commerce:l ac
data modify storage commerce:cp t13 set from storage commerce:l t
data modify storage commerce:cp tc13 set from storage commerce:l tc
scoreboard players set #i c.t 14
function commerce:page/ligne
data modify storage commerce:cp ve14 set from storage commerce:l ve
data modify storage commerce:cp vz14 set from storage commerce:l vz
data modify storage commerce:cp vc14 set from storage commerce:l vc
data modify storage commerce:cp ae14 set from storage commerce:l ae
data modify storage commerce:cp az14 set from storage commerce:l az
data modify storage commerce:cp ac14 set from storage commerce:l ac
data modify storage commerce:cp t14 set from storage commerce:l t
data modify storage commerce:cp tc14 set from storage commerce:l tc
scoreboard players set #i c.t 15
function commerce:page/ligne
data modify storage commerce:cp ve15 set from storage commerce:l ve
data modify storage commerce:cp vz15 set from storage commerce:l vz
data modify storage commerce:cp vc15 set from storage commerce:l vc
data modify storage commerce:cp ae15 set from storage commerce:l ae
data modify storage commerce:cp az15 set from storage commerce:l az
data modify storage commerce:cp ac15 set from storage commerce:l ac
data modify storage commerce:cp t15 set from storage commerce:l t
data modify storage commerce:cp tc15 set from storage commerce:l tc
scoreboard players set #i c.t 16
function commerce:page/ligne
data modify storage commerce:cp ve16 set from storage commerce:l ve
data modify storage commerce:cp vz16 set from storage commerce:l vz
data modify storage commerce:cp vc16 set from storage commerce:l vc
data modify storage commerce:cp ae16 set from storage commerce:l ae
data modify storage commerce:cp az16 set from storage commerce:l az
data modify storage commerce:cp ac16 set from storage commerce:l ac
data modify storage commerce:cp t16 set from storage commerce:l t
data modify storage commerce:cp tc16 set from storage commerce:l tc
scoreboard players set #i c.t 17
function commerce:page/ligne
data modify storage commerce:cp ve17 set from storage commerce:l ve
data modify storage commerce:cp vz17 set from storage commerce:l vz
data modify storage commerce:cp vc17 set from storage commerce:l vc
data modify storage commerce:cp ae17 set from storage commerce:l ae
data modify storage commerce:cp az17 set from storage commerce:l az
data modify storage commerce:cp ac17 set from storage commerce:l ac
data modify storage commerce:cp t17 set from storage commerce:l t
data modify storage commerce:cp tc17 set from storage commerce:l tc
scoreboard players set #i c.t 18
function commerce:page/ligne
data modify storage commerce:cp ve18 set from storage commerce:l ve
data modify storage commerce:cp vz18 set from storage commerce:l vz
data modify storage commerce:cp vc18 set from storage commerce:l vc
data modify storage commerce:cp ae18 set from storage commerce:l ae
data modify storage commerce:cp az18 set from storage commerce:l az
data modify storage commerce:cp ac18 set from storage commerce:l ac
data modify storage commerce:cp t18 set from storage commerce:l t
data modify storage commerce:cp tc18 set from storage commerce:l tc
scoreboard players set #i c.t 19
function commerce:page/ligne
data modify storage commerce:cp ve19 set from storage commerce:l ve
data modify storage commerce:cp vz19 set from storage commerce:l vz
data modify storage commerce:cp vc19 set from storage commerce:l vc
data modify storage commerce:cp ae19 set from storage commerce:l ae
data modify storage commerce:cp az19 set from storage commerce:l az
data modify storage commerce:cp ac19 set from storage commerce:l ac
data modify storage commerce:cp t19 set from storage commerce:l t
data modify storage commerce:cp tc19 set from storage commerce:l tc
scoreboard players set #i c.t 20
function commerce:page/ligne
data modify storage commerce:cp ve20 set from storage commerce:l ve
data modify storage commerce:cp vz20 set from storage commerce:l vz
data modify storage commerce:cp vc20 set from storage commerce:l vc
data modify storage commerce:cp ae20 set from storage commerce:l ae
data modify storage commerce:cp az20 set from storage commerce:l az
data modify storage commerce:cp ac20 set from storage commerce:l ac
data modify storage commerce:cp t20 set from storage commerce:l t
data modify storage commerce:cp tc20 set from storage commerce:l tc
scoreboard players set #i c.t 21
function commerce:page/ligne
data modify storage commerce:cp ve21 set from storage commerce:l ve
data modify storage commerce:cp vz21 set from storage commerce:l vz
data modify storage commerce:cp vc21 set from storage commerce:l vc
data modify storage commerce:cp ae21 set from storage commerce:l ae
data modify storage commerce:cp az21 set from storage commerce:l az
data modify storage commerce:cp ac21 set from storage commerce:l ac
data modify storage commerce:cp t21 set from storage commerce:l t
data modify storage commerce:cp tc21 set from storage commerce:l tc
scoreboard players set #i c.t 22
function commerce:page/ligne
data modify storage commerce:cp ve22 set from storage commerce:l ve
data modify storage commerce:cp vz22 set from storage commerce:l vz
data modify storage commerce:cp vc22 set from storage commerce:l vc
data modify storage commerce:cp ae22 set from storage commerce:l ae
data modify storage commerce:cp az22 set from storage commerce:l az
data modify storage commerce:cp ac22 set from storage commerce:l ac
data modify storage commerce:cp t22 set from storage commerce:l t
data modify storage commerce:cp tc22 set from storage commerce:l tc
scoreboard players set #i c.t 23
function commerce:page/ligne
data modify storage commerce:cp ve23 set from storage commerce:l ve
data modify storage commerce:cp vz23 set from storage commerce:l vz
data modify storage commerce:cp vc23 set from storage commerce:l vc
data modify storage commerce:cp ae23 set from storage commerce:l ae
data modify storage commerce:cp az23 set from storage commerce:l az
data modify storage commerce:cp ac23 set from storage commerce:l ac
data modify storage commerce:cp t23 set from storage commerce:l t
data modify storage commerce:cp tc23 set from storage commerce:l tc
scoreboard players set #i c.t 24
function commerce:page/ligne
data modify storage commerce:cp ve24 set from storage commerce:l ve
data modify storage commerce:cp vz24 set from storage commerce:l vz
data modify storage commerce:cp vc24 set from storage commerce:l vc
data modify storage commerce:cp ae24 set from storage commerce:l ae
data modify storage commerce:cp az24 set from storage commerce:l az
data modify storage commerce:cp ac24 set from storage commerce:l ac
data modify storage commerce:cp t24 set from storage commerce:l t
data modify storage commerce:cp tc24 set from storage commerce:l tc
scoreboard players set #i c.t 25
function commerce:page/ligne
data modify storage commerce:cp ve25 set from storage commerce:l ve
data modify storage commerce:cp vz25 set from storage commerce:l vz
data modify storage commerce:cp vc25 set from storage commerce:l vc
data modify storage commerce:cp ae25 set from storage commerce:l ae
data modify storage commerce:cp az25 set from storage commerce:l az
data modify storage commerce:cp ac25 set from storage commerce:l ac
data modify storage commerce:cp t25 set from storage commerce:l t
data modify storage commerce:cp tc25 set from storage commerce:l tc
scoreboard players set #i c.t 26
function commerce:page/ligne
data modify storage commerce:cp ve26 set from storage commerce:l ve
data modify storage commerce:cp vz26 set from storage commerce:l vz
data modify storage commerce:cp vc26 set from storage commerce:l vc
data modify storage commerce:cp ae26 set from storage commerce:l ae
data modify storage commerce:cp az26 set from storage commerce:l az
data modify storage commerce:cp ac26 set from storage commerce:l ac
data modify storage commerce:cp t26 set from storage commerce:l t
data modify storage commerce:cp tc26 set from storage commerce:l tc
function commerce:page/cat_1_d with storage commerce:cp
