function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 1
function commerce:page/ligne
data modify storage commerce:cp ve1 set from storage commerce:l ve
data modify storage commerce:cp vz1 set from storage commerce:l vz
data modify storage commerce:cp vc1 set from storage commerce:l vc
data modify storage commerce:cp ae1 set from storage commerce:l ae
data modify storage commerce:cp az1 set from storage commerce:l az
data modify storage commerce:cp ac1 set from storage commerce:l ac
data modify storage commerce:cp t1 set from storage commerce:l t
data modify storage commerce:cp tc1 set from storage commerce:l tc
scoreboard players set #i c.t 2
function commerce:page/ligne
data modify storage commerce:cp ve2 set from storage commerce:l ve
data modify storage commerce:cp vz2 set from storage commerce:l vz
data modify storage commerce:cp vc2 set from storage commerce:l vc
data modify storage commerce:cp ae2 set from storage commerce:l ae
data modify storage commerce:cp az2 set from storage commerce:l az
data modify storage commerce:cp ac2 set from storage commerce:l ac
data modify storage commerce:cp t2 set from storage commerce:l t
data modify storage commerce:cp tc2 set from storage commerce:l tc
scoreboard players set #i c.t 3
function commerce:page/ligne
data modify storage commerce:cp ve3 set from storage commerce:l ve
data modify storage commerce:cp vz3 set from storage commerce:l vz
data modify storage commerce:cp vc3 set from storage commerce:l vc
data modify storage commerce:cp ae3 set from storage commerce:l ae
data modify storage commerce:cp az3 set from storage commerce:l az
data modify storage commerce:cp ac3 set from storage commerce:l ac
data modify storage commerce:cp t3 set from storage commerce:l t
data modify storage commerce:cp tc3 set from storage commerce:l tc
scoreboard players set #i c.t 4
function commerce:page/ligne
data modify storage commerce:cp ve4 set from storage commerce:l ve
data modify storage commerce:cp vz4 set from storage commerce:l vz
data modify storage commerce:cp vc4 set from storage commerce:l vc
data modify storage commerce:cp ae4 set from storage commerce:l ae
data modify storage commerce:cp az4 set from storage commerce:l az
data modify storage commerce:cp ac4 set from storage commerce:l ac
data modify storage commerce:cp t4 set from storage commerce:l t
data modify storage commerce:cp tc4 set from storage commerce:l tc
scoreboard players set #i c.t 5
function commerce:page/ligne
data modify storage commerce:cp ve5 set from storage commerce:l ve
data modify storage commerce:cp vz5 set from storage commerce:l vz
data modify storage commerce:cp vc5 set from storage commerce:l vc
data modify storage commerce:cp ae5 set from storage commerce:l ae
data modify storage commerce:cp az5 set from storage commerce:l az
data modify storage commerce:cp ac5 set from storage commerce:l ac
data modify storage commerce:cp t5 set from storage commerce:l t
data modify storage commerce:cp tc5 set from storage commerce:l tc
scoreboard players set #i c.t 6
function commerce:page/ligne
data modify storage commerce:cp ve6 set from storage commerce:l ve
data modify storage commerce:cp vz6 set from storage commerce:l vz
data modify storage commerce:cp vc6 set from storage commerce:l vc
data modify storage commerce:cp ae6 set from storage commerce:l ae
data modify storage commerce:cp az6 set from storage commerce:l az
data modify storage commerce:cp ac6 set from storage commerce:l ac
data modify storage commerce:cp t6 set from storage commerce:l t
data modify storage commerce:cp tc6 set from storage commerce:l tc
scoreboard players set #i c.t 7
function commerce:page/ligne
data modify storage commerce:cp ve7 set from storage commerce:l ve
data modify storage commerce:cp vz7 set from storage commerce:l vz
data modify storage commerce:cp vc7 set from storage commerce:l vc
data modify storage commerce:cp ae7 set from storage commerce:l ae
data modify storage commerce:cp az7 set from storage commerce:l az
data modify storage commerce:cp ac7 set from storage commerce:l ac
data modify storage commerce:cp t7 set from storage commerce:l t
data modify storage commerce:cp tc7 set from storage commerce:l tc
scoreboard players set #i c.t 8
function commerce:page/ligne
data modify storage commerce:cp ve8 set from storage commerce:l ve
data modify storage commerce:cp vz8 set from storage commerce:l vz
data modify storage commerce:cp vc8 set from storage commerce:l vc
data modify storage commerce:cp ae8 set from storage commerce:l ae
data modify storage commerce:cp az8 set from storage commerce:l az
data modify storage commerce:cp ac8 set from storage commerce:l ac
data modify storage commerce:cp t8 set from storage commerce:l t
data modify storage commerce:cp tc8 set from storage commerce:l tc
scoreboard players set #i c.t 9
function commerce:page/ligne
data modify storage commerce:cp ve9 set from storage commerce:l ve
data modify storage commerce:cp vz9 set from storage commerce:l vz
data modify storage commerce:cp vc9 set from storage commerce:l vc
data modify storage commerce:cp ae9 set from storage commerce:l ae
data modify storage commerce:cp az9 set from storage commerce:l az
data modify storage commerce:cp ac9 set from storage commerce:l ac
data modify storage commerce:cp t9 set from storage commerce:l t
data modify storage commerce:cp tc9 set from storage commerce:l tc
scoreboard players set #i c.t 10
function commerce:page/ligne
data modify storage commerce:cp ve10 set from storage commerce:l ve
data modify storage commerce:cp vz10 set from storage commerce:l vz
data modify storage commerce:cp vc10 set from storage commerce:l vc
data modify storage commerce:cp ae10 set from storage commerce:l ae
data modify storage commerce:cp az10 set from storage commerce:l az
data modify storage commerce:cp ac10 set from storage commerce:l ac
data modify storage commerce:cp t10 set from storage commerce:l t
data modify storage commerce:cp tc10 set from storage commerce:l tc
scoreboard players set #i c.t 11
function commerce:page/ligne
data modify storage commerce:cp ve11 set from storage commerce:l ve
data modify storage commerce:cp vz11 set from storage commerce:l vz
data modify storage commerce:cp vc11 set from storage commerce:l vc
data modify storage commerce:cp ae11 set from storage commerce:l ae
data modify storage commerce:cp az11 set from storage commerce:l az
data modify storage commerce:cp ac11 set from storage commerce:l ac
data modify storage commerce:cp t11 set from storage commerce:l t
data modify storage commerce:cp tc11 set from storage commerce:l tc
scoreboard players set #i c.t 12
function commerce:page/ligne
data modify storage commerce:cp ve12 set from storage commerce:l ve
data modify storage commerce:cp vz12 set from storage commerce:l vz
data modify storage commerce:cp vc12 set from storage commerce:l vc
data modify storage commerce:cp ae12 set from storage commerce:l ae
data modify storage commerce:cp az12 set from storage commerce:l az
data modify storage commerce:cp ac12 set from storage commerce:l ac
data modify storage commerce:cp t12 set from storage commerce:l t
data modify storage commerce:cp tc12 set from storage commerce:l tc
scoreboard players set #i c.t 13
function commerce:page/ligne
data modify storage commerce:cp ve13 set from storage commerce:l ve
data modify storage commerce:cp vz13 set from storage commerce:l vz
data modify storage commerce:cp vc13 set from storage commerce:l vc
data modify storage commerce:cp ae13 set from storage commerce:l ae
data modify storage commerce:cp az13 set from storage commerce:l az
data modify storage commerce:cp ac13 set from storage commerce:l ac
data modify storage commerce:cp t13 set from storage commerce:l t
data modify storage commerce:cp tc13 set from storage commerce:l tc
scoreboard players set #i c.t 14
function commerce:page/ligne
data modify storage commerce:cp ve14 set from storage commerce:l ve
data modify storage commerce:cp vz14 set from storage commerce:l vz
data modify storage commerce:cp vc14 set from storage commerce:l vc
data modify storage commerce:cp ae14 set from storage commerce:l ae
data modify storage commerce:cp az14 set from storage commerce:l az
data modify storage commerce:cp ac14 set from storage commerce:l ac
data modify storage commerce:cp t14 set from storage commerce:l t
data modify storage commerce:cp tc14 set from storage commerce:l tc
scoreboard players set #i c.t 15
function commerce:page/ligne
data modify storage commerce:cp ve15 set from storage commerce:l ve
data modify storage commerce:cp vz15 set from storage commerce:l vz
data modify storage commerce:cp vc15 set from storage commerce:l vc
data modify storage commerce:cp ae15 set from storage commerce:l ae
data modify storage commerce:cp az15 set from storage commerce:l az
data modify storage commerce:cp ac15 set from storage commerce:l ac
data modify storage commerce:cp t15 set from storage commerce:l t
data modify storage commerce:cp tc15 set from storage commerce:l tc
scoreboard players set #i c.t 16
function commerce:page/ligne
data modify storage commerce:cp ve16 set from storage commerce:l ve
data modify storage commerce:cp vz16 set from storage commerce:l vz
data modify storage commerce:cp vc16 set from storage commerce:l vc
data modify storage commerce:cp ae16 set from storage commerce:l ae
data modify storage commerce:cp az16 set from storage commerce:l az
data modify storage commerce:cp ac16 set from storage commerce:l ac
data modify storage commerce:cp t16 set from storage commerce:l t
data modify storage commerce:cp tc16 set from storage commerce:l tc
scoreboard players set #i c.t 17
function commerce:page/ligne
data modify storage commerce:cp ve17 set from storage commerce:l ve
data modify storage commerce:cp vz17 set from storage commerce:l vz
data modify storage commerce:cp vc17 set from storage commerce:l vc
data modify storage commerce:cp ae17 set from storage commerce:l ae
data modify storage commerce:cp az17 set from storage commerce:l az
data modify storage commerce:cp ac17 set from storage commerce:l ac
data modify storage commerce:cp t17 set from storage commerce:l t
data modify storage commerce:cp tc17 set from storage commerce:l tc
scoreboard players set #i c.t 18
function commerce:page/ligne
data modify storage commerce:cp ve18 set from storage commerce:l ve
data modify storage commerce:cp vz18 set from storage commerce:l vz
data modify storage commerce:cp vc18 set from storage commerce:l vc
data modify storage commerce:cp ae18 set from storage commerce:l ae
data modify storage commerce:cp az18 set from storage commerce:l az
data modify storage commerce:cp ac18 set from storage commerce:l ac
data modify storage commerce:cp t18 set from storage commerce:l t
data modify storage commerce:cp tc18 set from storage commerce:l tc
scoreboard players set #i c.t 19
function commerce:page/ligne
data modify storage commerce:cp ve19 set from storage commerce:l ve
data modify storage commerce:cp vz19 set from storage commerce:l vz
data modify storage commerce:cp vc19 set from storage commerce:l vc
data modify storage commerce:cp ae19 set from storage commerce:l ae
data modify storage commerce:cp az19 set from storage commerce:l az
data modify storage commerce:cp ac19 set from storage commerce:l ac
data modify storage commerce:cp t19 set from storage commerce:l t
data modify storage commerce:cp tc19 set from storage commerce:l tc
scoreboard players set #i c.t 20
function commerce:page/ligne
data modify storage commerce:cp ve20 set from storage commerce:l ve
data modify storage commerce:cp vz20 set from storage commerce:l vz
data modify storage commerce:cp vc20 set from storage commerce:l vc
data modify storage commerce:cp ae20 set from storage commerce:l ae
data modify storage commerce:cp az20 set from storage commerce:l az
data modify storage commerce:cp ac20 set from storage commerce:l ac
data modify storage commerce:cp t20 set from storage commerce:l t
data modify storage commerce:cp tc20 set from storage commerce:l tc
scoreboard players set #i c.t 21
function commerce:page/ligne
data modify storage commerce:cp ve21 set from storage commerce:l ve
data modify storage commerce:cp vz21 set from storage commerce:l vz
data modify storage commerce:cp vc21 set from storage commerce:l vc
data modify storage commerce:cp ae21 set from storage commerce:l ae
data modify storage commerce:cp az21 set from storage commerce:l az
data modify storage commerce:cp ac21 set from storage commerce:l ac
data modify storage commerce:cp t21 set from storage commerce:l t
data modify storage commerce:cp tc21 set from storage commerce:l tc
scoreboard players set #i c.t 22
function commerce:page/ligne
data modify storage commerce:cp ve22 set from storage commerce:l ve
data modify storage commerce:cp vz22 set from storage commerce:l vz
data modify storage commerce:cp vc22 set from storage commerce:l vc
data modify storage commerce:cp ae22 set from storage commerce:l ae
data modify storage commerce:cp az22 set from storage commerce:l az
data modify storage commerce:cp ac22 set from storage commerce:l ac
data modify storage commerce:cp t22 set from storage commerce:l t
data modify storage commerce:cp tc22 set from storage commerce:l tc
scoreboard players set #i c.t 23
function commerce:page/ligne
data modify storage commerce:cp ve23 set from storage commerce:l ve
data modify storage commerce:cp vz23 set from storage commerce:l vz
data modify storage commerce:cp vc23 set from storage commerce:l vc
data modify storage commerce:cp ae23 set from storage commerce:l ae
data modify storage commerce:cp az23 set from storage commerce:l az
data modify storage commerce:cp ac23 set from storage commerce:l ac
data modify storage commerce:cp t23 set from storage commerce:l t
data modify storage commerce:cp tc23 set from storage commerce:l tc
scoreboard players set #i c.t 24
function commerce:page/ligne
data modify storage commerce:cp ve24 set from storage commerce:l ve
data modify storage commerce:cp vz24 set from storage commerce:l vz
data modify storage commerce:cp vc24 set from storage commerce:l vc
data modify storage commerce:cp ae24 set from storage commerce:l ae
data modify storage commerce:cp az24 set from storage commerce:l az
data modify storage commerce:cp ac24 set from storage commerce:l ac
data modify storage commerce:cp t24 set from storage commerce:l t
data modify storage commerce:cp tc24 set from storage commerce:l tc
scoreboard players set #i c.t 25
function commerce:page/ligne
data modify storage commerce:cp ve25 set from storage commerce:l ve
data modify storage commerce:cp vz25 set from storage commerce:l vz
data modify storage commerce:cp vc25 set from storage commerce:l vc
data modify storage commerce:cp ae25 set from storage commerce:l ae
data modify storage commerce:cp az25 set from storage commerce:l az
data modify storage commerce:cp ac25 set from storage commerce:l ac
data modify storage commerce:cp t25 set from storage commerce:l t
data modify storage commerce:cp tc25 set from storage commerce:l tc
scoreboard players set #i c.t 26
function commerce:page/ligne
data modify storage commerce:cp ve26 set from storage commerce:l ve
data modify storage commerce:cp vz26 set from storage commerce:l vz
data modify storage commerce:cp vc26 set from storage commerce:l vc
data modify storage commerce:cp ae26 set from storage commerce:l ae
data modify storage commerce:cp az26 set from storage commerce:l az
data modify storage commerce:cp ac26 set from storage commerce:l ac
data modify storage commerce:cp t26 set from storage commerce:l t
data modify storage commerce:cp tc26 set from storage commerce:l tc
scoreboard players set #i c.t 27
function commerce:page/ligne
data modify storage commerce:cp ve27 set from storage commerce:l ve
data modify storage commerce:cp vz27 set from storage commerce:l vz
data modify storage commerce:cp vc27 set from storage commerce:l vc
data modify storage commerce:cp ae27 set from storage commerce:l ae
data modify storage commerce:cp az27 set from storage commerce:l az
data modify storage commerce:cp ac27 set from storage commerce:l ac
data modify storage commerce:cp t27 set from storage commerce:l t
data modify storage commerce:cp tc27 set from storage commerce:l tc
scoreboard players set #i c.t 28
function commerce:page/ligne
data modify storage commerce:cp ve28 set from storage commerce:l ve
data modify storage commerce:cp vz28 set from storage commerce:l vz
data modify storage commerce:cp vc28 set from storage commerce:l vc
data modify storage commerce:cp ae28 set from storage commerce:l ae
data modify storage commerce:cp az28 set from storage commerce:l az
data modify storage commerce:cp ac28 set from storage commerce:l ac
data modify storage commerce:cp t28 set from storage commerce:l t
data modify storage commerce:cp tc28 set from storage commerce:l tc
scoreboard players set #i c.t 29
function commerce:page/ligne
data modify storage commerce:cp ve29 set from storage commerce:l ve
data modify storage commerce:cp vz29 set from storage commerce:l vz
data modify storage commerce:cp vc29 set from storage commerce:l vc
data modify storage commerce:cp ae29 set from storage commerce:l ae
data modify storage commerce:cp az29 set from storage commerce:l az
data modify storage commerce:cp ac29 set from storage commerce:l ac
data modify storage commerce:cp t29 set from storage commerce:l t
data modify storage commerce:cp tc29 set from storage commerce:l tc
scoreboard players set #i c.t 30
function commerce:page/ligne
data modify storage commerce:cp ve30 set from storage commerce:l ve
data modify storage commerce:cp vz30 set from storage commerce:l vz
data modify storage commerce:cp vc30 set from storage commerce:l vc
data modify storage commerce:cp ae30 set from storage commerce:l ae
data modify storage commerce:cp az30 set from storage commerce:l az
data modify storage commerce:cp ac30 set from storage commerce:l ac
data modify storage commerce:cp t30 set from storage commerce:l t
data modify storage commerce:cp tc30 set from storage commerce:l tc
scoreboard players set #i c.t 31
function commerce:page/ligne
data modify storage commerce:cp ve31 set from storage commerce:l ve
data modify storage commerce:cp vz31 set from storage commerce:l vz
data modify storage commerce:cp vc31 set from storage commerce:l vc
data modify storage commerce:cp ae31 set from storage commerce:l ae
data modify storage commerce:cp az31 set from storage commerce:l az
data modify storage commerce:cp ac31 set from storage commerce:l ac
data modify storage commerce:cp t31 set from storage commerce:l t
data modify storage commerce:cp tc31 set from storage commerce:l tc
scoreboard players set #i c.t 32
function commerce:page/ligne
data modify storage commerce:cp ve32 set from storage commerce:l ve
data modify storage commerce:cp vz32 set from storage commerce:l vz
data modify storage commerce:cp vc32 set from storage commerce:l vc
data modify storage commerce:cp ae32 set from storage commerce:l ae
data modify storage commerce:cp az32 set from storage commerce:l az
data modify storage commerce:cp ac32 set from storage commerce:l ac
data modify storage commerce:cp t32 set from storage commerce:l t
data modify storage commerce:cp tc32 set from storage commerce:l tc
scoreboard players set #i c.t 33
function commerce:page/ligne
data modify storage commerce:cp ve33 set from storage commerce:l ve
data modify storage commerce:cp vz33 set from storage commerce:l vz
data modify storage commerce:cp vc33 set from storage commerce:l vc
data modify storage commerce:cp ae33 set from storage commerce:l ae
data modify storage commerce:cp az33 set from storage commerce:l az
data modify storage commerce:cp ac33 set from storage commerce:l ac
data modify storage commerce:cp t33 set from storage commerce:l t
data modify storage commerce:cp tc33 set from storage commerce:l tc
scoreboard players set #i c.t 34
function commerce:page/ligne
data modify storage commerce:cp ve34 set from storage commerce:l ve
data modify storage commerce:cp vz34 set from storage commerce:l vz
data modify storage commerce:cp vc34 set from storage commerce:l vc
data modify storage commerce:cp ae34 set from storage commerce:l ae
data modify storage commerce:cp az34 set from storage commerce:l az
data modify storage commerce:cp ac34 set from storage commerce:l ac
data modify storage commerce:cp t34 set from storage commerce:l t
data modify storage commerce:cp tc34 set from storage commerce:l tc
scoreboard players set #i c.t 35
function commerce:page/ligne
data modify storage commerce:cp ve35 set from storage commerce:l ve
data modify storage commerce:cp vz35 set from storage commerce:l vz
data modify storage commerce:cp vc35 set from storage commerce:l vc
data modify storage commerce:cp ae35 set from storage commerce:l ae
data modify storage commerce:cp az35 set from storage commerce:l az
data modify storage commerce:cp ac35 set from storage commerce:l ac
data modify storage commerce:cp t35 set from storage commerce:l t
data modify storage commerce:cp tc35 set from storage commerce:l tc
scoreboard players set #i c.t 36
function commerce:page/ligne
data modify storage commerce:cp ve36 set from storage commerce:l ve
data modify storage commerce:cp vz36 set from storage commerce:l vz
data modify storage commerce:cp vc36 set from storage commerce:l vc
data modify storage commerce:cp ae36 set from storage commerce:l ae
data modify storage commerce:cp az36 set from storage commerce:l az
data modify storage commerce:cp ac36 set from storage commerce:l ac
data modify storage commerce:cp t36 set from storage commerce:l t
data modify storage commerce:cp tc36 set from storage commerce:l tc
scoreboard players set #i c.t 37
function commerce:page/ligne
data modify storage commerce:cp ve37 set from storage commerce:l ve
data modify storage commerce:cp vz37 set from storage commerce:l vz
data modify storage commerce:cp vc37 set from storage commerce:l vc
data modify storage commerce:cp ae37 set from storage commerce:l ae
data modify storage commerce:cp az37 set from storage commerce:l az
data modify storage commerce:cp ac37 set from storage commerce:l ac
data modify storage commerce:cp t37 set from storage commerce:l t
data modify storage commerce:cp tc37 set from storage commerce:l tc
scoreboard players set #i c.t 38
function commerce:page/ligne
data modify storage commerce:cp ve38 set from storage commerce:l ve
data modify storage commerce:cp vz38 set from storage commerce:l vz
data modify storage commerce:cp vc38 set from storage commerce:l vc
data modify storage commerce:cp ae38 set from storage commerce:l ae
data modify storage commerce:cp az38 set from storage commerce:l az
data modify storage commerce:cp ac38 set from storage commerce:l ac
data modify storage commerce:cp t38 set from storage commerce:l t
data modify storage commerce:cp tc38 set from storage commerce:l tc
scoreboard players set #i c.t 39
function commerce:page/ligne
data modify storage commerce:cp ve39 set from storage commerce:l ve
data modify storage commerce:cp vz39 set from storage commerce:l vz
data modify storage commerce:cp vc39 set from storage commerce:l vc
data modify storage commerce:cp ae39 set from storage commerce:l ae
data modify storage commerce:cp az39 set from storage commerce:l az
data modify storage commerce:cp ac39 set from storage commerce:l ac
data modify storage commerce:cp t39 set from storage commerce:l t
data modify storage commerce:cp tc39 set from storage commerce:l tc
scoreboard players set #i c.t 40
function commerce:page/ligne
data modify storage commerce:cp ve40 set from storage commerce:l ve
data modify storage commerce:cp vz40 set from storage commerce:l vz
data modify storage commerce:cp vc40 set from storage commerce:l vc
data modify storage commerce:cp ae40 set from storage commerce:l ae
data modify storage commerce:cp az40 set from storage commerce:l az
data modify storage commerce:cp ac40 set from storage commerce:l ac
data modify storage commerce:cp t40 set from storage commerce:l t
data modify storage commerce:cp tc40 set from storage commerce:l tc
scoreboard players set #i c.t 41
function commerce:page/ligne
data modify storage commerce:cp ve41 set from storage commerce:l ve
data modify storage commerce:cp vz41 set from storage commerce:l vz
data modify storage commerce:cp vc41 set from storage commerce:l vc
data modify storage commerce:cp ae41 set from storage commerce:l ae
data modify storage commerce:cp az41 set from storage commerce:l az
data modify storage commerce:cp ac41 set from storage commerce:l ac
data modify storage commerce:cp t41 set from storage commerce:l t
data modify storage commerce:cp tc41 set from storage commerce:l tc
scoreboard players set #i c.t 42
function commerce:page/ligne
data modify storage commerce:cp ve42 set from storage commerce:l ve
data modify storage commerce:cp vz42 set from storage commerce:l vz
data modify storage commerce:cp vc42 set from storage commerce:l vc
data modify storage commerce:cp ae42 set from storage commerce:l ae
data modify storage commerce:cp az42 set from storage commerce:l az
data modify storage commerce:cp ac42 set from storage commerce:l ac
data modify storage commerce:cp t42 set from storage commerce:l t
data modify storage commerce:cp tc42 set from storage commerce:l tc
scoreboard players set #i c.t 43
function commerce:page/ligne
data modify storage commerce:cp ve43 set from storage commerce:l ve
data modify storage commerce:cp vz43 set from storage commerce:l vz
data modify storage commerce:cp vc43 set from storage commerce:l vc
data modify storage commerce:cp ae43 set from storage commerce:l ae
data modify storage commerce:cp az43 set from storage commerce:l az
data modify storage commerce:cp ac43 set from storage commerce:l ac
data modify storage commerce:cp t43 set from storage commerce:l t
data modify storage commerce:cp tc43 set from storage commerce:l tc
scoreboard players set #i c.t 44
function commerce:page/ligne
data modify storage commerce:cp ve44 set from storage commerce:l ve
data modify storage commerce:cp vz44 set from storage commerce:l vz
data modify storage commerce:cp vc44 set from storage commerce:l vc
data modify storage commerce:cp ae44 set from storage commerce:l ae
data modify storage commerce:cp az44 set from storage commerce:l az
data modify storage commerce:cp ac44 set from storage commerce:l ac
data modify storage commerce:cp t44 set from storage commerce:l t
data modify storage commerce:cp tc44 set from storage commerce:l tc
function commerce:page/cat_1_d with storage commerce:cp
