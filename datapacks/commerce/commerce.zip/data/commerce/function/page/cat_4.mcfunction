function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 88
function commerce:page/ligne
data modify storage commerce:cp ve88 set from storage commerce:l ve
data modify storage commerce:cp vz88 set from storage commerce:l vz
data modify storage commerce:cp vc88 set from storage commerce:l vc
data modify storage commerce:cp ae88 set from storage commerce:l ae
data modify storage commerce:cp az88 set from storage commerce:l az
data modify storage commerce:cp ac88 set from storage commerce:l ac
data modify storage commerce:cp t88 set from storage commerce:l t
data modify storage commerce:cp tc88 set from storage commerce:l tc
scoreboard players set #i c.t 89
function commerce:page/ligne
data modify storage commerce:cp ve89 set from storage commerce:l ve
data modify storage commerce:cp vz89 set from storage commerce:l vz
data modify storage commerce:cp vc89 set from storage commerce:l vc
data modify storage commerce:cp ae89 set from storage commerce:l ae
data modify storage commerce:cp az89 set from storage commerce:l az
data modify storage commerce:cp ac89 set from storage commerce:l ac
data modify storage commerce:cp t89 set from storage commerce:l t
data modify storage commerce:cp tc89 set from storage commerce:l tc
scoreboard players set #i c.t 90
function commerce:page/ligne
data modify storage commerce:cp ve90 set from storage commerce:l ve
data modify storage commerce:cp vz90 set from storage commerce:l vz
data modify storage commerce:cp vc90 set from storage commerce:l vc
data modify storage commerce:cp ae90 set from storage commerce:l ae
data modify storage commerce:cp az90 set from storage commerce:l az
data modify storage commerce:cp ac90 set from storage commerce:l ac
data modify storage commerce:cp t90 set from storage commerce:l t
data modify storage commerce:cp tc90 set from storage commerce:l tc
scoreboard players set #i c.t 91
function commerce:page/ligne
data modify storage commerce:cp ve91 set from storage commerce:l ve
data modify storage commerce:cp vz91 set from storage commerce:l vz
data modify storage commerce:cp vc91 set from storage commerce:l vc
data modify storage commerce:cp ae91 set from storage commerce:l ae
data modify storage commerce:cp az91 set from storage commerce:l az
data modify storage commerce:cp ac91 set from storage commerce:l ac
data modify storage commerce:cp t91 set from storage commerce:l t
data modify storage commerce:cp tc91 set from storage commerce:l tc
scoreboard players set #i c.t 92
function commerce:page/ligne
data modify storage commerce:cp ve92 set from storage commerce:l ve
data modify storage commerce:cp vz92 set from storage commerce:l vz
data modify storage commerce:cp vc92 set from storage commerce:l vc
data modify storage commerce:cp ae92 set from storage commerce:l ae
data modify storage commerce:cp az92 set from storage commerce:l az
data modify storage commerce:cp ac92 set from storage commerce:l ac
data modify storage commerce:cp t92 set from storage commerce:l t
data modify storage commerce:cp tc92 set from storage commerce:l tc
scoreboard players set #i c.t 93
function commerce:page/ligne
data modify storage commerce:cp ve93 set from storage commerce:l ve
data modify storage commerce:cp vz93 set from storage commerce:l vz
data modify storage commerce:cp vc93 set from storage commerce:l vc
data modify storage commerce:cp ae93 set from storage commerce:l ae
data modify storage commerce:cp az93 set from storage commerce:l az
data modify storage commerce:cp ac93 set from storage commerce:l ac
data modify storage commerce:cp t93 set from storage commerce:l t
data modify storage commerce:cp tc93 set from storage commerce:l tc
scoreboard players set #i c.t 94
function commerce:page/ligne
data modify storage commerce:cp ve94 set from storage commerce:l ve
data modify storage commerce:cp vz94 set from storage commerce:l vz
data modify storage commerce:cp vc94 set from storage commerce:l vc
data modify storage commerce:cp ae94 set from storage commerce:l ae
data modify storage commerce:cp az94 set from storage commerce:l az
data modify storage commerce:cp ac94 set from storage commerce:l ac
data modify storage commerce:cp t94 set from storage commerce:l t
data modify storage commerce:cp tc94 set from storage commerce:l tc
scoreboard players set #i c.t 95
function commerce:page/ligne
data modify storage commerce:cp ve95 set from storage commerce:l ve
data modify storage commerce:cp vz95 set from storage commerce:l vz
data modify storage commerce:cp vc95 set from storage commerce:l vc
data modify storage commerce:cp ae95 set from storage commerce:l ae
data modify storage commerce:cp az95 set from storage commerce:l az
data modify storage commerce:cp ac95 set from storage commerce:l ac
data modify storage commerce:cp t95 set from storage commerce:l t
data modify storage commerce:cp tc95 set from storage commerce:l tc
scoreboard players set #i c.t 96
function commerce:page/ligne
data modify storage commerce:cp ve96 set from storage commerce:l ve
data modify storage commerce:cp vz96 set from storage commerce:l vz
data modify storage commerce:cp vc96 set from storage commerce:l vc
data modify storage commerce:cp ae96 set from storage commerce:l ae
data modify storage commerce:cp az96 set from storage commerce:l az
data modify storage commerce:cp ac96 set from storage commerce:l ac
data modify storage commerce:cp t96 set from storage commerce:l t
data modify storage commerce:cp tc96 set from storage commerce:l tc
scoreboard players set #i c.t 97
function commerce:page/ligne
data modify storage commerce:cp ve97 set from storage commerce:l ve
data modify storage commerce:cp vz97 set from storage commerce:l vz
data modify storage commerce:cp vc97 set from storage commerce:l vc
data modify storage commerce:cp ae97 set from storage commerce:l ae
data modify storage commerce:cp az97 set from storage commerce:l az
data modify storage commerce:cp ac97 set from storage commerce:l ac
data modify storage commerce:cp t97 set from storage commerce:l t
data modify storage commerce:cp tc97 set from storage commerce:l tc
scoreboard players set #i c.t 98
function commerce:page/ligne
data modify storage commerce:cp ve98 set from storage commerce:l ve
data modify storage commerce:cp vz98 set from storage commerce:l vz
data modify storage commerce:cp vc98 set from storage commerce:l vc
data modify storage commerce:cp ae98 set from storage commerce:l ae
data modify storage commerce:cp az98 set from storage commerce:l az
data modify storage commerce:cp ac98 set from storage commerce:l ac
data modify storage commerce:cp t98 set from storage commerce:l t
data modify storage commerce:cp tc98 set from storage commerce:l tc
scoreboard players set #i c.t 99
function commerce:page/ligne
data modify storage commerce:cp ve99 set from storage commerce:l ve
data modify storage commerce:cp vz99 set from storage commerce:l vz
data modify storage commerce:cp vc99 set from storage commerce:l vc
data modify storage commerce:cp ae99 set from storage commerce:l ae
data modify storage commerce:cp az99 set from storage commerce:l az
data modify storage commerce:cp ac99 set from storage commerce:l ac
data modify storage commerce:cp t99 set from storage commerce:l t
data modify storage commerce:cp tc99 set from storage commerce:l tc
scoreboard players set #i c.t 100
function commerce:page/ligne
data modify storage commerce:cp ve100 set from storage commerce:l ve
data modify storage commerce:cp vz100 set from storage commerce:l vz
data modify storage commerce:cp vc100 set from storage commerce:l vc
data modify storage commerce:cp ae100 set from storage commerce:l ae
data modify storage commerce:cp az100 set from storage commerce:l az
data modify storage commerce:cp ac100 set from storage commerce:l ac
data modify storage commerce:cp t100 set from storage commerce:l t
data modify storage commerce:cp tc100 set from storage commerce:l tc
scoreboard players set #i c.t 101
function commerce:page/ligne
data modify storage commerce:cp ve101 set from storage commerce:l ve
data modify storage commerce:cp vz101 set from storage commerce:l vz
data modify storage commerce:cp vc101 set from storage commerce:l vc
data modify storage commerce:cp ae101 set from storage commerce:l ae
data modify storage commerce:cp az101 set from storage commerce:l az
data modify storage commerce:cp ac101 set from storage commerce:l ac
data modify storage commerce:cp t101 set from storage commerce:l t
data modify storage commerce:cp tc101 set from storage commerce:l tc
scoreboard players set #i c.t 102
function commerce:page/ligne
data modify storage commerce:cp ve102 set from storage commerce:l ve
data modify storage commerce:cp vz102 set from storage commerce:l vz
data modify storage commerce:cp vc102 set from storage commerce:l vc
data modify storage commerce:cp ae102 set from storage commerce:l ae
data modify storage commerce:cp az102 set from storage commerce:l az
data modify storage commerce:cp ac102 set from storage commerce:l ac
data modify storage commerce:cp t102 set from storage commerce:l t
data modify storage commerce:cp tc102 set from storage commerce:l tc
scoreboard players set #i c.t 103
function commerce:page/ligne
data modify storage commerce:cp ve103 set from storage commerce:l ve
data modify storage commerce:cp vz103 set from storage commerce:l vz
data modify storage commerce:cp vc103 set from storage commerce:l vc
data modify storage commerce:cp ae103 set from storage commerce:l ae
data modify storage commerce:cp az103 set from storage commerce:l az
data modify storage commerce:cp ac103 set from storage commerce:l ac
data modify storage commerce:cp t103 set from storage commerce:l t
data modify storage commerce:cp tc103 set from storage commerce:l tc
scoreboard players set #i c.t 104
function commerce:page/ligne
data modify storage commerce:cp ve104 set from storage commerce:l ve
data modify storage commerce:cp vz104 set from storage commerce:l vz
data modify storage commerce:cp vc104 set from storage commerce:l vc
data modify storage commerce:cp ae104 set from storage commerce:l ae
data modify storage commerce:cp az104 set from storage commerce:l az
data modify storage commerce:cp ac104 set from storage commerce:l ac
data modify storage commerce:cp t104 set from storage commerce:l t
data modify storage commerce:cp tc104 set from storage commerce:l tc
scoreboard players set #i c.t 105
function commerce:page/ligne
data modify storage commerce:cp ve105 set from storage commerce:l ve
data modify storage commerce:cp vz105 set from storage commerce:l vz
data modify storage commerce:cp vc105 set from storage commerce:l vc
data modify storage commerce:cp ae105 set from storage commerce:l ae
data modify storage commerce:cp az105 set from storage commerce:l az
data modify storage commerce:cp ac105 set from storage commerce:l ac
data modify storage commerce:cp t105 set from storage commerce:l t
data modify storage commerce:cp tc105 set from storage commerce:l tc
scoreboard players set #i c.t 106
function commerce:page/ligne
data modify storage commerce:cp ve106 set from storage commerce:l ve
data modify storage commerce:cp vz106 set from storage commerce:l vz
data modify storage commerce:cp vc106 set from storage commerce:l vc
data modify storage commerce:cp ae106 set from storage commerce:l ae
data modify storage commerce:cp az106 set from storage commerce:l az
data modify storage commerce:cp ac106 set from storage commerce:l ac
data modify storage commerce:cp t106 set from storage commerce:l t
data modify storage commerce:cp tc106 set from storage commerce:l tc
scoreboard players set #i c.t 107
function commerce:page/ligne
data modify storage commerce:cp ve107 set from storage commerce:l ve
data modify storage commerce:cp vz107 set from storage commerce:l vz
data modify storage commerce:cp vc107 set from storage commerce:l vc
data modify storage commerce:cp ae107 set from storage commerce:l ae
data modify storage commerce:cp az107 set from storage commerce:l az
data modify storage commerce:cp ac107 set from storage commerce:l ac
data modify storage commerce:cp t107 set from storage commerce:l t
data modify storage commerce:cp tc107 set from storage commerce:l tc
scoreboard players set #i c.t 108
function commerce:page/ligne
data modify storage commerce:cp ve108 set from storage commerce:l ve
data modify storage commerce:cp vz108 set from storage commerce:l vz
data modify storage commerce:cp vc108 set from storage commerce:l vc
data modify storage commerce:cp ae108 set from storage commerce:l ae
data modify storage commerce:cp az108 set from storage commerce:l az
data modify storage commerce:cp ac108 set from storage commerce:l ac
data modify storage commerce:cp t108 set from storage commerce:l t
data modify storage commerce:cp tc108 set from storage commerce:l tc
scoreboard players set #i c.t 109
function commerce:page/ligne
data modify storage commerce:cp ve109 set from storage commerce:l ve
data modify storage commerce:cp vz109 set from storage commerce:l vz
data modify storage commerce:cp vc109 set from storage commerce:l vc
data modify storage commerce:cp ae109 set from storage commerce:l ae
data modify storage commerce:cp az109 set from storage commerce:l az
data modify storage commerce:cp ac109 set from storage commerce:l ac
data modify storage commerce:cp t109 set from storage commerce:l t
data modify storage commerce:cp tc109 set from storage commerce:l tc
scoreboard players set #i c.t 110
function commerce:page/ligne
data modify storage commerce:cp ve110 set from storage commerce:l ve
data modify storage commerce:cp vz110 set from storage commerce:l vz
data modify storage commerce:cp vc110 set from storage commerce:l vc
data modify storage commerce:cp ae110 set from storage commerce:l ae
data modify storage commerce:cp az110 set from storage commerce:l az
data modify storage commerce:cp ac110 set from storage commerce:l ac
data modify storage commerce:cp t110 set from storage commerce:l t
data modify storage commerce:cp tc110 set from storage commerce:l tc
scoreboard players set #i c.t 111
function commerce:page/ligne
data modify storage commerce:cp ve111 set from storage commerce:l ve
data modify storage commerce:cp vz111 set from storage commerce:l vz
data modify storage commerce:cp vc111 set from storage commerce:l vc
data modify storage commerce:cp ae111 set from storage commerce:l ae
data modify storage commerce:cp az111 set from storage commerce:l az
data modify storage commerce:cp ac111 set from storage commerce:l ac
data modify storage commerce:cp t111 set from storage commerce:l t
data modify storage commerce:cp tc111 set from storage commerce:l tc
scoreboard players set #i c.t 112
function commerce:page/ligne
data modify storage commerce:cp ve112 set from storage commerce:l ve
data modify storage commerce:cp vz112 set from storage commerce:l vz
data modify storage commerce:cp vc112 set from storage commerce:l vc
data modify storage commerce:cp ae112 set from storage commerce:l ae
data modify storage commerce:cp az112 set from storage commerce:l az
data modify storage commerce:cp ac112 set from storage commerce:l ac
data modify storage commerce:cp t112 set from storage commerce:l t
data modify storage commerce:cp tc112 set from storage commerce:l tc
scoreboard players set #i c.t 113
function commerce:page/ligne
data modify storage commerce:cp ve113 set from storage commerce:l ve
data modify storage commerce:cp vz113 set from storage commerce:l vz
data modify storage commerce:cp vc113 set from storage commerce:l vc
data modify storage commerce:cp ae113 set from storage commerce:l ae
data modify storage commerce:cp az113 set from storage commerce:l az
data modify storage commerce:cp ac113 set from storage commerce:l ac
data modify storage commerce:cp t113 set from storage commerce:l t
data modify storage commerce:cp tc113 set from storage commerce:l tc
scoreboard players set #i c.t 114
function commerce:page/ligne
data modify storage commerce:cp ve114 set from storage commerce:l ve
data modify storage commerce:cp vz114 set from storage commerce:l vz
data modify storage commerce:cp vc114 set from storage commerce:l vc
data modify storage commerce:cp ae114 set from storage commerce:l ae
data modify storage commerce:cp az114 set from storage commerce:l az
data modify storage commerce:cp ac114 set from storage commerce:l ac
data modify storage commerce:cp t114 set from storage commerce:l t
data modify storage commerce:cp tc114 set from storage commerce:l tc
scoreboard players set #i c.t 115
function commerce:page/ligne
data modify storage commerce:cp ve115 set from storage commerce:l ve
data modify storage commerce:cp vz115 set from storage commerce:l vz
data modify storage commerce:cp vc115 set from storage commerce:l vc
data modify storage commerce:cp ae115 set from storage commerce:l ae
data modify storage commerce:cp az115 set from storage commerce:l az
data modify storage commerce:cp ac115 set from storage commerce:l ac
data modify storage commerce:cp t115 set from storage commerce:l t
data modify storage commerce:cp tc115 set from storage commerce:l tc
scoreboard players set #i c.t 116
function commerce:page/ligne
data modify storage commerce:cp ve116 set from storage commerce:l ve
data modify storage commerce:cp vz116 set from storage commerce:l vz
data modify storage commerce:cp vc116 set from storage commerce:l vc
data modify storage commerce:cp ae116 set from storage commerce:l ae
data modify storage commerce:cp az116 set from storage commerce:l az
data modify storage commerce:cp ac116 set from storage commerce:l ac
data modify storage commerce:cp t116 set from storage commerce:l t
data modify storage commerce:cp tc116 set from storage commerce:l tc
scoreboard players set #i c.t 117
function commerce:page/ligne
data modify storage commerce:cp ve117 set from storage commerce:l ve
data modify storage commerce:cp vz117 set from storage commerce:l vz
data modify storage commerce:cp vc117 set from storage commerce:l vc
data modify storage commerce:cp ae117 set from storage commerce:l ae
data modify storage commerce:cp az117 set from storage commerce:l az
data modify storage commerce:cp ac117 set from storage commerce:l ac
data modify storage commerce:cp t117 set from storage commerce:l t
data modify storage commerce:cp tc117 set from storage commerce:l tc
scoreboard players set #i c.t 118
function commerce:page/ligne
data modify storage commerce:cp ve118 set from storage commerce:l ve
data modify storage commerce:cp vz118 set from storage commerce:l vz
data modify storage commerce:cp vc118 set from storage commerce:l vc
data modify storage commerce:cp ae118 set from storage commerce:l ae
data modify storage commerce:cp az118 set from storage commerce:l az
data modify storage commerce:cp ac118 set from storage commerce:l ac
data modify storage commerce:cp t118 set from storage commerce:l t
data modify storage commerce:cp tc118 set from storage commerce:l tc
scoreboard players set #i c.t 119
function commerce:page/ligne
data modify storage commerce:cp ve119 set from storage commerce:l ve
data modify storage commerce:cp vz119 set from storage commerce:l vz
data modify storage commerce:cp vc119 set from storage commerce:l vc
data modify storage commerce:cp ae119 set from storage commerce:l ae
data modify storage commerce:cp az119 set from storage commerce:l az
data modify storage commerce:cp ac119 set from storage commerce:l ac
data modify storage commerce:cp t119 set from storage commerce:l t
data modify storage commerce:cp tc119 set from storage commerce:l tc
scoreboard players set #i c.t 120
function commerce:page/ligne
data modify storage commerce:cp ve120 set from storage commerce:l ve
data modify storage commerce:cp vz120 set from storage commerce:l vz
data modify storage commerce:cp vc120 set from storage commerce:l vc
data modify storage commerce:cp ae120 set from storage commerce:l ae
data modify storage commerce:cp az120 set from storage commerce:l az
data modify storage commerce:cp ac120 set from storage commerce:l ac
data modify storage commerce:cp t120 set from storage commerce:l t
data modify storage commerce:cp tc120 set from storage commerce:l tc
scoreboard players set #i c.t 121
function commerce:page/ligne
data modify storage commerce:cp ve121 set from storage commerce:l ve
data modify storage commerce:cp vz121 set from storage commerce:l vz
data modify storage commerce:cp vc121 set from storage commerce:l vc
data modify storage commerce:cp ae121 set from storage commerce:l ae
data modify storage commerce:cp az121 set from storage commerce:l az
data modify storage commerce:cp ac121 set from storage commerce:l ac
data modify storage commerce:cp t121 set from storage commerce:l t
data modify storage commerce:cp tc121 set from storage commerce:l tc
function commerce:page/cat_4_d with storage commerce:cp
