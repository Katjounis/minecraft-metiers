function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 154
function commerce:page/ligne
data modify storage commerce:cp ve154 set from storage commerce:l ve
data modify storage commerce:cp vz154 set from storage commerce:l vz
data modify storage commerce:cp vc154 set from storage commerce:l vc
data modify storage commerce:cp ae154 set from storage commerce:l ae
data modify storage commerce:cp az154 set from storage commerce:l az
data modify storage commerce:cp ac154 set from storage commerce:l ac
data modify storage commerce:cp t154 set from storage commerce:l t
data modify storage commerce:cp tc154 set from storage commerce:l tc
scoreboard players set #i c.t 155
function commerce:page/ligne
data modify storage commerce:cp ve155 set from storage commerce:l ve
data modify storage commerce:cp vz155 set from storage commerce:l vz
data modify storage commerce:cp vc155 set from storage commerce:l vc
data modify storage commerce:cp ae155 set from storage commerce:l ae
data modify storage commerce:cp az155 set from storage commerce:l az
data modify storage commerce:cp ac155 set from storage commerce:l ac
data modify storage commerce:cp t155 set from storage commerce:l t
data modify storage commerce:cp tc155 set from storage commerce:l tc
scoreboard players set #i c.t 156
function commerce:page/ligne
data modify storage commerce:cp ve156 set from storage commerce:l ve
data modify storage commerce:cp vz156 set from storage commerce:l vz
data modify storage commerce:cp vc156 set from storage commerce:l vc
data modify storage commerce:cp ae156 set from storage commerce:l ae
data modify storage commerce:cp az156 set from storage commerce:l az
data modify storage commerce:cp ac156 set from storage commerce:l ac
data modify storage commerce:cp t156 set from storage commerce:l t
data modify storage commerce:cp tc156 set from storage commerce:l tc
scoreboard players set #i c.t 157
function commerce:page/ligne
data modify storage commerce:cp ve157 set from storage commerce:l ve
data modify storage commerce:cp vz157 set from storage commerce:l vz
data modify storage commerce:cp vc157 set from storage commerce:l vc
data modify storage commerce:cp ae157 set from storage commerce:l ae
data modify storage commerce:cp az157 set from storage commerce:l az
data modify storage commerce:cp ac157 set from storage commerce:l ac
data modify storage commerce:cp t157 set from storage commerce:l t
data modify storage commerce:cp tc157 set from storage commerce:l tc
scoreboard players set #i c.t 158
function commerce:page/ligne
data modify storage commerce:cp ve158 set from storage commerce:l ve
data modify storage commerce:cp vz158 set from storage commerce:l vz
data modify storage commerce:cp vc158 set from storage commerce:l vc
data modify storage commerce:cp ae158 set from storage commerce:l ae
data modify storage commerce:cp az158 set from storage commerce:l az
data modify storage commerce:cp ac158 set from storage commerce:l ac
data modify storage commerce:cp t158 set from storage commerce:l t
data modify storage commerce:cp tc158 set from storage commerce:l tc
scoreboard players set #i c.t 159
function commerce:page/ligne
data modify storage commerce:cp ve159 set from storage commerce:l ve
data modify storage commerce:cp vz159 set from storage commerce:l vz
data modify storage commerce:cp vc159 set from storage commerce:l vc
data modify storage commerce:cp ae159 set from storage commerce:l ae
data modify storage commerce:cp az159 set from storage commerce:l az
data modify storage commerce:cp ac159 set from storage commerce:l ac
data modify storage commerce:cp t159 set from storage commerce:l t
data modify storage commerce:cp tc159 set from storage commerce:l tc
scoreboard players set #i c.t 160
function commerce:page/ligne
data modify storage commerce:cp ve160 set from storage commerce:l ve
data modify storage commerce:cp vz160 set from storage commerce:l vz
data modify storage commerce:cp vc160 set from storage commerce:l vc
data modify storage commerce:cp ae160 set from storage commerce:l ae
data modify storage commerce:cp az160 set from storage commerce:l az
data modify storage commerce:cp ac160 set from storage commerce:l ac
data modify storage commerce:cp t160 set from storage commerce:l t
data modify storage commerce:cp tc160 set from storage commerce:l tc
scoreboard players set #i c.t 161
function commerce:page/ligne
data modify storage commerce:cp ve161 set from storage commerce:l ve
data modify storage commerce:cp vz161 set from storage commerce:l vz
data modify storage commerce:cp vc161 set from storage commerce:l vc
data modify storage commerce:cp ae161 set from storage commerce:l ae
data modify storage commerce:cp az161 set from storage commerce:l az
data modify storage commerce:cp ac161 set from storage commerce:l ac
data modify storage commerce:cp t161 set from storage commerce:l t
data modify storage commerce:cp tc161 set from storage commerce:l tc
scoreboard players set #i c.t 162
function commerce:page/ligne
data modify storage commerce:cp ve162 set from storage commerce:l ve
data modify storage commerce:cp vz162 set from storage commerce:l vz
data modify storage commerce:cp vc162 set from storage commerce:l vc
data modify storage commerce:cp ae162 set from storage commerce:l ae
data modify storage commerce:cp az162 set from storage commerce:l az
data modify storage commerce:cp ac162 set from storage commerce:l ac
data modify storage commerce:cp t162 set from storage commerce:l t
data modify storage commerce:cp tc162 set from storage commerce:l tc
scoreboard players set #i c.t 163
function commerce:page/ligne
data modify storage commerce:cp ve163 set from storage commerce:l ve
data modify storage commerce:cp vz163 set from storage commerce:l vz
data modify storage commerce:cp vc163 set from storage commerce:l vc
data modify storage commerce:cp ae163 set from storage commerce:l ae
data modify storage commerce:cp az163 set from storage commerce:l az
data modify storage commerce:cp ac163 set from storage commerce:l ac
data modify storage commerce:cp t163 set from storage commerce:l t
data modify storage commerce:cp tc163 set from storage commerce:l tc
scoreboard players set #i c.t 164
function commerce:page/ligne
data modify storage commerce:cp ve164 set from storage commerce:l ve
data modify storage commerce:cp vz164 set from storage commerce:l vz
data modify storage commerce:cp vc164 set from storage commerce:l vc
data modify storage commerce:cp ae164 set from storage commerce:l ae
data modify storage commerce:cp az164 set from storage commerce:l az
data modify storage commerce:cp ac164 set from storage commerce:l ac
data modify storage commerce:cp t164 set from storage commerce:l t
data modify storage commerce:cp tc164 set from storage commerce:l tc
scoreboard players set #i c.t 165
function commerce:page/ligne
data modify storage commerce:cp ve165 set from storage commerce:l ve
data modify storage commerce:cp vz165 set from storage commerce:l vz
data modify storage commerce:cp vc165 set from storage commerce:l vc
data modify storage commerce:cp ae165 set from storage commerce:l ae
data modify storage commerce:cp az165 set from storage commerce:l az
data modify storage commerce:cp ac165 set from storage commerce:l ac
data modify storage commerce:cp t165 set from storage commerce:l t
data modify storage commerce:cp tc165 set from storage commerce:l tc
scoreboard players set #i c.t 166
function commerce:page/ligne
data modify storage commerce:cp ve166 set from storage commerce:l ve
data modify storage commerce:cp vz166 set from storage commerce:l vz
data modify storage commerce:cp vc166 set from storage commerce:l vc
data modify storage commerce:cp ae166 set from storage commerce:l ae
data modify storage commerce:cp az166 set from storage commerce:l az
data modify storage commerce:cp ac166 set from storage commerce:l ac
data modify storage commerce:cp t166 set from storage commerce:l t
data modify storage commerce:cp tc166 set from storage commerce:l tc
scoreboard players set #i c.t 167
function commerce:page/ligne
data modify storage commerce:cp ve167 set from storage commerce:l ve
data modify storage commerce:cp vz167 set from storage commerce:l vz
data modify storage commerce:cp vc167 set from storage commerce:l vc
data modify storage commerce:cp ae167 set from storage commerce:l ae
data modify storage commerce:cp az167 set from storage commerce:l az
data modify storage commerce:cp ac167 set from storage commerce:l ac
data modify storage commerce:cp t167 set from storage commerce:l t
data modify storage commerce:cp tc167 set from storage commerce:l tc
scoreboard players set #i c.t 168
function commerce:page/ligne
data modify storage commerce:cp ve168 set from storage commerce:l ve
data modify storage commerce:cp vz168 set from storage commerce:l vz
data modify storage commerce:cp vc168 set from storage commerce:l vc
data modify storage commerce:cp ae168 set from storage commerce:l ae
data modify storage commerce:cp az168 set from storage commerce:l az
data modify storage commerce:cp ac168 set from storage commerce:l ac
data modify storage commerce:cp t168 set from storage commerce:l t
data modify storage commerce:cp tc168 set from storage commerce:l tc
scoreboard players set #i c.t 169
function commerce:page/ligne
data modify storage commerce:cp ve169 set from storage commerce:l ve
data modify storage commerce:cp vz169 set from storage commerce:l vz
data modify storage commerce:cp vc169 set from storage commerce:l vc
data modify storage commerce:cp ae169 set from storage commerce:l ae
data modify storage commerce:cp az169 set from storage commerce:l az
data modify storage commerce:cp ac169 set from storage commerce:l ac
data modify storage commerce:cp t169 set from storage commerce:l t
data modify storage commerce:cp tc169 set from storage commerce:l tc
scoreboard players set #i c.t 170
function commerce:page/ligne
data modify storage commerce:cp ve170 set from storage commerce:l ve
data modify storage commerce:cp vz170 set from storage commerce:l vz
data modify storage commerce:cp vc170 set from storage commerce:l vc
data modify storage commerce:cp ae170 set from storage commerce:l ae
data modify storage commerce:cp az170 set from storage commerce:l az
data modify storage commerce:cp ac170 set from storage commerce:l ac
data modify storage commerce:cp t170 set from storage commerce:l t
data modify storage commerce:cp tc170 set from storage commerce:l tc
scoreboard players set #i c.t 171
function commerce:page/ligne
data modify storage commerce:cp ve171 set from storage commerce:l ve
data modify storage commerce:cp vz171 set from storage commerce:l vz
data modify storage commerce:cp vc171 set from storage commerce:l vc
data modify storage commerce:cp ae171 set from storage commerce:l ae
data modify storage commerce:cp az171 set from storage commerce:l az
data modify storage commerce:cp ac171 set from storage commerce:l ac
data modify storage commerce:cp t171 set from storage commerce:l t
data modify storage commerce:cp tc171 set from storage commerce:l tc
scoreboard players set #i c.t 172
function commerce:page/ligne
data modify storage commerce:cp ve172 set from storage commerce:l ve
data modify storage commerce:cp vz172 set from storage commerce:l vz
data modify storage commerce:cp vc172 set from storage commerce:l vc
data modify storage commerce:cp ae172 set from storage commerce:l ae
data modify storage commerce:cp az172 set from storage commerce:l az
data modify storage commerce:cp ac172 set from storage commerce:l ac
data modify storage commerce:cp t172 set from storage commerce:l t
data modify storage commerce:cp tc172 set from storage commerce:l tc
scoreboard players set #i c.t 173
function commerce:page/ligne
data modify storage commerce:cp ve173 set from storage commerce:l ve
data modify storage commerce:cp vz173 set from storage commerce:l vz
data modify storage commerce:cp vc173 set from storage commerce:l vc
data modify storage commerce:cp ae173 set from storage commerce:l ae
data modify storage commerce:cp az173 set from storage commerce:l az
data modify storage commerce:cp ac173 set from storage commerce:l ac
data modify storage commerce:cp t173 set from storage commerce:l t
data modify storage commerce:cp tc173 set from storage commerce:l tc
scoreboard players set #i c.t 174
function commerce:page/ligne
data modify storage commerce:cp ve174 set from storage commerce:l ve
data modify storage commerce:cp vz174 set from storage commerce:l vz
data modify storage commerce:cp vc174 set from storage commerce:l vc
data modify storage commerce:cp ae174 set from storage commerce:l ae
data modify storage commerce:cp az174 set from storage commerce:l az
data modify storage commerce:cp ac174 set from storage commerce:l ac
data modify storage commerce:cp t174 set from storage commerce:l t
data modify storage commerce:cp tc174 set from storage commerce:l tc
scoreboard players set #i c.t 175
function commerce:page/ligne
data modify storage commerce:cp ve175 set from storage commerce:l ve
data modify storage commerce:cp vz175 set from storage commerce:l vz
data modify storage commerce:cp vc175 set from storage commerce:l vc
data modify storage commerce:cp ae175 set from storage commerce:l ae
data modify storage commerce:cp az175 set from storage commerce:l az
data modify storage commerce:cp ac175 set from storage commerce:l ac
data modify storage commerce:cp t175 set from storage commerce:l t
data modify storage commerce:cp tc175 set from storage commerce:l tc
scoreboard players set #i c.t 176
function commerce:page/ligne
data modify storage commerce:cp ve176 set from storage commerce:l ve
data modify storage commerce:cp vz176 set from storage commerce:l vz
data modify storage commerce:cp vc176 set from storage commerce:l vc
data modify storage commerce:cp ae176 set from storage commerce:l ae
data modify storage commerce:cp az176 set from storage commerce:l az
data modify storage commerce:cp ac176 set from storage commerce:l ac
data modify storage commerce:cp t176 set from storage commerce:l t
data modify storage commerce:cp tc176 set from storage commerce:l tc
scoreboard players set #i c.t 177
function commerce:page/ligne
data modify storage commerce:cp ve177 set from storage commerce:l ve
data modify storage commerce:cp vz177 set from storage commerce:l vz
data modify storage commerce:cp vc177 set from storage commerce:l vc
data modify storage commerce:cp ae177 set from storage commerce:l ae
data modify storage commerce:cp az177 set from storage commerce:l az
data modify storage commerce:cp ac177 set from storage commerce:l ac
data modify storage commerce:cp t177 set from storage commerce:l t
data modify storage commerce:cp tc177 set from storage commerce:l tc
scoreboard players set #i c.t 178
function commerce:page/ligne
data modify storage commerce:cp ve178 set from storage commerce:l ve
data modify storage commerce:cp vz178 set from storage commerce:l vz
data modify storage commerce:cp vc178 set from storage commerce:l vc
data modify storage commerce:cp ae178 set from storage commerce:l ae
data modify storage commerce:cp az178 set from storage commerce:l az
data modify storage commerce:cp ac178 set from storage commerce:l ac
data modify storage commerce:cp t178 set from storage commerce:l t
data modify storage commerce:cp tc178 set from storage commerce:l tc
scoreboard players set #i c.t 179
function commerce:page/ligne
data modify storage commerce:cp ve179 set from storage commerce:l ve
data modify storage commerce:cp vz179 set from storage commerce:l vz
data modify storage commerce:cp vc179 set from storage commerce:l vc
data modify storage commerce:cp ae179 set from storage commerce:l ae
data modify storage commerce:cp az179 set from storage commerce:l az
data modify storage commerce:cp ac179 set from storage commerce:l ac
data modify storage commerce:cp t179 set from storage commerce:l t
data modify storage commerce:cp tc179 set from storage commerce:l tc
scoreboard players set #i c.t 180
function commerce:page/ligne
data modify storage commerce:cp ve180 set from storage commerce:l ve
data modify storage commerce:cp vz180 set from storage commerce:l vz
data modify storage commerce:cp vc180 set from storage commerce:l vc
data modify storage commerce:cp ae180 set from storage commerce:l ae
data modify storage commerce:cp az180 set from storage commerce:l az
data modify storage commerce:cp ac180 set from storage commerce:l ac
data modify storage commerce:cp t180 set from storage commerce:l t
data modify storage commerce:cp tc180 set from storage commerce:l tc
scoreboard players set #i c.t 181
function commerce:page/ligne
data modify storage commerce:cp ve181 set from storage commerce:l ve
data modify storage commerce:cp vz181 set from storage commerce:l vz
data modify storage commerce:cp vc181 set from storage commerce:l vc
data modify storage commerce:cp ae181 set from storage commerce:l ae
data modify storage commerce:cp az181 set from storage commerce:l az
data modify storage commerce:cp ac181 set from storage commerce:l ac
data modify storage commerce:cp t181 set from storage commerce:l t
data modify storage commerce:cp tc181 set from storage commerce:l tc
scoreboard players set #i c.t 182
function commerce:page/ligne
data modify storage commerce:cp ve182 set from storage commerce:l ve
data modify storage commerce:cp vz182 set from storage commerce:l vz
data modify storage commerce:cp vc182 set from storage commerce:l vc
data modify storage commerce:cp ae182 set from storage commerce:l ae
data modify storage commerce:cp az182 set from storage commerce:l az
data modify storage commerce:cp ac182 set from storage commerce:l ac
data modify storage commerce:cp t182 set from storage commerce:l t
data modify storage commerce:cp tc182 set from storage commerce:l tc
scoreboard players set #i c.t 183
function commerce:page/ligne
data modify storage commerce:cp ve183 set from storage commerce:l ve
data modify storage commerce:cp vz183 set from storage commerce:l vz
data modify storage commerce:cp vc183 set from storage commerce:l vc
data modify storage commerce:cp ae183 set from storage commerce:l ae
data modify storage commerce:cp az183 set from storage commerce:l az
data modify storage commerce:cp ac183 set from storage commerce:l ac
data modify storage commerce:cp t183 set from storage commerce:l t
data modify storage commerce:cp tc183 set from storage commerce:l tc
scoreboard players set #i c.t 184
function commerce:page/ligne
data modify storage commerce:cp ve184 set from storage commerce:l ve
data modify storage commerce:cp vz184 set from storage commerce:l vz
data modify storage commerce:cp vc184 set from storage commerce:l vc
data modify storage commerce:cp ae184 set from storage commerce:l ae
data modify storage commerce:cp az184 set from storage commerce:l az
data modify storage commerce:cp ac184 set from storage commerce:l ac
data modify storage commerce:cp t184 set from storage commerce:l t
data modify storage commerce:cp tc184 set from storage commerce:l tc
scoreboard players set #i c.t 185
function commerce:page/ligne
data modify storage commerce:cp ve185 set from storage commerce:l ve
data modify storage commerce:cp vz185 set from storage commerce:l vz
data modify storage commerce:cp vc185 set from storage commerce:l vc
data modify storage commerce:cp ae185 set from storage commerce:l ae
data modify storage commerce:cp az185 set from storage commerce:l az
data modify storage commerce:cp ac185 set from storage commerce:l ac
data modify storage commerce:cp t185 set from storage commerce:l t
data modify storage commerce:cp tc185 set from storage commerce:l tc
scoreboard players set #i c.t 186
function commerce:page/ligne
data modify storage commerce:cp ve186 set from storage commerce:l ve
data modify storage commerce:cp vz186 set from storage commerce:l vz
data modify storage commerce:cp vc186 set from storage commerce:l vc
data modify storage commerce:cp ae186 set from storage commerce:l ae
data modify storage commerce:cp az186 set from storage commerce:l az
data modify storage commerce:cp ac186 set from storage commerce:l ac
data modify storage commerce:cp t186 set from storage commerce:l t
data modify storage commerce:cp tc186 set from storage commerce:l tc
function commerce:page/cat_6_d with storage commerce:cp
