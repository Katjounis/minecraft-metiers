function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 395
function commerce:page/ligne
data modify storage commerce:cp ve395 set from storage commerce:l ve
data modify storage commerce:cp vz395 set from storage commerce:l vz
data modify storage commerce:cp vc395 set from storage commerce:l vc
data modify storage commerce:cp ae395 set from storage commerce:l ae
data modify storage commerce:cp az395 set from storage commerce:l az
data modify storage commerce:cp ac395 set from storage commerce:l ac
data modify storage commerce:cp t395 set from storage commerce:l t
scoreboard players set #i c.t 36
function commerce:page/ligne
data modify storage commerce:cp ve36 set from storage commerce:l ve
data modify storage commerce:cp vz36 set from storage commerce:l vz
data modify storage commerce:cp vc36 set from storage commerce:l vc
data modify storage commerce:cp ae36 set from storage commerce:l ae
data modify storage commerce:cp az36 set from storage commerce:l az
data modify storage commerce:cp ac36 set from storage commerce:l ac
data modify storage commerce:cp t36 set from storage commerce:l t
scoreboard players set #i c.t 37
function commerce:page/ligne
data modify storage commerce:cp ve37 set from storage commerce:l ve
data modify storage commerce:cp vz37 set from storage commerce:l vz
data modify storage commerce:cp vc37 set from storage commerce:l vc
data modify storage commerce:cp ae37 set from storage commerce:l ae
data modify storage commerce:cp az37 set from storage commerce:l az
data modify storage commerce:cp ac37 set from storage commerce:l ac
data modify storage commerce:cp t37 set from storage commerce:l t
scoreboard players set #i c.t 468
function commerce:page/ligne
data modify storage commerce:cp ve468 set from storage commerce:l ve
data modify storage commerce:cp vz468 set from storage commerce:l vz
data modify storage commerce:cp vc468 set from storage commerce:l vc
data modify storage commerce:cp ae468 set from storage commerce:l ae
data modify storage commerce:cp az468 set from storage commerce:l az
data modify storage commerce:cp ac468 set from storage commerce:l ac
data modify storage commerce:cp t468 set from storage commerce:l t
scoreboard players set #i c.t 57
function commerce:page/ligne
data modify storage commerce:cp ve57 set from storage commerce:l ve
data modify storage commerce:cp vz57 set from storage commerce:l vz
data modify storage commerce:cp vc57 set from storage commerce:l vc
data modify storage commerce:cp ae57 set from storage commerce:l ae
data modify storage commerce:cp az57 set from storage commerce:l az
data modify storage commerce:cp ac57 set from storage commerce:l ac
data modify storage commerce:cp t57 set from storage commerce:l t
scoreboard players set #i c.t 326
function commerce:page/ligne
data modify storage commerce:cp ve326 set from storage commerce:l ve
data modify storage commerce:cp vz326 set from storage commerce:l vz
data modify storage commerce:cp vc326 set from storage commerce:l vc
data modify storage commerce:cp ae326 set from storage commerce:l ae
data modify storage commerce:cp az326 set from storage commerce:l az
data modify storage commerce:cp ac326 set from storage commerce:l ac
data modify storage commerce:cp t326 set from storage commerce:l t
scoreboard players set #i c.t 34
function commerce:page/ligne
data modify storage commerce:cp ve34 set from storage commerce:l ve
data modify storage commerce:cp vz34 set from storage commerce:l vz
data modify storage commerce:cp vc34 set from storage commerce:l vc
data modify storage commerce:cp ae34 set from storage commerce:l ae
data modify storage commerce:cp az34 set from storage commerce:l az
data modify storage commerce:cp ac34 set from storage commerce:l ac
data modify storage commerce:cp t34 set from storage commerce:l t
scoreboard players set #i c.t 251
function commerce:page/ligne
data modify storage commerce:cp ve251 set from storage commerce:l ve
data modify storage commerce:cp vz251 set from storage commerce:l vz
data modify storage commerce:cp vc251 set from storage commerce:l vc
data modify storage commerce:cp ae251 set from storage commerce:l ae
data modify storage commerce:cp az251 set from storage commerce:l az
data modify storage commerce:cp ac251 set from storage commerce:l ac
data modify storage commerce:cp t251 set from storage commerce:l t
scoreboard players set #i c.t 35
function commerce:page/ligne
data modify storage commerce:cp ve35 set from storage commerce:l ve
data modify storage commerce:cp vz35 set from storage commerce:l vz
data modify storage commerce:cp vc35 set from storage commerce:l vc
data modify storage commerce:cp ae35 set from storage commerce:l ae
data modify storage commerce:cp az35 set from storage commerce:l az
data modify storage commerce:cp ac35 set from storage commerce:l ac
data modify storage commerce:cp t35 set from storage commerce:l t
scoreboard players set #i c.t 18
function commerce:page/ligne
data modify storage commerce:cp ve18 set from storage commerce:l ve
data modify storage commerce:cp vz18 set from storage commerce:l vz
data modify storage commerce:cp vc18 set from storage commerce:l vc
data modify storage commerce:cp ae18 set from storage commerce:l ae
data modify storage commerce:cp az18 set from storage commerce:l az
data modify storage commerce:cp ac18 set from storage commerce:l ac
data modify storage commerce:cp t18 set from storage commerce:l t
function commerce:page/lettre_b_6_d with storage commerce:cp
