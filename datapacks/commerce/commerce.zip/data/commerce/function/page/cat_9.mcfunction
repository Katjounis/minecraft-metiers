function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 118
function commerce:page/ligne
data modify storage commerce:cp ve118 set from storage commerce:l ve
data modify storage commerce:cp vz118 set from storage commerce:l vz
data modify storage commerce:cp vc118 set from storage commerce:l vc
data modify storage commerce:cp ae118 set from storage commerce:l ae
data modify storage commerce:cp az118 set from storage commerce:l az
data modify storage commerce:cp ac118 set from storage commerce:l ac
data modify storage commerce:cp t118 set from storage commerce:l t
data modify storage commerce:cp tc118 set from storage commerce:l tc
scoreboard players set #i c.t 119
function commerce:page/ligne
data modify storage commerce:cp ve119 set from storage commerce:l ve
data modify storage commerce:cp vz119 set from storage commerce:l vz
data modify storage commerce:cp vc119 set from storage commerce:l vc
data modify storage commerce:cp ae119 set from storage commerce:l ae
data modify storage commerce:cp az119 set from storage commerce:l az
data modify storage commerce:cp ac119 set from storage commerce:l ac
data modify storage commerce:cp t119 set from storage commerce:l t
data modify storage commerce:cp tc119 set from storage commerce:l tc
scoreboard players set #i c.t 120
function commerce:page/ligne
data modify storage commerce:cp ve120 set from storage commerce:l ve
data modify storage commerce:cp vz120 set from storage commerce:l vz
data modify storage commerce:cp vc120 set from storage commerce:l vc
data modify storage commerce:cp ae120 set from storage commerce:l ae
data modify storage commerce:cp az120 set from storage commerce:l az
data modify storage commerce:cp ac120 set from storage commerce:l ac
data modify storage commerce:cp t120 set from storage commerce:l t
data modify storage commerce:cp tc120 set from storage commerce:l tc
scoreboard players set #i c.t 121
function commerce:page/ligne
data modify storage commerce:cp ve121 set from storage commerce:l ve
data modify storage commerce:cp vz121 set from storage commerce:l vz
data modify storage commerce:cp vc121 set from storage commerce:l vc
data modify storage commerce:cp ae121 set from storage commerce:l ae
data modify storage commerce:cp az121 set from storage commerce:l az
data modify storage commerce:cp ac121 set from storage commerce:l ac
data modify storage commerce:cp t121 set from storage commerce:l t
data modify storage commerce:cp tc121 set from storage commerce:l tc
scoreboard players set #i c.t 122
function commerce:page/ligne
data modify storage commerce:cp ve122 set from storage commerce:l ve
data modify storage commerce:cp vz122 set from storage commerce:l vz
data modify storage commerce:cp vc122 set from storage commerce:l vc
data modify storage commerce:cp ae122 set from storage commerce:l ae
data modify storage commerce:cp az122 set from storage commerce:l az
data modify storage commerce:cp ac122 set from storage commerce:l ac
data modify storage commerce:cp t122 set from storage commerce:l t
data modify storage commerce:cp tc122 set from storage commerce:l tc
scoreboard players set #i c.t 123
function commerce:page/ligne
data modify storage commerce:cp ve123 set from storage commerce:l ve
data modify storage commerce:cp vz123 set from storage commerce:l vz
data modify storage commerce:cp vc123 set from storage commerce:l vc
data modify storage commerce:cp ae123 set from storage commerce:l ae
data modify storage commerce:cp az123 set from storage commerce:l az
data modify storage commerce:cp ac123 set from storage commerce:l ac
data modify storage commerce:cp t123 set from storage commerce:l t
data modify storage commerce:cp tc123 set from storage commerce:l tc
scoreboard players set #i c.t 124
function commerce:page/ligne
data modify storage commerce:cp ve124 set from storage commerce:l ve
data modify storage commerce:cp vz124 set from storage commerce:l vz
data modify storage commerce:cp vc124 set from storage commerce:l vc
data modify storage commerce:cp ae124 set from storage commerce:l ae
data modify storage commerce:cp az124 set from storage commerce:l az
data modify storage commerce:cp ac124 set from storage commerce:l ac
data modify storage commerce:cp t124 set from storage commerce:l t
data modify storage commerce:cp tc124 set from storage commerce:l tc
scoreboard players set #i c.t 125
function commerce:page/ligne
data modify storage commerce:cp ve125 set from storage commerce:l ve
data modify storage commerce:cp vz125 set from storage commerce:l vz
data modify storage commerce:cp vc125 set from storage commerce:l vc
data modify storage commerce:cp ae125 set from storage commerce:l ae
data modify storage commerce:cp az125 set from storage commerce:l az
data modify storage commerce:cp ac125 set from storage commerce:l ac
data modify storage commerce:cp t125 set from storage commerce:l t
data modify storage commerce:cp tc125 set from storage commerce:l tc
scoreboard players set #i c.t 126
function commerce:page/ligne
data modify storage commerce:cp ve126 set from storage commerce:l ve
data modify storage commerce:cp vz126 set from storage commerce:l vz
data modify storage commerce:cp vc126 set from storage commerce:l vc
data modify storage commerce:cp ae126 set from storage commerce:l ae
data modify storage commerce:cp az126 set from storage commerce:l az
data modify storage commerce:cp ac126 set from storage commerce:l ac
data modify storage commerce:cp t126 set from storage commerce:l t
data modify storage commerce:cp tc126 set from storage commerce:l tc
scoreboard players set #i c.t 127
function commerce:page/ligne
data modify storage commerce:cp ve127 set from storage commerce:l ve
data modify storage commerce:cp vz127 set from storage commerce:l vz
data modify storage commerce:cp vc127 set from storage commerce:l vc
data modify storage commerce:cp ae127 set from storage commerce:l ae
data modify storage commerce:cp az127 set from storage commerce:l az
data modify storage commerce:cp ac127 set from storage commerce:l ac
data modify storage commerce:cp t127 set from storage commerce:l t
data modify storage commerce:cp tc127 set from storage commerce:l tc
scoreboard players set #i c.t 128
function commerce:page/ligne
data modify storage commerce:cp ve128 set from storage commerce:l ve
data modify storage commerce:cp vz128 set from storage commerce:l vz
data modify storage commerce:cp vc128 set from storage commerce:l vc
data modify storage commerce:cp ae128 set from storage commerce:l ae
data modify storage commerce:cp az128 set from storage commerce:l az
data modify storage commerce:cp ac128 set from storage commerce:l ac
data modify storage commerce:cp t128 set from storage commerce:l t
data modify storage commerce:cp tc128 set from storage commerce:l tc
scoreboard players set #i c.t 129
function commerce:page/ligne
data modify storage commerce:cp ve129 set from storage commerce:l ve
data modify storage commerce:cp vz129 set from storage commerce:l vz
data modify storage commerce:cp vc129 set from storage commerce:l vc
data modify storage commerce:cp ae129 set from storage commerce:l ae
data modify storage commerce:cp az129 set from storage commerce:l az
data modify storage commerce:cp ac129 set from storage commerce:l ac
data modify storage commerce:cp t129 set from storage commerce:l t
data modify storage commerce:cp tc129 set from storage commerce:l tc
scoreboard players set #i c.t 130
function commerce:page/ligne
data modify storage commerce:cp ve130 set from storage commerce:l ve
data modify storage commerce:cp vz130 set from storage commerce:l vz
data modify storage commerce:cp vc130 set from storage commerce:l vc
data modify storage commerce:cp ae130 set from storage commerce:l ae
data modify storage commerce:cp az130 set from storage commerce:l az
data modify storage commerce:cp ac130 set from storage commerce:l ac
data modify storage commerce:cp t130 set from storage commerce:l t
data modify storage commerce:cp tc130 set from storage commerce:l tc
scoreboard players set #i c.t 131
function commerce:page/ligne
data modify storage commerce:cp ve131 set from storage commerce:l ve
data modify storage commerce:cp vz131 set from storage commerce:l vz
data modify storage commerce:cp vc131 set from storage commerce:l vc
data modify storage commerce:cp ae131 set from storage commerce:l ae
data modify storage commerce:cp az131 set from storage commerce:l az
data modify storage commerce:cp ac131 set from storage commerce:l ac
data modify storage commerce:cp t131 set from storage commerce:l t
data modify storage commerce:cp tc131 set from storage commerce:l tc
scoreboard players set #i c.t 132
function commerce:page/ligne
data modify storage commerce:cp ve132 set from storage commerce:l ve
data modify storage commerce:cp vz132 set from storage commerce:l vz
data modify storage commerce:cp vc132 set from storage commerce:l vc
data modify storage commerce:cp ae132 set from storage commerce:l ae
data modify storage commerce:cp az132 set from storage commerce:l az
data modify storage commerce:cp ac132 set from storage commerce:l ac
data modify storage commerce:cp t132 set from storage commerce:l t
data modify storage commerce:cp tc132 set from storage commerce:l tc
scoreboard players set #i c.t 133
function commerce:page/ligne
data modify storage commerce:cp ve133 set from storage commerce:l ve
data modify storage commerce:cp vz133 set from storage commerce:l vz
data modify storage commerce:cp vc133 set from storage commerce:l vc
data modify storage commerce:cp ae133 set from storage commerce:l ae
data modify storage commerce:cp az133 set from storage commerce:l az
data modify storage commerce:cp ac133 set from storage commerce:l ac
data modify storage commerce:cp t133 set from storage commerce:l t
data modify storage commerce:cp tc133 set from storage commerce:l tc
function commerce:page/cat_9_d with storage commerce:cp
