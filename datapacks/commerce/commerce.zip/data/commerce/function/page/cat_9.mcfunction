function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 250
function commerce:page/ligne
data modify storage commerce:cp ve250 set from storage commerce:l ve
data modify storage commerce:cp vz250 set from storage commerce:l vz
data modify storage commerce:cp vc250 set from storage commerce:l vc
data modify storage commerce:cp ae250 set from storage commerce:l ae
data modify storage commerce:cp az250 set from storage commerce:l az
data modify storage commerce:cp ac250 set from storage commerce:l ac
data modify storage commerce:cp t250 set from storage commerce:l t
data modify storage commerce:cp tc250 set from storage commerce:l tc
scoreboard players set #i c.t 251
function commerce:page/ligne
data modify storage commerce:cp ve251 set from storage commerce:l ve
data modify storage commerce:cp vz251 set from storage commerce:l vz
data modify storage commerce:cp vc251 set from storage commerce:l vc
data modify storage commerce:cp ae251 set from storage commerce:l ae
data modify storage commerce:cp az251 set from storage commerce:l az
data modify storage commerce:cp ac251 set from storage commerce:l ac
data modify storage commerce:cp t251 set from storage commerce:l t
data modify storage commerce:cp tc251 set from storage commerce:l tc
scoreboard players set #i c.t 252
function commerce:page/ligne
data modify storage commerce:cp ve252 set from storage commerce:l ve
data modify storage commerce:cp vz252 set from storage commerce:l vz
data modify storage commerce:cp vc252 set from storage commerce:l vc
data modify storage commerce:cp ae252 set from storage commerce:l ae
data modify storage commerce:cp az252 set from storage commerce:l az
data modify storage commerce:cp ac252 set from storage commerce:l ac
data modify storage commerce:cp t252 set from storage commerce:l t
data modify storage commerce:cp tc252 set from storage commerce:l tc
scoreboard players set #i c.t 253
function commerce:page/ligne
data modify storage commerce:cp ve253 set from storage commerce:l ve
data modify storage commerce:cp vz253 set from storage commerce:l vz
data modify storage commerce:cp vc253 set from storage commerce:l vc
data modify storage commerce:cp ae253 set from storage commerce:l ae
data modify storage commerce:cp az253 set from storage commerce:l az
data modify storage commerce:cp ac253 set from storage commerce:l ac
data modify storage commerce:cp t253 set from storage commerce:l t
data modify storage commerce:cp tc253 set from storage commerce:l tc
scoreboard players set #i c.t 254
function commerce:page/ligne
data modify storage commerce:cp ve254 set from storage commerce:l ve
data modify storage commerce:cp vz254 set from storage commerce:l vz
data modify storage commerce:cp vc254 set from storage commerce:l vc
data modify storage commerce:cp ae254 set from storage commerce:l ae
data modify storage commerce:cp az254 set from storage commerce:l az
data modify storage commerce:cp ac254 set from storage commerce:l ac
data modify storage commerce:cp t254 set from storage commerce:l t
data modify storage commerce:cp tc254 set from storage commerce:l tc
scoreboard players set #i c.t 255
function commerce:page/ligne
data modify storage commerce:cp ve255 set from storage commerce:l ve
data modify storage commerce:cp vz255 set from storage commerce:l vz
data modify storage commerce:cp vc255 set from storage commerce:l vc
data modify storage commerce:cp ae255 set from storage commerce:l ae
data modify storage commerce:cp az255 set from storage commerce:l az
data modify storage commerce:cp ac255 set from storage commerce:l ac
data modify storage commerce:cp t255 set from storage commerce:l t
data modify storage commerce:cp tc255 set from storage commerce:l tc
scoreboard players set #i c.t 256
function commerce:page/ligne
data modify storage commerce:cp ve256 set from storage commerce:l ve
data modify storage commerce:cp vz256 set from storage commerce:l vz
data modify storage commerce:cp vc256 set from storage commerce:l vc
data modify storage commerce:cp ae256 set from storage commerce:l ae
data modify storage commerce:cp az256 set from storage commerce:l az
data modify storage commerce:cp ac256 set from storage commerce:l ac
data modify storage commerce:cp t256 set from storage commerce:l t
data modify storage commerce:cp tc256 set from storage commerce:l tc
scoreboard players set #i c.t 257
function commerce:page/ligne
data modify storage commerce:cp ve257 set from storage commerce:l ve
data modify storage commerce:cp vz257 set from storage commerce:l vz
data modify storage commerce:cp vc257 set from storage commerce:l vc
data modify storage commerce:cp ae257 set from storage commerce:l ae
data modify storage commerce:cp az257 set from storage commerce:l az
data modify storage commerce:cp ac257 set from storage commerce:l ac
data modify storage commerce:cp t257 set from storage commerce:l t
data modify storage commerce:cp tc257 set from storage commerce:l tc
scoreboard players set #i c.t 258
function commerce:page/ligne
data modify storage commerce:cp ve258 set from storage commerce:l ve
data modify storage commerce:cp vz258 set from storage commerce:l vz
data modify storage commerce:cp vc258 set from storage commerce:l vc
data modify storage commerce:cp ae258 set from storage commerce:l ae
data modify storage commerce:cp az258 set from storage commerce:l az
data modify storage commerce:cp ac258 set from storage commerce:l ac
data modify storage commerce:cp t258 set from storage commerce:l t
data modify storage commerce:cp tc258 set from storage commerce:l tc
scoreboard players set #i c.t 259
function commerce:page/ligne
data modify storage commerce:cp ve259 set from storage commerce:l ve
data modify storage commerce:cp vz259 set from storage commerce:l vz
data modify storage commerce:cp vc259 set from storage commerce:l vc
data modify storage commerce:cp ae259 set from storage commerce:l ae
data modify storage commerce:cp az259 set from storage commerce:l az
data modify storage commerce:cp ac259 set from storage commerce:l ac
data modify storage commerce:cp t259 set from storage commerce:l t
data modify storage commerce:cp tc259 set from storage commerce:l tc
scoreboard players set #i c.t 260
function commerce:page/ligne
data modify storage commerce:cp ve260 set from storage commerce:l ve
data modify storage commerce:cp vz260 set from storage commerce:l vz
data modify storage commerce:cp vc260 set from storage commerce:l vc
data modify storage commerce:cp ae260 set from storage commerce:l ae
data modify storage commerce:cp az260 set from storage commerce:l az
data modify storage commerce:cp ac260 set from storage commerce:l ac
data modify storage commerce:cp t260 set from storage commerce:l t
data modify storage commerce:cp tc260 set from storage commerce:l tc
scoreboard players set #i c.t 261
function commerce:page/ligne
data modify storage commerce:cp ve261 set from storage commerce:l ve
data modify storage commerce:cp vz261 set from storage commerce:l vz
data modify storage commerce:cp vc261 set from storage commerce:l vc
data modify storage commerce:cp ae261 set from storage commerce:l ae
data modify storage commerce:cp az261 set from storage commerce:l az
data modify storage commerce:cp ac261 set from storage commerce:l ac
data modify storage commerce:cp t261 set from storage commerce:l t
data modify storage commerce:cp tc261 set from storage commerce:l tc
scoreboard players set #i c.t 262
function commerce:page/ligne
data modify storage commerce:cp ve262 set from storage commerce:l ve
data modify storage commerce:cp vz262 set from storage commerce:l vz
data modify storage commerce:cp vc262 set from storage commerce:l vc
data modify storage commerce:cp ae262 set from storage commerce:l ae
data modify storage commerce:cp az262 set from storage commerce:l az
data modify storage commerce:cp ac262 set from storage commerce:l ac
data modify storage commerce:cp t262 set from storage commerce:l t
data modify storage commerce:cp tc262 set from storage commerce:l tc
scoreboard players set #i c.t 263
function commerce:page/ligne
data modify storage commerce:cp ve263 set from storage commerce:l ve
data modify storage commerce:cp vz263 set from storage commerce:l vz
data modify storage commerce:cp vc263 set from storage commerce:l vc
data modify storage commerce:cp ae263 set from storage commerce:l ae
data modify storage commerce:cp az263 set from storage commerce:l az
data modify storage commerce:cp ac263 set from storage commerce:l ac
data modify storage commerce:cp t263 set from storage commerce:l t
data modify storage commerce:cp tc263 set from storage commerce:l tc
scoreboard players set #i c.t 264
function commerce:page/ligne
data modify storage commerce:cp ve264 set from storage commerce:l ve
data modify storage commerce:cp vz264 set from storage commerce:l vz
data modify storage commerce:cp vc264 set from storage commerce:l vc
data modify storage commerce:cp ae264 set from storage commerce:l ae
data modify storage commerce:cp az264 set from storage commerce:l az
data modify storage commerce:cp ac264 set from storage commerce:l ac
data modify storage commerce:cp t264 set from storage commerce:l t
data modify storage commerce:cp tc264 set from storage commerce:l tc
scoreboard players set #i c.t 265
function commerce:page/ligne
data modify storage commerce:cp ve265 set from storage commerce:l ve
data modify storage commerce:cp vz265 set from storage commerce:l vz
data modify storage commerce:cp vc265 set from storage commerce:l vc
data modify storage commerce:cp ae265 set from storage commerce:l ae
data modify storage commerce:cp az265 set from storage commerce:l az
data modify storage commerce:cp ac265 set from storage commerce:l ac
data modify storage commerce:cp t265 set from storage commerce:l t
data modify storage commerce:cp tc265 set from storage commerce:l tc
scoreboard players set #i c.t 266
function commerce:page/ligne
data modify storage commerce:cp ve266 set from storage commerce:l ve
data modify storage commerce:cp vz266 set from storage commerce:l vz
data modify storage commerce:cp vc266 set from storage commerce:l vc
data modify storage commerce:cp ae266 set from storage commerce:l ae
data modify storage commerce:cp az266 set from storage commerce:l az
data modify storage commerce:cp ac266 set from storage commerce:l ac
data modify storage commerce:cp t266 set from storage commerce:l t
data modify storage commerce:cp tc266 set from storage commerce:l tc
scoreboard players set #i c.t 267
function commerce:page/ligne
data modify storage commerce:cp ve267 set from storage commerce:l ve
data modify storage commerce:cp vz267 set from storage commerce:l vz
data modify storage commerce:cp vc267 set from storage commerce:l vc
data modify storage commerce:cp ae267 set from storage commerce:l ae
data modify storage commerce:cp az267 set from storage commerce:l az
data modify storage commerce:cp ac267 set from storage commerce:l ac
data modify storage commerce:cp t267 set from storage commerce:l t
data modify storage commerce:cp tc267 set from storage commerce:l tc
scoreboard players set #i c.t 268
function commerce:page/ligne
data modify storage commerce:cp ve268 set from storage commerce:l ve
data modify storage commerce:cp vz268 set from storage commerce:l vz
data modify storage commerce:cp vc268 set from storage commerce:l vc
data modify storage commerce:cp ae268 set from storage commerce:l ae
data modify storage commerce:cp az268 set from storage commerce:l az
data modify storage commerce:cp ac268 set from storage commerce:l ac
data modify storage commerce:cp t268 set from storage commerce:l t
data modify storage commerce:cp tc268 set from storage commerce:l tc
scoreboard players set #i c.t 269
function commerce:page/ligne
data modify storage commerce:cp ve269 set from storage commerce:l ve
data modify storage commerce:cp vz269 set from storage commerce:l vz
data modify storage commerce:cp vc269 set from storage commerce:l vc
data modify storage commerce:cp ae269 set from storage commerce:l ae
data modify storage commerce:cp az269 set from storage commerce:l az
data modify storage commerce:cp ac269 set from storage commerce:l ac
data modify storage commerce:cp t269 set from storage commerce:l t
data modify storage commerce:cp tc269 set from storage commerce:l tc
scoreboard players set #i c.t 270
function commerce:page/ligne
data modify storage commerce:cp ve270 set from storage commerce:l ve
data modify storage commerce:cp vz270 set from storage commerce:l vz
data modify storage commerce:cp vc270 set from storage commerce:l vc
data modify storage commerce:cp ae270 set from storage commerce:l ae
data modify storage commerce:cp az270 set from storage commerce:l az
data modify storage commerce:cp ac270 set from storage commerce:l ac
data modify storage commerce:cp t270 set from storage commerce:l t
data modify storage commerce:cp tc270 set from storage commerce:l tc
scoreboard players set #i c.t 271
function commerce:page/ligne
data modify storage commerce:cp ve271 set from storage commerce:l ve
data modify storage commerce:cp vz271 set from storage commerce:l vz
data modify storage commerce:cp vc271 set from storage commerce:l vc
data modify storage commerce:cp ae271 set from storage commerce:l ae
data modify storage commerce:cp az271 set from storage commerce:l az
data modify storage commerce:cp ac271 set from storage commerce:l ac
data modify storage commerce:cp t271 set from storage commerce:l t
data modify storage commerce:cp tc271 set from storage commerce:l tc
scoreboard players set #i c.t 272
function commerce:page/ligne
data modify storage commerce:cp ve272 set from storage commerce:l ve
data modify storage commerce:cp vz272 set from storage commerce:l vz
data modify storage commerce:cp vc272 set from storage commerce:l vc
data modify storage commerce:cp ae272 set from storage commerce:l ae
data modify storage commerce:cp az272 set from storage commerce:l az
data modify storage commerce:cp ac272 set from storage commerce:l ac
data modify storage commerce:cp t272 set from storage commerce:l t
data modify storage commerce:cp tc272 set from storage commerce:l tc
scoreboard players set #i c.t 273
function commerce:page/ligne
data modify storage commerce:cp ve273 set from storage commerce:l ve
data modify storage commerce:cp vz273 set from storage commerce:l vz
data modify storage commerce:cp vc273 set from storage commerce:l vc
data modify storage commerce:cp ae273 set from storage commerce:l ae
data modify storage commerce:cp az273 set from storage commerce:l az
data modify storage commerce:cp ac273 set from storage commerce:l ac
data modify storage commerce:cp t273 set from storage commerce:l t
data modify storage commerce:cp tc273 set from storage commerce:l tc
scoreboard players set #i c.t 274
function commerce:page/ligne
data modify storage commerce:cp ve274 set from storage commerce:l ve
data modify storage commerce:cp vz274 set from storage commerce:l vz
data modify storage commerce:cp vc274 set from storage commerce:l vc
data modify storage commerce:cp ae274 set from storage commerce:l ae
data modify storage commerce:cp az274 set from storage commerce:l az
data modify storage commerce:cp ac274 set from storage commerce:l ac
data modify storage commerce:cp t274 set from storage commerce:l t
data modify storage commerce:cp tc274 set from storage commerce:l tc
scoreboard players set #i c.t 275
function commerce:page/ligne
data modify storage commerce:cp ve275 set from storage commerce:l ve
data modify storage commerce:cp vz275 set from storage commerce:l vz
data modify storage commerce:cp vc275 set from storage commerce:l vc
data modify storage commerce:cp ae275 set from storage commerce:l ae
data modify storage commerce:cp az275 set from storage commerce:l az
data modify storage commerce:cp ac275 set from storage commerce:l ac
data modify storage commerce:cp t275 set from storage commerce:l t
data modify storage commerce:cp tc275 set from storage commerce:l tc
scoreboard players set #i c.t 276
function commerce:page/ligne
data modify storage commerce:cp ve276 set from storage commerce:l ve
data modify storage commerce:cp vz276 set from storage commerce:l vz
data modify storage commerce:cp vc276 set from storage commerce:l vc
data modify storage commerce:cp ae276 set from storage commerce:l ae
data modify storage commerce:cp az276 set from storage commerce:l az
data modify storage commerce:cp ac276 set from storage commerce:l ac
data modify storage commerce:cp t276 set from storage commerce:l t
data modify storage commerce:cp tc276 set from storage commerce:l tc
scoreboard players set #i c.t 277
function commerce:page/ligne
data modify storage commerce:cp ve277 set from storage commerce:l ve
data modify storage commerce:cp vz277 set from storage commerce:l vz
data modify storage commerce:cp vc277 set from storage commerce:l vc
data modify storage commerce:cp ae277 set from storage commerce:l ae
data modify storage commerce:cp az277 set from storage commerce:l az
data modify storage commerce:cp ac277 set from storage commerce:l ac
data modify storage commerce:cp t277 set from storage commerce:l t
data modify storage commerce:cp tc277 set from storage commerce:l tc
scoreboard players set #i c.t 278
function commerce:page/ligne
data modify storage commerce:cp ve278 set from storage commerce:l ve
data modify storage commerce:cp vz278 set from storage commerce:l vz
data modify storage commerce:cp vc278 set from storage commerce:l vc
data modify storage commerce:cp ae278 set from storage commerce:l ae
data modify storage commerce:cp az278 set from storage commerce:l az
data modify storage commerce:cp ac278 set from storage commerce:l ac
data modify storage commerce:cp t278 set from storage commerce:l t
data modify storage commerce:cp tc278 set from storage commerce:l tc
function commerce:page/cat_9_d with storage commerce:cp
