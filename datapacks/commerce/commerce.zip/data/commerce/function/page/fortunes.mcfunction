function commerce:rang/calcul {obj:"c.ecus",n:10}
function commerce:fmt/solde
data modify storage commerce:r se set from storage commerce:t s.e
data modify storage commerce:r sz set from storage commerce:t s.z
data modify storage commerce:r sc set from storage commerce:t s.c
function commerce:page/fortunes_d with storage commerce:r
