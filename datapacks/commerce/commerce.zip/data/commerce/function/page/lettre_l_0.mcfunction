function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 122
function commerce:page/ligne
data modify storage commerce:cp ve122 set from storage commerce:l ve
data modify storage commerce:cp vz122 set from storage commerce:l vz
data modify storage commerce:cp vc122 set from storage commerce:l vc
data modify storage commerce:cp ae122 set from storage commerce:l ae
data modify storage commerce:cp az122 set from storage commerce:l az
data modify storage commerce:cp ac122 set from storage commerce:l ac
data modify storage commerce:cp t122 set from storage commerce:l t
scoreboard players set #i c.t 125
function commerce:page/ligne
data modify storage commerce:cp ve125 set from storage commerce:l ve
data modify storage commerce:cp vz125 set from storage commerce:l vz
data modify storage commerce:cp vc125 set from storage commerce:l vc
data modify storage commerce:cp ae125 set from storage commerce:l ae
data modify storage commerce:cp az125 set from storage commerce:l az
data modify storage commerce:cp ac125 set from storage commerce:l ac
data modify storage commerce:cp t125 set from storage commerce:l t
scoreboard players set #i c.t 133
function commerce:page/ligne
data modify storage commerce:cp ve133 set from storage commerce:l ve
data modify storage commerce:cp vz133 set from storage commerce:l vz
data modify storage commerce:cp vc133 set from storage commerce:l vc
data modify storage commerce:cp ae133 set from storage commerce:l ae
data modify storage commerce:cp az133 set from storage commerce:l az
data modify storage commerce:cp ac133 set from storage commerce:l ac
data modify storage commerce:cp t133 set from storage commerce:l t
scoreboard players set #i c.t 131
function commerce:page/ligne
data modify storage commerce:cp ve131 set from storage commerce:l ve
data modify storage commerce:cp vz131 set from storage commerce:l vz
data modify storage commerce:cp vc131 set from storage commerce:l vc
data modify storage commerce:cp ae131 set from storage commerce:l ae
data modify storage commerce:cp az131 set from storage commerce:l az
data modify storage commerce:cp ac131 set from storage commerce:l ac
data modify storage commerce:cp t131 set from storage commerce:l t
scoreboard players set #i c.t 130
function commerce:page/ligne
data modify storage commerce:cp ve130 set from storage commerce:l ve
data modify storage commerce:cp vz130 set from storage commerce:l vz
data modify storage commerce:cp vc130 set from storage commerce:l vc
data modify storage commerce:cp ae130 set from storage commerce:l ae
data modify storage commerce:cp az130 set from storage commerce:l az
data modify storage commerce:cp ac130 set from storage commerce:l ac
data modify storage commerce:cp t130 set from storage commerce:l t
scoreboard players set #i c.t 129
function commerce:page/ligne
data modify storage commerce:cp ve129 set from storage commerce:l ve
data modify storage commerce:cp vz129 set from storage commerce:l vz
data modify storage commerce:cp vc129 set from storage commerce:l vc
data modify storage commerce:cp ae129 set from storage commerce:l ae
data modify storage commerce:cp az129 set from storage commerce:l az
data modify storage commerce:cp ac129 set from storage commerce:l ac
data modify storage commerce:cp t129 set from storage commerce:l t
scoreboard players set #i c.t 126
function commerce:page/ligne
data modify storage commerce:cp ve126 set from storage commerce:l ve
data modify storage commerce:cp vz126 set from storage commerce:l vz
data modify storage commerce:cp vc126 set from storage commerce:l vc
data modify storage commerce:cp ae126 set from storage commerce:l ae
data modify storage commerce:cp az126 set from storage commerce:l az
data modify storage commerce:cp ac126 set from storage commerce:l ac
data modify storage commerce:cp t126 set from storage commerce:l t
scoreboard players set #i c.t 124
function commerce:page/ligne
data modify storage commerce:cp ve124 set from storage commerce:l ve
data modify storage commerce:cp vz124 set from storage commerce:l vz
data modify storage commerce:cp vc124 set from storage commerce:l vc
data modify storage commerce:cp ae124 set from storage commerce:l ae
data modify storage commerce:cp az124 set from storage commerce:l az
data modify storage commerce:cp ac124 set from storage commerce:l ac
data modify storage commerce:cp t124 set from storage commerce:l t
scoreboard players set #i c.t 134
function commerce:page/ligne
data modify storage commerce:cp ve134 set from storage commerce:l ve
data modify storage commerce:cp vz134 set from storage commerce:l vz
data modify storage commerce:cp vc134 set from storage commerce:l vc
data modify storage commerce:cp ae134 set from storage commerce:l ae
data modify storage commerce:cp az134 set from storage commerce:l az
data modify storage commerce:cp ac134 set from storage commerce:l ac
data modify storage commerce:cp t134 set from storage commerce:l t
scoreboard players set #i c.t 137
function commerce:page/ligne
data modify storage commerce:cp ve137 set from storage commerce:l ve
data modify storage commerce:cp vz137 set from storage commerce:l vz
data modify storage commerce:cp vc137 set from storage commerce:l vc
data modify storage commerce:cp ae137 set from storage commerce:l ae
data modify storage commerce:cp az137 set from storage commerce:l az
data modify storage commerce:cp ac137 set from storage commerce:l ac
data modify storage commerce:cp t137 set from storage commerce:l t
function commerce:page/lettre_l_0_d with storage commerce:cp
