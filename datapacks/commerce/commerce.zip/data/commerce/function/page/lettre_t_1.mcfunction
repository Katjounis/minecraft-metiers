function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 153
function commerce:page/ligne
data modify storage commerce:cp ve153 set from storage commerce:l ve
data modify storage commerce:cp vz153 set from storage commerce:l vz
data modify storage commerce:cp vc153 set from storage commerce:l vc
data modify storage commerce:cp ae153 set from storage commerce:l ae
data modify storage commerce:cp az153 set from storage commerce:l az
data modify storage commerce:cp ac153 set from storage commerce:l ac
data modify storage commerce:cp t153 set from storage commerce:l t
scoreboard players set #i c.t 139
function commerce:page/ligne
data modify storage commerce:cp ve139 set from storage commerce:l ve
data modify storage commerce:cp vz139 set from storage commerce:l vz
data modify storage commerce:cp vc139 set from storage commerce:l vc
data modify storage commerce:cp ae139 set from storage commerce:l ae
data modify storage commerce:cp az139 set from storage commerce:l az
data modify storage commerce:cp ac139 set from storage commerce:l ac
data modify storage commerce:cp t139 set from storage commerce:l t
scoreboard players set #i c.t 144
function commerce:page/ligne
data modify storage commerce:cp ve144 set from storage commerce:l ve
data modify storage commerce:cp vz144 set from storage commerce:l vz
data modify storage commerce:cp vc144 set from storage commerce:l vc
data modify storage commerce:cp ae144 set from storage commerce:l ae
data modify storage commerce:cp az144 set from storage commerce:l az
data modify storage commerce:cp ac144 set from storage commerce:l ac
data modify storage commerce:cp t144 set from storage commerce:l t
scoreboard players set #i c.t 152
function commerce:page/ligne
data modify storage commerce:cp ve152 set from storage commerce:l ve
data modify storage commerce:cp vz152 set from storage commerce:l vz
data modify storage commerce:cp vc152 set from storage commerce:l vc
data modify storage commerce:cp ae152 set from storage commerce:l ae
data modify storage commerce:cp az152 set from storage commerce:l az
data modify storage commerce:cp ac152 set from storage commerce:l ac
data modify storage commerce:cp t152 set from storage commerce:l t
scoreboard players set #i c.t 143
function commerce:page/ligne
data modify storage commerce:cp ve143 set from storage commerce:l ve
data modify storage commerce:cp vz143 set from storage commerce:l vz
data modify storage commerce:cp vc143 set from storage commerce:l vc
data modify storage commerce:cp ae143 set from storage commerce:l ae
data modify storage commerce:cp az143 set from storage commerce:l az
data modify storage commerce:cp ac143 set from storage commerce:l ac
data modify storage commerce:cp t143 set from storage commerce:l t
scoreboard players set #i c.t 151
function commerce:page/ligne
data modify storage commerce:cp ve151 set from storage commerce:l ve
data modify storage commerce:cp vz151 set from storage commerce:l vz
data modify storage commerce:cp vc151 set from storage commerce:l vc
data modify storage commerce:cp ae151 set from storage commerce:l ae
data modify storage commerce:cp az151 set from storage commerce:l az
data modify storage commerce:cp ac151 set from storage commerce:l ac
data modify storage commerce:cp t151 set from storage commerce:l t
scoreboard players set #i c.t 148
function commerce:page/ligne
data modify storage commerce:cp ve148 set from storage commerce:l ve
data modify storage commerce:cp vz148 set from storage commerce:l vz
data modify storage commerce:cp vc148 set from storage commerce:l vc
data modify storage commerce:cp ae148 set from storage commerce:l ae
data modify storage commerce:cp az148 set from storage commerce:l az
data modify storage commerce:cp ac148 set from storage commerce:l ac
data modify storage commerce:cp t148 set from storage commerce:l t
scoreboard players set #i c.t 45
function commerce:page/ligne
data modify storage commerce:cp ve45 set from storage commerce:l ve
data modify storage commerce:cp vz45 set from storage commerce:l vz
data modify storage commerce:cp vc45 set from storage commerce:l vc
data modify storage commerce:cp ae45 set from storage commerce:l ae
data modify storage commerce:cp az45 set from storage commerce:l az
data modify storage commerce:cp ac45 set from storage commerce:l ac
data modify storage commerce:cp t45 set from storage commerce:l t
scoreboard players set #i c.t 170
function commerce:page/ligne
data modify storage commerce:cp ve170 set from storage commerce:l ve
data modify storage commerce:cp vz170 set from storage commerce:l vz
data modify storage commerce:cp vc170 set from storage commerce:l vc
data modify storage commerce:cp ae170 set from storage commerce:l ae
data modify storage commerce:cp az170 set from storage commerce:l az
data modify storage commerce:cp ac170 set from storage commerce:l ac
data modify storage commerce:cp t170 set from storage commerce:l t
scoreboard players set #i c.t 171
function commerce:page/ligne
data modify storage commerce:cp ve171 set from storage commerce:l ve
data modify storage commerce:cp vz171 set from storage commerce:l vz
data modify storage commerce:cp vc171 set from storage commerce:l vc
data modify storage commerce:cp ae171 set from storage commerce:l ae
data modify storage commerce:cp az171 set from storage commerce:l az
data modify storage commerce:cp ac171 set from storage commerce:l ac
data modify storage commerce:cp t171 set from storage commerce:l t
function commerce:page/lettre_t_1_d with storage commerce:cp
