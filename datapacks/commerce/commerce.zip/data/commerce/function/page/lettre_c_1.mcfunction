function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 248
function commerce:page/ligne
data modify storage commerce:cp ve248 set from storage commerce:l ve
data modify storage commerce:cp vz248 set from storage commerce:l vz
data modify storage commerce:cp vc248 set from storage commerce:l vc
data modify storage commerce:cp ae248 set from storage commerce:l ae
data modify storage commerce:cp az248 set from storage commerce:l az
data modify storage commerce:cp ac248 set from storage commerce:l ac
data modify storage commerce:cp t248 set from storage commerce:l t
scoreboard players set #i c.t 118
function commerce:page/ligne
data modify storage commerce:cp ve118 set from storage commerce:l ve
data modify storage commerce:cp vz118 set from storage commerce:l vz
data modify storage commerce:cp vc118 set from storage commerce:l vc
data modify storage commerce:cp ae118 set from storage commerce:l ae
data modify storage commerce:cp az118 set from storage commerce:l az
data modify storage commerce:cp ac118 set from storage commerce:l ac
data modify storage commerce:cp t118 set from storage commerce:l t
scoreboard players set #i c.t 426
function commerce:page/ligne
data modify storage commerce:cp ve426 set from storage commerce:l ve
data modify storage commerce:cp vz426 set from storage commerce:l vz
data modify storage commerce:cp vc426 set from storage commerce:l vc
data modify storage commerce:cp ae426 set from storage commerce:l ae
data modify storage commerce:cp az426 set from storage commerce:l az
data modify storage commerce:cp ac426 set from storage commerce:l ac
data modify storage commerce:cp t426 set from storage commerce:l t
scoreboard players set #i c.t 116
function commerce:page/ligne
data modify storage commerce:cp ve116 set from storage commerce:l ve
data modify storage commerce:cp vz116 set from storage commerce:l vz
data modify storage commerce:cp vc116 set from storage commerce:l vc
data modify storage commerce:cp ae116 set from storage commerce:l ae
data modify storage commerce:cp az116 set from storage commerce:l az
data modify storage commerce:cp ac116 set from storage commerce:l ac
data modify storage commerce:cp t116 set from storage commerce:l t
scoreboard players set #i c.t 427
function commerce:page/ligne
data modify storage commerce:cp ve427 set from storage commerce:l ve
data modify storage commerce:cp vz427 set from storage commerce:l vz
data modify storage commerce:cp vc427 set from storage commerce:l vc
data modify storage commerce:cp ae427 set from storage commerce:l ae
data modify storage commerce:cp az427 set from storage commerce:l az
data modify storage commerce:cp ac427 set from storage commerce:l ac
data modify storage commerce:cp t427 set from storage commerce:l t
scoreboard players set #i c.t 265
function commerce:page/ligne
data modify storage commerce:cp ve265 set from storage commerce:l ve
data modify storage commerce:cp vz265 set from storage commerce:l vz
data modify storage commerce:cp vc265 set from storage commerce:l vc
data modify storage commerce:cp ae265 set from storage commerce:l ae
data modify storage commerce:cp az265 set from storage commerce:l az
data modify storage commerce:cp ac265 set from storage commerce:l ac
data modify storage commerce:cp t265 set from storage commerce:l t
scoreboard players set #i c.t 221
function commerce:page/ligne
data modify storage commerce:cp ve221 set from storage commerce:l ve
data modify storage commerce:cp vz221 set from storage commerce:l vz
data modify storage commerce:cp vc221 set from storage commerce:l vc
data modify storage commerce:cp ae221 set from storage commerce:l ae
data modify storage commerce:cp az221 set from storage commerce:l az
data modify storage commerce:cp ac221 set from storage commerce:l ac
data modify storage commerce:cp t221 set from storage commerce:l t
scoreboard players set #i c.t 399
function commerce:page/ligne
data modify storage commerce:cp ve399 set from storage commerce:l ve
data modify storage commerce:cp vz399 set from storage commerce:l vz
data modify storage commerce:cp vc399 set from storage commerce:l vc
data modify storage commerce:cp ae399 set from storage commerce:l ae
data modify storage commerce:cp az399 set from storage commerce:l az
data modify storage commerce:cp ac399 set from storage commerce:l ac
data modify storage commerce:cp t399 set from storage commerce:l t
scoreboard players set #i c.t 276
function commerce:page/ligne
data modify storage commerce:cp ve276 set from storage commerce:l ve
data modify storage commerce:cp vz276 set from storage commerce:l vz
data modify storage commerce:cp vc276 set from storage commerce:l vc
data modify storage commerce:cp ae276 set from storage commerce:l ae
data modify storage commerce:cp az276 set from storage commerce:l az
data modify storage commerce:cp ac276 set from storage commerce:l ac
data modify storage commerce:cp t276 set from storage commerce:l t
scoreboard players set #i c.t 391
function commerce:page/ligne
data modify storage commerce:cp ve391 set from storage commerce:l ve
data modify storage commerce:cp vz391 set from storage commerce:l vz
data modify storage commerce:cp vc391 set from storage commerce:l vc
data modify storage commerce:cp ae391 set from storage commerce:l ae
data modify storage commerce:cp az391 set from storage commerce:l az
data modify storage commerce:cp ac391 set from storage commerce:l ac
data modify storage commerce:cp t391 set from storage commerce:l t
function commerce:page/lettre_c_1_d with storage commerce:cp
