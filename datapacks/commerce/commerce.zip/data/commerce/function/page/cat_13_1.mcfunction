function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 357
function commerce:page/ligne
data modify storage commerce:cp ve357 set from storage commerce:l ve
data modify storage commerce:cp vz357 set from storage commerce:l vz
data modify storage commerce:cp vc357 set from storage commerce:l vc
data modify storage commerce:cp ae357 set from storage commerce:l ae
data modify storage commerce:cp az357 set from storage commerce:l az
data modify storage commerce:cp ac357 set from storage commerce:l ac
data modify storage commerce:cp t357 set from storage commerce:l t
scoreboard players set #i c.t 358
function commerce:page/ligne
data modify storage commerce:cp ve358 set from storage commerce:l ve
data modify storage commerce:cp vz358 set from storage commerce:l vz
data modify storage commerce:cp vc358 set from storage commerce:l vc
data modify storage commerce:cp ae358 set from storage commerce:l ae
data modify storage commerce:cp az358 set from storage commerce:l az
data modify storage commerce:cp ac358 set from storage commerce:l ac
data modify storage commerce:cp t358 set from storage commerce:l t
scoreboard players set #i c.t 359
function commerce:page/ligne
data modify storage commerce:cp ve359 set from storage commerce:l ve
data modify storage commerce:cp vz359 set from storage commerce:l vz
data modify storage commerce:cp vc359 set from storage commerce:l vc
data modify storage commerce:cp ae359 set from storage commerce:l ae
data modify storage commerce:cp az359 set from storage commerce:l az
data modify storage commerce:cp ac359 set from storage commerce:l ac
data modify storage commerce:cp t359 set from storage commerce:l t
scoreboard players set #i c.t 360
function commerce:page/ligne
data modify storage commerce:cp ve360 set from storage commerce:l ve
data modify storage commerce:cp vz360 set from storage commerce:l vz
data modify storage commerce:cp vc360 set from storage commerce:l vc
data modify storage commerce:cp ae360 set from storage commerce:l ae
data modify storage commerce:cp az360 set from storage commerce:l az
data modify storage commerce:cp ac360 set from storage commerce:l ac
data modify storage commerce:cp t360 set from storage commerce:l t
function commerce:page/cat_13_1_d with storage commerce:cp
