function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 1
function commerce:page/ligne
data modify storage commerce:cp ve1 set from storage commerce:l ve
data modify storage commerce:cp vz1 set from storage commerce:l vz
data modify storage commerce:cp vc1 set from storage commerce:l vc
data modify storage commerce:cp ae1 set from storage commerce:l ae
data modify storage commerce:cp az1 set from storage commerce:l az
data modify storage commerce:cp ac1 set from storage commerce:l ac
data modify storage commerce:cp t1 set from storage commerce:l t
scoreboard players set #i c.t 2
function commerce:page/ligne
data modify storage commerce:cp ve2 set from storage commerce:l ve
data modify storage commerce:cp vz2 set from storage commerce:l vz
data modify storage commerce:cp vc2 set from storage commerce:l vc
data modify storage commerce:cp ae2 set from storage commerce:l ae
data modify storage commerce:cp az2 set from storage commerce:l az
data modify storage commerce:cp ac2 set from storage commerce:l ac
data modify storage commerce:cp t2 set from storage commerce:l t
scoreboard players set #i c.t 3
function commerce:page/ligne
data modify storage commerce:cp ve3 set from storage commerce:l ve
data modify storage commerce:cp vz3 set from storage commerce:l vz
data modify storage commerce:cp vc3 set from storage commerce:l vc
data modify storage commerce:cp ae3 set from storage commerce:l ae
data modify storage commerce:cp az3 set from storage commerce:l az
data modify storage commerce:cp ac3 set from storage commerce:l ac
data modify storage commerce:cp t3 set from storage commerce:l t
scoreboard players set #i c.t 4
function commerce:page/ligne
data modify storage commerce:cp ve4 set from storage commerce:l ve
data modify storage commerce:cp vz4 set from storage commerce:l vz
data modify storage commerce:cp vc4 set from storage commerce:l vc
data modify storage commerce:cp ae4 set from storage commerce:l ae
data modify storage commerce:cp az4 set from storage commerce:l az
data modify storage commerce:cp ac4 set from storage commerce:l ac
data modify storage commerce:cp t4 set from storage commerce:l t
scoreboard players set #i c.t 5
function commerce:page/ligne
data modify storage commerce:cp ve5 set from storage commerce:l ve
data modify storage commerce:cp vz5 set from storage commerce:l vz
data modify storage commerce:cp vc5 set from storage commerce:l vc
data modify storage commerce:cp ae5 set from storage commerce:l ae
data modify storage commerce:cp az5 set from storage commerce:l az
data modify storage commerce:cp ac5 set from storage commerce:l ac
data modify storage commerce:cp t5 set from storage commerce:l t
scoreboard players set #i c.t 6
function commerce:page/ligne
data modify storage commerce:cp ve6 set from storage commerce:l ve
data modify storage commerce:cp vz6 set from storage commerce:l vz
data modify storage commerce:cp vc6 set from storage commerce:l vc
data modify storage commerce:cp ae6 set from storage commerce:l ae
data modify storage commerce:cp az6 set from storage commerce:l az
data modify storage commerce:cp ac6 set from storage commerce:l ac
data modify storage commerce:cp t6 set from storage commerce:l t
scoreboard players set #i c.t 7
function commerce:page/ligne
data modify storage commerce:cp ve7 set from storage commerce:l ve
data modify storage commerce:cp vz7 set from storage commerce:l vz
data modify storage commerce:cp vc7 set from storage commerce:l vc
data modify storage commerce:cp ae7 set from storage commerce:l ae
data modify storage commerce:cp az7 set from storage commerce:l az
data modify storage commerce:cp ac7 set from storage commerce:l ac
data modify storage commerce:cp t7 set from storage commerce:l t
scoreboard players set #i c.t 8
function commerce:page/ligne
data modify storage commerce:cp ve8 set from storage commerce:l ve
data modify storage commerce:cp vz8 set from storage commerce:l vz
data modify storage commerce:cp vc8 set from storage commerce:l vc
data modify storage commerce:cp ae8 set from storage commerce:l ae
data modify storage commerce:cp az8 set from storage commerce:l az
data modify storage commerce:cp ac8 set from storage commerce:l ac
data modify storage commerce:cp t8 set from storage commerce:l t
scoreboard players set #i c.t 9
function commerce:page/ligne
data modify storage commerce:cp ve9 set from storage commerce:l ve
data modify storage commerce:cp vz9 set from storage commerce:l vz
data modify storage commerce:cp vc9 set from storage commerce:l vc
data modify storage commerce:cp ae9 set from storage commerce:l ae
data modify storage commerce:cp az9 set from storage commerce:l az
data modify storage commerce:cp ac9 set from storage commerce:l ac
data modify storage commerce:cp t9 set from storage commerce:l t
scoreboard players set #i c.t 10
function commerce:page/ligne
data modify storage commerce:cp ve10 set from storage commerce:l ve
data modify storage commerce:cp vz10 set from storage commerce:l vz
data modify storage commerce:cp vc10 set from storage commerce:l vc
data modify storage commerce:cp ae10 set from storage commerce:l ae
data modify storage commerce:cp az10 set from storage commerce:l az
data modify storage commerce:cp ac10 set from storage commerce:l ac
data modify storage commerce:cp t10 set from storage commerce:l t
function commerce:page/cat_1_0_d with storage commerce:cp
