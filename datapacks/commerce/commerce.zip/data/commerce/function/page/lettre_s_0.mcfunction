function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 52
function commerce:page/ligne
data modify storage commerce:cp ve52 set from storage commerce:l ve
data modify storage commerce:cp vz52 set from storage commerce:l vz
data modify storage commerce:cp vc52 set from storage commerce:l vc
data modify storage commerce:cp ae52 set from storage commerce:l ae
data modify storage commerce:cp az52 set from storage commerce:l az
data modify storage commerce:cp ac52 set from storage commerce:l ac
data modify storage commerce:cp t52 set from storage commerce:l t
scoreboard players set #i c.t 62
function commerce:page/ligne
data modify storage commerce:cp ve62 set from storage commerce:l ve
data modify storage commerce:cp vz62 set from storage commerce:l vz
data modify storage commerce:cp vc62 set from storage commerce:l vc
data modify storage commerce:cp ae62 set from storage commerce:l ae
data modify storage commerce:cp az62 set from storage commerce:l az
data modify storage commerce:cp ac62 set from storage commerce:l ac
data modify storage commerce:cp t62 set from storage commerce:l t
scoreboard players set #i c.t 53
function commerce:page/ligne
data modify storage commerce:cp ve53 set from storage commerce:l ve
data modify storage commerce:cp vz53 set from storage commerce:l vz
data modify storage commerce:cp vc53 set from storage commerce:l vc
data modify storage commerce:cp ae53 set from storage commerce:l ae
data modify storage commerce:cp az53 set from storage commerce:l az
data modify storage commerce:cp ac53 set from storage commerce:l ac
data modify storage commerce:cp t53 set from storage commerce:l t
scoreboard players set #i c.t 335
function commerce:page/ligne
data modify storage commerce:cp ve335 set from storage commerce:l ve
data modify storage commerce:cp vz335 set from storage commerce:l vz
data modify storage commerce:cp vc335 set from storage commerce:l vc
data modify storage commerce:cp ae335 set from storage commerce:l ae
data modify storage commerce:cp az335 set from storage commerce:l az
data modify storage commerce:cp ac335 set from storage commerce:l ac
data modify storage commerce:cp t335 set from storage commerce:l t
scoreboard players set #i c.t 359
function commerce:page/ligne
data modify storage commerce:cp ve359 set from storage commerce:l ve
data modify storage commerce:cp vz359 set from storage commerce:l vz
data modify storage commerce:cp vc359 set from storage commerce:l vc
data modify storage commerce:cp ae359 set from storage commerce:l ae
data modify storage commerce:cp az359 set from storage commerce:l az
data modify storage commerce:cp ac359 set from storage commerce:l ac
data modify storage commerce:cp t359 set from storage commerce:l t
scoreboard players set #i c.t 390
function commerce:page/ligne
data modify storage commerce:cp ve390 set from storage commerce:l ve
data modify storage commerce:cp vz390 set from storage commerce:l vz
data modify storage commerce:cp vc390 set from storage commerce:l vc
data modify storage commerce:cp ae390 set from storage commerce:l ae
data modify storage commerce:cp az390 set from storage commerce:l az
data modify storage commerce:cp ac390 set from storage commerce:l ac
data modify storage commerce:cp t390 set from storage commerce:l t
scoreboard players set #i c.t 398
function commerce:page/ligne
data modify storage commerce:cp ve398 set from storage commerce:l ve
data modify storage commerce:cp vz398 set from storage commerce:l vz
data modify storage commerce:cp vc398 set from storage commerce:l vc
data modify storage commerce:cp ae398 set from storage commerce:l ae
data modify storage commerce:cp az398 set from storage commerce:l az
data modify storage commerce:cp ac398 set from storage commerce:l ac
data modify storage commerce:cp t398 set from storage commerce:l t
scoreboard players set #i c.t 246
function commerce:page/ligne
data modify storage commerce:cp ve246 set from storage commerce:l ve
data modify storage commerce:cp vz246 set from storage commerce:l vz
data modify storage commerce:cp vc246 set from storage commerce:l vc
data modify storage commerce:cp ae246 set from storage commerce:l ae
data modify storage commerce:cp az246 set from storage commerce:l az
data modify storage commerce:cp ac246 set from storage commerce:l ac
data modify storage commerce:cp t246 set from storage commerce:l t
scoreboard players set #i c.t 452
function commerce:page/ligne
data modify storage commerce:cp ve452 set from storage commerce:l ve
data modify storage commerce:cp vz452 set from storage commerce:l vz
data modify storage commerce:cp vc452 set from storage commerce:l vc
data modify storage commerce:cp ae452 set from storage commerce:l ae
data modify storage commerce:cp az452 set from storage commerce:l az
data modify storage commerce:cp ac452 set from storage commerce:l ac
data modify storage commerce:cp t452 set from storage commerce:l t
scoreboard players set #i c.t 26
function commerce:page/ligne
data modify storage commerce:cp ve26 set from storage commerce:l ve
data modify storage commerce:cp vz26 set from storage commerce:l vz
data modify storage commerce:cp vc26 set from storage commerce:l vc
data modify storage commerce:cp ae26 set from storage commerce:l ae
data modify storage commerce:cp az26 set from storage commerce:l az
data modify storage commerce:cp ac26 set from storage commerce:l ac
data modify storage commerce:cp t26 set from storage commerce:l t
function commerce:page/lettre_s_0_d with storage commerce:cp
