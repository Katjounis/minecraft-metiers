function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 302
function commerce:page/ligne
data modify storage commerce:cp ve302 set from storage commerce:l ve
data modify storage commerce:cp vz302 set from storage commerce:l vz
data modify storage commerce:cp vc302 set from storage commerce:l vc
data modify storage commerce:cp ae302 set from storage commerce:l ae
data modify storage commerce:cp az302 set from storage commerce:l az
data modify storage commerce:cp ac302 set from storage commerce:l ac
data modify storage commerce:cp t302 set from storage commerce:l t
scoreboard players set #i c.t 303
function commerce:page/ligne
data modify storage commerce:cp ve303 set from storage commerce:l ve
data modify storage commerce:cp vz303 set from storage commerce:l vz
data modify storage commerce:cp vc303 set from storage commerce:l vc
data modify storage commerce:cp ae303 set from storage commerce:l ae
data modify storage commerce:cp az303 set from storage commerce:l az
data modify storage commerce:cp ac303 set from storage commerce:l ac
data modify storage commerce:cp t303 set from storage commerce:l t
scoreboard players set #i c.t 304
function commerce:page/ligne
data modify storage commerce:cp ve304 set from storage commerce:l ve
data modify storage commerce:cp vz304 set from storage commerce:l vz
data modify storage commerce:cp vc304 set from storage commerce:l vc
data modify storage commerce:cp ae304 set from storage commerce:l ae
data modify storage commerce:cp az304 set from storage commerce:l az
data modify storage commerce:cp ac304 set from storage commerce:l ac
data modify storage commerce:cp t304 set from storage commerce:l t
scoreboard players set #i c.t 305
function commerce:page/ligne
data modify storage commerce:cp ve305 set from storage commerce:l ve
data modify storage commerce:cp vz305 set from storage commerce:l vz
data modify storage commerce:cp vc305 set from storage commerce:l vc
data modify storage commerce:cp ae305 set from storage commerce:l ae
data modify storage commerce:cp az305 set from storage commerce:l az
data modify storage commerce:cp ac305 set from storage commerce:l ac
data modify storage commerce:cp t305 set from storage commerce:l t
scoreboard players set #i c.t 306
function commerce:page/ligne
data modify storage commerce:cp ve306 set from storage commerce:l ve
data modify storage commerce:cp vz306 set from storage commerce:l vz
data modify storage commerce:cp vc306 set from storage commerce:l vc
data modify storage commerce:cp ae306 set from storage commerce:l ae
data modify storage commerce:cp az306 set from storage commerce:l az
data modify storage commerce:cp ac306 set from storage commerce:l ac
data modify storage commerce:cp t306 set from storage commerce:l t
scoreboard players set #i c.t 307
function commerce:page/ligne
data modify storage commerce:cp ve307 set from storage commerce:l ve
data modify storage commerce:cp vz307 set from storage commerce:l vz
data modify storage commerce:cp vc307 set from storage commerce:l vc
data modify storage commerce:cp ae307 set from storage commerce:l ae
data modify storage commerce:cp az307 set from storage commerce:l az
data modify storage commerce:cp ac307 set from storage commerce:l ac
data modify storage commerce:cp t307 set from storage commerce:l t
scoreboard players set #i c.t 308
function commerce:page/ligne
data modify storage commerce:cp ve308 set from storage commerce:l ve
data modify storage commerce:cp vz308 set from storage commerce:l vz
data modify storage commerce:cp vc308 set from storage commerce:l vc
data modify storage commerce:cp ae308 set from storage commerce:l ae
data modify storage commerce:cp az308 set from storage commerce:l az
data modify storage commerce:cp ac308 set from storage commerce:l ac
data modify storage commerce:cp t308 set from storage commerce:l t
scoreboard players set #i c.t 309
function commerce:page/ligne
data modify storage commerce:cp ve309 set from storage commerce:l ve
data modify storage commerce:cp vz309 set from storage commerce:l vz
data modify storage commerce:cp vc309 set from storage commerce:l vc
data modify storage commerce:cp ae309 set from storage commerce:l ae
data modify storage commerce:cp az309 set from storage commerce:l az
data modify storage commerce:cp ac309 set from storage commerce:l ac
data modify storage commerce:cp t309 set from storage commerce:l t
scoreboard players set #i c.t 310
function commerce:page/ligne
data modify storage commerce:cp ve310 set from storage commerce:l ve
data modify storage commerce:cp vz310 set from storage commerce:l vz
data modify storage commerce:cp vc310 set from storage commerce:l vc
data modify storage commerce:cp ae310 set from storage commerce:l ae
data modify storage commerce:cp az310 set from storage commerce:l az
data modify storage commerce:cp ac310 set from storage commerce:l ac
data modify storage commerce:cp t310 set from storage commerce:l t
scoreboard players set #i c.t 311
function commerce:page/ligne
data modify storage commerce:cp ve311 set from storage commerce:l ve
data modify storage commerce:cp vz311 set from storage commerce:l vz
data modify storage commerce:cp vc311 set from storage commerce:l vc
data modify storage commerce:cp ae311 set from storage commerce:l ae
data modify storage commerce:cp az311 set from storage commerce:l az
data modify storage commerce:cp ac311 set from storage commerce:l ac
data modify storage commerce:cp t311 set from storage commerce:l t
function commerce:page/cat_11_0_d with storage commerce:cp
