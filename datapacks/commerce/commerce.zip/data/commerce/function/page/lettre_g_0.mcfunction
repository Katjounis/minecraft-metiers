function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 459
function commerce:page/ligne
data modify storage commerce:cp ve459 set from storage commerce:l ve
data modify storage commerce:cp vz459 set from storage commerce:l vz
data modify storage commerce:cp vc459 set from storage commerce:l vc
data modify storage commerce:cp ae459 set from storage commerce:l ae
data modify storage commerce:cp az459 set from storage commerce:l az
data modify storage commerce:cp ac459 set from storage commerce:l ac
data modify storage commerce:cp t459 set from storage commerce:l t
scoreboard players set #i c.t 59
function commerce:page/ligne
data modify storage commerce:cp ve59 set from storage commerce:l ve
data modify storage commerce:cp vz59 set from storage commerce:l vz
data modify storage commerce:cp vc59 set from storage commerce:l vc
data modify storage commerce:cp ae59 set from storage commerce:l ae
data modify storage commerce:cp az59 set from storage commerce:l az
data modify storage commerce:cp ac59 set from storage commerce:l ac
data modify storage commerce:cp t59 set from storage commerce:l t
scoreboard players set #i c.t 61
function commerce:page/ligne
data modify storage commerce:cp ve61 set from storage commerce:l ve
data modify storage commerce:cp vz61 set from storage commerce:l vz
data modify storage commerce:cp vc61 set from storage commerce:l vc
data modify storage commerce:cp ae61 set from storage commerce:l ae
data modify storage commerce:cp az61 set from storage commerce:l az
data modify storage commerce:cp ac61 set from storage commerce:l ac
data modify storage commerce:cp t61 set from storage commerce:l t
scoreboard players set #i c.t 60
function commerce:page/ligne
data modify storage commerce:cp ve60 set from storage commerce:l ve
data modify storage commerce:cp vz60 set from storage commerce:l vz
data modify storage commerce:cp vc60 set from storage commerce:l vc
data modify storage commerce:cp ae60 set from storage commerce:l ae
data modify storage commerce:cp az60 set from storage commerce:l az
data modify storage commerce:cp ac60 set from storage commerce:l ac
data modify storage commerce:cp t60 set from storage commerce:l t
scoreboard players set #i c.t 286
function commerce:page/ligne
data modify storage commerce:cp ve286 set from storage commerce:l ve
data modify storage commerce:cp vz286 set from storage commerce:l vz
data modify storage commerce:cp vc286 set from storage commerce:l vc
data modify storage commerce:cp ae286 set from storage commerce:l ae
data modify storage commerce:cp az286 set from storage commerce:l az
data modify storage commerce:cp ac286 set from storage commerce:l ac
data modify storage commerce:cp t286 set from storage commerce:l t
scoreboard players set #i c.t 281
function commerce:page/ligne
data modify storage commerce:cp ve281 set from storage commerce:l ve
data modify storage commerce:cp vz281 set from storage commerce:l vz
data modify storage commerce:cp vc281 set from storage commerce:l vc
data modify storage commerce:cp ae281 set from storage commerce:l ae
data modify storage commerce:cp az281 set from storage commerce:l az
data modify storage commerce:cp ac281 set from storage commerce:l ac
data modify storage commerce:cp t281 set from storage commerce:l t
scoreboard players set #i c.t 292
function commerce:page/ligne
data modify storage commerce:cp ve292 set from storage commerce:l ve
data modify storage commerce:cp vz292 set from storage commerce:l vz
data modify storage commerce:cp vc292 set from storage commerce:l vc
data modify storage commerce:cp ae292 set from storage commerce:l ae
data modify storage commerce:cp az292 set from storage commerce:l az
data modify storage commerce:cp ac292 set from storage commerce:l ac
data modify storage commerce:cp t292 set from storage commerce:l t
scoreboard players set #i c.t 289
function commerce:page/ligne
data modify storage commerce:cp ve289 set from storage commerce:l ve
data modify storage commerce:cp vz289 set from storage commerce:l vz
data modify storage commerce:cp vc289 set from storage commerce:l vc
data modify storage commerce:cp ae289 set from storage commerce:l ae
data modify storage commerce:cp az289 set from storage commerce:l az
data modify storage commerce:cp ac289 set from storage commerce:l ac
data modify storage commerce:cp t289 set from storage commerce:l t
scoreboard players set #i c.t 9
function commerce:page/ligne
data modify storage commerce:cp ve9 set from storage commerce:l ve
data modify storage commerce:cp vz9 set from storage commerce:l vz
data modify storage commerce:cp vc9 set from storage commerce:l vc
data modify storage commerce:cp ae9 set from storage commerce:l ae
data modify storage commerce:cp az9 set from storage commerce:l az
data modify storage commerce:cp ac9 set from storage commerce:l ac
data modify storage commerce:cp t9 set from storage commerce:l t
scoreboard players set #i c.t 10
function commerce:page/ligne
data modify storage commerce:cp ve10 set from storage commerce:l ve
data modify storage commerce:cp vz10 set from storage commerce:l vz
data modify storage commerce:cp vc10 set from storage commerce:l vc
data modify storage commerce:cp ae10 set from storage commerce:l ae
data modify storage commerce:cp az10 set from storage commerce:l az
data modify storage commerce:cp ac10 set from storage commerce:l ac
data modify storage commerce:cp t10 set from storage commerce:l t
function commerce:page/lettre_g_0_d with storage commerce:cp
