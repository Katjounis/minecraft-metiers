scoreboard players set #btot c.t 0
scoreboard players set #lot c.t 1
execute unless items entity @s container.* minecraft:bread[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:bread[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:bread[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 347
execute if items entity @s weapon.offhand minecraft:bread[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 347
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:baked_potato[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:baked_potato[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:baked_potato[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 348
execute if items entity @s weapon.offhand minecraft:baked_potato[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 348
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:pumpkin_pie[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:pumpkin_pie[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:pumpkin_pie[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 349
execute if items entity @s weapon.offhand minecraft:pumpkin_pie[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 349
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:cookie[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cookie[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cookie[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 350
execute if items entity @s weapon.offhand minecraft:cookie[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 350
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:golden_carrot[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:golden_carrot[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:golden_carrot[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 351
execute if items entity @s weapon.offhand minecraft:golden_carrot[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 351
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:mushroom_stew[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:mushroom_stew[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:mushroom_stew[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 352
execute if items entity @s weapon.offhand minecraft:mushroom_stew[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 352
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:cooked_beef[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cooked_beef[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cooked_beef[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 353
execute if items entity @s weapon.offhand minecraft:cooked_beef[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 353
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:cooked_porkchop[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cooked_porkchop[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cooked_porkchop[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 354
execute if items entity @s weapon.offhand minecraft:cooked_porkchop[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 354
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:cooked_chicken[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cooked_chicken[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cooked_chicken[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 355
execute if items entity @s weapon.offhand minecraft:cooked_chicken[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 355
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:cooked_mutton[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cooked_mutton[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cooked_mutton[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 356
execute if items entity @s weapon.offhand minecraft:cooked_mutton[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 356
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:cooked_rabbit[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cooked_rabbit[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cooked_rabbit[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 357
execute if items entity @s weapon.offhand minecraft:cooked_rabbit[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 357
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:cooked_cod[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cooked_cod[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cooked_cod[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 358
execute if items entity @s weapon.offhand minecraft:cooked_cod[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 358
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:cooked_salmon[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cooked_salmon[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cooked_salmon[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 359
execute if items entity @s weapon.offhand minecraft:cooked_salmon[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 359
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:golden_apple[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:golden_apple[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:golden_apple[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 360
execute if items entity @s weapon.offhand minecraft:golden_apple[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 360
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
scoreboard players set #lot c.t 0
scoreboard players operation #btot c.t /= #100 c.g
execute if score #btot c.t matches ..0 run tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Rien à vendre dans cette catégorie (les objets renommés ou spéciaux sont gardés).",color:"red",bold:false,italic:false}]
execute if score #btot c.t matches 1.. run tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Cuisine vendu en entier : ",color:"gray",bold:false,italic:false},{score:{name:"#btot",objective:"c.t"},color:"gold",bold:true},{text:" Écus",color:"gold",bold:false,italic:false}]
execute if score #btot c.t matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.7 1.4
function commerce:page/cat_13_0
