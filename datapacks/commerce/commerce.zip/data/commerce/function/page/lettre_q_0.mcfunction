function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 243
function commerce:page/ligne
data modify storage commerce:cp ve243 set from storage commerce:l ve
data modify storage commerce:cp vz243 set from storage commerce:l vz
data modify storage commerce:cp vc243 set from storage commerce:l vc
data modify storage commerce:cp ae243 set from storage commerce:l ae
data modify storage commerce:cp az243 set from storage commerce:l az
data modify storage commerce:cp ac243 set from storage commerce:l ac
data modify storage commerce:cp t243 set from storage commerce:l t
scoreboard players set #i c.t 269
function commerce:page/ligne
data modify storage commerce:cp ve269 set from storage commerce:l ve
data modify storage commerce:cp vz269 set from storage commerce:l vz
data modify storage commerce:cp vc269 set from storage commerce:l vc
data modify storage commerce:cp ae269 set from storage commerce:l ae
data modify storage commerce:cp az269 set from storage commerce:l az
data modify storage commerce:cp ac269 set from storage commerce:l ac
data modify storage commerce:cp t269 set from storage commerce:l t
function commerce:page/lettre_q_0_d with storage commerce:cp
