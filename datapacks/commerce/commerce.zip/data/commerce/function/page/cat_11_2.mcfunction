function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 322
function commerce:page/ligne
data modify storage commerce:cp ve322 set from storage commerce:l ve
data modify storage commerce:cp vz322 set from storage commerce:l vz
data modify storage commerce:cp vc322 set from storage commerce:l vc
data modify storage commerce:cp ae322 set from storage commerce:l ae
data modify storage commerce:cp az322 set from storage commerce:l az
data modify storage commerce:cp ac322 set from storage commerce:l ac
data modify storage commerce:cp t322 set from storage commerce:l t
scoreboard players set #i c.t 323
function commerce:page/ligne
data modify storage commerce:cp ve323 set from storage commerce:l ve
data modify storage commerce:cp vz323 set from storage commerce:l vz
data modify storage commerce:cp vc323 set from storage commerce:l vc
data modify storage commerce:cp ae323 set from storage commerce:l ae
data modify storage commerce:cp az323 set from storage commerce:l az
data modify storage commerce:cp ac323 set from storage commerce:l ac
data modify storage commerce:cp t323 set from storage commerce:l t
scoreboard players set #i c.t 324
function commerce:page/ligne
data modify storage commerce:cp ve324 set from storage commerce:l ve
data modify storage commerce:cp vz324 set from storage commerce:l vz
data modify storage commerce:cp vc324 set from storage commerce:l vc
data modify storage commerce:cp ae324 set from storage commerce:l ae
data modify storage commerce:cp az324 set from storage commerce:l az
data modify storage commerce:cp ac324 set from storage commerce:l ac
data modify storage commerce:cp t324 set from storage commerce:l t
scoreboard players set #i c.t 325
function commerce:page/ligne
data modify storage commerce:cp ve325 set from storage commerce:l ve
data modify storage commerce:cp vz325 set from storage commerce:l vz
data modify storage commerce:cp vc325 set from storage commerce:l vc
data modify storage commerce:cp ae325 set from storage commerce:l ae
data modify storage commerce:cp az325 set from storage commerce:l az
data modify storage commerce:cp ac325 set from storage commerce:l ac
data modify storage commerce:cp t325 set from storage commerce:l t
scoreboard players set #i c.t 326
function commerce:page/ligne
data modify storage commerce:cp ve326 set from storage commerce:l ve
data modify storage commerce:cp vz326 set from storage commerce:l vz
data modify storage commerce:cp vc326 set from storage commerce:l vc
data modify storage commerce:cp ae326 set from storage commerce:l ae
data modify storage commerce:cp az326 set from storage commerce:l az
data modify storage commerce:cp ac326 set from storage commerce:l ac
data modify storage commerce:cp t326 set from storage commerce:l t
scoreboard players set #i c.t 327
function commerce:page/ligne
data modify storage commerce:cp ve327 set from storage commerce:l ve
data modify storage commerce:cp vz327 set from storage commerce:l vz
data modify storage commerce:cp vc327 set from storage commerce:l vc
data modify storage commerce:cp ae327 set from storage commerce:l ae
data modify storage commerce:cp az327 set from storage commerce:l az
data modify storage commerce:cp ac327 set from storage commerce:l ac
data modify storage commerce:cp t327 set from storage commerce:l t
scoreboard players set #i c.t 328
function commerce:page/ligne
data modify storage commerce:cp ve328 set from storage commerce:l ve
data modify storage commerce:cp vz328 set from storage commerce:l vz
data modify storage commerce:cp vc328 set from storage commerce:l vc
data modify storage commerce:cp ae328 set from storage commerce:l ae
data modify storage commerce:cp az328 set from storage commerce:l az
data modify storage commerce:cp ac328 set from storage commerce:l ac
data modify storage commerce:cp t328 set from storage commerce:l t
scoreboard players set #i c.t 329
function commerce:page/ligne
data modify storage commerce:cp ve329 set from storage commerce:l ve
data modify storage commerce:cp vz329 set from storage commerce:l vz
data modify storage commerce:cp vc329 set from storage commerce:l vc
data modify storage commerce:cp ae329 set from storage commerce:l ae
data modify storage commerce:cp az329 set from storage commerce:l az
data modify storage commerce:cp ac329 set from storage commerce:l ac
data modify storage commerce:cp t329 set from storage commerce:l t
scoreboard players set #i c.t 330
function commerce:page/ligne
data modify storage commerce:cp ve330 set from storage commerce:l ve
data modify storage commerce:cp vz330 set from storage commerce:l vz
data modify storage commerce:cp vc330 set from storage commerce:l vc
data modify storage commerce:cp ae330 set from storage commerce:l ae
data modify storage commerce:cp az330 set from storage commerce:l az
data modify storage commerce:cp ac330 set from storage commerce:l ac
data modify storage commerce:cp t330 set from storage commerce:l t
scoreboard players set #i c.t 331
function commerce:page/ligne
data modify storage commerce:cp ve331 set from storage commerce:l ve
data modify storage commerce:cp vz331 set from storage commerce:l vz
data modify storage commerce:cp vc331 set from storage commerce:l vc
data modify storage commerce:cp ae331 set from storage commerce:l ae
data modify storage commerce:cp az331 set from storage commerce:l az
data modify storage commerce:cp ac331 set from storage commerce:l ac
data modify storage commerce:cp t331 set from storage commerce:l t
function commerce:page/cat_11_2_d with storage commerce:cp
