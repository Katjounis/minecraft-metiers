function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 114
function commerce:page/ligne
data modify storage commerce:cp ve114 set from storage commerce:l ve
data modify storage commerce:cp vz114 set from storage commerce:l vz
data modify storage commerce:cp vc114 set from storage commerce:l vc
data modify storage commerce:cp ae114 set from storage commerce:l ae
data modify storage commerce:cp az114 set from storage commerce:l az
data modify storage commerce:cp ac114 set from storage commerce:l ac
data modify storage commerce:cp t114 set from storage commerce:l t
scoreboard players set #i c.t 93
function commerce:page/ligne
data modify storage commerce:cp ve93 set from storage commerce:l ve
data modify storage commerce:cp vz93 set from storage commerce:l vz
data modify storage commerce:cp vc93 set from storage commerce:l vc
data modify storage commerce:cp ae93 set from storage commerce:l ae
data modify storage commerce:cp az93 set from storage commerce:l az
data modify storage commerce:cp ac93 set from storage commerce:l ac
data modify storage commerce:cp t93 set from storage commerce:l t
scoreboard players set #i c.t 39
function commerce:page/ligne
data modify storage commerce:cp ve39 set from storage commerce:l ve
data modify storage commerce:cp vz39 set from storage commerce:l vz
data modify storage commerce:cp vc39 set from storage commerce:l vc
data modify storage commerce:cp ae39 set from storage commerce:l ae
data modify storage commerce:cp az39 set from storage commerce:l az
data modify storage commerce:cp ac39 set from storage commerce:l ac
data modify storage commerce:cp t39 set from storage commerce:l t
scoreboard players set #i c.t 41
function commerce:page/ligne
data modify storage commerce:cp ve41 set from storage commerce:l ve
data modify storage commerce:cp vz41 set from storage commerce:l vz
data modify storage commerce:cp vc41 set from storage commerce:l vc
data modify storage commerce:cp ae41 set from storage commerce:l ae
data modify storage commerce:cp az41 set from storage commerce:l az
data modify storage commerce:cp ac41 set from storage commerce:l ac
data modify storage commerce:cp t41 set from storage commerce:l t
scoreboard players set #i c.t 108
function commerce:page/ligne
data modify storage commerce:cp ve108 set from storage commerce:l ve
data modify storage commerce:cp vz108 set from storage commerce:l vz
data modify storage commerce:cp vc108 set from storage commerce:l vc
data modify storage commerce:cp ae108 set from storage commerce:l ae
data modify storage commerce:cp az108 set from storage commerce:l az
data modify storage commerce:cp ac108 set from storage commerce:l ac
data modify storage commerce:cp t108 set from storage commerce:l t
function commerce:page/lettre_p_6_d with storage commerce:cp
