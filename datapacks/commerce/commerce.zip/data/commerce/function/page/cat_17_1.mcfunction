function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 470
function commerce:page/ligne
data modify storage commerce:cp ve470 set from storage commerce:l ve
data modify storage commerce:cp vz470 set from storage commerce:l vz
data modify storage commerce:cp vc470 set from storage commerce:l vc
data modify storage commerce:cp ae470 set from storage commerce:l ae
data modify storage commerce:cp az470 set from storage commerce:l az
data modify storage commerce:cp ac470 set from storage commerce:l ac
data modify storage commerce:cp t470 set from storage commerce:l t
scoreboard players set #i c.t 471
function commerce:page/ligne
data modify storage commerce:cp ve471 set from storage commerce:l ve
data modify storage commerce:cp vz471 set from storage commerce:l vz
data modify storage commerce:cp vc471 set from storage commerce:l vc
data modify storage commerce:cp ae471 set from storage commerce:l ae
data modify storage commerce:cp az471 set from storage commerce:l az
data modify storage commerce:cp ac471 set from storage commerce:l ac
data modify storage commerce:cp t471 set from storage commerce:l t
scoreboard players set #i c.t 472
function commerce:page/ligne
data modify storage commerce:cp ve472 set from storage commerce:l ve
data modify storage commerce:cp vz472 set from storage commerce:l vz
data modify storage commerce:cp vc472 set from storage commerce:l vc
data modify storage commerce:cp ae472 set from storage commerce:l ae
data modify storage commerce:cp az472 set from storage commerce:l az
data modify storage commerce:cp ac472 set from storage commerce:l ac
data modify storage commerce:cp t472 set from storage commerce:l t
scoreboard players set #i c.t 473
function commerce:page/ligne
data modify storage commerce:cp ve473 set from storage commerce:l ve
data modify storage commerce:cp vz473 set from storage commerce:l vz
data modify storage commerce:cp vc473 set from storage commerce:l vc
data modify storage commerce:cp ae473 set from storage commerce:l ae
data modify storage commerce:cp az473 set from storage commerce:l az
data modify storage commerce:cp ac473 set from storage commerce:l ac
data modify storage commerce:cp t473 set from storage commerce:l t
scoreboard players set #i c.t 474
function commerce:page/ligne
data modify storage commerce:cp ve474 set from storage commerce:l ve
data modify storage commerce:cp vz474 set from storage commerce:l vz
data modify storage commerce:cp vc474 set from storage commerce:l vc
data modify storage commerce:cp ae474 set from storage commerce:l ae
data modify storage commerce:cp az474 set from storage commerce:l az
data modify storage commerce:cp ac474 set from storage commerce:l ac
data modify storage commerce:cp t474 set from storage commerce:l t
scoreboard players set #i c.t 475
function commerce:page/ligne
data modify storage commerce:cp ve475 set from storage commerce:l ve
data modify storage commerce:cp vz475 set from storage commerce:l vz
data modify storage commerce:cp vc475 set from storage commerce:l vc
data modify storage commerce:cp ae475 set from storage commerce:l ae
data modify storage commerce:cp az475 set from storage commerce:l az
data modify storage commerce:cp ac475 set from storage commerce:l ac
data modify storage commerce:cp t475 set from storage commerce:l t
scoreboard players set #i c.t 476
function commerce:page/ligne
data modify storage commerce:cp ve476 set from storage commerce:l ve
data modify storage commerce:cp vz476 set from storage commerce:l vz
data modify storage commerce:cp vc476 set from storage commerce:l vc
data modify storage commerce:cp ae476 set from storage commerce:l ae
data modify storage commerce:cp az476 set from storage commerce:l az
data modify storage commerce:cp ac476 set from storage commerce:l ac
data modify storage commerce:cp t476 set from storage commerce:l t
scoreboard players set #i c.t 477
function commerce:page/ligne
data modify storage commerce:cp ve477 set from storage commerce:l ve
data modify storage commerce:cp vz477 set from storage commerce:l vz
data modify storage commerce:cp vc477 set from storage commerce:l vc
data modify storage commerce:cp ae477 set from storage commerce:l ae
data modify storage commerce:cp az477 set from storage commerce:l az
data modify storage commerce:cp ac477 set from storage commerce:l ac
data modify storage commerce:cp t477 set from storage commerce:l t
scoreboard players set #i c.t 478
function commerce:page/ligne
data modify storage commerce:cp ve478 set from storage commerce:l ve
data modify storage commerce:cp vz478 set from storage commerce:l vz
data modify storage commerce:cp vc478 set from storage commerce:l vc
data modify storage commerce:cp ae478 set from storage commerce:l ae
data modify storage commerce:cp az478 set from storage commerce:l az
data modify storage commerce:cp ac478 set from storage commerce:l ac
data modify storage commerce:cp t478 set from storage commerce:l t
scoreboard players set #i c.t 479
function commerce:page/ligne
data modify storage commerce:cp ve479 set from storage commerce:l ve
data modify storage commerce:cp vz479 set from storage commerce:l vz
data modify storage commerce:cp vc479 set from storage commerce:l vc
data modify storage commerce:cp ae479 set from storage commerce:l ae
data modify storage commerce:cp az479 set from storage commerce:l az
data modify storage commerce:cp ac479 set from storage commerce:l ac
data modify storage commerce:cp t479 set from storage commerce:l t
function commerce:page/cat_17_1_d with storage commerce:cp
