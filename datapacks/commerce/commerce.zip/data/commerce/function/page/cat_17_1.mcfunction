function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 466
function commerce:page/ligne
data modify storage commerce:cp ve466 set from storage commerce:l ve
data modify storage commerce:cp vz466 set from storage commerce:l vz
data modify storage commerce:cp vc466 set from storage commerce:l vc
data modify storage commerce:cp ae466 set from storage commerce:l ae
data modify storage commerce:cp az466 set from storage commerce:l az
data modify storage commerce:cp ac466 set from storage commerce:l ac
data modify storage commerce:cp t466 set from storage commerce:l t
scoreboard players set #i c.t 467
function commerce:page/ligne
data modify storage commerce:cp ve467 set from storage commerce:l ve
data modify storage commerce:cp vz467 set from storage commerce:l vz
data modify storage commerce:cp vc467 set from storage commerce:l vc
data modify storage commerce:cp ae467 set from storage commerce:l ae
data modify storage commerce:cp az467 set from storage commerce:l az
data modify storage commerce:cp ac467 set from storage commerce:l ac
data modify storage commerce:cp t467 set from storage commerce:l t
scoreboard players set #i c.t 468
function commerce:page/ligne
data modify storage commerce:cp ve468 set from storage commerce:l ve
data modify storage commerce:cp vz468 set from storage commerce:l vz
data modify storage commerce:cp vc468 set from storage commerce:l vc
data modify storage commerce:cp ae468 set from storage commerce:l ae
data modify storage commerce:cp az468 set from storage commerce:l az
data modify storage commerce:cp ac468 set from storage commerce:l ac
data modify storage commerce:cp t468 set from storage commerce:l t
scoreboard players set #i c.t 469
function commerce:page/ligne
data modify storage commerce:cp ve469 set from storage commerce:l ve
data modify storage commerce:cp vz469 set from storage commerce:l vz
data modify storage commerce:cp vc469 set from storage commerce:l vc
data modify storage commerce:cp ae469 set from storage commerce:l ae
data modify storage commerce:cp az469 set from storage commerce:l az
data modify storage commerce:cp ac469 set from storage commerce:l ac
data modify storage commerce:cp t469 set from storage commerce:l t
scoreboard players set #i c.t 470
function commerce:page/ligne
data modify storage commerce:cp ve470 set from storage commerce:l ve
data modify storage commerce:cp vz470 set from storage commerce:l vz
data modify storage commerce:cp vc470 set from storage commerce:l vc
data modify storage commerce:cp ae470 set from storage commerce:l ae
data modify storage commerce:cp az470 set from storage commerce:l az
data modify storage commerce:cp ac470 set from storage commerce:l ac
data modify storage commerce:cp t470 set from storage commerce:l t
scoreboard players set #i c.t 471
function commerce:page/ligne
data modify storage commerce:cp ve471 set from storage commerce:l ve
data modify storage commerce:cp vz471 set from storage commerce:l vz
data modify storage commerce:cp vc471 set from storage commerce:l vc
data modify storage commerce:cp ae471 set from storage commerce:l ae
data modify storage commerce:cp az471 set from storage commerce:l az
data modify storage commerce:cp ac471 set from storage commerce:l ac
data modify storage commerce:cp t471 set from storage commerce:l t
scoreboard players set #i c.t 472
function commerce:page/ligne
data modify storage commerce:cp ve472 set from storage commerce:l ve
data modify storage commerce:cp vz472 set from storage commerce:l vz
data modify storage commerce:cp vc472 set from storage commerce:l vc
data modify storage commerce:cp ae472 set from storage commerce:l ae
data modify storage commerce:cp az472 set from storage commerce:l az
data modify storage commerce:cp ac472 set from storage commerce:l ac
data modify storage commerce:cp t472 set from storage commerce:l t
scoreboard players set #i c.t 473
function commerce:page/ligne
data modify storage commerce:cp ve473 set from storage commerce:l ve
data modify storage commerce:cp vz473 set from storage commerce:l vz
data modify storage commerce:cp vc473 set from storage commerce:l vc
data modify storage commerce:cp ae473 set from storage commerce:l ae
data modify storage commerce:cp az473 set from storage commerce:l az
data modify storage commerce:cp ac473 set from storage commerce:l ac
data modify storage commerce:cp t473 set from storage commerce:l t
scoreboard players set #i c.t 474
function commerce:page/ligne
data modify storage commerce:cp ve474 set from storage commerce:l ve
data modify storage commerce:cp vz474 set from storage commerce:l vz
data modify storage commerce:cp vc474 set from storage commerce:l vc
data modify storage commerce:cp ae474 set from storage commerce:l ae
data modify storage commerce:cp az474 set from storage commerce:l az
data modify storage commerce:cp ac474 set from storage commerce:l ac
data modify storage commerce:cp t474 set from storage commerce:l t
scoreboard players set #i c.t 475
function commerce:page/ligne
data modify storage commerce:cp ve475 set from storage commerce:l ve
data modify storage commerce:cp vz475 set from storage commerce:l vz
data modify storage commerce:cp vc475 set from storage commerce:l vc
data modify storage commerce:cp ae475 set from storage commerce:l ae
data modify storage commerce:cp az475 set from storage commerce:l az
data modify storage commerce:cp ac475 set from storage commerce:l ac
data modify storage commerce:cp t475 set from storage commerce:l t
function commerce:page/cat_17_1_d with storage commerce:cp
