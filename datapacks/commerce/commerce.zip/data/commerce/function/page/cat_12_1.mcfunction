function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 344
function commerce:page/ligne
data modify storage commerce:cp ve344 set from storage commerce:l ve
data modify storage commerce:cp vz344 set from storage commerce:l vz
data modify storage commerce:cp vc344 set from storage commerce:l vc
data modify storage commerce:cp ae344 set from storage commerce:l ae
data modify storage commerce:cp az344 set from storage commerce:l az
data modify storage commerce:cp ac344 set from storage commerce:l ac
data modify storage commerce:cp t344 set from storage commerce:l t
scoreboard players set #i c.t 345
function commerce:page/ligne
data modify storage commerce:cp ve345 set from storage commerce:l ve
data modify storage commerce:cp vz345 set from storage commerce:l vz
data modify storage commerce:cp vc345 set from storage commerce:l vc
data modify storage commerce:cp ae345 set from storage commerce:l ae
data modify storage commerce:cp az345 set from storage commerce:l az
data modify storage commerce:cp ac345 set from storage commerce:l ac
data modify storage commerce:cp t345 set from storage commerce:l t
scoreboard players set #i c.t 346
function commerce:page/ligne
data modify storage commerce:cp ve346 set from storage commerce:l ve
data modify storage commerce:cp vz346 set from storage commerce:l vz
data modify storage commerce:cp vc346 set from storage commerce:l vc
data modify storage commerce:cp ae346 set from storage commerce:l ae
data modify storage commerce:cp az346 set from storage commerce:l az
data modify storage commerce:cp ac346 set from storage commerce:l ac
data modify storage commerce:cp t346 set from storage commerce:l t
function commerce:page/cat_12_1_d with storage commerce:cp
