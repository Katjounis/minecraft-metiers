function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 381
function commerce:page/ligne
data modify storage commerce:cp ve381 set from storage commerce:l ve
data modify storage commerce:cp vz381 set from storage commerce:l vz
data modify storage commerce:cp vc381 set from storage commerce:l vc
data modify storage commerce:cp ae381 set from storage commerce:l ae
data modify storage commerce:cp az381 set from storage commerce:l az
data modify storage commerce:cp ac381 set from storage commerce:l ac
data modify storage commerce:cp t381 set from storage commerce:l t
scoreboard players set #i c.t 382
function commerce:page/ligne
data modify storage commerce:cp ve382 set from storage commerce:l ve
data modify storage commerce:cp vz382 set from storage commerce:l vz
data modify storage commerce:cp vc382 set from storage commerce:l vc
data modify storage commerce:cp ae382 set from storage commerce:l ae
data modify storage commerce:cp az382 set from storage commerce:l az
data modify storage commerce:cp ac382 set from storage commerce:l ac
data modify storage commerce:cp t382 set from storage commerce:l t
scoreboard players set #i c.t 383
function commerce:page/ligne
data modify storage commerce:cp ve383 set from storage commerce:l ve
data modify storage commerce:cp vz383 set from storage commerce:l vz
data modify storage commerce:cp vc383 set from storage commerce:l vc
data modify storage commerce:cp ae383 set from storage commerce:l ae
data modify storage commerce:cp az383 set from storage commerce:l az
data modify storage commerce:cp ac383 set from storage commerce:l ac
data modify storage commerce:cp t383 set from storage commerce:l t
scoreboard players set #i c.t 384
function commerce:page/ligne
data modify storage commerce:cp ve384 set from storage commerce:l ve
data modify storage commerce:cp vz384 set from storage commerce:l vz
data modify storage commerce:cp vc384 set from storage commerce:l vc
data modify storage commerce:cp ae384 set from storage commerce:l ae
data modify storage commerce:cp az384 set from storage commerce:l az
data modify storage commerce:cp ac384 set from storage commerce:l ac
data modify storage commerce:cp t384 set from storage commerce:l t
scoreboard players set #i c.t 385
function commerce:page/ligne
data modify storage commerce:cp ve385 set from storage commerce:l ve
data modify storage commerce:cp vz385 set from storage commerce:l vz
data modify storage commerce:cp vc385 set from storage commerce:l vc
data modify storage commerce:cp ae385 set from storage commerce:l ae
data modify storage commerce:cp az385 set from storage commerce:l az
data modify storage commerce:cp ac385 set from storage commerce:l ac
data modify storage commerce:cp t385 set from storage commerce:l t
scoreboard players set #i c.t 386
function commerce:page/ligne
data modify storage commerce:cp ve386 set from storage commerce:l ve
data modify storage commerce:cp vz386 set from storage commerce:l vz
data modify storage commerce:cp vc386 set from storage commerce:l vc
data modify storage commerce:cp ae386 set from storage commerce:l ae
data modify storage commerce:cp az386 set from storage commerce:l az
data modify storage commerce:cp ac386 set from storage commerce:l ac
data modify storage commerce:cp t386 set from storage commerce:l t
scoreboard players set #i c.t 387
function commerce:page/ligne
data modify storage commerce:cp ve387 set from storage commerce:l ve
data modify storage commerce:cp vz387 set from storage commerce:l vz
data modify storage commerce:cp vc387 set from storage commerce:l vc
data modify storage commerce:cp ae387 set from storage commerce:l ae
data modify storage commerce:cp az387 set from storage commerce:l az
data modify storage commerce:cp ac387 set from storage commerce:l ac
data modify storage commerce:cp t387 set from storage commerce:l t
scoreboard players set #i c.t 388
function commerce:page/ligne
data modify storage commerce:cp ve388 set from storage commerce:l ve
data modify storage commerce:cp vz388 set from storage commerce:l vz
data modify storage commerce:cp vc388 set from storage commerce:l vc
data modify storage commerce:cp ae388 set from storage commerce:l ae
data modify storage commerce:cp az388 set from storage commerce:l az
data modify storage commerce:cp ac388 set from storage commerce:l ac
data modify storage commerce:cp t388 set from storage commerce:l t
scoreboard players set #i c.t 389
function commerce:page/ligne
data modify storage commerce:cp ve389 set from storage commerce:l ve
data modify storage commerce:cp vz389 set from storage commerce:l vz
data modify storage commerce:cp vc389 set from storage commerce:l vc
data modify storage commerce:cp ae389 set from storage commerce:l ae
data modify storage commerce:cp az389 set from storage commerce:l az
data modify storage commerce:cp ac389 set from storage commerce:l ac
data modify storage commerce:cp t389 set from storage commerce:l t
scoreboard players set #i c.t 390
function commerce:page/ligne
data modify storage commerce:cp ve390 set from storage commerce:l ve
data modify storage commerce:cp vz390 set from storage commerce:l vz
data modify storage commerce:cp vc390 set from storage commerce:l vc
data modify storage commerce:cp ae390 set from storage commerce:l ae
data modify storage commerce:cp az390 set from storage commerce:l az
data modify storage commerce:cp ac390 set from storage commerce:l ac
data modify storage commerce:cp t390 set from storage commerce:l t
function commerce:page/cat_14_2_d with storage commerce:cp
