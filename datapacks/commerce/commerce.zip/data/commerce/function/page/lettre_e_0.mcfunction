function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 400
function commerce:page/ligne
data modify storage commerce:cp ve400 set from storage commerce:l ve
data modify storage commerce:cp vz400 set from storage commerce:l vz
data modify storage commerce:cp vc400 set from storage commerce:l vc
data modify storage commerce:cp ae400 set from storage commerce:l ae
data modify storage commerce:cp az400 set from storage commerce:l az
data modify storage commerce:cp ac400 set from storage commerce:l ac
data modify storage commerce:cp t400 set from storage commerce:l t
scoreboard players set #i c.t 382
function commerce:page/ligne
data modify storage commerce:cp ve382 set from storage commerce:l ve
data modify storage commerce:cp vz382 set from storage commerce:l vz
data modify storage commerce:cp vc382 set from storage commerce:l vc
data modify storage commerce:cp ae382 set from storage commerce:l ae
data modify storage commerce:cp az382 set from storage commerce:l az
data modify storage commerce:cp ac382 set from storage commerce:l ac
data modify storage commerce:cp t382 set from storage commerce:l t
scoreboard players set #i c.t 318
function commerce:page/ligne
data modify storage commerce:cp ve318 set from storage commerce:l ve
data modify storage commerce:cp vz318 set from storage commerce:l vz
data modify storage commerce:cp vc318 set from storage commerce:l vc
data modify storage commerce:cp ae318 set from storage commerce:l ae
data modify storage commerce:cp az318 set from storage commerce:l az
data modify storage commerce:cp ac318 set from storage commerce:l ac
data modify storage commerce:cp t318 set from storage commerce:l t
scoreboard players set #i c.t 317
function commerce:page/ligne
data modify storage commerce:cp ve317 set from storage commerce:l ve
data modify storage commerce:cp vz317 set from storage commerce:l vz
data modify storage commerce:cp vc317 set from storage commerce:l vc
data modify storage commerce:cp ae317 set from storage commerce:l ae
data modify storage commerce:cp az317 set from storage commerce:l az
data modify storage commerce:cp ac317 set from storage commerce:l ac
data modify storage commerce:cp t317 set from storage commerce:l t
scoreboard players set #i c.t 371
function commerce:page/ligne
data modify storage commerce:cp ve371 set from storage commerce:l ve
data modify storage commerce:cp vz371 set from storage commerce:l vz
data modify storage commerce:cp vc371 set from storage commerce:l vc
data modify storage commerce:cp ae371 set from storage commerce:l ae
data modify storage commerce:cp az371 set from storage commerce:l az
data modify storage commerce:cp ac371 set from storage commerce:l ac
data modify storage commerce:cp t371 set from storage commerce:l t
scoreboard players set #i c.t 370
function commerce:page/ligne
data modify storage commerce:cp ve370 set from storage commerce:l ve
data modify storage commerce:cp vz370 set from storage commerce:l vz
data modify storage commerce:cp vc370 set from storage commerce:l vc
data modify storage commerce:cp ae370 set from storage commerce:l ae
data modify storage commerce:cp az370 set from storage commerce:l az
data modify storage commerce:cp ac370 set from storage commerce:l ac
data modify storage commerce:cp t370 set from storage commerce:l t
scoreboard players set #i c.t 244
function commerce:page/ligne
data modify storage commerce:cp ve244 set from storage commerce:l ve
data modify storage commerce:cp vz244 set from storage commerce:l vz
data modify storage commerce:cp vc244 set from storage commerce:l vc
data modify storage commerce:cp ae244 set from storage commerce:l ae
data modify storage commerce:cp az244 set from storage commerce:l az
data modify storage commerce:cp ac244 set from storage commerce:l ac
data modify storage commerce:cp t244 set from storage commerce:l t
scoreboard players set #i c.t 438
function commerce:page/ligne
data modify storage commerce:cp ve438 set from storage commerce:l ve
data modify storage commerce:cp vz438 set from storage commerce:l vz
data modify storage commerce:cp vc438 set from storage commerce:l vc
data modify storage commerce:cp ae438 set from storage commerce:l ae
data modify storage commerce:cp az438 set from storage commerce:l az
data modify storage commerce:cp ac438 set from storage commerce:l ac
data modify storage commerce:cp t438 set from storage commerce:l t
scoreboard players set #i c.t 340
function commerce:page/ligne
data modify storage commerce:cp ve340 set from storage commerce:l ve
data modify storage commerce:cp vz340 set from storage commerce:l vz
data modify storage commerce:cp vc340 set from storage commerce:l vc
data modify storage commerce:cp ae340 set from storage commerce:l ae
data modify storage commerce:cp az340 set from storage commerce:l az
data modify storage commerce:cp ac340 set from storage commerce:l ac
data modify storage commerce:cp t340 set from storage commerce:l t
scoreboard players set #i c.t 433
function commerce:page/ligne
data modify storage commerce:cp ve433 set from storage commerce:l ve
data modify storage commerce:cp vz433 set from storage commerce:l vz
data modify storage commerce:cp vc433 set from storage commerce:l vc
data modify storage commerce:cp ae433 set from storage commerce:l ae
data modify storage commerce:cp az433 set from storage commerce:l az
data modify storage commerce:cp ac433 set from storage commerce:l ac
data modify storage commerce:cp t433 set from storage commerce:l t
function commerce:page/lettre_e_0_d with storage commerce:cp
