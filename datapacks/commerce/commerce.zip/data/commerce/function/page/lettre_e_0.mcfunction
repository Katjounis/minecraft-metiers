function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 398
function commerce:page/ligne
data modify storage commerce:cp ve398 set from storage commerce:l ve
data modify storage commerce:cp vz398 set from storage commerce:l vz
data modify storage commerce:cp vc398 set from storage commerce:l vc
data modify storage commerce:cp ae398 set from storage commerce:l ae
data modify storage commerce:cp az398 set from storage commerce:l az
data modify storage commerce:cp ac398 set from storage commerce:l ac
data modify storage commerce:cp t398 set from storage commerce:l t
scoreboard players set #i c.t 382
function commerce:page/ligne
data modify storage commerce:cp ve382 set from storage commerce:l ve
data modify storage commerce:cp vz382 set from storage commerce:l vz
data modify storage commerce:cp vc382 set from storage commerce:l vc
data modify storage commerce:cp ae382 set from storage commerce:l ae
data modify storage commerce:cp az382 set from storage commerce:l az
data modify storage commerce:cp ac382 set from storage commerce:l ac
data modify storage commerce:cp t382 set from storage commerce:l t
scoreboard players set #i c.t 318
function commerce:page/ligne
data modify storage commerce:cp ve318 set from storage commerce:l ve
data modify storage commerce:cp vz318 set from storage commerce:l vz
data modify storage commerce:cp vc318 set from storage commerce:l vc
data modify storage commerce:cp ae318 set from storage commerce:l ae
data modify storage commerce:cp az318 set from storage commerce:l az
data modify storage commerce:cp ac318 set from storage commerce:l ac
data modify storage commerce:cp t318 set from storage commerce:l t
scoreboard players set #i c.t 317
function commerce:page/ligne
data modify storage commerce:cp ve317 set from storage commerce:l ve
data modify storage commerce:cp vz317 set from storage commerce:l vz
data modify storage commerce:cp vc317 set from storage commerce:l vc
data modify storage commerce:cp ae317 set from storage commerce:l ae
data modify storage commerce:cp az317 set from storage commerce:l az
data modify storage commerce:cp ac317 set from storage commerce:l ac
data modify storage commerce:cp t317 set from storage commerce:l t
scoreboard players set #i c.t 371
function commerce:page/ligne
data modify storage commerce:cp ve371 set from storage commerce:l ve
data modify storage commerce:cp vz371 set from storage commerce:l vz
data modify storage commerce:cp vc371 set from storage commerce:l vc
data modify storage commerce:cp ae371 set from storage commerce:l ae
data modify storage commerce:cp az371 set from storage commerce:l az
data modify storage commerce:cp ac371 set from storage commerce:l ac
data modify storage commerce:cp t371 set from storage commerce:l t
scoreboard players set #i c.t 370
function commerce:page/ligne
data modify storage commerce:cp ve370 set from storage commerce:l ve
data modify storage commerce:cp vz370 set from storage commerce:l vz
data modify storage commerce:cp vc370 set from storage commerce:l vc
data modify storage commerce:cp ae370 set from storage commerce:l ae
data modify storage commerce:cp az370 set from storage commerce:l az
data modify storage commerce:cp ac370 set from storage commerce:l ac
data modify storage commerce:cp t370 set from storage commerce:l t
scoreboard players set #i c.t 244
function commerce:page/ligne
data modify storage commerce:cp ve244 set from storage commerce:l ve
data modify storage commerce:cp vz244 set from storage commerce:l vz
data modify storage commerce:cp vc244 set from storage commerce:l vc
data modify storage commerce:cp ae244 set from storage commerce:l ae
data modify storage commerce:cp az244 set from storage commerce:l az
data modify storage commerce:cp ac244 set from storage commerce:l ac
data modify storage commerce:cp t244 set from storage commerce:l t
scoreboard players set #i c.t 436
function commerce:page/ligne
data modify storage commerce:cp ve436 set from storage commerce:l ve
data modify storage commerce:cp vz436 set from storage commerce:l vz
data modify storage commerce:cp vc436 set from storage commerce:l vc
data modify storage commerce:cp ae436 set from storage commerce:l ae
data modify storage commerce:cp az436 set from storage commerce:l az
data modify storage commerce:cp ac436 set from storage commerce:l ac
data modify storage commerce:cp t436 set from storage commerce:l t
scoreboard players set #i c.t 340
function commerce:page/ligne
data modify storage commerce:cp ve340 set from storage commerce:l ve
data modify storage commerce:cp vz340 set from storage commerce:l vz
data modify storage commerce:cp vc340 set from storage commerce:l vc
data modify storage commerce:cp ae340 set from storage commerce:l ae
data modify storage commerce:cp az340 set from storage commerce:l az
data modify storage commerce:cp ac340 set from storage commerce:l ac
data modify storage commerce:cp t340 set from storage commerce:l t
scoreboard players set #i c.t 431
function commerce:page/ligne
data modify storage commerce:cp ve431 set from storage commerce:l ve
data modify storage commerce:cp vz431 set from storage commerce:l vz
data modify storage commerce:cp vc431 set from storage commerce:l vc
data modify storage commerce:cp ae431 set from storage commerce:l ae
data modify storage commerce:cp az431 set from storage commerce:l az
data modify storage commerce:cp ac431 set from storage commerce:l ac
data modify storage commerce:cp t431 set from storage commerce:l t
function commerce:page/lettre_e_0_d with storage commerce:cp
