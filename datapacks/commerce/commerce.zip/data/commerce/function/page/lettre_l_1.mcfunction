function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 123
function commerce:page/ligne
data modify storage commerce:cp ve123 set from storage commerce:l ve
data modify storage commerce:cp vz123 set from storage commerce:l vz
data modify storage commerce:cp vc123 set from storage commerce:l vc
data modify storage commerce:cp ae123 set from storage commerce:l ae
data modify storage commerce:cp az123 set from storage commerce:l az
data modify storage commerce:cp ac123 set from storage commerce:l ac
data modify storage commerce:cp t123 set from storage commerce:l t
scoreboard players set #i c.t 128
function commerce:page/ligne
data modify storage commerce:cp ve128 set from storage commerce:l ve
data modify storage commerce:cp vz128 set from storage commerce:l vz
data modify storage commerce:cp vc128 set from storage commerce:l vc
data modify storage commerce:cp ae128 set from storage commerce:l ae
data modify storage commerce:cp az128 set from storage commerce:l az
data modify storage commerce:cp ac128 set from storage commerce:l ac
data modify storage commerce:cp t128 set from storage commerce:l t
scoreboard players set #i c.t 136
function commerce:page/ligne
data modify storage commerce:cp ve136 set from storage commerce:l ve
data modify storage commerce:cp vz136 set from storage commerce:l vz
data modify storage commerce:cp vc136 set from storage commerce:l vc
data modify storage commerce:cp ae136 set from storage commerce:l ae
data modify storage commerce:cp az136 set from storage commerce:l az
data modify storage commerce:cp ac136 set from storage commerce:l ac
data modify storage commerce:cp t136 set from storage commerce:l t
scoreboard players set #i c.t 127
function commerce:page/ligne
data modify storage commerce:cp ve127 set from storage commerce:l ve
data modify storage commerce:cp vz127 set from storage commerce:l vz
data modify storage commerce:cp vc127 set from storage commerce:l vc
data modify storage commerce:cp ae127 set from storage commerce:l ae
data modify storage commerce:cp az127 set from storage commerce:l az
data modify storage commerce:cp ac127 set from storage commerce:l ac
data modify storage commerce:cp t127 set from storage commerce:l t
scoreboard players set #i c.t 135
function commerce:page/ligne
data modify storage commerce:cp ve135 set from storage commerce:l ve
data modify storage commerce:cp vz135 set from storage commerce:l vz
data modify storage commerce:cp vc135 set from storage commerce:l vc
data modify storage commerce:cp ae135 set from storage commerce:l ae
data modify storage commerce:cp az135 set from storage commerce:l az
data modify storage commerce:cp ac135 set from storage commerce:l ac
data modify storage commerce:cp t135 set from storage commerce:l t
scoreboard players set #i c.t 132
function commerce:page/ligne
data modify storage commerce:cp ve132 set from storage commerce:l ve
data modify storage commerce:cp vz132 set from storage commerce:l vz
data modify storage commerce:cp vc132 set from storage commerce:l vc
data modify storage commerce:cp ae132 set from storage commerce:l ae
data modify storage commerce:cp az132 set from storage commerce:l az
data modify storage commerce:cp ac132 set from storage commerce:l ac
data modify storage commerce:cp t132 set from storage commerce:l t
scoreboard players set #i c.t 396
function commerce:page/ligne
data modify storage commerce:cp ve396 set from storage commerce:l ve
data modify storage commerce:cp vz396 set from storage commerce:l vz
data modify storage commerce:cp vc396 set from storage commerce:l vc
data modify storage commerce:cp ae396 set from storage commerce:l ae
data modify storage commerce:cp az396 set from storage commerce:l az
data modify storage commerce:cp ac396 set from storage commerce:l ac
data modify storage commerce:cp t396 set from storage commerce:l t
scoreboard players set #i c.t 389
function commerce:page/ligne
data modify storage commerce:cp ve389 set from storage commerce:l ve
data modify storage commerce:cp vz389 set from storage commerce:l vz
data modify storage commerce:cp vc389 set from storage commerce:l vc
data modify storage commerce:cp ae389 set from storage commerce:l ae
data modify storage commerce:cp az389 set from storage commerce:l az
data modify storage commerce:cp ac389 set from storage commerce:l ac
data modify storage commerce:cp t389 set from storage commerce:l t
scoreboard players set #i c.t 363
function commerce:page/ligne
data modify storage commerce:cp ve363 set from storage commerce:l ve
data modify storage commerce:cp vz363 set from storage commerce:l vz
data modify storage commerce:cp vc363 set from storage commerce:l vc
data modify storage commerce:cp ae363 set from storage commerce:l ae
data modify storage commerce:cp az363 set from storage commerce:l az
data modify storage commerce:cp ac363 set from storage commerce:l ac
data modify storage commerce:cp t363 set from storage commerce:l t
scoreboard players set #i c.t 42
function commerce:page/ligne
data modify storage commerce:cp ve42 set from storage commerce:l ve
data modify storage commerce:cp vz42 set from storage commerce:l vz
data modify storage commerce:cp vc42 set from storage commerce:l vc
data modify storage commerce:cp ae42 set from storage commerce:l ae
data modify storage commerce:cp az42 set from storage commerce:l az
data modify storage commerce:cp ac42 set from storage commerce:l ac
data modify storage commerce:cp t42 set from storage commerce:l t
function commerce:page/lettre_l_1_d with storage commerce:cp
