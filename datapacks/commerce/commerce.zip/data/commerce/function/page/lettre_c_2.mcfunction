function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 290
function commerce:page/ligne
data modify storage commerce:cp ve290 set from storage commerce:l ve
data modify storage commerce:cp vz290 set from storage commerce:l vz
data modify storage commerce:cp vc290 set from storage commerce:l vc
data modify storage commerce:cp ae290 set from storage commerce:l ae
data modify storage commerce:cp az290 set from storage commerce:l az
data modify storage commerce:cp ac290 set from storage commerce:l ac
data modify storage commerce:cp t290 set from storage commerce:l t
scoreboard players set #i c.t 291
function commerce:page/ligne
data modify storage commerce:cp ve291 set from storage commerce:l ve
data modify storage commerce:cp vz291 set from storage commerce:l vz
data modify storage commerce:cp vc291 set from storage commerce:l vc
data modify storage commerce:cp ae291 set from storage commerce:l ae
data modify storage commerce:cp az291 set from storage commerce:l az
data modify storage commerce:cp ac291 set from storage commerce:l ac
data modify storage commerce:cp t291 set from storage commerce:l t
scoreboard players set #i c.t 438
function commerce:page/ligne
data modify storage commerce:cp ve438 set from storage commerce:l ve
data modify storage commerce:cp vz438 set from storage commerce:l vz
data modify storage commerce:cp vc438 set from storage commerce:l vc
data modify storage commerce:cp ae438 set from storage commerce:l ae
data modify storage commerce:cp az438 set from storage commerce:l az
data modify storage commerce:cp ac438 set from storage commerce:l ac
data modify storage commerce:cp t438 set from storage commerce:l t
scoreboard players set #i c.t 368
function commerce:page/ligne
data modify storage commerce:cp ve368 set from storage commerce:l ve
data modify storage commerce:cp vz368 set from storage commerce:l vz
data modify storage commerce:cp vc368 set from storage commerce:l vc
data modify storage commerce:cp ae368 set from storage commerce:l ae
data modify storage commerce:cp az368 set from storage commerce:l az
data modify storage commerce:cp ac368 set from storage commerce:l ac
data modify storage commerce:cp t368 set from storage commerce:l t
scoreboard players set #i c.t 386
function commerce:page/ligne
data modify storage commerce:cp ve386 set from storage commerce:l ve
data modify storage commerce:cp vz386 set from storage commerce:l vz
data modify storage commerce:cp vc386 set from storage commerce:l vc
data modify storage commerce:cp ae386 set from storage commerce:l ae
data modify storage commerce:cp az386 set from storage commerce:l az
data modify storage commerce:cp ac386 set from storage commerce:l ac
data modify storage commerce:cp t386 set from storage commerce:l t
scoreboard players set #i c.t 350
function commerce:page/ligne
data modify storage commerce:cp ve350 set from storage commerce:l ve
data modify storage commerce:cp vz350 set from storage commerce:l vz
data modify storage commerce:cp vc350 set from storage commerce:l vc
data modify storage commerce:cp ae350 set from storage commerce:l ae
data modify storage commerce:cp az350 set from storage commerce:l az
data modify storage commerce:cp ac350 set from storage commerce:l ac
data modify storage commerce:cp t350 set from storage commerce:l t
scoreboard players set #i c.t 399
function commerce:page/ligne
data modify storage commerce:cp ve399 set from storage commerce:l ve
data modify storage commerce:cp vz399 set from storage commerce:l vz
data modify storage commerce:cp vc399 set from storage commerce:l vc
data modify storage commerce:cp ae399 set from storage commerce:l ae
data modify storage commerce:cp az399 set from storage commerce:l az
data modify storage commerce:cp ac399 set from storage commerce:l ac
data modify storage commerce:cp t399 set from storage commerce:l t
scoreboard players set #i c.t 437
function commerce:page/ligne
data modify storage commerce:cp ve437 set from storage commerce:l ve
data modify storage commerce:cp vz437 set from storage commerce:l vz
data modify storage commerce:cp vc437 set from storage commerce:l vc
data modify storage commerce:cp ae437 set from storage commerce:l ae
data modify storage commerce:cp az437 set from storage commerce:l az
data modify storage commerce:cp ac437 set from storage commerce:l ac
data modify storage commerce:cp t437 set from storage commerce:l t
scoreboard players set #i c.t 453
function commerce:page/ligne
data modify storage commerce:cp ve453 set from storage commerce:l ve
data modify storage commerce:cp vz453 set from storage commerce:l vz
data modify storage commerce:cp vc453 set from storage commerce:l vc
data modify storage commerce:cp ae453 set from storage commerce:l ae
data modify storage commerce:cp az453 set from storage commerce:l az
data modify storage commerce:cp ac453 set from storage commerce:l ac
data modify storage commerce:cp t453 set from storage commerce:l t
scoreboard players set #i c.t 346
function commerce:page/ligne
data modify storage commerce:cp ve346 set from storage commerce:l ve
data modify storage commerce:cp vz346 set from storage commerce:l vz
data modify storage commerce:cp vc346 set from storage commerce:l vc
data modify storage commerce:cp ae346 set from storage commerce:l ae
data modify storage commerce:cp az346 set from storage commerce:l az
data modify storage commerce:cp ac346 set from storage commerce:l ac
data modify storage commerce:cp t346 set from storage commerce:l t
function commerce:page/lettre_c_2_d with storage commerce:cp
