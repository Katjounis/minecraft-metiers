function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 290
function commerce:page/ligne
data modify storage commerce:cp ve290 set from storage commerce:l ve
data modify storage commerce:cp vz290 set from storage commerce:l vz
data modify storage commerce:cp vc290 set from storage commerce:l vc
data modify storage commerce:cp ae290 set from storage commerce:l ae
data modify storage commerce:cp az290 set from storage commerce:l az
data modify storage commerce:cp ac290 set from storage commerce:l ac
data modify storage commerce:cp t290 set from storage commerce:l t
scoreboard players set #i c.t 291
function commerce:page/ligne
data modify storage commerce:cp ve291 set from storage commerce:l ve
data modify storage commerce:cp vz291 set from storage commerce:l vz
data modify storage commerce:cp vc291 set from storage commerce:l vc
data modify storage commerce:cp ae291 set from storage commerce:l ae
data modify storage commerce:cp az291 set from storage commerce:l az
data modify storage commerce:cp ac291 set from storage commerce:l ac
data modify storage commerce:cp t291 set from storage commerce:l t
scoreboard players set #i c.t 440
function commerce:page/ligne
data modify storage commerce:cp ve440 set from storage commerce:l ve
data modify storage commerce:cp vz440 set from storage commerce:l vz
data modify storage commerce:cp vc440 set from storage commerce:l vc
data modify storage commerce:cp ae440 set from storage commerce:l ae
data modify storage commerce:cp az440 set from storage commerce:l az
data modify storage commerce:cp ac440 set from storage commerce:l ac
data modify storage commerce:cp t440 set from storage commerce:l t
scoreboard players set #i c.t 368
function commerce:page/ligne
data modify storage commerce:cp ve368 set from storage commerce:l ve
data modify storage commerce:cp vz368 set from storage commerce:l vz
data modify storage commerce:cp vc368 set from storage commerce:l vc
data modify storage commerce:cp ae368 set from storage commerce:l ae
data modify storage commerce:cp az368 set from storage commerce:l az
data modify storage commerce:cp ac368 set from storage commerce:l ac
data modify storage commerce:cp t368 set from storage commerce:l t
scoreboard players set #i c.t 386
function commerce:page/ligne
data modify storage commerce:cp ve386 set from storage commerce:l ve
data modify storage commerce:cp vz386 set from storage commerce:l vz
data modify storage commerce:cp vc386 set from storage commerce:l vc
data modify storage commerce:cp ae386 set from storage commerce:l ae
data modify storage commerce:cp az386 set from storage commerce:l az
data modify storage commerce:cp ac386 set from storage commerce:l ac
data modify storage commerce:cp t386 set from storage commerce:l t
scoreboard players set #i c.t 350
function commerce:page/ligne
data modify storage commerce:cp ve350 set from storage commerce:l ve
data modify storage commerce:cp vz350 set from storage commerce:l vz
data modify storage commerce:cp vc350 set from storage commerce:l vc
data modify storage commerce:cp ae350 set from storage commerce:l ae
data modify storage commerce:cp az350 set from storage commerce:l az
data modify storage commerce:cp ac350 set from storage commerce:l ac
data modify storage commerce:cp t350 set from storage commerce:l t
scoreboard players set #i c.t 401
function commerce:page/ligne
data modify storage commerce:cp ve401 set from storage commerce:l ve
data modify storage commerce:cp vz401 set from storage commerce:l vz
data modify storage commerce:cp vc401 set from storage commerce:l vc
data modify storage commerce:cp ae401 set from storage commerce:l ae
data modify storage commerce:cp az401 set from storage commerce:l az
data modify storage commerce:cp ac401 set from storage commerce:l ac
data modify storage commerce:cp t401 set from storage commerce:l t
scoreboard players set #i c.t 439
function commerce:page/ligne
data modify storage commerce:cp ve439 set from storage commerce:l ve
data modify storage commerce:cp vz439 set from storage commerce:l vz
data modify storage commerce:cp vc439 set from storage commerce:l vc
data modify storage commerce:cp ae439 set from storage commerce:l ae
data modify storage commerce:cp az439 set from storage commerce:l az
data modify storage commerce:cp ac439 set from storage commerce:l ac
data modify storage commerce:cp t439 set from storage commerce:l t
scoreboard players set #i c.t 455
function commerce:page/ligne
data modify storage commerce:cp ve455 set from storage commerce:l ve
data modify storage commerce:cp vz455 set from storage commerce:l vz
data modify storage commerce:cp vc455 set from storage commerce:l vc
data modify storage commerce:cp ae455 set from storage commerce:l ae
data modify storage commerce:cp az455 set from storage commerce:l az
data modify storage commerce:cp ac455 set from storage commerce:l ac
data modify storage commerce:cp t455 set from storage commerce:l t
scoreboard players set #i c.t 346
function commerce:page/ligne
data modify storage commerce:cp ve346 set from storage commerce:l ve
data modify storage commerce:cp vz346 set from storage commerce:l vz
data modify storage commerce:cp vc346 set from storage commerce:l vc
data modify storage commerce:cp ae346 set from storage commerce:l ae
data modify storage commerce:cp az346 set from storage commerce:l az
data modify storage commerce:cp ac346 set from storage commerce:l ac
data modify storage commerce:cp t346 set from storage commerce:l t
function commerce:page/lettre_c_2_d with storage commerce:cp
