function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 260
function commerce:page/ligne
data modify storage commerce:cp ve260 set from storage commerce:l ve
data modify storage commerce:cp vz260 set from storage commerce:l vz
data modify storage commerce:cp vc260 set from storage commerce:l vc
data modify storage commerce:cp ae260 set from storage commerce:l ae
data modify storage commerce:cp az260 set from storage commerce:l az
data modify storage commerce:cp ac260 set from storage commerce:l ac
data modify storage commerce:cp t260 set from storage commerce:l t
scoreboard players set #i c.t 261
function commerce:page/ligne
data modify storage commerce:cp ve261 set from storage commerce:l ve
data modify storage commerce:cp vz261 set from storage commerce:l vz
data modify storage commerce:cp vc261 set from storage commerce:l vc
data modify storage commerce:cp ae261 set from storage commerce:l ae
data modify storage commerce:cp az261 set from storage commerce:l az
data modify storage commerce:cp ac261 set from storage commerce:l ac
data modify storage commerce:cp t261 set from storage commerce:l t
scoreboard players set #i c.t 262
function commerce:page/ligne
data modify storage commerce:cp ve262 set from storage commerce:l ve
data modify storage commerce:cp vz262 set from storage commerce:l vz
data modify storage commerce:cp vc262 set from storage commerce:l vc
data modify storage commerce:cp ae262 set from storage commerce:l ae
data modify storage commerce:cp az262 set from storage commerce:l az
data modify storage commerce:cp ac262 set from storage commerce:l ac
data modify storage commerce:cp t262 set from storage commerce:l t
scoreboard players set #i c.t 263
function commerce:page/ligne
data modify storage commerce:cp ve263 set from storage commerce:l ve
data modify storage commerce:cp vz263 set from storage commerce:l vz
data modify storage commerce:cp vc263 set from storage commerce:l vc
data modify storage commerce:cp ae263 set from storage commerce:l ae
data modify storage commerce:cp az263 set from storage commerce:l az
data modify storage commerce:cp ac263 set from storage commerce:l ac
data modify storage commerce:cp t263 set from storage commerce:l t
scoreboard players set #i c.t 264
function commerce:page/ligne
data modify storage commerce:cp ve264 set from storage commerce:l ve
data modify storage commerce:cp vz264 set from storage commerce:l vz
data modify storage commerce:cp vc264 set from storage commerce:l vc
data modify storage commerce:cp ae264 set from storage commerce:l ae
data modify storage commerce:cp az264 set from storage commerce:l az
data modify storage commerce:cp ac264 set from storage commerce:l ac
data modify storage commerce:cp t264 set from storage commerce:l t
scoreboard players set #i c.t 265
function commerce:page/ligne
data modify storage commerce:cp ve265 set from storage commerce:l ve
data modify storage commerce:cp vz265 set from storage commerce:l vz
data modify storage commerce:cp vc265 set from storage commerce:l vc
data modify storage commerce:cp ae265 set from storage commerce:l ae
data modify storage commerce:cp az265 set from storage commerce:l az
data modify storage commerce:cp ac265 set from storage commerce:l ac
data modify storage commerce:cp t265 set from storage commerce:l t
scoreboard players set #i c.t 266
function commerce:page/ligne
data modify storage commerce:cp ve266 set from storage commerce:l ve
data modify storage commerce:cp vz266 set from storage commerce:l vz
data modify storage commerce:cp vc266 set from storage commerce:l vc
data modify storage commerce:cp ae266 set from storage commerce:l ae
data modify storage commerce:cp az266 set from storage commerce:l az
data modify storage commerce:cp ac266 set from storage commerce:l ac
data modify storage commerce:cp t266 set from storage commerce:l t
scoreboard players set #i c.t 267
function commerce:page/ligne
data modify storage commerce:cp ve267 set from storage commerce:l ve
data modify storage commerce:cp vz267 set from storage commerce:l vz
data modify storage commerce:cp vc267 set from storage commerce:l vc
data modify storage commerce:cp ae267 set from storage commerce:l ae
data modify storage commerce:cp az267 set from storage commerce:l az
data modify storage commerce:cp ac267 set from storage commerce:l ac
data modify storage commerce:cp t267 set from storage commerce:l t
scoreboard players set #i c.t 268
function commerce:page/ligne
data modify storage commerce:cp ve268 set from storage commerce:l ve
data modify storage commerce:cp vz268 set from storage commerce:l vz
data modify storage commerce:cp vc268 set from storage commerce:l vc
data modify storage commerce:cp ae268 set from storage commerce:l ae
data modify storage commerce:cp az268 set from storage commerce:l az
data modify storage commerce:cp ac268 set from storage commerce:l ac
data modify storage commerce:cp t268 set from storage commerce:l t
scoreboard players set #i c.t 269
function commerce:page/ligne
data modify storage commerce:cp ve269 set from storage commerce:l ve
data modify storage commerce:cp vz269 set from storage commerce:l vz
data modify storage commerce:cp vc269 set from storage commerce:l vc
data modify storage commerce:cp ae269 set from storage commerce:l ae
data modify storage commerce:cp az269 set from storage commerce:l az
data modify storage commerce:cp ac269 set from storage commerce:l ac
data modify storage commerce:cp t269 set from storage commerce:l t
function commerce:page/cat_9_1_d with storage commerce:cp
