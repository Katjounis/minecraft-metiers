function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 299
function commerce:page/ligne
data modify storage commerce:cp ve299 set from storage commerce:l ve
data modify storage commerce:cp vz299 set from storage commerce:l vz
data modify storage commerce:cp vc299 set from storage commerce:l vc
data modify storage commerce:cp ae299 set from storage commerce:l ae
data modify storage commerce:cp az299 set from storage commerce:l az
data modify storage commerce:cp ac299 set from storage commerce:l ac
data modify storage commerce:cp t299 set from storage commerce:l t
scoreboard players set #i c.t 298
function commerce:page/ligne
data modify storage commerce:cp ve298 set from storage commerce:l ve
data modify storage commerce:cp vz298 set from storage commerce:l vz
data modify storage commerce:cp vc298 set from storage commerce:l vc
data modify storage commerce:cp ae298 set from storage commerce:l ae
data modify storage commerce:cp az298 set from storage commerce:l az
data modify storage commerce:cp ac298 set from storage commerce:l ac
data modify storage commerce:cp t298 set from storage commerce:l t
scoreboard players set #i c.t 301
function commerce:page/ligne
data modify storage commerce:cp ve301 set from storage commerce:l ve
data modify storage commerce:cp vz301 set from storage commerce:l vz
data modify storage commerce:cp vc301 set from storage commerce:l vc
data modify storage commerce:cp ae301 set from storage commerce:l ae
data modify storage commerce:cp az301 set from storage commerce:l az
data modify storage commerce:cp ac301 set from storage commerce:l ac
data modify storage commerce:cp t301 set from storage commerce:l t
scoreboard players set #i c.t 247
function commerce:page/ligne
data modify storage commerce:cp ve247 set from storage commerce:l ve
data modify storage commerce:cp vz247 set from storage commerce:l vz
data modify storage commerce:cp vc247 set from storage commerce:l vc
data modify storage commerce:cp ae247 set from storage commerce:l ae
data modify storage commerce:cp az247 set from storage commerce:l az
data modify storage commerce:cp ac247 set from storage commerce:l ac
data modify storage commerce:cp t247 set from storage commerce:l t
scoreboard players set #i c.t 254
function commerce:page/ligne
data modify storage commerce:cp ve254 set from storage commerce:l ve
data modify storage commerce:cp vz254 set from storage commerce:l vz
data modify storage commerce:cp vc254 set from storage commerce:l vc
data modify storage commerce:cp ae254 set from storage commerce:l ae
data modify storage commerce:cp az254 set from storage commerce:l az
data modify storage commerce:cp ac254 set from storage commerce:l ac
data modify storage commerce:cp t254 set from storage commerce:l t
scoreboard players set #i c.t 256
function commerce:page/ligne
data modify storage commerce:cp ve256 set from storage commerce:l ve
data modify storage commerce:cp vz256 set from storage commerce:l vz
data modify storage commerce:cp vc256 set from storage commerce:l vc
data modify storage commerce:cp ae256 set from storage commerce:l ae
data modify storage commerce:cp az256 set from storage commerce:l az
data modify storage commerce:cp ac256 set from storage commerce:l ac
data modify storage commerce:cp t256 set from storage commerce:l t
scoreboard players set #i c.t 255
function commerce:page/ligne
data modify storage commerce:cp ve255 set from storage commerce:l ve
data modify storage commerce:cp vz255 set from storage commerce:l vz
data modify storage commerce:cp vc255 set from storage commerce:l vc
data modify storage commerce:cp ae255 set from storage commerce:l ae
data modify storage commerce:cp az255 set from storage commerce:l az
data modify storage commerce:cp ac255 set from storage commerce:l ac
data modify storage commerce:cp t255 set from storage commerce:l t
scoreboard players set #i c.t 120
function commerce:page/ligne
data modify storage commerce:cp ve120 set from storage commerce:l ve
data modify storage commerce:cp vz120 set from storage commerce:l vz
data modify storage commerce:cp vc120 set from storage commerce:l vc
data modify storage commerce:cp ae120 set from storage commerce:l ae
data modify storage commerce:cp az120 set from storage commerce:l az
data modify storage commerce:cp ac120 set from storage commerce:l ac
data modify storage commerce:cp t120 set from storage commerce:l t
scoreboard players set #i c.t 329
function commerce:page/ligne
data modify storage commerce:cp ve329 set from storage commerce:l ve
data modify storage commerce:cp vz329 set from storage commerce:l vz
data modify storage commerce:cp vc329 set from storage commerce:l vc
data modify storage commerce:cp ae329 set from storage commerce:l ae
data modify storage commerce:cp az329 set from storage commerce:l az
data modify storage commerce:cp ac329 set from storage commerce:l ac
data modify storage commerce:cp t329 set from storage commerce:l t
scoreboard players set #i c.t 332
function commerce:page/ligne
data modify storage commerce:cp ve332 set from storage commerce:l ve
data modify storage commerce:cp vz332 set from storage commerce:l vz
data modify storage commerce:cp vc332 set from storage commerce:l vc
data modify storage commerce:cp ae332 set from storage commerce:l ae
data modify storage commerce:cp az332 set from storage commerce:l az
data modify storage commerce:cp ac332 set from storage commerce:l ac
data modify storage commerce:cp t332 set from storage commerce:l t
function commerce:page/lettre_b_0_d with storage commerce:cp
