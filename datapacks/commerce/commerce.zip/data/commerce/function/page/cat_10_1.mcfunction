function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 289
function commerce:page/ligne
data modify storage commerce:cp ve289 set from storage commerce:l ve
data modify storage commerce:cp vz289 set from storage commerce:l vz
data modify storage commerce:cp vc289 set from storage commerce:l vc
data modify storage commerce:cp ae289 set from storage commerce:l ae
data modify storage commerce:cp az289 set from storage commerce:l az
data modify storage commerce:cp ac289 set from storage commerce:l ac
data modify storage commerce:cp t289 set from storage commerce:l t
scoreboard players set #i c.t 290
function commerce:page/ligne
data modify storage commerce:cp ve290 set from storage commerce:l ve
data modify storage commerce:cp vz290 set from storage commerce:l vz
data modify storage commerce:cp vc290 set from storage commerce:l vc
data modify storage commerce:cp ae290 set from storage commerce:l ae
data modify storage commerce:cp az290 set from storage commerce:l az
data modify storage commerce:cp ac290 set from storage commerce:l ac
data modify storage commerce:cp t290 set from storage commerce:l t
scoreboard players set #i c.t 291
function commerce:page/ligne
data modify storage commerce:cp ve291 set from storage commerce:l ve
data modify storage commerce:cp vz291 set from storage commerce:l vz
data modify storage commerce:cp vc291 set from storage commerce:l vc
data modify storage commerce:cp ae291 set from storage commerce:l ae
data modify storage commerce:cp az291 set from storage commerce:l az
data modify storage commerce:cp ac291 set from storage commerce:l ac
data modify storage commerce:cp t291 set from storage commerce:l t
scoreboard players set #i c.t 292
function commerce:page/ligne
data modify storage commerce:cp ve292 set from storage commerce:l ve
data modify storage commerce:cp vz292 set from storage commerce:l vz
data modify storage commerce:cp vc292 set from storage commerce:l vc
data modify storage commerce:cp ae292 set from storage commerce:l ae
data modify storage commerce:cp az292 set from storage commerce:l az
data modify storage commerce:cp ac292 set from storage commerce:l ac
data modify storage commerce:cp t292 set from storage commerce:l t
scoreboard players set #i c.t 293
function commerce:page/ligne
data modify storage commerce:cp ve293 set from storage commerce:l ve
data modify storage commerce:cp vz293 set from storage commerce:l vz
data modify storage commerce:cp vc293 set from storage commerce:l vc
data modify storage commerce:cp ae293 set from storage commerce:l ae
data modify storage commerce:cp az293 set from storage commerce:l az
data modify storage commerce:cp ac293 set from storage commerce:l ac
data modify storage commerce:cp t293 set from storage commerce:l t
scoreboard players set #i c.t 294
function commerce:page/ligne
data modify storage commerce:cp ve294 set from storage commerce:l ve
data modify storage commerce:cp vz294 set from storage commerce:l vz
data modify storage commerce:cp vc294 set from storage commerce:l vc
data modify storage commerce:cp ae294 set from storage commerce:l ae
data modify storage commerce:cp az294 set from storage commerce:l az
data modify storage commerce:cp ac294 set from storage commerce:l ac
data modify storage commerce:cp t294 set from storage commerce:l t
scoreboard players set #i c.t 295
function commerce:page/ligne
data modify storage commerce:cp ve295 set from storage commerce:l ve
data modify storage commerce:cp vz295 set from storage commerce:l vz
data modify storage commerce:cp vc295 set from storage commerce:l vc
data modify storage commerce:cp ae295 set from storage commerce:l ae
data modify storage commerce:cp az295 set from storage commerce:l az
data modify storage commerce:cp ac295 set from storage commerce:l ac
data modify storage commerce:cp t295 set from storage commerce:l t
scoreboard players set #i c.t 296
function commerce:page/ligne
data modify storage commerce:cp ve296 set from storage commerce:l ve
data modify storage commerce:cp vz296 set from storage commerce:l vz
data modify storage commerce:cp vc296 set from storage commerce:l vc
data modify storage commerce:cp ae296 set from storage commerce:l ae
data modify storage commerce:cp az296 set from storage commerce:l az
data modify storage commerce:cp ac296 set from storage commerce:l ac
data modify storage commerce:cp t296 set from storage commerce:l t
scoreboard players set #i c.t 297
function commerce:page/ligne
data modify storage commerce:cp ve297 set from storage commerce:l ve
data modify storage commerce:cp vz297 set from storage commerce:l vz
data modify storage commerce:cp vc297 set from storage commerce:l vc
data modify storage commerce:cp ae297 set from storage commerce:l ae
data modify storage commerce:cp az297 set from storage commerce:l az
data modify storage commerce:cp ac297 set from storage commerce:l ac
data modify storage commerce:cp t297 set from storage commerce:l t
scoreboard players set #i c.t 298
function commerce:page/ligne
data modify storage commerce:cp ve298 set from storage commerce:l ve
data modify storage commerce:cp vz298 set from storage commerce:l vz
data modify storage commerce:cp vc298 set from storage commerce:l vc
data modify storage commerce:cp ae298 set from storage commerce:l ae
data modify storage commerce:cp az298 set from storage commerce:l az
data modify storage commerce:cp ac298 set from storage commerce:l ac
data modify storage commerce:cp t298 set from storage commerce:l t
function commerce:page/cat_10_1_d with storage commerce:cp
