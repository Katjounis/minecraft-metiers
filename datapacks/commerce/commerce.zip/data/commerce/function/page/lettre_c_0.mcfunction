function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 300
function commerce:page/ligne
data modify storage commerce:cp ve300 set from storage commerce:l ve
data modify storage commerce:cp vz300 set from storage commerce:l vz
data modify storage commerce:cp vc300 set from storage commerce:l vc
data modify storage commerce:cp ae300 set from storage commerce:l ae
data modify storage commerce:cp az300 set from storage commerce:l az
data modify storage commerce:cp ac300 set from storage commerce:l ac
data modify storage commerce:cp t300 set from storage commerce:l t
scoreboard players set #i c.t 374
function commerce:page/ligne
data modify storage commerce:cp ve374 set from storage commerce:l ve
data modify storage commerce:cp vz374 set from storage commerce:l vz
data modify storage commerce:cp vc374 set from storage commerce:l vc
data modify storage commerce:cp ae374 set from storage commerce:l ae
data modify storage commerce:cp az374 set from storage commerce:l az
data modify storage commerce:cp ac374 set from storage commerce:l ac
data modify storage commerce:cp t374 set from storage commerce:l t
scoreboard players set #i c.t 24
function commerce:page/ligne
data modify storage commerce:cp ve24 set from storage commerce:l ve
data modify storage commerce:cp vz24 set from storage commerce:l vz
data modify storage commerce:cp vc24 set from storage commerce:l vc
data modify storage commerce:cp ae24 set from storage commerce:l ae
data modify storage commerce:cp az24 set from storage commerce:l az
data modify storage commerce:cp ac24 set from storage commerce:l ac
data modify storage commerce:cp t24 set from storage commerce:l t
scoreboard players set #i c.t 392
function commerce:page/ligne
data modify storage commerce:cp ve392 set from storage commerce:l ve
data modify storage commerce:cp vz392 set from storage commerce:l vz
data modify storage commerce:cp vc392 set from storage commerce:l vc
data modify storage commerce:cp ae392 set from storage commerce:l ae
data modify storage commerce:cp az392 set from storage commerce:l az
data modify storage commerce:cp ac392 set from storage commerce:l ac
data modify storage commerce:cp t392 set from storage commerce:l t
scoreboard players set #i c.t 293
function commerce:page/ligne
data modify storage commerce:cp ve293 set from storage commerce:l ve
data modify storage commerce:cp vz293 set from storage commerce:l vz
data modify storage commerce:cp vc293 set from storage commerce:l vc
data modify storage commerce:cp ae293 set from storage commerce:l ae
data modify storage commerce:cp az293 set from storage commerce:l az
data modify storage commerce:cp ac293 set from storage commerce:l ac
data modify storage commerce:cp t293 set from storage commerce:l t
scoreboard players set #i c.t 442
function commerce:page/ligne
data modify storage commerce:cp ve442 set from storage commerce:l ve
data modify storage commerce:cp vz442 set from storage commerce:l vz
data modify storage commerce:cp vc442 set from storage commerce:l vc
data modify storage commerce:cp ae442 set from storage commerce:l ae
data modify storage commerce:cp az442 set from storage commerce:l az
data modify storage commerce:cp ac442 set from storage commerce:l ac
data modify storage commerce:cp t442 set from storage commerce:l t
scoreboard players set #i c.t 282
function commerce:page/ligne
data modify storage commerce:cp ve282 set from storage commerce:l ve
data modify storage commerce:cp vz282 set from storage commerce:l vz
data modify storage commerce:cp vc282 set from storage commerce:l vc
data modify storage commerce:cp ae282 set from storage commerce:l ae
data modify storage commerce:cp az282 set from storage commerce:l az
data modify storage commerce:cp ac282 set from storage commerce:l ac
data modify storage commerce:cp t282 set from storage commerce:l t
scoreboard players set #i c.t 351
function commerce:page/ligne
data modify storage commerce:cp ve351 set from storage commerce:l ve
data modify storage commerce:cp vz351 set from storage commerce:l vz
data modify storage commerce:cp vc351 set from storage commerce:l vc
data modify storage commerce:cp ae351 set from storage commerce:l ae
data modify storage commerce:cp az351 set from storage commerce:l az
data modify storage commerce:cp ac351 set from storage commerce:l ac
data modify storage commerce:cp t351 set from storage commerce:l t
scoreboard players set #i c.t 19
function commerce:page/ligne
data modify storage commerce:cp ve19 set from storage commerce:l ve
data modify storage commerce:cp vz19 set from storage commerce:l vz
data modify storage commerce:cp vc19 set from storage commerce:l vc
data modify storage commerce:cp ae19 set from storage commerce:l ae
data modify storage commerce:cp az19 set from storage commerce:l az
data modify storage commerce:cp ac19 set from storage commerce:l ac
data modify storage commerce:cp t19 set from storage commerce:l t
scoreboard players set #i c.t 319
function commerce:page/ligne
data modify storage commerce:cp ve319 set from storage commerce:l ve
data modify storage commerce:cp vz319 set from storage commerce:l vz
data modify storage commerce:cp vc319 set from storage commerce:l vc
data modify storage commerce:cp ae319 set from storage commerce:l ae
data modify storage commerce:cp az319 set from storage commerce:l az
data modify storage commerce:cp ac319 set from storage commerce:l ac
data modify storage commerce:cp t319 set from storage commerce:l t
function commerce:page/lettre_c_0_d with storage commerce:cp
