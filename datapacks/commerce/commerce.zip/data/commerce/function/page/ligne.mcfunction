function commerce:item/charger
scoreboard players set #d c.t 0
function commerce:prix/mid
function commerce:prix/bonus
function commerce:prix/vente
scoreboard players operation #x c.t = #u c.t
function commerce:fmt/centi
data modify storage commerce:l ve set from storage commerce:t f.e
data modify storage commerce:l vz set from storage commerce:t f.z
data modify storage commerce:l vc set from storage commerce:t f.c
scoreboard players operation #x c.t = #a c.t
function commerce:fmt/centi
data modify storage commerce:l ae set from storage commerce:t f.e
data modify storage commerce:l az set from storage commerce:t f.z
data modify storage commerce:l ac set from storage commerce:t f.c
function commerce:fmt/tendance
data modify storage commerce:l t set from storage commerce:t tr
data modify storage commerce:l tc set from storage commerce:t trc
