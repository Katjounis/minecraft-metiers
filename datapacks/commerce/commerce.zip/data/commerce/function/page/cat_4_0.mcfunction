function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 88
function commerce:page/ligne
data modify storage commerce:cp ve88 set from storage commerce:l ve
data modify storage commerce:cp vz88 set from storage commerce:l vz
data modify storage commerce:cp vc88 set from storage commerce:l vc
data modify storage commerce:cp ae88 set from storage commerce:l ae
data modify storage commerce:cp az88 set from storage commerce:l az
data modify storage commerce:cp ac88 set from storage commerce:l ac
data modify storage commerce:cp t88 set from storage commerce:l t
scoreboard players set #i c.t 89
function commerce:page/ligne
data modify storage commerce:cp ve89 set from storage commerce:l ve
data modify storage commerce:cp vz89 set from storage commerce:l vz
data modify storage commerce:cp vc89 set from storage commerce:l vc
data modify storage commerce:cp ae89 set from storage commerce:l ae
data modify storage commerce:cp az89 set from storage commerce:l az
data modify storage commerce:cp ac89 set from storage commerce:l ac
data modify storage commerce:cp t89 set from storage commerce:l t
scoreboard players set #i c.t 90
function commerce:page/ligne
data modify storage commerce:cp ve90 set from storage commerce:l ve
data modify storage commerce:cp vz90 set from storage commerce:l vz
data modify storage commerce:cp vc90 set from storage commerce:l vc
data modify storage commerce:cp ae90 set from storage commerce:l ae
data modify storage commerce:cp az90 set from storage commerce:l az
data modify storage commerce:cp ac90 set from storage commerce:l ac
data modify storage commerce:cp t90 set from storage commerce:l t
scoreboard players set #i c.t 91
function commerce:page/ligne
data modify storage commerce:cp ve91 set from storage commerce:l ve
data modify storage commerce:cp vz91 set from storage commerce:l vz
data modify storage commerce:cp vc91 set from storage commerce:l vc
data modify storage commerce:cp ae91 set from storage commerce:l ae
data modify storage commerce:cp az91 set from storage commerce:l az
data modify storage commerce:cp ac91 set from storage commerce:l ac
data modify storage commerce:cp t91 set from storage commerce:l t
scoreboard players set #i c.t 92
function commerce:page/ligne
data modify storage commerce:cp ve92 set from storage commerce:l ve
data modify storage commerce:cp vz92 set from storage commerce:l vz
data modify storage commerce:cp vc92 set from storage commerce:l vc
data modify storage commerce:cp ae92 set from storage commerce:l ae
data modify storage commerce:cp az92 set from storage commerce:l az
data modify storage commerce:cp ac92 set from storage commerce:l ac
data modify storage commerce:cp t92 set from storage commerce:l t
scoreboard players set #i c.t 93
function commerce:page/ligne
data modify storage commerce:cp ve93 set from storage commerce:l ve
data modify storage commerce:cp vz93 set from storage commerce:l vz
data modify storage commerce:cp vc93 set from storage commerce:l vc
data modify storage commerce:cp ae93 set from storage commerce:l ae
data modify storage commerce:cp az93 set from storage commerce:l az
data modify storage commerce:cp ac93 set from storage commerce:l ac
data modify storage commerce:cp t93 set from storage commerce:l t
scoreboard players set #i c.t 94
function commerce:page/ligne
data modify storage commerce:cp ve94 set from storage commerce:l ve
data modify storage commerce:cp vz94 set from storage commerce:l vz
data modify storage commerce:cp vc94 set from storage commerce:l vc
data modify storage commerce:cp ae94 set from storage commerce:l ae
data modify storage commerce:cp az94 set from storage commerce:l az
data modify storage commerce:cp ac94 set from storage commerce:l ac
data modify storage commerce:cp t94 set from storage commerce:l t
scoreboard players set #i c.t 95
function commerce:page/ligne
data modify storage commerce:cp ve95 set from storage commerce:l ve
data modify storage commerce:cp vz95 set from storage commerce:l vz
data modify storage commerce:cp vc95 set from storage commerce:l vc
data modify storage commerce:cp ae95 set from storage commerce:l ae
data modify storage commerce:cp az95 set from storage commerce:l az
data modify storage commerce:cp ac95 set from storage commerce:l ac
data modify storage commerce:cp t95 set from storage commerce:l t
scoreboard players set #i c.t 96
function commerce:page/ligne
data modify storage commerce:cp ve96 set from storage commerce:l ve
data modify storage commerce:cp vz96 set from storage commerce:l vz
data modify storage commerce:cp vc96 set from storage commerce:l vc
data modify storage commerce:cp ae96 set from storage commerce:l ae
data modify storage commerce:cp az96 set from storage commerce:l az
data modify storage commerce:cp ac96 set from storage commerce:l ac
data modify storage commerce:cp t96 set from storage commerce:l t
scoreboard players set #i c.t 97
function commerce:page/ligne
data modify storage commerce:cp ve97 set from storage commerce:l ve
data modify storage commerce:cp vz97 set from storage commerce:l vz
data modify storage commerce:cp vc97 set from storage commerce:l vc
data modify storage commerce:cp ae97 set from storage commerce:l ae
data modify storage commerce:cp az97 set from storage commerce:l az
data modify storage commerce:cp ac97 set from storage commerce:l ac
data modify storage commerce:cp t97 set from storage commerce:l t
function commerce:page/cat_4_0_d with storage commerce:cp
