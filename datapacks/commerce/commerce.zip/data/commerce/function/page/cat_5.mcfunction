function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 122
function commerce:page/ligne
data modify storage commerce:cp ve122 set from storage commerce:l ve
data modify storage commerce:cp vz122 set from storage commerce:l vz
data modify storage commerce:cp vc122 set from storage commerce:l vc
data modify storage commerce:cp ae122 set from storage commerce:l ae
data modify storage commerce:cp az122 set from storage commerce:l az
data modify storage commerce:cp ac122 set from storage commerce:l ac
data modify storage commerce:cp t122 set from storage commerce:l t
data modify storage commerce:cp tc122 set from storage commerce:l tc
scoreboard players set #i c.t 123
function commerce:page/ligne
data modify storage commerce:cp ve123 set from storage commerce:l ve
data modify storage commerce:cp vz123 set from storage commerce:l vz
data modify storage commerce:cp vc123 set from storage commerce:l vc
data modify storage commerce:cp ae123 set from storage commerce:l ae
data modify storage commerce:cp az123 set from storage commerce:l az
data modify storage commerce:cp ac123 set from storage commerce:l ac
data modify storage commerce:cp t123 set from storage commerce:l t
data modify storage commerce:cp tc123 set from storage commerce:l tc
scoreboard players set #i c.t 124
function commerce:page/ligne
data modify storage commerce:cp ve124 set from storage commerce:l ve
data modify storage commerce:cp vz124 set from storage commerce:l vz
data modify storage commerce:cp vc124 set from storage commerce:l vc
data modify storage commerce:cp ae124 set from storage commerce:l ae
data modify storage commerce:cp az124 set from storage commerce:l az
data modify storage commerce:cp ac124 set from storage commerce:l ac
data modify storage commerce:cp t124 set from storage commerce:l t
data modify storage commerce:cp tc124 set from storage commerce:l tc
scoreboard players set #i c.t 125
function commerce:page/ligne
data modify storage commerce:cp ve125 set from storage commerce:l ve
data modify storage commerce:cp vz125 set from storage commerce:l vz
data modify storage commerce:cp vc125 set from storage commerce:l vc
data modify storage commerce:cp ae125 set from storage commerce:l ae
data modify storage commerce:cp az125 set from storage commerce:l az
data modify storage commerce:cp ac125 set from storage commerce:l ac
data modify storage commerce:cp t125 set from storage commerce:l t
data modify storage commerce:cp tc125 set from storage commerce:l tc
scoreboard players set #i c.t 126
function commerce:page/ligne
data modify storage commerce:cp ve126 set from storage commerce:l ve
data modify storage commerce:cp vz126 set from storage commerce:l vz
data modify storage commerce:cp vc126 set from storage commerce:l vc
data modify storage commerce:cp ae126 set from storage commerce:l ae
data modify storage commerce:cp az126 set from storage commerce:l az
data modify storage commerce:cp ac126 set from storage commerce:l ac
data modify storage commerce:cp t126 set from storage commerce:l t
data modify storage commerce:cp tc126 set from storage commerce:l tc
scoreboard players set #i c.t 127
function commerce:page/ligne
data modify storage commerce:cp ve127 set from storage commerce:l ve
data modify storage commerce:cp vz127 set from storage commerce:l vz
data modify storage commerce:cp vc127 set from storage commerce:l vc
data modify storage commerce:cp ae127 set from storage commerce:l ae
data modify storage commerce:cp az127 set from storage commerce:l az
data modify storage commerce:cp ac127 set from storage commerce:l ac
data modify storage commerce:cp t127 set from storage commerce:l t
data modify storage commerce:cp tc127 set from storage commerce:l tc
scoreboard players set #i c.t 128
function commerce:page/ligne
data modify storage commerce:cp ve128 set from storage commerce:l ve
data modify storage commerce:cp vz128 set from storage commerce:l vz
data modify storage commerce:cp vc128 set from storage commerce:l vc
data modify storage commerce:cp ae128 set from storage commerce:l ae
data modify storage commerce:cp az128 set from storage commerce:l az
data modify storage commerce:cp ac128 set from storage commerce:l ac
data modify storage commerce:cp t128 set from storage commerce:l t
data modify storage commerce:cp tc128 set from storage commerce:l tc
scoreboard players set #i c.t 129
function commerce:page/ligne
data modify storage commerce:cp ve129 set from storage commerce:l ve
data modify storage commerce:cp vz129 set from storage commerce:l vz
data modify storage commerce:cp vc129 set from storage commerce:l vc
data modify storage commerce:cp ae129 set from storage commerce:l ae
data modify storage commerce:cp az129 set from storage commerce:l az
data modify storage commerce:cp ac129 set from storage commerce:l ac
data modify storage commerce:cp t129 set from storage commerce:l t
data modify storage commerce:cp tc129 set from storage commerce:l tc
scoreboard players set #i c.t 130
function commerce:page/ligne
data modify storage commerce:cp ve130 set from storage commerce:l ve
data modify storage commerce:cp vz130 set from storage commerce:l vz
data modify storage commerce:cp vc130 set from storage commerce:l vc
data modify storage commerce:cp ae130 set from storage commerce:l ae
data modify storage commerce:cp az130 set from storage commerce:l az
data modify storage commerce:cp ac130 set from storage commerce:l ac
data modify storage commerce:cp t130 set from storage commerce:l t
data modify storage commerce:cp tc130 set from storage commerce:l tc
scoreboard players set #i c.t 131
function commerce:page/ligne
data modify storage commerce:cp ve131 set from storage commerce:l ve
data modify storage commerce:cp vz131 set from storage commerce:l vz
data modify storage commerce:cp vc131 set from storage commerce:l vc
data modify storage commerce:cp ae131 set from storage commerce:l ae
data modify storage commerce:cp az131 set from storage commerce:l az
data modify storage commerce:cp ac131 set from storage commerce:l ac
data modify storage commerce:cp t131 set from storage commerce:l t
data modify storage commerce:cp tc131 set from storage commerce:l tc
scoreboard players set #i c.t 132
function commerce:page/ligne
data modify storage commerce:cp ve132 set from storage commerce:l ve
data modify storage commerce:cp vz132 set from storage commerce:l vz
data modify storage commerce:cp vc132 set from storage commerce:l vc
data modify storage commerce:cp ae132 set from storage commerce:l ae
data modify storage commerce:cp az132 set from storage commerce:l az
data modify storage commerce:cp ac132 set from storage commerce:l ac
data modify storage commerce:cp t132 set from storage commerce:l t
data modify storage commerce:cp tc132 set from storage commerce:l tc
scoreboard players set #i c.t 133
function commerce:page/ligne
data modify storage commerce:cp ve133 set from storage commerce:l ve
data modify storage commerce:cp vz133 set from storage commerce:l vz
data modify storage commerce:cp vc133 set from storage commerce:l vc
data modify storage commerce:cp ae133 set from storage commerce:l ae
data modify storage commerce:cp az133 set from storage commerce:l az
data modify storage commerce:cp ac133 set from storage commerce:l ac
data modify storage commerce:cp t133 set from storage commerce:l t
data modify storage commerce:cp tc133 set from storage commerce:l tc
scoreboard players set #i c.t 134
function commerce:page/ligne
data modify storage commerce:cp ve134 set from storage commerce:l ve
data modify storage commerce:cp vz134 set from storage commerce:l vz
data modify storage commerce:cp vc134 set from storage commerce:l vc
data modify storage commerce:cp ae134 set from storage commerce:l ae
data modify storage commerce:cp az134 set from storage commerce:l az
data modify storage commerce:cp ac134 set from storage commerce:l ac
data modify storage commerce:cp t134 set from storage commerce:l t
data modify storage commerce:cp tc134 set from storage commerce:l tc
scoreboard players set #i c.t 135
function commerce:page/ligne
data modify storage commerce:cp ve135 set from storage commerce:l ve
data modify storage commerce:cp vz135 set from storage commerce:l vz
data modify storage commerce:cp vc135 set from storage commerce:l vc
data modify storage commerce:cp ae135 set from storage commerce:l ae
data modify storage commerce:cp az135 set from storage commerce:l az
data modify storage commerce:cp ac135 set from storage commerce:l ac
data modify storage commerce:cp t135 set from storage commerce:l t
data modify storage commerce:cp tc135 set from storage commerce:l tc
scoreboard players set #i c.t 136
function commerce:page/ligne
data modify storage commerce:cp ve136 set from storage commerce:l ve
data modify storage commerce:cp vz136 set from storage commerce:l vz
data modify storage commerce:cp vc136 set from storage commerce:l vc
data modify storage commerce:cp ae136 set from storage commerce:l ae
data modify storage commerce:cp az136 set from storage commerce:l az
data modify storage commerce:cp ac136 set from storage commerce:l ac
data modify storage commerce:cp t136 set from storage commerce:l t
data modify storage commerce:cp tc136 set from storage commerce:l tc
scoreboard players set #i c.t 137
function commerce:page/ligne
data modify storage commerce:cp ve137 set from storage commerce:l ve
data modify storage commerce:cp vz137 set from storage commerce:l vz
data modify storage commerce:cp vc137 set from storage commerce:l vc
data modify storage commerce:cp ae137 set from storage commerce:l ae
data modify storage commerce:cp az137 set from storage commerce:l az
data modify storage commerce:cp ac137 set from storage commerce:l ac
data modify storage commerce:cp t137 set from storage commerce:l t
data modify storage commerce:cp tc137 set from storage commerce:l tc
scoreboard players set #i c.t 138
function commerce:page/ligne
data modify storage commerce:cp ve138 set from storage commerce:l ve
data modify storage commerce:cp vz138 set from storage commerce:l vz
data modify storage commerce:cp vc138 set from storage commerce:l vc
data modify storage commerce:cp ae138 set from storage commerce:l ae
data modify storage commerce:cp az138 set from storage commerce:l az
data modify storage commerce:cp ac138 set from storage commerce:l ac
data modify storage commerce:cp t138 set from storage commerce:l t
data modify storage commerce:cp tc138 set from storage commerce:l tc
scoreboard players set #i c.t 139
function commerce:page/ligne
data modify storage commerce:cp ve139 set from storage commerce:l ve
data modify storage commerce:cp vz139 set from storage commerce:l vz
data modify storage commerce:cp vc139 set from storage commerce:l vc
data modify storage commerce:cp ae139 set from storage commerce:l ae
data modify storage commerce:cp az139 set from storage commerce:l az
data modify storage commerce:cp ac139 set from storage commerce:l ac
data modify storage commerce:cp t139 set from storage commerce:l t
data modify storage commerce:cp tc139 set from storage commerce:l tc
scoreboard players set #i c.t 140
function commerce:page/ligne
data modify storage commerce:cp ve140 set from storage commerce:l ve
data modify storage commerce:cp vz140 set from storage commerce:l vz
data modify storage commerce:cp vc140 set from storage commerce:l vc
data modify storage commerce:cp ae140 set from storage commerce:l ae
data modify storage commerce:cp az140 set from storage commerce:l az
data modify storage commerce:cp ac140 set from storage commerce:l ac
data modify storage commerce:cp t140 set from storage commerce:l t
data modify storage commerce:cp tc140 set from storage commerce:l tc
scoreboard players set #i c.t 141
function commerce:page/ligne
data modify storage commerce:cp ve141 set from storage commerce:l ve
data modify storage commerce:cp vz141 set from storage commerce:l vz
data modify storage commerce:cp vc141 set from storage commerce:l vc
data modify storage commerce:cp ae141 set from storage commerce:l ae
data modify storage commerce:cp az141 set from storage commerce:l az
data modify storage commerce:cp ac141 set from storage commerce:l ac
data modify storage commerce:cp t141 set from storage commerce:l t
data modify storage commerce:cp tc141 set from storage commerce:l tc
scoreboard players set #i c.t 142
function commerce:page/ligne
data modify storage commerce:cp ve142 set from storage commerce:l ve
data modify storage commerce:cp vz142 set from storage commerce:l vz
data modify storage commerce:cp vc142 set from storage commerce:l vc
data modify storage commerce:cp ae142 set from storage commerce:l ae
data modify storage commerce:cp az142 set from storage commerce:l az
data modify storage commerce:cp ac142 set from storage commerce:l ac
data modify storage commerce:cp t142 set from storage commerce:l t
data modify storage commerce:cp tc142 set from storage commerce:l tc
scoreboard players set #i c.t 143
function commerce:page/ligne
data modify storage commerce:cp ve143 set from storage commerce:l ve
data modify storage commerce:cp vz143 set from storage commerce:l vz
data modify storage commerce:cp vc143 set from storage commerce:l vc
data modify storage commerce:cp ae143 set from storage commerce:l ae
data modify storage commerce:cp az143 set from storage commerce:l az
data modify storage commerce:cp ac143 set from storage commerce:l ac
data modify storage commerce:cp t143 set from storage commerce:l t
data modify storage commerce:cp tc143 set from storage commerce:l tc
scoreboard players set #i c.t 144
function commerce:page/ligne
data modify storage commerce:cp ve144 set from storage commerce:l ve
data modify storage commerce:cp vz144 set from storage commerce:l vz
data modify storage commerce:cp vc144 set from storage commerce:l vc
data modify storage commerce:cp ae144 set from storage commerce:l ae
data modify storage commerce:cp az144 set from storage commerce:l az
data modify storage commerce:cp ac144 set from storage commerce:l ac
data modify storage commerce:cp t144 set from storage commerce:l t
data modify storage commerce:cp tc144 set from storage commerce:l tc
scoreboard players set #i c.t 145
function commerce:page/ligne
data modify storage commerce:cp ve145 set from storage commerce:l ve
data modify storage commerce:cp vz145 set from storage commerce:l vz
data modify storage commerce:cp vc145 set from storage commerce:l vc
data modify storage commerce:cp ae145 set from storage commerce:l ae
data modify storage commerce:cp az145 set from storage commerce:l az
data modify storage commerce:cp ac145 set from storage commerce:l ac
data modify storage commerce:cp t145 set from storage commerce:l t
data modify storage commerce:cp tc145 set from storage commerce:l tc
scoreboard players set #i c.t 146
function commerce:page/ligne
data modify storage commerce:cp ve146 set from storage commerce:l ve
data modify storage commerce:cp vz146 set from storage commerce:l vz
data modify storage commerce:cp vc146 set from storage commerce:l vc
data modify storage commerce:cp ae146 set from storage commerce:l ae
data modify storage commerce:cp az146 set from storage commerce:l az
data modify storage commerce:cp ac146 set from storage commerce:l ac
data modify storage commerce:cp t146 set from storage commerce:l t
data modify storage commerce:cp tc146 set from storage commerce:l tc
scoreboard players set #i c.t 147
function commerce:page/ligne
data modify storage commerce:cp ve147 set from storage commerce:l ve
data modify storage commerce:cp vz147 set from storage commerce:l vz
data modify storage commerce:cp vc147 set from storage commerce:l vc
data modify storage commerce:cp ae147 set from storage commerce:l ae
data modify storage commerce:cp az147 set from storage commerce:l az
data modify storage commerce:cp ac147 set from storage commerce:l ac
data modify storage commerce:cp t147 set from storage commerce:l t
data modify storage commerce:cp tc147 set from storage commerce:l tc
scoreboard players set #i c.t 148
function commerce:page/ligne
data modify storage commerce:cp ve148 set from storage commerce:l ve
data modify storage commerce:cp vz148 set from storage commerce:l vz
data modify storage commerce:cp vc148 set from storage commerce:l vc
data modify storage commerce:cp ae148 set from storage commerce:l ae
data modify storage commerce:cp az148 set from storage commerce:l az
data modify storage commerce:cp ac148 set from storage commerce:l ac
data modify storage commerce:cp t148 set from storage commerce:l t
data modify storage commerce:cp tc148 set from storage commerce:l tc
scoreboard players set #i c.t 149
function commerce:page/ligne
data modify storage commerce:cp ve149 set from storage commerce:l ve
data modify storage commerce:cp vz149 set from storage commerce:l vz
data modify storage commerce:cp vc149 set from storage commerce:l vc
data modify storage commerce:cp ae149 set from storage commerce:l ae
data modify storage commerce:cp az149 set from storage commerce:l az
data modify storage commerce:cp ac149 set from storage commerce:l ac
data modify storage commerce:cp t149 set from storage commerce:l t
data modify storage commerce:cp tc149 set from storage commerce:l tc
scoreboard players set #i c.t 150
function commerce:page/ligne
data modify storage commerce:cp ve150 set from storage commerce:l ve
data modify storage commerce:cp vz150 set from storage commerce:l vz
data modify storage commerce:cp vc150 set from storage commerce:l vc
data modify storage commerce:cp ae150 set from storage commerce:l ae
data modify storage commerce:cp az150 set from storage commerce:l az
data modify storage commerce:cp ac150 set from storage commerce:l ac
data modify storage commerce:cp t150 set from storage commerce:l t
data modify storage commerce:cp tc150 set from storage commerce:l tc
scoreboard players set #i c.t 151
function commerce:page/ligne
data modify storage commerce:cp ve151 set from storage commerce:l ve
data modify storage commerce:cp vz151 set from storage commerce:l vz
data modify storage commerce:cp vc151 set from storage commerce:l vc
data modify storage commerce:cp ae151 set from storage commerce:l ae
data modify storage commerce:cp az151 set from storage commerce:l az
data modify storage commerce:cp ac151 set from storage commerce:l ac
data modify storage commerce:cp t151 set from storage commerce:l t
data modify storage commerce:cp tc151 set from storage commerce:l tc
scoreboard players set #i c.t 152
function commerce:page/ligne
data modify storage commerce:cp ve152 set from storage commerce:l ve
data modify storage commerce:cp vz152 set from storage commerce:l vz
data modify storage commerce:cp vc152 set from storage commerce:l vc
data modify storage commerce:cp ae152 set from storage commerce:l ae
data modify storage commerce:cp az152 set from storage commerce:l az
data modify storage commerce:cp ac152 set from storage commerce:l ac
data modify storage commerce:cp t152 set from storage commerce:l t
data modify storage commerce:cp tc152 set from storage commerce:l tc
scoreboard players set #i c.t 153
function commerce:page/ligne
data modify storage commerce:cp ve153 set from storage commerce:l ve
data modify storage commerce:cp vz153 set from storage commerce:l vz
data modify storage commerce:cp vc153 set from storage commerce:l vc
data modify storage commerce:cp ae153 set from storage commerce:l ae
data modify storage commerce:cp az153 set from storage commerce:l az
data modify storage commerce:cp ac153 set from storage commerce:l ac
data modify storage commerce:cp t153 set from storage commerce:l t
data modify storage commerce:cp tc153 set from storage commerce:l tc
function commerce:page/cat_5_d with storage commerce:cp
