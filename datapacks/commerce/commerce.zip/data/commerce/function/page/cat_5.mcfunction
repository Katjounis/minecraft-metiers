function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 67
function commerce:page/ligne
data modify storage commerce:cp ve67 set from storage commerce:l ve
data modify storage commerce:cp vz67 set from storage commerce:l vz
data modify storage commerce:cp vc67 set from storage commerce:l vc
data modify storage commerce:cp ae67 set from storage commerce:l ae
data modify storage commerce:cp az67 set from storage commerce:l az
data modify storage commerce:cp ac67 set from storage commerce:l ac
data modify storage commerce:cp t67 set from storage commerce:l t
data modify storage commerce:cp tc67 set from storage commerce:l tc
scoreboard players set #i c.t 68
function commerce:page/ligne
data modify storage commerce:cp ve68 set from storage commerce:l ve
data modify storage commerce:cp vz68 set from storage commerce:l vz
data modify storage commerce:cp vc68 set from storage commerce:l vc
data modify storage commerce:cp ae68 set from storage commerce:l ae
data modify storage commerce:cp az68 set from storage commerce:l az
data modify storage commerce:cp ac68 set from storage commerce:l ac
data modify storage commerce:cp t68 set from storage commerce:l t
data modify storage commerce:cp tc68 set from storage commerce:l tc
scoreboard players set #i c.t 69
function commerce:page/ligne
data modify storage commerce:cp ve69 set from storage commerce:l ve
data modify storage commerce:cp vz69 set from storage commerce:l vz
data modify storage commerce:cp vc69 set from storage commerce:l vc
data modify storage commerce:cp ae69 set from storage commerce:l ae
data modify storage commerce:cp az69 set from storage commerce:l az
data modify storage commerce:cp ac69 set from storage commerce:l ac
data modify storage commerce:cp t69 set from storage commerce:l t
data modify storage commerce:cp tc69 set from storage commerce:l tc
scoreboard players set #i c.t 70
function commerce:page/ligne
data modify storage commerce:cp ve70 set from storage commerce:l ve
data modify storage commerce:cp vz70 set from storage commerce:l vz
data modify storage commerce:cp vc70 set from storage commerce:l vc
data modify storage commerce:cp ae70 set from storage commerce:l ae
data modify storage commerce:cp az70 set from storage commerce:l az
data modify storage commerce:cp ac70 set from storage commerce:l ac
data modify storage commerce:cp t70 set from storage commerce:l t
data modify storage commerce:cp tc70 set from storage commerce:l tc
scoreboard players set #i c.t 71
function commerce:page/ligne
data modify storage commerce:cp ve71 set from storage commerce:l ve
data modify storage commerce:cp vz71 set from storage commerce:l vz
data modify storage commerce:cp vc71 set from storage commerce:l vc
data modify storage commerce:cp ae71 set from storage commerce:l ae
data modify storage commerce:cp az71 set from storage commerce:l az
data modify storage commerce:cp ac71 set from storage commerce:l ac
data modify storage commerce:cp t71 set from storage commerce:l t
data modify storage commerce:cp tc71 set from storage commerce:l tc
scoreboard players set #i c.t 72
function commerce:page/ligne
data modify storage commerce:cp ve72 set from storage commerce:l ve
data modify storage commerce:cp vz72 set from storage commerce:l vz
data modify storage commerce:cp vc72 set from storage commerce:l vc
data modify storage commerce:cp ae72 set from storage commerce:l ae
data modify storage commerce:cp az72 set from storage commerce:l az
data modify storage commerce:cp ac72 set from storage commerce:l ac
data modify storage commerce:cp t72 set from storage commerce:l t
data modify storage commerce:cp tc72 set from storage commerce:l tc
scoreboard players set #i c.t 73
function commerce:page/ligne
data modify storage commerce:cp ve73 set from storage commerce:l ve
data modify storage commerce:cp vz73 set from storage commerce:l vz
data modify storage commerce:cp vc73 set from storage commerce:l vc
data modify storage commerce:cp ae73 set from storage commerce:l ae
data modify storage commerce:cp az73 set from storage commerce:l az
data modify storage commerce:cp ac73 set from storage commerce:l ac
data modify storage commerce:cp t73 set from storage commerce:l t
data modify storage commerce:cp tc73 set from storage commerce:l tc
scoreboard players set #i c.t 74
function commerce:page/ligne
data modify storage commerce:cp ve74 set from storage commerce:l ve
data modify storage commerce:cp vz74 set from storage commerce:l vz
data modify storage commerce:cp vc74 set from storage commerce:l vc
data modify storage commerce:cp ae74 set from storage commerce:l ae
data modify storage commerce:cp az74 set from storage commerce:l az
data modify storage commerce:cp ac74 set from storage commerce:l ac
data modify storage commerce:cp t74 set from storage commerce:l t
data modify storage commerce:cp tc74 set from storage commerce:l tc
scoreboard players set #i c.t 75
function commerce:page/ligne
data modify storage commerce:cp ve75 set from storage commerce:l ve
data modify storage commerce:cp vz75 set from storage commerce:l vz
data modify storage commerce:cp vc75 set from storage commerce:l vc
data modify storage commerce:cp ae75 set from storage commerce:l ae
data modify storage commerce:cp az75 set from storage commerce:l az
data modify storage commerce:cp ac75 set from storage commerce:l ac
data modify storage commerce:cp t75 set from storage commerce:l t
data modify storage commerce:cp tc75 set from storage commerce:l tc
scoreboard players set #i c.t 76
function commerce:page/ligne
data modify storage commerce:cp ve76 set from storage commerce:l ve
data modify storage commerce:cp vz76 set from storage commerce:l vz
data modify storage commerce:cp vc76 set from storage commerce:l vc
data modify storage commerce:cp ae76 set from storage commerce:l ae
data modify storage commerce:cp az76 set from storage commerce:l az
data modify storage commerce:cp ac76 set from storage commerce:l ac
data modify storage commerce:cp t76 set from storage commerce:l t
data modify storage commerce:cp tc76 set from storage commerce:l tc
scoreboard players set #i c.t 77
function commerce:page/ligne
data modify storage commerce:cp ve77 set from storage commerce:l ve
data modify storage commerce:cp vz77 set from storage commerce:l vz
data modify storage commerce:cp vc77 set from storage commerce:l vc
data modify storage commerce:cp ae77 set from storage commerce:l ae
data modify storage commerce:cp az77 set from storage commerce:l az
data modify storage commerce:cp ac77 set from storage commerce:l ac
data modify storage commerce:cp t77 set from storage commerce:l t
data modify storage commerce:cp tc77 set from storage commerce:l tc
scoreboard players set #i c.t 78
function commerce:page/ligne
data modify storage commerce:cp ve78 set from storage commerce:l ve
data modify storage commerce:cp vz78 set from storage commerce:l vz
data modify storage commerce:cp vc78 set from storage commerce:l vc
data modify storage commerce:cp ae78 set from storage commerce:l ae
data modify storage commerce:cp az78 set from storage commerce:l az
data modify storage commerce:cp ac78 set from storage commerce:l ac
data modify storage commerce:cp t78 set from storage commerce:l t
data modify storage commerce:cp tc78 set from storage commerce:l tc
scoreboard players set #i c.t 79
function commerce:page/ligne
data modify storage commerce:cp ve79 set from storage commerce:l ve
data modify storage commerce:cp vz79 set from storage commerce:l vz
data modify storage commerce:cp vc79 set from storage commerce:l vc
data modify storage commerce:cp ae79 set from storage commerce:l ae
data modify storage commerce:cp az79 set from storage commerce:l az
data modify storage commerce:cp ac79 set from storage commerce:l ac
data modify storage commerce:cp t79 set from storage commerce:l t
data modify storage commerce:cp tc79 set from storage commerce:l tc
scoreboard players set #i c.t 80
function commerce:page/ligne
data modify storage commerce:cp ve80 set from storage commerce:l ve
data modify storage commerce:cp vz80 set from storage commerce:l vz
data modify storage commerce:cp vc80 set from storage commerce:l vc
data modify storage commerce:cp ae80 set from storage commerce:l ae
data modify storage commerce:cp az80 set from storage commerce:l az
data modify storage commerce:cp ac80 set from storage commerce:l ac
data modify storage commerce:cp t80 set from storage commerce:l t
data modify storage commerce:cp tc80 set from storage commerce:l tc
scoreboard players set #i c.t 81
function commerce:page/ligne
data modify storage commerce:cp ve81 set from storage commerce:l ve
data modify storage commerce:cp vz81 set from storage commerce:l vz
data modify storage commerce:cp vc81 set from storage commerce:l vc
data modify storage commerce:cp ae81 set from storage commerce:l ae
data modify storage commerce:cp az81 set from storage commerce:l az
data modify storage commerce:cp ac81 set from storage commerce:l ac
data modify storage commerce:cp t81 set from storage commerce:l t
data modify storage commerce:cp tc81 set from storage commerce:l tc
scoreboard players set #i c.t 82
function commerce:page/ligne
data modify storage commerce:cp ve82 set from storage commerce:l ve
data modify storage commerce:cp vz82 set from storage commerce:l vz
data modify storage commerce:cp vc82 set from storage commerce:l vc
data modify storage commerce:cp ae82 set from storage commerce:l ae
data modify storage commerce:cp az82 set from storage commerce:l az
data modify storage commerce:cp ac82 set from storage commerce:l ac
data modify storage commerce:cp t82 set from storage commerce:l t
data modify storage commerce:cp tc82 set from storage commerce:l tc
scoreboard players set #i c.t 83
function commerce:page/ligne
data modify storage commerce:cp ve83 set from storage commerce:l ve
data modify storage commerce:cp vz83 set from storage commerce:l vz
data modify storage commerce:cp vc83 set from storage commerce:l vc
data modify storage commerce:cp ae83 set from storage commerce:l ae
data modify storage commerce:cp az83 set from storage commerce:l az
data modify storage commerce:cp ac83 set from storage commerce:l ac
data modify storage commerce:cp t83 set from storage commerce:l t
data modify storage commerce:cp tc83 set from storage commerce:l tc
scoreboard players set #i c.t 84
function commerce:page/ligne
data modify storage commerce:cp ve84 set from storage commerce:l ve
data modify storage commerce:cp vz84 set from storage commerce:l vz
data modify storage commerce:cp vc84 set from storage commerce:l vc
data modify storage commerce:cp ae84 set from storage commerce:l ae
data modify storage commerce:cp az84 set from storage commerce:l az
data modify storage commerce:cp ac84 set from storage commerce:l ac
data modify storage commerce:cp t84 set from storage commerce:l t
data modify storage commerce:cp tc84 set from storage commerce:l tc
scoreboard players set #i c.t 85
function commerce:page/ligne
data modify storage commerce:cp ve85 set from storage commerce:l ve
data modify storage commerce:cp vz85 set from storage commerce:l vz
data modify storage commerce:cp vc85 set from storage commerce:l vc
data modify storage commerce:cp ae85 set from storage commerce:l ae
data modify storage commerce:cp az85 set from storage commerce:l az
data modify storage commerce:cp ac85 set from storage commerce:l ac
data modify storage commerce:cp t85 set from storage commerce:l t
data modify storage commerce:cp tc85 set from storage commerce:l tc
function commerce:page/cat_5_d with storage commerce:cp
