function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 66
function commerce:page/ligne
data modify storage commerce:cp ve66 set from storage commerce:l ve
data modify storage commerce:cp vz66 set from storage commerce:l vz
data modify storage commerce:cp vc66 set from storage commerce:l vc
data modify storage commerce:cp ae66 set from storage commerce:l ae
data modify storage commerce:cp az66 set from storage commerce:l az
data modify storage commerce:cp ac66 set from storage commerce:l ac
data modify storage commerce:cp t66 set from storage commerce:l t
scoreboard players set #i c.t 72
function commerce:page/ligne
data modify storage commerce:cp ve72 set from storage commerce:l ve
data modify storage commerce:cp vz72 set from storage commerce:l vz
data modify storage commerce:cp vc72 set from storage commerce:l vc
data modify storage commerce:cp ae72 set from storage commerce:l ae
data modify storage commerce:cp az72 set from storage commerce:l az
data modify storage commerce:cp ac72 set from storage commerce:l ac
data modify storage commerce:cp t72 set from storage commerce:l t
scoreboard players set #i c.t 70
function commerce:page/ligne
data modify storage commerce:cp ve70 set from storage commerce:l ve
data modify storage commerce:cp vz70 set from storage commerce:l vz
data modify storage commerce:cp vc70 set from storage commerce:l vc
data modify storage commerce:cp ae70 set from storage commerce:l ae
data modify storage commerce:cp az70 set from storage commerce:l az
data modify storage commerce:cp ac70 set from storage commerce:l ac
data modify storage commerce:cp t70 set from storage commerce:l t
scoreboard players set #i c.t 69
function commerce:page/ligne
data modify storage commerce:cp ve69 set from storage commerce:l ve
data modify storage commerce:cp vz69 set from storage commerce:l vz
data modify storage commerce:cp vc69 set from storage commerce:l vc
data modify storage commerce:cp ae69 set from storage commerce:l ae
data modify storage commerce:cp az69 set from storage commerce:l az
data modify storage commerce:cp ac69 set from storage commerce:l ac
data modify storage commerce:cp t69 set from storage commerce:l t
scoreboard players set #i c.t 79
function commerce:page/ligne
data modify storage commerce:cp ve79 set from storage commerce:l ve
data modify storage commerce:cp vz79 set from storage commerce:l vz
data modify storage commerce:cp vc79 set from storage commerce:l vc
data modify storage commerce:cp ae79 set from storage commerce:l ae
data modify storage commerce:cp az79 set from storage commerce:l az
data modify storage commerce:cp ac79 set from storage commerce:l ac
data modify storage commerce:cp t79 set from storage commerce:l t
scoreboard players set #i c.t 65
function commerce:page/ligne
data modify storage commerce:cp ve65 set from storage commerce:l ve
data modify storage commerce:cp vz65 set from storage commerce:l vz
data modify storage commerce:cp vc65 set from storage commerce:l vc
data modify storage commerce:cp ae65 set from storage commerce:l ae
data modify storage commerce:cp az65 set from storage commerce:l az
data modify storage commerce:cp ac65 set from storage commerce:l ac
data modify storage commerce:cp t65 set from storage commerce:l t
scoreboard players set #i c.t 75
function commerce:page/ligne
data modify storage commerce:cp ve75 set from storage commerce:l ve
data modify storage commerce:cp vz75 set from storage commerce:l vz
data modify storage commerce:cp vc75 set from storage commerce:l vc
data modify storage commerce:cp ae75 set from storage commerce:l ae
data modify storage commerce:cp az75 set from storage commerce:l az
data modify storage commerce:cp ac75 set from storage commerce:l ac
data modify storage commerce:cp t75 set from storage commerce:l t
scoreboard players set #i c.t 81
function commerce:page/ligne
data modify storage commerce:cp ve81 set from storage commerce:l ve
data modify storage commerce:cp vz81 set from storage commerce:l vz
data modify storage commerce:cp vc81 set from storage commerce:l vc
data modify storage commerce:cp ae81 set from storage commerce:l ae
data modify storage commerce:cp az81 set from storage commerce:l az
data modify storage commerce:cp ac81 set from storage commerce:l ac
data modify storage commerce:cp t81 set from storage commerce:l t
scoreboard players set #i c.t 77
function commerce:page/ligne
data modify storage commerce:cp ve77 set from storage commerce:l ve
data modify storage commerce:cp vz77 set from storage commerce:l vz
data modify storage commerce:cp vc77 set from storage commerce:l vc
data modify storage commerce:cp ae77 set from storage commerce:l ae
data modify storage commerce:cp az77 set from storage commerce:l az
data modify storage commerce:cp ac77 set from storage commerce:l ac
data modify storage commerce:cp t77 set from storage commerce:l t
scoreboard players set #i c.t 67
function commerce:page/ligne
data modify storage commerce:cp ve67 set from storage commerce:l ve
data modify storage commerce:cp vz67 set from storage commerce:l vz
data modify storage commerce:cp vc67 set from storage commerce:l vc
data modify storage commerce:cp ae67 set from storage commerce:l ae
data modify storage commerce:cp az67 set from storage commerce:l az
data modify storage commerce:cp ac67 set from storage commerce:l ac
data modify storage commerce:cp t67 set from storage commerce:l t
function commerce:page/lettre_b_9_d with storage commerce:cp
