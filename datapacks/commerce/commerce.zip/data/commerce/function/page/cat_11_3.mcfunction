function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 332
function commerce:page/ligne
data modify storage commerce:cp ve332 set from storage commerce:l ve
data modify storage commerce:cp vz332 set from storage commerce:l vz
data modify storage commerce:cp vc332 set from storage commerce:l vc
data modify storage commerce:cp ae332 set from storage commerce:l ae
data modify storage commerce:cp az332 set from storage commerce:l az
data modify storage commerce:cp ac332 set from storage commerce:l ac
data modify storage commerce:cp t332 set from storage commerce:l t
scoreboard players set #i c.t 333
function commerce:page/ligne
data modify storage commerce:cp ve333 set from storage commerce:l ve
data modify storage commerce:cp vz333 set from storage commerce:l vz
data modify storage commerce:cp vc333 set from storage commerce:l vc
data modify storage commerce:cp ae333 set from storage commerce:l ae
data modify storage commerce:cp az333 set from storage commerce:l az
data modify storage commerce:cp ac333 set from storage commerce:l ac
data modify storage commerce:cp t333 set from storage commerce:l t
function commerce:page/cat_11_3_d with storage commerce:cp
