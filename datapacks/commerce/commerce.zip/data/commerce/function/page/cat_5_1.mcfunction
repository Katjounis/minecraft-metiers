function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 132
function commerce:page/ligne
data modify storage commerce:cp ve132 set from storage commerce:l ve
data modify storage commerce:cp vz132 set from storage commerce:l vz
data modify storage commerce:cp vc132 set from storage commerce:l vc
data modify storage commerce:cp ae132 set from storage commerce:l ae
data modify storage commerce:cp az132 set from storage commerce:l az
data modify storage commerce:cp ac132 set from storage commerce:l ac
data modify storage commerce:cp t132 set from storage commerce:l t
scoreboard players set #i c.t 133
function commerce:page/ligne
data modify storage commerce:cp ve133 set from storage commerce:l ve
data modify storage commerce:cp vz133 set from storage commerce:l vz
data modify storage commerce:cp vc133 set from storage commerce:l vc
data modify storage commerce:cp ae133 set from storage commerce:l ae
data modify storage commerce:cp az133 set from storage commerce:l az
data modify storage commerce:cp ac133 set from storage commerce:l ac
data modify storage commerce:cp t133 set from storage commerce:l t
scoreboard players set #i c.t 134
function commerce:page/ligne
data modify storage commerce:cp ve134 set from storage commerce:l ve
data modify storage commerce:cp vz134 set from storage commerce:l vz
data modify storage commerce:cp vc134 set from storage commerce:l vc
data modify storage commerce:cp ae134 set from storage commerce:l ae
data modify storage commerce:cp az134 set from storage commerce:l az
data modify storage commerce:cp ac134 set from storage commerce:l ac
data modify storage commerce:cp t134 set from storage commerce:l t
scoreboard players set #i c.t 135
function commerce:page/ligne
data modify storage commerce:cp ve135 set from storage commerce:l ve
data modify storage commerce:cp vz135 set from storage commerce:l vz
data modify storage commerce:cp vc135 set from storage commerce:l vc
data modify storage commerce:cp ae135 set from storage commerce:l ae
data modify storage commerce:cp az135 set from storage commerce:l az
data modify storage commerce:cp ac135 set from storage commerce:l ac
data modify storage commerce:cp t135 set from storage commerce:l t
scoreboard players set #i c.t 136
function commerce:page/ligne
data modify storage commerce:cp ve136 set from storage commerce:l ve
data modify storage commerce:cp vz136 set from storage commerce:l vz
data modify storage commerce:cp vc136 set from storage commerce:l vc
data modify storage commerce:cp ae136 set from storage commerce:l ae
data modify storage commerce:cp az136 set from storage commerce:l az
data modify storage commerce:cp ac136 set from storage commerce:l ac
data modify storage commerce:cp t136 set from storage commerce:l t
scoreboard players set #i c.t 137
function commerce:page/ligne
data modify storage commerce:cp ve137 set from storage commerce:l ve
data modify storage commerce:cp vz137 set from storage commerce:l vz
data modify storage commerce:cp vc137 set from storage commerce:l vc
data modify storage commerce:cp ae137 set from storage commerce:l ae
data modify storage commerce:cp az137 set from storage commerce:l az
data modify storage commerce:cp ac137 set from storage commerce:l ac
data modify storage commerce:cp t137 set from storage commerce:l t
scoreboard players set #i c.t 138
function commerce:page/ligne
data modify storage commerce:cp ve138 set from storage commerce:l ve
data modify storage commerce:cp vz138 set from storage commerce:l vz
data modify storage commerce:cp vc138 set from storage commerce:l vc
data modify storage commerce:cp ae138 set from storage commerce:l ae
data modify storage commerce:cp az138 set from storage commerce:l az
data modify storage commerce:cp ac138 set from storage commerce:l ac
data modify storage commerce:cp t138 set from storage commerce:l t
scoreboard players set #i c.t 139
function commerce:page/ligne
data modify storage commerce:cp ve139 set from storage commerce:l ve
data modify storage commerce:cp vz139 set from storage commerce:l vz
data modify storage commerce:cp vc139 set from storage commerce:l vc
data modify storage commerce:cp ae139 set from storage commerce:l ae
data modify storage commerce:cp az139 set from storage commerce:l az
data modify storage commerce:cp ac139 set from storage commerce:l ac
data modify storage commerce:cp t139 set from storage commerce:l t
scoreboard players set #i c.t 140
function commerce:page/ligne
data modify storage commerce:cp ve140 set from storage commerce:l ve
data modify storage commerce:cp vz140 set from storage commerce:l vz
data modify storage commerce:cp vc140 set from storage commerce:l vc
data modify storage commerce:cp ae140 set from storage commerce:l ae
data modify storage commerce:cp az140 set from storage commerce:l az
data modify storage commerce:cp ac140 set from storage commerce:l ac
data modify storage commerce:cp t140 set from storage commerce:l t
scoreboard players set #i c.t 141
function commerce:page/ligne
data modify storage commerce:cp ve141 set from storage commerce:l ve
data modify storage commerce:cp vz141 set from storage commerce:l vz
data modify storage commerce:cp vc141 set from storage commerce:l vc
data modify storage commerce:cp ae141 set from storage commerce:l ae
data modify storage commerce:cp az141 set from storage commerce:l az
data modify storage commerce:cp ac141 set from storage commerce:l ac
data modify storage commerce:cp t141 set from storage commerce:l t
function commerce:page/cat_5_1_d with storage commerce:cp
