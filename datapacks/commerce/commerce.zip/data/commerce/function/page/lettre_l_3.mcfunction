function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 224
function commerce:page/ligne
data modify storage commerce:cp ve224 set from storage commerce:l ve
data modify storage commerce:cp vz224 set from storage commerce:l vz
data modify storage commerce:cp vc224 set from storage commerce:l vc
data modify storage commerce:cp ae224 set from storage commerce:l ae
data modify storage commerce:cp az224 set from storage commerce:l az
data modify storage commerce:cp ac224 set from storage commerce:l ac
data modify storage commerce:cp t224 set from storage commerce:l t
scoreboard players set #i c.t 230
function commerce:page/ligne
data modify storage commerce:cp ve230 set from storage commerce:l ve
data modify storage commerce:cp vz230 set from storage commerce:l vz
data modify storage commerce:cp vc230 set from storage commerce:l vc
data modify storage commerce:cp ae230 set from storage commerce:l ae
data modify storage commerce:cp az230 set from storage commerce:l az
data modify storage commerce:cp ac230 set from storage commerce:l ac
data modify storage commerce:cp t230 set from storage commerce:l t
scoreboard players set #i c.t 435
function commerce:page/ligne
data modify storage commerce:cp ve435 set from storage commerce:l ve
data modify storage commerce:cp vz435 set from storage commerce:l vz
data modify storage commerce:cp vc435 set from storage commerce:l vc
data modify storage commerce:cp ae435 set from storage commerce:l ae
data modify storage commerce:cp az435 set from storage commerce:l az
data modify storage commerce:cp ac435 set from storage commerce:l ac
data modify storage commerce:cp t435 set from storage commerce:l t
scoreboard players set #i c.t 423
function commerce:page/ligne
data modify storage commerce:cp ve423 set from storage commerce:l ve
data modify storage commerce:cp vz423 set from storage commerce:l vz
data modify storage commerce:cp vc423 set from storage commerce:l vc
data modify storage commerce:cp ae423 set from storage commerce:l ae
data modify storage commerce:cp az423 set from storage commerce:l az
data modify storage commerce:cp ac423 set from storage commerce:l ac
data modify storage commerce:cp t423 set from storage commerce:l t
scoreboard players set #i c.t 372
function commerce:page/ligne
data modify storage commerce:cp ve372 set from storage commerce:l ve
data modify storage commerce:cp vz372 set from storage commerce:l vz
data modify storage commerce:cp vc372 set from storage commerce:l vc
data modify storage commerce:cp ae372 set from storage commerce:l ae
data modify storage commerce:cp az372 set from storage commerce:l az
data modify storage commerce:cp ac372 set from storage commerce:l ac
data modify storage commerce:cp t372 set from storage commerce:l t
scoreboard players set #i c.t 456
function commerce:page/ligne
data modify storage commerce:cp ve456 set from storage commerce:l ve
data modify storage commerce:cp vz456 set from storage commerce:l vz
data modify storage commerce:cp vc456 set from storage commerce:l vc
data modify storage commerce:cp ae456 set from storage commerce:l ae
data modify storage commerce:cp az456 set from storage commerce:l az
data modify storage commerce:cp ac456 set from storage commerce:l ac
data modify storage commerce:cp t456 set from storage commerce:l t
function commerce:page/lettre_l_3_d with storage commerce:cp
