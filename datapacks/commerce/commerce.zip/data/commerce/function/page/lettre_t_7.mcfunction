function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 287
function commerce:page/ligne
data modify storage commerce:cp ve287 set from storage commerce:l ve
data modify storage commerce:cp vz287 set from storage commerce:l vz
data modify storage commerce:cp vc287 set from storage commerce:l vc
data modify storage commerce:cp ae287 set from storage commerce:l ae
data modify storage commerce:cp az287 set from storage commerce:l az
data modify storage commerce:cp ac287 set from storage commerce:l ac
data modify storage commerce:cp t287 set from storage commerce:l t
scoreboard players set #i c.t 21
function commerce:page/ligne
data modify storage commerce:cp ve21 set from storage commerce:l ve
data modify storage commerce:cp vz21 set from storage commerce:l vz
data modify storage commerce:cp vc21 set from storage commerce:l vc
data modify storage commerce:cp ae21 set from storage commerce:l ae
data modify storage commerce:cp az21 set from storage commerce:l az
data modify storage commerce:cp ac21 set from storage commerce:l ac
data modify storage commerce:cp t21 set from storage commerce:l t
scoreboard players set #i c.t 22
function commerce:page/ligne
data modify storage commerce:cp ve22 set from storage commerce:l ve
data modify storage commerce:cp vz22 set from storage commerce:l vz
data modify storage commerce:cp vc22 set from storage commerce:l vc
data modify storage commerce:cp ae22 set from storage commerce:l ae
data modify storage commerce:cp az22 set from storage commerce:l az
data modify storage commerce:cp ac22 set from storage commerce:l ac
data modify storage commerce:cp t22 set from storage commerce:l t
scoreboard players set #i c.t 406
function commerce:page/ligne
data modify storage commerce:cp ve406 set from storage commerce:l ve
data modify storage commerce:cp vz406 set from storage commerce:l vz
data modify storage commerce:cp vc406 set from storage commerce:l vc
data modify storage commerce:cp ae406 set from storage commerce:l ae
data modify storage commerce:cp az406 set from storage commerce:l az
data modify storage commerce:cp ac406 set from storage commerce:l ac
data modify storage commerce:cp t406 set from storage commerce:l t
scoreboard players set #i c.t 405
function commerce:page/ligne
data modify storage commerce:cp ve405 set from storage commerce:l ve
data modify storage commerce:cp vz405 set from storage commerce:l vz
data modify storage commerce:cp vc405 set from storage commerce:l vc
data modify storage commerce:cp ae405 set from storage commerce:l ae
data modify storage commerce:cp az405 set from storage commerce:l az
data modify storage commerce:cp ac405 set from storage commerce:l ac
data modify storage commerce:cp t405 set from storage commerce:l t
scoreboard players set #i c.t 407
function commerce:page/ligne
data modify storage commerce:cp ve407 set from storage commerce:l ve
data modify storage commerce:cp vz407 set from storage commerce:l vz
data modify storage commerce:cp vc407 set from storage commerce:l vc
data modify storage commerce:cp ae407 set from storage commerce:l ae
data modify storage commerce:cp az407 set from storage commerce:l az
data modify storage commerce:cp ac407 set from storage commerce:l ac
data modify storage commerce:cp t407 set from storage commerce:l t
scoreboard players set #i c.t 404
function commerce:page/ligne
data modify storage commerce:cp ve404 set from storage commerce:l ve
data modify storage commerce:cp vz404 set from storage commerce:l vz
data modify storage commerce:cp vc404 set from storage commerce:l vc
data modify storage commerce:cp ae404 set from storage commerce:l ae
data modify storage commerce:cp az404 set from storage commerce:l az
data modify storage commerce:cp ac404 set from storage commerce:l ac
data modify storage commerce:cp t404 set from storage commerce:l t
function commerce:page/lettre_t_7_d with storage commerce:cp
