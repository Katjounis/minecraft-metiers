function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 221
function commerce:page/ligne
data modify storage commerce:cp ve221 set from storage commerce:l ve
data modify storage commerce:cp vz221 set from storage commerce:l vz
data modify storage commerce:cp vc221 set from storage commerce:l vc
data modify storage commerce:cp ae221 set from storage commerce:l ae
data modify storage commerce:cp az221 set from storage commerce:l az
data modify storage commerce:cp ac221 set from storage commerce:l ac
data modify storage commerce:cp t221 set from storage commerce:l t
data modify storage commerce:cp tc221 set from storage commerce:l tc
scoreboard players set #i c.t 222
function commerce:page/ligne
data modify storage commerce:cp ve222 set from storage commerce:l ve
data modify storage commerce:cp vz222 set from storage commerce:l vz
data modify storage commerce:cp vc222 set from storage commerce:l vc
data modify storage commerce:cp ae222 set from storage commerce:l ae
data modify storage commerce:cp az222 set from storage commerce:l az
data modify storage commerce:cp ac222 set from storage commerce:l ac
data modify storage commerce:cp t222 set from storage commerce:l t
data modify storage commerce:cp tc222 set from storage commerce:l tc
scoreboard players set #i c.t 223
function commerce:page/ligne
data modify storage commerce:cp ve223 set from storage commerce:l ve
data modify storage commerce:cp vz223 set from storage commerce:l vz
data modify storage commerce:cp vc223 set from storage commerce:l vc
data modify storage commerce:cp ae223 set from storage commerce:l ae
data modify storage commerce:cp az223 set from storage commerce:l az
data modify storage commerce:cp ac223 set from storage commerce:l ac
data modify storage commerce:cp t223 set from storage commerce:l t
data modify storage commerce:cp tc223 set from storage commerce:l tc
scoreboard players set #i c.t 224
function commerce:page/ligne
data modify storage commerce:cp ve224 set from storage commerce:l ve
data modify storage commerce:cp vz224 set from storage commerce:l vz
data modify storage commerce:cp vc224 set from storage commerce:l vc
data modify storage commerce:cp ae224 set from storage commerce:l ae
data modify storage commerce:cp az224 set from storage commerce:l az
data modify storage commerce:cp ac224 set from storage commerce:l ac
data modify storage commerce:cp t224 set from storage commerce:l t
data modify storage commerce:cp tc224 set from storage commerce:l tc
scoreboard players set #i c.t 225
function commerce:page/ligne
data modify storage commerce:cp ve225 set from storage commerce:l ve
data modify storage commerce:cp vz225 set from storage commerce:l vz
data modify storage commerce:cp vc225 set from storage commerce:l vc
data modify storage commerce:cp ae225 set from storage commerce:l ae
data modify storage commerce:cp az225 set from storage commerce:l az
data modify storage commerce:cp ac225 set from storage commerce:l ac
data modify storage commerce:cp t225 set from storage commerce:l t
data modify storage commerce:cp tc225 set from storage commerce:l tc
scoreboard players set #i c.t 226
function commerce:page/ligne
data modify storage commerce:cp ve226 set from storage commerce:l ve
data modify storage commerce:cp vz226 set from storage commerce:l vz
data modify storage commerce:cp vc226 set from storage commerce:l vc
data modify storage commerce:cp ae226 set from storage commerce:l ae
data modify storage commerce:cp az226 set from storage commerce:l az
data modify storage commerce:cp ac226 set from storage commerce:l ac
data modify storage commerce:cp t226 set from storage commerce:l t
data modify storage commerce:cp tc226 set from storage commerce:l tc
scoreboard players set #i c.t 227
function commerce:page/ligne
data modify storage commerce:cp ve227 set from storage commerce:l ve
data modify storage commerce:cp vz227 set from storage commerce:l vz
data modify storage commerce:cp vc227 set from storage commerce:l vc
data modify storage commerce:cp ae227 set from storage commerce:l ae
data modify storage commerce:cp az227 set from storage commerce:l az
data modify storage commerce:cp ac227 set from storage commerce:l ac
data modify storage commerce:cp t227 set from storage commerce:l t
data modify storage commerce:cp tc227 set from storage commerce:l tc
scoreboard players set #i c.t 228
function commerce:page/ligne
data modify storage commerce:cp ve228 set from storage commerce:l ve
data modify storage commerce:cp vz228 set from storage commerce:l vz
data modify storage commerce:cp vc228 set from storage commerce:l vc
data modify storage commerce:cp ae228 set from storage commerce:l ae
data modify storage commerce:cp az228 set from storage commerce:l az
data modify storage commerce:cp ac228 set from storage commerce:l ac
data modify storage commerce:cp t228 set from storage commerce:l t
data modify storage commerce:cp tc228 set from storage commerce:l tc
scoreboard players set #i c.t 229
function commerce:page/ligne
data modify storage commerce:cp ve229 set from storage commerce:l ve
data modify storage commerce:cp vz229 set from storage commerce:l vz
data modify storage commerce:cp vc229 set from storage commerce:l vc
data modify storage commerce:cp ae229 set from storage commerce:l ae
data modify storage commerce:cp az229 set from storage commerce:l az
data modify storage commerce:cp ac229 set from storage commerce:l ac
data modify storage commerce:cp t229 set from storage commerce:l t
data modify storage commerce:cp tc229 set from storage commerce:l tc
scoreboard players set #i c.t 230
function commerce:page/ligne
data modify storage commerce:cp ve230 set from storage commerce:l ve
data modify storage commerce:cp vz230 set from storage commerce:l vz
data modify storage commerce:cp vc230 set from storage commerce:l vc
data modify storage commerce:cp ae230 set from storage commerce:l ae
data modify storage commerce:cp az230 set from storage commerce:l az
data modify storage commerce:cp ac230 set from storage commerce:l ac
data modify storage commerce:cp t230 set from storage commerce:l t
data modify storage commerce:cp tc230 set from storage commerce:l tc
scoreboard players set #i c.t 231
function commerce:page/ligne
data modify storage commerce:cp ve231 set from storage commerce:l ve
data modify storage commerce:cp vz231 set from storage commerce:l vz
data modify storage commerce:cp vc231 set from storage commerce:l vc
data modify storage commerce:cp ae231 set from storage commerce:l ae
data modify storage commerce:cp az231 set from storage commerce:l az
data modify storage commerce:cp ac231 set from storage commerce:l ac
data modify storage commerce:cp t231 set from storage commerce:l t
data modify storage commerce:cp tc231 set from storage commerce:l tc
scoreboard players set #i c.t 232
function commerce:page/ligne
data modify storage commerce:cp ve232 set from storage commerce:l ve
data modify storage commerce:cp vz232 set from storage commerce:l vz
data modify storage commerce:cp vc232 set from storage commerce:l vc
data modify storage commerce:cp ae232 set from storage commerce:l ae
data modify storage commerce:cp az232 set from storage commerce:l az
data modify storage commerce:cp ac232 set from storage commerce:l ac
data modify storage commerce:cp t232 set from storage commerce:l t
data modify storage commerce:cp tc232 set from storage commerce:l tc
scoreboard players set #i c.t 233
function commerce:page/ligne
data modify storage commerce:cp ve233 set from storage commerce:l ve
data modify storage commerce:cp vz233 set from storage commerce:l vz
data modify storage commerce:cp vc233 set from storage commerce:l vc
data modify storage commerce:cp ae233 set from storage commerce:l ae
data modify storage commerce:cp az233 set from storage commerce:l az
data modify storage commerce:cp ac233 set from storage commerce:l ac
data modify storage commerce:cp t233 set from storage commerce:l t
data modify storage commerce:cp tc233 set from storage commerce:l tc
scoreboard players set #i c.t 234
function commerce:page/ligne
data modify storage commerce:cp ve234 set from storage commerce:l ve
data modify storage commerce:cp vz234 set from storage commerce:l vz
data modify storage commerce:cp vc234 set from storage commerce:l vc
data modify storage commerce:cp ae234 set from storage commerce:l ae
data modify storage commerce:cp az234 set from storage commerce:l az
data modify storage commerce:cp ac234 set from storage commerce:l ac
data modify storage commerce:cp t234 set from storage commerce:l t
data modify storage commerce:cp tc234 set from storage commerce:l tc
scoreboard players set #i c.t 235
function commerce:page/ligne
data modify storage commerce:cp ve235 set from storage commerce:l ve
data modify storage commerce:cp vz235 set from storage commerce:l vz
data modify storage commerce:cp vc235 set from storage commerce:l vc
data modify storage commerce:cp ae235 set from storage commerce:l ae
data modify storage commerce:cp az235 set from storage commerce:l az
data modify storage commerce:cp ac235 set from storage commerce:l ac
data modify storage commerce:cp t235 set from storage commerce:l t
data modify storage commerce:cp tc235 set from storage commerce:l tc
scoreboard players set #i c.t 236
function commerce:page/ligne
data modify storage commerce:cp ve236 set from storage commerce:l ve
data modify storage commerce:cp vz236 set from storage commerce:l vz
data modify storage commerce:cp vc236 set from storage commerce:l vc
data modify storage commerce:cp ae236 set from storage commerce:l ae
data modify storage commerce:cp az236 set from storage commerce:l az
data modify storage commerce:cp ac236 set from storage commerce:l ac
data modify storage commerce:cp t236 set from storage commerce:l t
data modify storage commerce:cp tc236 set from storage commerce:l tc
scoreboard players set #i c.t 237
function commerce:page/ligne
data modify storage commerce:cp ve237 set from storage commerce:l ve
data modify storage commerce:cp vz237 set from storage commerce:l vz
data modify storage commerce:cp vc237 set from storage commerce:l vc
data modify storage commerce:cp ae237 set from storage commerce:l ae
data modify storage commerce:cp az237 set from storage commerce:l az
data modify storage commerce:cp ac237 set from storage commerce:l ac
data modify storage commerce:cp t237 set from storage commerce:l t
data modify storage commerce:cp tc237 set from storage commerce:l tc
scoreboard players set #i c.t 238
function commerce:page/ligne
data modify storage commerce:cp ve238 set from storage commerce:l ve
data modify storage commerce:cp vz238 set from storage commerce:l vz
data modify storage commerce:cp vc238 set from storage commerce:l vc
data modify storage commerce:cp ae238 set from storage commerce:l ae
data modify storage commerce:cp az238 set from storage commerce:l az
data modify storage commerce:cp ac238 set from storage commerce:l ac
data modify storage commerce:cp t238 set from storage commerce:l t
data modify storage commerce:cp tc238 set from storage commerce:l tc
scoreboard players set #i c.t 239
function commerce:page/ligne
data modify storage commerce:cp ve239 set from storage commerce:l ve
data modify storage commerce:cp vz239 set from storage commerce:l vz
data modify storage commerce:cp vc239 set from storage commerce:l vc
data modify storage commerce:cp ae239 set from storage commerce:l ae
data modify storage commerce:cp az239 set from storage commerce:l az
data modify storage commerce:cp ac239 set from storage commerce:l ac
data modify storage commerce:cp t239 set from storage commerce:l t
data modify storage commerce:cp tc239 set from storage commerce:l tc
scoreboard players set #i c.t 240
function commerce:page/ligne
data modify storage commerce:cp ve240 set from storage commerce:l ve
data modify storage commerce:cp vz240 set from storage commerce:l vz
data modify storage commerce:cp vc240 set from storage commerce:l vc
data modify storage commerce:cp ae240 set from storage commerce:l ae
data modify storage commerce:cp az240 set from storage commerce:l az
data modify storage commerce:cp ac240 set from storage commerce:l ac
data modify storage commerce:cp t240 set from storage commerce:l t
data modify storage commerce:cp tc240 set from storage commerce:l tc
scoreboard players set #i c.t 241
function commerce:page/ligne
data modify storage commerce:cp ve241 set from storage commerce:l ve
data modify storage commerce:cp vz241 set from storage commerce:l vz
data modify storage commerce:cp vc241 set from storage commerce:l vc
data modify storage commerce:cp ae241 set from storage commerce:l ae
data modify storage commerce:cp az241 set from storage commerce:l az
data modify storage commerce:cp ac241 set from storage commerce:l ac
data modify storage commerce:cp t241 set from storage commerce:l t
data modify storage commerce:cp tc241 set from storage commerce:l tc
scoreboard players set #i c.t 242
function commerce:page/ligne
data modify storage commerce:cp ve242 set from storage commerce:l ve
data modify storage commerce:cp vz242 set from storage commerce:l vz
data modify storage commerce:cp vc242 set from storage commerce:l vc
data modify storage commerce:cp ae242 set from storage commerce:l ae
data modify storage commerce:cp az242 set from storage commerce:l az
data modify storage commerce:cp ac242 set from storage commerce:l ac
data modify storage commerce:cp t242 set from storage commerce:l t
data modify storage commerce:cp tc242 set from storage commerce:l tc
scoreboard players set #i c.t 243
function commerce:page/ligne
data modify storage commerce:cp ve243 set from storage commerce:l ve
data modify storage commerce:cp vz243 set from storage commerce:l vz
data modify storage commerce:cp vc243 set from storage commerce:l vc
data modify storage commerce:cp ae243 set from storage commerce:l ae
data modify storage commerce:cp az243 set from storage commerce:l az
data modify storage commerce:cp ac243 set from storage commerce:l ac
data modify storage commerce:cp t243 set from storage commerce:l t
data modify storage commerce:cp tc243 set from storage commerce:l tc
scoreboard players set #i c.t 244
function commerce:page/ligne
data modify storage commerce:cp ve244 set from storage commerce:l ve
data modify storage commerce:cp vz244 set from storage commerce:l vz
data modify storage commerce:cp vc244 set from storage commerce:l vc
data modify storage commerce:cp ae244 set from storage commerce:l ae
data modify storage commerce:cp az244 set from storage commerce:l az
data modify storage commerce:cp ac244 set from storage commerce:l ac
data modify storage commerce:cp t244 set from storage commerce:l t
data modify storage commerce:cp tc244 set from storage commerce:l tc
scoreboard players set #i c.t 245
function commerce:page/ligne
data modify storage commerce:cp ve245 set from storage commerce:l ve
data modify storage commerce:cp vz245 set from storage commerce:l vz
data modify storage commerce:cp vc245 set from storage commerce:l vc
data modify storage commerce:cp ae245 set from storage commerce:l ae
data modify storage commerce:cp az245 set from storage commerce:l az
data modify storage commerce:cp ac245 set from storage commerce:l ac
data modify storage commerce:cp t245 set from storage commerce:l t
data modify storage commerce:cp tc245 set from storage commerce:l tc
scoreboard players set #i c.t 246
function commerce:page/ligne
data modify storage commerce:cp ve246 set from storage commerce:l ve
data modify storage commerce:cp vz246 set from storage commerce:l vz
data modify storage commerce:cp vc246 set from storage commerce:l vc
data modify storage commerce:cp ae246 set from storage commerce:l ae
data modify storage commerce:cp az246 set from storage commerce:l az
data modify storage commerce:cp ac246 set from storage commerce:l ac
data modify storage commerce:cp t246 set from storage commerce:l t
data modify storage commerce:cp tc246 set from storage commerce:l tc
scoreboard players set #i c.t 247
function commerce:page/ligne
data modify storage commerce:cp ve247 set from storage commerce:l ve
data modify storage commerce:cp vz247 set from storage commerce:l vz
data modify storage commerce:cp vc247 set from storage commerce:l vc
data modify storage commerce:cp ae247 set from storage commerce:l ae
data modify storage commerce:cp az247 set from storage commerce:l az
data modify storage commerce:cp ac247 set from storage commerce:l ac
data modify storage commerce:cp t247 set from storage commerce:l t
data modify storage commerce:cp tc247 set from storage commerce:l tc
scoreboard players set #i c.t 248
function commerce:page/ligne
data modify storage commerce:cp ve248 set from storage commerce:l ve
data modify storage commerce:cp vz248 set from storage commerce:l vz
data modify storage commerce:cp vc248 set from storage commerce:l vc
data modify storage commerce:cp ae248 set from storage commerce:l ae
data modify storage commerce:cp az248 set from storage commerce:l az
data modify storage commerce:cp ac248 set from storage commerce:l ac
data modify storage commerce:cp t248 set from storage commerce:l t
data modify storage commerce:cp tc248 set from storage commerce:l tc
scoreboard players set #i c.t 249
function commerce:page/ligne
data modify storage commerce:cp ve249 set from storage commerce:l ve
data modify storage commerce:cp vz249 set from storage commerce:l vz
data modify storage commerce:cp vc249 set from storage commerce:l vc
data modify storage commerce:cp ae249 set from storage commerce:l ae
data modify storage commerce:cp az249 set from storage commerce:l az
data modify storage commerce:cp ac249 set from storage commerce:l ac
data modify storage commerce:cp t249 set from storage commerce:l t
data modify storage commerce:cp tc249 set from storage commerce:l tc
function commerce:page/cat_8_d with storage commerce:cp
