scoreboard players set #btot c.t 0
scoreboard players set #lot c.t 1
execute unless items entity @s container.* minecraft:diamond[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:diamond[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:diamond[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 431
execute if items entity @s weapon.offhand minecraft:diamond[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 431
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:diamond_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:diamond_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:diamond_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 432
execute if items entity @s weapon.offhand minecraft:diamond_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 432
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:emerald[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:emerald[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:emerald[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 433
execute if items entity @s weapon.offhand minecraft:emerald[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 433
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:emerald_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:emerald_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:emerald_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 434
execute if items entity @s weapon.offhand minecraft:emerald_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 434
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:ancient_debris[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:ancient_debris[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:ancient_debris[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 435
execute if items entity @s weapon.offhand minecraft:ancient_debris[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 435
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:netherite_scrap[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:netherite_scrap[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:netherite_scrap[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 436
execute if items entity @s weapon.offhand minecraft:netherite_scrap[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 436
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:netherite_ingot[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:netherite_ingot[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:netherite_ingot[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 437
execute if items entity @s weapon.offhand minecraft:netherite_ingot[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 437
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:echo_shard[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:echo_shard[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:echo_shard[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 438
execute if items entity @s weapon.offhand minecraft:echo_shard[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 438
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:nautilus_shell[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:nautilus_shell[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:nautilus_shell[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 439
execute if items entity @s weapon.offhand minecraft:nautilus_shell[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 439
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:heart_of_the_sea[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:heart_of_the_sea[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:heart_of_the_sea[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 440
execute if items entity @s weapon.offhand minecraft:heart_of_the_sea[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 440
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:sponge[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:sponge[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:sponge[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 441
execute if items entity @s weapon.offhand minecraft:sponge[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 441
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:wet_sponge[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:wet_sponge[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:wet_sponge[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 442
execute if items entity @s weapon.offhand minecraft:wet_sponge[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 442
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:ghast_tear[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:ghast_tear[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:ghast_tear[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 443
execute if items entity @s weapon.offhand minecraft:ghast_tear[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 443
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:shulker_shell[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:shulker_shell[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:shulker_shell[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 444
execute if items entity @s weapon.offhand minecraft:shulker_shell[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 444
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:totem_of_undying[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:totem_of_undying[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:totem_of_undying[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 445
execute if items entity @s weapon.offhand minecraft:totem_of_undying[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 445
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:wither_skeleton_skull[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:wither_skeleton_skull[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:wither_skeleton_skull[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 446
execute if items entity @s weapon.offhand minecraft:wither_skeleton_skull[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 446
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:skeleton_skull[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:skeleton_skull[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:skeleton_skull[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 447
execute if items entity @s weapon.offhand minecraft:skeleton_skull[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 447
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:zombie_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:zombie_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:zombie_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 448
execute if items entity @s weapon.offhand minecraft:zombie_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 448
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:creeper_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:creeper_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:creeper_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 449
execute if items entity @s weapon.offhand minecraft:creeper_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 449
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:piglin_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:piglin_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:piglin_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 450
execute if items entity @s weapon.offhand minecraft:piglin_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 450
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:nether_star[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:nether_star[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:nether_star[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 451
execute if items entity @s weapon.offhand minecraft:nether_star[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 451
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:dragon_breath[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:dragon_breath[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:dragon_breath[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 452
execute if items entity @s weapon.offhand minecraft:dragon_breath[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 452
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:dragon_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:dragon_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:dragon_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 453
execute if items entity @s weapon.offhand minecraft:dragon_head[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 453
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:heavy_core[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:heavy_core[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:heavy_core[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 454
execute if items entity @s weapon.offhand minecraft:heavy_core[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 454
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:goat_horn[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:goat_horn[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:goat_horn[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 455
execute if items entity @s weapon.offhand minecraft:goat_horn[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 455
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:sniffer_egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:sniffer_egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:sniffer_egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 456
execute if items entity @s weapon.offhand minecraft:sniffer_egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 456
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:trident[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:trident[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:trident[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 457
execute if items entity @s weapon.offhand minecraft:trident[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 457
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:enchanted_golden_apple[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:enchanted_golden_apple[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:enchanted_golden_apple[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 458
execute if items entity @s weapon.offhand minecraft:enchanted_golden_apple[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 458
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
scoreboard players set #lot c.t 0
scoreboard players operation #btot c.t /= #100 c.g
execute if score #btot c.t matches ..0 run tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Rien à vendre dans cette catégorie (les objets renommés ou spéciaux sont gardés).",color:"red",bold:false,italic:false}]
execute if score #btot c.t matches 1.. run tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Trésors vendu en entier : ",color:"gray",bold:false,italic:false},{score:{name:"#btot",objective:"c.t"},color:"gold",bold:true},{text:" Écus",color:"gold",bold:false,italic:false}]
execute if score #btot c.t matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.7 1.4
function commerce:page/cat_15_0
