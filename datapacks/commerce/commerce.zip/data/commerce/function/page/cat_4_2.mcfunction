function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 108
function commerce:page/ligne
data modify storage commerce:cp ve108 set from storage commerce:l ve
data modify storage commerce:cp vz108 set from storage commerce:l vz
data modify storage commerce:cp vc108 set from storage commerce:l vc
data modify storage commerce:cp ae108 set from storage commerce:l ae
data modify storage commerce:cp az108 set from storage commerce:l az
data modify storage commerce:cp ac108 set from storage commerce:l ac
data modify storage commerce:cp t108 set from storage commerce:l t
scoreboard players set #i c.t 109
function commerce:page/ligne
data modify storage commerce:cp ve109 set from storage commerce:l ve
data modify storage commerce:cp vz109 set from storage commerce:l vz
data modify storage commerce:cp vc109 set from storage commerce:l vc
data modify storage commerce:cp ae109 set from storage commerce:l ae
data modify storage commerce:cp az109 set from storage commerce:l az
data modify storage commerce:cp ac109 set from storage commerce:l ac
data modify storage commerce:cp t109 set from storage commerce:l t
scoreboard players set #i c.t 110
function commerce:page/ligne
data modify storage commerce:cp ve110 set from storage commerce:l ve
data modify storage commerce:cp vz110 set from storage commerce:l vz
data modify storage commerce:cp vc110 set from storage commerce:l vc
data modify storage commerce:cp ae110 set from storage commerce:l ae
data modify storage commerce:cp az110 set from storage commerce:l az
data modify storage commerce:cp ac110 set from storage commerce:l ac
data modify storage commerce:cp t110 set from storage commerce:l t
scoreboard players set #i c.t 111
function commerce:page/ligne
data modify storage commerce:cp ve111 set from storage commerce:l ve
data modify storage commerce:cp vz111 set from storage commerce:l vz
data modify storage commerce:cp vc111 set from storage commerce:l vc
data modify storage commerce:cp ae111 set from storage commerce:l ae
data modify storage commerce:cp az111 set from storage commerce:l az
data modify storage commerce:cp ac111 set from storage commerce:l ac
data modify storage commerce:cp t111 set from storage commerce:l t
scoreboard players set #i c.t 112
function commerce:page/ligne
data modify storage commerce:cp ve112 set from storage commerce:l ve
data modify storage commerce:cp vz112 set from storage commerce:l vz
data modify storage commerce:cp vc112 set from storage commerce:l vc
data modify storage commerce:cp ae112 set from storage commerce:l ae
data modify storage commerce:cp az112 set from storage commerce:l az
data modify storage commerce:cp ac112 set from storage commerce:l ac
data modify storage commerce:cp t112 set from storage commerce:l t
scoreboard players set #i c.t 113
function commerce:page/ligne
data modify storage commerce:cp ve113 set from storage commerce:l ve
data modify storage commerce:cp vz113 set from storage commerce:l vz
data modify storage commerce:cp vc113 set from storage commerce:l vc
data modify storage commerce:cp ae113 set from storage commerce:l ae
data modify storage commerce:cp az113 set from storage commerce:l az
data modify storage commerce:cp ac113 set from storage commerce:l ac
data modify storage commerce:cp t113 set from storage commerce:l t
scoreboard players set #i c.t 114
function commerce:page/ligne
data modify storage commerce:cp ve114 set from storage commerce:l ve
data modify storage commerce:cp vz114 set from storage commerce:l vz
data modify storage commerce:cp vc114 set from storage commerce:l vc
data modify storage commerce:cp ae114 set from storage commerce:l ae
data modify storage commerce:cp az114 set from storage commerce:l az
data modify storage commerce:cp ac114 set from storage commerce:l ac
data modify storage commerce:cp t114 set from storage commerce:l t
scoreboard players set #i c.t 115
function commerce:page/ligne
data modify storage commerce:cp ve115 set from storage commerce:l ve
data modify storage commerce:cp vz115 set from storage commerce:l vz
data modify storage commerce:cp vc115 set from storage commerce:l vc
data modify storage commerce:cp ae115 set from storage commerce:l ae
data modify storage commerce:cp az115 set from storage commerce:l az
data modify storage commerce:cp ac115 set from storage commerce:l ac
data modify storage commerce:cp t115 set from storage commerce:l t
scoreboard players set #i c.t 116
function commerce:page/ligne
data modify storage commerce:cp ve116 set from storage commerce:l ve
data modify storage commerce:cp vz116 set from storage commerce:l vz
data modify storage commerce:cp vc116 set from storage commerce:l vc
data modify storage commerce:cp ae116 set from storage commerce:l ae
data modify storage commerce:cp az116 set from storage commerce:l az
data modify storage commerce:cp ac116 set from storage commerce:l ac
data modify storage commerce:cp t116 set from storage commerce:l t
scoreboard players set #i c.t 117
function commerce:page/ligne
data modify storage commerce:cp ve117 set from storage commerce:l ve
data modify storage commerce:cp vz117 set from storage commerce:l vz
data modify storage commerce:cp vc117 set from storage commerce:l vc
data modify storage commerce:cp ae117 set from storage commerce:l ae
data modify storage commerce:cp az117 set from storage commerce:l az
data modify storage commerce:cp ac117 set from storage commerce:l ac
data modify storage commerce:cp t117 set from storage commerce:l t
function commerce:page/cat_4_2_d with storage commerce:cp
