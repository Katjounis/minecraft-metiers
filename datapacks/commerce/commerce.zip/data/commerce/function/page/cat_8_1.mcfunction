function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 231
function commerce:page/ligne
data modify storage commerce:cp ve231 set from storage commerce:l ve
data modify storage commerce:cp vz231 set from storage commerce:l vz
data modify storage commerce:cp vc231 set from storage commerce:l vc
data modify storage commerce:cp ae231 set from storage commerce:l ae
data modify storage commerce:cp az231 set from storage commerce:l az
data modify storage commerce:cp ac231 set from storage commerce:l ac
data modify storage commerce:cp t231 set from storage commerce:l t
scoreboard players set #i c.t 232
function commerce:page/ligne
data modify storage commerce:cp ve232 set from storage commerce:l ve
data modify storage commerce:cp vz232 set from storage commerce:l vz
data modify storage commerce:cp vc232 set from storage commerce:l vc
data modify storage commerce:cp ae232 set from storage commerce:l ae
data modify storage commerce:cp az232 set from storage commerce:l az
data modify storage commerce:cp ac232 set from storage commerce:l ac
data modify storage commerce:cp t232 set from storage commerce:l t
scoreboard players set #i c.t 233
function commerce:page/ligne
data modify storage commerce:cp ve233 set from storage commerce:l ve
data modify storage commerce:cp vz233 set from storage commerce:l vz
data modify storage commerce:cp vc233 set from storage commerce:l vc
data modify storage commerce:cp ae233 set from storage commerce:l ae
data modify storage commerce:cp az233 set from storage commerce:l az
data modify storage commerce:cp ac233 set from storage commerce:l ac
data modify storage commerce:cp t233 set from storage commerce:l t
scoreboard players set #i c.t 234
function commerce:page/ligne
data modify storage commerce:cp ve234 set from storage commerce:l ve
data modify storage commerce:cp vz234 set from storage commerce:l vz
data modify storage commerce:cp vc234 set from storage commerce:l vc
data modify storage commerce:cp ae234 set from storage commerce:l ae
data modify storage commerce:cp az234 set from storage commerce:l az
data modify storage commerce:cp ac234 set from storage commerce:l ac
data modify storage commerce:cp t234 set from storage commerce:l t
scoreboard players set #i c.t 235
function commerce:page/ligne
data modify storage commerce:cp ve235 set from storage commerce:l ve
data modify storage commerce:cp vz235 set from storage commerce:l vz
data modify storage commerce:cp vc235 set from storage commerce:l vc
data modify storage commerce:cp ae235 set from storage commerce:l ae
data modify storage commerce:cp az235 set from storage commerce:l az
data modify storage commerce:cp ac235 set from storage commerce:l ac
data modify storage commerce:cp t235 set from storage commerce:l t
scoreboard players set #i c.t 236
function commerce:page/ligne
data modify storage commerce:cp ve236 set from storage commerce:l ve
data modify storage commerce:cp vz236 set from storage commerce:l vz
data modify storage commerce:cp vc236 set from storage commerce:l vc
data modify storage commerce:cp ae236 set from storage commerce:l ae
data modify storage commerce:cp az236 set from storage commerce:l az
data modify storage commerce:cp ac236 set from storage commerce:l ac
data modify storage commerce:cp t236 set from storage commerce:l t
scoreboard players set #i c.t 237
function commerce:page/ligne
data modify storage commerce:cp ve237 set from storage commerce:l ve
data modify storage commerce:cp vz237 set from storage commerce:l vz
data modify storage commerce:cp vc237 set from storage commerce:l vc
data modify storage commerce:cp ae237 set from storage commerce:l ae
data modify storage commerce:cp az237 set from storage commerce:l az
data modify storage commerce:cp ac237 set from storage commerce:l ac
data modify storage commerce:cp t237 set from storage commerce:l t
scoreboard players set #i c.t 238
function commerce:page/ligne
data modify storage commerce:cp ve238 set from storage commerce:l ve
data modify storage commerce:cp vz238 set from storage commerce:l vz
data modify storage commerce:cp vc238 set from storage commerce:l vc
data modify storage commerce:cp ae238 set from storage commerce:l ae
data modify storage commerce:cp az238 set from storage commerce:l az
data modify storage commerce:cp ac238 set from storage commerce:l ac
data modify storage commerce:cp t238 set from storage commerce:l t
scoreboard players set #i c.t 239
function commerce:page/ligne
data modify storage commerce:cp ve239 set from storage commerce:l ve
data modify storage commerce:cp vz239 set from storage commerce:l vz
data modify storage commerce:cp vc239 set from storage commerce:l vc
data modify storage commerce:cp ae239 set from storage commerce:l ae
data modify storage commerce:cp az239 set from storage commerce:l az
data modify storage commerce:cp ac239 set from storage commerce:l ac
data modify storage commerce:cp t239 set from storage commerce:l t
scoreboard players set #i c.t 240
function commerce:page/ligne
data modify storage commerce:cp ve240 set from storage commerce:l ve
data modify storage commerce:cp vz240 set from storage commerce:l vz
data modify storage commerce:cp vc240 set from storage commerce:l vc
data modify storage commerce:cp ae240 set from storage commerce:l ae
data modify storage commerce:cp az240 set from storage commerce:l az
data modify storage commerce:cp ac240 set from storage commerce:l ac
data modify storage commerce:cp t240 set from storage commerce:l t
function commerce:page/cat_8_1_d with storage commerce:cp
