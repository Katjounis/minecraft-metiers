function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 106
function commerce:page/ligne
data modify storage commerce:cp ve106 set from storage commerce:l ve
data modify storage commerce:cp vz106 set from storage commerce:l vz
data modify storage commerce:cp vc106 set from storage commerce:l vc
data modify storage commerce:cp ae106 set from storage commerce:l ae
data modify storage commerce:cp az106 set from storage commerce:l az
data modify storage commerce:cp ac106 set from storage commerce:l ac
data modify storage commerce:cp t106 set from storage commerce:l t
scoreboard players set #i c.t 91
function commerce:page/ligne
data modify storage commerce:cp ve91 set from storage commerce:l ve
data modify storage commerce:cp vz91 set from storage commerce:l vz
data modify storage commerce:cp vc91 set from storage commerce:l vc
data modify storage commerce:cp ae91 set from storage commerce:l ae
data modify storage commerce:cp az91 set from storage commerce:l az
data modify storage commerce:cp ac91 set from storage commerce:l ac
data modify storage commerce:cp t91 set from storage commerce:l t
scoreboard players set #i c.t 100
function commerce:page/ligne
data modify storage commerce:cp ve100 set from storage commerce:l ve
data modify storage commerce:cp vz100 set from storage commerce:l vz
data modify storage commerce:cp vc100 set from storage commerce:l vc
data modify storage commerce:cp ae100 set from storage commerce:l ae
data modify storage commerce:cp az100 set from storage commerce:l az
data modify storage commerce:cp ac100 set from storage commerce:l ac
data modify storage commerce:cp t100 set from storage commerce:l t
scoreboard players set #i c.t 97
function commerce:page/ligne
data modify storage commerce:cp ve97 set from storage commerce:l ve
data modify storage commerce:cp vz97 set from storage commerce:l vz
data modify storage commerce:cp vc97 set from storage commerce:l vc
data modify storage commerce:cp ae97 set from storage commerce:l ae
data modify storage commerce:cp az97 set from storage commerce:l az
data modify storage commerce:cp ac97 set from storage commerce:l ac
data modify storage commerce:cp t97 set from storage commerce:l t
scoreboard players set #i c.t 308
function commerce:page/ligne
data modify storage commerce:cp ve308 set from storage commerce:l ve
data modify storage commerce:cp vz308 set from storage commerce:l vz
data modify storage commerce:cp vc308 set from storage commerce:l vc
data modify storage commerce:cp ae308 set from storage commerce:l ae
data modify storage commerce:cp az308 set from storage commerce:l az
data modify storage commerce:cp ac308 set from storage commerce:l ac
data modify storage commerce:cp t308 set from storage commerce:l t
scoreboard players set #i c.t 338
function commerce:page/ligne
data modify storage commerce:cp ve338 set from storage commerce:l ve
data modify storage commerce:cp vz338 set from storage commerce:l vz
data modify storage commerce:cp vc338 set from storage commerce:l vc
data modify storage commerce:cp ae338 set from storage commerce:l ae
data modify storage commerce:cp az338 set from storage commerce:l az
data modify storage commerce:cp ac338 set from storage commerce:l ac
data modify storage commerce:cp t338 set from storage commerce:l t
scoreboard players set #i c.t 339
function commerce:page/ligne
data modify storage commerce:cp ve339 set from storage commerce:l ve
data modify storage commerce:cp vz339 set from storage commerce:l vz
data modify storage commerce:cp vc339 set from storage commerce:l vc
data modify storage commerce:cp ae339 set from storage commerce:l ae
data modify storage commerce:cp az339 set from storage commerce:l az
data modify storage commerce:cp ac339 set from storage commerce:l ac
data modify storage commerce:cp t339 set from storage commerce:l t
scoreboard players set #i c.t 48
function commerce:page/ligne
data modify storage commerce:cp ve48 set from storage commerce:l ve
data modify storage commerce:cp vz48 set from storage commerce:l vz
data modify storage commerce:cp vc48 set from storage commerce:l vc
data modify storage commerce:cp ae48 set from storage commerce:l ae
data modify storage commerce:cp az48 set from storage commerce:l az
data modify storage commerce:cp ac48 set from storage commerce:l ac
data modify storage commerce:cp t48 set from storage commerce:l t
scoreboard players set #i c.t 336
function commerce:page/ligne
data modify storage commerce:cp ve336 set from storage commerce:l ve
data modify storage commerce:cp vz336 set from storage commerce:l vz
data modify storage commerce:cp vc336 set from storage commerce:l vc
data modify storage commerce:cp ae336 set from storage commerce:l ae
data modify storage commerce:cp az336 set from storage commerce:l az
data modify storage commerce:cp ac336 set from storage commerce:l ac
data modify storage commerce:cp t336 set from storage commerce:l t
scoreboard players set #i c.t 337
function commerce:page/ligne
data modify storage commerce:cp ve337 set from storage commerce:l ve
data modify storage commerce:cp vz337 set from storage commerce:l vz
data modify storage commerce:cp vc337 set from storage commerce:l vc
data modify storage commerce:cp ae337 set from storage commerce:l ae
data modify storage commerce:cp az337 set from storage commerce:l az
data modify storage commerce:cp ac337 set from storage commerce:l ac
data modify storage commerce:cp t337 set from storage commerce:l t
function commerce:page/lettre_p_3_d with storage commerce:cp
