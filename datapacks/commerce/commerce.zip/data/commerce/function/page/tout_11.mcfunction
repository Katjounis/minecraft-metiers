scoreboard players set #btot c.t 0
scoreboard players set #lot c.t 1
execute unless items entity @s container.* minecraft:leather[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:leather[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:leather[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 302
execute if items entity @s weapon.offhand minecraft:leather[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 302
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:rabbit_hide[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:rabbit_hide[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:rabbit_hide[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 303
execute if items entity @s weapon.offhand minecraft:rabbit_hide[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 303
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:rabbit_foot[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:rabbit_foot[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:rabbit_foot[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 304
execute if items entity @s weapon.offhand minecraft:rabbit_foot[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 304
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 305
execute if items entity @s weapon.offhand minecraft:egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 305
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:brown_egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:brown_egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:brown_egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 306
execute if items entity @s weapon.offhand minecraft:brown_egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 306
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:blue_egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:blue_egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:blue_egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 307
execute if items entity @s weapon.offhand minecraft:blue_egg[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 307
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:feather[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:feather[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:feather[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 308
execute if items entity @s weapon.offhand minecraft:feather[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 308
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:beef[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:beef[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:beef[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 309
execute if items entity @s weapon.offhand minecraft:beef[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 309
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:porkchop[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:porkchop[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:porkchop[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 310
execute if items entity @s weapon.offhand minecraft:porkchop[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 310
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:chicken[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:chicken[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:chicken[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 311
execute if items entity @s weapon.offhand minecraft:chicken[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 311
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:mutton[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:mutton[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:mutton[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 312
execute if items entity @s weapon.offhand minecraft:mutton[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 312
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:rabbit[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:rabbit[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:rabbit[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 313
execute if items entity @s weapon.offhand minecraft:rabbit[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 313
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:honeycomb[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:honeycomb[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:honeycomb[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 314
execute if items entity @s weapon.offhand minecraft:honeycomb[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 314
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:honey_bottle[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:honey_bottle[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:honey_bottle[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 315
execute if items entity @s weapon.offhand minecraft:honey_bottle[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 315
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:honey_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:honey_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:honey_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 316
execute if items entity @s weapon.offhand minecraft:honey_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 316
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:turtle_scute[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:turtle_scute[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:turtle_scute[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 317
execute if items entity @s weapon.offhand minecraft:turtle_scute[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 317
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:armadillo_scute[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:armadillo_scute[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:armadillo_scute[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 318
execute if items entity @s weapon.offhand minecraft:armadillo_scute[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 318
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:rotten_flesh[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:rotten_flesh[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:rotten_flesh[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 319
execute if items entity @s weapon.offhand minecraft:rotten_flesh[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 319
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:bone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:bone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:bone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 320
execute if items entity @s weapon.offhand minecraft:bone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 320
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:bone_meal[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:bone_meal[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:bone_meal[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 321
execute if items entity @s weapon.offhand minecraft:bone_meal[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 321
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:string[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:string[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:string[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 322
execute if items entity @s weapon.offhand minecraft:string[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 322
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:gunpowder[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:gunpowder[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:gunpowder[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 323
execute if items entity @s weapon.offhand minecraft:gunpowder[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 323
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:spider_eye[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:spider_eye[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:spider_eye[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 324
execute if items entity @s weapon.offhand minecraft:spider_eye[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 324
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:fermented_spider_eye[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:fermented_spider_eye[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:fermented_spider_eye[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 325
execute if items entity @s weapon.offhand minecraft:fermented_spider_eye[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 325
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:slime_ball[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:slime_ball[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:slime_ball[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 326
execute if items entity @s weapon.offhand minecraft:slime_ball[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 326
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:slime_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:slime_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:slime_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 327
execute if items entity @s weapon.offhand minecraft:slime_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 327
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:ender_pearl[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:ender_pearl[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:ender_pearl[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 328
execute if items entity @s weapon.offhand minecraft:ender_pearl[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 328
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:blaze_rod[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:blaze_rod[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:blaze_rod[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 329
execute if items entity @s weapon.offhand minecraft:blaze_rod[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 329
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:blaze_powder[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:blaze_powder[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:blaze_powder[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 330
execute if items entity @s weapon.offhand minecraft:blaze_powder[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 330
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:ender_eye[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:ender_eye[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:ender_eye[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 331
execute if items entity @s weapon.offhand minecraft:ender_eye[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 331
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:breeze_rod[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:breeze_rod[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:breeze_rod[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 332
execute if items entity @s weapon.offhand minecraft:breeze_rod[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 332
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:phantom_membrane[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:phantom_membrane[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:phantom_membrane[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 333
execute if items entity @s weapon.offhand minecraft:phantom_membrane[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 333
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
scoreboard players set #lot c.t 0
scoreboard players operation #btot c.t /= #100 c.g
execute if score #btot c.t matches ..0 run tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Rien à vendre dans cette catégorie (les objets renommés ou spéciaux sont gardés).",color:"red",bold:false,italic:false}]
execute if score #btot c.t matches 1.. run tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Élevage et chasse vendu en entier : ",color:"gray",bold:false,italic:false},{score:{name:"#btot",objective:"c.t"},color:"gold",bold:true},{text:" Écus",color:"gold",bold:false,italic:false}]
execute if score #btot c.t matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.7 1.4
function commerce:page/cat_11_0
