function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 367
function commerce:page/ligne
data modify storage commerce:cp ve367 set from storage commerce:l ve
data modify storage commerce:cp vz367 set from storage commerce:l vz
data modify storage commerce:cp vc367 set from storage commerce:l vc
data modify storage commerce:cp ae367 set from storage commerce:l ae
data modify storage commerce:cp az367 set from storage commerce:l az
data modify storage commerce:cp ac367 set from storage commerce:l ac
data modify storage commerce:cp t367 set from storage commerce:l t
scoreboard players set #i c.t 434
function commerce:page/ligne
data modify storage commerce:cp ve434 set from storage commerce:l ve
data modify storage commerce:cp vz434 set from storage commerce:l vz
data modify storage commerce:cp vc434 set from storage commerce:l vc
data modify storage commerce:cp ae434 set from storage commerce:l ae
data modify storage commerce:cp az434 set from storage commerce:l az
data modify storage commerce:cp ac434 set from storage commerce:l ac
data modify storage commerce:cp t434 set from storage commerce:l t
scoreboard players set #i c.t 275
function commerce:page/ligne
data modify storage commerce:cp ve275 set from storage commerce:l ve
data modify storage commerce:cp vz275 set from storage commerce:l vz
data modify storage commerce:cp vc275 set from storage commerce:l vc
data modify storage commerce:cp ae275 set from storage commerce:l ae
data modify storage commerce:cp az275 set from storage commerce:l az
data modify storage commerce:cp ac275 set from storage commerce:l ac
data modify storage commerce:cp t275 set from storage commerce:l t
scoreboard players set #i c.t 463
function commerce:page/ligne
data modify storage commerce:cp ve463 set from storage commerce:l ve
data modify storage commerce:cp vz463 set from storage commerce:l vz
data modify storage commerce:cp vc463 set from storage commerce:l vc
data modify storage commerce:cp ae463 set from storage commerce:l ae
data modify storage commerce:cp az463 set from storage commerce:l az
data modify storage commerce:cp ac463 set from storage commerce:l ac
data modify storage commerce:cp t463 set from storage commerce:l t
function commerce:page/lettre_f_2_d with storage commerce:cp
