function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 367
function commerce:page/ligne
data modify storage commerce:cp ve367 set from storage commerce:l ve
data modify storage commerce:cp vz367 set from storage commerce:l vz
data modify storage commerce:cp vc367 set from storage commerce:l vc
data modify storage commerce:cp ae367 set from storage commerce:l ae
data modify storage commerce:cp az367 set from storage commerce:l az
data modify storage commerce:cp ac367 set from storage commerce:l ac
data modify storage commerce:cp t367 set from storage commerce:l t
scoreboard players set #i c.t 436
function commerce:page/ligne
data modify storage commerce:cp ve436 set from storage commerce:l ve
data modify storage commerce:cp vz436 set from storage commerce:l vz
data modify storage commerce:cp vc436 set from storage commerce:l vc
data modify storage commerce:cp ae436 set from storage commerce:l ae
data modify storage commerce:cp az436 set from storage commerce:l az
data modify storage commerce:cp ac436 set from storage commerce:l ac
data modify storage commerce:cp t436 set from storage commerce:l t
scoreboard players set #i c.t 275
function commerce:page/ligne
data modify storage commerce:cp ve275 set from storage commerce:l ve
data modify storage commerce:cp vz275 set from storage commerce:l vz
data modify storage commerce:cp vc275 set from storage commerce:l vc
data modify storage commerce:cp ae275 set from storage commerce:l ae
data modify storage commerce:cp az275 set from storage commerce:l az
data modify storage commerce:cp ac275 set from storage commerce:l ac
data modify storage commerce:cp t275 set from storage commerce:l t
scoreboard players set #i c.t 470
function commerce:page/ligne
data modify storage commerce:cp ve470 set from storage commerce:l ve
data modify storage commerce:cp vz470 set from storage commerce:l vz
data modify storage commerce:cp vc470 set from storage commerce:l vc
data modify storage commerce:cp ae470 set from storage commerce:l ae
data modify storage commerce:cp az470 set from storage commerce:l az
data modify storage commerce:cp ac470 set from storage commerce:l ac
data modify storage commerce:cp t470 set from storage commerce:l t
function commerce:page/lettre_f_2_d with storage commerce:cp
