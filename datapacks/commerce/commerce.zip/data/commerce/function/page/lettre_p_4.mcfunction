function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 121
function commerce:page/ligne
data modify storage commerce:cp ve121 set from storage commerce:l ve
data modify storage commerce:cp vz121 set from storage commerce:l vz
data modify storage commerce:cp vc121 set from storage commerce:l vc
data modify storage commerce:cp ae121 set from storage commerce:l ae
data modify storage commerce:cp az121 set from storage commerce:l az
data modify storage commerce:cp ac121 set from storage commerce:l ac
data modify storage commerce:cp t121 set from storage commerce:l t
scoreboard players set #i c.t 455
function commerce:page/ligne
data modify storage commerce:cp ve455 set from storage commerce:l ve
data modify storage commerce:cp vz455 set from storage commerce:l vz
data modify storage commerce:cp vc455 set from storage commerce:l vc
data modify storage commerce:cp ae455 set from storage commerce:l ae
data modify storage commerce:cp az455 set from storage commerce:l az
data modify storage commerce:cp ac455 set from storage commerce:l ac
data modify storage commerce:cp t455 set from storage commerce:l t
scoreboard players set #i c.t 283
function commerce:page/ligne
data modify storage commerce:cp ve283 set from storage commerce:l ve
data modify storage commerce:cp vz283 set from storage commerce:l vz
data modify storage commerce:cp vc283 set from storage commerce:l vc
data modify storage commerce:cp ae283 set from storage commerce:l ae
data modify storage commerce:cp az283 set from storage commerce:l az
data modify storage commerce:cp ac283 set from storage commerce:l ac
data modify storage commerce:cp t283 set from storage commerce:l t
scoreboard players set #i c.t 348
function commerce:page/ligne
data modify storage commerce:cp ve348 set from storage commerce:l ve
data modify storage commerce:cp vz348 set from storage commerce:l vz
data modify storage commerce:cp vc348 set from storage commerce:l vc
data modify storage commerce:cp ae348 set from storage commerce:l ae
data modify storage commerce:cp az348 set from storage commerce:l az
data modify storage commerce:cp ac348 set from storage commerce:l ac
data modify storage commerce:cp t348 set from storage commerce:l t
scoreboard players set #i c.t 284
function commerce:page/ligne
data modify storage commerce:cp ve284 set from storage commerce:l ve
data modify storage commerce:cp vz284 set from storage commerce:l vz
data modify storage commerce:cp vc284 set from storage commerce:l vc
data modify storage commerce:cp ae284 set from storage commerce:l ae
data modify storage commerce:cp az284 set from storage commerce:l az
data modify storage commerce:cp ac284 set from storage commerce:l ac
data modify storage commerce:cp t284 set from storage commerce:l t
scoreboard players set #i c.t 360
function commerce:page/ligne
data modify storage commerce:cp ve360 set from storage commerce:l ve
data modify storage commerce:cp vz360 set from storage commerce:l vz
data modify storage commerce:cp vc360 set from storage commerce:l vc
data modify storage commerce:cp ae360 set from storage commerce:l ae
data modify storage commerce:cp az360 set from storage commerce:l az
data modify storage commerce:cp ac360 set from storage commerce:l ac
data modify storage commerce:cp t360 set from storage commerce:l t
scoreboard players set #i c.t 375
function commerce:page/ligne
data modify storage commerce:cp ve375 set from storage commerce:l ve
data modify storage commerce:cp vz375 set from storage commerce:l vz
data modify storage commerce:cp vc375 set from storage commerce:l vc
data modify storage commerce:cp ae375 set from storage commerce:l ae
data modify storage commerce:cp az375 set from storage commerce:l az
data modify storage commerce:cp ac375 set from storage commerce:l ac
data modify storage commerce:cp t375 set from storage commerce:l t
scoreboard players set #i c.t 323
function commerce:page/ligne
data modify storage commerce:cp ve323 set from storage commerce:l ve
data modify storage commerce:cp vz323 set from storage commerce:l vz
data modify storage commerce:cp vc323 set from storage commerce:l vc
data modify storage commerce:cp ae323 set from storage commerce:l ae
data modify storage commerce:cp az323 set from storage commerce:l az
data modify storage commerce:cp ac323 set from storage commerce:l ac
data modify storage commerce:cp t323 set from storage commerce:l t
scoreboard players set #i c.t 321
function commerce:page/ligne
data modify storage commerce:cp ve321 set from storage commerce:l ve
data modify storage commerce:cp vz321 set from storage commerce:l vz
data modify storage commerce:cp vc321 set from storage commerce:l vc
data modify storage commerce:cp ae321 set from storage commerce:l ae
data modify storage commerce:cp az321 set from storage commerce:l az
data modify storage commerce:cp ac321 set from storage commerce:l ac
data modify storage commerce:cp t321 set from storage commerce:l t
scoreboard players set #i c.t 330
function commerce:page/ligne
data modify storage commerce:cp ve330 set from storage commerce:l ve
data modify storage commerce:cp vz330 set from storage commerce:l vz
data modify storage commerce:cp vc330 set from storage commerce:l vc
data modify storage commerce:cp ae330 set from storage commerce:l ae
data modify storage commerce:cp az330 set from storage commerce:l az
data modify storage commerce:cp ac330 set from storage commerce:l ac
data modify storage commerce:cp t330 set from storage commerce:l t
function commerce:page/lettre_p_4_d with storage commerce:cp
