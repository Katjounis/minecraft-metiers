function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 381
function commerce:page/ligne
data modify storage commerce:cp ve381 set from storage commerce:l ve
data modify storage commerce:cp vz381 set from storage commerce:l vz
data modify storage commerce:cp vc381 set from storage commerce:l vc
data modify storage commerce:cp ae381 set from storage commerce:l ae
data modify storage commerce:cp az381 set from storage commerce:l az
data modify storage commerce:cp ac381 set from storage commerce:l ac
data modify storage commerce:cp t381 set from storage commerce:l t
scoreboard players set #i c.t 43
function commerce:page/ligne
data modify storage commerce:cp ve43 set from storage commerce:l ve
data modify storage commerce:cp vz43 set from storage commerce:l vz
data modify storage commerce:cp vc43 set from storage commerce:l vc
data modify storage commerce:cp ae43 set from storage commerce:l ae
data modify storage commerce:cp az43 set from storage commerce:l az
data modify storage commerce:cp ac43 set from storage commerce:l ac
data modify storage commerce:cp t43 set from storage commerce:l t
scoreboard players set #i c.t 44
function commerce:page/ligne
data modify storage commerce:cp ve44 set from storage commerce:l ve
data modify storage commerce:cp vz44 set from storage commerce:l vz
data modify storage commerce:cp vc44 set from storage commerce:l vc
data modify storage commerce:cp ae44 set from storage commerce:l ae
data modify storage commerce:cp az44 set from storage commerce:l az
data modify storage commerce:cp ac44 set from storage commerce:l ac
data modify storage commerce:cp t44 set from storage commerce:l t
scoreboard players set #i c.t 324
function commerce:page/ligne
data modify storage commerce:cp ve324 set from storage commerce:l ve
data modify storage commerce:cp vz324 set from storage commerce:l vz
data modify storage commerce:cp vc324 set from storage commerce:l vc
data modify storage commerce:cp ae324 set from storage commerce:l ae
data modify storage commerce:cp az324 set from storage commerce:l az
data modify storage commerce:cp ac324 set from storage commerce:l ac
data modify storage commerce:cp t324 set from storage commerce:l t
scoreboard players set #i c.t 325
function commerce:page/ligne
data modify storage commerce:cp ve325 set from storage commerce:l ve
data modify storage commerce:cp vz325 set from storage commerce:l vz
data modify storage commerce:cp vc325 set from storage commerce:l vc
data modify storage commerce:cp ae325 set from storage commerce:l ae
data modify storage commerce:cp az325 set from storage commerce:l az
data modify storage commerce:cp ac325 set from storage commerce:l ac
data modify storage commerce:cp t325 set from storage commerce:l t
scoreboard players set #i c.t 331
function commerce:page/ligne
data modify storage commerce:cp ve331 set from storage commerce:l ve
data modify storage commerce:cp vz331 set from storage commerce:l vz
data modify storage commerce:cp vc331 set from storage commerce:l vc
data modify storage commerce:cp ae331 set from storage commerce:l ae
data modify storage commerce:cp az331 set from storage commerce:l az
data modify storage commerce:cp ac331 set from storage commerce:l ac
data modify storage commerce:cp t331 set from storage commerce:l t
scoreboard players set #i c.t 305
function commerce:page/ligne
data modify storage commerce:cp ve305 set from storage commerce:l ve
data modify storage commerce:cp vz305 set from storage commerce:l vz
data modify storage commerce:cp vc305 set from storage commerce:l vc
data modify storage commerce:cp ae305 set from storage commerce:l ae
data modify storage commerce:cp az305 set from storage commerce:l az
data modify storage commerce:cp ac305 set from storage commerce:l ac
data modify storage commerce:cp t305 set from storage commerce:l t
scoreboard players set #i c.t 307
function commerce:page/ligne
data modify storage commerce:cp ve307 set from storage commerce:l ve
data modify storage commerce:cp vz307 set from storage commerce:l vz
data modify storage commerce:cp vc307 set from storage commerce:l vc
data modify storage commerce:cp ae307 set from storage commerce:l ae
data modify storage commerce:cp az307 set from storage commerce:l az
data modify storage commerce:cp ac307 set from storage commerce:l ac
data modify storage commerce:cp t307 set from storage commerce:l t
scoreboard players set #i c.t 306
function commerce:page/ligne
data modify storage commerce:cp ve306 set from storage commerce:l ve
data modify storage commerce:cp vz306 set from storage commerce:l vz
data modify storage commerce:cp vc306 set from storage commerce:l vc
data modify storage commerce:cp ae306 set from storage commerce:l ae
data modify storage commerce:cp az306 set from storage commerce:l az
data modify storage commerce:cp ac306 set from storage commerce:l ac
data modify storage commerce:cp t306 set from storage commerce:l t
scoreboard players set #i c.t 456
function commerce:page/ligne
data modify storage commerce:cp ve456 set from storage commerce:l ve
data modify storage commerce:cp vz456 set from storage commerce:l vz
data modify storage commerce:cp vc456 set from storage commerce:l vc
data modify storage commerce:cp ae456 set from storage commerce:l ae
data modify storage commerce:cp az456 set from storage commerce:l az
data modify storage commerce:cp ac456 set from storage commerce:l ac
data modify storage commerce:cp t456 set from storage commerce:l t
function commerce:page/lettre_o_0_d with storage commerce:cp
