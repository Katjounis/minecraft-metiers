function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 439
function commerce:page/ligne
data modify storage commerce:cp ve439 set from storage commerce:l ve
data modify storage commerce:cp vz439 set from storage commerce:l vz
data modify storage commerce:cp vc439 set from storage commerce:l vc
data modify storage commerce:cp ae439 set from storage commerce:l ae
data modify storage commerce:cp az439 set from storage commerce:l az
data modify storage commerce:cp ac439 set from storage commerce:l ac
data modify storage commerce:cp t439 set from storage commerce:l t
scoreboard players set #i c.t 440
function commerce:page/ligne
data modify storage commerce:cp ve440 set from storage commerce:l ve
data modify storage commerce:cp vz440 set from storage commerce:l vz
data modify storage commerce:cp vc440 set from storage commerce:l vc
data modify storage commerce:cp ae440 set from storage commerce:l ae
data modify storage commerce:cp az440 set from storage commerce:l az
data modify storage commerce:cp ac440 set from storage commerce:l ac
data modify storage commerce:cp t440 set from storage commerce:l t
scoreboard players set #i c.t 441
function commerce:page/ligne
data modify storage commerce:cp ve441 set from storage commerce:l ve
data modify storage commerce:cp vz441 set from storage commerce:l vz
data modify storage commerce:cp vc441 set from storage commerce:l vc
data modify storage commerce:cp ae441 set from storage commerce:l ae
data modify storage commerce:cp az441 set from storage commerce:l az
data modify storage commerce:cp ac441 set from storage commerce:l ac
data modify storage commerce:cp t441 set from storage commerce:l t
scoreboard players set #i c.t 442
function commerce:page/ligne
data modify storage commerce:cp ve442 set from storage commerce:l ve
data modify storage commerce:cp vz442 set from storage commerce:l vz
data modify storage commerce:cp vc442 set from storage commerce:l vc
data modify storage commerce:cp ae442 set from storage commerce:l ae
data modify storage commerce:cp az442 set from storage commerce:l az
data modify storage commerce:cp ac442 set from storage commerce:l ac
data modify storage commerce:cp t442 set from storage commerce:l t
scoreboard players set #i c.t 443
function commerce:page/ligne
data modify storage commerce:cp ve443 set from storage commerce:l ve
data modify storage commerce:cp vz443 set from storage commerce:l vz
data modify storage commerce:cp vc443 set from storage commerce:l vc
data modify storage commerce:cp ae443 set from storage commerce:l ae
data modify storage commerce:cp az443 set from storage commerce:l az
data modify storage commerce:cp ac443 set from storage commerce:l ac
data modify storage commerce:cp t443 set from storage commerce:l t
scoreboard players set #i c.t 444
function commerce:page/ligne
data modify storage commerce:cp ve444 set from storage commerce:l ve
data modify storage commerce:cp vz444 set from storage commerce:l vz
data modify storage commerce:cp vc444 set from storage commerce:l vc
data modify storage commerce:cp ae444 set from storage commerce:l ae
data modify storage commerce:cp az444 set from storage commerce:l az
data modify storage commerce:cp ac444 set from storage commerce:l ac
data modify storage commerce:cp t444 set from storage commerce:l t
scoreboard players set #i c.t 445
function commerce:page/ligne
data modify storage commerce:cp ve445 set from storage commerce:l ve
data modify storage commerce:cp vz445 set from storage commerce:l vz
data modify storage commerce:cp vc445 set from storage commerce:l vc
data modify storage commerce:cp ae445 set from storage commerce:l ae
data modify storage commerce:cp az445 set from storage commerce:l az
data modify storage commerce:cp ac445 set from storage commerce:l ac
data modify storage commerce:cp t445 set from storage commerce:l t
scoreboard players set #i c.t 446
function commerce:page/ligne
data modify storage commerce:cp ve446 set from storage commerce:l ve
data modify storage commerce:cp vz446 set from storage commerce:l vz
data modify storage commerce:cp vc446 set from storage commerce:l vc
data modify storage commerce:cp ae446 set from storage commerce:l ae
data modify storage commerce:cp az446 set from storage commerce:l az
data modify storage commerce:cp ac446 set from storage commerce:l ac
data modify storage commerce:cp t446 set from storage commerce:l t
scoreboard players set #i c.t 447
function commerce:page/ligne
data modify storage commerce:cp ve447 set from storage commerce:l ve
data modify storage commerce:cp vz447 set from storage commerce:l vz
data modify storage commerce:cp vc447 set from storage commerce:l vc
data modify storage commerce:cp ae447 set from storage commerce:l ae
data modify storage commerce:cp az447 set from storage commerce:l az
data modify storage commerce:cp ac447 set from storage commerce:l ac
data modify storage commerce:cp t447 set from storage commerce:l t
scoreboard players set #i c.t 448
function commerce:page/ligne
data modify storage commerce:cp ve448 set from storage commerce:l ve
data modify storage commerce:cp vz448 set from storage commerce:l vz
data modify storage commerce:cp vc448 set from storage commerce:l vc
data modify storage commerce:cp ae448 set from storage commerce:l ae
data modify storage commerce:cp az448 set from storage commerce:l az
data modify storage commerce:cp ac448 set from storage commerce:l ac
data modify storage commerce:cp t448 set from storage commerce:l t
function commerce:page/cat_15_1_d with storage commerce:cp
