function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 439
function commerce:page/ligne
data modify storage commerce:cp ve439 set from storage commerce:l ve
data modify storage commerce:cp vz439 set from storage commerce:l vz
data modify storage commerce:cp vc439 set from storage commerce:l vc
data modify storage commerce:cp ae439 set from storage commerce:l ae
data modify storage commerce:cp az439 set from storage commerce:l az
data modify storage commerce:cp ac439 set from storage commerce:l ac
data modify storage commerce:cp t439 set from storage commerce:l t
scoreboard players set #i c.t 440
function commerce:page/ligne
data modify storage commerce:cp ve440 set from storage commerce:l ve
data modify storage commerce:cp vz440 set from storage commerce:l vz
data modify storage commerce:cp vc440 set from storage commerce:l vc
data modify storage commerce:cp ae440 set from storage commerce:l ae
data modify storage commerce:cp az440 set from storage commerce:l az
data modify storage commerce:cp ac440 set from storage commerce:l ac
data modify storage commerce:cp t440 set from storage commerce:l t
scoreboard players set #i c.t 366
function commerce:page/ligne
data modify storage commerce:cp ve366 set from storage commerce:l ve
data modify storage commerce:cp vz366 set from storage commerce:l vz
data modify storage commerce:cp vc366 set from storage commerce:l vc
data modify storage commerce:cp ae366 set from storage commerce:l ae
data modify storage commerce:cp az366 set from storage commerce:l az
data modify storage commerce:cp ac366 set from storage commerce:l ac
data modify storage commerce:cp t366 set from storage commerce:l t
scoreboard players set #i c.t 395
function commerce:page/ligne
data modify storage commerce:cp ve395 set from storage commerce:l ve
data modify storage commerce:cp vz395 set from storage commerce:l vz
data modify storage commerce:cp vc395 set from storage commerce:l vc
data modify storage commerce:cp ae395 set from storage commerce:l ae
data modify storage commerce:cp az395 set from storage commerce:l az
data modify storage commerce:cp ac395 set from storage commerce:l ac
data modify storage commerce:cp t395 set from storage commerce:l t
scoreboard players set #i c.t 449
function commerce:page/ligne
data modify storage commerce:cp ve449 set from storage commerce:l ve
data modify storage commerce:cp vz449 set from storage commerce:l vz
data modify storage commerce:cp vc449 set from storage commerce:l vc
data modify storage commerce:cp ae449 set from storage commerce:l ae
data modify storage commerce:cp az449 set from storage commerce:l az
data modify storage commerce:cp ac449 set from storage commerce:l ac
data modify storage commerce:cp t449 set from storage commerce:l t
function commerce:page/lettre_e_1_d with storage commerce:cp
