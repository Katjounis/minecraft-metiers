function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 433
function commerce:page/ligne
data modify storage commerce:cp ve433 set from storage commerce:l ve
data modify storage commerce:cp vz433 set from storage commerce:l vz
data modify storage commerce:cp vc433 set from storage commerce:l vc
data modify storage commerce:cp ae433 set from storage commerce:l ae
data modify storage commerce:cp az433 set from storage commerce:l az
data modify storage commerce:cp ac433 set from storage commerce:l ac
data modify storage commerce:cp t433 set from storage commerce:l t
scoreboard players set #i c.t 464
function commerce:page/ligne
data modify storage commerce:cp ve464 set from storage commerce:l ve
data modify storage commerce:cp vz464 set from storage commerce:l vz
data modify storage commerce:cp vc464 set from storage commerce:l vc
data modify storage commerce:cp ae464 set from storage commerce:l ae
data modify storage commerce:cp az464 set from storage commerce:l az
data modify storage commerce:cp ac464 set from storage commerce:l ac
data modify storage commerce:cp t464 set from storage commerce:l t
scoreboard players set #i c.t 441
function commerce:page/ligne
data modify storage commerce:cp ve441 set from storage commerce:l ve
data modify storage commerce:cp vz441 set from storage commerce:l vz
data modify storage commerce:cp vc441 set from storage commerce:l vc
data modify storage commerce:cp ae441 set from storage commerce:l ae
data modify storage commerce:cp az441 set from storage commerce:l az
data modify storage commerce:cp ac441 set from storage commerce:l ac
data modify storage commerce:cp t441 set from storage commerce:l t
scoreboard players set #i c.t 442
function commerce:page/ligne
data modify storage commerce:cp ve442 set from storage commerce:l ve
data modify storage commerce:cp vz442 set from storage commerce:l vz
data modify storage commerce:cp vc442 set from storage commerce:l vc
data modify storage commerce:cp ae442 set from storage commerce:l ae
data modify storage commerce:cp az442 set from storage commerce:l az
data modify storage commerce:cp ac442 set from storage commerce:l ac
data modify storage commerce:cp t442 set from storage commerce:l t
scoreboard players set #i c.t 366
function commerce:page/ligne
data modify storage commerce:cp ve366 set from storage commerce:l ve
data modify storage commerce:cp vz366 set from storage commerce:l vz
data modify storage commerce:cp vc366 set from storage commerce:l vc
data modify storage commerce:cp ae366 set from storage commerce:l ae
data modify storage commerce:cp az366 set from storage commerce:l az
data modify storage commerce:cp ac366 set from storage commerce:l ac
data modify storage commerce:cp t366 set from storage commerce:l t
scoreboard players set #i c.t 397
function commerce:page/ligne
data modify storage commerce:cp ve397 set from storage commerce:l ve
data modify storage commerce:cp vz397 set from storage commerce:l vz
data modify storage commerce:cp vc397 set from storage commerce:l vc
data modify storage commerce:cp ae397 set from storage commerce:l ae
data modify storage commerce:cp az397 set from storage commerce:l az
data modify storage commerce:cp ac397 set from storage commerce:l ac
data modify storage commerce:cp t397 set from storage commerce:l t
scoreboard players set #i c.t 451
function commerce:page/ligne
data modify storage commerce:cp ve451 set from storage commerce:l ve
data modify storage commerce:cp vz451 set from storage commerce:l vz
data modify storage commerce:cp vc451 set from storage commerce:l vc
data modify storage commerce:cp ae451 set from storage commerce:l ae
data modify storage commerce:cp az451 set from storage commerce:l az
data modify storage commerce:cp ac451 set from storage commerce:l ac
data modify storage commerce:cp t451 set from storage commerce:l t
function commerce:page/lettre_e_1_d with storage commerce:cp
