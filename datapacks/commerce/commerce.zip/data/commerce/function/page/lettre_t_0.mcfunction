function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 349
function commerce:page/ligne
data modify storage commerce:cp ve349 set from storage commerce:l ve
data modify storage commerce:cp vz349 set from storage commerce:l vz
data modify storage commerce:cp vc349 set from storage commerce:l vc
data modify storage commerce:cp ae349 set from storage commerce:l ae
data modify storage commerce:cp az349 set from storage commerce:l az
data modify storage commerce:cp ac349 set from storage commerce:l ac
data modify storage commerce:cp t349 set from storage commerce:l t
scoreboard players set #i c.t 138
function commerce:page/ligne
data modify storage commerce:cp ve138 set from storage commerce:l ve
data modify storage commerce:cp vz138 set from storage commerce:l vz
data modify storage commerce:cp vc138 set from storage commerce:l vc
data modify storage commerce:cp ae138 set from storage commerce:l ae
data modify storage commerce:cp az138 set from storage commerce:l az
data modify storage commerce:cp ac138 set from storage commerce:l ac
data modify storage commerce:cp t138 set from storage commerce:l t
scoreboard players set #i c.t 141
function commerce:page/ligne
data modify storage commerce:cp ve141 set from storage commerce:l ve
data modify storage commerce:cp vz141 set from storage commerce:l vz
data modify storage commerce:cp vc141 set from storage commerce:l vc
data modify storage commerce:cp ae141 set from storage commerce:l ae
data modify storage commerce:cp az141 set from storage commerce:l az
data modify storage commerce:cp ac141 set from storage commerce:l ac
data modify storage commerce:cp t141 set from storage commerce:l t
scoreboard players set #i c.t 149
function commerce:page/ligne
data modify storage commerce:cp ve149 set from storage commerce:l ve
data modify storage commerce:cp vz149 set from storage commerce:l vz
data modify storage commerce:cp vc149 set from storage commerce:l vc
data modify storage commerce:cp ae149 set from storage commerce:l ae
data modify storage commerce:cp az149 set from storage commerce:l az
data modify storage commerce:cp ac149 set from storage commerce:l ac
data modify storage commerce:cp t149 set from storage commerce:l t
scoreboard players set #i c.t 147
function commerce:page/ligne
data modify storage commerce:cp ve147 set from storage commerce:l ve
data modify storage commerce:cp vz147 set from storage commerce:l vz
data modify storage commerce:cp vc147 set from storage commerce:l vc
data modify storage commerce:cp ae147 set from storage commerce:l ae
data modify storage commerce:cp az147 set from storage commerce:l az
data modify storage commerce:cp ac147 set from storage commerce:l ac
data modify storage commerce:cp t147 set from storage commerce:l t
scoreboard players set #i c.t 146
function commerce:page/ligne
data modify storage commerce:cp ve146 set from storage commerce:l ve
data modify storage commerce:cp vz146 set from storage commerce:l vz
data modify storage commerce:cp vc146 set from storage commerce:l vc
data modify storage commerce:cp ae146 set from storage commerce:l ae
data modify storage commerce:cp az146 set from storage commerce:l az
data modify storage commerce:cp ac146 set from storage commerce:l ac
data modify storage commerce:cp t146 set from storage commerce:l t
scoreboard players set #i c.t 145
function commerce:page/ligne
data modify storage commerce:cp ve145 set from storage commerce:l ve
data modify storage commerce:cp vz145 set from storage commerce:l vz
data modify storage commerce:cp vc145 set from storage commerce:l vc
data modify storage commerce:cp ae145 set from storage commerce:l ae
data modify storage commerce:cp az145 set from storage commerce:l az
data modify storage commerce:cp ac145 set from storage commerce:l ac
data modify storage commerce:cp t145 set from storage commerce:l t
scoreboard players set #i c.t 142
function commerce:page/ligne
data modify storage commerce:cp ve142 set from storage commerce:l ve
data modify storage commerce:cp vz142 set from storage commerce:l vz
data modify storage commerce:cp vc142 set from storage commerce:l vc
data modify storage commerce:cp ae142 set from storage commerce:l ae
data modify storage commerce:cp az142 set from storage commerce:l az
data modify storage commerce:cp ac142 set from storage commerce:l ac
data modify storage commerce:cp t142 set from storage commerce:l t
scoreboard players set #i c.t 140
function commerce:page/ligne
data modify storage commerce:cp ve140 set from storage commerce:l ve
data modify storage commerce:cp vz140 set from storage commerce:l vz
data modify storage commerce:cp vc140 set from storage commerce:l vc
data modify storage commerce:cp ae140 set from storage commerce:l ae
data modify storage commerce:cp az140 set from storage commerce:l az
data modify storage commerce:cp ac140 set from storage commerce:l ac
data modify storage commerce:cp t140 set from storage commerce:l t
scoreboard players set #i c.t 150
function commerce:page/ligne
data modify storage commerce:cp ve150 set from storage commerce:l ve
data modify storage commerce:cp vz150 set from storage commerce:l vz
data modify storage commerce:cp vc150 set from storage commerce:l vc
data modify storage commerce:cp ae150 set from storage commerce:l ae
data modify storage commerce:cp az150 set from storage commerce:l az
data modify storage commerce:cp ac150 set from storage commerce:l ac
data modify storage commerce:cp t150 set from storage commerce:l t
function commerce:page/lettre_t_0_d with storage commerce:cp
