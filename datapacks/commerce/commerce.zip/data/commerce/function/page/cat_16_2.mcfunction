function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 419
function commerce:page/ligne
data modify storage commerce:cp ve419 set from storage commerce:l ve
data modify storage commerce:cp vz419 set from storage commerce:l vz
data modify storage commerce:cp vc419 set from storage commerce:l vc
data modify storage commerce:cp ae419 set from storage commerce:l ae
data modify storage commerce:cp az419 set from storage commerce:l az
data modify storage commerce:cp ac419 set from storage commerce:l ac
data modify storage commerce:cp t419 set from storage commerce:l t
scoreboard players set #i c.t 420
function commerce:page/ligne
data modify storage commerce:cp ve420 set from storage commerce:l ve
data modify storage commerce:cp vz420 set from storage commerce:l vz
data modify storage commerce:cp vc420 set from storage commerce:l vc
data modify storage commerce:cp ae420 set from storage commerce:l ae
data modify storage commerce:cp az420 set from storage commerce:l az
data modify storage commerce:cp ac420 set from storage commerce:l ac
data modify storage commerce:cp t420 set from storage commerce:l t
scoreboard players set #i c.t 421
function commerce:page/ligne
data modify storage commerce:cp ve421 set from storage commerce:l ve
data modify storage commerce:cp vz421 set from storage commerce:l vz
data modify storage commerce:cp vc421 set from storage commerce:l vc
data modify storage commerce:cp ae421 set from storage commerce:l ae
data modify storage commerce:cp az421 set from storage commerce:l az
data modify storage commerce:cp ac421 set from storage commerce:l ac
data modify storage commerce:cp t421 set from storage commerce:l t
scoreboard players set #i c.t 422
function commerce:page/ligne
data modify storage commerce:cp ve422 set from storage commerce:l ve
data modify storage commerce:cp vz422 set from storage commerce:l vz
data modify storage commerce:cp vc422 set from storage commerce:l vc
data modify storage commerce:cp ae422 set from storage commerce:l ae
data modify storage commerce:cp az422 set from storage commerce:l az
data modify storage commerce:cp ac422 set from storage commerce:l ac
data modify storage commerce:cp t422 set from storage commerce:l t
scoreboard players set #i c.t 423
function commerce:page/ligne
data modify storage commerce:cp ve423 set from storage commerce:l ve
data modify storage commerce:cp vz423 set from storage commerce:l vz
data modify storage commerce:cp vc423 set from storage commerce:l vc
data modify storage commerce:cp ae423 set from storage commerce:l ae
data modify storage commerce:cp az423 set from storage commerce:l az
data modify storage commerce:cp ac423 set from storage commerce:l ac
data modify storage commerce:cp t423 set from storage commerce:l t
scoreboard players set #i c.t 424
function commerce:page/ligne
data modify storage commerce:cp ve424 set from storage commerce:l ve
data modify storage commerce:cp vz424 set from storage commerce:l vz
data modify storage commerce:cp vc424 set from storage commerce:l vc
data modify storage commerce:cp ae424 set from storage commerce:l ae
data modify storage commerce:cp az424 set from storage commerce:l az
data modify storage commerce:cp ac424 set from storage commerce:l ac
data modify storage commerce:cp t424 set from storage commerce:l t
scoreboard players set #i c.t 425
function commerce:page/ligne
data modify storage commerce:cp ve425 set from storage commerce:l ve
data modify storage commerce:cp vz425 set from storage commerce:l vz
data modify storage commerce:cp vc425 set from storage commerce:l vc
data modify storage commerce:cp ae425 set from storage commerce:l ae
data modify storage commerce:cp az425 set from storage commerce:l az
data modify storage commerce:cp ac425 set from storage commerce:l ac
data modify storage commerce:cp t425 set from storage commerce:l t
scoreboard players set #i c.t 426
function commerce:page/ligne
data modify storage commerce:cp ve426 set from storage commerce:l ve
data modify storage commerce:cp vz426 set from storage commerce:l vz
data modify storage commerce:cp vc426 set from storage commerce:l vc
data modify storage commerce:cp ae426 set from storage commerce:l ae
data modify storage commerce:cp az426 set from storage commerce:l az
data modify storage commerce:cp ac426 set from storage commerce:l ac
data modify storage commerce:cp t426 set from storage commerce:l t
scoreboard players set #i c.t 427
function commerce:page/ligne
data modify storage commerce:cp ve427 set from storage commerce:l ve
data modify storage commerce:cp vz427 set from storage commerce:l vz
data modify storage commerce:cp vc427 set from storage commerce:l vc
data modify storage commerce:cp ae427 set from storage commerce:l ae
data modify storage commerce:cp az427 set from storage commerce:l az
data modify storage commerce:cp ac427 set from storage commerce:l ac
data modify storage commerce:cp t427 set from storage commerce:l t
scoreboard players set #i c.t 428
function commerce:page/ligne
data modify storage commerce:cp ve428 set from storage commerce:l ve
data modify storage commerce:cp vz428 set from storage commerce:l vz
data modify storage commerce:cp vc428 set from storage commerce:l vc
data modify storage commerce:cp ae428 set from storage commerce:l ae
data modify storage commerce:cp az428 set from storage commerce:l az
data modify storage commerce:cp ac428 set from storage commerce:l ac
data modify storage commerce:cp t428 set from storage commerce:l t
function commerce:page/cat_16_2_d with storage commerce:cp
