function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 250
function commerce:page/ligne
data modify storage commerce:cp ve250 set from storage commerce:l ve
data modify storage commerce:cp vz250 set from storage commerce:l vz
data modify storage commerce:cp vc250 set from storage commerce:l vc
data modify storage commerce:cp ae250 set from storage commerce:l ae
data modify storage commerce:cp az250 set from storage commerce:l az
data modify storage commerce:cp ac250 set from storage commerce:l ac
data modify storage commerce:cp t250 set from storage commerce:l t
scoreboard players set #i c.t 342
function commerce:page/ligne
data modify storage commerce:cp ve342 set from storage commerce:l ve
data modify storage commerce:cp vz342 set from storage commerce:l vz
data modify storage commerce:cp vc342 set from storage commerce:l vc
data modify storage commerce:cp ae342 set from storage commerce:l ae
data modify storage commerce:cp az342 set from storage commerce:l az
data modify storage commerce:cp ac342 set from storage commerce:l ac
data modify storage commerce:cp t342 set from storage commerce:l t
scoreboard players set #i c.t 452
function commerce:page/ligne
data modify storage commerce:cp ve452 set from storage commerce:l ve
data modify storage commerce:cp vz452 set from storage commerce:l vz
data modify storage commerce:cp vc452 set from storage commerce:l vc
data modify storage commerce:cp ae452 set from storage commerce:l ae
data modify storage commerce:cp az452 set from storage commerce:l az
data modify storage commerce:cp ac452 set from storage commerce:l ac
data modify storage commerce:cp t452 set from storage commerce:l t
function commerce:page/lettre_n_0_d with storage commerce:cp
