function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 250
function commerce:page/ligne
data modify storage commerce:cp ve250 set from storage commerce:l ve
data modify storage commerce:cp vz250 set from storage commerce:l vz
data modify storage commerce:cp vc250 set from storage commerce:l vc
data modify storage commerce:cp ae250 set from storage commerce:l ae
data modify storage commerce:cp az250 set from storage commerce:l az
data modify storage commerce:cp ac250 set from storage commerce:l ac
data modify storage commerce:cp t250 set from storage commerce:l t
scoreboard players set #i c.t 342
function commerce:page/ligne
data modify storage commerce:cp ve342 set from storage commerce:l ve
data modify storage commerce:cp vz342 set from storage commerce:l vz
data modify storage commerce:cp vc342 set from storage commerce:l vc
data modify storage commerce:cp ae342 set from storage commerce:l ae
data modify storage commerce:cp az342 set from storage commerce:l az
data modify storage commerce:cp ac342 set from storage commerce:l ac
data modify storage commerce:cp t342 set from storage commerce:l t
scoreboard players set #i c.t 454
function commerce:page/ligne
data modify storage commerce:cp ve454 set from storage commerce:l ve
data modify storage commerce:cp vz454 set from storage commerce:l vz
data modify storage commerce:cp vc454 set from storage commerce:l vc
data modify storage commerce:cp ae454 set from storage commerce:l ae
data modify storage commerce:cp az454 set from storage commerce:l az
data modify storage commerce:cp ac454 set from storage commerce:l ac
data modify storage commerce:cp t454 set from storage commerce:l t
function commerce:page/lettre_n_0_d with storage commerce:cp
