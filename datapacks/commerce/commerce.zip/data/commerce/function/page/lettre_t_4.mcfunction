function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 178
function commerce:page/ligne
data modify storage commerce:cp ve178 set from storage commerce:l ve
data modify storage commerce:cp vz178 set from storage commerce:l vz
data modify storage commerce:cp vc178 set from storage commerce:l vc
data modify storage commerce:cp ae178 set from storage commerce:l ae
data modify storage commerce:cp az178 set from storage commerce:l az
data modify storage commerce:cp ac178 set from storage commerce:l ac
data modify storage commerce:cp t178 set from storage commerce:l t
scoreboard players set #i c.t 175
function commerce:page/ligne
data modify storage commerce:cp ve175 set from storage commerce:l ve
data modify storage commerce:cp vz175 set from storage commerce:l vz
data modify storage commerce:cp vc175 set from storage commerce:l vc
data modify storage commerce:cp ae175 set from storage commerce:l ae
data modify storage commerce:cp az175 set from storage commerce:l az
data modify storage commerce:cp ac175 set from storage commerce:l ac
data modify storage commerce:cp t175 set from storage commerce:l t
scoreboard players set #i c.t 173
function commerce:page/ligne
data modify storage commerce:cp ve173 set from storage commerce:l ve
data modify storage commerce:cp vz173 set from storage commerce:l vz
data modify storage commerce:cp vc173 set from storage commerce:l vc
data modify storage commerce:cp ae173 set from storage commerce:l ae
data modify storage commerce:cp az173 set from storage commerce:l az
data modify storage commerce:cp ac173 set from storage commerce:l ac
data modify storage commerce:cp t173 set from storage commerce:l t
scoreboard players set #i c.t 183
function commerce:page/ligne
data modify storage commerce:cp ve183 set from storage commerce:l ve
data modify storage commerce:cp vz183 set from storage commerce:l vz
data modify storage commerce:cp vc183 set from storage commerce:l vc
data modify storage commerce:cp ae183 set from storage commerce:l ae
data modify storage commerce:cp az183 set from storage commerce:l az
data modify storage commerce:cp ac183 set from storage commerce:l ac
data modify storage commerce:cp t183 set from storage commerce:l t
scoreboard players set #i c.t 186
function commerce:page/ligne
data modify storage commerce:cp ve186 set from storage commerce:l ve
data modify storage commerce:cp vz186 set from storage commerce:l vz
data modify storage commerce:cp vc186 set from storage commerce:l vc
data modify storage commerce:cp ae186 set from storage commerce:l ae
data modify storage commerce:cp az186 set from storage commerce:l az
data modify storage commerce:cp ac186 set from storage commerce:l ac
data modify storage commerce:cp t186 set from storage commerce:l t
scoreboard players set #i c.t 172
function commerce:page/ligne
data modify storage commerce:cp ve172 set from storage commerce:l ve
data modify storage commerce:cp vz172 set from storage commerce:l vz
data modify storage commerce:cp vc172 set from storage commerce:l vc
data modify storage commerce:cp ae172 set from storage commerce:l ae
data modify storage commerce:cp az172 set from storage commerce:l az
data modify storage commerce:cp ac172 set from storage commerce:l ac
data modify storage commerce:cp t172 set from storage commerce:l t
scoreboard players set #i c.t 177
function commerce:page/ligne
data modify storage commerce:cp ve177 set from storage commerce:l ve
data modify storage commerce:cp vz177 set from storage commerce:l vz
data modify storage commerce:cp vc177 set from storage commerce:l vc
data modify storage commerce:cp ae177 set from storage commerce:l ae
data modify storage commerce:cp az177 set from storage commerce:l az
data modify storage commerce:cp ac177 set from storage commerce:l ac
data modify storage commerce:cp t177 set from storage commerce:l t
scoreboard players set #i c.t 185
function commerce:page/ligne
data modify storage commerce:cp ve185 set from storage commerce:l ve
data modify storage commerce:cp vz185 set from storage commerce:l vz
data modify storage commerce:cp vc185 set from storage commerce:l vc
data modify storage commerce:cp ae185 set from storage commerce:l ae
data modify storage commerce:cp az185 set from storage commerce:l az
data modify storage commerce:cp ac185 set from storage commerce:l ac
data modify storage commerce:cp t185 set from storage commerce:l t
scoreboard players set #i c.t 176
function commerce:page/ligne
data modify storage commerce:cp ve176 set from storage commerce:l ve
data modify storage commerce:cp vz176 set from storage commerce:l vz
data modify storage commerce:cp vc176 set from storage commerce:l vc
data modify storage commerce:cp ae176 set from storage commerce:l ae
data modify storage commerce:cp az176 set from storage commerce:l az
data modify storage commerce:cp ac176 set from storage commerce:l ac
data modify storage commerce:cp t176 set from storage commerce:l t
scoreboard players set #i c.t 184
function commerce:page/ligne
data modify storage commerce:cp ve184 set from storage commerce:l ve
data modify storage commerce:cp vz184 set from storage commerce:l vz
data modify storage commerce:cp vc184 set from storage commerce:l vc
data modify storage commerce:cp ae184 set from storage commerce:l ae
data modify storage commerce:cp az184 set from storage commerce:l az
data modify storage commerce:cp ac184 set from storage commerce:l ac
data modify storage commerce:cp t184 set from storage commerce:l t
function commerce:page/lettre_t_4_d with storage commerce:cp
