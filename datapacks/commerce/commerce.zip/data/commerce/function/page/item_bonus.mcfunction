execute store result storage commerce:t f.e int 1 run scoreboard players get #x c.t
function commerce:page/item_bonus_m with storage commerce:t f
