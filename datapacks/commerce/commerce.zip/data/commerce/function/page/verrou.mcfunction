function commerce:fmt/solde
data modify storage commerce:v se set from storage commerce:t s.e
data modify storage commerce:v sz set from storage commerce:t s.z
data modify storage commerce:v sc set from storage commerce:t s.c
function commerce:page/verrou_d with storage commerce:v
