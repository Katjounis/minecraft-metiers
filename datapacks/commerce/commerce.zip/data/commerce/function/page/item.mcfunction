function commerce:item/charger
data modify storage commerce:t ip set from storage commerce:t it
execute store result score #have c.t run function commerce:op/compter with storage commerce:t it
execute store result storage commerce:t ip.have int 1 run scoreboard players get #have c.t
scoreboard players set #q c.t 1
scoreboard players operation #d c.t = #q c.t
scoreboard players operation #d c.t *= #1000 c.g
scoreboard players operation #d c.t /= #V c.t
function commerce:prix/mid
function commerce:prix/bonus
function commerce:prix/vente
scoreboard players operation #x c.t = #u c.t
scoreboard players operation #x c.t *= #q c.t
function commerce:fmt/centi
data modify storage commerce:t ip.s1e set from storage commerce:t f.e
data modify storage commerce:t ip.s1z set from storage commerce:t f.z
data modify storage commerce:t ip.s1c set from storage commerce:t f.c
scoreboard players operation #d c.t = #q c.t
scoreboard players operation #d c.t *= #500 c.g
scoreboard players operation #d c.t /= #V c.t
scoreboard players operation #d c.t *= #-1 c.g
function commerce:prix/mid
function commerce:prix/sans_bonus
function commerce:prix/vente
scoreboard players operation #x c.t = #a c.t
scoreboard players operation #x c.t *= #q c.t
scoreboard players add #x c.t 99
scoreboard players operation #x c.t /= #100 c.g
execute store result storage commerce:t ip.b1 int 1 run scoreboard players get #x c.t
scoreboard players set #q c.t 16
scoreboard players operation #d c.t = #q c.t
scoreboard players operation #d c.t *= #1000 c.g
scoreboard players operation #d c.t /= #V c.t
function commerce:prix/mid
function commerce:prix/bonus
function commerce:prix/vente
scoreboard players operation #x c.t = #u c.t
scoreboard players operation #x c.t *= #q c.t
function commerce:fmt/centi
data modify storage commerce:t ip.s16e set from storage commerce:t f.e
data modify storage commerce:t ip.s16z set from storage commerce:t f.z
data modify storage commerce:t ip.s16c set from storage commerce:t f.c
scoreboard players operation #d c.t = #q c.t
scoreboard players operation #d c.t *= #500 c.g
scoreboard players operation #d c.t /= #V c.t
scoreboard players operation #d c.t *= #-1 c.g
function commerce:prix/mid
function commerce:prix/sans_bonus
function commerce:prix/vente
scoreboard players operation #x c.t = #a c.t
scoreboard players operation #x c.t *= #q c.t
scoreboard players add #x c.t 99
scoreboard players operation #x c.t /= #100 c.g
execute store result storage commerce:t ip.b16 int 1 run scoreboard players get #x c.t
scoreboard players set #q c.t 64
scoreboard players operation #d c.t = #q c.t
scoreboard players operation #d c.t *= #1000 c.g
scoreboard players operation #d c.t /= #V c.t
function commerce:prix/mid
function commerce:prix/bonus
function commerce:prix/vente
scoreboard players operation #x c.t = #u c.t
scoreboard players operation #x c.t *= #q c.t
function commerce:fmt/centi
data modify storage commerce:t ip.s64e set from storage commerce:t f.e
data modify storage commerce:t ip.s64z set from storage commerce:t f.z
data modify storage commerce:t ip.s64c set from storage commerce:t f.c
scoreboard players operation #d c.t = #q c.t
scoreboard players operation #d c.t *= #500 c.g
scoreboard players operation #d c.t /= #V c.t
scoreboard players operation #d c.t *= #-1 c.g
function commerce:prix/mid
function commerce:prix/sans_bonus
function commerce:prix/vente
scoreboard players operation #x c.t = #a c.t
scoreboard players operation #x c.t *= #q c.t
scoreboard players add #x c.t 99
scoreboard players operation #x c.t /= #100 c.g
execute store result storage commerce:t ip.b64 int 1 run scoreboard players get #x c.t
scoreboard players operation #q c.t = #have c.t
execute if score #q c.t matches 641.. run scoreboard players set #q c.t 640
scoreboard players operation #d c.t = #q c.t
scoreboard players operation #d c.t *= #1000 c.g
scoreboard players operation #d c.t /= #V c.t
function commerce:prix/mid
function commerce:prix/bonus
function commerce:prix/vente
scoreboard players operation #x c.t = #u c.t
scoreboard players operation #x c.t *= #q c.t
function commerce:fmt/centi
data modify storage commerce:t ip.stoute set from storage commerce:t f.e
data modify storage commerce:t ip.stoutz set from storage commerce:t f.z
data modify storage commerce:t ip.stoutc set from storage commerce:t f.c
scoreboard players set #d c.t 0
function commerce:prix/mid
function commerce:prix/bonus
function commerce:prix/vente
scoreboard players operation #x c.t = #u c.t
function commerce:fmt/centi
data modify storage commerce:t ip.ve set from storage commerce:t f.e
data modify storage commerce:t ip.vz set from storage commerce:t f.z
data modify storage commerce:t ip.vc set from storage commerce:t f.c
scoreboard players operation #x c.t = #a c.t
function commerce:fmt/centi
data modify storage commerce:t ip.ae set from storage commerce:t f.e
data modify storage commerce:t ip.az set from storage commerce:t f.z
data modify storage commerce:t ip.ac set from storage commerce:t f.c
scoreboard players operation #x c.t = #bon c.t
scoreboard players remove #x c.t 1000
scoreboard players operation #x c.t /= #10 c.g
data modify storage commerce:t ip.bp set value ""
execute if score #x c.t matches 1.. run function commerce:page/item_bonus
function commerce:fmt/tendance
data modify storage commerce:t ip.tr set from storage commerce:t tr
data modify storage commerce:t ip.trc set from storage commerce:t trc
function commerce:hist/charger with storage commerce:t it
function commerce:hist/courbe
data modify storage commerce:t ip.sp set from storage commerce:t SP
data modify storage commerce:t ip.var set from storage commerce:t VAR
data modify storage commerce:t ip.varc set from storage commerce:t VARC
data modify storage commerce:t ip.ev set value ""
execute if score #e c.t matches 1001.. run data modify storage commerce:t ip.ev set value "   ·   pénurie : x1,6"
execute if score #e c.t matches ..999 run data modify storage commerce:t ip.ev set value "   ·   krach : /2"
data modify storage commerce:t ip.msg set from storage commerce:t msg
data modify storage commerce:t msg set value ""
execute if score #rare c.t matches 1 run return run function commerce:page/item_v with storage commerce:t ip
function commerce:page/item_a with storage commerce:t ip
