function commerce:item/charger
scoreboard players set #d c.t 0
function commerce:prix/mid
function commerce:prix/bonus
function commerce:prix/vente
data modify storage commerce:t ip set from storage commerce:t it
scoreboard players operation #x c.t = #u c.t
function commerce:fmt/centi
data modify storage commerce:t ip.ve set from storage commerce:t f.e
data modify storage commerce:t ip.vz set from storage commerce:t f.z
data modify storage commerce:t ip.vc set from storage commerce:t f.c
scoreboard players operation #x c.t = #a c.t
function commerce:fmt/centi
data modify storage commerce:t ip.ae set from storage commerce:t f.e
data modify storage commerce:t ip.az set from storage commerce:t f.z
data modify storage commerce:t ip.ac set from storage commerce:t f.c
scoreboard players operation #x c.t = #bon c.t
scoreboard players remove #x c.t 1000
scoreboard players operation #x c.t /= #10 c.g
data modify storage commerce:t ip.bp set value ""
execute if score #x c.t matches 1.. run function commerce:page/item_bonus
function commerce:fmt/tendance
data modify storage commerce:t ip.tr set from storage commerce:t tr
data modify storage commerce:t ip.trc set from storage commerce:t trc
execute store result storage commerce:t ip.have int 1 run function commerce:op/compter with storage commerce:t it
execute store result storage commerce:t ip.vs int 1 run scoreboard players get #vs c.t
execute store result storage commerce:t ip.as int 1 run scoreboard players get #as c.t
scoreboard players set #x c.t 700
scoreboard players operation #x c.t -= #p c.t
scoreboard players operation #x c.t /= #100 c.g
execute if score #x c.t matches 0 run data modify storage commerce:t ip.bar set value ""
execute if score #x c.t matches 1 run data modify storage commerce:t ip.bar set value ""
execute if score #x c.t matches 2 run data modify storage commerce:t ip.bar set value ""
execute if score #x c.t matches 3 run data modify storage commerce:t ip.bar set value ""
execute if score #x c.t matches 4 run data modify storage commerce:t ip.bar set value ""
execute if score #x c.t matches 5 run data modify storage commerce:t ip.bar set value ""
execute if score #x c.t matches 6 run data modify storage commerce:t ip.bar set value ""
execute if score #x c.t matches 7 run data modify storage commerce:t ip.bar set value ""
execute if score #x c.t matches 8 run data modify storage commerce:t ip.bar set value ""
execute if score #x c.t matches 9 run data modify storage commerce:t ip.bar set value ""
execute if score #x c.t matches 10 run data modify storage commerce:t ip.bar set value ""
data modify storage commerce:t ip.ev set value ""
execute if score #e c.t matches 1001.. run data modify storage commerce:t ip.ev set value "\nPénurie en cours : prix de vente x1,6."
execute if score #e c.t matches ..999 run data modify storage commerce:t ip.ev set value "\nKrach en cours : prix divisé par deux."
data modify storage commerce:t ip.q set value "$(q)"
data modify storage commerce:t ip.msg set from storage commerce:t msg
data modify storage commerce:t msg set value ""
execute if score #rare c.t matches 1 run return run function commerce:page/item_v with storage commerce:t ip
function commerce:page/item_a with storage commerce:t ip
