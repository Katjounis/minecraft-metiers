function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 174
function commerce:page/ligne
data modify storage commerce:cp ve174 set from storage commerce:l ve
data modify storage commerce:cp vz174 set from storage commerce:l vz
data modify storage commerce:cp vc174 set from storage commerce:l vc
data modify storage commerce:cp ae174 set from storage commerce:l ae
data modify storage commerce:cp az174 set from storage commerce:l az
data modify storage commerce:cp ac174 set from storage commerce:l ac
data modify storage commerce:cp t174 set from storage commerce:l t
scoreboard players set #i c.t 175
function commerce:page/ligne
data modify storage commerce:cp ve175 set from storage commerce:l ve
data modify storage commerce:cp vz175 set from storage commerce:l vz
data modify storage commerce:cp vc175 set from storage commerce:l vc
data modify storage commerce:cp ae175 set from storage commerce:l ae
data modify storage commerce:cp az175 set from storage commerce:l az
data modify storage commerce:cp ac175 set from storage commerce:l ac
data modify storage commerce:cp t175 set from storage commerce:l t
scoreboard players set #i c.t 176
function commerce:page/ligne
data modify storage commerce:cp ve176 set from storage commerce:l ve
data modify storage commerce:cp vz176 set from storage commerce:l vz
data modify storage commerce:cp vc176 set from storage commerce:l vc
data modify storage commerce:cp ae176 set from storage commerce:l ae
data modify storage commerce:cp az176 set from storage commerce:l az
data modify storage commerce:cp ac176 set from storage commerce:l ac
data modify storage commerce:cp t176 set from storage commerce:l t
scoreboard players set #i c.t 177
function commerce:page/ligne
data modify storage commerce:cp ve177 set from storage commerce:l ve
data modify storage commerce:cp vz177 set from storage commerce:l vz
data modify storage commerce:cp vc177 set from storage commerce:l vc
data modify storage commerce:cp ae177 set from storage commerce:l ae
data modify storage commerce:cp az177 set from storage commerce:l az
data modify storage commerce:cp ac177 set from storage commerce:l ac
data modify storage commerce:cp t177 set from storage commerce:l t
scoreboard players set #i c.t 178
function commerce:page/ligne
data modify storage commerce:cp ve178 set from storage commerce:l ve
data modify storage commerce:cp vz178 set from storage commerce:l vz
data modify storage commerce:cp vc178 set from storage commerce:l vc
data modify storage commerce:cp ae178 set from storage commerce:l ae
data modify storage commerce:cp az178 set from storage commerce:l az
data modify storage commerce:cp ac178 set from storage commerce:l ac
data modify storage commerce:cp t178 set from storage commerce:l t
scoreboard players set #i c.t 179
function commerce:page/ligne
data modify storage commerce:cp ve179 set from storage commerce:l ve
data modify storage commerce:cp vz179 set from storage commerce:l vz
data modify storage commerce:cp vc179 set from storage commerce:l vc
data modify storage commerce:cp ae179 set from storage commerce:l ae
data modify storage commerce:cp az179 set from storage commerce:l az
data modify storage commerce:cp ac179 set from storage commerce:l ac
data modify storage commerce:cp t179 set from storage commerce:l t
scoreboard players set #i c.t 180
function commerce:page/ligne
data modify storage commerce:cp ve180 set from storage commerce:l ve
data modify storage commerce:cp vz180 set from storage commerce:l vz
data modify storage commerce:cp vc180 set from storage commerce:l vc
data modify storage commerce:cp ae180 set from storage commerce:l ae
data modify storage commerce:cp az180 set from storage commerce:l az
data modify storage commerce:cp ac180 set from storage commerce:l ac
data modify storage commerce:cp t180 set from storage commerce:l t
scoreboard players set #i c.t 181
function commerce:page/ligne
data modify storage commerce:cp ve181 set from storage commerce:l ve
data modify storage commerce:cp vz181 set from storage commerce:l vz
data modify storage commerce:cp vc181 set from storage commerce:l vc
data modify storage commerce:cp ae181 set from storage commerce:l ae
data modify storage commerce:cp az181 set from storage commerce:l az
data modify storage commerce:cp ac181 set from storage commerce:l ac
data modify storage commerce:cp t181 set from storage commerce:l t
scoreboard players set #i c.t 182
function commerce:page/ligne
data modify storage commerce:cp ve182 set from storage commerce:l ve
data modify storage commerce:cp vz182 set from storage commerce:l vz
data modify storage commerce:cp vc182 set from storage commerce:l vc
data modify storage commerce:cp ae182 set from storage commerce:l ae
data modify storage commerce:cp az182 set from storage commerce:l az
data modify storage commerce:cp ac182 set from storage commerce:l ac
data modify storage commerce:cp t182 set from storage commerce:l t
scoreboard players set #i c.t 183
function commerce:page/ligne
data modify storage commerce:cp ve183 set from storage commerce:l ve
data modify storage commerce:cp vz183 set from storage commerce:l vz
data modify storage commerce:cp vc183 set from storage commerce:l vc
data modify storage commerce:cp ae183 set from storage commerce:l ae
data modify storage commerce:cp az183 set from storage commerce:l az
data modify storage commerce:cp ac183 set from storage commerce:l ac
data modify storage commerce:cp t183 set from storage commerce:l t
function commerce:page/cat_6_2_d with storage commerce:cp
