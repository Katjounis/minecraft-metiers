function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 98
function commerce:page/ligne
data modify storage commerce:cp ve98 set from storage commerce:l ve
data modify storage commerce:cp vz98 set from storage commerce:l vz
data modify storage commerce:cp vc98 set from storage commerce:l vc
data modify storage commerce:cp ae98 set from storage commerce:l ae
data modify storage commerce:cp az98 set from storage commerce:l az
data modify storage commerce:cp ac98 set from storage commerce:l ac
data modify storage commerce:cp t98 set from storage commerce:l t
scoreboard players set #i c.t 99
function commerce:page/ligne
data modify storage commerce:cp ve99 set from storage commerce:l ve
data modify storage commerce:cp vz99 set from storage commerce:l vz
data modify storage commerce:cp vc99 set from storage commerce:l vc
data modify storage commerce:cp ae99 set from storage commerce:l ae
data modify storage commerce:cp az99 set from storage commerce:l az
data modify storage commerce:cp ac99 set from storage commerce:l ac
data modify storage commerce:cp t99 set from storage commerce:l t
scoreboard players set #i c.t 100
function commerce:page/ligne
data modify storage commerce:cp ve100 set from storage commerce:l ve
data modify storage commerce:cp vz100 set from storage commerce:l vz
data modify storage commerce:cp vc100 set from storage commerce:l vc
data modify storage commerce:cp ae100 set from storage commerce:l ae
data modify storage commerce:cp az100 set from storage commerce:l az
data modify storage commerce:cp ac100 set from storage commerce:l ac
data modify storage commerce:cp t100 set from storage commerce:l t
scoreboard players set #i c.t 101
function commerce:page/ligne
data modify storage commerce:cp ve101 set from storage commerce:l ve
data modify storage commerce:cp vz101 set from storage commerce:l vz
data modify storage commerce:cp vc101 set from storage commerce:l vc
data modify storage commerce:cp ae101 set from storage commerce:l ae
data modify storage commerce:cp az101 set from storage commerce:l az
data modify storage commerce:cp ac101 set from storage commerce:l ac
data modify storage commerce:cp t101 set from storage commerce:l t
scoreboard players set #i c.t 102
function commerce:page/ligne
data modify storage commerce:cp ve102 set from storage commerce:l ve
data modify storage commerce:cp vz102 set from storage commerce:l vz
data modify storage commerce:cp vc102 set from storage commerce:l vc
data modify storage commerce:cp ae102 set from storage commerce:l ae
data modify storage commerce:cp az102 set from storage commerce:l az
data modify storage commerce:cp ac102 set from storage commerce:l ac
data modify storage commerce:cp t102 set from storage commerce:l t
scoreboard players set #i c.t 103
function commerce:page/ligne
data modify storage commerce:cp ve103 set from storage commerce:l ve
data modify storage commerce:cp vz103 set from storage commerce:l vz
data modify storage commerce:cp vc103 set from storage commerce:l vc
data modify storage commerce:cp ae103 set from storage commerce:l ae
data modify storage commerce:cp az103 set from storage commerce:l az
data modify storage commerce:cp ac103 set from storage commerce:l ac
data modify storage commerce:cp t103 set from storage commerce:l t
scoreboard players set #i c.t 104
function commerce:page/ligne
data modify storage commerce:cp ve104 set from storage commerce:l ve
data modify storage commerce:cp vz104 set from storage commerce:l vz
data modify storage commerce:cp vc104 set from storage commerce:l vc
data modify storage commerce:cp ae104 set from storage commerce:l ae
data modify storage commerce:cp az104 set from storage commerce:l az
data modify storage commerce:cp ac104 set from storage commerce:l ac
data modify storage commerce:cp t104 set from storage commerce:l t
scoreboard players set #i c.t 105
function commerce:page/ligne
data modify storage commerce:cp ve105 set from storage commerce:l ve
data modify storage commerce:cp vz105 set from storage commerce:l vz
data modify storage commerce:cp vc105 set from storage commerce:l vc
data modify storage commerce:cp ae105 set from storage commerce:l ae
data modify storage commerce:cp az105 set from storage commerce:l az
data modify storage commerce:cp ac105 set from storage commerce:l ac
data modify storage commerce:cp t105 set from storage commerce:l t
scoreboard players set #i c.t 106
function commerce:page/ligne
data modify storage commerce:cp ve106 set from storage commerce:l ve
data modify storage commerce:cp vz106 set from storage commerce:l vz
data modify storage commerce:cp vc106 set from storage commerce:l vc
data modify storage commerce:cp ae106 set from storage commerce:l ae
data modify storage commerce:cp az106 set from storage commerce:l az
data modify storage commerce:cp ac106 set from storage commerce:l ac
data modify storage commerce:cp t106 set from storage commerce:l t
scoreboard players set #i c.t 107
function commerce:page/ligne
data modify storage commerce:cp ve107 set from storage commerce:l ve
data modify storage commerce:cp vz107 set from storage commerce:l vz
data modify storage commerce:cp vc107 set from storage commerce:l vc
data modify storage commerce:cp ae107 set from storage commerce:l ae
data modify storage commerce:cp az107 set from storage commerce:l az
data modify storage commerce:cp ac107 set from storage commerce:l ac
data modify storage commerce:cp t107 set from storage commerce:l t
function commerce:page/cat_4_1_d with storage commerce:cp
