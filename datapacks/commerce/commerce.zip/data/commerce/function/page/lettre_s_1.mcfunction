function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 428
function commerce:page/ligne
data modify storage commerce:cp ve428 set from storage commerce:l ve
data modify storage commerce:cp vz428 set from storage commerce:l vz
data modify storage commerce:cp vc428 set from storage commerce:l vc
data modify storage commerce:cp ae428 set from storage commerce:l ae
data modify storage commerce:cp az428 set from storage commerce:l az
data modify storage commerce:cp ac428 set from storage commerce:l ac
data modify storage commerce:cp t428 set from storage commerce:l t
scoreboard players set #i c.t 353
function commerce:page/ligne
data modify storage commerce:cp ve353 set from storage commerce:l ve
data modify storage commerce:cp vz353 set from storage commerce:l vz
data modify storage commerce:cp vc353 set from storage commerce:l vc
data modify storage commerce:cp ae353 set from storage commerce:l ae
data modify storage commerce:cp az353 set from storage commerce:l az
data modify storage commerce:cp ac353 set from storage commerce:l ac
data modify storage commerce:cp t353 set from storage commerce:l t
scoreboard players set #i c.t 294
function commerce:page/ligne
data modify storage commerce:cp ve294 set from storage commerce:l ve
data modify storage commerce:cp vz294 set from storage commerce:l vz
data modify storage commerce:cp vc294 set from storage commerce:l vc
data modify storage commerce:cp ae294 set from storage commerce:l ae
data modify storage commerce:cp az294 set from storage commerce:l az
data modify storage commerce:cp ac294 set from storage commerce:l ac
data modify storage commerce:cp t294 set from storage commerce:l t
function commerce:page/lettre_s_1_d with storage commerce:cp
