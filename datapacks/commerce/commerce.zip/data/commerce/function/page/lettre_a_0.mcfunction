function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 343
function commerce:page/ligne
data modify storage commerce:cp ve343 set from storage commerce:l ve
data modify storage commerce:cp vz343 set from storage commerce:l vz
data modify storage commerce:cp vc343 set from storage commerce:l vc
data modify storage commerce:cp ae343 set from storage commerce:l ae
data modify storage commerce:cp az343 set from storage commerce:l az
data modify storage commerce:cp ac343 set from storage commerce:l ac
data modify storage commerce:cp t343 set from storage commerce:l t
scoreboard players set #i c.t 344
function commerce:page/ligne
data modify storage commerce:cp ve344 set from storage commerce:l ve
data modify storage commerce:cp vz344 set from storage commerce:l vz
data modify storage commerce:cp vc344 set from storage commerce:l vc
data modify storage commerce:cp ae344 set from storage commerce:l ae
data modify storage commerce:cp az344 set from storage commerce:l az
data modify storage commerce:cp ac344 set from storage commerce:l ac
data modify storage commerce:cp t344 set from storage commerce:l t
scoreboard players set #i c.t 404
function commerce:page/ligne
data modify storage commerce:cp ve404 set from storage commerce:l ve
data modify storage commerce:cp vz404 set from storage commerce:l vz
data modify storage commerce:cp vc404 set from storage commerce:l vc
data modify storage commerce:cp ae404 set from storage commerce:l ae
data modify storage commerce:cp az404 set from storage commerce:l az
data modify storage commerce:cp ac404 set from storage commerce:l ac
data modify storage commerce:cp t404 set from storage commerce:l t
scoreboard players set #i c.t 13
function commerce:page/ligne
data modify storage commerce:cp ve13 set from storage commerce:l ve
data modify storage commerce:cp vz13 set from storage commerce:l vz
data modify storage commerce:cp vc13 set from storage commerce:l vc
data modify storage commerce:cp ae13 set from storage commerce:l ae
data modify storage commerce:cp az13 set from storage commerce:l az
data modify storage commerce:cp ac13 set from storage commerce:l ac
data modify storage commerce:cp t13 set from storage commerce:l t
scoreboard players set #i c.t 14
function commerce:page/ligne
data modify storage commerce:cp ve14 set from storage commerce:l ve
data modify storage commerce:cp vz14 set from storage commerce:l vz
data modify storage commerce:cp vc14 set from storage commerce:l vc
data modify storage commerce:cp ae14 set from storage commerce:l ae
data modify storage commerce:cp az14 set from storage commerce:l az
data modify storage commerce:cp ac14 set from storage commerce:l ac
data modify storage commerce:cp t14 set from storage commerce:l t
scoreboard players set #i c.t 467
function commerce:page/ligne
data modify storage commerce:cp ve467 set from storage commerce:l ve
data modify storage commerce:cp vz467 set from storage commerce:l vz
data modify storage commerce:cp vc467 set from storage commerce:l vc
data modify storage commerce:cp ae467 set from storage commerce:l ae
data modify storage commerce:cp az467 set from storage commerce:l az
data modify storage commerce:cp ac467 set from storage commerce:l ac
data modify storage commerce:cp t467 set from storage commerce:l t
scoreboard players set #i c.t 393
function commerce:page/ligne
data modify storage commerce:cp ve393 set from storage commerce:l ve
data modify storage commerce:cp vz393 set from storage commerce:l vz
data modify storage commerce:cp vc393 set from storage commerce:l vc
data modify storage commerce:cp ae393 set from storage commerce:l ae
data modify storage commerce:cp az393 set from storage commerce:l az
data modify storage commerce:cp ac393 set from storage commerce:l ac
data modify storage commerce:cp t393 set from storage commerce:l t
scoreboard players set #i c.t 15
function commerce:page/ligne
data modify storage commerce:cp ve15 set from storage commerce:l ve
data modify storage commerce:cp vz15 set from storage commerce:l vz
data modify storage commerce:cp vc15 set from storage commerce:l vc
data modify storage commerce:cp ae15 set from storage commerce:l ae
data modify storage commerce:cp az15 set from storage commerce:l az
data modify storage commerce:cp ac15 set from storage commerce:l ac
data modify storage commerce:cp t15 set from storage commerce:l t
scoreboard players set #i c.t 17
function commerce:page/ligne
data modify storage commerce:cp ve17 set from storage commerce:l ve
data modify storage commerce:cp vz17 set from storage commerce:l vz
data modify storage commerce:cp vc17 set from storage commerce:l vc
data modify storage commerce:cp ae17 set from storage commerce:l ae
data modify storage commerce:cp az17 set from storage commerce:l az
data modify storage commerce:cp ac17 set from storage commerce:l ac
data modify storage commerce:cp t17 set from storage commerce:l t
scoreboard players set #i c.t 20
function commerce:page/ligne
data modify storage commerce:cp ve20 set from storage commerce:l ve
data modify storage commerce:cp vz20 set from storage commerce:l vz
data modify storage commerce:cp vc20 set from storage commerce:l vc
data modify storage commerce:cp ae20 set from storage commerce:l ae
data modify storage commerce:cp az20 set from storage commerce:l az
data modify storage commerce:cp ac20 set from storage commerce:l ac
data modify storage commerce:cp t20 set from storage commerce:l t
function commerce:page/lettre_a_0_d with storage commerce:cp
