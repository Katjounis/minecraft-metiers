function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 312
function commerce:page/ligne
data modify storage commerce:cp ve312 set from storage commerce:l ve
data modify storage commerce:cp vz312 set from storage commerce:l vz
data modify storage commerce:cp vc312 set from storage commerce:l vc
data modify storage commerce:cp ae312 set from storage commerce:l ae
data modify storage commerce:cp az312 set from storage commerce:l az
data modify storage commerce:cp ac312 set from storage commerce:l ac
data modify storage commerce:cp t312 set from storage commerce:l t
scoreboard players set #i c.t 313
function commerce:page/ligne
data modify storage commerce:cp ve313 set from storage commerce:l ve
data modify storage commerce:cp vz313 set from storage commerce:l vz
data modify storage commerce:cp vc313 set from storage commerce:l vc
data modify storage commerce:cp ae313 set from storage commerce:l ae
data modify storage commerce:cp az313 set from storage commerce:l az
data modify storage commerce:cp ac313 set from storage commerce:l ac
data modify storage commerce:cp t313 set from storage commerce:l t
scoreboard players set #i c.t 314
function commerce:page/ligne
data modify storage commerce:cp ve314 set from storage commerce:l ve
data modify storage commerce:cp vz314 set from storage commerce:l vz
data modify storage commerce:cp vc314 set from storage commerce:l vc
data modify storage commerce:cp ae314 set from storage commerce:l ae
data modify storage commerce:cp az314 set from storage commerce:l az
data modify storage commerce:cp ac314 set from storage commerce:l ac
data modify storage commerce:cp t314 set from storage commerce:l t
scoreboard players set #i c.t 315
function commerce:page/ligne
data modify storage commerce:cp ve315 set from storage commerce:l ve
data modify storage commerce:cp vz315 set from storage commerce:l vz
data modify storage commerce:cp vc315 set from storage commerce:l vc
data modify storage commerce:cp ae315 set from storage commerce:l ae
data modify storage commerce:cp az315 set from storage commerce:l az
data modify storage commerce:cp ac315 set from storage commerce:l ac
data modify storage commerce:cp t315 set from storage commerce:l t
scoreboard players set #i c.t 316
function commerce:page/ligne
data modify storage commerce:cp ve316 set from storage commerce:l ve
data modify storage commerce:cp vz316 set from storage commerce:l vz
data modify storage commerce:cp vc316 set from storage commerce:l vc
data modify storage commerce:cp ae316 set from storage commerce:l ae
data modify storage commerce:cp az316 set from storage commerce:l az
data modify storage commerce:cp ac316 set from storage commerce:l ac
data modify storage commerce:cp t316 set from storage commerce:l t
scoreboard players set #i c.t 317
function commerce:page/ligne
data modify storage commerce:cp ve317 set from storage commerce:l ve
data modify storage commerce:cp vz317 set from storage commerce:l vz
data modify storage commerce:cp vc317 set from storage commerce:l vc
data modify storage commerce:cp ae317 set from storage commerce:l ae
data modify storage commerce:cp az317 set from storage commerce:l az
data modify storage commerce:cp ac317 set from storage commerce:l ac
data modify storage commerce:cp t317 set from storage commerce:l t
scoreboard players set #i c.t 318
function commerce:page/ligne
data modify storage commerce:cp ve318 set from storage commerce:l ve
data modify storage commerce:cp vz318 set from storage commerce:l vz
data modify storage commerce:cp vc318 set from storage commerce:l vc
data modify storage commerce:cp ae318 set from storage commerce:l ae
data modify storage commerce:cp az318 set from storage commerce:l az
data modify storage commerce:cp ac318 set from storage commerce:l ac
data modify storage commerce:cp t318 set from storage commerce:l t
scoreboard players set #i c.t 319
function commerce:page/ligne
data modify storage commerce:cp ve319 set from storage commerce:l ve
data modify storage commerce:cp vz319 set from storage commerce:l vz
data modify storage commerce:cp vc319 set from storage commerce:l vc
data modify storage commerce:cp ae319 set from storage commerce:l ae
data modify storage commerce:cp az319 set from storage commerce:l az
data modify storage commerce:cp ac319 set from storage commerce:l ac
data modify storage commerce:cp t319 set from storage commerce:l t
scoreboard players set #i c.t 320
function commerce:page/ligne
data modify storage commerce:cp ve320 set from storage commerce:l ve
data modify storage commerce:cp vz320 set from storage commerce:l vz
data modify storage commerce:cp vc320 set from storage commerce:l vc
data modify storage commerce:cp ae320 set from storage commerce:l ae
data modify storage commerce:cp az320 set from storage commerce:l az
data modify storage commerce:cp ac320 set from storage commerce:l ac
data modify storage commerce:cp t320 set from storage commerce:l t
scoreboard players set #i c.t 321
function commerce:page/ligne
data modify storage commerce:cp ve321 set from storage commerce:l ve
data modify storage commerce:cp vz321 set from storage commerce:l vz
data modify storage commerce:cp vc321 set from storage commerce:l vc
data modify storage commerce:cp ae321 set from storage commerce:l ae
data modify storage commerce:cp az321 set from storage commerce:l az
data modify storage commerce:cp ac321 set from storage commerce:l ac
data modify storage commerce:cp t321 set from storage commerce:l t
function commerce:page/cat_11_1_d with storage commerce:cp
