function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 410
function commerce:page/ligne
data modify storage commerce:cp ve410 set from storage commerce:l ve
data modify storage commerce:cp vz410 set from storage commerce:l vz
data modify storage commerce:cp vc410 set from storage commerce:l vc
data modify storage commerce:cp ae410 set from storage commerce:l ae
data modify storage commerce:cp az410 set from storage commerce:l az
data modify storage commerce:cp ac410 set from storage commerce:l ac
data modify storage commerce:cp t410 set from storage commerce:l t
scoreboard players set #i c.t 333
function commerce:page/ligne
data modify storage commerce:cp ve333 set from storage commerce:l ve
data modify storage commerce:cp vz333 set from storage commerce:l vz
data modify storage commerce:cp vc333 set from storage commerce:l vc
data modify storage commerce:cp ae333 set from storage commerce:l ae
data modify storage commerce:cp az333 set from storage commerce:l az
data modify storage commerce:cp ac333 set from storage commerce:l ac
data modify storage commerce:cp t333 set from storage commerce:l t
scoreboard players set #i c.t 334
function commerce:page/ligne
data modify storage commerce:cp ve334 set from storage commerce:l ve
data modify storage commerce:cp vz334 set from storage commerce:l vz
data modify storage commerce:cp vc334 set from storage commerce:l vc
data modify storage commerce:cp ae334 set from storage commerce:l ae
data modify storage commerce:cp az334 set from storage commerce:l az
data modify storage commerce:cp ac334 set from storage commerce:l ac
data modify storage commerce:cp t334 set from storage commerce:l t
scoreboard players set #i c.t 358
function commerce:page/ligne
data modify storage commerce:cp ve358 set from storage commerce:l ve
data modify storage commerce:cp vz358 set from storage commerce:l vz
data modify storage commerce:cp vc358 set from storage commerce:l vc
data modify storage commerce:cp ae358 set from storage commerce:l ae
data modify storage commerce:cp az358 set from storage commerce:l az
data modify storage commerce:cp ac358 set from storage commerce:l ac
data modify storage commerce:cp t358 set from storage commerce:l t
scoreboard players set #i c.t 312
function commerce:page/ligne
data modify storage commerce:cp ve312 set from storage commerce:l ve
data modify storage commerce:cp vz312 set from storage commerce:l vz
data modify storage commerce:cp vc312 set from storage commerce:l vc
data modify storage commerce:cp ae312 set from storage commerce:l ae
data modify storage commerce:cp az312 set from storage commerce:l az
data modify storage commerce:cp ac312 set from storage commerce:l ac
data modify storage commerce:cp t312 set from storage commerce:l t
scoreboard players set #i c.t 356
function commerce:page/ligne
data modify storage commerce:cp ve356 set from storage commerce:l ve
data modify storage commerce:cp vz356 set from storage commerce:l vz
data modify storage commerce:cp vc356 set from storage commerce:l vc
data modify storage commerce:cp ae356 set from storage commerce:l ae
data modify storage commerce:cp az356 set from storage commerce:l az
data modify storage commerce:cp ac356 set from storage commerce:l ac
data modify storage commerce:cp t356 set from storage commerce:l t
scoreboard players set #i c.t 412
function commerce:page/ligne
data modify storage commerce:cp ve412 set from storage commerce:l ve
data modify storage commerce:cp vz412 set from storage commerce:l vz
data modify storage commerce:cp vc412 set from storage commerce:l vc
data modify storage commerce:cp ae412 set from storage commerce:l ae
data modify storage commerce:cp az412 set from storage commerce:l az
data modify storage commerce:cp ac412 set from storage commerce:l ac
data modify storage commerce:cp t412 set from storage commerce:l t
scoreboard players set #i c.t 49
function commerce:page/ligne
data modify storage commerce:cp ve49 set from storage commerce:l ve
data modify storage commerce:cp vz49 set from storage commerce:l vz
data modify storage commerce:cp vc49 set from storage commerce:l vc
data modify storage commerce:cp ae49 set from storage commerce:l ae
data modify storage commerce:cp az49 set from storage commerce:l az
data modify storage commerce:cp ac49 set from storage commerce:l ac
data modify storage commerce:cp t49 set from storage commerce:l t
function commerce:page/lettre_m_0_d with storage commerce:cp
