function commerce:fmt/solde
data modify storage commerce:mk se set from storage commerce:t s.e
data modify storage commerce:mk sz set from storage commerce:t s.z
data modify storage commerce:mk sc set from storage commerce:t s.c
function commerce:page/marche_d with storage commerce:mk
