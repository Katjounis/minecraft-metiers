function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 98
function commerce:page/ligne
data modify storage commerce:cp ve98 set from storage commerce:l ve
data modify storage commerce:cp vz98 set from storage commerce:l vz
data modify storage commerce:cp vc98 set from storage commerce:l vc
data modify storage commerce:cp ae98 set from storage commerce:l ae
data modify storage commerce:cp az98 set from storage commerce:l az
data modify storage commerce:cp ac98 set from storage commerce:l ac
data modify storage commerce:cp t98 set from storage commerce:l t
scoreboard players set #i c.t 296
function commerce:page/ligne
data modify storage commerce:cp ve296 set from storage commerce:l ve
data modify storage commerce:cp vz296 set from storage commerce:l vz
data modify storage commerce:cp vc296 set from storage commerce:l vc
data modify storage commerce:cp ae296 set from storage commerce:l ae
data modify storage commerce:cp az296 set from storage commerce:l az
data modify storage commerce:cp ac296 set from storage commerce:l ac
data modify storage commerce:cp t296 set from storage commerce:l t
scoreboard players set #i c.t 322
function commerce:page/ligne
data modify storage commerce:cp ve322 set from storage commerce:l ve
data modify storage commerce:cp vz322 set from storage commerce:l vz
data modify storage commerce:cp vc322 set from storage commerce:l vc
data modify storage commerce:cp ae322 set from storage commerce:l ae
data modify storage commerce:cp az322 set from storage commerce:l az
data modify storage commerce:cp ac322 set from storage commerce:l ac
data modify storage commerce:cp t322 set from storage commerce:l t
scoreboard players set #i c.t 457
function commerce:page/ligne
data modify storage commerce:cp ve457 set from storage commerce:l ve
data modify storage commerce:cp vz457 set from storage commerce:l vz
data modify storage commerce:cp vc457 set from storage commerce:l vc
data modify storage commerce:cp ae457 set from storage commerce:l ae
data modify storage commerce:cp az457 set from storage commerce:l az
data modify storage commerce:cp ac457 set from storage commerce:l ac
data modify storage commerce:cp t457 set from storage commerce:l t
scoreboard players set #i c.t 315
function commerce:page/ligne
data modify storage commerce:cp ve315 set from storage commerce:l ve
data modify storage commerce:cp vz315 set from storage commerce:l vz
data modify storage commerce:cp vc315 set from storage commerce:l vc
data modify storage commerce:cp ae315 set from storage commerce:l ae
data modify storage commerce:cp az315 set from storage commerce:l az
data modify storage commerce:cp ac315 set from storage commerce:l ac
data modify storage commerce:cp t315 set from storage commerce:l t
scoreboard players set #i c.t 458
function commerce:page/ligne
data modify storage commerce:cp ve458 set from storage commerce:l ve
data modify storage commerce:cp vz458 set from storage commerce:l vz
data modify storage commerce:cp vc458 set from storage commerce:l vc
data modify storage commerce:cp ae458 set from storage commerce:l ae
data modify storage commerce:cp az458 set from storage commerce:l az
data modify storage commerce:cp ac458 set from storage commerce:l ac
data modify storage commerce:cp t458 set from storage commerce:l t
scoreboard players set #i c.t 417
function commerce:page/ligne
data modify storage commerce:cp ve417 set from storage commerce:l ve
data modify storage commerce:cp vz417 set from storage commerce:l vz
data modify storage commerce:cp vc417 set from storage commerce:l vc
data modify storage commerce:cp ae417 set from storage commerce:l ae
data modify storage commerce:cp az417 set from storage commerce:l az
data modify storage commerce:cp ac417 set from storage commerce:l ac
data modify storage commerce:cp t417 set from storage commerce:l t
scoreboard players set #i c.t 416
function commerce:page/ligne
data modify storage commerce:cp ve416 set from storage commerce:l ve
data modify storage commerce:cp vz416 set from storage commerce:l vz
data modify storage commerce:cp vc416 set from storage commerce:l vc
data modify storage commerce:cp ae416 set from storage commerce:l ae
data modify storage commerce:cp az416 set from storage commerce:l az
data modify storage commerce:cp ac416 set from storage commerce:l ac
data modify storage commerce:cp t416 set from storage commerce:l t
scoreboard players set #i c.t 393
function commerce:page/ligne
data modify storage commerce:cp ve393 set from storage commerce:l ve
data modify storage commerce:cp vz393 set from storage commerce:l vz
data modify storage commerce:cp vc393 set from storage commerce:l vc
data modify storage commerce:cp ae393 set from storage commerce:l ae
data modify storage commerce:cp az393 set from storage commerce:l az
data modify storage commerce:cp ac393 set from storage commerce:l ac
data modify storage commerce:cp t393 set from storage commerce:l t
scoreboard players set #i c.t 420
function commerce:page/ligne
data modify storage commerce:cp ve420 set from storage commerce:l ve
data modify storage commerce:cp vz420 set from storage commerce:l vz
data modify storage commerce:cp vc420 set from storage commerce:l vc
data modify storage commerce:cp ae420 set from storage commerce:l ae
data modify storage commerce:cp az420 set from storage commerce:l az
data modify storage commerce:cp ac420 set from storage commerce:l ac
data modify storage commerce:cp t420 set from storage commerce:l t
function commerce:page/lettre_f_1_d with storage commerce:cp
