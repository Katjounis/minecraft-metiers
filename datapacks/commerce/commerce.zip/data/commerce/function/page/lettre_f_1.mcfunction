function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 98
function commerce:page/ligne
data modify storage commerce:cp ve98 set from storage commerce:l ve
data modify storage commerce:cp vz98 set from storage commerce:l vz
data modify storage commerce:cp vc98 set from storage commerce:l vc
data modify storage commerce:cp ae98 set from storage commerce:l ae
data modify storage commerce:cp az98 set from storage commerce:l az
data modify storage commerce:cp ac98 set from storage commerce:l ac
data modify storage commerce:cp t98 set from storage commerce:l t
scoreboard players set #i c.t 296
function commerce:page/ligne
data modify storage commerce:cp ve296 set from storage commerce:l ve
data modify storage commerce:cp vz296 set from storage commerce:l vz
data modify storage commerce:cp vc296 set from storage commerce:l vc
data modify storage commerce:cp ae296 set from storage commerce:l ae
data modify storage commerce:cp az296 set from storage commerce:l az
data modify storage commerce:cp ac296 set from storage commerce:l ac
data modify storage commerce:cp t296 set from storage commerce:l t
scoreboard players set #i c.t 322
function commerce:page/ligne
data modify storage commerce:cp ve322 set from storage commerce:l ve
data modify storage commerce:cp vz322 set from storage commerce:l vz
data modify storage commerce:cp vc322 set from storage commerce:l vc
data modify storage commerce:cp ae322 set from storage commerce:l ae
data modify storage commerce:cp az322 set from storage commerce:l az
data modify storage commerce:cp ac322 set from storage commerce:l ac
data modify storage commerce:cp t322 set from storage commerce:l t
scoreboard players set #i c.t 461
function commerce:page/ligne
data modify storage commerce:cp ve461 set from storage commerce:l ve
data modify storage commerce:cp vz461 set from storage commerce:l vz
data modify storage commerce:cp vc461 set from storage commerce:l vc
data modify storage commerce:cp ae461 set from storage commerce:l ae
data modify storage commerce:cp az461 set from storage commerce:l az
data modify storage commerce:cp ac461 set from storage commerce:l ac
data modify storage commerce:cp t461 set from storage commerce:l t
scoreboard players set #i c.t 315
function commerce:page/ligne
data modify storage commerce:cp ve315 set from storage commerce:l ve
data modify storage commerce:cp vz315 set from storage commerce:l vz
data modify storage commerce:cp vc315 set from storage commerce:l vc
data modify storage commerce:cp ae315 set from storage commerce:l ae
data modify storage commerce:cp az315 set from storage commerce:l az
data modify storage commerce:cp ac315 set from storage commerce:l ac
data modify storage commerce:cp t315 set from storage commerce:l t
scoreboard players set #i c.t 462
function commerce:page/ligne
data modify storage commerce:cp ve462 set from storage commerce:l ve
data modify storage commerce:cp vz462 set from storage commerce:l vz
data modify storage commerce:cp vc462 set from storage commerce:l vc
data modify storage commerce:cp ae462 set from storage commerce:l ae
data modify storage commerce:cp az462 set from storage commerce:l az
data modify storage commerce:cp ac462 set from storage commerce:l ac
data modify storage commerce:cp t462 set from storage commerce:l t
scoreboard players set #i c.t 419
function commerce:page/ligne
data modify storage commerce:cp ve419 set from storage commerce:l ve
data modify storage commerce:cp vz419 set from storage commerce:l vz
data modify storage commerce:cp vc419 set from storage commerce:l vc
data modify storage commerce:cp ae419 set from storage commerce:l ae
data modify storage commerce:cp az419 set from storage commerce:l az
data modify storage commerce:cp ac419 set from storage commerce:l ac
data modify storage commerce:cp t419 set from storage commerce:l t
scoreboard players set #i c.t 418
function commerce:page/ligne
data modify storage commerce:cp ve418 set from storage commerce:l ve
data modify storage commerce:cp vz418 set from storage commerce:l vz
data modify storage commerce:cp vc418 set from storage commerce:l vc
data modify storage commerce:cp ae418 set from storage commerce:l ae
data modify storage commerce:cp az418 set from storage commerce:l az
data modify storage commerce:cp ac418 set from storage commerce:l ac
data modify storage commerce:cp t418 set from storage commerce:l t
scoreboard players set #i c.t 394
function commerce:page/ligne
data modify storage commerce:cp ve394 set from storage commerce:l ve
data modify storage commerce:cp vz394 set from storage commerce:l vz
data modify storage commerce:cp vc394 set from storage commerce:l vc
data modify storage commerce:cp ae394 set from storage commerce:l ae
data modify storage commerce:cp az394 set from storage commerce:l az
data modify storage commerce:cp ac394 set from storage commerce:l ac
data modify storage commerce:cp t394 set from storage commerce:l t
scoreboard players set #i c.t 422
function commerce:page/ligne
data modify storage commerce:cp ve422 set from storage commerce:l ve
data modify storage commerce:cp vz422 set from storage commerce:l vz
data modify storage commerce:cp vc422 set from storage commerce:l vc
data modify storage commerce:cp ae422 set from storage commerce:l ae
data modify storage commerce:cp az422 set from storage commerce:l az
data modify storage commerce:cp ac422 set from storage commerce:l ac
data modify storage commerce:cp t422 set from storage commerce:l t
function commerce:page/lettre_f_1_d with storage commerce:cp
