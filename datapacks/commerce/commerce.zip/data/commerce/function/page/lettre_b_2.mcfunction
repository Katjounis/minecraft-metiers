function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 169
function commerce:page/ligne
data modify storage commerce:cp ve169 set from storage commerce:l ve
data modify storage commerce:cp vz169 set from storage commerce:l vz
data modify storage commerce:cp vc169 set from storage commerce:l vc
data modify storage commerce:cp ae169 set from storage commerce:l ae
data modify storage commerce:cp az169 set from storage commerce:l az
data modify storage commerce:cp ac169 set from storage commerce:l ac
data modify storage commerce:cp t169 set from storage commerce:l t
scoreboard players set #i c.t 155
function commerce:page/ligne
data modify storage commerce:cp ve155 set from storage commerce:l ve
data modify storage commerce:cp vz155 set from storage commerce:l vz
data modify storage commerce:cp vc155 set from storage commerce:l vc
data modify storage commerce:cp ae155 set from storage commerce:l ae
data modify storage commerce:cp az155 set from storage commerce:l az
data modify storage commerce:cp ac155 set from storage commerce:l ac
data modify storage commerce:cp t155 set from storage commerce:l t
scoreboard players set #i c.t 160
function commerce:page/ligne
data modify storage commerce:cp ve160 set from storage commerce:l ve
data modify storage commerce:cp vz160 set from storage commerce:l vz
data modify storage commerce:cp vc160 set from storage commerce:l vc
data modify storage commerce:cp ae160 set from storage commerce:l ae
data modify storage commerce:cp az160 set from storage commerce:l az
data modify storage commerce:cp ac160 set from storage commerce:l ac
data modify storage commerce:cp t160 set from storage commerce:l t
scoreboard players set #i c.t 168
function commerce:page/ligne
data modify storage commerce:cp ve168 set from storage commerce:l ve
data modify storage commerce:cp vz168 set from storage commerce:l vz
data modify storage commerce:cp vc168 set from storage commerce:l vc
data modify storage commerce:cp ae168 set from storage commerce:l ae
data modify storage commerce:cp az168 set from storage commerce:l az
data modify storage commerce:cp ac168 set from storage commerce:l ac
data modify storage commerce:cp t168 set from storage commerce:l t
scoreboard players set #i c.t 167
function commerce:page/ligne
data modify storage commerce:cp ve167 set from storage commerce:l ve
data modify storage commerce:cp vz167 set from storage commerce:l vz
data modify storage commerce:cp vc167 set from storage commerce:l vc
data modify storage commerce:cp ae167 set from storage commerce:l ae
data modify storage commerce:cp az167 set from storage commerce:l az
data modify storage commerce:cp ac167 set from storage commerce:l ac
data modify storage commerce:cp t167 set from storage commerce:l t
scoreboard players set #i c.t 159
function commerce:page/ligne
data modify storage commerce:cp ve159 set from storage commerce:l ve
data modify storage commerce:cp vz159 set from storage commerce:l vz
data modify storage commerce:cp vc159 set from storage commerce:l vc
data modify storage commerce:cp ae159 set from storage commerce:l ae
data modify storage commerce:cp az159 set from storage commerce:l az
data modify storage commerce:cp ac159 set from storage commerce:l ac
data modify storage commerce:cp t159 set from storage commerce:l t
scoreboard players set #i c.t 164
function commerce:page/ligne
data modify storage commerce:cp ve164 set from storage commerce:l ve
data modify storage commerce:cp vz164 set from storage commerce:l vz
data modify storage commerce:cp vc164 set from storage commerce:l vc
data modify storage commerce:cp ae164 set from storage commerce:l ae
data modify storage commerce:cp az164 set from storage commerce:l az
data modify storage commerce:cp ac164 set from storage commerce:l ac
data modify storage commerce:cp t164 set from storage commerce:l t
scoreboard players set #i c.t 373
function commerce:page/ligne
data modify storage commerce:cp ve373 set from storage commerce:l ve
data modify storage commerce:cp vz373 set from storage commerce:l vz
data modify storage commerce:cp vc373 set from storage commerce:l vc
data modify storage commerce:cp ae373 set from storage commerce:l ae
data modify storage commerce:cp az373 set from storage commerce:l az
data modify storage commerce:cp ac373 set from storage commerce:l ac
data modify storage commerce:cp t373 set from storage commerce:l t
scoreboard players set #i c.t 409
function commerce:page/ligne
data modify storage commerce:cp ve409 set from storage commerce:l ve
data modify storage commerce:cp vz409 set from storage commerce:l vz
data modify storage commerce:cp vc409 set from storage commerce:l vc
data modify storage commerce:cp ae409 set from storage commerce:l ae
data modify storage commerce:cp az409 set from storage commerce:l az
data modify storage commerce:cp ac409 set from storage commerce:l ac
data modify storage commerce:cp t409 set from storage commerce:l t
scoreboard players set #i c.t 279
function commerce:page/ligne
data modify storage commerce:cp ve279 set from storage commerce:l ve
data modify storage commerce:cp vz279 set from storage commerce:l vz
data modify storage commerce:cp vc279 set from storage commerce:l vc
data modify storage commerce:cp ae279 set from storage commerce:l ae
data modify storage commerce:cp az279 set from storage commerce:l az
data modify storage commerce:cp ac279 set from storage commerce:l ac
data modify storage commerce:cp t279 set from storage commerce:l t
function commerce:page/lettre_b_2_d with storage commerce:cp
