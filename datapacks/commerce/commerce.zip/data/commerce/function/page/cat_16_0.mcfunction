function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 401
function commerce:page/ligne
data modify storage commerce:cp ve401 set from storage commerce:l ve
data modify storage commerce:cp vz401 set from storage commerce:l vz
data modify storage commerce:cp vc401 set from storage commerce:l vc
data modify storage commerce:cp ae401 set from storage commerce:l ae
data modify storage commerce:cp az401 set from storage commerce:l az
data modify storage commerce:cp ac401 set from storage commerce:l ac
data modify storage commerce:cp t401 set from storage commerce:l t
scoreboard players set #i c.t 402
function commerce:page/ligne
data modify storage commerce:cp ve402 set from storage commerce:l ve
data modify storage commerce:cp vz402 set from storage commerce:l vz
data modify storage commerce:cp vc402 set from storage commerce:l vc
data modify storage commerce:cp ae402 set from storage commerce:l ae
data modify storage commerce:cp az402 set from storage commerce:l az
data modify storage commerce:cp ac402 set from storage commerce:l ac
data modify storage commerce:cp t402 set from storage commerce:l t
scoreboard players set #i c.t 403
function commerce:page/ligne
data modify storage commerce:cp ve403 set from storage commerce:l ve
data modify storage commerce:cp vz403 set from storage commerce:l vz
data modify storage commerce:cp vc403 set from storage commerce:l vc
data modify storage commerce:cp ae403 set from storage commerce:l ae
data modify storage commerce:cp az403 set from storage commerce:l az
data modify storage commerce:cp ac403 set from storage commerce:l ac
data modify storage commerce:cp t403 set from storage commerce:l t
scoreboard players set #i c.t 404
function commerce:page/ligne
data modify storage commerce:cp ve404 set from storage commerce:l ve
data modify storage commerce:cp vz404 set from storage commerce:l vz
data modify storage commerce:cp vc404 set from storage commerce:l vc
data modify storage commerce:cp ae404 set from storage commerce:l ae
data modify storage commerce:cp az404 set from storage commerce:l az
data modify storage commerce:cp ac404 set from storage commerce:l ac
data modify storage commerce:cp t404 set from storage commerce:l t
scoreboard players set #i c.t 405
function commerce:page/ligne
data modify storage commerce:cp ve405 set from storage commerce:l ve
data modify storage commerce:cp vz405 set from storage commerce:l vz
data modify storage commerce:cp vc405 set from storage commerce:l vc
data modify storage commerce:cp ae405 set from storage commerce:l ae
data modify storage commerce:cp az405 set from storage commerce:l az
data modify storage commerce:cp ac405 set from storage commerce:l ac
data modify storage commerce:cp t405 set from storage commerce:l t
scoreboard players set #i c.t 406
function commerce:page/ligne
data modify storage commerce:cp ve406 set from storage commerce:l ve
data modify storage commerce:cp vz406 set from storage commerce:l vz
data modify storage commerce:cp vc406 set from storage commerce:l vc
data modify storage commerce:cp ae406 set from storage commerce:l ae
data modify storage commerce:cp az406 set from storage commerce:l az
data modify storage commerce:cp ac406 set from storage commerce:l ac
data modify storage commerce:cp t406 set from storage commerce:l t
scoreboard players set #i c.t 407
function commerce:page/ligne
data modify storage commerce:cp ve407 set from storage commerce:l ve
data modify storage commerce:cp vz407 set from storage commerce:l vz
data modify storage commerce:cp vc407 set from storage commerce:l vc
data modify storage commerce:cp ae407 set from storage commerce:l ae
data modify storage commerce:cp az407 set from storage commerce:l az
data modify storage commerce:cp ac407 set from storage commerce:l ac
data modify storage commerce:cp t407 set from storage commerce:l t
scoreboard players set #i c.t 408
function commerce:page/ligne
data modify storage commerce:cp ve408 set from storage commerce:l ve
data modify storage commerce:cp vz408 set from storage commerce:l vz
data modify storage commerce:cp vc408 set from storage commerce:l vc
data modify storage commerce:cp ae408 set from storage commerce:l ae
data modify storage commerce:cp az408 set from storage commerce:l az
data modify storage commerce:cp ac408 set from storage commerce:l ac
data modify storage commerce:cp t408 set from storage commerce:l t
scoreboard players set #i c.t 409
function commerce:page/ligne
data modify storage commerce:cp ve409 set from storage commerce:l ve
data modify storage commerce:cp vz409 set from storage commerce:l vz
data modify storage commerce:cp vc409 set from storage commerce:l vc
data modify storage commerce:cp ae409 set from storage commerce:l ae
data modify storage commerce:cp az409 set from storage commerce:l az
data modify storage commerce:cp ac409 set from storage commerce:l ac
data modify storage commerce:cp t409 set from storage commerce:l t
scoreboard players set #i c.t 410
function commerce:page/ligne
data modify storage commerce:cp ve410 set from storage commerce:l ve
data modify storage commerce:cp vz410 set from storage commerce:l vz
data modify storage commerce:cp vc410 set from storage commerce:l vc
data modify storage commerce:cp ae410 set from storage commerce:l ae
data modify storage commerce:cp az410 set from storage commerce:l az
data modify storage commerce:cp ac410 set from storage commerce:l ac
data modify storage commerce:cp t410 set from storage commerce:l t
function commerce:page/cat_16_0_d with storage commerce:cp
