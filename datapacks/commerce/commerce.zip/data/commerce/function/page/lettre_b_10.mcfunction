function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 71
function commerce:page/ligne
data modify storage commerce:cp ve71 set from storage commerce:l ve
data modify storage commerce:cp vz71 set from storage commerce:l vz
data modify storage commerce:cp vc71 set from storage commerce:l vc
data modify storage commerce:cp ae71 set from storage commerce:l ae
data modify storage commerce:cp az71 set from storage commerce:l az
data modify storage commerce:cp ac71 set from storage commerce:l ac
data modify storage commerce:cp t71 set from storage commerce:l t
function commerce:page/lettre_b_10_d with storage commerce:cp
