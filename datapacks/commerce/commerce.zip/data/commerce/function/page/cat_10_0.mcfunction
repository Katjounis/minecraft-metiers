function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 279
function commerce:page/ligne
data modify storage commerce:cp ve279 set from storage commerce:l ve
data modify storage commerce:cp vz279 set from storage commerce:l vz
data modify storage commerce:cp vc279 set from storage commerce:l vc
data modify storage commerce:cp ae279 set from storage commerce:l ae
data modify storage commerce:cp az279 set from storage commerce:l az
data modify storage commerce:cp ac279 set from storage commerce:l ac
data modify storage commerce:cp t279 set from storage commerce:l t
scoreboard players set #i c.t 280
function commerce:page/ligne
data modify storage commerce:cp ve280 set from storage commerce:l ve
data modify storage commerce:cp vz280 set from storage commerce:l vz
data modify storage commerce:cp vc280 set from storage commerce:l vc
data modify storage commerce:cp ae280 set from storage commerce:l ae
data modify storage commerce:cp az280 set from storage commerce:l az
data modify storage commerce:cp ac280 set from storage commerce:l ac
data modify storage commerce:cp t280 set from storage commerce:l t
scoreboard players set #i c.t 281
function commerce:page/ligne
data modify storage commerce:cp ve281 set from storage commerce:l ve
data modify storage commerce:cp vz281 set from storage commerce:l vz
data modify storage commerce:cp vc281 set from storage commerce:l vc
data modify storage commerce:cp ae281 set from storage commerce:l ae
data modify storage commerce:cp az281 set from storage commerce:l az
data modify storage commerce:cp ac281 set from storage commerce:l ac
data modify storage commerce:cp t281 set from storage commerce:l t
scoreboard players set #i c.t 282
function commerce:page/ligne
data modify storage commerce:cp ve282 set from storage commerce:l ve
data modify storage commerce:cp vz282 set from storage commerce:l vz
data modify storage commerce:cp vc282 set from storage commerce:l vc
data modify storage commerce:cp ae282 set from storage commerce:l ae
data modify storage commerce:cp az282 set from storage commerce:l az
data modify storage commerce:cp ac282 set from storage commerce:l ac
data modify storage commerce:cp t282 set from storage commerce:l t
scoreboard players set #i c.t 283
function commerce:page/ligne
data modify storage commerce:cp ve283 set from storage commerce:l ve
data modify storage commerce:cp vz283 set from storage commerce:l vz
data modify storage commerce:cp vc283 set from storage commerce:l vc
data modify storage commerce:cp ae283 set from storage commerce:l ae
data modify storage commerce:cp az283 set from storage commerce:l az
data modify storage commerce:cp ac283 set from storage commerce:l ac
data modify storage commerce:cp t283 set from storage commerce:l t
scoreboard players set #i c.t 284
function commerce:page/ligne
data modify storage commerce:cp ve284 set from storage commerce:l ve
data modify storage commerce:cp vz284 set from storage commerce:l vz
data modify storage commerce:cp vc284 set from storage commerce:l vc
data modify storage commerce:cp ae284 set from storage commerce:l ae
data modify storage commerce:cp az284 set from storage commerce:l az
data modify storage commerce:cp ac284 set from storage commerce:l ac
data modify storage commerce:cp t284 set from storage commerce:l t
scoreboard players set #i c.t 285
function commerce:page/ligne
data modify storage commerce:cp ve285 set from storage commerce:l ve
data modify storage commerce:cp vz285 set from storage commerce:l vz
data modify storage commerce:cp vc285 set from storage commerce:l vc
data modify storage commerce:cp ae285 set from storage commerce:l ae
data modify storage commerce:cp az285 set from storage commerce:l az
data modify storage commerce:cp ac285 set from storage commerce:l ac
data modify storage commerce:cp t285 set from storage commerce:l t
scoreboard players set #i c.t 286
function commerce:page/ligne
data modify storage commerce:cp ve286 set from storage commerce:l ve
data modify storage commerce:cp vz286 set from storage commerce:l vz
data modify storage commerce:cp vc286 set from storage commerce:l vc
data modify storage commerce:cp ae286 set from storage commerce:l ae
data modify storage commerce:cp az286 set from storage commerce:l az
data modify storage commerce:cp ac286 set from storage commerce:l ac
data modify storage commerce:cp t286 set from storage commerce:l t
scoreboard players set #i c.t 287
function commerce:page/ligne
data modify storage commerce:cp ve287 set from storage commerce:l ve
data modify storage commerce:cp vz287 set from storage commerce:l vz
data modify storage commerce:cp vc287 set from storage commerce:l vc
data modify storage commerce:cp ae287 set from storage commerce:l ae
data modify storage commerce:cp az287 set from storage commerce:l az
data modify storage commerce:cp ac287 set from storage commerce:l ac
data modify storage commerce:cp t287 set from storage commerce:l t
scoreboard players set #i c.t 288
function commerce:page/ligne
data modify storage commerce:cp ve288 set from storage commerce:l ve
data modify storage commerce:cp vz288 set from storage commerce:l vz
data modify storage commerce:cp vc288 set from storage commerce:l vc
data modify storage commerce:cp ae288 set from storage commerce:l ae
data modify storage commerce:cp az288 set from storage commerce:l az
data modify storage commerce:cp ac288 set from storage commerce:l ac
data modify storage commerce:cp t288 set from storage commerce:l t
function commerce:page/cat_10_0_d with storage commerce:cp
