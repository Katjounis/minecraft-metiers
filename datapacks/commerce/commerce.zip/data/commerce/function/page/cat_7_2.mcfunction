function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 207
function commerce:page/ligne
data modify storage commerce:cp ve207 set from storage commerce:l ve
data modify storage commerce:cp vz207 set from storage commerce:l vz
data modify storage commerce:cp vc207 set from storage commerce:l vc
data modify storage commerce:cp ae207 set from storage commerce:l ae
data modify storage commerce:cp az207 set from storage commerce:l az
data modify storage commerce:cp ac207 set from storage commerce:l ac
data modify storage commerce:cp t207 set from storage commerce:l t
scoreboard players set #i c.t 208
function commerce:page/ligne
data modify storage commerce:cp ve208 set from storage commerce:l ve
data modify storage commerce:cp vz208 set from storage commerce:l vz
data modify storage commerce:cp vc208 set from storage commerce:l vc
data modify storage commerce:cp ae208 set from storage commerce:l ae
data modify storage commerce:cp az208 set from storage commerce:l az
data modify storage commerce:cp ac208 set from storage commerce:l ac
data modify storage commerce:cp t208 set from storage commerce:l t
scoreboard players set #i c.t 209
function commerce:page/ligne
data modify storage commerce:cp ve209 set from storage commerce:l ve
data modify storage commerce:cp vz209 set from storage commerce:l vz
data modify storage commerce:cp vc209 set from storage commerce:l vc
data modify storage commerce:cp ae209 set from storage commerce:l ae
data modify storage commerce:cp az209 set from storage commerce:l az
data modify storage commerce:cp ac209 set from storage commerce:l ac
data modify storage commerce:cp t209 set from storage commerce:l t
scoreboard players set #i c.t 210
function commerce:page/ligne
data modify storage commerce:cp ve210 set from storage commerce:l ve
data modify storage commerce:cp vz210 set from storage commerce:l vz
data modify storage commerce:cp vc210 set from storage commerce:l vc
data modify storage commerce:cp ae210 set from storage commerce:l ae
data modify storage commerce:cp az210 set from storage commerce:l az
data modify storage commerce:cp ac210 set from storage commerce:l ac
data modify storage commerce:cp t210 set from storage commerce:l t
scoreboard players set #i c.t 211
function commerce:page/ligne
data modify storage commerce:cp ve211 set from storage commerce:l ve
data modify storage commerce:cp vz211 set from storage commerce:l vz
data modify storage commerce:cp vc211 set from storage commerce:l vc
data modify storage commerce:cp ae211 set from storage commerce:l ae
data modify storage commerce:cp az211 set from storage commerce:l az
data modify storage commerce:cp ac211 set from storage commerce:l ac
data modify storage commerce:cp t211 set from storage commerce:l t
scoreboard players set #i c.t 212
function commerce:page/ligne
data modify storage commerce:cp ve212 set from storage commerce:l ve
data modify storage commerce:cp vz212 set from storage commerce:l vz
data modify storage commerce:cp vc212 set from storage commerce:l vc
data modify storage commerce:cp ae212 set from storage commerce:l ae
data modify storage commerce:cp az212 set from storage commerce:l az
data modify storage commerce:cp ac212 set from storage commerce:l ac
data modify storage commerce:cp t212 set from storage commerce:l t
scoreboard players set #i c.t 213
function commerce:page/ligne
data modify storage commerce:cp ve213 set from storage commerce:l ve
data modify storage commerce:cp vz213 set from storage commerce:l vz
data modify storage commerce:cp vc213 set from storage commerce:l vc
data modify storage commerce:cp ae213 set from storage commerce:l ae
data modify storage commerce:cp az213 set from storage commerce:l az
data modify storage commerce:cp ac213 set from storage commerce:l ac
data modify storage commerce:cp t213 set from storage commerce:l t
scoreboard players set #i c.t 214
function commerce:page/ligne
data modify storage commerce:cp ve214 set from storage commerce:l ve
data modify storage commerce:cp vz214 set from storage commerce:l vz
data modify storage commerce:cp vc214 set from storage commerce:l vc
data modify storage commerce:cp ae214 set from storage commerce:l ae
data modify storage commerce:cp az214 set from storage commerce:l az
data modify storage commerce:cp ac214 set from storage commerce:l ac
data modify storage commerce:cp t214 set from storage commerce:l t
scoreboard players set #i c.t 215
function commerce:page/ligne
data modify storage commerce:cp ve215 set from storage commerce:l ve
data modify storage commerce:cp vz215 set from storage commerce:l vz
data modify storage commerce:cp vc215 set from storage commerce:l vc
data modify storage commerce:cp ae215 set from storage commerce:l ae
data modify storage commerce:cp az215 set from storage commerce:l az
data modify storage commerce:cp ac215 set from storage commerce:l ac
data modify storage commerce:cp t215 set from storage commerce:l t
scoreboard players set #i c.t 216
function commerce:page/ligne
data modify storage commerce:cp ve216 set from storage commerce:l ve
data modify storage commerce:cp vz216 set from storage commerce:l vz
data modify storage commerce:cp vc216 set from storage commerce:l vc
data modify storage commerce:cp ae216 set from storage commerce:l ae
data modify storage commerce:cp az216 set from storage commerce:l az
data modify storage commerce:cp ac216 set from storage commerce:l ac
data modify storage commerce:cp t216 set from storage commerce:l t
function commerce:page/cat_7_2_d with storage commerce:cp
