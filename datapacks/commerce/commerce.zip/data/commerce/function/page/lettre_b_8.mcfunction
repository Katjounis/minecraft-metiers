function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 253
function commerce:page/ligne
data modify storage commerce:cp ve253 set from storage commerce:l ve
data modify storage commerce:cp vz253 set from storage commerce:l vz
data modify storage commerce:cp vc253 set from storage commerce:l vc
data modify storage commerce:cp ae253 set from storage commerce:l ae
data modify storage commerce:cp az253 set from storage commerce:l az
data modify storage commerce:cp ac253 set from storage commerce:l ac
data modify storage commerce:cp t253 set from storage commerce:l t
scoreboard players set #i c.t 418
function commerce:page/ligne
data modify storage commerce:cp ve418 set from storage commerce:l ve
data modify storage commerce:cp vz418 set from storage commerce:l vz
data modify storage commerce:cp vc418 set from storage commerce:l vc
data modify storage commerce:cp ae418 set from storage commerce:l ae
data modify storage commerce:cp az418 set from storage commerce:l az
data modify storage commerce:cp ac418 set from storage commerce:l ac
data modify storage commerce:cp t418 set from storage commerce:l t
scoreboard players set #i c.t 422
function commerce:page/ligne
data modify storage commerce:cp ve422 set from storage commerce:l ve
data modify storage commerce:cp vz422 set from storage commerce:l vz
data modify storage commerce:cp vc422 set from storage commerce:l vc
data modify storage commerce:cp ae422 set from storage commerce:l ae
data modify storage commerce:cp az422 set from storage commerce:l az
data modify storage commerce:cp ac422 set from storage commerce:l ac
data modify storage commerce:cp t422 set from storage commerce:l t
scoreboard players set #i c.t 68
function commerce:page/ligne
data modify storage commerce:cp ve68 set from storage commerce:l ve
data modify storage commerce:cp vz68 set from storage commerce:l vz
data modify storage commerce:cp vc68 set from storage commerce:l vc
data modify storage commerce:cp ae68 set from storage commerce:l ae
data modify storage commerce:cp az68 set from storage commerce:l az
data modify storage commerce:cp ac68 set from storage commerce:l ac
data modify storage commerce:cp t68 set from storage commerce:l t
scoreboard players set #i c.t 78
function commerce:page/ligne
data modify storage commerce:cp ve78 set from storage commerce:l ve
data modify storage commerce:cp vz78 set from storage commerce:l vz
data modify storage commerce:cp vc78 set from storage commerce:l vc
data modify storage commerce:cp ae78 set from storage commerce:l ae
data modify storage commerce:cp az78 set from storage commerce:l az
data modify storage commerce:cp ac78 set from storage commerce:l ac
data modify storage commerce:cp t78 set from storage commerce:l t
scoreboard players set #i c.t 64
function commerce:page/ligne
data modify storage commerce:cp ve64 set from storage commerce:l ve
data modify storage commerce:cp vz64 set from storage commerce:l vz
data modify storage commerce:cp vc64 set from storage commerce:l vc
data modify storage commerce:cp ae64 set from storage commerce:l ae
data modify storage commerce:cp az64 set from storage commerce:l az
data modify storage commerce:cp ac64 set from storage commerce:l ac
data modify storage commerce:cp t64 set from storage commerce:l t
scoreboard players set #i c.t 74
function commerce:page/ligne
data modify storage commerce:cp ve74 set from storage commerce:l ve
data modify storage commerce:cp vz74 set from storage commerce:l vz
data modify storage commerce:cp vc74 set from storage commerce:l vc
data modify storage commerce:cp ae74 set from storage commerce:l ae
data modify storage commerce:cp az74 set from storage commerce:l az
data modify storage commerce:cp ac74 set from storage commerce:l ac
data modify storage commerce:cp t74 set from storage commerce:l t
scoreboard players set #i c.t 80
function commerce:page/ligne
data modify storage commerce:cp ve80 set from storage commerce:l ve
data modify storage commerce:cp vz80 set from storage commerce:l vz
data modify storage commerce:cp vc80 set from storage commerce:l vc
data modify storage commerce:cp ae80 set from storage commerce:l ae
data modify storage commerce:cp az80 set from storage commerce:l az
data modify storage commerce:cp ac80 set from storage commerce:l ac
data modify storage commerce:cp t80 set from storage commerce:l t
scoreboard players set #i c.t 76
function commerce:page/ligne
data modify storage commerce:cp ve76 set from storage commerce:l ve
data modify storage commerce:cp vz76 set from storage commerce:l vz
data modify storage commerce:cp vc76 set from storage commerce:l vc
data modify storage commerce:cp ae76 set from storage commerce:l ae
data modify storage commerce:cp az76 set from storage commerce:l az
data modify storage commerce:cp ac76 set from storage commerce:l ac
data modify storage commerce:cp t76 set from storage commerce:l t
scoreboard players set #i c.t 66
function commerce:page/ligne
data modify storage commerce:cp ve66 set from storage commerce:l ve
data modify storage commerce:cp vz66 set from storage commerce:l vz
data modify storage commerce:cp vc66 set from storage commerce:l vc
data modify storage commerce:cp ae66 set from storage commerce:l ae
data modify storage commerce:cp az66 set from storage commerce:l az
data modify storage commerce:cp ac66 set from storage commerce:l ac
data modify storage commerce:cp t66 set from storage commerce:l t
function commerce:page/lettre_b_8_d with storage commerce:cp
