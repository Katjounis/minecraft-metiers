function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 479
function commerce:page/ligne
data modify storage commerce:cp ve479 set from storage commerce:l ve
data modify storage commerce:cp vz479 set from storage commerce:l vz
data modify storage commerce:cp vc479 set from storage commerce:l vc
data modify storage commerce:cp ae479 set from storage commerce:l ae
data modify storage commerce:cp az479 set from storage commerce:l az
data modify storage commerce:cp ac479 set from storage commerce:l ac
data modify storage commerce:cp t479 set from storage commerce:l t
scoreboard players set #i c.t 480
function commerce:page/ligne
data modify storage commerce:cp ve480 set from storage commerce:l ve
data modify storage commerce:cp vz480 set from storage commerce:l vz
data modify storage commerce:cp vc480 set from storage commerce:l vc
data modify storage commerce:cp ae480 set from storage commerce:l ae
data modify storage commerce:cp az480 set from storage commerce:l az
data modify storage commerce:cp ac480 set from storage commerce:l ac
data modify storage commerce:cp t480 set from storage commerce:l t
scoreboard players set #i c.t 481
function commerce:page/ligne
data modify storage commerce:cp ve481 set from storage commerce:l ve
data modify storage commerce:cp vz481 set from storage commerce:l vz
data modify storage commerce:cp vc481 set from storage commerce:l vc
data modify storage commerce:cp ae481 set from storage commerce:l ae
data modify storage commerce:cp az481 set from storage commerce:l az
data modify storage commerce:cp ac481 set from storage commerce:l ac
data modify storage commerce:cp t481 set from storage commerce:l t
scoreboard players set #i c.t 482
function commerce:page/ligne
data modify storage commerce:cp ve482 set from storage commerce:l ve
data modify storage commerce:cp vz482 set from storage commerce:l vz
data modify storage commerce:cp vc482 set from storage commerce:l vc
data modify storage commerce:cp ae482 set from storage commerce:l ae
data modify storage commerce:cp az482 set from storage commerce:l az
data modify storage commerce:cp ac482 set from storage commerce:l ac
data modify storage commerce:cp t482 set from storage commerce:l t
function commerce:page/cat_17_2_d with storage commerce:cp
