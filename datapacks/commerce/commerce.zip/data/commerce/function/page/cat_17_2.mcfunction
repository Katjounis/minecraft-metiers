function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 476
function commerce:page/ligne
data modify storage commerce:cp ve476 set from storage commerce:l ve
data modify storage commerce:cp vz476 set from storage commerce:l vz
data modify storage commerce:cp vc476 set from storage commerce:l vc
data modify storage commerce:cp ae476 set from storage commerce:l ae
data modify storage commerce:cp az476 set from storage commerce:l az
data modify storage commerce:cp ac476 set from storage commerce:l ac
data modify storage commerce:cp t476 set from storage commerce:l t
function commerce:page/cat_17_2_d with storage commerce:cp
