scoreboard players set #btot c.t 0
scoreboard players set #lot c.t 1
execute unless items entity @s container.* minecraft:cobblestone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cobblestone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cobblestone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 1
execute if items entity @s weapon.offhand minecraft:cobblestone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 1
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:mossy_cobblestone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:mossy_cobblestone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:mossy_cobblestone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 2
execute if items entity @s weapon.offhand minecraft:mossy_cobblestone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 2
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:stone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:stone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:stone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 3
execute if items entity @s weapon.offhand minecraft:stone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 3
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:smooth_stone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:smooth_stone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:smooth_stone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 4
execute if items entity @s weapon.offhand minecraft:smooth_stone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 4
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 5
execute if items entity @s weapon.offhand minecraft:stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 5
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:mossy_stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:mossy_stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:mossy_stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 6
execute if items entity @s weapon.offhand minecraft:mossy_stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 6
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:cracked_stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cracked_stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cracked_stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 7
execute if items entity @s weapon.offhand minecraft:cracked_stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 7
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:chiseled_stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:chiseled_stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:chiseled_stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 8
execute if items entity @s weapon.offhand minecraft:chiseled_stone_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 8
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:granite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:granite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:granite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 9
execute if items entity @s weapon.offhand minecraft:granite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 9
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:polished_granite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:polished_granite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:polished_granite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 10
execute if items entity @s weapon.offhand minecraft:polished_granite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 10
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:diorite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:diorite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:diorite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 11
execute if items entity @s weapon.offhand minecraft:diorite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 11
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:polished_diorite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:polished_diorite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:polished_diorite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 12
execute if items entity @s weapon.offhand minecraft:polished_diorite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 12
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:andesite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:andesite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:andesite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 13
execute if items entity @s weapon.offhand minecraft:andesite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 13
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:polished_andesite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:polished_andesite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:polished_andesite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 14
execute if items entity @s weapon.offhand minecraft:polished_andesite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 14
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 15
execute if items entity @s weapon.offhand minecraft:deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 15
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:cobbled_deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cobbled_deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cobbled_deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 16
execute if items entity @s weapon.offhand minecraft:cobbled_deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 16
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:polished_deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:polished_deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:polished_deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 17
execute if items entity @s weapon.offhand minecraft:polished_deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 17
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:deepslate_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:deepslate_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:deepslate_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 18
execute if items entity @s weapon.offhand minecraft:deepslate_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 18
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:deepslate_tiles[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:deepslate_tiles[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:deepslate_tiles[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 19
execute if items entity @s weapon.offhand minecraft:deepslate_tiles[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 19
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:chiseled_deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:chiseled_deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:chiseled_deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 20
execute if items entity @s weapon.offhand minecraft:chiseled_deepslate[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 20
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:tuff[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:tuff[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:tuff[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 21
execute if items entity @s weapon.offhand minecraft:tuff[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 21
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:polished_tuff[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:polished_tuff[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:polished_tuff[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 22
execute if items entity @s weapon.offhand minecraft:polished_tuff[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 22
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:tuff_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:tuff_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:tuff_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 23
execute if items entity @s weapon.offhand minecraft:tuff_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 23
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:calcite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:calcite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:calcite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 24
execute if items entity @s weapon.offhand minecraft:calcite[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 24
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:dripstone_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:dripstone_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:dripstone_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 25
execute if items entity @s weapon.offhand minecraft:dripstone_block[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 25
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:pointed_dripstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:pointed_dripstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:pointed_dripstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 26
execute if items entity @s weapon.offhand minecraft:pointed_dripstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 26
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 27
execute if items entity @s weapon.offhand minecraft:sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 27
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:smooth_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:smooth_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:smooth_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 28
execute if items entity @s weapon.offhand minecraft:smooth_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 28
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:cut_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cut_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cut_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 29
execute if items entity @s weapon.offhand minecraft:cut_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 29
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:chiseled_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:chiseled_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:chiseled_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 30
execute if items entity @s weapon.offhand minecraft:chiseled_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 30
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:red_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:red_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:red_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 31
execute if items entity @s weapon.offhand minecraft:red_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 31
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:smooth_red_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:smooth_red_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:smooth_red_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 32
execute if items entity @s weapon.offhand minecraft:smooth_red_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 32
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:cut_red_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cut_red_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cut_red_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 33
execute if items entity @s weapon.offhand minecraft:cut_red_sandstone[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 33
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:brick[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:brick[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:brick[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 34
execute if items entity @s weapon.offhand minecraft:brick[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 34
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 35
execute if items entity @s weapon.offhand minecraft:bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 35
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:mud[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:mud[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:mud[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 36
execute if items entity @s weapon.offhand minecraft:mud[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 36
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:packed_mud[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:packed_mud[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:packed_mud[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 37
execute if items entity @s weapon.offhand minecraft:packed_mud[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 37
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:mud_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:mud_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:mud_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 38
execute if items entity @s weapon.offhand minecraft:mud_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 38
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:prismarine[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:prismarine[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:prismarine[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 39
execute if items entity @s weapon.offhand minecraft:prismarine[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 39
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:prismarine_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:prismarine_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:prismarine_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 40
execute if items entity @s weapon.offhand minecraft:prismarine_bricks[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 40
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:dark_prismarine[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:dark_prismarine[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:dark_prismarine[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 41
execute if items entity @s weapon.offhand minecraft:dark_prismarine[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 41
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:sea_lantern[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:sea_lantern[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:sea_lantern[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 42
execute if items entity @s weapon.offhand minecraft:sea_lantern[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 42
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:obsidian[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:obsidian[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:obsidian[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 43
execute if items entity @s weapon.offhand minecraft:obsidian[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 43
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:crying_obsidian[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:crying_obsidian[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:crying_obsidian[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 44
execute if items entity @s weapon.offhand minecraft:crying_obsidian[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 44
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
scoreboard players set #lot c.t 0
scoreboard players operation #btot c.t /= #100 c.g
execute if score #btot c.t matches ..0 run tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Rien à vendre dans cette catégorie (les objets renommés ou spéciaux sont gardés).",color:"red",bold:false,italic:false}]
execute if score #btot c.t matches 1.. run tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Pierres vendu en entier : ",color:"gray",bold:false,italic:false},{score:{name:"#btot",objective:"c.t"},color:"gold",bold:true},{text:" Écus",color:"gold",bold:false,italic:false}]
execute if score #btot c.t matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.7 1.4
function commerce:page/cat_1_0
