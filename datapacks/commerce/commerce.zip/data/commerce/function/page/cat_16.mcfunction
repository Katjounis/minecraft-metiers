function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 401
function commerce:page/ligne
data modify storage commerce:cp ve401 set from storage commerce:l ve
data modify storage commerce:cp vz401 set from storage commerce:l vz
data modify storage commerce:cp vc401 set from storage commerce:l vc
data modify storage commerce:cp ae401 set from storage commerce:l ae
data modify storage commerce:cp az401 set from storage commerce:l az
data modify storage commerce:cp ac401 set from storage commerce:l ac
data modify storage commerce:cp t401 set from storage commerce:l t
data modify storage commerce:cp tc401 set from storage commerce:l tc
scoreboard players set #i c.t 402
function commerce:page/ligne
data modify storage commerce:cp ve402 set from storage commerce:l ve
data modify storage commerce:cp vz402 set from storage commerce:l vz
data modify storage commerce:cp vc402 set from storage commerce:l vc
data modify storage commerce:cp ae402 set from storage commerce:l ae
data modify storage commerce:cp az402 set from storage commerce:l az
data modify storage commerce:cp ac402 set from storage commerce:l ac
data modify storage commerce:cp t402 set from storage commerce:l t
data modify storage commerce:cp tc402 set from storage commerce:l tc
scoreboard players set #i c.t 403
function commerce:page/ligne
data modify storage commerce:cp ve403 set from storage commerce:l ve
data modify storage commerce:cp vz403 set from storage commerce:l vz
data modify storage commerce:cp vc403 set from storage commerce:l vc
data modify storage commerce:cp ae403 set from storage commerce:l ae
data modify storage commerce:cp az403 set from storage commerce:l az
data modify storage commerce:cp ac403 set from storage commerce:l ac
data modify storage commerce:cp t403 set from storage commerce:l t
data modify storage commerce:cp tc403 set from storage commerce:l tc
scoreboard players set #i c.t 404
function commerce:page/ligne
data modify storage commerce:cp ve404 set from storage commerce:l ve
data modify storage commerce:cp vz404 set from storage commerce:l vz
data modify storage commerce:cp vc404 set from storage commerce:l vc
data modify storage commerce:cp ae404 set from storage commerce:l ae
data modify storage commerce:cp az404 set from storage commerce:l az
data modify storage commerce:cp ac404 set from storage commerce:l ac
data modify storage commerce:cp t404 set from storage commerce:l t
data modify storage commerce:cp tc404 set from storage commerce:l tc
scoreboard players set #i c.t 405
function commerce:page/ligne
data modify storage commerce:cp ve405 set from storage commerce:l ve
data modify storage commerce:cp vz405 set from storage commerce:l vz
data modify storage commerce:cp vc405 set from storage commerce:l vc
data modify storage commerce:cp ae405 set from storage commerce:l ae
data modify storage commerce:cp az405 set from storage commerce:l az
data modify storage commerce:cp ac405 set from storage commerce:l ac
data modify storage commerce:cp t405 set from storage commerce:l t
data modify storage commerce:cp tc405 set from storage commerce:l tc
scoreboard players set #i c.t 406
function commerce:page/ligne
data modify storage commerce:cp ve406 set from storage commerce:l ve
data modify storage commerce:cp vz406 set from storage commerce:l vz
data modify storage commerce:cp vc406 set from storage commerce:l vc
data modify storage commerce:cp ae406 set from storage commerce:l ae
data modify storage commerce:cp az406 set from storage commerce:l az
data modify storage commerce:cp ac406 set from storage commerce:l ac
data modify storage commerce:cp t406 set from storage commerce:l t
data modify storage commerce:cp tc406 set from storage commerce:l tc
scoreboard players set #i c.t 407
function commerce:page/ligne
data modify storage commerce:cp ve407 set from storage commerce:l ve
data modify storage commerce:cp vz407 set from storage commerce:l vz
data modify storage commerce:cp vc407 set from storage commerce:l vc
data modify storage commerce:cp ae407 set from storage commerce:l ae
data modify storage commerce:cp az407 set from storage commerce:l az
data modify storage commerce:cp ac407 set from storage commerce:l ac
data modify storage commerce:cp t407 set from storage commerce:l t
data modify storage commerce:cp tc407 set from storage commerce:l tc
scoreboard players set #i c.t 408
function commerce:page/ligne
data modify storage commerce:cp ve408 set from storage commerce:l ve
data modify storage commerce:cp vz408 set from storage commerce:l vz
data modify storage commerce:cp vc408 set from storage commerce:l vc
data modify storage commerce:cp ae408 set from storage commerce:l ae
data modify storage commerce:cp az408 set from storage commerce:l az
data modify storage commerce:cp ac408 set from storage commerce:l ac
data modify storage commerce:cp t408 set from storage commerce:l t
data modify storage commerce:cp tc408 set from storage commerce:l tc
scoreboard players set #i c.t 409
function commerce:page/ligne
data modify storage commerce:cp ve409 set from storage commerce:l ve
data modify storage commerce:cp vz409 set from storage commerce:l vz
data modify storage commerce:cp vc409 set from storage commerce:l vc
data modify storage commerce:cp ae409 set from storage commerce:l ae
data modify storage commerce:cp az409 set from storage commerce:l az
data modify storage commerce:cp ac409 set from storage commerce:l ac
data modify storage commerce:cp t409 set from storage commerce:l t
data modify storage commerce:cp tc409 set from storage commerce:l tc
scoreboard players set #i c.t 410
function commerce:page/ligne
data modify storage commerce:cp ve410 set from storage commerce:l ve
data modify storage commerce:cp vz410 set from storage commerce:l vz
data modify storage commerce:cp vc410 set from storage commerce:l vc
data modify storage commerce:cp ae410 set from storage commerce:l ae
data modify storage commerce:cp az410 set from storage commerce:l az
data modify storage commerce:cp ac410 set from storage commerce:l ac
data modify storage commerce:cp t410 set from storage commerce:l t
data modify storage commerce:cp tc410 set from storage commerce:l tc
scoreboard players set #i c.t 411
function commerce:page/ligne
data modify storage commerce:cp ve411 set from storage commerce:l ve
data modify storage commerce:cp vz411 set from storage commerce:l vz
data modify storage commerce:cp vc411 set from storage commerce:l vc
data modify storage commerce:cp ae411 set from storage commerce:l ae
data modify storage commerce:cp az411 set from storage commerce:l az
data modify storage commerce:cp ac411 set from storage commerce:l ac
data modify storage commerce:cp t411 set from storage commerce:l t
data modify storage commerce:cp tc411 set from storage commerce:l tc
scoreboard players set #i c.t 412
function commerce:page/ligne
data modify storage commerce:cp ve412 set from storage commerce:l ve
data modify storage commerce:cp vz412 set from storage commerce:l vz
data modify storage commerce:cp vc412 set from storage commerce:l vc
data modify storage commerce:cp ae412 set from storage commerce:l ae
data modify storage commerce:cp az412 set from storage commerce:l az
data modify storage commerce:cp ac412 set from storage commerce:l ac
data modify storage commerce:cp t412 set from storage commerce:l t
data modify storage commerce:cp tc412 set from storage commerce:l tc
scoreboard players set #i c.t 413
function commerce:page/ligne
data modify storage commerce:cp ve413 set from storage commerce:l ve
data modify storage commerce:cp vz413 set from storage commerce:l vz
data modify storage commerce:cp vc413 set from storage commerce:l vc
data modify storage commerce:cp ae413 set from storage commerce:l ae
data modify storage commerce:cp az413 set from storage commerce:l az
data modify storage commerce:cp ac413 set from storage commerce:l ac
data modify storage commerce:cp t413 set from storage commerce:l t
data modify storage commerce:cp tc413 set from storage commerce:l tc
scoreboard players set #i c.t 414
function commerce:page/ligne
data modify storage commerce:cp ve414 set from storage commerce:l ve
data modify storage commerce:cp vz414 set from storage commerce:l vz
data modify storage commerce:cp vc414 set from storage commerce:l vc
data modify storage commerce:cp ae414 set from storage commerce:l ae
data modify storage commerce:cp az414 set from storage commerce:l az
data modify storage commerce:cp ac414 set from storage commerce:l ac
data modify storage commerce:cp t414 set from storage commerce:l t
data modify storage commerce:cp tc414 set from storage commerce:l tc
scoreboard players set #i c.t 415
function commerce:page/ligne
data modify storage commerce:cp ve415 set from storage commerce:l ve
data modify storage commerce:cp vz415 set from storage commerce:l vz
data modify storage commerce:cp vc415 set from storage commerce:l vc
data modify storage commerce:cp ae415 set from storage commerce:l ae
data modify storage commerce:cp az415 set from storage commerce:l az
data modify storage commerce:cp ac415 set from storage commerce:l ac
data modify storage commerce:cp t415 set from storage commerce:l t
data modify storage commerce:cp tc415 set from storage commerce:l tc
scoreboard players set #i c.t 416
function commerce:page/ligne
data modify storage commerce:cp ve416 set from storage commerce:l ve
data modify storage commerce:cp vz416 set from storage commerce:l vz
data modify storage commerce:cp vc416 set from storage commerce:l vc
data modify storage commerce:cp ae416 set from storage commerce:l ae
data modify storage commerce:cp az416 set from storage commerce:l az
data modify storage commerce:cp ac416 set from storage commerce:l ac
data modify storage commerce:cp t416 set from storage commerce:l t
data modify storage commerce:cp tc416 set from storage commerce:l tc
scoreboard players set #i c.t 417
function commerce:page/ligne
data modify storage commerce:cp ve417 set from storage commerce:l ve
data modify storage commerce:cp vz417 set from storage commerce:l vz
data modify storage commerce:cp vc417 set from storage commerce:l vc
data modify storage commerce:cp ae417 set from storage commerce:l ae
data modify storage commerce:cp az417 set from storage commerce:l az
data modify storage commerce:cp ac417 set from storage commerce:l ac
data modify storage commerce:cp t417 set from storage commerce:l t
data modify storage commerce:cp tc417 set from storage commerce:l tc
scoreboard players set #i c.t 418
function commerce:page/ligne
data modify storage commerce:cp ve418 set from storage commerce:l ve
data modify storage commerce:cp vz418 set from storage commerce:l vz
data modify storage commerce:cp vc418 set from storage commerce:l vc
data modify storage commerce:cp ae418 set from storage commerce:l ae
data modify storage commerce:cp az418 set from storage commerce:l az
data modify storage commerce:cp ac418 set from storage commerce:l ac
data modify storage commerce:cp t418 set from storage commerce:l t
data modify storage commerce:cp tc418 set from storage commerce:l tc
scoreboard players set #i c.t 419
function commerce:page/ligne
data modify storage commerce:cp ve419 set from storage commerce:l ve
data modify storage commerce:cp vz419 set from storage commerce:l vz
data modify storage commerce:cp vc419 set from storage commerce:l vc
data modify storage commerce:cp ae419 set from storage commerce:l ae
data modify storage commerce:cp az419 set from storage commerce:l az
data modify storage commerce:cp ac419 set from storage commerce:l ac
data modify storage commerce:cp t419 set from storage commerce:l t
data modify storage commerce:cp tc419 set from storage commerce:l tc
scoreboard players set #i c.t 420
function commerce:page/ligne
data modify storage commerce:cp ve420 set from storage commerce:l ve
data modify storage commerce:cp vz420 set from storage commerce:l vz
data modify storage commerce:cp vc420 set from storage commerce:l vc
data modify storage commerce:cp ae420 set from storage commerce:l ae
data modify storage commerce:cp az420 set from storage commerce:l az
data modify storage commerce:cp ac420 set from storage commerce:l ac
data modify storage commerce:cp t420 set from storage commerce:l t
data modify storage commerce:cp tc420 set from storage commerce:l tc
scoreboard players set #i c.t 421
function commerce:page/ligne
data modify storage commerce:cp ve421 set from storage commerce:l ve
data modify storage commerce:cp vz421 set from storage commerce:l vz
data modify storage commerce:cp vc421 set from storage commerce:l vc
data modify storage commerce:cp ae421 set from storage commerce:l ae
data modify storage commerce:cp az421 set from storage commerce:l az
data modify storage commerce:cp ac421 set from storage commerce:l ac
data modify storage commerce:cp t421 set from storage commerce:l t
data modify storage commerce:cp tc421 set from storage commerce:l tc
scoreboard players set #i c.t 422
function commerce:page/ligne
data modify storage commerce:cp ve422 set from storage commerce:l ve
data modify storage commerce:cp vz422 set from storage commerce:l vz
data modify storage commerce:cp vc422 set from storage commerce:l vc
data modify storage commerce:cp ae422 set from storage commerce:l ae
data modify storage commerce:cp az422 set from storage commerce:l az
data modify storage commerce:cp ac422 set from storage commerce:l ac
data modify storage commerce:cp t422 set from storage commerce:l t
data modify storage commerce:cp tc422 set from storage commerce:l tc
scoreboard players set #i c.t 423
function commerce:page/ligne
data modify storage commerce:cp ve423 set from storage commerce:l ve
data modify storage commerce:cp vz423 set from storage commerce:l vz
data modify storage commerce:cp vc423 set from storage commerce:l vc
data modify storage commerce:cp ae423 set from storage commerce:l ae
data modify storage commerce:cp az423 set from storage commerce:l az
data modify storage commerce:cp ac423 set from storage commerce:l ac
data modify storage commerce:cp t423 set from storage commerce:l t
data modify storage commerce:cp tc423 set from storage commerce:l tc
scoreboard players set #i c.t 424
function commerce:page/ligne
data modify storage commerce:cp ve424 set from storage commerce:l ve
data modify storage commerce:cp vz424 set from storage commerce:l vz
data modify storage commerce:cp vc424 set from storage commerce:l vc
data modify storage commerce:cp ae424 set from storage commerce:l ae
data modify storage commerce:cp az424 set from storage commerce:l az
data modify storage commerce:cp ac424 set from storage commerce:l ac
data modify storage commerce:cp t424 set from storage commerce:l t
data modify storage commerce:cp tc424 set from storage commerce:l tc
scoreboard players set #i c.t 425
function commerce:page/ligne
data modify storage commerce:cp ve425 set from storage commerce:l ve
data modify storage commerce:cp vz425 set from storage commerce:l vz
data modify storage commerce:cp vc425 set from storage commerce:l vc
data modify storage commerce:cp ae425 set from storage commerce:l ae
data modify storage commerce:cp az425 set from storage commerce:l az
data modify storage commerce:cp ac425 set from storage commerce:l ac
data modify storage commerce:cp t425 set from storage commerce:l t
data modify storage commerce:cp tc425 set from storage commerce:l tc
scoreboard players set #i c.t 426
function commerce:page/ligne
data modify storage commerce:cp ve426 set from storage commerce:l ve
data modify storage commerce:cp vz426 set from storage commerce:l vz
data modify storage commerce:cp vc426 set from storage commerce:l vc
data modify storage commerce:cp ae426 set from storage commerce:l ae
data modify storage commerce:cp az426 set from storage commerce:l az
data modify storage commerce:cp ac426 set from storage commerce:l ac
data modify storage commerce:cp t426 set from storage commerce:l t
data modify storage commerce:cp tc426 set from storage commerce:l tc
scoreboard players set #i c.t 427
function commerce:page/ligne
data modify storage commerce:cp ve427 set from storage commerce:l ve
data modify storage commerce:cp vz427 set from storage commerce:l vz
data modify storage commerce:cp vc427 set from storage commerce:l vc
data modify storage commerce:cp ae427 set from storage commerce:l ae
data modify storage commerce:cp az427 set from storage commerce:l az
data modify storage commerce:cp ac427 set from storage commerce:l ac
data modify storage commerce:cp t427 set from storage commerce:l t
data modify storage commerce:cp tc427 set from storage commerce:l tc
scoreboard players set #i c.t 428
function commerce:page/ligne
data modify storage commerce:cp ve428 set from storage commerce:l ve
data modify storage commerce:cp vz428 set from storage commerce:l vz
data modify storage commerce:cp vc428 set from storage commerce:l vc
data modify storage commerce:cp ae428 set from storage commerce:l ae
data modify storage commerce:cp az428 set from storage commerce:l az
data modify storage commerce:cp ac428 set from storage commerce:l ac
data modify storage commerce:cp t428 set from storage commerce:l t
data modify storage commerce:cp tc428 set from storage commerce:l tc
scoreboard players set #i c.t 429
function commerce:page/ligne
data modify storage commerce:cp ve429 set from storage commerce:l ve
data modify storage commerce:cp vz429 set from storage commerce:l vz
data modify storage commerce:cp vc429 set from storage commerce:l vc
data modify storage commerce:cp ae429 set from storage commerce:l ae
data modify storage commerce:cp az429 set from storage commerce:l az
data modify storage commerce:cp ac429 set from storage commerce:l ac
data modify storage commerce:cp t429 set from storage commerce:l t
data modify storage commerce:cp tc429 set from storage commerce:l tc
scoreboard players set #i c.t 430
function commerce:page/ligne
data modify storage commerce:cp ve430 set from storage commerce:l ve
data modify storage commerce:cp vz430 set from storage commerce:l vz
data modify storage commerce:cp vc430 set from storage commerce:l vc
data modify storage commerce:cp ae430 set from storage commerce:l ae
data modify storage commerce:cp az430 set from storage commerce:l az
data modify storage commerce:cp ac430 set from storage commerce:l ac
data modify storage commerce:cp t430 set from storage commerce:l t
data modify storage commerce:cp tc430 set from storage commerce:l tc
function commerce:page/cat_16_d with storage commerce:cp
