function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 465
function commerce:page/ligne
data modify storage commerce:cp ve465 set from storage commerce:l ve
data modify storage commerce:cp vz465 set from storage commerce:l vz
data modify storage commerce:cp vc465 set from storage commerce:l vc
data modify storage commerce:cp ae465 set from storage commerce:l ae
data modify storage commerce:cp az465 set from storage commerce:l az
data modify storage commerce:cp ac465 set from storage commerce:l ac
data modify storage commerce:cp t465 set from storage commerce:l t
scoreboard players set #i c.t 423
function commerce:page/ligne
data modify storage commerce:cp ve423 set from storage commerce:l ve
data modify storage commerce:cp vz423 set from storage commerce:l vz
data modify storage commerce:cp vc423 set from storage commerce:l vc
data modify storage commerce:cp ae423 set from storage commerce:l ae
data modify storage commerce:cp az423 set from storage commerce:l az
data modify storage commerce:cp ac423 set from storage commerce:l ac
data modify storage commerce:cp t423 set from storage commerce:l t
scoreboard players set #i c.t 405
function commerce:page/ligne
data modify storage commerce:cp ve405 set from storage commerce:l ve
data modify storage commerce:cp vz405 set from storage commerce:l vz
data modify storage commerce:cp vc405 set from storage commerce:l vc
data modify storage commerce:cp ae405 set from storage commerce:l ae
data modify storage commerce:cp az405 set from storage commerce:l az
data modify storage commerce:cp ac405 set from storage commerce:l ac
data modify storage commerce:cp t405 set from storage commerce:l t
function commerce:page/lettre_h_0_d with storage commerce:cp
