function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 421
function commerce:page/ligne
data modify storage commerce:cp ve421 set from storage commerce:l ve
data modify storage commerce:cp vz421 set from storage commerce:l vz
data modify storage commerce:cp vc421 set from storage commerce:l vc
data modify storage commerce:cp ae421 set from storage commerce:l ae
data modify storage commerce:cp az421 set from storage commerce:l az
data modify storage commerce:cp ac421 set from storage commerce:l ac
data modify storage commerce:cp t421 set from storage commerce:l t
scoreboard players set #i c.t 403
function commerce:page/ligne
data modify storage commerce:cp ve403 set from storage commerce:l ve
data modify storage commerce:cp vz403 set from storage commerce:l vz
data modify storage commerce:cp vc403 set from storage commerce:l vc
data modify storage commerce:cp ae403 set from storage commerce:l ae
data modify storage commerce:cp az403 set from storage commerce:l az
data modify storage commerce:cp ac403 set from storage commerce:l ac
data modify storage commerce:cp t403 set from storage commerce:l t
function commerce:page/lettre_h_0_d with storage commerce:cp
