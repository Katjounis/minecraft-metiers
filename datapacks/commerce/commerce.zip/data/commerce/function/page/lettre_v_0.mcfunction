function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 187
function commerce:page/ligne
data modify storage commerce:cp ve187 set from storage commerce:l ve
data modify storage commerce:cp vz187 set from storage commerce:l vz
data modify storage commerce:cp vc187 set from storage commerce:l vc
data modify storage commerce:cp ae187 set from storage commerce:l ae
data modify storage commerce:cp az187 set from storage commerce:l az
data modify storage commerce:cp ac187 set from storage commerce:l ac
data modify storage commerce:cp t187 set from storage commerce:l t
scoreboard players set #i c.t 189
function commerce:page/ligne
data modify storage commerce:cp ve189 set from storage commerce:l ve
data modify storage commerce:cp vz189 set from storage commerce:l vz
data modify storage commerce:cp vc189 set from storage commerce:l vc
data modify storage commerce:cp ae189 set from storage commerce:l ae
data modify storage commerce:cp az189 set from storage commerce:l az
data modify storage commerce:cp ac189 set from storage commerce:l ac
data modify storage commerce:cp t189 set from storage commerce:l t
scoreboard players set #i c.t 200
function commerce:page/ligne
data modify storage commerce:cp ve200 set from storage commerce:l ve
data modify storage commerce:cp vz200 set from storage commerce:l vz
data modify storage commerce:cp vc200 set from storage commerce:l vc
data modify storage commerce:cp ae200 set from storage commerce:l ae
data modify storage commerce:cp az200 set from storage commerce:l az
data modify storage commerce:cp ac200 set from storage commerce:l ac
data modify storage commerce:cp t200 set from storage commerce:l t
scoreboard players set #i c.t 192
function commerce:page/ligne
data modify storage commerce:cp ve192 set from storage commerce:l ve
data modify storage commerce:cp vz192 set from storage commerce:l vz
data modify storage commerce:cp vc192 set from storage commerce:l vc
data modify storage commerce:cp ae192 set from storage commerce:l ae
data modify storage commerce:cp az192 set from storage commerce:l az
data modify storage commerce:cp ac192 set from storage commerce:l ac
data modify storage commerce:cp t192 set from storage commerce:l t
scoreboard players set #i c.t 198
function commerce:page/ligne
data modify storage commerce:cp ve198 set from storage commerce:l ve
data modify storage commerce:cp vz198 set from storage commerce:l vz
data modify storage commerce:cp vc198 set from storage commerce:l vc
data modify storage commerce:cp ae198 set from storage commerce:l ae
data modify storage commerce:cp az198 set from storage commerce:l az
data modify storage commerce:cp ac198 set from storage commerce:l ac
data modify storage commerce:cp t198 set from storage commerce:l t
scoreboard players set #i c.t 196
function commerce:page/ligne
data modify storage commerce:cp ve196 set from storage commerce:l ve
data modify storage commerce:cp vz196 set from storage commerce:l vz
data modify storage commerce:cp vc196 set from storage commerce:l vc
data modify storage commerce:cp ae196 set from storage commerce:l ae
data modify storage commerce:cp az196 set from storage commerce:l az
data modify storage commerce:cp ac196 set from storage commerce:l ac
data modify storage commerce:cp t196 set from storage commerce:l t
scoreboard players set #i c.t 197
function commerce:page/ligne
data modify storage commerce:cp ve197 set from storage commerce:l ve
data modify storage commerce:cp vz197 set from storage commerce:l vz
data modify storage commerce:cp vc197 set from storage commerce:l vc
data modify storage commerce:cp ae197 set from storage commerce:l ae
data modify storage commerce:cp az197 set from storage commerce:l az
data modify storage commerce:cp ac197 set from storage commerce:l ac
data modify storage commerce:cp t197 set from storage commerce:l t
scoreboard players set #i c.t 193
function commerce:page/ligne
data modify storage commerce:cp ve193 set from storage commerce:l ve
data modify storage commerce:cp vz193 set from storage commerce:l vz
data modify storage commerce:cp vc193 set from storage commerce:l vc
data modify storage commerce:cp ae193 set from storage commerce:l ae
data modify storage commerce:cp az193 set from storage commerce:l az
data modify storage commerce:cp ac193 set from storage commerce:l ac
data modify storage commerce:cp t193 set from storage commerce:l t
scoreboard players set #i c.t 191
function commerce:page/ligne
data modify storage commerce:cp ve191 set from storage commerce:l ve
data modify storage commerce:cp vz191 set from storage commerce:l vz
data modify storage commerce:cp vc191 set from storage commerce:l vc
data modify storage commerce:cp ae191 set from storage commerce:l ae
data modify storage commerce:cp az191 set from storage commerce:l az
data modify storage commerce:cp ac191 set from storage commerce:l ac
data modify storage commerce:cp t191 set from storage commerce:l t
scoreboard players set #i c.t 201
function commerce:page/ligne
data modify storage commerce:cp ve201 set from storage commerce:l ve
data modify storage commerce:cp vz201 set from storage commerce:l vz
data modify storage commerce:cp vc201 set from storage commerce:l vc
data modify storage commerce:cp ae201 set from storage commerce:l ae
data modify storage commerce:cp az201 set from storage commerce:l az
data modify storage commerce:cp ac201 set from storage commerce:l ac
data modify storage commerce:cp t201 set from storage commerce:l t
function commerce:page/lettre_v_0_d with storage commerce:cp
