function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 221
function commerce:page/ligne
data modify storage commerce:cp ve221 set from storage commerce:l ve
data modify storage commerce:cp vz221 set from storage commerce:l vz
data modify storage commerce:cp vc221 set from storage commerce:l vc
data modify storage commerce:cp ae221 set from storage commerce:l ae
data modify storage commerce:cp az221 set from storage commerce:l az
data modify storage commerce:cp ac221 set from storage commerce:l ac
data modify storage commerce:cp t221 set from storage commerce:l t
scoreboard players set #i c.t 222
function commerce:page/ligne
data modify storage commerce:cp ve222 set from storage commerce:l ve
data modify storage commerce:cp vz222 set from storage commerce:l vz
data modify storage commerce:cp vc222 set from storage commerce:l vc
data modify storage commerce:cp ae222 set from storage commerce:l ae
data modify storage commerce:cp az222 set from storage commerce:l az
data modify storage commerce:cp ac222 set from storage commerce:l ac
data modify storage commerce:cp t222 set from storage commerce:l t
scoreboard players set #i c.t 223
function commerce:page/ligne
data modify storage commerce:cp ve223 set from storage commerce:l ve
data modify storage commerce:cp vz223 set from storage commerce:l vz
data modify storage commerce:cp vc223 set from storage commerce:l vc
data modify storage commerce:cp ae223 set from storage commerce:l ae
data modify storage commerce:cp az223 set from storage commerce:l az
data modify storage commerce:cp ac223 set from storage commerce:l ac
data modify storage commerce:cp t223 set from storage commerce:l t
scoreboard players set #i c.t 224
function commerce:page/ligne
data modify storage commerce:cp ve224 set from storage commerce:l ve
data modify storage commerce:cp vz224 set from storage commerce:l vz
data modify storage commerce:cp vc224 set from storage commerce:l vc
data modify storage commerce:cp ae224 set from storage commerce:l ae
data modify storage commerce:cp az224 set from storage commerce:l az
data modify storage commerce:cp ac224 set from storage commerce:l ac
data modify storage commerce:cp t224 set from storage commerce:l t
scoreboard players set #i c.t 225
function commerce:page/ligne
data modify storage commerce:cp ve225 set from storage commerce:l ve
data modify storage commerce:cp vz225 set from storage commerce:l vz
data modify storage commerce:cp vc225 set from storage commerce:l vc
data modify storage commerce:cp ae225 set from storage commerce:l ae
data modify storage commerce:cp az225 set from storage commerce:l az
data modify storage commerce:cp ac225 set from storage commerce:l ac
data modify storage commerce:cp t225 set from storage commerce:l t
scoreboard players set #i c.t 226
function commerce:page/ligne
data modify storage commerce:cp ve226 set from storage commerce:l ve
data modify storage commerce:cp vz226 set from storage commerce:l vz
data modify storage commerce:cp vc226 set from storage commerce:l vc
data modify storage commerce:cp ae226 set from storage commerce:l ae
data modify storage commerce:cp az226 set from storage commerce:l az
data modify storage commerce:cp ac226 set from storage commerce:l ac
data modify storage commerce:cp t226 set from storage commerce:l t
scoreboard players set #i c.t 227
function commerce:page/ligne
data modify storage commerce:cp ve227 set from storage commerce:l ve
data modify storage commerce:cp vz227 set from storage commerce:l vz
data modify storage commerce:cp vc227 set from storage commerce:l vc
data modify storage commerce:cp ae227 set from storage commerce:l ae
data modify storage commerce:cp az227 set from storage commerce:l az
data modify storage commerce:cp ac227 set from storage commerce:l ac
data modify storage commerce:cp t227 set from storage commerce:l t
scoreboard players set #i c.t 228
function commerce:page/ligne
data modify storage commerce:cp ve228 set from storage commerce:l ve
data modify storage commerce:cp vz228 set from storage commerce:l vz
data modify storage commerce:cp vc228 set from storage commerce:l vc
data modify storage commerce:cp ae228 set from storage commerce:l ae
data modify storage commerce:cp az228 set from storage commerce:l az
data modify storage commerce:cp ac228 set from storage commerce:l ac
data modify storage commerce:cp t228 set from storage commerce:l t
scoreboard players set #i c.t 229
function commerce:page/ligne
data modify storage commerce:cp ve229 set from storage commerce:l ve
data modify storage commerce:cp vz229 set from storage commerce:l vz
data modify storage commerce:cp vc229 set from storage commerce:l vc
data modify storage commerce:cp ae229 set from storage commerce:l ae
data modify storage commerce:cp az229 set from storage commerce:l az
data modify storage commerce:cp ac229 set from storage commerce:l ac
data modify storage commerce:cp t229 set from storage commerce:l t
scoreboard players set #i c.t 230
function commerce:page/ligne
data modify storage commerce:cp ve230 set from storage commerce:l ve
data modify storage commerce:cp vz230 set from storage commerce:l vz
data modify storage commerce:cp vc230 set from storage commerce:l vc
data modify storage commerce:cp ae230 set from storage commerce:l ae
data modify storage commerce:cp az230 set from storage commerce:l az
data modify storage commerce:cp ac230 set from storage commerce:l ac
data modify storage commerce:cp t230 set from storage commerce:l t
function commerce:page/cat_8_0_d with storage commerce:cp
