function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 299
function commerce:page/ligne
data modify storage commerce:cp ve299 set from storage commerce:l ve
data modify storage commerce:cp vz299 set from storage commerce:l vz
data modify storage commerce:cp vc299 set from storage commerce:l vc
data modify storage commerce:cp ae299 set from storage commerce:l ae
data modify storage commerce:cp az299 set from storage commerce:l az
data modify storage commerce:cp ac299 set from storage commerce:l ac
data modify storage commerce:cp t299 set from storage commerce:l t
scoreboard players set #i c.t 300
function commerce:page/ligne
data modify storage commerce:cp ve300 set from storage commerce:l ve
data modify storage commerce:cp vz300 set from storage commerce:l vz
data modify storage commerce:cp vc300 set from storage commerce:l vc
data modify storage commerce:cp ae300 set from storage commerce:l ae
data modify storage commerce:cp az300 set from storage commerce:l az
data modify storage commerce:cp ac300 set from storage commerce:l ac
data modify storage commerce:cp t300 set from storage commerce:l t
scoreboard players set #i c.t 301
function commerce:page/ligne
data modify storage commerce:cp ve301 set from storage commerce:l ve
data modify storage commerce:cp vz301 set from storage commerce:l vz
data modify storage commerce:cp vc301 set from storage commerce:l vc
data modify storage commerce:cp ae301 set from storage commerce:l ae
data modify storage commerce:cp az301 set from storage commerce:l az
data modify storage commerce:cp ac301 set from storage commerce:l ac
data modify storage commerce:cp t301 set from storage commerce:l t
function commerce:page/cat_10_2_d with storage commerce:cp
