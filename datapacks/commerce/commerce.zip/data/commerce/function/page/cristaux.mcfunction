function commerce:fmt/solde
data modify storage commerce:cr se set from storage commerce:t s.e
data modify storage commerce:cr sz set from storage commerce:t s.z
data modify storage commerce:cr sc set from storage commerce:t s.c
function commerce:cristal/prix
execute store result storage commerce:cr p int 1 run scoreboard players get #cp c.t
execute store result storage commerce:cr n int 1 run scoreboard players get @s c.ncr
execute store result storage commerce:cr b int 1 run scoreboard players get @s m.cr_b
execute store result storage commerce:cr f int 1 run scoreboard players get @s m.cr_f
execute store result storage commerce:cr m int 1 run scoreboard players get @s m.cr_m
execute store result storage commerce:cr c int 1 run scoreboard players get @s m.cr_c
execute store result storage commerce:cr p int 1 run scoreboard players get @s m.cr_p
execute store result storage commerce:cr e int 1 run scoreboard players get @s m.cr_e
execute store result storage commerce:cr n int 1 run scoreboard players get @s m.cr_n
execute store result storage commerce:cr x int 1 run scoreboard players get @s m.cr_x
execute store result storage commerce:cr t int 1 run scoreboard players get @s m.cr_t
data modify storage commerce:cr msg set from storage commerce:t msg
data modify storage commerce:t msg set value ""
function commerce:page/cristaux_d with storage commerce:cr
