scoreboard players set #btot c.t 0
scoreboard players set #lot c.t 1
execute unless items entity @s container.* minecraft:poppy[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:poppy[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:poppy[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 401
execute if items entity @s weapon.offhand minecraft:poppy[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 401
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:dandelion[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:dandelion[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:dandelion[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 402
execute if items entity @s weapon.offhand minecraft:dandelion[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 402
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:blue_orchid[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:blue_orchid[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:blue_orchid[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 403
execute if items entity @s weapon.offhand minecraft:blue_orchid[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 403
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:allium[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:allium[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:allium[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 404
execute if items entity @s weapon.offhand minecraft:allium[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 404
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:azure_bluet[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:azure_bluet[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:azure_bluet[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 405
execute if items entity @s weapon.offhand minecraft:azure_bluet[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 405
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:red_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:red_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:red_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 406
execute if items entity @s weapon.offhand minecraft:red_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 406
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:orange_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:orange_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:orange_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 407
execute if items entity @s weapon.offhand minecraft:orange_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 407
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:white_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:white_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:white_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 408
execute if items entity @s weapon.offhand minecraft:white_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 408
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:pink_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:pink_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:pink_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 409
execute if items entity @s weapon.offhand minecraft:pink_tulip[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 409
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:oxeye_daisy[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:oxeye_daisy[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:oxeye_daisy[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 410
execute if items entity @s weapon.offhand minecraft:oxeye_daisy[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 410
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:cornflower[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cornflower[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cornflower[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 411
execute if items entity @s weapon.offhand minecraft:cornflower[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 411
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:lily_of_the_valley[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:lily_of_the_valley[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:lily_of_the_valley[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 412
execute if items entity @s weapon.offhand minecraft:lily_of_the_valley[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 412
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:sunflower[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:sunflower[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:sunflower[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 413
execute if items entity @s weapon.offhand minecraft:sunflower[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 413
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:lilac[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:lilac[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:lilac[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 414
execute if items entity @s weapon.offhand minecraft:lilac[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 414
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:rose_bush[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:rose_bush[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:rose_bush[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 415
execute if items entity @s weapon.offhand minecraft:rose_bush[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 415
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:peony[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:peony[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:peony[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 416
execute if items entity @s weapon.offhand minecraft:peony[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 416
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:pink_petals[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:pink_petals[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:pink_petals[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 417
execute if items entity @s weapon.offhand minecraft:pink_petals[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 417
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:wildflowers[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:wildflowers[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:wildflowers[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 418
execute if items entity @s weapon.offhand minecraft:wildflowers[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 418
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:cactus_flower[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:cactus_flower[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:cactus_flower[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 419
execute if items entity @s weapon.offhand minecraft:cactus_flower[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 419
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:firefly_bush[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:firefly_bush[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:firefly_bush[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 420
execute if items entity @s weapon.offhand minecraft:firefly_bush[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 420
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:vine[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:vine[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:vine[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 421
execute if items entity @s weapon.offhand minecraft:vine[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 421
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:fern[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:fern[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:fern[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 422
execute if items entity @s weapon.offhand minecraft:fern[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 422
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:short_grass[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:short_grass[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:short_grass[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 423
execute if items entity @s weapon.offhand minecraft:short_grass[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 423
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:dead_bush[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:dead_bush[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:dead_bush[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 424
execute if items entity @s weapon.offhand minecraft:dead_bush[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 424
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:leaf_litter[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:leaf_litter[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:leaf_litter[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 425
execute if items entity @s weapon.offhand minecraft:leaf_litter[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 425
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:brown_mushroom[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:brown_mushroom[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:brown_mushroom[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 426
execute if items entity @s weapon.offhand minecraft:brown_mushroom[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 426
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:red_mushroom[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:red_mushroom[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:red_mushroom[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 427
execute if items entity @s weapon.offhand minecraft:red_mushroom[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 427
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:glow_lichen[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:glow_lichen[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:glow_lichen[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 428
execute if items entity @s weapon.offhand minecraft:glow_lichen[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 428
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:azalea[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:azalea[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:azalea[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 429
execute if items entity @s weapon.offhand minecraft:azalea[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 429
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
execute unless items entity @s container.* minecraft:spore_blossom[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] unless items entity @s weapon.offhand minecraft:spore_blossom[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 0
execute if items entity @s container.* minecraft:spore_blossom[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 430
execute if items entity @s weapon.offhand minecraft:spore_blossom[!minecraft:custom_data,!minecraft:custom_name,minecraft:lore=[]] run scoreboard players set #i c.t 430
scoreboard players set #tot c.t 0
scoreboard players set #act c.t 3
scoreboard players set #q c.t 0
execute if score #i c.t matches 1.. run function commerce:op/vendre
scoreboard players operation #btot c.t += #tot c.t
scoreboard players set #lot c.t 0
scoreboard players operation #btot c.t /= #100 c.g
execute if score #btot c.t matches ..0 run tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Rien à vendre dans cette catégorie (les objets renommés ou spéciaux sont gardés).",color:"red",bold:false,italic:false}]
execute if score #btot c.t matches 1.. run tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Fleurs et plantes vendu en entier : ",color:"gray",bold:false,italic:false},{score:{name:"#btot",objective:"c.t"},color:"gold",bold:true},{text:" Écus",color:"gold",bold:false,italic:false}]
execute if score #btot c.t matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.7 1.4
function commerce:page/cat_16_0
