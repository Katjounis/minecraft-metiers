function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 41
function commerce:page/ligne
data modify storage commerce:cp ve41 set from storage commerce:l ve
data modify storage commerce:cp vz41 set from storage commerce:l vz
data modify storage commerce:cp vc41 set from storage commerce:l vc
data modify storage commerce:cp ae41 set from storage commerce:l ae
data modify storage commerce:cp az41 set from storage commerce:l az
data modify storage commerce:cp ac41 set from storage commerce:l ac
data modify storage commerce:cp t41 set from storage commerce:l t
scoreboard players set #i c.t 42
function commerce:page/ligne
data modify storage commerce:cp ve42 set from storage commerce:l ve
data modify storage commerce:cp vz42 set from storage commerce:l vz
data modify storage commerce:cp vc42 set from storage commerce:l vc
data modify storage commerce:cp ae42 set from storage commerce:l ae
data modify storage commerce:cp az42 set from storage commerce:l az
data modify storage commerce:cp ac42 set from storage commerce:l ac
data modify storage commerce:cp t42 set from storage commerce:l t
scoreboard players set #i c.t 43
function commerce:page/ligne
data modify storage commerce:cp ve43 set from storage commerce:l ve
data modify storage commerce:cp vz43 set from storage commerce:l vz
data modify storage commerce:cp vc43 set from storage commerce:l vc
data modify storage commerce:cp ae43 set from storage commerce:l ae
data modify storage commerce:cp az43 set from storage commerce:l az
data modify storage commerce:cp ac43 set from storage commerce:l ac
data modify storage commerce:cp t43 set from storage commerce:l t
scoreboard players set #i c.t 44
function commerce:page/ligne
data modify storage commerce:cp ve44 set from storage commerce:l ve
data modify storage commerce:cp vz44 set from storage commerce:l vz
data modify storage commerce:cp vc44 set from storage commerce:l vc
data modify storage commerce:cp ae44 set from storage commerce:l ae
data modify storage commerce:cp az44 set from storage commerce:l az
data modify storage commerce:cp ac44 set from storage commerce:l ac
data modify storage commerce:cp t44 set from storage commerce:l t
function commerce:page/cat_1_4_d with storage commerce:cp
