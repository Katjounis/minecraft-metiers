function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 431
function commerce:page/ligne
data modify storage commerce:cp ve431 set from storage commerce:l ve
data modify storage commerce:cp vz431 set from storage commerce:l vz
data modify storage commerce:cp vc431 set from storage commerce:l vc
data modify storage commerce:cp ae431 set from storage commerce:l ae
data modify storage commerce:cp az431 set from storage commerce:l az
data modify storage commerce:cp ac431 set from storage commerce:l ac
data modify storage commerce:cp t431 set from storage commerce:l t
scoreboard players set #i c.t 432
function commerce:page/ligne
data modify storage commerce:cp ve432 set from storage commerce:l ve
data modify storage commerce:cp vz432 set from storage commerce:l vz
data modify storage commerce:cp vc432 set from storage commerce:l vc
data modify storage commerce:cp ae432 set from storage commerce:l ae
data modify storage commerce:cp az432 set from storage commerce:l az
data modify storage commerce:cp ac432 set from storage commerce:l ac
data modify storage commerce:cp t432 set from storage commerce:l t
scoreboard players set #i c.t 433
function commerce:page/ligne
data modify storage commerce:cp ve433 set from storage commerce:l ve
data modify storage commerce:cp vz433 set from storage commerce:l vz
data modify storage commerce:cp vc433 set from storage commerce:l vc
data modify storage commerce:cp ae433 set from storage commerce:l ae
data modify storage commerce:cp az433 set from storage commerce:l az
data modify storage commerce:cp ac433 set from storage commerce:l ac
data modify storage commerce:cp t433 set from storage commerce:l t
scoreboard players set #i c.t 434
function commerce:page/ligne
data modify storage commerce:cp ve434 set from storage commerce:l ve
data modify storage commerce:cp vz434 set from storage commerce:l vz
data modify storage commerce:cp vc434 set from storage commerce:l vc
data modify storage commerce:cp ae434 set from storage commerce:l ae
data modify storage commerce:cp az434 set from storage commerce:l az
data modify storage commerce:cp ac434 set from storage commerce:l ac
data modify storage commerce:cp t434 set from storage commerce:l t
scoreboard players set #i c.t 435
function commerce:page/ligne
data modify storage commerce:cp ve435 set from storage commerce:l ve
data modify storage commerce:cp vz435 set from storage commerce:l vz
data modify storage commerce:cp vc435 set from storage commerce:l vc
data modify storage commerce:cp ae435 set from storage commerce:l ae
data modify storage commerce:cp az435 set from storage commerce:l az
data modify storage commerce:cp ac435 set from storage commerce:l ac
data modify storage commerce:cp t435 set from storage commerce:l t
scoreboard players set #i c.t 436
function commerce:page/ligne
data modify storage commerce:cp ve436 set from storage commerce:l ve
data modify storage commerce:cp vz436 set from storage commerce:l vz
data modify storage commerce:cp vc436 set from storage commerce:l vc
data modify storage commerce:cp ae436 set from storage commerce:l ae
data modify storage commerce:cp az436 set from storage commerce:l az
data modify storage commerce:cp ac436 set from storage commerce:l ac
data modify storage commerce:cp t436 set from storage commerce:l t
scoreboard players set #i c.t 437
function commerce:page/ligne
data modify storage commerce:cp ve437 set from storage commerce:l ve
data modify storage commerce:cp vz437 set from storage commerce:l vz
data modify storage commerce:cp vc437 set from storage commerce:l vc
data modify storage commerce:cp ae437 set from storage commerce:l ae
data modify storage commerce:cp az437 set from storage commerce:l az
data modify storage commerce:cp ac437 set from storage commerce:l ac
data modify storage commerce:cp t437 set from storage commerce:l t
scoreboard players set #i c.t 438
function commerce:page/ligne
data modify storage commerce:cp ve438 set from storage commerce:l ve
data modify storage commerce:cp vz438 set from storage commerce:l vz
data modify storage commerce:cp vc438 set from storage commerce:l vc
data modify storage commerce:cp ae438 set from storage commerce:l ae
data modify storage commerce:cp az438 set from storage commerce:l az
data modify storage commerce:cp ac438 set from storage commerce:l ac
data modify storage commerce:cp t438 set from storage commerce:l t
scoreboard players set #i c.t 439
function commerce:page/ligne
data modify storage commerce:cp ve439 set from storage commerce:l ve
data modify storage commerce:cp vz439 set from storage commerce:l vz
data modify storage commerce:cp vc439 set from storage commerce:l vc
data modify storage commerce:cp ae439 set from storage commerce:l ae
data modify storage commerce:cp az439 set from storage commerce:l az
data modify storage commerce:cp ac439 set from storage commerce:l ac
data modify storage commerce:cp t439 set from storage commerce:l t
scoreboard players set #i c.t 440
function commerce:page/ligne
data modify storage commerce:cp ve440 set from storage commerce:l ve
data modify storage commerce:cp vz440 set from storage commerce:l vz
data modify storage commerce:cp vc440 set from storage commerce:l vc
data modify storage commerce:cp ae440 set from storage commerce:l ae
data modify storage commerce:cp az440 set from storage commerce:l az
data modify storage commerce:cp ac440 set from storage commerce:l ac
data modify storage commerce:cp t440 set from storage commerce:l t
function commerce:page/cat_15_0_d with storage commerce:cp
