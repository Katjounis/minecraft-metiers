function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 352
function commerce:page/ligne
data modify storage commerce:cp ve352 set from storage commerce:l ve
data modify storage commerce:cp vz352 set from storage commerce:l vz
data modify storage commerce:cp vc352 set from storage commerce:l vc
data modify storage commerce:cp ae352 set from storage commerce:l ae
data modify storage commerce:cp az352 set from storage commerce:l az
data modify storage commerce:cp ac352 set from storage commerce:l ac
data modify storage commerce:cp t352 set from storage commerce:l t
scoreboard players set #i c.t 376
function commerce:page/ligne
data modify storage commerce:cp ve376 set from storage commerce:l ve
data modify storage commerce:cp vz376 set from storage commerce:l vz
data modify storage commerce:cp vc376 set from storage commerce:l vc
data modify storage commerce:cp ae376 set from storage commerce:l ae
data modify storage commerce:cp az376 set from storage commerce:l az
data modify storage commerce:cp ac376 set from storage commerce:l ac
data modify storage commerce:cp t376 set from storage commerce:l t
scoreboard players set #i c.t 377
function commerce:page/ligne
data modify storage commerce:cp ve377 set from storage commerce:l ve
data modify storage commerce:cp vz377 set from storage commerce:l vz
data modify storage commerce:cp vc377 set from storage commerce:l vc
data modify storage commerce:cp ae377 set from storage commerce:l ae
data modify storage commerce:cp az377 set from storage commerce:l az
data modify storage commerce:cp ac377 set from storage commerce:l ac
data modify storage commerce:cp t377 set from storage commerce:l t
scoreboard players set #i c.t 314
function commerce:page/ligne
data modify storage commerce:cp ve314 set from storage commerce:l ve
data modify storage commerce:cp vz314 set from storage commerce:l vz
data modify storage commerce:cp vc314 set from storage commerce:l vc
data modify storage commerce:cp ae314 set from storage commerce:l ae
data modify storage commerce:cp az314 set from storage commerce:l az
data modify storage commerce:cp ac314 set from storage commerce:l ac
data modify storage commerce:cp t314 set from storage commerce:l t
scoreboard players set #i c.t 385
function commerce:page/ligne
data modify storage commerce:cp ve385 set from storage commerce:l ve
data modify storage commerce:cp vz385 set from storage commerce:l vz
data modify storage commerce:cp vc385 set from storage commerce:l vc
data modify storage commerce:cp ae385 set from storage commerce:l ae
data modify storage commerce:cp az385 set from storage commerce:l az
data modify storage commerce:cp ac385 set from storage commerce:l ac
data modify storage commerce:cp t385 set from storage commerce:l t
scoreboard players set #i c.t 3
function commerce:page/ligne
data modify storage commerce:cp ve3 set from storage commerce:l ve
data modify storage commerce:cp vz3 set from storage commerce:l vz
data modify storage commerce:cp vc3 set from storage commerce:l vc
data modify storage commerce:cp ae3 set from storage commerce:l ae
data modify storage commerce:cp az3 set from storage commerce:l az
data modify storage commerce:cp ac3 set from storage commerce:l ac
data modify storage commerce:cp t3 set from storage commerce:l t
scoreboard players set #i c.t 4
function commerce:page/ligne
data modify storage commerce:cp ve4 set from storage commerce:l ve
data modify storage commerce:cp vz4 set from storage commerce:l vz
data modify storage commerce:cp vc4 set from storage commerce:l vc
data modify storage commerce:cp ae4 set from storage commerce:l ae
data modify storage commerce:cp az4 set from storage commerce:l az
data modify storage commerce:cp ac4 set from storage commerce:l ac
data modify storage commerce:cp t4 set from storage commerce:l t
scoreboard players set #i c.t 257
function commerce:page/ligne
data modify storage commerce:cp ve257 set from storage commerce:l ve
data modify storage commerce:cp vz257 set from storage commerce:l vz
data modify storage commerce:cp vc257 set from storage commerce:l vc
data modify storage commerce:cp ae257 set from storage commerce:l ae
data modify storage commerce:cp az257 set from storage commerce:l az
data modify storage commerce:cp ac257 set from storage commerce:l ac
data modify storage commerce:cp t257 set from storage commerce:l t
scoreboard players set #i c.t 260
function commerce:page/ligne
data modify storage commerce:cp ve260 set from storage commerce:l ve
data modify storage commerce:cp vz260 set from storage commerce:l vz
data modify storage commerce:cp vc260 set from storage commerce:l vc
data modify storage commerce:cp ae260 set from storage commerce:l ae
data modify storage commerce:cp az260 set from storage commerce:l az
data modify storage commerce:cp ac260 set from storage commerce:l ac
data modify storage commerce:cp t260 set from storage commerce:l t
scoreboard players set #i c.t 258
function commerce:page/ligne
data modify storage commerce:cp ve258 set from storage commerce:l ve
data modify storage commerce:cp vz258 set from storage commerce:l vz
data modify storage commerce:cp vc258 set from storage commerce:l vc
data modify storage commerce:cp ae258 set from storage commerce:l ae
data modify storage commerce:cp az258 set from storage commerce:l az
data modify storage commerce:cp ac258 set from storage commerce:l ac
data modify storage commerce:cp t258 set from storage commerce:l t
function commerce:page/lettre_r_0_d with storage commerce:cp
