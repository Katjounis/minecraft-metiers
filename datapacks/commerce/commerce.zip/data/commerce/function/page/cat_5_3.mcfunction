function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 152
function commerce:page/ligne
data modify storage commerce:cp ve152 set from storage commerce:l ve
data modify storage commerce:cp vz152 set from storage commerce:l vz
data modify storage commerce:cp vc152 set from storage commerce:l vc
data modify storage commerce:cp ae152 set from storage commerce:l ae
data modify storage commerce:cp az152 set from storage commerce:l az
data modify storage commerce:cp ac152 set from storage commerce:l ac
data modify storage commerce:cp t152 set from storage commerce:l t
scoreboard players set #i c.t 153
function commerce:page/ligne
data modify storage commerce:cp ve153 set from storage commerce:l ve
data modify storage commerce:cp vz153 set from storage commerce:l vz
data modify storage commerce:cp vc153 set from storage commerce:l vc
data modify storage commerce:cp ae153 set from storage commerce:l ae
data modify storage commerce:cp az153 set from storage commerce:l az
data modify storage commerce:cp ac153 set from storage commerce:l ac
data modify storage commerce:cp t153 set from storage commerce:l t
function commerce:page/cat_5_3_d with storage commerce:cp
