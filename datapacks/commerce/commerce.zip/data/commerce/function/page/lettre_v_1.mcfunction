function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 204
function commerce:page/ligne
data modify storage commerce:cp ve204 set from storage commerce:l ve
data modify storage commerce:cp vz204 set from storage commerce:l vz
data modify storage commerce:cp vc204 set from storage commerce:l vc
data modify storage commerce:cp ae204 set from storage commerce:l ae
data modify storage commerce:cp az204 set from storage commerce:l az
data modify storage commerce:cp ac204 set from storage commerce:l ac
data modify storage commerce:cp t204 set from storage commerce:l t
scoreboard players set #i c.t 190
function commerce:page/ligne
data modify storage commerce:cp ve190 set from storage commerce:l ve
data modify storage commerce:cp vz190 set from storage commerce:l vz
data modify storage commerce:cp vc190 set from storage commerce:l vc
data modify storage commerce:cp ae190 set from storage commerce:l ae
data modify storage commerce:cp az190 set from storage commerce:l az
data modify storage commerce:cp ac190 set from storage commerce:l ac
data modify storage commerce:cp t190 set from storage commerce:l t
scoreboard players set #i c.t 195
function commerce:page/ligne
data modify storage commerce:cp ve195 set from storage commerce:l ve
data modify storage commerce:cp vz195 set from storage commerce:l vz
data modify storage commerce:cp vc195 set from storage commerce:l vc
data modify storage commerce:cp ae195 set from storage commerce:l ae
data modify storage commerce:cp az195 set from storage commerce:l az
data modify storage commerce:cp ac195 set from storage commerce:l ac
data modify storage commerce:cp t195 set from storage commerce:l t
scoreboard players set #i c.t 203
function commerce:page/ligne
data modify storage commerce:cp ve203 set from storage commerce:l ve
data modify storage commerce:cp vz203 set from storage commerce:l vz
data modify storage commerce:cp vc203 set from storage commerce:l vc
data modify storage commerce:cp ae203 set from storage commerce:l ae
data modify storage commerce:cp az203 set from storage commerce:l az
data modify storage commerce:cp ac203 set from storage commerce:l ac
data modify storage commerce:cp t203 set from storage commerce:l t
scoreboard players set #i c.t 202
function commerce:page/ligne
data modify storage commerce:cp ve202 set from storage commerce:l ve
data modify storage commerce:cp vz202 set from storage commerce:l vz
data modify storage commerce:cp vc202 set from storage commerce:l vc
data modify storage commerce:cp ae202 set from storage commerce:l ae
data modify storage commerce:cp az202 set from storage commerce:l az
data modify storage commerce:cp ac202 set from storage commerce:l ac
data modify storage commerce:cp t202 set from storage commerce:l t
scoreboard players set #i c.t 194
function commerce:page/ligne
data modify storage commerce:cp ve194 set from storage commerce:l ve
data modify storage commerce:cp vz194 set from storage commerce:l vz
data modify storage commerce:cp vc194 set from storage commerce:l vc
data modify storage commerce:cp ae194 set from storage commerce:l ae
data modify storage commerce:cp az194 set from storage commerce:l az
data modify storage commerce:cp ac194 set from storage commerce:l ac
data modify storage commerce:cp t194 set from storage commerce:l t
scoreboard players set #i c.t 199
function commerce:page/ligne
data modify storage commerce:cp ve199 set from storage commerce:l ve
data modify storage commerce:cp vz199 set from storage commerce:l vz
data modify storage commerce:cp vc199 set from storage commerce:l vc
data modify storage commerce:cp ae199 set from storage commerce:l ae
data modify storage commerce:cp az199 set from storage commerce:l az
data modify storage commerce:cp ac199 set from storage commerce:l ac
data modify storage commerce:cp t199 set from storage commerce:l t
scoreboard players set #i c.t 297
function commerce:page/ligne
data modify storage commerce:cp ve297 set from storage commerce:l ve
data modify storage commerce:cp vz297 set from storage commerce:l vz
data modify storage commerce:cp vc297 set from storage commerce:l vc
data modify storage commerce:cp ae297 set from storage commerce:l ae
data modify storage commerce:cp az297 set from storage commerce:l az
data modify storage commerce:cp ac297 set from storage commerce:l ac
data modify storage commerce:cp t297 set from storage commerce:l t
scoreboard players set #i c.t 188
function commerce:page/ligne
data modify storage commerce:cp ve188 set from storage commerce:l ve
data modify storage commerce:cp vz188 set from storage commerce:l vz
data modify storage commerce:cp vc188 set from storage commerce:l vc
data modify storage commerce:cp ae188 set from storage commerce:l ae
data modify storage commerce:cp az188 set from storage commerce:l az
data modify storage commerce:cp ac188 set from storage commerce:l ac
data modify storage commerce:cp t188 set from storage commerce:l t
function commerce:page/lettre_v_1_d with storage commerce:cp
