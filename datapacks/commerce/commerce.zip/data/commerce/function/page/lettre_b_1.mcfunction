function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 285
function commerce:page/ligne
data modify storage commerce:cp ve285 set from storage commerce:l ve
data modify storage commerce:cp vz285 set from storage commerce:l vz
data modify storage commerce:cp vc285 set from storage commerce:l vc
data modify storage commerce:cp ae285 set from storage commerce:l ae
data modify storage commerce:cp az285 set from storage commerce:l az
data modify storage commerce:cp ac285 set from storage commerce:l ac
data modify storage commerce:cp t285 set from storage commerce:l t
scoreboard players set #i c.t 154
function commerce:page/ligne
data modify storage commerce:cp ve154 set from storage commerce:l ve
data modify storage commerce:cp vz154 set from storage commerce:l vz
data modify storage commerce:cp vc154 set from storage commerce:l vc
data modify storage commerce:cp ae154 set from storage commerce:l ae
data modify storage commerce:cp az154 set from storage commerce:l az
data modify storage commerce:cp ac154 set from storage commerce:l ac
data modify storage commerce:cp t154 set from storage commerce:l t
scoreboard players set #i c.t 165
function commerce:page/ligne
data modify storage commerce:cp ve165 set from storage commerce:l ve
data modify storage commerce:cp vz165 set from storage commerce:l vz
data modify storage commerce:cp vc165 set from storage commerce:l vc
data modify storage commerce:cp ae165 set from storage commerce:l ae
data modify storage commerce:cp az165 set from storage commerce:l az
data modify storage commerce:cp ac165 set from storage commerce:l ac
data modify storage commerce:cp t165 set from storage commerce:l t
scoreboard players set #i c.t 157
function commerce:page/ligne
data modify storage commerce:cp ve157 set from storage commerce:l ve
data modify storage commerce:cp vz157 set from storage commerce:l vz
data modify storage commerce:cp vc157 set from storage commerce:l vc
data modify storage commerce:cp ae157 set from storage commerce:l ae
data modify storage commerce:cp az157 set from storage commerce:l az
data modify storage commerce:cp ac157 set from storage commerce:l ac
data modify storage commerce:cp t157 set from storage commerce:l t
scoreboard players set #i c.t 163
function commerce:page/ligne
data modify storage commerce:cp ve163 set from storage commerce:l ve
data modify storage commerce:cp vz163 set from storage commerce:l vz
data modify storage commerce:cp vc163 set from storage commerce:l vc
data modify storage commerce:cp ae163 set from storage commerce:l ae
data modify storage commerce:cp az163 set from storage commerce:l az
data modify storage commerce:cp ac163 set from storage commerce:l ac
data modify storage commerce:cp t163 set from storage commerce:l t
scoreboard players set #i c.t 161
function commerce:page/ligne
data modify storage commerce:cp ve161 set from storage commerce:l ve
data modify storage commerce:cp vz161 set from storage commerce:l vz
data modify storage commerce:cp vc161 set from storage commerce:l vc
data modify storage commerce:cp ae161 set from storage commerce:l ae
data modify storage commerce:cp az161 set from storage commerce:l az
data modify storage commerce:cp ac161 set from storage commerce:l ac
data modify storage commerce:cp t161 set from storage commerce:l t
scoreboard players set #i c.t 162
function commerce:page/ligne
data modify storage commerce:cp ve162 set from storage commerce:l ve
data modify storage commerce:cp vz162 set from storage commerce:l vz
data modify storage commerce:cp vc162 set from storage commerce:l vc
data modify storage commerce:cp ae162 set from storage commerce:l ae
data modify storage commerce:cp az162 set from storage commerce:l az
data modify storage commerce:cp ac162 set from storage commerce:l ac
data modify storage commerce:cp t162 set from storage commerce:l t
scoreboard players set #i c.t 158
function commerce:page/ligne
data modify storage commerce:cp ve158 set from storage commerce:l ve
data modify storage commerce:cp vz158 set from storage commerce:l vz
data modify storage commerce:cp vc158 set from storage commerce:l vc
data modify storage commerce:cp ae158 set from storage commerce:l ae
data modify storage commerce:cp az158 set from storage commerce:l az
data modify storage commerce:cp ac158 set from storage commerce:l ac
data modify storage commerce:cp t158 set from storage commerce:l t
scoreboard players set #i c.t 156
function commerce:page/ligne
data modify storage commerce:cp ve156 set from storage commerce:l ve
data modify storage commerce:cp vz156 set from storage commerce:l vz
data modify storage commerce:cp vc156 set from storage commerce:l vc
data modify storage commerce:cp ae156 set from storage commerce:l ae
data modify storage commerce:cp az156 set from storage commerce:l az
data modify storage commerce:cp ac156 set from storage commerce:l ac
data modify storage commerce:cp t156 set from storage commerce:l t
scoreboard players set #i c.t 166
function commerce:page/ligne
data modify storage commerce:cp ve166 set from storage commerce:l ve
data modify storage commerce:cp vz166 set from storage commerce:l vz
data modify storage commerce:cp vc166 set from storage commerce:l vc
data modify storage commerce:cp ae166 set from storage commerce:l ae
data modify storage commerce:cp az166 set from storage commerce:l az
data modify storage commerce:cp ac166 set from storage commerce:l ac
data modify storage commerce:cp t166 set from storage commerce:l t
function commerce:page/lettre_b_1_d with storage commerce:cp
