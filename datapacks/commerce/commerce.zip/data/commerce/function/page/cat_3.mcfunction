function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 41
function commerce:page/ligne
data modify storage commerce:cp ve41 set from storage commerce:l ve
data modify storage commerce:cp vz41 set from storage commerce:l vz
data modify storage commerce:cp vc41 set from storage commerce:l vc
data modify storage commerce:cp ae41 set from storage commerce:l ae
data modify storage commerce:cp az41 set from storage commerce:l az
data modify storage commerce:cp ac41 set from storage commerce:l ac
data modify storage commerce:cp t41 set from storage commerce:l t
data modify storage commerce:cp tc41 set from storage commerce:l tc
scoreboard players set #i c.t 42
function commerce:page/ligne
data modify storage commerce:cp ve42 set from storage commerce:l ve
data modify storage commerce:cp vz42 set from storage commerce:l vz
data modify storage commerce:cp vc42 set from storage commerce:l vc
data modify storage commerce:cp ae42 set from storage commerce:l ae
data modify storage commerce:cp az42 set from storage commerce:l az
data modify storage commerce:cp ac42 set from storage commerce:l ac
data modify storage commerce:cp t42 set from storage commerce:l t
data modify storage commerce:cp tc42 set from storage commerce:l tc
scoreboard players set #i c.t 43
function commerce:page/ligne
data modify storage commerce:cp ve43 set from storage commerce:l ve
data modify storage commerce:cp vz43 set from storage commerce:l vz
data modify storage commerce:cp vc43 set from storage commerce:l vc
data modify storage commerce:cp ae43 set from storage commerce:l ae
data modify storage commerce:cp az43 set from storage commerce:l az
data modify storage commerce:cp ac43 set from storage commerce:l ac
data modify storage commerce:cp t43 set from storage commerce:l t
data modify storage commerce:cp tc43 set from storage commerce:l tc
scoreboard players set #i c.t 44
function commerce:page/ligne
data modify storage commerce:cp ve44 set from storage commerce:l ve
data modify storage commerce:cp vz44 set from storage commerce:l vz
data modify storage commerce:cp vc44 set from storage commerce:l vc
data modify storage commerce:cp ae44 set from storage commerce:l ae
data modify storage commerce:cp az44 set from storage commerce:l az
data modify storage commerce:cp ac44 set from storage commerce:l ac
data modify storage commerce:cp t44 set from storage commerce:l t
data modify storage commerce:cp tc44 set from storage commerce:l tc
scoreboard players set #i c.t 45
function commerce:page/ligne
data modify storage commerce:cp ve45 set from storage commerce:l ve
data modify storage commerce:cp vz45 set from storage commerce:l vz
data modify storage commerce:cp vc45 set from storage commerce:l vc
data modify storage commerce:cp ae45 set from storage commerce:l ae
data modify storage commerce:cp az45 set from storage commerce:l az
data modify storage commerce:cp ac45 set from storage commerce:l ac
data modify storage commerce:cp t45 set from storage commerce:l t
data modify storage commerce:cp tc45 set from storage commerce:l tc
scoreboard players set #i c.t 46
function commerce:page/ligne
data modify storage commerce:cp ve46 set from storage commerce:l ve
data modify storage commerce:cp vz46 set from storage commerce:l vz
data modify storage commerce:cp vc46 set from storage commerce:l vc
data modify storage commerce:cp ae46 set from storage commerce:l ae
data modify storage commerce:cp az46 set from storage commerce:l az
data modify storage commerce:cp ac46 set from storage commerce:l ac
data modify storage commerce:cp t46 set from storage commerce:l t
data modify storage commerce:cp tc46 set from storage commerce:l tc
scoreboard players set #i c.t 47
function commerce:page/ligne
data modify storage commerce:cp ve47 set from storage commerce:l ve
data modify storage commerce:cp vz47 set from storage commerce:l vz
data modify storage commerce:cp vc47 set from storage commerce:l vc
data modify storage commerce:cp ae47 set from storage commerce:l ae
data modify storage commerce:cp az47 set from storage commerce:l az
data modify storage commerce:cp ac47 set from storage commerce:l ac
data modify storage commerce:cp t47 set from storage commerce:l t
data modify storage commerce:cp tc47 set from storage commerce:l tc
scoreboard players set #i c.t 48
function commerce:page/ligne
data modify storage commerce:cp ve48 set from storage commerce:l ve
data modify storage commerce:cp vz48 set from storage commerce:l vz
data modify storage commerce:cp vc48 set from storage commerce:l vc
data modify storage commerce:cp ae48 set from storage commerce:l ae
data modify storage commerce:cp az48 set from storage commerce:l az
data modify storage commerce:cp ac48 set from storage commerce:l ac
data modify storage commerce:cp t48 set from storage commerce:l t
data modify storage commerce:cp tc48 set from storage commerce:l tc
scoreboard players set #i c.t 49
function commerce:page/ligne
data modify storage commerce:cp ve49 set from storage commerce:l ve
data modify storage commerce:cp vz49 set from storage commerce:l vz
data modify storage commerce:cp vc49 set from storage commerce:l vc
data modify storage commerce:cp ae49 set from storage commerce:l ae
data modify storage commerce:cp az49 set from storage commerce:l az
data modify storage commerce:cp ac49 set from storage commerce:l ac
data modify storage commerce:cp t49 set from storage commerce:l t
data modify storage commerce:cp tc49 set from storage commerce:l tc
scoreboard players set #i c.t 50
function commerce:page/ligne
data modify storage commerce:cp ve50 set from storage commerce:l ve
data modify storage commerce:cp vz50 set from storage commerce:l vz
data modify storage commerce:cp vc50 set from storage commerce:l vc
data modify storage commerce:cp ae50 set from storage commerce:l ae
data modify storage commerce:cp az50 set from storage commerce:l az
data modify storage commerce:cp ac50 set from storage commerce:l ac
data modify storage commerce:cp t50 set from storage commerce:l t
data modify storage commerce:cp tc50 set from storage commerce:l tc
scoreboard players set #i c.t 51
function commerce:page/ligne
data modify storage commerce:cp ve51 set from storage commerce:l ve
data modify storage commerce:cp vz51 set from storage commerce:l vz
data modify storage commerce:cp vc51 set from storage commerce:l vc
data modify storage commerce:cp ae51 set from storage commerce:l ae
data modify storage commerce:cp az51 set from storage commerce:l az
data modify storage commerce:cp ac51 set from storage commerce:l ac
data modify storage commerce:cp t51 set from storage commerce:l t
data modify storage commerce:cp tc51 set from storage commerce:l tc
scoreboard players set #i c.t 52
function commerce:page/ligne
data modify storage commerce:cp ve52 set from storage commerce:l ve
data modify storage commerce:cp vz52 set from storage commerce:l vz
data modify storage commerce:cp vc52 set from storage commerce:l vc
data modify storage commerce:cp ae52 set from storage commerce:l ae
data modify storage commerce:cp az52 set from storage commerce:l az
data modify storage commerce:cp ac52 set from storage commerce:l ac
data modify storage commerce:cp t52 set from storage commerce:l t
data modify storage commerce:cp tc52 set from storage commerce:l tc
scoreboard players set #i c.t 53
function commerce:page/ligne
data modify storage commerce:cp ve53 set from storage commerce:l ve
data modify storage commerce:cp vz53 set from storage commerce:l vz
data modify storage commerce:cp vc53 set from storage commerce:l vc
data modify storage commerce:cp ae53 set from storage commerce:l ae
data modify storage commerce:cp az53 set from storage commerce:l az
data modify storage commerce:cp ac53 set from storage commerce:l ac
data modify storage commerce:cp t53 set from storage commerce:l t
data modify storage commerce:cp tc53 set from storage commerce:l tc
function commerce:page/cat_3_d with storage commerce:cp
