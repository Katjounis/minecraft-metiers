function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 347
function commerce:page/ligne
data modify storage commerce:cp ve347 set from storage commerce:l ve
data modify storage commerce:cp vz347 set from storage commerce:l vz
data modify storage commerce:cp vc347 set from storage commerce:l vc
data modify storage commerce:cp ae347 set from storage commerce:l ae
data modify storage commerce:cp az347 set from storage commerce:l az
data modify storage commerce:cp ac347 set from storage commerce:l ac
data modify storage commerce:cp t347 set from storage commerce:l t
scoreboard players set #i c.t 295
function commerce:page/ligne
data modify storage commerce:cp ve295 set from storage commerce:l ve
data modify storage commerce:cp vz295 set from storage commerce:l vz
data modify storage commerce:cp vc295 set from storage commerce:l vc
data modify storage commerce:cp ae295 set from storage commerce:l ae
data modify storage commerce:cp az295 set from storage commerce:l az
data modify storage commerce:cp ac295 set from storage commerce:l ac
data modify storage commerce:cp t295 set from storage commerce:l t
scoreboard players set #i c.t 249
function commerce:page/ligne
data modify storage commerce:cp ve249 set from storage commerce:l ve
data modify storage commerce:cp vz249 set from storage commerce:l vz
data modify storage commerce:cp vc249 set from storage commerce:l vc
data modify storage commerce:cp ae249 set from storage commerce:l ae
data modify storage commerce:cp az249 set from storage commerce:l az
data modify storage commerce:cp ac249 set from storage commerce:l ac
data modify storage commerce:cp t249 set from storage commerce:l t
scoreboard players set #i c.t 288
function commerce:page/ligne
data modify storage commerce:cp ve288 set from storage commerce:l ve
data modify storage commerce:cp vz288 set from storage commerce:l vz
data modify storage commerce:cp vc288 set from storage commerce:l vc
data modify storage commerce:cp ae288 set from storage commerce:l ae
data modify storage commerce:cp az288 set from storage commerce:l az
data modify storage commerce:cp ac288 set from storage commerce:l ac
data modify storage commerce:cp t288 set from storage commerce:l t
scoreboard players set #i c.t 304
function commerce:page/ligne
data modify storage commerce:cp ve304 set from storage commerce:l ve
data modify storage commerce:cp vz304 set from storage commerce:l vz
data modify storage commerce:cp vc304 set from storage commerce:l vc
data modify storage commerce:cp ae304 set from storage commerce:l ae
data modify storage commerce:cp az304 set from storage commerce:l az
data modify storage commerce:cp ac304 set from storage commerce:l ac
data modify storage commerce:cp t304 set from storage commerce:l t
scoreboard players set #i c.t 303
function commerce:page/ligne
data modify storage commerce:cp ve303 set from storage commerce:l ve
data modify storage commerce:cp vz303 set from storage commerce:l vz
data modify storage commerce:cp vc303 set from storage commerce:l vc
data modify storage commerce:cp ae303 set from storage commerce:l ae
data modify storage commerce:cp az303 set from storage commerce:l az
data modify storage commerce:cp ac303 set from storage commerce:l ac
data modify storage commerce:cp t303 set from storage commerce:l t
scoreboard players set #i c.t 328
function commerce:page/ligne
data modify storage commerce:cp ve328 set from storage commerce:l ve
data modify storage commerce:cp vz328 set from storage commerce:l vz
data modify storage commerce:cp vc328 set from storage commerce:l vc
data modify storage commerce:cp ae328 set from storage commerce:l ae
data modify storage commerce:cp az328 set from storage commerce:l az
data modify storage commerce:cp ac328 set from storage commerce:l ac
data modify storage commerce:cp t328 set from storage commerce:l t
scoreboard players set #i c.t 236
function commerce:page/ligne
data modify storage commerce:cp ve236 set from storage commerce:l ve
data modify storage commerce:cp vz236 set from storage commerce:l vz
data modify storage commerce:cp vc236 set from storage commerce:l vc
data modify storage commerce:cp ae236 set from storage commerce:l ae
data modify storage commerce:cp az236 set from storage commerce:l az
data modify storage commerce:cp ac236 set from storage commerce:l ac
data modify storage commerce:cp t236 set from storage commerce:l t
scoreboard players set #i c.t 228
function commerce:page/ligne
data modify storage commerce:cp ve228 set from storage commerce:l ve
data modify storage commerce:cp vz228 set from storage commerce:l vz
data modify storage commerce:cp vc228 set from storage commerce:l vc
data modify storage commerce:cp ae228 set from storage commerce:l ae
data modify storage commerce:cp az228 set from storage commerce:l az
data modify storage commerce:cp ac228 set from storage commerce:l ac
data modify storage commerce:cp t228 set from storage commerce:l t
scoreboard players set #i c.t 231
function commerce:page/ligne
data modify storage commerce:cp ve231 set from storage commerce:l ve
data modify storage commerce:cp vz231 set from storage commerce:l vz
data modify storage commerce:cp vc231 set from storage commerce:l vc
data modify storage commerce:cp ae231 set from storage commerce:l ae
data modify storage commerce:cp az231 set from storage commerce:l az
data modify storage commerce:cp ac231 set from storage commerce:l ac
data modify storage commerce:cp t231 set from storage commerce:l t
function commerce:page/lettre_p_0_d with storage commerce:cp
