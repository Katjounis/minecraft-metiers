function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 27
function commerce:page/ligne
data modify storage commerce:cp ve27 set from storage commerce:l ve
data modify storage commerce:cp vz27 set from storage commerce:l vz
data modify storage commerce:cp vc27 set from storage commerce:l vc
data modify storage commerce:cp ae27 set from storage commerce:l ae
data modify storage commerce:cp az27 set from storage commerce:l az
data modify storage commerce:cp ac27 set from storage commerce:l ac
data modify storage commerce:cp t27 set from storage commerce:l t
data modify storage commerce:cp tc27 set from storage commerce:l tc
scoreboard players set #i c.t 28
function commerce:page/ligne
data modify storage commerce:cp ve28 set from storage commerce:l ve
data modify storage commerce:cp vz28 set from storage commerce:l vz
data modify storage commerce:cp vc28 set from storage commerce:l vc
data modify storage commerce:cp ae28 set from storage commerce:l ae
data modify storage commerce:cp az28 set from storage commerce:l az
data modify storage commerce:cp ac28 set from storage commerce:l ac
data modify storage commerce:cp t28 set from storage commerce:l t
data modify storage commerce:cp tc28 set from storage commerce:l tc
scoreboard players set #i c.t 29
function commerce:page/ligne
data modify storage commerce:cp ve29 set from storage commerce:l ve
data modify storage commerce:cp vz29 set from storage commerce:l vz
data modify storage commerce:cp vc29 set from storage commerce:l vc
data modify storage commerce:cp ae29 set from storage commerce:l ae
data modify storage commerce:cp az29 set from storage commerce:l az
data modify storage commerce:cp ac29 set from storage commerce:l ac
data modify storage commerce:cp t29 set from storage commerce:l t
data modify storage commerce:cp tc29 set from storage commerce:l tc
scoreboard players set #i c.t 30
function commerce:page/ligne
data modify storage commerce:cp ve30 set from storage commerce:l ve
data modify storage commerce:cp vz30 set from storage commerce:l vz
data modify storage commerce:cp vc30 set from storage commerce:l vc
data modify storage commerce:cp ae30 set from storage commerce:l ae
data modify storage commerce:cp az30 set from storage commerce:l az
data modify storage commerce:cp ac30 set from storage commerce:l ac
data modify storage commerce:cp t30 set from storage commerce:l t
data modify storage commerce:cp tc30 set from storage commerce:l tc
scoreboard players set #i c.t 31
function commerce:page/ligne
data modify storage commerce:cp ve31 set from storage commerce:l ve
data modify storage commerce:cp vz31 set from storage commerce:l vz
data modify storage commerce:cp vc31 set from storage commerce:l vc
data modify storage commerce:cp ae31 set from storage commerce:l ae
data modify storage commerce:cp az31 set from storage commerce:l az
data modify storage commerce:cp ac31 set from storage commerce:l ac
data modify storage commerce:cp t31 set from storage commerce:l t
data modify storage commerce:cp tc31 set from storage commerce:l tc
scoreboard players set #i c.t 32
function commerce:page/ligne
data modify storage commerce:cp ve32 set from storage commerce:l ve
data modify storage commerce:cp vz32 set from storage commerce:l vz
data modify storage commerce:cp vc32 set from storage commerce:l vc
data modify storage commerce:cp ae32 set from storage commerce:l ae
data modify storage commerce:cp az32 set from storage commerce:l az
data modify storage commerce:cp ac32 set from storage commerce:l ac
data modify storage commerce:cp t32 set from storage commerce:l t
data modify storage commerce:cp tc32 set from storage commerce:l tc
scoreboard players set #i c.t 33
function commerce:page/ligne
data modify storage commerce:cp ve33 set from storage commerce:l ve
data modify storage commerce:cp vz33 set from storage commerce:l vz
data modify storage commerce:cp vc33 set from storage commerce:l vc
data modify storage commerce:cp ae33 set from storage commerce:l ae
data modify storage commerce:cp az33 set from storage commerce:l az
data modify storage commerce:cp ac33 set from storage commerce:l ac
data modify storage commerce:cp t33 set from storage commerce:l t
data modify storage commerce:cp tc33 set from storage commerce:l tc
scoreboard players set #i c.t 34
function commerce:page/ligne
data modify storage commerce:cp ve34 set from storage commerce:l ve
data modify storage commerce:cp vz34 set from storage commerce:l vz
data modify storage commerce:cp vc34 set from storage commerce:l vc
data modify storage commerce:cp ae34 set from storage commerce:l ae
data modify storage commerce:cp az34 set from storage commerce:l az
data modify storage commerce:cp ac34 set from storage commerce:l ac
data modify storage commerce:cp t34 set from storage commerce:l t
data modify storage commerce:cp tc34 set from storage commerce:l tc
scoreboard players set #i c.t 35
function commerce:page/ligne
data modify storage commerce:cp ve35 set from storage commerce:l ve
data modify storage commerce:cp vz35 set from storage commerce:l vz
data modify storage commerce:cp vc35 set from storage commerce:l vc
data modify storage commerce:cp ae35 set from storage commerce:l ae
data modify storage commerce:cp az35 set from storage commerce:l az
data modify storage commerce:cp ac35 set from storage commerce:l ac
data modify storage commerce:cp t35 set from storage commerce:l t
data modify storage commerce:cp tc35 set from storage commerce:l tc
scoreboard players set #i c.t 36
function commerce:page/ligne
data modify storage commerce:cp ve36 set from storage commerce:l ve
data modify storage commerce:cp vz36 set from storage commerce:l vz
data modify storage commerce:cp vc36 set from storage commerce:l vc
data modify storage commerce:cp ae36 set from storage commerce:l ae
data modify storage commerce:cp az36 set from storage commerce:l az
data modify storage commerce:cp ac36 set from storage commerce:l ac
data modify storage commerce:cp t36 set from storage commerce:l t
data modify storage commerce:cp tc36 set from storage commerce:l tc
scoreboard players set #i c.t 37
function commerce:page/ligne
data modify storage commerce:cp ve37 set from storage commerce:l ve
data modify storage commerce:cp vz37 set from storage commerce:l vz
data modify storage commerce:cp vc37 set from storage commerce:l vc
data modify storage commerce:cp ae37 set from storage commerce:l ae
data modify storage commerce:cp az37 set from storage commerce:l az
data modify storage commerce:cp ac37 set from storage commerce:l ac
data modify storage commerce:cp t37 set from storage commerce:l t
data modify storage commerce:cp tc37 set from storage commerce:l tc
scoreboard players set #i c.t 38
function commerce:page/ligne
data modify storage commerce:cp ve38 set from storage commerce:l ve
data modify storage commerce:cp vz38 set from storage commerce:l vz
data modify storage commerce:cp vc38 set from storage commerce:l vc
data modify storage commerce:cp ae38 set from storage commerce:l ae
data modify storage commerce:cp az38 set from storage commerce:l az
data modify storage commerce:cp ac38 set from storage commerce:l ac
data modify storage commerce:cp t38 set from storage commerce:l t
data modify storage commerce:cp tc38 set from storage commerce:l tc
scoreboard players set #i c.t 39
function commerce:page/ligne
data modify storage commerce:cp ve39 set from storage commerce:l ve
data modify storage commerce:cp vz39 set from storage commerce:l vz
data modify storage commerce:cp vc39 set from storage commerce:l vc
data modify storage commerce:cp ae39 set from storage commerce:l ae
data modify storage commerce:cp az39 set from storage commerce:l az
data modify storage commerce:cp ac39 set from storage commerce:l ac
data modify storage commerce:cp t39 set from storage commerce:l t
data modify storage commerce:cp tc39 set from storage commerce:l tc
scoreboard players set #i c.t 40
function commerce:page/ligne
data modify storage commerce:cp ve40 set from storage commerce:l ve
data modify storage commerce:cp vz40 set from storage commerce:l vz
data modify storage commerce:cp vc40 set from storage commerce:l vc
data modify storage commerce:cp ae40 set from storage commerce:l ae
data modify storage commerce:cp az40 set from storage commerce:l az
data modify storage commerce:cp ac40 set from storage commerce:l ac
data modify storage commerce:cp t40 set from storage commerce:l t
data modify storage commerce:cp tc40 set from storage commerce:l tc
function commerce:page/cat_2_d with storage commerce:cp
