scoreboard players operation #i c.t = #v c.t
scoreboard players remove #i c.t 10000
function commerce:page/item
