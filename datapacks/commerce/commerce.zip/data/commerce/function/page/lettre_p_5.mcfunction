function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 239
function commerce:page/ligne
data modify storage commerce:cp ve239 set from storage commerce:l ve
data modify storage commerce:cp vz239 set from storage commerce:l vz
data modify storage commerce:cp vc239 set from storage commerce:l vc
data modify storage commerce:cp ae239 set from storage commerce:l ae
data modify storage commerce:cp az239 set from storage commerce:l az
data modify storage commerce:cp ac239 set from storage commerce:l ac
data modify storage commerce:cp t239 set from storage commerce:l t
scoreboard players set #i c.t 263
function commerce:page/ligne
data modify storage commerce:cp ve263 set from storage commerce:l ve
data modify storage commerce:cp vz263 set from storage commerce:l vz
data modify storage commerce:cp vc263 set from storage commerce:l vc
data modify storage commerce:cp ae263 set from storage commerce:l ae
data modify storage commerce:cp az263 set from storage commerce:l az
data modify storage commerce:cp ac263 set from storage commerce:l ac
data modify storage commerce:cp t263 set from storage commerce:l t
scoreboard players set #i c.t 311
function commerce:page/ligne
data modify storage commerce:cp ve311 set from storage commerce:l ve
data modify storage commerce:cp vz311 set from storage commerce:l vz
data modify storage commerce:cp vc311 set from storage commerce:l vc
data modify storage commerce:cp ae311 set from storage commerce:l ae
data modify storage commerce:cp az311 set from storage commerce:l az
data modify storage commerce:cp ac311 set from storage commerce:l ac
data modify storage commerce:cp t311 set from storage commerce:l t
scoreboard players set #i c.t 355
function commerce:page/ligne
data modify storage commerce:cp ve355 set from storage commerce:l ve
data modify storage commerce:cp vz355 set from storage commerce:l vz
data modify storage commerce:cp vc355 set from storage commerce:l vc
data modify storage commerce:cp ae355 set from storage commerce:l ae
data modify storage commerce:cp az355 set from storage commerce:l az
data modify storage commerce:cp ac355 set from storage commerce:l ac
data modify storage commerce:cp t355 set from storage commerce:l t
scoreboard players set #i c.t 102
function commerce:page/ligne
data modify storage commerce:cp ve102 set from storage commerce:l ve
data modify storage commerce:cp vz102 set from storage commerce:l vz
data modify storage commerce:cp vc102 set from storage commerce:l vc
data modify storage commerce:cp ae102 set from storage commerce:l ae
data modify storage commerce:cp az102 set from storage commerce:l az
data modify storage commerce:cp ac102 set from storage commerce:l ac
data modify storage commerce:cp t102 set from storage commerce:l t
scoreboard players set #i c.t 99
function commerce:page/ligne
data modify storage commerce:cp ve99 set from storage commerce:l ve
data modify storage commerce:cp vz99 set from storage commerce:l vz
data modify storage commerce:cp vc99 set from storage commerce:l vc
data modify storage commerce:cp ae99 set from storage commerce:l ae
data modify storage commerce:cp az99 set from storage commerce:l az
data modify storage commerce:cp ac99 set from storage commerce:l ac
data modify storage commerce:cp t99 set from storage commerce:l t
scoreboard players set #i c.t 96
function commerce:page/ligne
data modify storage commerce:cp ve96 set from storage commerce:l ve
data modify storage commerce:cp vz96 set from storage commerce:l vz
data modify storage commerce:cp vc96 set from storage commerce:l vc
data modify storage commerce:cp ae96 set from storage commerce:l ae
data modify storage commerce:cp az96 set from storage commerce:l az
data modify storage commerce:cp ac96 set from storage commerce:l ac
data modify storage commerce:cp t96 set from storage commerce:l t
scoreboard players set #i c.t 111
function commerce:page/ligne
data modify storage commerce:cp ve111 set from storage commerce:l ve
data modify storage commerce:cp vz111 set from storage commerce:l vz
data modify storage commerce:cp vc111 set from storage commerce:l vc
data modify storage commerce:cp ae111 set from storage commerce:l ae
data modify storage commerce:cp az111 set from storage commerce:l az
data modify storage commerce:cp ac111 set from storage commerce:l ac
data modify storage commerce:cp t111 set from storage commerce:l t
scoreboard players set #i c.t 90
function commerce:page/ligne
data modify storage commerce:cp ve90 set from storage commerce:l ve
data modify storage commerce:cp vz90 set from storage commerce:l vz
data modify storage commerce:cp vc90 set from storage commerce:l vc
data modify storage commerce:cp ae90 set from storage commerce:l ae
data modify storage commerce:cp az90 set from storage commerce:l az
data modify storage commerce:cp ac90 set from storage commerce:l ac
data modify storage commerce:cp t90 set from storage commerce:l t
scoreboard players set #i c.t 105
function commerce:page/ligne
data modify storage commerce:cp ve105 set from storage commerce:l ve
data modify storage commerce:cp vz105 set from storage commerce:l vz
data modify storage commerce:cp vc105 set from storage commerce:l vc
data modify storage commerce:cp ae105 set from storage commerce:l ae
data modify storage commerce:cp az105 set from storage commerce:l az
data modify storage commerce:cp ac105 set from storage commerce:l ac
data modify storage commerce:cp t105 set from storage commerce:l t
function commerce:page/lettre_p_5_d with storage commerce:cp
