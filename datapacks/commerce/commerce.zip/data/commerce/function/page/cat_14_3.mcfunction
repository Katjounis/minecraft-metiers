function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 391
function commerce:page/ligne
data modify storage commerce:cp ve391 set from storage commerce:l ve
data modify storage commerce:cp vz391 set from storage commerce:l vz
data modify storage commerce:cp vc391 set from storage commerce:l vc
data modify storage commerce:cp ae391 set from storage commerce:l ae
data modify storage commerce:cp az391 set from storage commerce:l az
data modify storage commerce:cp ac391 set from storage commerce:l ac
data modify storage commerce:cp t391 set from storage commerce:l t
scoreboard players set #i c.t 392
function commerce:page/ligne
data modify storage commerce:cp ve392 set from storage commerce:l ve
data modify storage commerce:cp vz392 set from storage commerce:l vz
data modify storage commerce:cp vc392 set from storage commerce:l vc
data modify storage commerce:cp ae392 set from storage commerce:l ae
data modify storage commerce:cp az392 set from storage commerce:l az
data modify storage commerce:cp ac392 set from storage commerce:l ac
data modify storage commerce:cp t392 set from storage commerce:l t
scoreboard players set #i c.t 393
function commerce:page/ligne
data modify storage commerce:cp ve393 set from storage commerce:l ve
data modify storage commerce:cp vz393 set from storage commerce:l vz
data modify storage commerce:cp vc393 set from storage commerce:l vc
data modify storage commerce:cp ae393 set from storage commerce:l ae
data modify storage commerce:cp az393 set from storage commerce:l az
data modify storage commerce:cp ac393 set from storage commerce:l ac
data modify storage commerce:cp t393 set from storage commerce:l t
scoreboard players set #i c.t 394
function commerce:page/ligne
data modify storage commerce:cp ve394 set from storage commerce:l ve
data modify storage commerce:cp vz394 set from storage commerce:l vz
data modify storage commerce:cp vc394 set from storage commerce:l vc
data modify storage commerce:cp ae394 set from storage commerce:l ae
data modify storage commerce:cp az394 set from storage commerce:l az
data modify storage commerce:cp ac394 set from storage commerce:l ac
data modify storage commerce:cp t394 set from storage commerce:l t
scoreboard players set #i c.t 395
function commerce:page/ligne
data modify storage commerce:cp ve395 set from storage commerce:l ve
data modify storage commerce:cp vz395 set from storage commerce:l vz
data modify storage commerce:cp vc395 set from storage commerce:l vc
data modify storage commerce:cp ae395 set from storage commerce:l ae
data modify storage commerce:cp az395 set from storage commerce:l az
data modify storage commerce:cp ac395 set from storage commerce:l ac
data modify storage commerce:cp t395 set from storage commerce:l t
scoreboard players set #i c.t 396
function commerce:page/ligne
data modify storage commerce:cp ve396 set from storage commerce:l ve
data modify storage commerce:cp vz396 set from storage commerce:l vz
data modify storage commerce:cp vc396 set from storage commerce:l vc
data modify storage commerce:cp ae396 set from storage commerce:l ae
data modify storage commerce:cp az396 set from storage commerce:l az
data modify storage commerce:cp ac396 set from storage commerce:l ac
data modify storage commerce:cp t396 set from storage commerce:l t
scoreboard players set #i c.t 397
function commerce:page/ligne
data modify storage commerce:cp ve397 set from storage commerce:l ve
data modify storage commerce:cp vz397 set from storage commerce:l vz
data modify storage commerce:cp vc397 set from storage commerce:l vc
data modify storage commerce:cp ae397 set from storage commerce:l ae
data modify storage commerce:cp az397 set from storage commerce:l az
data modify storage commerce:cp ac397 set from storage commerce:l ac
data modify storage commerce:cp t397 set from storage commerce:l t
scoreboard players set #i c.t 398
function commerce:page/ligne
data modify storage commerce:cp ve398 set from storage commerce:l ve
data modify storage commerce:cp vz398 set from storage commerce:l vz
data modify storage commerce:cp vc398 set from storage commerce:l vc
data modify storage commerce:cp ae398 set from storage commerce:l ae
data modify storage commerce:cp az398 set from storage commerce:l az
data modify storage commerce:cp ac398 set from storage commerce:l ac
data modify storage commerce:cp t398 set from storage commerce:l t
function commerce:page/cat_14_3_d with storage commerce:cp
