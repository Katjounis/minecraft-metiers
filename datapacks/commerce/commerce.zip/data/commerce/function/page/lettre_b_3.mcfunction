function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 345
function commerce:page/ligne
data modify storage commerce:cp ve345 set from storage commerce:l ve
data modify storage commerce:cp vz345 set from storage commerce:l vz
data modify storage commerce:cp vc345 set from storage commerce:l vc
data modify storage commerce:cp ae345 set from storage commerce:l ae
data modify storage commerce:cp az345 set from storage commerce:l az
data modify storage commerce:cp ac345 set from storage commerce:l ac
data modify storage commerce:cp t345 set from storage commerce:l t
scoreboard players set #i c.t 245
function commerce:page/ligne
data modify storage commerce:cp ve245 set from storage commerce:l ve
data modify storage commerce:cp vz245 set from storage commerce:l vz
data modify storage commerce:cp vc245 set from storage commerce:l vc
data modify storage commerce:cp ae245 set from storage commerce:l ae
data modify storage commerce:cp az245 set from storage commerce:l az
data modify storage commerce:cp ac245 set from storage commerce:l ac
data modify storage commerce:cp t245 set from storage commerce:l t
scoreboard players set #i c.t 56
function commerce:page/ligne
data modify storage commerce:cp ve56 set from storage commerce:l ve
data modify storage commerce:cp vz56 set from storage commerce:l vz
data modify storage commerce:cp vc56 set from storage commerce:l vc
data modify storage commerce:cp ae56 set from storage commerce:l ae
data modify storage commerce:cp az56 set from storage commerce:l az
data modify storage commerce:cp ac56 set from storage commerce:l ac
data modify storage commerce:cp t56 set from storage commerce:l t
scoreboard players set #i c.t 434
function commerce:page/ligne
data modify storage commerce:cp ve434 set from storage commerce:l ve
data modify storage commerce:cp vz434 set from storage commerce:l vz
data modify storage commerce:cp vc434 set from storage commerce:l vc
data modify storage commerce:cp ae434 set from storage commerce:l ae
data modify storage commerce:cp az434 set from storage commerce:l az
data modify storage commerce:cp ac434 set from storage commerce:l ac
data modify storage commerce:cp t434 set from storage commerce:l t
scoreboard players set #i c.t 50
function commerce:page/ligne
data modify storage commerce:cp ve50 set from storage commerce:l ve
data modify storage commerce:cp vz50 set from storage commerce:l vz
data modify storage commerce:cp vc50 set from storage commerce:l vc
data modify storage commerce:cp ae50 set from storage commerce:l ae
data modify storage commerce:cp az50 set from storage commerce:l az
data modify storage commerce:cp ac50 set from storage commerce:l ac
data modify storage commerce:cp t50 set from storage commerce:l t
scoreboard players set #i c.t 237
function commerce:page/ligne
data modify storage commerce:cp ve237 set from storage commerce:l ve
data modify storage commerce:cp vz237 set from storage commerce:l vz
data modify storage commerce:cp vc237 set from storage commerce:l vc
data modify storage commerce:cp ae237 set from storage commerce:l ae
data modify storage commerce:cp az237 set from storage commerce:l az
data modify storage commerce:cp ac237 set from storage commerce:l ac
data modify storage commerce:cp t237 set from storage commerce:l t
scoreboard players set #i c.t 238
function commerce:page/ligne
data modify storage commerce:cp ve238 set from storage commerce:l ve
data modify storage commerce:cp vz238 set from storage commerce:l vz
data modify storage commerce:cp vc238 set from storage commerce:l vc
data modify storage commerce:cp ae238 set from storage commerce:l ae
data modify storage commerce:cp az238 set from storage commerce:l az
data modify storage commerce:cp ac238 set from storage commerce:l ac
data modify storage commerce:cp t238 set from storage commerce:l t
scoreboard players set #i c.t 272
function commerce:page/ligne
data modify storage commerce:cp ve272 set from storage commerce:l ve
data modify storage commerce:cp vz272 set from storage commerce:l vz
data modify storage commerce:cp vc272 set from storage commerce:l vc
data modify storage commerce:cp ae272 set from storage commerce:l ae
data modify storage commerce:cp az272 set from storage commerce:l az
data modify storage commerce:cp ac272 set from storage commerce:l ac
data modify storage commerce:cp t272 set from storage commerce:l t
scoreboard players set #i c.t 86
function commerce:page/ligne
data modify storage commerce:cp ve86 set from storage commerce:l ve
data modify storage commerce:cp vz86 set from storage commerce:l vz
data modify storage commerce:cp vc86 set from storage commerce:l vc
data modify storage commerce:cp ae86 set from storage commerce:l ae
data modify storage commerce:cp az86 set from storage commerce:l az
data modify storage commerce:cp ac86 set from storage commerce:l ac
data modify storage commerce:cp t86 set from storage commerce:l t
scoreboard players set #i c.t 87
function commerce:page/ligne
data modify storage commerce:cp ve87 set from storage commerce:l ve
data modify storage commerce:cp vz87 set from storage commerce:l vz
data modify storage commerce:cp vc87 set from storage commerce:l vc
data modify storage commerce:cp ae87 set from storage commerce:l ae
data modify storage commerce:cp az87 set from storage commerce:l az
data modify storage commerce:cp ac87 set from storage commerce:l ac
data modify storage commerce:cp t87 set from storage commerce:l t
function commerce:page/lettre_b_3_d with storage commerce:cp
