function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 334
function commerce:page/ligne
data modify storage commerce:cp ve334 set from storage commerce:l ve
data modify storage commerce:cp vz334 set from storage commerce:l vz
data modify storage commerce:cp vc334 set from storage commerce:l vc
data modify storage commerce:cp ae334 set from storage commerce:l ae
data modify storage commerce:cp az334 set from storage commerce:l az
data modify storage commerce:cp ac334 set from storage commerce:l ac
data modify storage commerce:cp t334 set from storage commerce:l t
scoreboard players set #i c.t 335
function commerce:page/ligne
data modify storage commerce:cp ve335 set from storage commerce:l ve
data modify storage commerce:cp vz335 set from storage commerce:l vz
data modify storage commerce:cp vc335 set from storage commerce:l vc
data modify storage commerce:cp ae335 set from storage commerce:l ae
data modify storage commerce:cp az335 set from storage commerce:l az
data modify storage commerce:cp ac335 set from storage commerce:l ac
data modify storage commerce:cp t335 set from storage commerce:l t
scoreboard players set #i c.t 336
function commerce:page/ligne
data modify storage commerce:cp ve336 set from storage commerce:l ve
data modify storage commerce:cp vz336 set from storage commerce:l vz
data modify storage commerce:cp vc336 set from storage commerce:l vc
data modify storage commerce:cp ae336 set from storage commerce:l ae
data modify storage commerce:cp az336 set from storage commerce:l az
data modify storage commerce:cp ac336 set from storage commerce:l ac
data modify storage commerce:cp t336 set from storage commerce:l t
scoreboard players set #i c.t 337
function commerce:page/ligne
data modify storage commerce:cp ve337 set from storage commerce:l ve
data modify storage commerce:cp vz337 set from storage commerce:l vz
data modify storage commerce:cp vc337 set from storage commerce:l vc
data modify storage commerce:cp ae337 set from storage commerce:l ae
data modify storage commerce:cp az337 set from storage commerce:l az
data modify storage commerce:cp ac337 set from storage commerce:l ac
data modify storage commerce:cp t337 set from storage commerce:l t
scoreboard players set #i c.t 338
function commerce:page/ligne
data modify storage commerce:cp ve338 set from storage commerce:l ve
data modify storage commerce:cp vz338 set from storage commerce:l vz
data modify storage commerce:cp vc338 set from storage commerce:l vc
data modify storage commerce:cp ae338 set from storage commerce:l ae
data modify storage commerce:cp az338 set from storage commerce:l az
data modify storage commerce:cp ac338 set from storage commerce:l ac
data modify storage commerce:cp t338 set from storage commerce:l t
scoreboard players set #i c.t 339
function commerce:page/ligne
data modify storage commerce:cp ve339 set from storage commerce:l ve
data modify storage commerce:cp vz339 set from storage commerce:l vz
data modify storage commerce:cp vc339 set from storage commerce:l vc
data modify storage commerce:cp ae339 set from storage commerce:l ae
data modify storage commerce:cp az339 set from storage commerce:l az
data modify storage commerce:cp ac339 set from storage commerce:l ac
data modify storage commerce:cp t339 set from storage commerce:l t
scoreboard players set #i c.t 340
function commerce:page/ligne
data modify storage commerce:cp ve340 set from storage commerce:l ve
data modify storage commerce:cp vz340 set from storage commerce:l vz
data modify storage commerce:cp vc340 set from storage commerce:l vc
data modify storage commerce:cp ae340 set from storage commerce:l ae
data modify storage commerce:cp az340 set from storage commerce:l az
data modify storage commerce:cp ac340 set from storage commerce:l ac
data modify storage commerce:cp t340 set from storage commerce:l t
scoreboard players set #i c.t 341
function commerce:page/ligne
data modify storage commerce:cp ve341 set from storage commerce:l ve
data modify storage commerce:cp vz341 set from storage commerce:l vz
data modify storage commerce:cp vc341 set from storage commerce:l vc
data modify storage commerce:cp ae341 set from storage commerce:l ae
data modify storage commerce:cp az341 set from storage commerce:l az
data modify storage commerce:cp ac341 set from storage commerce:l ac
data modify storage commerce:cp t341 set from storage commerce:l t
scoreboard players set #i c.t 342
function commerce:page/ligne
data modify storage commerce:cp ve342 set from storage commerce:l ve
data modify storage commerce:cp vz342 set from storage commerce:l vz
data modify storage commerce:cp vc342 set from storage commerce:l vc
data modify storage commerce:cp ae342 set from storage commerce:l ae
data modify storage commerce:cp az342 set from storage commerce:l az
data modify storage commerce:cp ac342 set from storage commerce:l ac
data modify storage commerce:cp t342 set from storage commerce:l t
scoreboard players set #i c.t 343
function commerce:page/ligne
data modify storage commerce:cp ve343 set from storage commerce:l ve
data modify storage commerce:cp vz343 set from storage commerce:l vz
data modify storage commerce:cp vc343 set from storage commerce:l vc
data modify storage commerce:cp ae343 set from storage commerce:l ae
data modify storage commerce:cp az343 set from storage commerce:l az
data modify storage commerce:cp ac343 set from storage commerce:l ac
data modify storage commerce:cp t343 set from storage commerce:l t
function commerce:page/cat_12_0_d with storage commerce:cp
