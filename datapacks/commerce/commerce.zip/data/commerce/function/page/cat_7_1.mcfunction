function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 197
function commerce:page/ligne
data modify storage commerce:cp ve197 set from storage commerce:l ve
data modify storage commerce:cp vz197 set from storage commerce:l vz
data modify storage commerce:cp vc197 set from storage commerce:l vc
data modify storage commerce:cp ae197 set from storage commerce:l ae
data modify storage commerce:cp az197 set from storage commerce:l az
data modify storage commerce:cp ac197 set from storage commerce:l ac
data modify storage commerce:cp t197 set from storage commerce:l t
scoreboard players set #i c.t 198
function commerce:page/ligne
data modify storage commerce:cp ve198 set from storage commerce:l ve
data modify storage commerce:cp vz198 set from storage commerce:l vz
data modify storage commerce:cp vc198 set from storage commerce:l vc
data modify storage commerce:cp ae198 set from storage commerce:l ae
data modify storage commerce:cp az198 set from storage commerce:l az
data modify storage commerce:cp ac198 set from storage commerce:l ac
data modify storage commerce:cp t198 set from storage commerce:l t
scoreboard players set #i c.t 199
function commerce:page/ligne
data modify storage commerce:cp ve199 set from storage commerce:l ve
data modify storage commerce:cp vz199 set from storage commerce:l vz
data modify storage commerce:cp vc199 set from storage commerce:l vc
data modify storage commerce:cp ae199 set from storage commerce:l ae
data modify storage commerce:cp az199 set from storage commerce:l az
data modify storage commerce:cp ac199 set from storage commerce:l ac
data modify storage commerce:cp t199 set from storage commerce:l t
scoreboard players set #i c.t 200
function commerce:page/ligne
data modify storage commerce:cp ve200 set from storage commerce:l ve
data modify storage commerce:cp vz200 set from storage commerce:l vz
data modify storage commerce:cp vc200 set from storage commerce:l vc
data modify storage commerce:cp ae200 set from storage commerce:l ae
data modify storage commerce:cp az200 set from storage commerce:l az
data modify storage commerce:cp ac200 set from storage commerce:l ac
data modify storage commerce:cp t200 set from storage commerce:l t
scoreboard players set #i c.t 201
function commerce:page/ligne
data modify storage commerce:cp ve201 set from storage commerce:l ve
data modify storage commerce:cp vz201 set from storage commerce:l vz
data modify storage commerce:cp vc201 set from storage commerce:l vc
data modify storage commerce:cp ae201 set from storage commerce:l ae
data modify storage commerce:cp az201 set from storage commerce:l az
data modify storage commerce:cp ac201 set from storage commerce:l ac
data modify storage commerce:cp t201 set from storage commerce:l t
scoreboard players set #i c.t 202
function commerce:page/ligne
data modify storage commerce:cp ve202 set from storage commerce:l ve
data modify storage commerce:cp vz202 set from storage commerce:l vz
data modify storage commerce:cp vc202 set from storage commerce:l vc
data modify storage commerce:cp ae202 set from storage commerce:l ae
data modify storage commerce:cp az202 set from storage commerce:l az
data modify storage commerce:cp ac202 set from storage commerce:l ac
data modify storage commerce:cp t202 set from storage commerce:l t
scoreboard players set #i c.t 203
function commerce:page/ligne
data modify storage commerce:cp ve203 set from storage commerce:l ve
data modify storage commerce:cp vz203 set from storage commerce:l vz
data modify storage commerce:cp vc203 set from storage commerce:l vc
data modify storage commerce:cp ae203 set from storage commerce:l ae
data modify storage commerce:cp az203 set from storage commerce:l az
data modify storage commerce:cp ac203 set from storage commerce:l ac
data modify storage commerce:cp t203 set from storage commerce:l t
scoreboard players set #i c.t 204
function commerce:page/ligne
data modify storage commerce:cp ve204 set from storage commerce:l ve
data modify storage commerce:cp vz204 set from storage commerce:l vz
data modify storage commerce:cp vc204 set from storage commerce:l vc
data modify storage commerce:cp ae204 set from storage commerce:l ae
data modify storage commerce:cp az204 set from storage commerce:l az
data modify storage commerce:cp ac204 set from storage commerce:l ac
data modify storage commerce:cp t204 set from storage commerce:l t
scoreboard players set #i c.t 205
function commerce:page/ligne
data modify storage commerce:cp ve205 set from storage commerce:l ve
data modify storage commerce:cp vz205 set from storage commerce:l vz
data modify storage commerce:cp vc205 set from storage commerce:l vc
data modify storage commerce:cp ae205 set from storage commerce:l ae
data modify storage commerce:cp az205 set from storage commerce:l az
data modify storage commerce:cp ac205 set from storage commerce:l ac
data modify storage commerce:cp t205 set from storage commerce:l t
scoreboard players set #i c.t 206
function commerce:page/ligne
data modify storage commerce:cp ve206 set from storage commerce:l ve
data modify storage commerce:cp vz206 set from storage commerce:l vz
data modify storage commerce:cp vc206 set from storage commerce:l vc
data modify storage commerce:cp ae206 set from storage commerce:l ae
data modify storage commerce:cp az206 set from storage commerce:l az
data modify storage commerce:cp ac206 set from storage commerce:l ac
data modify storage commerce:cp t206 set from storage commerce:l t
function commerce:page/cat_7_1_d with storage commerce:cp
