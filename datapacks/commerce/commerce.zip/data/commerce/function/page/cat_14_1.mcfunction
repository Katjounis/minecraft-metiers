function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 371
function commerce:page/ligne
data modify storage commerce:cp ve371 set from storage commerce:l ve
data modify storage commerce:cp vz371 set from storage commerce:l vz
data modify storage commerce:cp vc371 set from storage commerce:l vc
data modify storage commerce:cp ae371 set from storage commerce:l ae
data modify storage commerce:cp az371 set from storage commerce:l az
data modify storage commerce:cp ac371 set from storage commerce:l ac
data modify storage commerce:cp t371 set from storage commerce:l t
scoreboard players set #i c.t 372
function commerce:page/ligne
data modify storage commerce:cp ve372 set from storage commerce:l ve
data modify storage commerce:cp vz372 set from storage commerce:l vz
data modify storage commerce:cp vc372 set from storage commerce:l vc
data modify storage commerce:cp ae372 set from storage commerce:l ae
data modify storage commerce:cp az372 set from storage commerce:l az
data modify storage commerce:cp ac372 set from storage commerce:l ac
data modify storage commerce:cp t372 set from storage commerce:l t
scoreboard players set #i c.t 373
function commerce:page/ligne
data modify storage commerce:cp ve373 set from storage commerce:l ve
data modify storage commerce:cp vz373 set from storage commerce:l vz
data modify storage commerce:cp vc373 set from storage commerce:l vc
data modify storage commerce:cp ae373 set from storage commerce:l ae
data modify storage commerce:cp az373 set from storage commerce:l az
data modify storage commerce:cp ac373 set from storage commerce:l ac
data modify storage commerce:cp t373 set from storage commerce:l t
scoreboard players set #i c.t 374
function commerce:page/ligne
data modify storage commerce:cp ve374 set from storage commerce:l ve
data modify storage commerce:cp vz374 set from storage commerce:l vz
data modify storage commerce:cp vc374 set from storage commerce:l vc
data modify storage commerce:cp ae374 set from storage commerce:l ae
data modify storage commerce:cp az374 set from storage commerce:l az
data modify storage commerce:cp ac374 set from storage commerce:l ac
data modify storage commerce:cp t374 set from storage commerce:l t
scoreboard players set #i c.t 375
function commerce:page/ligne
data modify storage commerce:cp ve375 set from storage commerce:l ve
data modify storage commerce:cp vz375 set from storage commerce:l vz
data modify storage commerce:cp vc375 set from storage commerce:l vc
data modify storage commerce:cp ae375 set from storage commerce:l ae
data modify storage commerce:cp az375 set from storage commerce:l az
data modify storage commerce:cp ac375 set from storage commerce:l ac
data modify storage commerce:cp t375 set from storage commerce:l t
scoreboard players set #i c.t 376
function commerce:page/ligne
data modify storage commerce:cp ve376 set from storage commerce:l ve
data modify storage commerce:cp vz376 set from storage commerce:l vz
data modify storage commerce:cp vc376 set from storage commerce:l vc
data modify storage commerce:cp ae376 set from storage commerce:l ae
data modify storage commerce:cp az376 set from storage commerce:l az
data modify storage commerce:cp ac376 set from storage commerce:l ac
data modify storage commerce:cp t376 set from storage commerce:l t
scoreboard players set #i c.t 377
function commerce:page/ligne
data modify storage commerce:cp ve377 set from storage commerce:l ve
data modify storage commerce:cp vz377 set from storage commerce:l vz
data modify storage commerce:cp vc377 set from storage commerce:l vc
data modify storage commerce:cp ae377 set from storage commerce:l ae
data modify storage commerce:cp az377 set from storage commerce:l az
data modify storage commerce:cp ac377 set from storage commerce:l ac
data modify storage commerce:cp t377 set from storage commerce:l t
scoreboard players set #i c.t 378
function commerce:page/ligne
data modify storage commerce:cp ve378 set from storage commerce:l ve
data modify storage commerce:cp vz378 set from storage commerce:l vz
data modify storage commerce:cp vc378 set from storage commerce:l vc
data modify storage commerce:cp ae378 set from storage commerce:l ae
data modify storage commerce:cp az378 set from storage commerce:l az
data modify storage commerce:cp ac378 set from storage commerce:l ac
data modify storage commerce:cp t378 set from storage commerce:l t
scoreboard players set #i c.t 379
function commerce:page/ligne
data modify storage commerce:cp ve379 set from storage commerce:l ve
data modify storage commerce:cp vz379 set from storage commerce:l vz
data modify storage commerce:cp vc379 set from storage commerce:l vc
data modify storage commerce:cp ae379 set from storage commerce:l ae
data modify storage commerce:cp az379 set from storage commerce:l az
data modify storage commerce:cp ac379 set from storage commerce:l ac
data modify storage commerce:cp t379 set from storage commerce:l t
scoreboard players set #i c.t 380
function commerce:page/ligne
data modify storage commerce:cp ve380 set from storage commerce:l ve
data modify storage commerce:cp vz380 set from storage commerce:l vz
data modify storage commerce:cp vc380 set from storage commerce:l vc
data modify storage commerce:cp ae380 set from storage commerce:l ae
data modify storage commerce:cp az380 set from storage commerce:l az
data modify storage commerce:cp ac380 set from storage commerce:l ac
data modify storage commerce:cp t380 set from storage commerce:l t
function commerce:page/cat_14_1_d with storage commerce:cp
