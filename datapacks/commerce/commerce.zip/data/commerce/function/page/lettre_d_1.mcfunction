function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 482
function commerce:page/ligne
data modify storage commerce:cp ve482 set from storage commerce:l ve
data modify storage commerce:cp vz482 set from storage commerce:l vz
data modify storage commerce:cp vc482 set from storage commerce:l vc
data modify storage commerce:cp ae482 set from storage commerce:l ae
data modify storage commerce:cp az482 set from storage commerce:l az
data modify storage commerce:cp ac482 set from storage commerce:l ac
data modify storage commerce:cp t482 set from storage commerce:l t
scoreboard players set #i c.t 481
function commerce:page/ligne
data modify storage commerce:cp ve481 set from storage commerce:l ve
data modify storage commerce:cp vz481 set from storage commerce:l vz
data modify storage commerce:cp vc481 set from storage commerce:l vc
data modify storage commerce:cp ae481 set from storage commerce:l ae
data modify storage commerce:cp az481 set from storage commerce:l az
data modify storage commerce:cp ac481 set from storage commerce:l ac
data modify storage commerce:cp t481 set from storage commerce:l t
scoreboard players set #i c.t 477
function commerce:page/ligne
data modify storage commerce:cp ve477 set from storage commerce:l ve
data modify storage commerce:cp vz477 set from storage commerce:l vz
data modify storage commerce:cp vc477 set from storage commerce:l vc
data modify storage commerce:cp ae477 set from storage commerce:l ae
data modify storage commerce:cp az477 set from storage commerce:l az
data modify storage commerce:cp ac477 set from storage commerce:l ac
data modify storage commerce:cp t477 set from storage commerce:l t
scoreboard players set #i c.t 478
function commerce:page/ligne
data modify storage commerce:cp ve478 set from storage commerce:l ve
data modify storage commerce:cp vz478 set from storage commerce:l vz
data modify storage commerce:cp vc478 set from storage commerce:l vc
data modify storage commerce:cp ae478 set from storage commerce:l ae
data modify storage commerce:cp az478 set from storage commerce:l az
data modify storage commerce:cp ac478 set from storage commerce:l ac
data modify storage commerce:cp t478 set from storage commerce:l t
scoreboard players set #i c.t 480
function commerce:page/ligne
data modify storage commerce:cp ve480 set from storage commerce:l ve
data modify storage commerce:cp vz480 set from storage commerce:l vz
data modify storage commerce:cp vc480 set from storage commerce:l vc
data modify storage commerce:cp ae480 set from storage commerce:l ae
data modify storage commerce:cp az480 set from storage commerce:l az
data modify storage commerce:cp ac480 set from storage commerce:l ac
data modify storage commerce:cp t480 set from storage commerce:l t
scoreboard players set #i c.t 479
function commerce:page/ligne
data modify storage commerce:cp ve479 set from storage commerce:l ve
data modify storage commerce:cp vz479 set from storage commerce:l vz
data modify storage commerce:cp vc479 set from storage commerce:l vc
data modify storage commerce:cp ae479 set from storage commerce:l ae
data modify storage commerce:cp az479 set from storage commerce:l az
data modify storage commerce:cp ac479 set from storage commerce:l ac
data modify storage commerce:cp t479 set from storage commerce:l t
scoreboard players set #i c.t 384
function commerce:page/ligne
data modify storage commerce:cp ve384 set from storage commerce:l ve
data modify storage commerce:cp vz384 set from storage commerce:l vz
data modify storage commerce:cp vc384 set from storage commerce:l vc
data modify storage commerce:cp ae384 set from storage commerce:l ae
data modify storage commerce:cp az384 set from storage commerce:l az
data modify storage commerce:cp ac384 set from storage commerce:l ac
data modify storage commerce:cp t384 set from storage commerce:l t
scoreboard players set #i c.t 383
function commerce:page/ligne
data modify storage commerce:cp ve383 set from storage commerce:l ve
data modify storage commerce:cp vz383 set from storage commerce:l vz
data modify storage commerce:cp vc383 set from storage commerce:l vc
data modify storage commerce:cp ae383 set from storage commerce:l ae
data modify storage commerce:cp az383 set from storage commerce:l az
data modify storage commerce:cp ac383 set from storage commerce:l ac
data modify storage commerce:cp t383 set from storage commerce:l t
function commerce:page/lettre_d_1_d with storage commerce:cp
