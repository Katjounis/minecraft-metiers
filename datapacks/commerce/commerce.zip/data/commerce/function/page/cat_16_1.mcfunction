function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 409
function commerce:page/ligne
data modify storage commerce:cp ve409 set from storage commerce:l ve
data modify storage commerce:cp vz409 set from storage commerce:l vz
data modify storage commerce:cp vc409 set from storage commerce:l vc
data modify storage commerce:cp ae409 set from storage commerce:l ae
data modify storage commerce:cp az409 set from storage commerce:l az
data modify storage commerce:cp ac409 set from storage commerce:l ac
data modify storage commerce:cp t409 set from storage commerce:l t
scoreboard players set #i c.t 410
function commerce:page/ligne
data modify storage commerce:cp ve410 set from storage commerce:l ve
data modify storage commerce:cp vz410 set from storage commerce:l vz
data modify storage commerce:cp vc410 set from storage commerce:l vc
data modify storage commerce:cp ae410 set from storage commerce:l ae
data modify storage commerce:cp az410 set from storage commerce:l az
data modify storage commerce:cp ac410 set from storage commerce:l ac
data modify storage commerce:cp t410 set from storage commerce:l t
scoreboard players set #i c.t 411
function commerce:page/ligne
data modify storage commerce:cp ve411 set from storage commerce:l ve
data modify storage commerce:cp vz411 set from storage commerce:l vz
data modify storage commerce:cp vc411 set from storage commerce:l vc
data modify storage commerce:cp ae411 set from storage commerce:l ae
data modify storage commerce:cp az411 set from storage commerce:l az
data modify storage commerce:cp ac411 set from storage commerce:l ac
data modify storage commerce:cp t411 set from storage commerce:l t
scoreboard players set #i c.t 412
function commerce:page/ligne
data modify storage commerce:cp ve412 set from storage commerce:l ve
data modify storage commerce:cp vz412 set from storage commerce:l vz
data modify storage commerce:cp vc412 set from storage commerce:l vc
data modify storage commerce:cp ae412 set from storage commerce:l ae
data modify storage commerce:cp az412 set from storage commerce:l az
data modify storage commerce:cp ac412 set from storage commerce:l ac
data modify storage commerce:cp t412 set from storage commerce:l t
scoreboard players set #i c.t 413
function commerce:page/ligne
data modify storage commerce:cp ve413 set from storage commerce:l ve
data modify storage commerce:cp vz413 set from storage commerce:l vz
data modify storage commerce:cp vc413 set from storage commerce:l vc
data modify storage commerce:cp ae413 set from storage commerce:l ae
data modify storage commerce:cp az413 set from storage commerce:l az
data modify storage commerce:cp ac413 set from storage commerce:l ac
data modify storage commerce:cp t413 set from storage commerce:l t
scoreboard players set #i c.t 414
function commerce:page/ligne
data modify storage commerce:cp ve414 set from storage commerce:l ve
data modify storage commerce:cp vz414 set from storage commerce:l vz
data modify storage commerce:cp vc414 set from storage commerce:l vc
data modify storage commerce:cp ae414 set from storage commerce:l ae
data modify storage commerce:cp az414 set from storage commerce:l az
data modify storage commerce:cp ac414 set from storage commerce:l ac
data modify storage commerce:cp t414 set from storage commerce:l t
scoreboard players set #i c.t 415
function commerce:page/ligne
data modify storage commerce:cp ve415 set from storage commerce:l ve
data modify storage commerce:cp vz415 set from storage commerce:l vz
data modify storage commerce:cp vc415 set from storage commerce:l vc
data modify storage commerce:cp ae415 set from storage commerce:l ae
data modify storage commerce:cp az415 set from storage commerce:l az
data modify storage commerce:cp ac415 set from storage commerce:l ac
data modify storage commerce:cp t415 set from storage commerce:l t
scoreboard players set #i c.t 416
function commerce:page/ligne
data modify storage commerce:cp ve416 set from storage commerce:l ve
data modify storage commerce:cp vz416 set from storage commerce:l vz
data modify storage commerce:cp vc416 set from storage commerce:l vc
data modify storage commerce:cp ae416 set from storage commerce:l ae
data modify storage commerce:cp az416 set from storage commerce:l az
data modify storage commerce:cp ac416 set from storage commerce:l ac
data modify storage commerce:cp t416 set from storage commerce:l t
scoreboard players set #i c.t 417
function commerce:page/ligne
data modify storage commerce:cp ve417 set from storage commerce:l ve
data modify storage commerce:cp vz417 set from storage commerce:l vz
data modify storage commerce:cp vc417 set from storage commerce:l vc
data modify storage commerce:cp ae417 set from storage commerce:l ae
data modify storage commerce:cp az417 set from storage commerce:l az
data modify storage commerce:cp ac417 set from storage commerce:l ac
data modify storage commerce:cp t417 set from storage commerce:l t
scoreboard players set #i c.t 418
function commerce:page/ligne
data modify storage commerce:cp ve418 set from storage commerce:l ve
data modify storage commerce:cp vz418 set from storage commerce:l vz
data modify storage commerce:cp vc418 set from storage commerce:l vc
data modify storage commerce:cp ae418 set from storage commerce:l ae
data modify storage commerce:cp az418 set from storage commerce:l az
data modify storage commerce:cp ac418 set from storage commerce:l ac
data modify storage commerce:cp t418 set from storage commerce:l t
function commerce:page/cat_16_1_d with storage commerce:cp
