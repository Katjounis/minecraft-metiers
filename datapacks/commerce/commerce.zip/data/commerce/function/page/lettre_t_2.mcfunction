function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 174
function commerce:page/ligne
data modify storage commerce:cp ve174 set from storage commerce:l ve
data modify storage commerce:cp vz174 set from storage commerce:l vz
data modify storage commerce:cp vc174 set from storage commerce:l vc
data modify storage commerce:cp ae174 set from storage commerce:l ae
data modify storage commerce:cp az174 set from storage commerce:l az
data modify storage commerce:cp ac174 set from storage commerce:l ac
data modify storage commerce:cp t174 set from storage commerce:l t
scoreboard players set #i c.t 182
function commerce:page/ligne
data modify storage commerce:cp ve182 set from storage commerce:l ve
data modify storage commerce:cp vz182 set from storage commerce:l vz
data modify storage commerce:cp vc182 set from storage commerce:l vc
data modify storage commerce:cp ae182 set from storage commerce:l ae
data modify storage commerce:cp az182 set from storage commerce:l az
data modify storage commerce:cp ac182 set from storage commerce:l ac
data modify storage commerce:cp t182 set from storage commerce:l t
scoreboard players set #i c.t 180
function commerce:page/ligne
data modify storage commerce:cp ve180 set from storage commerce:l ve
data modify storage commerce:cp vz180 set from storage commerce:l vz
data modify storage commerce:cp vc180 set from storage commerce:l vc
data modify storage commerce:cp ae180 set from storage commerce:l ae
data modify storage commerce:cp az180 set from storage commerce:l az
data modify storage commerce:cp ac180 set from storage commerce:l ac
data modify storage commerce:cp t180 set from storage commerce:l t
scoreboard players set #i c.t 205
function commerce:page/ligne
data modify storage commerce:cp ve205 set from storage commerce:l ve
data modify storage commerce:cp vz205 set from storage commerce:l vz
data modify storage commerce:cp vc205 set from storage commerce:l vc
data modify storage commerce:cp ae205 set from storage commerce:l ae
data modify storage commerce:cp az205 set from storage commerce:l az
data modify storage commerce:cp ac205 set from storage commerce:l ac
data modify storage commerce:cp t205 set from storage commerce:l t
scoreboard players set #i c.t 208
function commerce:page/ligne
data modify storage commerce:cp ve208 set from storage commerce:l ve
data modify storage commerce:cp vz208 set from storage commerce:l vz
data modify storage commerce:cp vc208 set from storage commerce:l vc
data modify storage commerce:cp ae208 set from storage commerce:l ae
data modify storage commerce:cp az208 set from storage commerce:l az
data modify storage commerce:cp ac208 set from storage commerce:l ac
data modify storage commerce:cp t208 set from storage commerce:l t
scoreboard players set #i c.t 216
function commerce:page/ligne
data modify storage commerce:cp ve216 set from storage commerce:l ve
data modify storage commerce:cp vz216 set from storage commerce:l vz
data modify storage commerce:cp vc216 set from storage commerce:l vc
data modify storage commerce:cp ae216 set from storage commerce:l ae
data modify storage commerce:cp az216 set from storage commerce:l az
data modify storage commerce:cp ac216 set from storage commerce:l ac
data modify storage commerce:cp t216 set from storage commerce:l t
scoreboard players set #i c.t 214
function commerce:page/ligne
data modify storage commerce:cp ve214 set from storage commerce:l ve
data modify storage commerce:cp vz214 set from storage commerce:l vz
data modify storage commerce:cp vc214 set from storage commerce:l vc
data modify storage commerce:cp ae214 set from storage commerce:l ae
data modify storage commerce:cp az214 set from storage commerce:l az
data modify storage commerce:cp ac214 set from storage commerce:l ac
data modify storage commerce:cp t214 set from storage commerce:l t
scoreboard players set #i c.t 213
function commerce:page/ligne
data modify storage commerce:cp ve213 set from storage commerce:l ve
data modify storage commerce:cp vz213 set from storage commerce:l vz
data modify storage commerce:cp vc213 set from storage commerce:l vc
data modify storage commerce:cp ae213 set from storage commerce:l ae
data modify storage commerce:cp az213 set from storage commerce:l az
data modify storage commerce:cp ac213 set from storage commerce:l ac
data modify storage commerce:cp t213 set from storage commerce:l t
scoreboard players set #i c.t 212
function commerce:page/ligne
data modify storage commerce:cp ve212 set from storage commerce:l ve
data modify storage commerce:cp vz212 set from storage commerce:l vz
data modify storage commerce:cp vc212 set from storage commerce:l vc
data modify storage commerce:cp ae212 set from storage commerce:l ae
data modify storage commerce:cp az212 set from storage commerce:l az
data modify storage commerce:cp ac212 set from storage commerce:l ac
data modify storage commerce:cp t212 set from storage commerce:l t
scoreboard players set #i c.t 209
function commerce:page/ligne
data modify storage commerce:cp ve209 set from storage commerce:l ve
data modify storage commerce:cp vz209 set from storage commerce:l vz
data modify storage commerce:cp vc209 set from storage commerce:l vc
data modify storage commerce:cp ae209 set from storage commerce:l ae
data modify storage commerce:cp az209 set from storage commerce:l az
data modify storage commerce:cp ac209 set from storage commerce:l ac
data modify storage commerce:cp t209 set from storage commerce:l t
function commerce:page/lettre_t_2_d with storage commerce:cp
