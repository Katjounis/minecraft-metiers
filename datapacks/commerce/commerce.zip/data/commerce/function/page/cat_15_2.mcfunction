function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 451
function commerce:page/ligne
data modify storage commerce:cp ve451 set from storage commerce:l ve
data modify storage commerce:cp vz451 set from storage commerce:l vz
data modify storage commerce:cp vc451 set from storage commerce:l vc
data modify storage commerce:cp ae451 set from storage commerce:l ae
data modify storage commerce:cp az451 set from storage commerce:l az
data modify storage commerce:cp ac451 set from storage commerce:l ac
data modify storage commerce:cp t451 set from storage commerce:l t
scoreboard players set #i c.t 452
function commerce:page/ligne
data modify storage commerce:cp ve452 set from storage commerce:l ve
data modify storage commerce:cp vz452 set from storage commerce:l vz
data modify storage commerce:cp vc452 set from storage commerce:l vc
data modify storage commerce:cp ae452 set from storage commerce:l ae
data modify storage commerce:cp az452 set from storage commerce:l az
data modify storage commerce:cp ac452 set from storage commerce:l ac
data modify storage commerce:cp t452 set from storage commerce:l t
scoreboard players set #i c.t 453
function commerce:page/ligne
data modify storage commerce:cp ve453 set from storage commerce:l ve
data modify storage commerce:cp vz453 set from storage commerce:l vz
data modify storage commerce:cp vc453 set from storage commerce:l vc
data modify storage commerce:cp ae453 set from storage commerce:l ae
data modify storage commerce:cp az453 set from storage commerce:l az
data modify storage commerce:cp ac453 set from storage commerce:l ac
data modify storage commerce:cp t453 set from storage commerce:l t
scoreboard players set #i c.t 454
function commerce:page/ligne
data modify storage commerce:cp ve454 set from storage commerce:l ve
data modify storage commerce:cp vz454 set from storage commerce:l vz
data modify storage commerce:cp vc454 set from storage commerce:l vc
data modify storage commerce:cp ae454 set from storage commerce:l ae
data modify storage commerce:cp az454 set from storage commerce:l az
data modify storage commerce:cp ac454 set from storage commerce:l ac
data modify storage commerce:cp t454 set from storage commerce:l t
scoreboard players set #i c.t 455
function commerce:page/ligne
data modify storage commerce:cp ve455 set from storage commerce:l ve
data modify storage commerce:cp vz455 set from storage commerce:l vz
data modify storage commerce:cp vc455 set from storage commerce:l vc
data modify storage commerce:cp ae455 set from storage commerce:l ae
data modify storage commerce:cp az455 set from storage commerce:l az
data modify storage commerce:cp ac455 set from storage commerce:l ac
data modify storage commerce:cp t455 set from storage commerce:l t
scoreboard players set #i c.t 456
function commerce:page/ligne
data modify storage commerce:cp ve456 set from storage commerce:l ve
data modify storage commerce:cp vz456 set from storage commerce:l vz
data modify storage commerce:cp vc456 set from storage commerce:l vc
data modify storage commerce:cp ae456 set from storage commerce:l ae
data modify storage commerce:cp az456 set from storage commerce:l az
data modify storage commerce:cp ac456 set from storage commerce:l ac
data modify storage commerce:cp t456 set from storage commerce:l t
scoreboard players set #i c.t 457
function commerce:page/ligne
data modify storage commerce:cp ve457 set from storage commerce:l ve
data modify storage commerce:cp vz457 set from storage commerce:l vz
data modify storage commerce:cp vc457 set from storage commerce:l vc
data modify storage commerce:cp ae457 set from storage commerce:l ae
data modify storage commerce:cp az457 set from storage commerce:l az
data modify storage commerce:cp ac457 set from storage commerce:l ac
data modify storage commerce:cp t457 set from storage commerce:l t
scoreboard players set #i c.t 458
function commerce:page/ligne
data modify storage commerce:cp ve458 set from storage commerce:l ve
data modify storage commerce:cp vz458 set from storage commerce:l vz
data modify storage commerce:cp vc458 set from storage commerce:l vc
data modify storage commerce:cp ae458 set from storage commerce:l ae
data modify storage commerce:cp az458 set from storage commerce:l az
data modify storage commerce:cp ac458 set from storage commerce:l ac
data modify storage commerce:cp t458 set from storage commerce:l t
function commerce:page/cat_15_2_d with storage commerce:cp
