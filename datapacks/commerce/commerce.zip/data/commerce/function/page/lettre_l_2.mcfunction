function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 364
function commerce:page/ligne
data modify storage commerce:cp ve364 set from storage commerce:l ve
data modify storage commerce:cp vz364 set from storage commerce:l vz
data modify storage commerce:cp vc364 set from storage commerce:l vc
data modify storage commerce:cp ae364 set from storage commerce:l ae
data modify storage commerce:cp az364 set from storage commerce:l az
data modify storage commerce:cp ac364 set from storage commerce:l ac
data modify storage commerce:cp t364 set from storage commerce:l t
scoreboard players set #i c.t 313
function commerce:page/ligne
data modify storage commerce:cp ve313 set from storage commerce:l ve
data modify storage commerce:cp vz313 set from storage commerce:l vz
data modify storage commerce:cp vc313 set from storage commerce:l vc
data modify storage commerce:cp ae313 set from storage commerce:l ae
data modify storage commerce:cp az313 set from storage commerce:l az
data modify storage commerce:cp ac313 set from storage commerce:l ac
data modify storage commerce:cp t313 set from storage commerce:l t
scoreboard players set #i c.t 357
function commerce:page/ligne
data modify storage commerce:cp ve357 set from storage commerce:l ve
data modify storage commerce:cp vz357 set from storage commerce:l vz
data modify storage commerce:cp vc357 set from storage commerce:l vc
data modify storage commerce:cp ae357 set from storage commerce:l ae
data modify storage commerce:cp az357 set from storage commerce:l az
data modify storage commerce:cp ac357 set from storage commerce:l ac
data modify storage commerce:cp t357 set from storage commerce:l t
scoreboard players set #i c.t 241
function commerce:page/ligne
data modify storage commerce:cp ve241 set from storage commerce:l ve
data modify storage commerce:cp vz241 set from storage commerce:l vz
data modify storage commerce:cp vc241 set from storage commerce:l vc
data modify storage commerce:cp ae241 set from storage commerce:l ae
data modify storage commerce:cp az241 set from storage commerce:l az
data modify storage commerce:cp ac241 set from storage commerce:l ac
data modify storage commerce:cp t241 set from storage commerce:l t
scoreboard players set #i c.t 443
function commerce:page/ligne
data modify storage commerce:cp ve443 set from storage commerce:l ve
data modify storage commerce:cp vz443 set from storage commerce:l vz
data modify storage commerce:cp vc443 set from storage commerce:l vc
data modify storage commerce:cp ae443 set from storage commerce:l ae
data modify storage commerce:cp az443 set from storage commerce:l az
data modify storage commerce:cp ac443 set from storage commerce:l ac
data modify storage commerce:cp t443 set from storage commerce:l t
scoreboard players set #i c.t 387
function commerce:page/ligne
data modify storage commerce:cp ve387 set from storage commerce:l ve
data modify storage commerce:cp vz387 set from storage commerce:l vz
data modify storage commerce:cp vc387 set from storage commerce:l vc
data modify storage commerce:cp ae387 set from storage commerce:l ae
data modify storage commerce:cp az387 set from storage commerce:l az
data modify storage commerce:cp ac387 set from storage commerce:l ac
data modify storage commerce:cp t387 set from storage commerce:l t
scoreboard players set #i c.t 421
function commerce:page/ligne
data modify storage commerce:cp ve421 set from storage commerce:l ve
data modify storage commerce:cp vz421 set from storage commerce:l vz
data modify storage commerce:cp vc421 set from storage commerce:l vc
data modify storage commerce:cp ae421 set from storage commerce:l ae
data modify storage commerce:cp az421 set from storage commerce:l az
data modify storage commerce:cp ac421 set from storage commerce:l ac
data modify storage commerce:cp t421 set from storage commerce:l t
scoreboard players set #i c.t 428
function commerce:page/ligne
data modify storage commerce:cp ve428 set from storage commerce:l ve
data modify storage commerce:cp vz428 set from storage commerce:l vz
data modify storage commerce:cp vc428 set from storage commerce:l vc
data modify storage commerce:cp ae428 set from storage commerce:l ae
data modify storage commerce:cp az428 set from storage commerce:l az
data modify storage commerce:cp ac428 set from storage commerce:l ac
data modify storage commerce:cp t428 set from storage commerce:l t
scoreboard players set #i c.t 414
function commerce:page/ligne
data modify storage commerce:cp ve414 set from storage commerce:l ve
data modify storage commerce:cp vz414 set from storage commerce:l vz
data modify storage commerce:cp vc414 set from storage commerce:l vc
data modify storage commerce:cp ae414 set from storage commerce:l ae
data modify storage commerce:cp az414 set from storage commerce:l az
data modify storage commerce:cp ac414 set from storage commerce:l ac
data modify storage commerce:cp t414 set from storage commerce:l t
scoreboard players set #i c.t 235
function commerce:page/ligne
data modify storage commerce:cp ve235 set from storage commerce:l ve
data modify storage commerce:cp vz235 set from storage commerce:l vz
data modify storage commerce:cp vc235 set from storage commerce:l vc
data modify storage commerce:cp ae235 set from storage commerce:l ae
data modify storage commerce:cp az235 set from storage commerce:l az
data modify storage commerce:cp ac235 set from storage commerce:l ac
data modify storage commerce:cp t235 set from storage commerce:l t
function commerce:page/lettre_l_2_d with storage commerce:cp
