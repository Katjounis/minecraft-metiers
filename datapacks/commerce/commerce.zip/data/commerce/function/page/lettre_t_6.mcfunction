function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 82
function commerce:page/ligne
data modify storage commerce:cp ve82 set from storage commerce:l ve
data modify storage commerce:cp vz82 set from storage commerce:l vz
data modify storage commerce:cp vc82 set from storage commerce:l vc
data modify storage commerce:cp ae82 set from storage commerce:l ae
data modify storage commerce:cp az82 set from storage commerce:l az
data modify storage commerce:cp ac82 set from storage commerce:l ac
data modify storage commerce:cp t82 set from storage commerce:l t
scoreboard players set #i c.t 83
function commerce:page/ligne
data modify storage commerce:cp ve83 set from storage commerce:l ve
data modify storage commerce:cp vz83 set from storage commerce:l vz
data modify storage commerce:cp vc83 set from storage commerce:l vc
data modify storage commerce:cp ae83 set from storage commerce:l ae
data modify storage commerce:cp az83 set from storage commerce:l az
data modify storage commerce:cp ac83 set from storage commerce:l ac
data modify storage commerce:cp t83 set from storage commerce:l t
scoreboard players set #i c.t 467
function commerce:page/ligne
data modify storage commerce:cp ve467 set from storage commerce:l ve
data modify storage commerce:cp vz467 set from storage commerce:l vz
data modify storage commerce:cp vc467 set from storage commerce:l vc
data modify storage commerce:cp ae467 set from storage commerce:l ae
data modify storage commerce:cp az467 set from storage commerce:l az
data modify storage commerce:cp ac467 set from storage commerce:l ac
data modify storage commerce:cp t467 set from storage commerce:l t
scoreboard players set #i c.t 470
function commerce:page/ligne
data modify storage commerce:cp ve470 set from storage commerce:l ve
data modify storage commerce:cp vz470 set from storage commerce:l vz
data modify storage commerce:cp vc470 set from storage commerce:l vc
data modify storage commerce:cp ae470 set from storage commerce:l ae
data modify storage commerce:cp az470 set from storage commerce:l az
data modify storage commerce:cp ac470 set from storage commerce:l ac
data modify storage commerce:cp t470 set from storage commerce:l t
scoreboard players set #i c.t 369
function commerce:page/ligne
data modify storage commerce:cp ve369 set from storage commerce:l ve
data modify storage commerce:cp vz369 set from storage commerce:l vz
data modify storage commerce:cp vc369 set from storage commerce:l vc
data modify storage commerce:cp ae369 set from storage commerce:l ae
data modify storage commerce:cp az369 set from storage commerce:l az
data modify storage commerce:cp ac369 set from storage commerce:l ac
data modify storage commerce:cp t369 set from storage commerce:l t
scoreboard players set #i c.t 361
function commerce:page/ligne
data modify storage commerce:cp ve361 set from storage commerce:l ve
data modify storage commerce:cp vz361 set from storage commerce:l vz
data modify storage commerce:cp vc361 set from storage commerce:l vc
data modify storage commerce:cp ae361 set from storage commerce:l ae
data modify storage commerce:cp az361 set from storage commerce:l az
data modify storage commerce:cp ac361 set from storage commerce:l ac
data modify storage commerce:cp t361 set from storage commerce:l t
scoreboard players set #i c.t 388
function commerce:page/ligne
data modify storage commerce:cp ve388 set from storage commerce:l ve
data modify storage commerce:cp vz388 set from storage commerce:l vz
data modify storage commerce:cp vc388 set from storage commerce:l vc
data modify storage commerce:cp ae388 set from storage commerce:l ae
data modify storage commerce:cp az388 set from storage commerce:l az
data modify storage commerce:cp ac388 set from storage commerce:l ac
data modify storage commerce:cp t388 set from storage commerce:l t
scoreboard players set #i c.t 362
function commerce:page/ligne
data modify storage commerce:cp ve362 set from storage commerce:l ve
data modify storage commerce:cp vz362 set from storage commerce:l vz
data modify storage commerce:cp vc362 set from storage commerce:l vc
data modify storage commerce:cp ae362 set from storage commerce:l ae
data modify storage commerce:cp az362 set from storage commerce:l az
data modify storage commerce:cp ac362 set from storage commerce:l ac
data modify storage commerce:cp t362 set from storage commerce:l t
scoreboard players set #i c.t 445
function commerce:page/ligne
data modify storage commerce:cp ve445 set from storage commerce:l ve
data modify storage commerce:cp vz445 set from storage commerce:l vz
data modify storage commerce:cp vc445 set from storage commerce:l vc
data modify storage commerce:cp ae445 set from storage commerce:l ae
data modify storage commerce:cp az445 set from storage commerce:l az
data modify storage commerce:cp ac445 set from storage commerce:l ac
data modify storage commerce:cp t445 set from storage commerce:l t
scoreboard players set #i c.t 413
function commerce:page/ligne
data modify storage commerce:cp ve413 set from storage commerce:l ve
data modify storage commerce:cp vz413 set from storage commerce:l vz
data modify storage commerce:cp vc413 set from storage commerce:l vc
data modify storage commerce:cp ae413 set from storage commerce:l ae
data modify storage commerce:cp az413 set from storage commerce:l az
data modify storage commerce:cp ac413 set from storage commerce:l ac
data modify storage commerce:cp t413 set from storage commerce:l t
function commerce:page/lettre_t_6_d with storage commerce:cp
