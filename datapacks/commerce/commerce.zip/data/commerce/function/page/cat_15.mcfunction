function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 431
function commerce:page/ligne
data modify storage commerce:cp ve431 set from storage commerce:l ve
data modify storage commerce:cp vz431 set from storage commerce:l vz
data modify storage commerce:cp vc431 set from storage commerce:l vc
data modify storage commerce:cp ae431 set from storage commerce:l ae
data modify storage commerce:cp az431 set from storage commerce:l az
data modify storage commerce:cp ac431 set from storage commerce:l ac
data modify storage commerce:cp t431 set from storage commerce:l t
data modify storage commerce:cp tc431 set from storage commerce:l tc
scoreboard players set #i c.t 432
function commerce:page/ligne
data modify storage commerce:cp ve432 set from storage commerce:l ve
data modify storage commerce:cp vz432 set from storage commerce:l vz
data modify storage commerce:cp vc432 set from storage commerce:l vc
data modify storage commerce:cp ae432 set from storage commerce:l ae
data modify storage commerce:cp az432 set from storage commerce:l az
data modify storage commerce:cp ac432 set from storage commerce:l ac
data modify storage commerce:cp t432 set from storage commerce:l t
data modify storage commerce:cp tc432 set from storage commerce:l tc
scoreboard players set #i c.t 433
function commerce:page/ligne
data modify storage commerce:cp ve433 set from storage commerce:l ve
data modify storage commerce:cp vz433 set from storage commerce:l vz
data modify storage commerce:cp vc433 set from storage commerce:l vc
data modify storage commerce:cp ae433 set from storage commerce:l ae
data modify storage commerce:cp az433 set from storage commerce:l az
data modify storage commerce:cp ac433 set from storage commerce:l ac
data modify storage commerce:cp t433 set from storage commerce:l t
data modify storage commerce:cp tc433 set from storage commerce:l tc
scoreboard players set #i c.t 434
function commerce:page/ligne
data modify storage commerce:cp ve434 set from storage commerce:l ve
data modify storage commerce:cp vz434 set from storage commerce:l vz
data modify storage commerce:cp vc434 set from storage commerce:l vc
data modify storage commerce:cp ae434 set from storage commerce:l ae
data modify storage commerce:cp az434 set from storage commerce:l az
data modify storage commerce:cp ac434 set from storage commerce:l ac
data modify storage commerce:cp t434 set from storage commerce:l t
data modify storage commerce:cp tc434 set from storage commerce:l tc
scoreboard players set #i c.t 435
function commerce:page/ligne
data modify storage commerce:cp ve435 set from storage commerce:l ve
data modify storage commerce:cp vz435 set from storage commerce:l vz
data modify storage commerce:cp vc435 set from storage commerce:l vc
data modify storage commerce:cp ae435 set from storage commerce:l ae
data modify storage commerce:cp az435 set from storage commerce:l az
data modify storage commerce:cp ac435 set from storage commerce:l ac
data modify storage commerce:cp t435 set from storage commerce:l t
data modify storage commerce:cp tc435 set from storage commerce:l tc
scoreboard players set #i c.t 436
function commerce:page/ligne
data modify storage commerce:cp ve436 set from storage commerce:l ve
data modify storage commerce:cp vz436 set from storage commerce:l vz
data modify storage commerce:cp vc436 set from storage commerce:l vc
data modify storage commerce:cp ae436 set from storage commerce:l ae
data modify storage commerce:cp az436 set from storage commerce:l az
data modify storage commerce:cp ac436 set from storage commerce:l ac
data modify storage commerce:cp t436 set from storage commerce:l t
data modify storage commerce:cp tc436 set from storage commerce:l tc
scoreboard players set #i c.t 437
function commerce:page/ligne
data modify storage commerce:cp ve437 set from storage commerce:l ve
data modify storage commerce:cp vz437 set from storage commerce:l vz
data modify storage commerce:cp vc437 set from storage commerce:l vc
data modify storage commerce:cp ae437 set from storage commerce:l ae
data modify storage commerce:cp az437 set from storage commerce:l az
data modify storage commerce:cp ac437 set from storage commerce:l ac
data modify storage commerce:cp t437 set from storage commerce:l t
data modify storage commerce:cp tc437 set from storage commerce:l tc
scoreboard players set #i c.t 438
function commerce:page/ligne
data modify storage commerce:cp ve438 set from storage commerce:l ve
data modify storage commerce:cp vz438 set from storage commerce:l vz
data modify storage commerce:cp vc438 set from storage commerce:l vc
data modify storage commerce:cp ae438 set from storage commerce:l ae
data modify storage commerce:cp az438 set from storage commerce:l az
data modify storage commerce:cp ac438 set from storage commerce:l ac
data modify storage commerce:cp t438 set from storage commerce:l t
data modify storage commerce:cp tc438 set from storage commerce:l tc
scoreboard players set #i c.t 439
function commerce:page/ligne
data modify storage commerce:cp ve439 set from storage commerce:l ve
data modify storage commerce:cp vz439 set from storage commerce:l vz
data modify storage commerce:cp vc439 set from storage commerce:l vc
data modify storage commerce:cp ae439 set from storage commerce:l ae
data modify storage commerce:cp az439 set from storage commerce:l az
data modify storage commerce:cp ac439 set from storage commerce:l ac
data modify storage commerce:cp t439 set from storage commerce:l t
data modify storage commerce:cp tc439 set from storage commerce:l tc
scoreboard players set #i c.t 440
function commerce:page/ligne
data modify storage commerce:cp ve440 set from storage commerce:l ve
data modify storage commerce:cp vz440 set from storage commerce:l vz
data modify storage commerce:cp vc440 set from storage commerce:l vc
data modify storage commerce:cp ae440 set from storage commerce:l ae
data modify storage commerce:cp az440 set from storage commerce:l az
data modify storage commerce:cp ac440 set from storage commerce:l ac
data modify storage commerce:cp t440 set from storage commerce:l t
data modify storage commerce:cp tc440 set from storage commerce:l tc
scoreboard players set #i c.t 441
function commerce:page/ligne
data modify storage commerce:cp ve441 set from storage commerce:l ve
data modify storage commerce:cp vz441 set from storage commerce:l vz
data modify storage commerce:cp vc441 set from storage commerce:l vc
data modify storage commerce:cp ae441 set from storage commerce:l ae
data modify storage commerce:cp az441 set from storage commerce:l az
data modify storage commerce:cp ac441 set from storage commerce:l ac
data modify storage commerce:cp t441 set from storage commerce:l t
data modify storage commerce:cp tc441 set from storage commerce:l tc
scoreboard players set #i c.t 442
function commerce:page/ligne
data modify storage commerce:cp ve442 set from storage commerce:l ve
data modify storage commerce:cp vz442 set from storage commerce:l vz
data modify storage commerce:cp vc442 set from storage commerce:l vc
data modify storage commerce:cp ae442 set from storage commerce:l ae
data modify storage commerce:cp az442 set from storage commerce:l az
data modify storage commerce:cp ac442 set from storage commerce:l ac
data modify storage commerce:cp t442 set from storage commerce:l t
data modify storage commerce:cp tc442 set from storage commerce:l tc
scoreboard players set #i c.t 443
function commerce:page/ligne
data modify storage commerce:cp ve443 set from storage commerce:l ve
data modify storage commerce:cp vz443 set from storage commerce:l vz
data modify storage commerce:cp vc443 set from storage commerce:l vc
data modify storage commerce:cp ae443 set from storage commerce:l ae
data modify storage commerce:cp az443 set from storage commerce:l az
data modify storage commerce:cp ac443 set from storage commerce:l ac
data modify storage commerce:cp t443 set from storage commerce:l t
data modify storage commerce:cp tc443 set from storage commerce:l tc
scoreboard players set #i c.t 444
function commerce:page/ligne
data modify storage commerce:cp ve444 set from storage commerce:l ve
data modify storage commerce:cp vz444 set from storage commerce:l vz
data modify storage commerce:cp vc444 set from storage commerce:l vc
data modify storage commerce:cp ae444 set from storage commerce:l ae
data modify storage commerce:cp az444 set from storage commerce:l az
data modify storage commerce:cp ac444 set from storage commerce:l ac
data modify storage commerce:cp t444 set from storage commerce:l t
data modify storage commerce:cp tc444 set from storage commerce:l tc
scoreboard players set #i c.t 445
function commerce:page/ligne
data modify storage commerce:cp ve445 set from storage commerce:l ve
data modify storage commerce:cp vz445 set from storage commerce:l vz
data modify storage commerce:cp vc445 set from storage commerce:l vc
data modify storage commerce:cp ae445 set from storage commerce:l ae
data modify storage commerce:cp az445 set from storage commerce:l az
data modify storage commerce:cp ac445 set from storage commerce:l ac
data modify storage commerce:cp t445 set from storage commerce:l t
data modify storage commerce:cp tc445 set from storage commerce:l tc
scoreboard players set #i c.t 446
function commerce:page/ligne
data modify storage commerce:cp ve446 set from storage commerce:l ve
data modify storage commerce:cp vz446 set from storage commerce:l vz
data modify storage commerce:cp vc446 set from storage commerce:l vc
data modify storage commerce:cp ae446 set from storage commerce:l ae
data modify storage commerce:cp az446 set from storage commerce:l az
data modify storage commerce:cp ac446 set from storage commerce:l ac
data modify storage commerce:cp t446 set from storage commerce:l t
data modify storage commerce:cp tc446 set from storage commerce:l tc
scoreboard players set #i c.t 447
function commerce:page/ligne
data modify storage commerce:cp ve447 set from storage commerce:l ve
data modify storage commerce:cp vz447 set from storage commerce:l vz
data modify storage commerce:cp vc447 set from storage commerce:l vc
data modify storage commerce:cp ae447 set from storage commerce:l ae
data modify storage commerce:cp az447 set from storage commerce:l az
data modify storage commerce:cp ac447 set from storage commerce:l ac
data modify storage commerce:cp t447 set from storage commerce:l t
data modify storage commerce:cp tc447 set from storage commerce:l tc
scoreboard players set #i c.t 448
function commerce:page/ligne
data modify storage commerce:cp ve448 set from storage commerce:l ve
data modify storage commerce:cp vz448 set from storage commerce:l vz
data modify storage commerce:cp vc448 set from storage commerce:l vc
data modify storage commerce:cp ae448 set from storage commerce:l ae
data modify storage commerce:cp az448 set from storage commerce:l az
data modify storage commerce:cp ac448 set from storage commerce:l ac
data modify storage commerce:cp t448 set from storage commerce:l t
data modify storage commerce:cp tc448 set from storage commerce:l tc
scoreboard players set #i c.t 449
function commerce:page/ligne
data modify storage commerce:cp ve449 set from storage commerce:l ve
data modify storage commerce:cp vz449 set from storage commerce:l vz
data modify storage commerce:cp vc449 set from storage commerce:l vc
data modify storage commerce:cp ae449 set from storage commerce:l ae
data modify storage commerce:cp az449 set from storage commerce:l az
data modify storage commerce:cp ac449 set from storage commerce:l ac
data modify storage commerce:cp t449 set from storage commerce:l t
data modify storage commerce:cp tc449 set from storage commerce:l tc
scoreboard players set #i c.t 450
function commerce:page/ligne
data modify storage commerce:cp ve450 set from storage commerce:l ve
data modify storage commerce:cp vz450 set from storage commerce:l vz
data modify storage commerce:cp vc450 set from storage commerce:l vc
data modify storage commerce:cp ae450 set from storage commerce:l ae
data modify storage commerce:cp az450 set from storage commerce:l az
data modify storage commerce:cp ac450 set from storage commerce:l ac
data modify storage commerce:cp t450 set from storage commerce:l t
data modify storage commerce:cp tc450 set from storage commerce:l tc
scoreboard players set #i c.t 451
function commerce:page/ligne
data modify storage commerce:cp ve451 set from storage commerce:l ve
data modify storage commerce:cp vz451 set from storage commerce:l vz
data modify storage commerce:cp vc451 set from storage commerce:l vc
data modify storage commerce:cp ae451 set from storage commerce:l ae
data modify storage commerce:cp az451 set from storage commerce:l az
data modify storage commerce:cp ac451 set from storage commerce:l ac
data modify storage commerce:cp t451 set from storage commerce:l t
data modify storage commerce:cp tc451 set from storage commerce:l tc
scoreboard players set #i c.t 452
function commerce:page/ligne
data modify storage commerce:cp ve452 set from storage commerce:l ve
data modify storage commerce:cp vz452 set from storage commerce:l vz
data modify storage commerce:cp vc452 set from storage commerce:l vc
data modify storage commerce:cp ae452 set from storage commerce:l ae
data modify storage commerce:cp az452 set from storage commerce:l az
data modify storage commerce:cp ac452 set from storage commerce:l ac
data modify storage commerce:cp t452 set from storage commerce:l t
data modify storage commerce:cp tc452 set from storage commerce:l tc
scoreboard players set #i c.t 453
function commerce:page/ligne
data modify storage commerce:cp ve453 set from storage commerce:l ve
data modify storage commerce:cp vz453 set from storage commerce:l vz
data modify storage commerce:cp vc453 set from storage commerce:l vc
data modify storage commerce:cp ae453 set from storage commerce:l ae
data modify storage commerce:cp az453 set from storage commerce:l az
data modify storage commerce:cp ac453 set from storage commerce:l ac
data modify storage commerce:cp t453 set from storage commerce:l t
data modify storage commerce:cp tc453 set from storage commerce:l tc
scoreboard players set #i c.t 454
function commerce:page/ligne
data modify storage commerce:cp ve454 set from storage commerce:l ve
data modify storage commerce:cp vz454 set from storage commerce:l vz
data modify storage commerce:cp vc454 set from storage commerce:l vc
data modify storage commerce:cp ae454 set from storage commerce:l ae
data modify storage commerce:cp az454 set from storage commerce:l az
data modify storage commerce:cp ac454 set from storage commerce:l ac
data modify storage commerce:cp t454 set from storage commerce:l t
data modify storage commerce:cp tc454 set from storage commerce:l tc
scoreboard players set #i c.t 455
function commerce:page/ligne
data modify storage commerce:cp ve455 set from storage commerce:l ve
data modify storage commerce:cp vz455 set from storage commerce:l vz
data modify storage commerce:cp vc455 set from storage commerce:l vc
data modify storage commerce:cp ae455 set from storage commerce:l ae
data modify storage commerce:cp az455 set from storage commerce:l az
data modify storage commerce:cp ac455 set from storage commerce:l ac
data modify storage commerce:cp t455 set from storage commerce:l t
data modify storage commerce:cp tc455 set from storage commerce:l tc
scoreboard players set #i c.t 456
function commerce:page/ligne
data modify storage commerce:cp ve456 set from storage commerce:l ve
data modify storage commerce:cp vz456 set from storage commerce:l vz
data modify storage commerce:cp vc456 set from storage commerce:l vc
data modify storage commerce:cp ae456 set from storage commerce:l ae
data modify storage commerce:cp az456 set from storage commerce:l az
data modify storage commerce:cp ac456 set from storage commerce:l ac
data modify storage commerce:cp t456 set from storage commerce:l t
data modify storage commerce:cp tc456 set from storage commerce:l tc
scoreboard players set #i c.t 457
function commerce:page/ligne
data modify storage commerce:cp ve457 set from storage commerce:l ve
data modify storage commerce:cp vz457 set from storage commerce:l vz
data modify storage commerce:cp vc457 set from storage commerce:l vc
data modify storage commerce:cp ae457 set from storage commerce:l ae
data modify storage commerce:cp az457 set from storage commerce:l az
data modify storage commerce:cp ac457 set from storage commerce:l ac
data modify storage commerce:cp t457 set from storage commerce:l t
data modify storage commerce:cp tc457 set from storage commerce:l tc
scoreboard players set #i c.t 458
function commerce:page/ligne
data modify storage commerce:cp ve458 set from storage commerce:l ve
data modify storage commerce:cp vz458 set from storage commerce:l vz
data modify storage commerce:cp vc458 set from storage commerce:l vc
data modify storage commerce:cp ae458 set from storage commerce:l ae
data modify storage commerce:cp az458 set from storage commerce:l az
data modify storage commerce:cp ac458 set from storage commerce:l ac
data modify storage commerce:cp t458 set from storage commerce:l t
data modify storage commerce:cp tc458 set from storage commerce:l tc
scoreboard players set #i c.t 459
function commerce:page/ligne
data modify storage commerce:cp ve459 set from storage commerce:l ve
data modify storage commerce:cp vz459 set from storage commerce:l vz
data modify storage commerce:cp vc459 set from storage commerce:l vc
data modify storage commerce:cp ae459 set from storage commerce:l ae
data modify storage commerce:cp az459 set from storage commerce:l az
data modify storage commerce:cp ac459 set from storage commerce:l ac
data modify storage commerce:cp t459 set from storage commerce:l t
data modify storage commerce:cp tc459 set from storage commerce:l tc
function commerce:page/cat_15_d with storage commerce:cp
