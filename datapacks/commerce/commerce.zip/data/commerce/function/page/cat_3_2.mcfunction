function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 84
function commerce:page/ligne
data modify storage commerce:cp ve84 set from storage commerce:l ve
data modify storage commerce:cp vz84 set from storage commerce:l vz
data modify storage commerce:cp vc84 set from storage commerce:l vc
data modify storage commerce:cp ae84 set from storage commerce:l ae
data modify storage commerce:cp az84 set from storage commerce:l az
data modify storage commerce:cp ac84 set from storage commerce:l ac
data modify storage commerce:cp t84 set from storage commerce:l t
scoreboard players set #i c.t 85
function commerce:page/ligne
data modify storage commerce:cp ve85 set from storage commerce:l ve
data modify storage commerce:cp vz85 set from storage commerce:l vz
data modify storage commerce:cp vc85 set from storage commerce:l vc
data modify storage commerce:cp ae85 set from storage commerce:l ae
data modify storage commerce:cp az85 set from storage commerce:l az
data modify storage commerce:cp ac85 set from storage commerce:l ac
data modify storage commerce:cp t85 set from storage commerce:l t
scoreboard players set #i c.t 86
function commerce:page/ligne
data modify storage commerce:cp ve86 set from storage commerce:l ve
data modify storage commerce:cp vz86 set from storage commerce:l vz
data modify storage commerce:cp vc86 set from storage commerce:l vc
data modify storage commerce:cp ae86 set from storage commerce:l ae
data modify storage commerce:cp az86 set from storage commerce:l az
data modify storage commerce:cp ac86 set from storage commerce:l ac
data modify storage commerce:cp t86 set from storage commerce:l t
scoreboard players set #i c.t 87
function commerce:page/ligne
data modify storage commerce:cp ve87 set from storage commerce:l ve
data modify storage commerce:cp vz87 set from storage commerce:l vz
data modify storage commerce:cp vc87 set from storage commerce:l vc
data modify storage commerce:cp ae87 set from storage commerce:l ae
data modify storage commerce:cp az87 set from storage commerce:l az
data modify storage commerce:cp ac87 set from storage commerce:l ac
data modify storage commerce:cp t87 set from storage commerce:l t
function commerce:page/cat_3_2_d with storage commerce:cp
