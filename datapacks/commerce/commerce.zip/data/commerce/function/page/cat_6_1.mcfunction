function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 164
function commerce:page/ligne
data modify storage commerce:cp ve164 set from storage commerce:l ve
data modify storage commerce:cp vz164 set from storage commerce:l vz
data modify storage commerce:cp vc164 set from storage commerce:l vc
data modify storage commerce:cp ae164 set from storage commerce:l ae
data modify storage commerce:cp az164 set from storage commerce:l az
data modify storage commerce:cp ac164 set from storage commerce:l ac
data modify storage commerce:cp t164 set from storage commerce:l t
scoreboard players set #i c.t 165
function commerce:page/ligne
data modify storage commerce:cp ve165 set from storage commerce:l ve
data modify storage commerce:cp vz165 set from storage commerce:l vz
data modify storage commerce:cp vc165 set from storage commerce:l vc
data modify storage commerce:cp ae165 set from storage commerce:l ae
data modify storage commerce:cp az165 set from storage commerce:l az
data modify storage commerce:cp ac165 set from storage commerce:l ac
data modify storage commerce:cp t165 set from storage commerce:l t
scoreboard players set #i c.t 166
function commerce:page/ligne
data modify storage commerce:cp ve166 set from storage commerce:l ve
data modify storage commerce:cp vz166 set from storage commerce:l vz
data modify storage commerce:cp vc166 set from storage commerce:l vc
data modify storage commerce:cp ae166 set from storage commerce:l ae
data modify storage commerce:cp az166 set from storage commerce:l az
data modify storage commerce:cp ac166 set from storage commerce:l ac
data modify storage commerce:cp t166 set from storage commerce:l t
scoreboard players set #i c.t 167
function commerce:page/ligne
data modify storage commerce:cp ve167 set from storage commerce:l ve
data modify storage commerce:cp vz167 set from storage commerce:l vz
data modify storage commerce:cp vc167 set from storage commerce:l vc
data modify storage commerce:cp ae167 set from storage commerce:l ae
data modify storage commerce:cp az167 set from storage commerce:l az
data modify storage commerce:cp ac167 set from storage commerce:l ac
data modify storage commerce:cp t167 set from storage commerce:l t
scoreboard players set #i c.t 168
function commerce:page/ligne
data modify storage commerce:cp ve168 set from storage commerce:l ve
data modify storage commerce:cp vz168 set from storage commerce:l vz
data modify storage commerce:cp vc168 set from storage commerce:l vc
data modify storage commerce:cp ae168 set from storage commerce:l ae
data modify storage commerce:cp az168 set from storage commerce:l az
data modify storage commerce:cp ac168 set from storage commerce:l ac
data modify storage commerce:cp t168 set from storage commerce:l t
scoreboard players set #i c.t 169
function commerce:page/ligne
data modify storage commerce:cp ve169 set from storage commerce:l ve
data modify storage commerce:cp vz169 set from storage commerce:l vz
data modify storage commerce:cp vc169 set from storage commerce:l vc
data modify storage commerce:cp ae169 set from storage commerce:l ae
data modify storage commerce:cp az169 set from storage commerce:l az
data modify storage commerce:cp ac169 set from storage commerce:l ac
data modify storage commerce:cp t169 set from storage commerce:l t
scoreboard players set #i c.t 170
function commerce:page/ligne
data modify storage commerce:cp ve170 set from storage commerce:l ve
data modify storage commerce:cp vz170 set from storage commerce:l vz
data modify storage commerce:cp vc170 set from storage commerce:l vc
data modify storage commerce:cp ae170 set from storage commerce:l ae
data modify storage commerce:cp az170 set from storage commerce:l az
data modify storage commerce:cp ac170 set from storage commerce:l ac
data modify storage commerce:cp t170 set from storage commerce:l t
scoreboard players set #i c.t 171
function commerce:page/ligne
data modify storage commerce:cp ve171 set from storage commerce:l ve
data modify storage commerce:cp vz171 set from storage commerce:l vz
data modify storage commerce:cp vc171 set from storage commerce:l vc
data modify storage commerce:cp ae171 set from storage commerce:l ae
data modify storage commerce:cp az171 set from storage commerce:l az
data modify storage commerce:cp ac171 set from storage commerce:l ac
data modify storage commerce:cp t171 set from storage commerce:l t
scoreboard players set #i c.t 172
function commerce:page/ligne
data modify storage commerce:cp ve172 set from storage commerce:l ve
data modify storage commerce:cp vz172 set from storage commerce:l vz
data modify storage commerce:cp vc172 set from storage commerce:l vc
data modify storage commerce:cp ae172 set from storage commerce:l ae
data modify storage commerce:cp az172 set from storage commerce:l az
data modify storage commerce:cp ac172 set from storage commerce:l ac
data modify storage commerce:cp t172 set from storage commerce:l t
scoreboard players set #i c.t 173
function commerce:page/ligne
data modify storage commerce:cp ve173 set from storage commerce:l ve
data modify storage commerce:cp vz173 set from storage commerce:l vz
data modify storage commerce:cp vc173 set from storage commerce:l vc
data modify storage commerce:cp ae173 set from storage commerce:l ae
data modify storage commerce:cp az173 set from storage commerce:l az
data modify storage commerce:cp ac173 set from storage commerce:l ac
data modify storage commerce:cp t173 set from storage commerce:l t
function commerce:page/cat_6_1_d with storage commerce:cp
