function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 378
function commerce:page/ligne
data modify storage commerce:cp ve378 set from storage commerce:l ve
data modify storage commerce:cp vz378 set from storage commerce:l vz
data modify storage commerce:cp vc378 set from storage commerce:l vc
data modify storage commerce:cp ae378 set from storage commerce:l ae
data modify storage commerce:cp az378 set from storage commerce:l az
data modify storage commerce:cp ac378 set from storage commerce:l ac
data modify storage commerce:cp t378 set from storage commerce:l t
function commerce:page/lettre_w_0_d with storage commerce:cp
