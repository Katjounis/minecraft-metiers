function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 417
function commerce:page/ligne
data modify storage commerce:cp ve417 set from storage commerce:l ve
data modify storage commerce:cp vz417 set from storage commerce:l vz
data modify storage commerce:cp vc417 set from storage commerce:l vc
data modify storage commerce:cp ae417 set from storage commerce:l ae
data modify storage commerce:cp az417 set from storage commerce:l az
data modify storage commerce:cp ac417 set from storage commerce:l ac
data modify storage commerce:cp t417 set from storage commerce:l t
scoreboard players set #i c.t 273
function commerce:page/ligne
data modify storage commerce:cp ve273 set from storage commerce:l ve
data modify storage commerce:cp vz273 set from storage commerce:l vz
data modify storage commerce:cp vc273 set from storage commerce:l vc
data modify storage commerce:cp ae273 set from storage commerce:l ae
data modify storage commerce:cp az273 set from storage commerce:l az
data modify storage commerce:cp ac273 set from storage commerce:l ac
data modify storage commerce:cp t273 set from storage commerce:l t
scoreboard players set #i c.t 264
function commerce:page/ligne
data modify storage commerce:cp ve264 set from storage commerce:l ve
data modify storage commerce:cp vz264 set from storage commerce:l vz
data modify storage commerce:cp vc264 set from storage commerce:l vc
data modify storage commerce:cp ae264 set from storage commerce:l ae
data modify storage commerce:cp az264 set from storage commerce:l az
data modify storage commerce:cp ac264 set from storage commerce:l ac
data modify storage commerce:cp t264 set from storage commerce:l t
scoreboard players set #i c.t 1
function commerce:page/ligne
data modify storage commerce:cp ve1 set from storage commerce:l ve
data modify storage commerce:cp vz1 set from storage commerce:l vz
data modify storage commerce:cp vc1 set from storage commerce:l vc
data modify storage commerce:cp ae1 set from storage commerce:l ae
data modify storage commerce:cp az1 set from storage commerce:l az
data modify storage commerce:cp ac1 set from storage commerce:l ac
data modify storage commerce:cp t1 set from storage commerce:l t
scoreboard players set #i c.t 2
function commerce:page/ligne
data modify storage commerce:cp ve2 set from storage commerce:l ve
data modify storage commerce:cp vz2 set from storage commerce:l vz
data modify storage commerce:cp vc2 set from storage commerce:l vc
data modify storage commerce:cp ae2 set from storage commerce:l ae
data modify storage commerce:cp az2 set from storage commerce:l az
data modify storage commerce:cp ac2 set from storage commerce:l ac
data modify storage commerce:cp t2 set from storage commerce:l t
scoreboard players set #i c.t 278
function commerce:page/ligne
data modify storage commerce:cp ve278 set from storage commerce:l ve
data modify storage commerce:cp vz278 set from storage commerce:l vz
data modify storage commerce:cp vc278 set from storage commerce:l vc
data modify storage commerce:cp ae278 set from storage commerce:l ae
data modify storage commerce:cp az278 set from storage commerce:l az
data modify storage commerce:cp ac278 set from storage commerce:l ac
data modify storage commerce:cp t278 set from storage commerce:l t
scoreboard players set #i c.t 271
function commerce:page/ligne
data modify storage commerce:cp ve271 set from storage commerce:l ve
data modify storage commerce:cp vz271 set from storage commerce:l vz
data modify storage commerce:cp vc271 set from storage commerce:l vc
data modify storage commerce:cp ae271 set from storage commerce:l ae
data modify storage commerce:cp az271 set from storage commerce:l az
data modify storage commerce:cp ac271 set from storage commerce:l ac
data modify storage commerce:cp t271 set from storage commerce:l t
scoreboard players set #i c.t 466
function commerce:page/ligne
data modify storage commerce:cp ve466 set from storage commerce:l ve
data modify storage commerce:cp vz466 set from storage commerce:l vz
data modify storage commerce:cp vc466 set from storage commerce:l vc
data modify storage commerce:cp ae466 set from storage commerce:l ae
data modify storage commerce:cp az466 set from storage commerce:l az
data modify storage commerce:cp ac466 set from storage commerce:l ac
data modify storage commerce:cp t466 set from storage commerce:l t
scoreboard players set #i c.t 402
function commerce:page/ligne
data modify storage commerce:cp ve402 set from storage commerce:l ve
data modify storage commerce:cp vz402 set from storage commerce:l vz
data modify storage commerce:cp vc402 set from storage commerce:l vc
data modify storage commerce:cp ae402 set from storage commerce:l ae
data modify storage commerce:cp az402 set from storage commerce:l az
data modify storage commerce:cp ac402 set from storage commerce:l ac
data modify storage commerce:cp t402 set from storage commerce:l t
scoreboard players set #i c.t 379
function commerce:page/ligne
data modify storage commerce:cp ve379 set from storage commerce:l ve
data modify storage commerce:cp vz379 set from storage commerce:l vz
data modify storage commerce:cp vc379 set from storage commerce:l vc
data modify storage commerce:cp ae379 set from storage commerce:l ae
data modify storage commerce:cp az379 set from storage commerce:l az
data modify storage commerce:cp ac379 set from storage commerce:l ac
data modify storage commerce:cp t379 set from storage commerce:l t
function commerce:page/lettre_p_1_d with storage commerce:cp
