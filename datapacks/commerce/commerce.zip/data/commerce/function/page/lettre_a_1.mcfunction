function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 16
function commerce:page/ligne
data modify storage commerce:cp ve16 set from storage commerce:l ve
data modify storage commerce:cp vz16 set from storage commerce:l vz
data modify storage commerce:cp vc16 set from storage commerce:l vc
data modify storage commerce:cp ae16 set from storage commerce:l ae
data modify storage commerce:cp az16 set from storage commerce:l az
data modify storage commerce:cp ac16 set from storage commerce:l ac
data modify storage commerce:cp t16 set from storage commerce:l t
scoreboard players set #i c.t 55
function commerce:page/ligne
data modify storage commerce:cp ve55 set from storage commerce:l ve
data modify storage commerce:cp vz55 set from storage commerce:l vz
data modify storage commerce:cp vc55 set from storage commerce:l vc
data modify storage commerce:cp ae55 set from storage commerce:l ae
data modify storage commerce:cp az55 set from storage commerce:l az
data modify storage commerce:cp ac55 set from storage commerce:l ac
data modify storage commerce:cp t55 set from storage commerce:l t
scoreboard players set #i c.t 429
function commerce:page/ligne
data modify storage commerce:cp ve429 set from storage commerce:l ve
data modify storage commerce:cp vz429 set from storage commerce:l vz
data modify storage commerce:cp vc429 set from storage commerce:l vc
data modify storage commerce:cp ae429 set from storage commerce:l ae
data modify storage commerce:cp az429 set from storage commerce:l az
data modify storage commerce:cp ac429 set from storage commerce:l ac
data modify storage commerce:cp t429 set from storage commerce:l t
function commerce:page/lettre_a_1_d with storage commerce:cp
