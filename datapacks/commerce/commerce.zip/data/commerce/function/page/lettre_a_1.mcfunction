function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 427
function commerce:page/ligne
data modify storage commerce:cp ve427 set from storage commerce:l ve
data modify storage commerce:cp vz427 set from storage commerce:l vz
data modify storage commerce:cp vc427 set from storage commerce:l vc
data modify storage commerce:cp ae427 set from storage commerce:l ae
data modify storage commerce:cp az427 set from storage commerce:l az
data modify storage commerce:cp ac427 set from storage commerce:l ac
data modify storage commerce:cp t427 set from storage commerce:l t
function commerce:page/lettre_a_1_d with storage commerce:cp
