function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 217
function commerce:page/ligne
data modify storage commerce:cp ve217 set from storage commerce:l ve
data modify storage commerce:cp vz217 set from storage commerce:l vz
data modify storage commerce:cp vc217 set from storage commerce:l vc
data modify storage commerce:cp ae217 set from storage commerce:l ae
data modify storage commerce:cp az217 set from storage commerce:l az
data modify storage commerce:cp ac217 set from storage commerce:l ac
data modify storage commerce:cp t217 set from storage commerce:l t
scoreboard players set #i c.t 218
function commerce:page/ligne
data modify storage commerce:cp ve218 set from storage commerce:l ve
data modify storage commerce:cp vz218 set from storage commerce:l vz
data modify storage commerce:cp vc218 set from storage commerce:l vc
data modify storage commerce:cp ae218 set from storage commerce:l ae
data modify storage commerce:cp az218 set from storage commerce:l az
data modify storage commerce:cp ac218 set from storage commerce:l ac
data modify storage commerce:cp t218 set from storage commerce:l t
scoreboard players set #i c.t 219
function commerce:page/ligne
data modify storage commerce:cp ve219 set from storage commerce:l ve
data modify storage commerce:cp vz219 set from storage commerce:l vz
data modify storage commerce:cp vc219 set from storage commerce:l vc
data modify storage commerce:cp ae219 set from storage commerce:l ae
data modify storage commerce:cp az219 set from storage commerce:l az
data modify storage commerce:cp ac219 set from storage commerce:l ac
data modify storage commerce:cp t219 set from storage commerce:l t
scoreboard players set #i c.t 220
function commerce:page/ligne
data modify storage commerce:cp ve220 set from storage commerce:l ve
data modify storage commerce:cp vz220 set from storage commerce:l vz
data modify storage commerce:cp vc220 set from storage commerce:l vc
data modify storage commerce:cp ae220 set from storage commerce:l ae
data modify storage commerce:cp az220 set from storage commerce:l az
data modify storage commerce:cp ac220 set from storage commerce:l ac
data modify storage commerce:cp t220 set from storage commerce:l t
function commerce:page/cat_7_3_d with storage commerce:cp
