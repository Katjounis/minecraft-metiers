function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 21
function commerce:page/ligne
data modify storage commerce:cp ve21 set from storage commerce:l ve
data modify storage commerce:cp vz21 set from storage commerce:l vz
data modify storage commerce:cp vc21 set from storage commerce:l vc
data modify storage commerce:cp ae21 set from storage commerce:l ae
data modify storage commerce:cp az21 set from storage commerce:l az
data modify storage commerce:cp ac21 set from storage commerce:l ac
data modify storage commerce:cp t21 set from storage commerce:l t
scoreboard players set #i c.t 22
function commerce:page/ligne
data modify storage commerce:cp ve22 set from storage commerce:l ve
data modify storage commerce:cp vz22 set from storage commerce:l vz
data modify storage commerce:cp vc22 set from storage commerce:l vc
data modify storage commerce:cp ae22 set from storage commerce:l ae
data modify storage commerce:cp az22 set from storage commerce:l az
data modify storage commerce:cp ac22 set from storage commerce:l ac
data modify storage commerce:cp t22 set from storage commerce:l t
scoreboard players set #i c.t 23
function commerce:page/ligne
data modify storage commerce:cp ve23 set from storage commerce:l ve
data modify storage commerce:cp vz23 set from storage commerce:l vz
data modify storage commerce:cp vc23 set from storage commerce:l vc
data modify storage commerce:cp ae23 set from storage commerce:l ae
data modify storage commerce:cp az23 set from storage commerce:l az
data modify storage commerce:cp ac23 set from storage commerce:l ac
data modify storage commerce:cp t23 set from storage commerce:l t
scoreboard players set #i c.t 24
function commerce:page/ligne
data modify storage commerce:cp ve24 set from storage commerce:l ve
data modify storage commerce:cp vz24 set from storage commerce:l vz
data modify storage commerce:cp vc24 set from storage commerce:l vc
data modify storage commerce:cp ae24 set from storage commerce:l ae
data modify storage commerce:cp az24 set from storage commerce:l az
data modify storage commerce:cp ac24 set from storage commerce:l ac
data modify storage commerce:cp t24 set from storage commerce:l t
scoreboard players set #i c.t 25
function commerce:page/ligne
data modify storage commerce:cp ve25 set from storage commerce:l ve
data modify storage commerce:cp vz25 set from storage commerce:l vz
data modify storage commerce:cp vc25 set from storage commerce:l vc
data modify storage commerce:cp ae25 set from storage commerce:l ae
data modify storage commerce:cp az25 set from storage commerce:l az
data modify storage commerce:cp ac25 set from storage commerce:l ac
data modify storage commerce:cp t25 set from storage commerce:l t
scoreboard players set #i c.t 26
function commerce:page/ligne
data modify storage commerce:cp ve26 set from storage commerce:l ve
data modify storage commerce:cp vz26 set from storage commerce:l vz
data modify storage commerce:cp vc26 set from storage commerce:l vc
data modify storage commerce:cp ae26 set from storage commerce:l ae
data modify storage commerce:cp az26 set from storage commerce:l az
data modify storage commerce:cp ac26 set from storage commerce:l ac
data modify storage commerce:cp t26 set from storage commerce:l t
scoreboard players set #i c.t 27
function commerce:page/ligne
data modify storage commerce:cp ve27 set from storage commerce:l ve
data modify storage commerce:cp vz27 set from storage commerce:l vz
data modify storage commerce:cp vc27 set from storage commerce:l vc
data modify storage commerce:cp ae27 set from storage commerce:l ae
data modify storage commerce:cp az27 set from storage commerce:l az
data modify storage commerce:cp ac27 set from storage commerce:l ac
data modify storage commerce:cp t27 set from storage commerce:l t
scoreboard players set #i c.t 28
function commerce:page/ligne
data modify storage commerce:cp ve28 set from storage commerce:l ve
data modify storage commerce:cp vz28 set from storage commerce:l vz
data modify storage commerce:cp vc28 set from storage commerce:l vc
data modify storage commerce:cp ae28 set from storage commerce:l ae
data modify storage commerce:cp az28 set from storage commerce:l az
data modify storage commerce:cp ac28 set from storage commerce:l ac
data modify storage commerce:cp t28 set from storage commerce:l t
scoreboard players set #i c.t 29
function commerce:page/ligne
data modify storage commerce:cp ve29 set from storage commerce:l ve
data modify storage commerce:cp vz29 set from storage commerce:l vz
data modify storage commerce:cp vc29 set from storage commerce:l vc
data modify storage commerce:cp ae29 set from storage commerce:l ae
data modify storage commerce:cp az29 set from storage commerce:l az
data modify storage commerce:cp ac29 set from storage commerce:l ac
data modify storage commerce:cp t29 set from storage commerce:l t
scoreboard players set #i c.t 30
function commerce:page/ligne
data modify storage commerce:cp ve30 set from storage commerce:l ve
data modify storage commerce:cp vz30 set from storage commerce:l vz
data modify storage commerce:cp vc30 set from storage commerce:l vc
data modify storage commerce:cp ae30 set from storage commerce:l ae
data modify storage commerce:cp az30 set from storage commerce:l az
data modify storage commerce:cp ac30 set from storage commerce:l ac
data modify storage commerce:cp t30 set from storage commerce:l t
function commerce:page/cat_1_2_d with storage commerce:cp
