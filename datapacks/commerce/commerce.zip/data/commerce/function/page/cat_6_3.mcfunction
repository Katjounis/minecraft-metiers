function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 184
function commerce:page/ligne
data modify storage commerce:cp ve184 set from storage commerce:l ve
data modify storage commerce:cp vz184 set from storage commerce:l vz
data modify storage commerce:cp vc184 set from storage commerce:l vc
data modify storage commerce:cp ae184 set from storage commerce:l ae
data modify storage commerce:cp az184 set from storage commerce:l az
data modify storage commerce:cp ac184 set from storage commerce:l ac
data modify storage commerce:cp t184 set from storage commerce:l t
scoreboard players set #i c.t 185
function commerce:page/ligne
data modify storage commerce:cp ve185 set from storage commerce:l ve
data modify storage commerce:cp vz185 set from storage commerce:l vz
data modify storage commerce:cp vc185 set from storage commerce:l vc
data modify storage commerce:cp ae185 set from storage commerce:l ae
data modify storage commerce:cp az185 set from storage commerce:l az
data modify storage commerce:cp ac185 set from storage commerce:l ac
data modify storage commerce:cp t185 set from storage commerce:l t
scoreboard players set #i c.t 186
function commerce:page/ligne
data modify storage commerce:cp ve186 set from storage commerce:l ve
data modify storage commerce:cp vz186 set from storage commerce:l vz
data modify storage commerce:cp vc186 set from storage commerce:l vc
data modify storage commerce:cp ae186 set from storage commerce:l ae
data modify storage commerce:cp az186 set from storage commerce:l az
data modify storage commerce:cp ac186 set from storage commerce:l ac
data modify storage commerce:cp t186 set from storage commerce:l t
function commerce:page/cat_6_3_d with storage commerce:cp
