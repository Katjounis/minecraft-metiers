function commerce:fmt/solde
data modify storage commerce:a se set from storage commerce:t s.e
data modify storage commerce:a sz set from storage commerce:t s.z
data modify storage commerce:a sc set from storage commerce:t s.c
execute store result storage commerce:a tv int 1 run scoreboard players get @s c.tv
execute store result storage commerce:a ta int 1 run scoreboard players get @s c.ta
data modify storage commerce:a cp set value "pas posé"
execute if score @s c.cmpt matches 1 run data modify storage commerce:a cp set value "posé"
data modify storage commerce:a ev set from storage commerce:g evtxt
data modify storage commerce:a msg set from storage commerce:t msg
data modify storage commerce:t msg set value ""
function commerce:page/accueil_d with storage commerce:a
