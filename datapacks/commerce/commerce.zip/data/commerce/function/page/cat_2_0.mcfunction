function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 45
function commerce:page/ligne
data modify storage commerce:cp ve45 set from storage commerce:l ve
data modify storage commerce:cp vz45 set from storage commerce:l vz
data modify storage commerce:cp vc45 set from storage commerce:l vc
data modify storage commerce:cp ae45 set from storage commerce:l ae
data modify storage commerce:cp az45 set from storage commerce:l az
data modify storage commerce:cp ac45 set from storage commerce:l ac
data modify storage commerce:cp t45 set from storage commerce:l t
scoreboard players set #i c.t 46
function commerce:page/ligne
data modify storage commerce:cp ve46 set from storage commerce:l ve
data modify storage commerce:cp vz46 set from storage commerce:l vz
data modify storage commerce:cp vc46 set from storage commerce:l vc
data modify storage commerce:cp ae46 set from storage commerce:l ae
data modify storage commerce:cp az46 set from storage commerce:l az
data modify storage commerce:cp ac46 set from storage commerce:l ac
data modify storage commerce:cp t46 set from storage commerce:l t
scoreboard players set #i c.t 47
function commerce:page/ligne
data modify storage commerce:cp ve47 set from storage commerce:l ve
data modify storage commerce:cp vz47 set from storage commerce:l vz
data modify storage commerce:cp vc47 set from storage commerce:l vc
data modify storage commerce:cp ae47 set from storage commerce:l ae
data modify storage commerce:cp az47 set from storage commerce:l az
data modify storage commerce:cp ac47 set from storage commerce:l ac
data modify storage commerce:cp t47 set from storage commerce:l t
scoreboard players set #i c.t 48
function commerce:page/ligne
data modify storage commerce:cp ve48 set from storage commerce:l ve
data modify storage commerce:cp vz48 set from storage commerce:l vz
data modify storage commerce:cp vc48 set from storage commerce:l vc
data modify storage commerce:cp ae48 set from storage commerce:l ae
data modify storage commerce:cp az48 set from storage commerce:l az
data modify storage commerce:cp ac48 set from storage commerce:l ac
data modify storage commerce:cp t48 set from storage commerce:l t
scoreboard players set #i c.t 49
function commerce:page/ligne
data modify storage commerce:cp ve49 set from storage commerce:l ve
data modify storage commerce:cp vz49 set from storage commerce:l vz
data modify storage commerce:cp vc49 set from storage commerce:l vc
data modify storage commerce:cp ae49 set from storage commerce:l ae
data modify storage commerce:cp az49 set from storage commerce:l az
data modify storage commerce:cp ac49 set from storage commerce:l ac
data modify storage commerce:cp t49 set from storage commerce:l t
scoreboard players set #i c.t 50
function commerce:page/ligne
data modify storage commerce:cp ve50 set from storage commerce:l ve
data modify storage commerce:cp vz50 set from storage commerce:l vz
data modify storage commerce:cp vc50 set from storage commerce:l vc
data modify storage commerce:cp ae50 set from storage commerce:l ae
data modify storage commerce:cp az50 set from storage commerce:l az
data modify storage commerce:cp ac50 set from storage commerce:l ac
data modify storage commerce:cp t50 set from storage commerce:l t
scoreboard players set #i c.t 51
function commerce:page/ligne
data modify storage commerce:cp ve51 set from storage commerce:l ve
data modify storage commerce:cp vz51 set from storage commerce:l vz
data modify storage commerce:cp vc51 set from storage commerce:l vc
data modify storage commerce:cp ae51 set from storage commerce:l ae
data modify storage commerce:cp az51 set from storage commerce:l az
data modify storage commerce:cp ac51 set from storage commerce:l ac
data modify storage commerce:cp t51 set from storage commerce:l t
scoreboard players set #i c.t 52
function commerce:page/ligne
data modify storage commerce:cp ve52 set from storage commerce:l ve
data modify storage commerce:cp vz52 set from storage commerce:l vz
data modify storage commerce:cp vc52 set from storage commerce:l vc
data modify storage commerce:cp ae52 set from storage commerce:l ae
data modify storage commerce:cp az52 set from storage commerce:l az
data modify storage commerce:cp ac52 set from storage commerce:l ac
data modify storage commerce:cp t52 set from storage commerce:l t
scoreboard players set #i c.t 53
function commerce:page/ligne
data modify storage commerce:cp ve53 set from storage commerce:l ve
data modify storage commerce:cp vz53 set from storage commerce:l vz
data modify storage commerce:cp vc53 set from storage commerce:l vc
data modify storage commerce:cp ae53 set from storage commerce:l ae
data modify storage commerce:cp az53 set from storage commerce:l az
data modify storage commerce:cp ac53 set from storage commerce:l ac
data modify storage commerce:cp t53 set from storage commerce:l t
scoreboard players set #i c.t 54
function commerce:page/ligne
data modify storage commerce:cp ve54 set from storage commerce:l ve
data modify storage commerce:cp vz54 set from storage commerce:l vz
data modify storage commerce:cp vc54 set from storage commerce:l vc
data modify storage commerce:cp ae54 set from storage commerce:l ae
data modify storage commerce:cp az54 set from storage commerce:l az
data modify storage commerce:cp ac54 set from storage commerce:l ac
data modify storage commerce:cp t54 set from storage commerce:l t
function commerce:page/cat_2_0_d with storage commerce:cp
