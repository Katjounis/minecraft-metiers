function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 54
function commerce:page/ligne
data modify storage commerce:cp ve54 set from storage commerce:l ve
data modify storage commerce:cp vz54 set from storage commerce:l vz
data modify storage commerce:cp vc54 set from storage commerce:l vc
data modify storage commerce:cp ae54 set from storage commerce:l ae
data modify storage commerce:cp az54 set from storage commerce:l az
data modify storage commerce:cp ac54 set from storage commerce:l ac
data modify storage commerce:cp t54 set from storage commerce:l t
scoreboard players set #i c.t 27
function commerce:page/ligne
data modify storage commerce:cp ve27 set from storage commerce:l ve
data modify storage commerce:cp vz27 set from storage commerce:l vz
data modify storage commerce:cp vc27 set from storage commerce:l vc
data modify storage commerce:cp ae27 set from storage commerce:l ae
data modify storage commerce:cp az27 set from storage commerce:l az
data modify storage commerce:cp ac27 set from storage commerce:l ac
data modify storage commerce:cp t27 set from storage commerce:l t
scoreboard players set #i c.t 28
function commerce:page/ligne
data modify storage commerce:cp ve28 set from storage commerce:l ve
data modify storage commerce:cp vz28 set from storage commerce:l vz
data modify storage commerce:cp vc28 set from storage commerce:l vc
data modify storage commerce:cp ae28 set from storage commerce:l ae
data modify storage commerce:cp az28 set from storage commerce:l az
data modify storage commerce:cp ac28 set from storage commerce:l ac
data modify storage commerce:cp t28 set from storage commerce:l t
scoreboard players set #i c.t 31
function commerce:page/ligne
data modify storage commerce:cp ve31 set from storage commerce:l ve
data modify storage commerce:cp vz31 set from storage commerce:l vz
data modify storage commerce:cp vc31 set from storage commerce:l vc
data modify storage commerce:cp ae31 set from storage commerce:l ae
data modify storage commerce:cp az31 set from storage commerce:l az
data modify storage commerce:cp ac31 set from storage commerce:l ac
data modify storage commerce:cp t31 set from storage commerce:l t
scoreboard players set #i c.t 32
function commerce:page/ligne
data modify storage commerce:cp ve32 set from storage commerce:l ve
data modify storage commerce:cp vz32 set from storage commerce:l vz
data modify storage commerce:cp vc32 set from storage commerce:l vc
data modify storage commerce:cp ae32 set from storage commerce:l ae
data modify storage commerce:cp az32 set from storage commerce:l az
data modify storage commerce:cp ac32 set from storage commerce:l ac
data modify storage commerce:cp t32 set from storage commerce:l t
scoreboard players set #i c.t 33
function commerce:page/ligne
data modify storage commerce:cp ve33 set from storage commerce:l ve
data modify storage commerce:cp vz33 set from storage commerce:l vz
data modify storage commerce:cp vc33 set from storage commerce:l vc
data modify storage commerce:cp ae33 set from storage commerce:l ae
data modify storage commerce:cp az33 set from storage commerce:l az
data modify storage commerce:cp ac33 set from storage commerce:l ac
data modify storage commerce:cp t33 set from storage commerce:l t
scoreboard players set #i c.t 30
function commerce:page/ligne
data modify storage commerce:cp ve30 set from storage commerce:l ve
data modify storage commerce:cp vz30 set from storage commerce:l vz
data modify storage commerce:cp vc30 set from storage commerce:l vc
data modify storage commerce:cp ae30 set from storage commerce:l ae
data modify storage commerce:cp az30 set from storage commerce:l az
data modify storage commerce:cp ac30 set from storage commerce:l ac
data modify storage commerce:cp t30 set from storage commerce:l t
scoreboard players set #i c.t 29
function commerce:page/ligne
data modify storage commerce:cp ve29 set from storage commerce:l ve
data modify storage commerce:cp vz29 set from storage commerce:l vz
data modify storage commerce:cp vc29 set from storage commerce:l vc
data modify storage commerce:cp ae29 set from storage commerce:l ae
data modify storage commerce:cp az29 set from storage commerce:l az
data modify storage commerce:cp ac29 set from storage commerce:l ac
data modify storage commerce:cp t29 set from storage commerce:l t
function commerce:page/lettre_g_1_d with storage commerce:cp
