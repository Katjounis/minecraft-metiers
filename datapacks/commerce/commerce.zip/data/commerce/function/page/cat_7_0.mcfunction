function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 187
function commerce:page/ligne
data modify storage commerce:cp ve187 set from storage commerce:l ve
data modify storage commerce:cp vz187 set from storage commerce:l vz
data modify storage commerce:cp vc187 set from storage commerce:l vc
data modify storage commerce:cp ae187 set from storage commerce:l ae
data modify storage commerce:cp az187 set from storage commerce:l az
data modify storage commerce:cp ac187 set from storage commerce:l ac
data modify storage commerce:cp t187 set from storage commerce:l t
scoreboard players set #i c.t 188
function commerce:page/ligne
data modify storage commerce:cp ve188 set from storage commerce:l ve
data modify storage commerce:cp vz188 set from storage commerce:l vz
data modify storage commerce:cp vc188 set from storage commerce:l vc
data modify storage commerce:cp ae188 set from storage commerce:l ae
data modify storage commerce:cp az188 set from storage commerce:l az
data modify storage commerce:cp ac188 set from storage commerce:l ac
data modify storage commerce:cp t188 set from storage commerce:l t
scoreboard players set #i c.t 189
function commerce:page/ligne
data modify storage commerce:cp ve189 set from storage commerce:l ve
data modify storage commerce:cp vz189 set from storage commerce:l vz
data modify storage commerce:cp vc189 set from storage commerce:l vc
data modify storage commerce:cp ae189 set from storage commerce:l ae
data modify storage commerce:cp az189 set from storage commerce:l az
data modify storage commerce:cp ac189 set from storage commerce:l ac
data modify storage commerce:cp t189 set from storage commerce:l t
scoreboard players set #i c.t 190
function commerce:page/ligne
data modify storage commerce:cp ve190 set from storage commerce:l ve
data modify storage commerce:cp vz190 set from storage commerce:l vz
data modify storage commerce:cp vc190 set from storage commerce:l vc
data modify storage commerce:cp ae190 set from storage commerce:l ae
data modify storage commerce:cp az190 set from storage commerce:l az
data modify storage commerce:cp ac190 set from storage commerce:l ac
data modify storage commerce:cp t190 set from storage commerce:l t
scoreboard players set #i c.t 191
function commerce:page/ligne
data modify storage commerce:cp ve191 set from storage commerce:l ve
data modify storage commerce:cp vz191 set from storage commerce:l vz
data modify storage commerce:cp vc191 set from storage commerce:l vc
data modify storage commerce:cp ae191 set from storage commerce:l ae
data modify storage commerce:cp az191 set from storage commerce:l az
data modify storage commerce:cp ac191 set from storage commerce:l ac
data modify storage commerce:cp t191 set from storage commerce:l t
scoreboard players set #i c.t 192
function commerce:page/ligne
data modify storage commerce:cp ve192 set from storage commerce:l ve
data modify storage commerce:cp vz192 set from storage commerce:l vz
data modify storage commerce:cp vc192 set from storage commerce:l vc
data modify storage commerce:cp ae192 set from storage commerce:l ae
data modify storage commerce:cp az192 set from storage commerce:l az
data modify storage commerce:cp ac192 set from storage commerce:l ac
data modify storage commerce:cp t192 set from storage commerce:l t
scoreboard players set #i c.t 193
function commerce:page/ligne
data modify storage commerce:cp ve193 set from storage commerce:l ve
data modify storage commerce:cp vz193 set from storage commerce:l vz
data modify storage commerce:cp vc193 set from storage commerce:l vc
data modify storage commerce:cp ae193 set from storage commerce:l ae
data modify storage commerce:cp az193 set from storage commerce:l az
data modify storage commerce:cp ac193 set from storage commerce:l ac
data modify storage commerce:cp t193 set from storage commerce:l t
scoreboard players set #i c.t 194
function commerce:page/ligne
data modify storage commerce:cp ve194 set from storage commerce:l ve
data modify storage commerce:cp vz194 set from storage commerce:l vz
data modify storage commerce:cp vc194 set from storage commerce:l vc
data modify storage commerce:cp ae194 set from storage commerce:l ae
data modify storage commerce:cp az194 set from storage commerce:l az
data modify storage commerce:cp ac194 set from storage commerce:l ac
data modify storage commerce:cp t194 set from storage commerce:l t
scoreboard players set #i c.t 195
function commerce:page/ligne
data modify storage commerce:cp ve195 set from storage commerce:l ve
data modify storage commerce:cp vz195 set from storage commerce:l vz
data modify storage commerce:cp vc195 set from storage commerce:l vc
data modify storage commerce:cp ae195 set from storage commerce:l ae
data modify storage commerce:cp az195 set from storage commerce:l az
data modify storage commerce:cp ac195 set from storage commerce:l ac
data modify storage commerce:cp t195 set from storage commerce:l t
scoreboard players set #i c.t 196
function commerce:page/ligne
data modify storage commerce:cp ve196 set from storage commerce:l ve
data modify storage commerce:cp vz196 set from storage commerce:l vz
data modify storage commerce:cp vc196 set from storage commerce:l vc
data modify storage commerce:cp ae196 set from storage commerce:l ae
data modify storage commerce:cp az196 set from storage commerce:l az
data modify storage commerce:cp ac196 set from storage commerce:l ac
data modify storage commerce:cp t196 set from storage commerce:l t
function commerce:page/cat_7_0_d with storage commerce:cp
