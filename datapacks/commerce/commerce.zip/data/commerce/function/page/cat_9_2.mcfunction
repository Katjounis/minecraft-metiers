function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 270
function commerce:page/ligne
data modify storage commerce:cp ve270 set from storage commerce:l ve
data modify storage commerce:cp vz270 set from storage commerce:l vz
data modify storage commerce:cp vc270 set from storage commerce:l vc
data modify storage commerce:cp ae270 set from storage commerce:l ae
data modify storage commerce:cp az270 set from storage commerce:l az
data modify storage commerce:cp ac270 set from storage commerce:l ac
data modify storage commerce:cp t270 set from storage commerce:l t
scoreboard players set #i c.t 271
function commerce:page/ligne
data modify storage commerce:cp ve271 set from storage commerce:l ve
data modify storage commerce:cp vz271 set from storage commerce:l vz
data modify storage commerce:cp vc271 set from storage commerce:l vc
data modify storage commerce:cp ae271 set from storage commerce:l ae
data modify storage commerce:cp az271 set from storage commerce:l az
data modify storage commerce:cp ac271 set from storage commerce:l ac
data modify storage commerce:cp t271 set from storage commerce:l t
scoreboard players set #i c.t 272
function commerce:page/ligne
data modify storage commerce:cp ve272 set from storage commerce:l ve
data modify storage commerce:cp vz272 set from storage commerce:l vz
data modify storage commerce:cp vc272 set from storage commerce:l vc
data modify storage commerce:cp ae272 set from storage commerce:l ae
data modify storage commerce:cp az272 set from storage commerce:l az
data modify storage commerce:cp ac272 set from storage commerce:l ac
data modify storage commerce:cp t272 set from storage commerce:l t
scoreboard players set #i c.t 273
function commerce:page/ligne
data modify storage commerce:cp ve273 set from storage commerce:l ve
data modify storage commerce:cp vz273 set from storage commerce:l vz
data modify storage commerce:cp vc273 set from storage commerce:l vc
data modify storage commerce:cp ae273 set from storage commerce:l ae
data modify storage commerce:cp az273 set from storage commerce:l az
data modify storage commerce:cp ac273 set from storage commerce:l ac
data modify storage commerce:cp t273 set from storage commerce:l t
scoreboard players set #i c.t 274
function commerce:page/ligne
data modify storage commerce:cp ve274 set from storage commerce:l ve
data modify storage commerce:cp vz274 set from storage commerce:l vz
data modify storage commerce:cp vc274 set from storage commerce:l vc
data modify storage commerce:cp ae274 set from storage commerce:l ae
data modify storage commerce:cp az274 set from storage commerce:l az
data modify storage commerce:cp ac274 set from storage commerce:l ac
data modify storage commerce:cp t274 set from storage commerce:l t
scoreboard players set #i c.t 275
function commerce:page/ligne
data modify storage commerce:cp ve275 set from storage commerce:l ve
data modify storage commerce:cp vz275 set from storage commerce:l vz
data modify storage commerce:cp vc275 set from storage commerce:l vc
data modify storage commerce:cp ae275 set from storage commerce:l ae
data modify storage commerce:cp az275 set from storage commerce:l az
data modify storage commerce:cp ac275 set from storage commerce:l ac
data modify storage commerce:cp t275 set from storage commerce:l t
scoreboard players set #i c.t 276
function commerce:page/ligne
data modify storage commerce:cp ve276 set from storage commerce:l ve
data modify storage commerce:cp vz276 set from storage commerce:l vz
data modify storage commerce:cp vc276 set from storage commerce:l vc
data modify storage commerce:cp ae276 set from storage commerce:l ae
data modify storage commerce:cp az276 set from storage commerce:l az
data modify storage commerce:cp ac276 set from storage commerce:l ac
data modify storage commerce:cp t276 set from storage commerce:l t
scoreboard players set #i c.t 277
function commerce:page/ligne
data modify storage commerce:cp ve277 set from storage commerce:l ve
data modify storage commerce:cp vz277 set from storage commerce:l vz
data modify storage commerce:cp vc277 set from storage commerce:l vc
data modify storage commerce:cp ae277 set from storage commerce:l ae
data modify storage commerce:cp az277 set from storage commerce:l az
data modify storage commerce:cp ac277 set from storage commerce:l ac
data modify storage commerce:cp t277 set from storage commerce:l t
scoreboard players set #i c.t 278
function commerce:page/ligne
data modify storage commerce:cp ve278 set from storage commerce:l ve
data modify storage commerce:cp vz278 set from storage commerce:l vz
data modify storage commerce:cp vc278 set from storage commerce:l vc
data modify storage commerce:cp ae278 set from storage commerce:l ae
data modify storage commerce:cp az278 set from storage commerce:l az
data modify storage commerce:cp ac278 set from storage commerce:l ac
data modify storage commerce:cp t278 set from storage commerce:l t
function commerce:page/cat_9_2_d with storage commerce:cp
