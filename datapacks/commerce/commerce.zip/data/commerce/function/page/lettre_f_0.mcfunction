function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 229
function commerce:page/ligne
data modify storage commerce:cp ve229 set from storage commerce:l ve
data modify storage commerce:cp vz229 set from storage commerce:l vz
data modify storage commerce:cp vc229 set from storage commerce:l vc
data modify storage commerce:cp ae229 set from storage commerce:l ae
data modify storage commerce:cp az229 set from storage commerce:l az
data modify storage commerce:cp ac229 set from storage commerce:l ac
data modify storage commerce:cp t229 set from storage commerce:l t
scoreboard players set #i c.t 365
function commerce:page/ligne
data modify storage commerce:cp ve365 set from storage commerce:l ve
data modify storage commerce:cp vz365 set from storage commerce:l vz
data modify storage commerce:cp vc365 set from storage commerce:l vc
data modify storage commerce:cp ae365 set from storage commerce:l ae
data modify storage commerce:cp az365 set from storage commerce:l az
data modify storage commerce:cp ac365 set from storage commerce:l ac
data modify storage commerce:cp t365 set from storage commerce:l t
scoreboard players set #i c.t 95
function commerce:page/ligne
data modify storage commerce:cp ve95 set from storage commerce:l ve
data modify storage commerce:cp vz95 set from storage commerce:l vz
data modify storage commerce:cp vc95 set from storage commerce:l vc
data modify storage commerce:cp ae95 set from storage commerce:l ae
data modify storage commerce:cp az95 set from storage commerce:l az
data modify storage commerce:cp ac95 set from storage commerce:l ac
data modify storage commerce:cp t95 set from storage commerce:l t
scoreboard players set #i c.t 110
function commerce:page/ligne
data modify storage commerce:cp ve110 set from storage commerce:l ve
data modify storage commerce:cp vz110 set from storage commerce:l vz
data modify storage commerce:cp vc110 set from storage commerce:l vc
data modify storage commerce:cp ae110 set from storage commerce:l ae
data modify storage commerce:cp az110 set from storage commerce:l az
data modify storage commerce:cp ac110 set from storage commerce:l ac
data modify storage commerce:cp t110 set from storage commerce:l t
scoreboard players set #i c.t 89
function commerce:page/ligne
data modify storage commerce:cp ve89 set from storage commerce:l ve
data modify storage commerce:cp vz89 set from storage commerce:l vz
data modify storage commerce:cp vc89 set from storage commerce:l vc
data modify storage commerce:cp ae89 set from storage commerce:l ae
data modify storage commerce:cp az89 set from storage commerce:l az
data modify storage commerce:cp ac89 set from storage commerce:l ac
data modify storage commerce:cp t89 set from storage commerce:l t
scoreboard players set #i c.t 104
function commerce:page/ligne
data modify storage commerce:cp ve104 set from storage commerce:l ve
data modify storage commerce:cp vz104 set from storage commerce:l vz
data modify storage commerce:cp vc104 set from storage commerce:l vc
data modify storage commerce:cp ae104 set from storage commerce:l ae
data modify storage commerce:cp az104 set from storage commerce:l az
data modify storage commerce:cp ac104 set from storage commerce:l ac
data modify storage commerce:cp t104 set from storage commerce:l t
scoreboard players set #i c.t 113
function commerce:page/ligne
data modify storage commerce:cp ve113 set from storage commerce:l ve
data modify storage commerce:cp vz113 set from storage commerce:l vz
data modify storage commerce:cp vc113 set from storage commerce:l vc
data modify storage commerce:cp ae113 set from storage commerce:l ae
data modify storage commerce:cp az113 set from storage commerce:l az
data modify storage commerce:cp ac113 set from storage commerce:l ac
data modify storage commerce:cp t113 set from storage commerce:l t
scoreboard players set #i c.t 107
function commerce:page/ligne
data modify storage commerce:cp ve107 set from storage commerce:l ve
data modify storage commerce:cp vz107 set from storage commerce:l vz
data modify storage commerce:cp vc107 set from storage commerce:l vc
data modify storage commerce:cp ae107 set from storage commerce:l ae
data modify storage commerce:cp az107 set from storage commerce:l az
data modify storage commerce:cp ac107 set from storage commerce:l ac
data modify storage commerce:cp t107 set from storage commerce:l t
scoreboard players set #i c.t 92
function commerce:page/ligne
data modify storage commerce:cp ve92 set from storage commerce:l ve
data modify storage commerce:cp vz92 set from storage commerce:l vz
data modify storage commerce:cp vc92 set from storage commerce:l vc
data modify storage commerce:cp ae92 set from storage commerce:l ae
data modify storage commerce:cp az92 set from storage commerce:l az
data modify storage commerce:cp ac92 set from storage commerce:l ac
data modify storage commerce:cp t92 set from storage commerce:l t
scoreboard players set #i c.t 101
function commerce:page/ligne
data modify storage commerce:cp ve101 set from storage commerce:l ve
data modify storage commerce:cp vz101 set from storage commerce:l vz
data modify storage commerce:cp vc101 set from storage commerce:l vc
data modify storage commerce:cp ae101 set from storage commerce:l ae
data modify storage commerce:cp az101 set from storage commerce:l az
data modify storage commerce:cp ac101 set from storage commerce:l ac
data modify storage commerce:cp t101 set from storage commerce:l t
function commerce:page/lettre_f_0_d with storage commerce:cp
