function commerce:fmt/solde
data modify storage commerce:cp se set from storage commerce:t s.e
data modify storage commerce:cp sz set from storage commerce:t s.z
data modify storage commerce:cp sc set from storage commerce:t s.c
scoreboard players set #i c.t 58
function commerce:page/ligne
data modify storage commerce:cp ve58 set from storage commerce:l ve
data modify storage commerce:cp vz58 set from storage commerce:l vz
data modify storage commerce:cp vc58 set from storage commerce:l vc
data modify storage commerce:cp ae58 set from storage commerce:l ae
data modify storage commerce:cp az58 set from storage commerce:l az
data modify storage commerce:cp ac58 set from storage commerce:l ac
data modify storage commerce:cp t58 set from storage commerce:l t
scoreboard players set #i c.t 277
function commerce:page/ligne
data modify storage commerce:cp ve277 set from storage commerce:l ve
data modify storage commerce:cp vz277 set from storage commerce:l vz
data modify storage commerce:cp vc277 set from storage commerce:l vc
data modify storage commerce:cp ae277 set from storage commerce:l ae
data modify storage commerce:cp az277 set from storage commerce:l az
data modify storage commerce:cp ac277 set from storage commerce:l ac
data modify storage commerce:cp t277 set from storage commerce:l t
scoreboard players set #i c.t 268
function commerce:page/ligne
data modify storage commerce:cp ve268 set from storage commerce:l ve
data modify storage commerce:cp vz268 set from storage commerce:l vz
data modify storage commerce:cp vc268 set from storage commerce:l vc
data modify storage commerce:cp ae268 set from storage commerce:l ae
data modify storage commerce:cp az268 set from storage commerce:l az
data modify storage commerce:cp ac268 set from storage commerce:l ac
data modify storage commerce:cp t268 set from storage commerce:l t
scoreboard players set #i c.t 240
function commerce:page/ligne
data modify storage commerce:cp ve240 set from storage commerce:l ve
data modify storage commerce:cp vz240 set from storage commerce:l vz
data modify storage commerce:cp vc240 set from storage commerce:l vc
data modify storage commerce:cp ae240 set from storage commerce:l ae
data modify storage commerce:cp az240 set from storage commerce:l az
data modify storage commerce:cp ac240 set from storage commerce:l ac
data modify storage commerce:cp t240 set from storage commerce:l t
scoreboard players set #i c.t 327
function commerce:page/ligne
data modify storage commerce:cp ve327 set from storage commerce:l ve
data modify storage commerce:cp vz327 set from storage commerce:l vz
data modify storage commerce:cp vc327 set from storage commerce:l vc
data modify storage commerce:cp ae327 set from storage commerce:l ae
data modify storage commerce:cp az327 set from storage commerce:l az
data modify storage commerce:cp ac327 set from storage commerce:l ac
data modify storage commerce:cp t327 set from storage commerce:l t
scoreboard players set #i c.t 25
function commerce:page/ligne
data modify storage commerce:cp ve25 set from storage commerce:l ve
data modify storage commerce:cp vz25 set from storage commerce:l vz
data modify storage commerce:cp vc25 set from storage commerce:l vc
data modify storage commerce:cp ae25 set from storage commerce:l ae
data modify storage commerce:cp az25 set from storage commerce:l az
data modify storage commerce:cp ac25 set from storage commerce:l ac
data modify storage commerce:cp t25 set from storage commerce:l t
scoreboard players set #i c.t 267
function commerce:page/ligne
data modify storage commerce:cp ve267 set from storage commerce:l ve
data modify storage commerce:cp vz267 set from storage commerce:l vz
data modify storage commerce:cp vc267 set from storage commerce:l vc
data modify storage commerce:cp ae267 set from storage commerce:l ae
data modify storage commerce:cp az267 set from storage commerce:l az
data modify storage commerce:cp ac267 set from storage commerce:l ac
data modify storage commerce:cp t267 set from storage commerce:l t
scoreboard players set #i c.t 266
function commerce:page/ligne
data modify storage commerce:cp ve266 set from storage commerce:l ve
data modify storage commerce:cp vz266 set from storage commerce:l vz
data modify storage commerce:cp vc266 set from storage commerce:l vc
data modify storage commerce:cp ae266 set from storage commerce:l ae
data modify storage commerce:cp az266 set from storage commerce:l az
data modify storage commerce:cp ac266 set from storage commerce:l ac
data modify storage commerce:cp t266 set from storage commerce:l t
scoreboard players set #i c.t 309
function commerce:page/ligne
data modify storage commerce:cp ve309 set from storage commerce:l ve
data modify storage commerce:cp vz309 set from storage commerce:l vz
data modify storage commerce:cp vc309 set from storage commerce:l vc
data modify storage commerce:cp ae309 set from storage commerce:l ae
data modify storage commerce:cp az309 set from storage commerce:l az
data modify storage commerce:cp ac309 set from storage commerce:l ac
data modify storage commerce:cp t309 set from storage commerce:l t
scoreboard players set #i c.t 280
function commerce:page/ligne
data modify storage commerce:cp ve280 set from storage commerce:l ve
data modify storage commerce:cp vz280 set from storage commerce:l vz
data modify storage commerce:cp vc280 set from storage commerce:l vc
data modify storage commerce:cp ae280 set from storage commerce:l ae
data modify storage commerce:cp az280 set from storage commerce:l az
data modify storage commerce:cp ac280 set from storage commerce:l ac
data modify storage commerce:cp t280 set from storage commerce:l t
function commerce:page/lettre_b_5_d with storage commerce:cp
