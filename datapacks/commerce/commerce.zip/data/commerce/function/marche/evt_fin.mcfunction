scoreboard players operation #i c.t = #evi c.g
function commerce:item/charger
scoreboard players set #e c.t 1000
function commerce:item/sauver
scoreboard players set #evi c.g 0
data modify storage commerce:g evtxt set value ""
tellraw @a [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Bourse : le cours de ",color:"light_purple",bold:false,italic:false},{storage:"commerce:t",nbt:"it.n",color:"white"},{text:" revient à la normale.",color:"light_purple",bold:false,italic:false}]
