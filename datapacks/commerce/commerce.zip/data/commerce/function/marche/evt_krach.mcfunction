$data modify storage commerce:g evtxt set value "Krach de $(n) ! Son prix est divisé par deux pendant 2 h de jeu."
