$data modify storage commerce:g evtxt set value "Pénurie de $(n) ! Il se vend 60 % plus cher pendant 2 h de jeu."
