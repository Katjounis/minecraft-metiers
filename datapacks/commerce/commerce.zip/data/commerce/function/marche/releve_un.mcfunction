function commerce:item/charger
scoreboard players set #d c.t 0
function commerce:prix/mid
function commerce:prix/sans_bonus
function commerce:prix/vente
scoreboard players operation #h c.t = #u0 c.t
function commerce:item/sauver
