execute store result score #i c.t run random value 1..117
scoreboard players operation #evi c.g = #i c.t
scoreboard players set #evt c.g 2
function commerce:item/charger
execute store result score #r c.t run random value 1..2
execute if score #r c.t matches 1 run scoreboard players set #e c.t 1600
execute if score #r c.t matches 2 run scoreboard players set #e c.t 500
function commerce:item/sauver
execute if score #r c.t matches 1 run function commerce:marche/evt_penurie with storage commerce:t it
execute if score #r c.t matches 2 run function commerce:marche/evt_krach with storage commerce:t it
tellraw @a [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Bourse : ",color:"light_purple",bold:true,italic:false},{storage:"commerce:g",nbt:"evtxt",color:"white"}]
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.7 1.4
