scoreboard players set #hr c.g 0
function commerce:marche/releve
scoreboard players set #r c.t 100
execute if score #evi c.g matches 0 store result score #r c.t run random value 1..100
execute if score #evt c.g matches 1.. run scoreboard players remove #evt c.g 1
execute if score #evi c.g matches 1.. if score #evt c.g matches 0 run function commerce:marche/evt_fin
execute if score #r c.t matches ..40 run function commerce:marche/evt_debut
