scoreboard players set #dec c.g 0
scoreboard players operation #x c.t = #cobblestone c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #cobblestone c.p -= #x c.t
execute if score #cobblestone c.p matches -11..11 run scoreboard players set #cobblestone c.p 0
scoreboard players operation #x c.t = #cobbled_deepslate c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #cobbled_deepslate c.p -= #x c.t
execute if score #cobbled_deepslate c.p matches -11..11 run scoreboard players set #cobbled_deepslate c.p 0
scoreboard players operation #x c.t = #stone c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #stone c.p -= #x c.t
execute if score #stone c.p matches -11..11 run scoreboard players set #stone c.p 0
scoreboard players operation #x c.t = #deepslate c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #deepslate c.p -= #x c.t
execute if score #deepslate c.p matches -11..11 run scoreboard players set #deepslate c.p 0
scoreboard players operation #x c.t = #andesite c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #andesite c.p -= #x c.t
execute if score #andesite c.p matches -11..11 run scoreboard players set #andesite c.p 0
scoreboard players operation #x c.t = #diorite c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #diorite c.p -= #x c.t
execute if score #diorite c.p matches -11..11 run scoreboard players set #diorite c.p 0
scoreboard players operation #x c.t = #granite c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #granite c.p -= #x c.t
execute if score #granite c.p matches -11..11 run scoreboard players set #granite c.p 0
scoreboard players operation #x c.t = #tuff c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #tuff c.p -= #x c.t
execute if score #tuff c.p matches -11..11 run scoreboard players set #tuff c.p 0
scoreboard players operation #x c.t = #calcite c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #calcite c.p -= #x c.t
execute if score #calcite c.p matches -11..11 run scoreboard players set #calcite c.p 0
scoreboard players operation #x c.t = #blackstone c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #blackstone c.p -= #x c.t
execute if score #blackstone c.p matches -11..11 run scoreboard players set #blackstone c.p 0
scoreboard players operation #x c.t = #basalt c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #basalt c.p -= #x c.t
execute if score #basalt c.p matches -11..11 run scoreboard players set #basalt c.p 0
scoreboard players operation #x c.t = #netherrack c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #netherrack c.p -= #x c.t
execute if score #netherrack c.p matches -11..11 run scoreboard players set #netherrack c.p 0
scoreboard players operation #x c.t = #end_stone c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #end_stone c.p -= #x c.t
execute if score #end_stone c.p matches -11..11 run scoreboard players set #end_stone c.p 0
scoreboard players operation #x c.t = #obsidian c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #obsidian c.p -= #x c.t
execute if score #obsidian c.p matches -11..11 run scoreboard players set #obsidian c.p 0
scoreboard players operation #x c.t = #dirt c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #dirt c.p -= #x c.t
execute if score #dirt c.p matches -11..11 run scoreboard players set #dirt c.p 0
scoreboard players operation #x c.t = #sand c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #sand c.p -= #x c.t
execute if score #sand c.p matches -11..11 run scoreboard players set #sand c.p 0
scoreboard players operation #x c.t = #red_sand c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #red_sand c.p -= #x c.t
execute if score #red_sand c.p matches -11..11 run scoreboard players set #red_sand c.p 0
scoreboard players operation #x c.t = #gravel c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #gravel c.p -= #x c.t
execute if score #gravel c.p matches -11..11 run scoreboard players set #gravel c.p 0
scoreboard players operation #x c.t = #clay_ball c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #clay_ball c.p -= #x c.t
execute if score #clay_ball c.p matches -11..11 run scoreboard players set #clay_ball c.p 0
scoreboard players operation #x c.t = #glass c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #glass c.p -= #x c.t
execute if score #glass c.p matches -11..11 run scoreboard players set #glass c.p 0
scoreboard players operation #x c.t = #stone_bricks c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #stone_bricks c.p -= #x c.t
execute if score #stone_bricks c.p matches -11..11 run scoreboard players set #stone_bricks c.p 0
scoreboard players operation #x c.t = #smooth_stone c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #smooth_stone c.p -= #x c.t
execute if score #smooth_stone c.p matches -11..11 run scoreboard players set #smooth_stone c.p 0
scoreboard players operation #x c.t = #sandstone c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #sandstone c.p -= #x c.t
execute if score #sandstone c.p matches -11..11 run scoreboard players set #sandstone c.p 0
scoreboard players operation #x c.t = #bricks c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #bricks c.p -= #x c.t
execute if score #bricks c.p matches -11..11 run scoreboard players set #bricks c.p 0
scoreboard players operation #x c.t = #terracotta c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #terracotta c.p -= #x c.t
execute if score #terracotta c.p matches -11..11 run scoreboard players set #terracotta c.p 0
scoreboard players operation #x c.t = #white_concrete c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #white_concrete c.p -= #x c.t
execute if score #white_concrete c.p matches -11..11 run scoreboard players set #white_concrete c.p 0
scoreboard players operation #x c.t = #oak_log c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #oak_log c.p -= #x c.t
execute if score #oak_log c.p matches -11..11 run scoreboard players set #oak_log c.p 0
scoreboard players operation #x c.t = #spruce_log c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #spruce_log c.p -= #x c.t
execute if score #spruce_log c.p matches -11..11 run scoreboard players set #spruce_log c.p 0
scoreboard players operation #x c.t = #birch_log c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #birch_log c.p -= #x c.t
execute if score #birch_log c.p matches -11..11 run scoreboard players set #birch_log c.p 0
scoreboard players operation #x c.t = #jungle_log c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #jungle_log c.p -= #x c.t
execute if score #jungle_log c.p matches -11..11 run scoreboard players set #jungle_log c.p 0
scoreboard players operation #x c.t = #acacia_log c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #acacia_log c.p -= #x c.t
execute if score #acacia_log c.p matches -11..11 run scoreboard players set #acacia_log c.p 0
scoreboard players operation #x c.t = #dark_oak_log c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #dark_oak_log c.p -= #x c.t
execute if score #dark_oak_log c.p matches -11..11 run scoreboard players set #dark_oak_log c.p 0
scoreboard players operation #x c.t = #mangrove_log c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #mangrove_log c.p -= #x c.t
execute if score #mangrove_log c.p matches -11..11 run scoreboard players set #mangrove_log c.p 0
scoreboard players operation #x c.t = #cherry_log c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #cherry_log c.p -= #x c.t
execute if score #cherry_log c.p matches -11..11 run scoreboard players set #cherry_log c.p 0
scoreboard players operation #x c.t = #pale_oak_log c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #pale_oak_log c.p -= #x c.t
execute if score #pale_oak_log c.p matches -11..11 run scoreboard players set #pale_oak_log c.p 0
scoreboard players operation #x c.t = #crimson_stem c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #crimson_stem c.p -= #x c.t
execute if score #crimson_stem c.p matches -11..11 run scoreboard players set #crimson_stem c.p 0
scoreboard players operation #x c.t = #warped_stem c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #warped_stem c.p -= #x c.t
execute if score #warped_stem c.p matches -11..11 run scoreboard players set #warped_stem c.p 0
scoreboard players operation #x c.t = #bamboo_block c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #bamboo_block c.p -= #x c.t
execute if score #bamboo_block c.p matches -11..11 run scoreboard players set #bamboo_block c.p 0
scoreboard players operation #x c.t = #apple c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #apple c.p -= #x c.t
execute if score #apple c.p matches -11..11 run scoreboard players set #apple c.p 0
scoreboard players operation #x c.t = #oak_sapling c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #oak_sapling c.p -= #x c.t
execute if score #oak_sapling c.p matches -11..11 run scoreboard players set #oak_sapling c.p 0
scoreboard players operation #x c.t = #coal c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #coal c.p -= #x c.t
execute if score #coal c.p matches -11..11 run scoreboard players set #coal c.p 0
scoreboard players operation #x c.t = #raw_copper c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #raw_copper c.p -= #x c.t
execute if score #raw_copper c.p matches -11..11 run scoreboard players set #raw_copper c.p 0
scoreboard players operation #x c.t = #copper_ingot c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #copper_ingot c.p -= #x c.t
execute if score #copper_ingot c.p matches -11..11 run scoreboard players set #copper_ingot c.p 0
scoreboard players operation #x c.t = #raw_iron c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #raw_iron c.p -= #x c.t
execute if score #raw_iron c.p matches -11..11 run scoreboard players set #raw_iron c.p 0
scoreboard players operation #x c.t = #iron_ingot c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #iron_ingot c.p -= #x c.t
execute if score #iron_ingot c.p matches -11..11 run scoreboard players set #iron_ingot c.p 0
scoreboard players operation #x c.t = #raw_gold c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #raw_gold c.p -= #x c.t
execute if score #raw_gold c.p matches -11..11 run scoreboard players set #raw_gold c.p 0
scoreboard players operation #x c.t = #gold_ingot c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #gold_ingot c.p -= #x c.t
execute if score #gold_ingot c.p matches -11..11 run scoreboard players set #gold_ingot c.p 0
scoreboard players operation #x c.t = #redstone c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #redstone c.p -= #x c.t
execute if score #redstone c.p matches -11..11 run scoreboard players set #redstone c.p 0
scoreboard players operation #x c.t = #lapis_lazuli c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #lapis_lazuli c.p -= #x c.t
execute if score #lapis_lazuli c.p matches -11..11 run scoreboard players set #lapis_lazuli c.p 0
scoreboard players operation #x c.t = #quartz c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #quartz c.p -= #x c.t
execute if score #quartz c.p matches -11..11 run scoreboard players set #quartz c.p 0
scoreboard players operation #x c.t = #amethyst_shard c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #amethyst_shard c.p -= #x c.t
execute if score #amethyst_shard c.p matches -11..11 run scoreboard players set #amethyst_shard c.p 0
scoreboard players operation #x c.t = #glowstone_dust c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #glowstone_dust c.p -= #x c.t
execute if score #glowstone_dust c.p matches -11..11 run scoreboard players set #glowstone_dust c.p 0
scoreboard players operation #x c.t = #flint c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #flint c.p -= #x c.t
execute if score #flint c.p matches -11..11 run scoreboard players set #flint c.p 0
scoreboard players operation #x c.t = #wheat c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #wheat c.p -= #x c.t
execute if score #wheat c.p matches -11..11 run scoreboard players set #wheat c.p 0
scoreboard players operation #x c.t = #wheat_seeds c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #wheat_seeds c.p -= #x c.t
execute if score #wheat_seeds c.p matches -11..11 run scoreboard players set #wheat_seeds c.p 0
scoreboard players operation #x c.t = #carrot c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #carrot c.p -= #x c.t
execute if score #carrot c.p matches -11..11 run scoreboard players set #carrot c.p 0
scoreboard players operation #x c.t = #potato c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #potato c.p -= #x c.t
execute if score #potato c.p matches -11..11 run scoreboard players set #potato c.p 0
scoreboard players operation #x c.t = #beetroot c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #beetroot c.p -= #x c.t
execute if score #beetroot c.p matches -11..11 run scoreboard players set #beetroot c.p 0
scoreboard players operation #x c.t = #melon_slice c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #melon_slice c.p -= #x c.t
execute if score #melon_slice c.p matches -11..11 run scoreboard players set #melon_slice c.p 0
scoreboard players operation #x c.t = #pumpkin c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #pumpkin c.p -= #x c.t
execute if score #pumpkin c.p matches -11..11 run scoreboard players set #pumpkin c.p 0
scoreboard players operation #x c.t = #sugar_cane c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #sugar_cane c.p -= #x c.t
execute if score #sugar_cane c.p matches -11..11 run scoreboard players set #sugar_cane c.p 0
scoreboard players operation #x c.t = #cocoa_beans c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #cocoa_beans c.p -= #x c.t
execute if score #cocoa_beans c.p matches -11..11 run scoreboard players set #cocoa_beans c.p 0
scoreboard players operation #x c.t = #nether_wart c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #nether_wart c.p -= #x c.t
execute if score #nether_wart c.p matches -11..11 run scoreboard players set #nether_wart c.p 0
scoreboard players operation #x c.t = #sweet_berries c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #sweet_berries c.p -= #x c.t
execute if score #sweet_berries c.p matches -11..11 run scoreboard players set #sweet_berries c.p 0
scoreboard players operation #x c.t = #cactus c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #cactus c.p -= #x c.t
execute if score #cactus c.p matches -11..11 run scoreboard players set #cactus c.p 0
scoreboard players operation #x c.t = #bamboo c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #bamboo c.p -= #x c.t
execute if score #bamboo c.p matches -11..11 run scoreboard players set #bamboo c.p 0
scoreboard players operation #x c.t = #white_wool c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #white_wool c.p -= #x c.t
execute if score #white_wool c.p matches -11..11 run scoreboard players set #white_wool c.p 0
scoreboard players operation #x c.t = #leather c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #leather c.p -= #x c.t
execute if score #leather c.p matches -11..11 run scoreboard players set #leather c.p 0
scoreboard players operation #x c.t = #egg c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #egg c.p -= #x c.t
execute if score #egg c.p matches -11..11 run scoreboard players set #egg c.p 0
scoreboard players operation #x c.t = #feather c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #feather c.p -= #x c.t
execute if score #feather c.p matches -11..11 run scoreboard players set #feather c.p 0
scoreboard players operation #x c.t = #beef c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #beef c.p -= #x c.t
execute if score #beef c.p matches -11..11 run scoreboard players set #beef c.p 0
scoreboard players operation #x c.t = #porkchop c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #porkchop c.p -= #x c.t
execute if score #porkchop c.p matches -11..11 run scoreboard players set #porkchop c.p 0
scoreboard players operation #x c.t = #chicken c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #chicken c.p -= #x c.t
execute if score #chicken c.p matches -11..11 run scoreboard players set #chicken c.p 0
scoreboard players operation #x c.t = #mutton c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #mutton c.p -= #x c.t
execute if score #mutton c.p matches -11..11 run scoreboard players set #mutton c.p 0
scoreboard players operation #x c.t = #rabbit c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #rabbit c.p -= #x c.t
execute if score #rabbit c.p matches -11..11 run scoreboard players set #rabbit c.p 0
scoreboard players operation #x c.t = #honeycomb c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #honeycomb c.p -= #x c.t
execute if score #honeycomb c.p matches -11..11 run scoreboard players set #honeycomb c.p 0
scoreboard players operation #x c.t = #rotten_flesh c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #rotten_flesh c.p -= #x c.t
execute if score #rotten_flesh c.p matches -11..11 run scoreboard players set #rotten_flesh c.p 0
scoreboard players operation #x c.t = #bone c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #bone c.p -= #x c.t
execute if score #bone c.p matches -11..11 run scoreboard players set #bone c.p 0
scoreboard players operation #x c.t = #string c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #string c.p -= #x c.t
execute if score #string c.p matches -11..11 run scoreboard players set #string c.p 0
scoreboard players operation #x c.t = #gunpowder c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #gunpowder c.p -= #x c.t
execute if score #gunpowder c.p matches -11..11 run scoreboard players set #gunpowder c.p 0
scoreboard players operation #x c.t = #spider_eye c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #spider_eye c.p -= #x c.t
execute if score #spider_eye c.p matches -11..11 run scoreboard players set #spider_eye c.p 0
scoreboard players operation #x c.t = #slime_ball c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #slime_ball c.p -= #x c.t
execute if score #slime_ball c.p matches -11..11 run scoreboard players set #slime_ball c.p 0
scoreboard players operation #x c.t = #ender_pearl c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #ender_pearl c.p -= #x c.t
execute if score #ender_pearl c.p matches -11..11 run scoreboard players set #ender_pearl c.p 0
scoreboard players operation #x c.t = #blaze_rod c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #blaze_rod c.p -= #x c.t
execute if score #blaze_rod c.p matches -11..11 run scoreboard players set #blaze_rod c.p 0
scoreboard players operation #x c.t = #phantom_membrane c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #phantom_membrane c.p -= #x c.t
execute if score #phantom_membrane c.p matches -11..11 run scoreboard players set #phantom_membrane c.p 0
scoreboard players operation #x c.t = #cod c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #cod c.p -= #x c.t
execute if score #cod c.p matches -11..11 run scoreboard players set #cod c.p 0
scoreboard players operation #x c.t = #salmon c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #salmon c.p -= #x c.t
execute if score #salmon c.p matches -11..11 run scoreboard players set #salmon c.p 0
scoreboard players operation #x c.t = #tropical_fish c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #tropical_fish c.p -= #x c.t
execute if score #tropical_fish c.p matches -11..11 run scoreboard players set #tropical_fish c.p 0
scoreboard players operation #x c.t = #pufferfish c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #pufferfish c.p -= #x c.t
execute if score #pufferfish c.p matches -11..11 run scoreboard players set #pufferfish c.p 0
scoreboard players operation #x c.t = #ink_sac c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #ink_sac c.p -= #x c.t
execute if score #ink_sac c.p matches -11..11 run scoreboard players set #ink_sac c.p 0
scoreboard players operation #x c.t = #glow_ink_sac c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #glow_ink_sac c.p -= #x c.t
execute if score #glow_ink_sac c.p matches -11..11 run scoreboard players set #glow_ink_sac c.p 0
scoreboard players operation #x c.t = #prismarine_shard c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #prismarine_shard c.p -= #x c.t
execute if score #prismarine_shard c.p matches -11..11 run scoreboard players set #prismarine_shard c.p 0
scoreboard players operation #x c.t = #prismarine_crystals c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #prismarine_crystals c.p -= #x c.t
execute if score #prismarine_crystals c.p matches -11..11 run scoreboard players set #prismarine_crystals c.p 0
scoreboard players operation #x c.t = #lily_pad c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #lily_pad c.p -= #x c.t
execute if score #lily_pad c.p matches -11..11 run scoreboard players set #lily_pad c.p 0
scoreboard players operation #x c.t = #kelp c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #kelp c.p -= #x c.t
execute if score #kelp c.p matches -11..11 run scoreboard players set #kelp c.p 0
scoreboard players operation #x c.t = #bread c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #bread c.p -= #x c.t
execute if score #bread c.p matches -11..11 run scoreboard players set #bread c.p 0
scoreboard players operation #x c.t = #baked_potato c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #baked_potato c.p -= #x c.t
execute if score #baked_potato c.p matches -11..11 run scoreboard players set #baked_potato c.p 0
scoreboard players operation #x c.t = #pumpkin_pie c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #pumpkin_pie c.p -= #x c.t
execute if score #pumpkin_pie c.p matches -11..11 run scoreboard players set #pumpkin_pie c.p 0
scoreboard players operation #x c.t = #cookie c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #cookie c.p -= #x c.t
execute if score #cookie c.p matches -11..11 run scoreboard players set #cookie c.p 0
scoreboard players operation #x c.t = #cooked_beef c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #cooked_beef c.p -= #x c.t
execute if score #cooked_beef c.p matches -11..11 run scoreboard players set #cooked_beef c.p 0
scoreboard players operation #x c.t = #cooked_porkchop c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #cooked_porkchop c.p -= #x c.t
execute if score #cooked_porkchop c.p matches -11..11 run scoreboard players set #cooked_porkchop c.p 0
scoreboard players operation #x c.t = #cooked_chicken c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #cooked_chicken c.p -= #x c.t
execute if score #cooked_chicken c.p matches -11..11 run scoreboard players set #cooked_chicken c.p 0
scoreboard players operation #x c.t = #cooked_salmon c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #cooked_salmon c.p -= #x c.t
execute if score #cooked_salmon c.p matches -11..11 run scoreboard players set #cooked_salmon c.p 0
scoreboard players operation #x c.t = #golden_carrot c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #golden_carrot c.p -= #x c.t
execute if score #golden_carrot c.p matches -11..11 run scoreboard players set #golden_carrot c.p 0
scoreboard players operation #x c.t = #golden_apple c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #golden_apple c.p -= #x c.t
execute if score #golden_apple c.p matches -11..11 run scoreboard players set #golden_apple c.p 0
scoreboard players operation #x c.t = #torch c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #torch c.p -= #x c.t
execute if score #torch c.p matches -11..11 run scoreboard players set #torch c.p 0
scoreboard players operation #x c.t = #lantern c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #lantern c.p -= #x c.t
execute if score #lantern c.p matches -11..11 run scoreboard players set #lantern c.p 0
scoreboard players operation #x c.t = #chest c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #chest c.p -= #x c.t
execute if score #chest c.p matches -11..11 run scoreboard players set #chest c.p 0
scoreboard players operation #x c.t = #barrel c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #barrel c.p -= #x c.t
execute if score #barrel c.p matches -11..11 run scoreboard players set #barrel c.p 0
scoreboard players operation #x c.t = #ladder c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #ladder c.p -= #x c.t
execute if score #ladder c.p matches -11..11 run scoreboard players set #ladder c.p 0
scoreboard players operation #x c.t = #rail c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #rail c.p -= #x c.t
execute if score #rail c.p matches -11..11 run scoreboard players set #rail c.p 0
scoreboard players operation #x c.t = #piston c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #piston c.p -= #x c.t
execute if score #piston c.p matches -11..11 run scoreboard players set #piston c.p 0
scoreboard players operation #x c.t = #observer c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #observer c.p -= #x c.t
execute if score #observer c.p matches -11..11 run scoreboard players set #observer c.p 0
scoreboard players operation #x c.t = #hopper c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #hopper c.p -= #x c.t
execute if score #hopper c.p matches -11..11 run scoreboard players set #hopper c.p 0
scoreboard players operation #x c.t = #bucket c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #bucket c.p -= #x c.t
execute if score #bucket c.p matches -11..11 run scoreboard players set #bucket c.p 0
scoreboard players operation #x c.t = #name_tag c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #name_tag c.p -= #x c.t
execute if score #name_tag c.p matches -11..11 run scoreboard players set #name_tag c.p 0
scoreboard players operation #x c.t = #saddle c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #saddle c.p -= #x c.t
execute if score #saddle c.p matches -11..11 run scoreboard players set #saddle c.p 0
scoreboard players operation #x c.t = #diamond c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #diamond c.p -= #x c.t
execute if score #diamond c.p matches -11..11 run scoreboard players set #diamond c.p 0
scoreboard players operation #x c.t = #emerald c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #emerald c.p -= #x c.t
execute if score #emerald c.p matches -11..11 run scoreboard players set #emerald c.p 0
scoreboard players operation #x c.t = #ancient_debris c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #ancient_debris c.p -= #x c.t
execute if score #ancient_debris c.p matches -11..11 run scoreboard players set #ancient_debris c.p 0
scoreboard players operation #x c.t = #netherite_scrap c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #netherite_scrap c.p -= #x c.t
execute if score #netherite_scrap c.p matches -11..11 run scoreboard players set #netherite_scrap c.p 0
scoreboard players operation #x c.t = #netherite_ingot c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #netherite_ingot c.p -= #x c.t
execute if score #netherite_ingot c.p matches -11..11 run scoreboard players set #netherite_ingot c.p 0
scoreboard players operation #x c.t = #echo_shard c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #echo_shard c.p -= #x c.t
execute if score #echo_shard c.p matches -11..11 run scoreboard players set #echo_shard c.p 0
scoreboard players operation #x c.t = #nautilus_shell c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #nautilus_shell c.p -= #x c.t
execute if score #nautilus_shell c.p matches -11..11 run scoreboard players set #nautilus_shell c.p 0
scoreboard players operation #x c.t = #heart_of_the_sea c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #heart_of_the_sea c.p -= #x c.t
execute if score #heart_of_the_sea c.p matches -11..11 run scoreboard players set #heart_of_the_sea c.p 0
scoreboard players operation #x c.t = #ghast_tear c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #ghast_tear c.p -= #x c.t
execute if score #ghast_tear c.p matches -11..11 run scoreboard players set #ghast_tear c.p 0
scoreboard players operation #x c.t = #shulker_shell c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #shulker_shell c.p -= #x c.t
execute if score #shulker_shell c.p matches -11..11 run scoreboard players set #shulker_shell c.p 0
scoreboard players operation #x c.t = #totem_of_undying c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #totem_of_undying c.p -= #x c.t
execute if score #totem_of_undying c.p matches -11..11 run scoreboard players set #totem_of_undying c.p 0
scoreboard players operation #x c.t = #wither_skeleton_skull c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #wither_skeleton_skull c.p -= #x c.t
execute if score #wither_skeleton_skull c.p matches -11..11 run scoreboard players set #wither_skeleton_skull c.p 0
scoreboard players operation #x c.t = #nether_star c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #nether_star c.p -= #x c.t
execute if score #nether_star c.p matches -11..11 run scoreboard players set #nether_star c.p 0
scoreboard players operation #x c.t = #trident c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #trident c.p -= #x c.t
execute if score #trident c.p matches -11..11 run scoreboard players set #trident c.p 0
scoreboard players operation #x c.t = #elytra c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #elytra c.p -= #x c.t
execute if score #elytra c.p matches -11..11 run scoreboard players set #elytra c.p 0
scoreboard players operation #x c.t = #enchanted_golden_apple c.p
scoreboard players operation #x c.t /= #12 c.g
scoreboard players operation #enchanted_golden_apple c.p -= #x c.t
execute if score #enchanted_golden_apple c.p matches -11..11 run scoreboard players set #enchanted_golden_apple c.p 0
