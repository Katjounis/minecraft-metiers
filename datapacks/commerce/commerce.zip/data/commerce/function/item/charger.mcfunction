execute store result storage commerce:t k.n int 1 run scoreboard players get #i c.t
function commerce:item/charger_m with storage commerce:t k
