$scoreboard players set #$(id) c.x 1
