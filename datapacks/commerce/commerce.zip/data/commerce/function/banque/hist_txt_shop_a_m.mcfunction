$data modify storage commerce:t hl.txt set value "Magasin de $(nom), achat : -$(v) Écus"
function commerce:banque/hist with storage commerce:t hl
