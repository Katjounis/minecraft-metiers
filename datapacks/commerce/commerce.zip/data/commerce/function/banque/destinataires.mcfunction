data modify storage commerce:bq D set value [{text:""}]
data modify storage commerce:t W set from storage commerce:j l
function commerce:banque/dest_boucle
function commerce:banque/dest_d with storage commerce:bq
