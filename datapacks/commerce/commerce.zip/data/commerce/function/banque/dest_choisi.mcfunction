scoreboard players operation @s c.dest = #v c.t
scoreboard players remove @s c.dest 8100000
scoreboard players set @s c.pend 1
execute store result storage commerce:bq o.id int 1 run scoreboard players get @s c.dest
data modify storage commerce:bq o.nom set value "?"
function commerce:banque/nom_de with storage commerce:bq o
data modify storage commerce:bq o.m set value "$(m)"
function commerce:banque/montant_d with storage commerce:bq o
