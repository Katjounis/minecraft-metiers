$data modify storage commerce:t hl.txt set value "Épargne : $(v) Écus déposés"
function commerce:banque/hist with storage commerce:t hl
