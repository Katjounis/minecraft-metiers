$data modify storage commerce:t hl.txt set value "Virement à $(nom) : -$(v) Écus"
function commerce:banque/hist with storage commerce:t hl
