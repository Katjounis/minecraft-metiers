$data modify storage commerce:t hl.txt set value "Virement de $(nom) : +$(v) Écus"
function commerce:banque/hist with storage commerce:t hl
