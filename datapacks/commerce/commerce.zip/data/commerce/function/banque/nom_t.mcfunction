$data modify storage commerce:t o.nom set from storage commerce:j l[{id:$(id)}].nom
