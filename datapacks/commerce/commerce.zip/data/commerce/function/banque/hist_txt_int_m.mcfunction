$data modify storage commerce:t hl.txt set value "Intérêts de l’épargne : +$(v) Écus"
function commerce:banque/hist with storage commerce:t hl
