$data modify storage commerce:h p$(id) prepend value {text:"$(txt)\n",color:"$(col)"}
$execute if data storage commerce:h p$(id)[15] run data remove storage commerce:h p$(id)[15]
