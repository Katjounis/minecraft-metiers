execute unless data storage commerce:t W[0] run return 0
scoreboard players set #dv c.t 8100000
execute store result score #di c.t run data get storage commerce:t W[0].id
scoreboard players operation #dv c.t += #di c.t
execute store result storage commerce:t W[0].v int 1 run scoreboard players get #dv c.t
function commerce:banque/dest_m with storage commerce:t W[0]
data remove storage commerce:t W[0]
function commerce:banque/dest_boucle
