scoreboard players set #q c.t 10000
execute if score #q c.t matches ..0 run return run data modify storage commerce:t msg set value "Rien à déposer."
execute if score @s c.ecus < #q c.t run return run data modify storage commerce:t msg set value "Pas assez d'Écus sur ton compte."
scoreboard players operation @s c.ecus -= #q c.t
scoreboard players operation @s c.ep += #q c.t
execute store result storage commerce:t m.v int 1 run scoreboard players get #q c.t
execute store result storage commerce:t hl.id int 1 run scoreboard players get @s m.id
data modify storage commerce:t hl.col set value "aqua"
function commerce:banque/hist_txt_dep
data modify storage commerce:t msg set value "Déposé sur ton épargne."
playsound minecraft:block.chain.place master @s ~ ~ ~ 0.8 1.4
