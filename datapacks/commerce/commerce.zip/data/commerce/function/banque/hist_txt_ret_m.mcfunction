$data modify storage commerce:t hl.txt set value "Épargne : $(v) Écus retirés"
function commerce:banque/hist with storage commerce:t hl
