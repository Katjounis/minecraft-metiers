function commerce:fmt/solde
data modify storage commerce:bq se set from storage commerce:t s.e
data modify storage commerce:bq sz set from storage commerce:t s.z
data modify storage commerce:bq sc set from storage commerce:t s.c
execute store result storage commerce:bq ep int 1 run scoreboard players get @s c.ep
execute store result storage commerce:bq o.id int 1 run scoreboard players get @s m.id
data modify storage commerce:bq hl set value [{text:"Aucune opération pour l’instant.",color:"dark_gray"}]
function commerce:banque/hist_lire with storage commerce:bq o
data modify storage commerce:bq msg set from storage commerce:t msg
data modify storage commerce:t msg set value ""
function commerce:banque/page_d with storage commerce:bq
