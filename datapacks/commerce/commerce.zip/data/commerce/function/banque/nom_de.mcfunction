$data modify storage commerce:bq o.nom set from storage commerce:j l[{id:$(id)}].nom
