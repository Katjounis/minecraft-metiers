$data modify storage commerce:t hl.txt set value "$(q) × $(n) vendus : +$(e),$(z)$(c) Écus"
function commerce:banque/hist with storage commerce:t hl
