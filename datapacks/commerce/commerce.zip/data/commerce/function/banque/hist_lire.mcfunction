$execute if data storage commerce:h p$(id)[0] run data modify storage commerce:bq hl set from storage commerce:h p$(id)
