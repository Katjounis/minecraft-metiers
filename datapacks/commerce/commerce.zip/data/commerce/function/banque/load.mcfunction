scoreboard objectives add c.ep dummy
scoreboard objectives add c.pend dummy
scoreboard objectives add c.dest dummy
scoreboard objectives add c.shid dummy
