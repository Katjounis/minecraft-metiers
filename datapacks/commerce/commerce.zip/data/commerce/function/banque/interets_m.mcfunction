scoreboard players set #x c.t 0
$execute store result score #x c.t run scoreboard players get $(nom) c.ep
scoreboard players operation #x c.t /= #50 c.g
scoreboard players set #z c.t 0
$execute if score $(nom) m.tbq matches 1 store result score #z c.t run scoreboard players get $(nom) c.ep
scoreboard players operation #z c.t /= #100 c.g
scoreboard players operation #x c.t += #z c.t
scoreboard players set #gn c.t 0
$execute store result score #gn c.t run scoreboard players get $(nom) c.gn
scoreboard players operation #y c.t = #x c.t
scoreboard players set #2 c.t 2
execute if score #gn c.t matches 2..3 run scoreboard players operation #y c.t /= #2 c.t
execute if score #gn c.t matches 2..3 run scoreboard players operation #x c.t += #y c.t
execute if score #gn c.t matches 4.. run scoreboard players operation #x c.t *= #2 c.t
execute if score #gn c.t matches ..3 if score #x c.t matches 5001.. run scoreboard players set #x c.t 5000
execute if score #gn c.t matches 4.. if score #x c.t matches 10001.. run scoreboard players set #x c.t 10000
execute if score #x c.t matches ..0 run return 0
$scoreboard players operation $(nom) c.ep += #x c.t
execute store result storage commerce:t m.v int 1 run scoreboard players get #x c.t
$data modify storage commerce:t hl.id set value $(id)
data modify storage commerce:t hl.col set value "aqua"
function commerce:banque/hist_txt_int
