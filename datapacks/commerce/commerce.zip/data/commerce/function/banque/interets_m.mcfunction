scoreboard players set #x c.t 0
$execute store result score #x c.t run scoreboard players get $(nom) c.ep
scoreboard players operation #x c.t /= #50 c.g
execute if score #x c.t matches 5001.. run scoreboard players set #x c.t 5000
execute if score #x c.t matches ..0 run return 0
$scoreboard players operation $(nom) c.ep += #x c.t
execute store result storage commerce:t m.v int 1 run scoreboard players get #x c.t
$data modify storage commerce:t hl.id set value $(id)
data modify storage commerce:t hl.col set value "aqua"
function commerce:banque/hist_txt_int
