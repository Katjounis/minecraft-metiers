execute unless data storage commerce:t W[0] run return 0
function commerce:banque/interets_m with storage commerce:t W[0]
data remove storage commerce:t W[0]
function commerce:banque/interets_boucle
