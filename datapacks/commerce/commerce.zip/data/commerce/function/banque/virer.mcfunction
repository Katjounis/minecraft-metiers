scoreboard players operation #q c.t = #v c.t
scoreboard players operation #q c.t *= #-1 c.g
scoreboard players set @s c.pend 0
execute if score @s c.ecus < #q c.t run return run data modify storage commerce:t msg set value "Pas assez d'Écus pour ce virement."
execute store result storage commerce:t o.id int 1 run scoreboard players get @s c.dest
data modify storage commerce:t o.nom set value ""
function commerce:banque/nom_t with storage commerce:t o
execute if data storage commerce:t o{nom:""} run return run data modify storage commerce:t msg set value "Joueur introuvable."
scoreboard players operation @s c.ecus -= #q c.t
execute store result storage commerce:t o.q int 1 run scoreboard players get #q c.t
function commerce:banque/virer_m with storage commerce:t o
data modify storage commerce:t m.nom set from storage commerce:t o.nom
execute store result storage commerce:t m.v int 1 run scoreboard players get #q c.t
execute store result storage commerce:t hl.id int 1 run scoreboard players get @s m.id
data modify storage commerce:t hl.col set value "red"
function commerce:banque/hist_txt_vir_env
function commerce:joueur/nom_moi
data modify storage commerce:t m.nom set from storage commerce:t moi
execute store result storage commerce:t hl.id int 1 run scoreboard players get @s c.dest
data modify storage commerce:t hl.col set value "green"
function commerce:banque/hist_txt_vir_rec
data modify storage commerce:t msg set value "Virement envoyé."
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
