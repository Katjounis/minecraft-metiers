$scoreboard players add $(nom) c.ecus $(q)
$tellraw @a[name=$(nom)] [{text:"[Commerce] ",color:"gold"},{selector:"@s",color:"white"},{text:" t’envoie $(q) Écus.",color:"green"}]
