$scoreboard players add $(nom) c.ecus $(q)
$scoreboard players add $(nom) c.a_com $(q)
$tellraw @a[name=$(nom)] [{text:"[Commerce] ",color:"gold"},{selector:"@s",color:"white"},{text:" t’envoie $(q) Écus.",color:"green"}]
