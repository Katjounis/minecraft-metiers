$execute if score @s m.id matches $(id) run return 0
$data modify storage commerce:bq D append value {text:"$(nom)",color:"yellow",underlined:true,click_event:{action:"run_command",command:"trigger commerce set $(v)"},hover_event:{action:"show_text",value:"Envoyer des Écus à $(nom)"}}
data modify storage commerce:bq D append value {text:"     "}
