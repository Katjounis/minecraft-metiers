scoreboard objectives remove c.ecus
scoreboard objectives remove c.cts
scoreboard objectives remove c.deb
scoreboard objectives remove c.cmpt
scoreboard objectives remove c.ser
scoreboard objectives remove c.own
scoreboard objectives remove c.nom
scoreboard objectives remove c.init
scoreboard objectives remove c.vu
scoreboard objectives remove c.tv
scoreboard objectives remove c.ta
scoreboard objectives remove c.ncr
scoreboard objectives remove c.pp_b
scoreboard objectives remove c.pp_f
scoreboard objectives remove c.pp_m
scoreboard objectives remove c.pp_c
scoreboard objectives remove c.pp_p
scoreboard objectives remove c.pp_e
scoreboard objectives remove c.pp_n
scoreboard objectives remove c.pp_x
scoreboard objectives remove c.pp_t
scoreboard objectives remove c.pp_k
scoreboard objectives remove c.dd_b
scoreboard objectives remove c.dd_f
scoreboard objectives remove c.dd_m
scoreboard objectives remove c.dd_c
scoreboard objectives remove c.dd_p
scoreboard objectives remove c.dd_e
scoreboard objectives remove c.dd_n
scoreboard objectives remove c.dd_x
scoreboard objectives remove c.dd_t
scoreboard objectives remove c.dd_k
scoreboard objectives remove c.dall
scoreboard objectives remove c.wd
scoreboard objectives remove c.wk
scoreboard objectives remove c.bk
scoreboard objectives remove c.init2
scoreboard objectives remove c.p
scoreboard objectives remove c.h
scoreboard objectives remove c.vs
scoreboard objectives remove c.as
scoreboard objectives remove c.ev
scoreboard objectives remove c.x
scoreboard objectives remove c.jv
scoreboard objectives remove c.ja
scoreboard objectives remove c.t
scoreboard objectives remove c.g
scoreboard objectives remove commerce
scoreboard objectives remove c.oeuf
scoreboard objectives remove c.craft
kill @e[type=minecraft:interaction,tag=commerce.clic]
data modify storage commerce:g evtxt set value ""
function commerce:prive/desinstaller
function commerce:spawner/desinstaller
tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Commerce désinstallé (les comptoirs posés restent des villageois). Retire commerce.zip puis redémarre.",color:"gold",bold:false,italic:false}]
