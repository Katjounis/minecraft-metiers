$tellraw @s [{"text":" · $(nom) ","color":"white"},{"text":"$(v) Écus","color":"yellow"},{"text":"  solde $(s)  tick $(t)","color":"gray"}]
