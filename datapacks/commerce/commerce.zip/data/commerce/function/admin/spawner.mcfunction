function commerce:spawner/donner {nom:"Zombie",m:9,v:0,q:0,p:0,c:0}
tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Spawner de zombie donné (admin).",color:"gold",bold:false,italic:false}]
