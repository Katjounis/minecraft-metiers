tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Derniers mouvements d'Écus non enregistrés (joueur, montant, solde après, heure de jeu) :",color:"gold",bold:false,italic:false}]
data modify storage commerce:t W set from storage commerce:journal anomalies
scoreboard players set #jn c.t 0
function commerce:admin/journal_boucle
