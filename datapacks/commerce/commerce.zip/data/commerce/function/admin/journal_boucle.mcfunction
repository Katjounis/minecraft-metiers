execute unless data storage commerce:t W[0] run return 0
execute if score #jn c.t matches 10.. run return 0
function commerce:admin/journal_m with storage commerce:t W[0]
data remove storage commerce:t W[0]
scoreboard players add #jn c.t 1
function commerce:admin/journal_boucle
