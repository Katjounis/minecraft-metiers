scoreboard players add @s c.ecus 10000
scoreboard players add @s c.a_com 10000
tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"+10 000 Écus (admin).",color:"gold",bold:false,italic:false}]
