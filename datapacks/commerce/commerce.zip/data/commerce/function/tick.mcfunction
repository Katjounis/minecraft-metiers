scoreboard players enable @a commerce
execute as @a[scores={commerce=1..}] at @s run function commerce:trigger/entree
execute as @e[type=minecraft:villager,tag=commerce.nouveau] at @s run function commerce:comptoir/pose
scoreboard players set @a[scores={c.oeuf=1..}] c.oeuf 0
execute if entity @a run scoreboard players add #t c.g 1
execute if score #t c.g matches 20.. run function commerce:seconde
