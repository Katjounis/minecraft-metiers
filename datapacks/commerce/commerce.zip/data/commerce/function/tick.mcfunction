scoreboard players enable @a commerce
execute as @a[scores={commerce=1..}] at @s run function commerce:trigger/entree
execute as @e[type=minecraft:villager,tag=commerce.nouveau] at @s run function commerce:comptoir/pose
execute as @e[type=minecraft:interaction,tag=commerce.clic] if data entity @s interaction run function commerce:comptoir/clic_i
execute as @e[type=minecraft:interaction,tag=commerce.clic] if data entity @s attack run data remove entity @s attack
scoreboard players set @a[scores={c.oeuf=1..}] c.oeuf 0
execute as @a run function commerce:hud/joueur
function commerce:spawner/tick
scoreboard players add #pt c.g 1
execute if score #pt c.g matches 2.. run function commerce:prive/tick
execute if entity @a run scoreboard players add #t c.g 1
execute if score #t c.g matches 20.. run function commerce:seconde
