function commerce:fmt/solde
data modify storage commerce:pf se set from storage commerce:t s.e
data modify storage commerce:pf sz set from storage commerce:t s.z
data modify storage commerce:pf sc set from storage commerce:t s.c
execute store result storage commerce:pf ep int 1 run scoreboard players get @s c.ep
execute store result storage commerce:pf tv int 1 run scoreboard players get @s c.tv
execute store result storage commerce:pf ta int 1 run scoreboard players get @s c.ta
data modify storage commerce:pf hr set value 0
execute store result storage commerce:pf hr int 1 run scoreboard players get @s hr.tot
scoreboard players set #tl c.t 0
data modify storage commerce:pf b set value 0
execute store result storage commerce:pf b int 1 run scoreboard players get @s m.b_lvl
data modify storage commerce:pf sb set value ""
execute if score @s m.b_pr matches 1 run data modify storage commerce:pf sb set value " ★"
execute if score @s m.b_pr matches 2 run data modify storage commerce:pf sb set value " ★★"
execute if score @s m.b_pr matches 3 run data modify storage commerce:pf sb set value " ★★★"
execute if score @s m.b_pr matches 4 run data modify storage commerce:pf sb set value " ★★★★"
execute if score @s m.b_pr matches 5 run data modify storage commerce:pf sb set value " ★★★★★"
scoreboard players operation #tl c.t += @s m.b_lvl
scoreboard players set #x c.t 0
scoreboard players operation #x c.t = @s m.b_pr
scoreboard players operation #x c.t *= #100 c.g
scoreboard players operation #tl c.t += #x c.t
data modify storage commerce:pf f set value 0
execute store result storage commerce:pf f int 1 run scoreboard players get @s m.f_lvl
data modify storage commerce:pf sf set value ""
execute if score @s m.f_pr matches 1 run data modify storage commerce:pf sf set value " ★"
execute if score @s m.f_pr matches 2 run data modify storage commerce:pf sf set value " ★★"
execute if score @s m.f_pr matches 3 run data modify storage commerce:pf sf set value " ★★★"
execute if score @s m.f_pr matches 4 run data modify storage commerce:pf sf set value " ★★★★"
execute if score @s m.f_pr matches 5 run data modify storage commerce:pf sf set value " ★★★★★"
scoreboard players operation #tl c.t += @s m.f_lvl
scoreboard players set #x c.t 0
scoreboard players operation #x c.t = @s m.f_pr
scoreboard players operation #x c.t *= #100 c.g
scoreboard players operation #tl c.t += #x c.t
data modify storage commerce:pf m set value 0
execute store result storage commerce:pf m int 1 run scoreboard players get @s m.m_lvl
data modify storage commerce:pf sm set value ""
execute if score @s m.m_pr matches 1 run data modify storage commerce:pf sm set value " ★"
execute if score @s m.m_pr matches 2 run data modify storage commerce:pf sm set value " ★★"
execute if score @s m.m_pr matches 3 run data modify storage commerce:pf sm set value " ★★★"
execute if score @s m.m_pr matches 4 run data modify storage commerce:pf sm set value " ★★★★"
execute if score @s m.m_pr matches 5 run data modify storage commerce:pf sm set value " ★★★★★"
scoreboard players operation #tl c.t += @s m.m_lvl
scoreboard players set #x c.t 0
scoreboard players operation #x c.t = @s m.m_pr
scoreboard players operation #x c.t *= #100 c.g
scoreboard players operation #tl c.t += #x c.t
data modify storage commerce:pf c set value 0
execute store result storage commerce:pf c int 1 run scoreboard players get @s m.c_lvl
data modify storage commerce:pf sc set value ""
execute if score @s m.c_pr matches 1 run data modify storage commerce:pf sc set value " ★"
execute if score @s m.c_pr matches 2 run data modify storage commerce:pf sc set value " ★★"
execute if score @s m.c_pr matches 3 run data modify storage commerce:pf sc set value " ★★★"
execute if score @s m.c_pr matches 4 run data modify storage commerce:pf sc set value " ★★★★"
execute if score @s m.c_pr matches 5 run data modify storage commerce:pf sc set value " ★★★★★"
scoreboard players operation #tl c.t += @s m.c_lvl
scoreboard players set #x c.t 0
scoreboard players operation #x c.t = @s m.c_pr
scoreboard players operation #x c.t *= #100 c.g
scoreboard players operation #tl c.t += #x c.t
data modify storage commerce:pf p set value 0
execute store result storage commerce:pf p int 1 run scoreboard players get @s m.p_lvl
data modify storage commerce:pf sp set value ""
execute if score @s m.p_pr matches 1 run data modify storage commerce:pf sp set value " ★"
execute if score @s m.p_pr matches 2 run data modify storage commerce:pf sp set value " ★★"
execute if score @s m.p_pr matches 3 run data modify storage commerce:pf sp set value " ★★★"
execute if score @s m.p_pr matches 4 run data modify storage commerce:pf sp set value " ★★★★"
execute if score @s m.p_pr matches 5 run data modify storage commerce:pf sp set value " ★★★★★"
scoreboard players operation #tl c.t += @s m.p_lvl
scoreboard players set #x c.t 0
scoreboard players operation #x c.t = @s m.p_pr
scoreboard players operation #x c.t *= #100 c.g
scoreboard players operation #tl c.t += #x c.t
data modify storage commerce:pf e set value 0
execute store result storage commerce:pf e int 1 run scoreboard players get @s m.e_lvl
data modify storage commerce:pf se set value ""
execute if score @s m.e_pr matches 1 run data modify storage commerce:pf se set value " ★"
execute if score @s m.e_pr matches 2 run data modify storage commerce:pf se set value " ★★"
execute if score @s m.e_pr matches 3 run data modify storage commerce:pf se set value " ★★★"
execute if score @s m.e_pr matches 4 run data modify storage commerce:pf se set value " ★★★★"
execute if score @s m.e_pr matches 5 run data modify storage commerce:pf se set value " ★★★★★"
scoreboard players operation #tl c.t += @s m.e_lvl
scoreboard players set #x c.t 0
scoreboard players operation #x c.t = @s m.e_pr
scoreboard players operation #x c.t *= #100 c.g
scoreboard players operation #tl c.t += #x c.t
data modify storage commerce:pf n set value 0
execute store result storage commerce:pf n int 1 run scoreboard players get @s m.n_lvl
data modify storage commerce:pf sn set value ""
execute if score @s m.n_pr matches 1 run data modify storage commerce:pf sn set value " ★"
execute if score @s m.n_pr matches 2 run data modify storage commerce:pf sn set value " ★★"
execute if score @s m.n_pr matches 3 run data modify storage commerce:pf sn set value " ★★★"
execute if score @s m.n_pr matches 4 run data modify storage commerce:pf sn set value " ★★★★"
execute if score @s m.n_pr matches 5 run data modify storage commerce:pf sn set value " ★★★★★"
scoreboard players operation #tl c.t += @s m.n_lvl
scoreboard players set #x c.t 0
scoreboard players operation #x c.t = @s m.n_pr
scoreboard players operation #x c.t *= #100 c.g
scoreboard players operation #tl c.t += #x c.t
data modify storage commerce:pf x set value 0
execute store result storage commerce:pf x int 1 run scoreboard players get @s m.x_lvl
data modify storage commerce:pf sx set value ""
execute if score @s m.x_pr matches 1 run data modify storage commerce:pf sx set value " ★"
execute if score @s m.x_pr matches 2 run data modify storage commerce:pf sx set value " ★★"
execute if score @s m.x_pr matches 3 run data modify storage commerce:pf sx set value " ★★★"
execute if score @s m.x_pr matches 4 run data modify storage commerce:pf sx set value " ★★★★"
execute if score @s m.x_pr matches 5 run data modify storage commerce:pf sx set value " ★★★★★"
scoreboard players operation #tl c.t += @s m.x_lvl
scoreboard players set #x c.t 0
scoreboard players operation #x c.t = @s m.x_pr
scoreboard players operation #x c.t *= #100 c.g
scoreboard players operation #tl c.t += #x c.t
data modify storage commerce:pf t set value 0
execute store result storage commerce:pf t int 1 run scoreboard players get @s m.t_lvl
data modify storage commerce:pf st set value ""
execute if score @s m.t_pr matches 1 run data modify storage commerce:pf st set value " ★"
execute if score @s m.t_pr matches 2 run data modify storage commerce:pf st set value " ★★"
execute if score @s m.t_pr matches 3 run data modify storage commerce:pf st set value " ★★★"
execute if score @s m.t_pr matches 4 run data modify storage commerce:pf st set value " ★★★★"
execute if score @s m.t_pr matches 5 run data modify storage commerce:pf st set value " ★★★★★"
scoreboard players operation #tl c.t += @s m.t_lvl
scoreboard players set #x c.t 0
scoreboard players operation #x c.t = @s m.t_pr
scoreboard players operation #x c.t *= #100 c.g
scoreboard players operation #tl c.t += #x c.t
data modify storage commerce:pf k set value 0
execute store result storage commerce:pf k int 1 run scoreboard players get @s m.k_lvl
data modify storage commerce:pf sk set value ""
execute if score @s m.k_pr matches 1 run data modify storage commerce:pf sk set value " ★"
execute if score @s m.k_pr matches 2 run data modify storage commerce:pf sk set value " ★★"
execute if score @s m.k_pr matches 3 run data modify storage commerce:pf sk set value " ★★★"
execute if score @s m.k_pr matches 4 run data modify storage commerce:pf sk set value " ★★★★"
execute if score @s m.k_pr matches 5 run data modify storage commerce:pf sk set value " ★★★★★"
scoreboard players operation #tl c.t += @s m.k_lvl
scoreboard players set #x c.t 0
scoreboard players operation #x c.t = @s m.k_pr
scoreboard players operation #x c.t *= #100 c.g
scoreboard players operation #tl c.t += #x c.t
execute store result storage commerce:pf tl int 1 run scoreboard players get #tl c.t
function commerce:joueur/nom_moi
data modify storage commerce:pf nom set from storage commerce:t moi
function commerce:serveur/profil_d with storage commerce:pf
