function commerce:serveur/guide_1
scoreboard players set @s c.gd 1
