scoreboard players operation #v c.t = @s commerce
scoreboard players set @s commerce 0
scoreboard players enable @s commerce
execute if score #v c.t matches 60 run return run function commerce:page/aide
execute unless score @s c.deb matches 1 run return run function commerce:page/verrou
execute if score #v c.t matches 1 run return run function commerce:page/accueil
execute if score #v c.t matches 9 run return run function commerce:page/marche
execute if score #v c.t matches 20 run return run function commerce:page/bourse
execute if score #v c.t matches 21 run return run function commerce:page/fortunes
execute if score #v c.t matches 22 run return run function commerce:page/cristaux
execute if score #v c.t matches 50 run return run function commerce:comptoir/deplacer
execute if score #v c.t matches 11 run return run function commerce:page/cat_1
execute if score #v c.t matches 12 run return run function commerce:page/cat_2
execute if score #v c.t matches 13 run return run function commerce:page/cat_3
execute if score #v c.t matches 14 run return run function commerce:page/cat_4
execute if score #v c.t matches 15 run return run function commerce:page/cat_5
execute if score #v c.t matches 16 run return run function commerce:page/cat_6
execute if score #v c.t matches 17 run return run function commerce:page/cat_7
execute if score #v c.t matches 18 run return run function commerce:page/cat_8
execute if score #v c.t matches 19 run return run function commerce:page/cat_9
execute if score #v c.t matches 401 run return run function commerce:page/cristal_b
execute if score #v c.t matches 402 run return run function commerce:page/cristal_f
execute if score #v c.t matches 403 run return run function commerce:page/cristal_m
execute if score #v c.t matches 404 run return run function commerce:page/cristal_c
execute if score #v c.t matches 405 run return run function commerce:page/cristal_p
execute if score #v c.t matches 406 run return run function commerce:page/cristal_e
execute if score #v c.t matches 407 run return run function commerce:page/cristal_n
execute if score #v c.t matches 408 run return run function commerce:page/cristal_x
execute if score #v c.t matches 409 run return run function commerce:page/cristal_t
execute if score #v c.t matches 10001..10133 run return run function commerce:page/item_depuis
execute if score #v c.t matches 1000000..3999999 run return run function commerce:op/entree
