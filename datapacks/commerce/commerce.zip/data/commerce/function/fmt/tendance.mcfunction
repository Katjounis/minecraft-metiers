data modify storage commerce:t tr set value "▬"
data modify storage commerce:t trc set value "gray"
execute unless score #h c.t matches 1.. run return 0
scoreboard players operation #cu c.t = #u0 c.t
scoreboard players operation #cu c.t *= #100 c.g
scoreboard players operation #hu c.t = #h c.t
scoreboard players operation #hu c.t *= #100 c.g
scoreboard players operation #hu c.t += #h c.t
scoreboard players operation #hu c.t += #h c.t
scoreboard players operation #hu c.t += #h c.t
execute if score #cu c.t > #hu c.t run data modify storage commerce:t tr set value "▲"
execute if score #cu c.t > #hu c.t run data modify storage commerce:t trc set value "green"
scoreboard players operation #hl c.t = #h c.t
scoreboard players operation #hl c.t *= #100 c.g
scoreboard players operation #hl c.t -= #h c.t
scoreboard players operation #hl c.t -= #h c.t
scoreboard players operation #hl c.t -= #h c.t
execute if score #cu c.t < #hl c.t run data modify storage commerce:t tr set value "▼"
execute if score #cu c.t < #hl c.t run data modify storage commerce:t trc set value "red"
