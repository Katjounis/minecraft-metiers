scoreboard players operation #fe c.t = #x c.t
scoreboard players operation #fe c.t /= #100 c.g
scoreboard players operation #fc c.t = #x c.t
scoreboard players operation #fc c.t %= #100 c.g
execute store result storage commerce:t f.e int 1 run scoreboard players get #fe c.t
execute store result storage commerce:t f.c int 1 run scoreboard players get #fc c.t
data modify storage commerce:t f.z set value ""
execute if score #fc c.t matches 0..9 run data modify storage commerce:t f.z set value "0"
