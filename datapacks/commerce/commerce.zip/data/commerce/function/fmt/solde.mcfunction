execute store result storage commerce:t s.e int 1 run scoreboard players get @s c.ecus
execute store result storage commerce:t s.c int 1 run scoreboard players get @s c.cts
data modify storage commerce:t s.z set value ""
execute if score @s c.cts matches 0..9 run data modify storage commerce:t s.z set value "0"
