scoreboard players operation #i c.t = #best c.t
function commerce:item/charger
function commerce:item/marquer with storage commerce:t it
data modify storage commerce:r ta3n set from storage commerce:t it.n
execute store result storage commerce:r ta3q int 1 run scoreboard players get #m c.t
