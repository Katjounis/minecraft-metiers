execute unless score #cobblestone c.x matches 1 if score #cobblestone c.vs > #m c.t run scoreboard players set #best c.t 1
execute if score #best c.t matches 1 run scoreboard players operation #m c.t = #cobblestone c.vs
execute unless score #cobbled_deepslate c.x matches 1 if score #cobbled_deepslate c.vs > #m c.t run scoreboard players set #best c.t 2
execute if score #best c.t matches 2 run scoreboard players operation #m c.t = #cobbled_deepslate c.vs
execute unless score #stone c.x matches 1 if score #stone c.vs > #m c.t run scoreboard players set #best c.t 3
execute if score #best c.t matches 3 run scoreboard players operation #m c.t = #stone c.vs
execute unless score #deepslate c.x matches 1 if score #deepslate c.vs > #m c.t run scoreboard players set #best c.t 4
execute if score #best c.t matches 4 run scoreboard players operation #m c.t = #deepslate c.vs
execute unless score #andesite c.x matches 1 if score #andesite c.vs > #m c.t run scoreboard players set #best c.t 5
execute if score #best c.t matches 5 run scoreboard players operation #m c.t = #andesite c.vs
execute unless score #diorite c.x matches 1 if score #diorite c.vs > #m c.t run scoreboard players set #best c.t 6
execute if score #best c.t matches 6 run scoreboard players operation #m c.t = #diorite c.vs
execute unless score #granite c.x matches 1 if score #granite c.vs > #m c.t run scoreboard players set #best c.t 7
execute if score #best c.t matches 7 run scoreboard players operation #m c.t = #granite c.vs
execute unless score #tuff c.x matches 1 if score #tuff c.vs > #m c.t run scoreboard players set #best c.t 8
execute if score #best c.t matches 8 run scoreboard players operation #m c.t = #tuff c.vs
execute unless score #calcite c.x matches 1 if score #calcite c.vs > #m c.t run scoreboard players set #best c.t 9
execute if score #best c.t matches 9 run scoreboard players operation #m c.t = #calcite c.vs
execute unless score #blackstone c.x matches 1 if score #blackstone c.vs > #m c.t run scoreboard players set #best c.t 10
execute if score #best c.t matches 10 run scoreboard players operation #m c.t = #blackstone c.vs
execute unless score #basalt c.x matches 1 if score #basalt c.vs > #m c.t run scoreboard players set #best c.t 11
execute if score #best c.t matches 11 run scoreboard players operation #m c.t = #basalt c.vs
execute unless score #netherrack c.x matches 1 if score #netherrack c.vs > #m c.t run scoreboard players set #best c.t 12
execute if score #best c.t matches 12 run scoreboard players operation #m c.t = #netherrack c.vs
execute unless score #end_stone c.x matches 1 if score #end_stone c.vs > #m c.t run scoreboard players set #best c.t 13
execute if score #best c.t matches 13 run scoreboard players operation #m c.t = #end_stone c.vs
execute unless score #obsidian c.x matches 1 if score #obsidian c.vs > #m c.t run scoreboard players set #best c.t 14
execute if score #best c.t matches 14 run scoreboard players operation #m c.t = #obsidian c.vs
execute unless score #dirt c.x matches 1 if score #dirt c.vs > #m c.t run scoreboard players set #best c.t 15
execute if score #best c.t matches 15 run scoreboard players operation #m c.t = #dirt c.vs
execute unless score #sand c.x matches 1 if score #sand c.vs > #m c.t run scoreboard players set #best c.t 16
execute if score #best c.t matches 16 run scoreboard players operation #m c.t = #sand c.vs
execute unless score #red_sand c.x matches 1 if score #red_sand c.vs > #m c.t run scoreboard players set #best c.t 17
execute if score #best c.t matches 17 run scoreboard players operation #m c.t = #red_sand c.vs
execute unless score #gravel c.x matches 1 if score #gravel c.vs > #m c.t run scoreboard players set #best c.t 18
execute if score #best c.t matches 18 run scoreboard players operation #m c.t = #gravel c.vs
execute unless score #clay_ball c.x matches 1 if score #clay_ball c.vs > #m c.t run scoreboard players set #best c.t 19
execute if score #best c.t matches 19 run scoreboard players operation #m c.t = #clay_ball c.vs
execute unless score #glass c.x matches 1 if score #glass c.vs > #m c.t run scoreboard players set #best c.t 20
execute if score #best c.t matches 20 run scoreboard players operation #m c.t = #glass c.vs
execute unless score #stone_bricks c.x matches 1 if score #stone_bricks c.vs > #m c.t run scoreboard players set #best c.t 21
execute if score #best c.t matches 21 run scoreboard players operation #m c.t = #stone_bricks c.vs
execute unless score #smooth_stone c.x matches 1 if score #smooth_stone c.vs > #m c.t run scoreboard players set #best c.t 22
execute if score #best c.t matches 22 run scoreboard players operation #m c.t = #smooth_stone c.vs
execute unless score #sandstone c.x matches 1 if score #sandstone c.vs > #m c.t run scoreboard players set #best c.t 23
execute if score #best c.t matches 23 run scoreboard players operation #m c.t = #sandstone c.vs
execute unless score #bricks c.x matches 1 if score #bricks c.vs > #m c.t run scoreboard players set #best c.t 24
execute if score #best c.t matches 24 run scoreboard players operation #m c.t = #bricks c.vs
execute unless score #terracotta c.x matches 1 if score #terracotta c.vs > #m c.t run scoreboard players set #best c.t 25
execute if score #best c.t matches 25 run scoreboard players operation #m c.t = #terracotta c.vs
execute unless score #white_concrete c.x matches 1 if score #white_concrete c.vs > #m c.t run scoreboard players set #best c.t 26
execute if score #best c.t matches 26 run scoreboard players operation #m c.t = #white_concrete c.vs
execute unless score #oak_log c.x matches 1 if score #oak_log c.vs > #m c.t run scoreboard players set #best c.t 27
execute if score #best c.t matches 27 run scoreboard players operation #m c.t = #oak_log c.vs
execute unless score #spruce_log c.x matches 1 if score #spruce_log c.vs > #m c.t run scoreboard players set #best c.t 28
execute if score #best c.t matches 28 run scoreboard players operation #m c.t = #spruce_log c.vs
execute unless score #birch_log c.x matches 1 if score #birch_log c.vs > #m c.t run scoreboard players set #best c.t 29
execute if score #best c.t matches 29 run scoreboard players operation #m c.t = #birch_log c.vs
execute unless score #jungle_log c.x matches 1 if score #jungle_log c.vs > #m c.t run scoreboard players set #best c.t 30
execute if score #best c.t matches 30 run scoreboard players operation #m c.t = #jungle_log c.vs
execute unless score #acacia_log c.x matches 1 if score #acacia_log c.vs > #m c.t run scoreboard players set #best c.t 31
execute if score #best c.t matches 31 run scoreboard players operation #m c.t = #acacia_log c.vs
execute unless score #dark_oak_log c.x matches 1 if score #dark_oak_log c.vs > #m c.t run scoreboard players set #best c.t 32
execute if score #best c.t matches 32 run scoreboard players operation #m c.t = #dark_oak_log c.vs
execute unless score #mangrove_log c.x matches 1 if score #mangrove_log c.vs > #m c.t run scoreboard players set #best c.t 33
execute if score #best c.t matches 33 run scoreboard players operation #m c.t = #mangrove_log c.vs
execute unless score #cherry_log c.x matches 1 if score #cherry_log c.vs > #m c.t run scoreboard players set #best c.t 34
execute if score #best c.t matches 34 run scoreboard players operation #m c.t = #cherry_log c.vs
execute unless score #pale_oak_log c.x matches 1 if score #pale_oak_log c.vs > #m c.t run scoreboard players set #best c.t 35
execute if score #best c.t matches 35 run scoreboard players operation #m c.t = #pale_oak_log c.vs
execute unless score #crimson_stem c.x matches 1 if score #crimson_stem c.vs > #m c.t run scoreboard players set #best c.t 36
execute if score #best c.t matches 36 run scoreboard players operation #m c.t = #crimson_stem c.vs
execute unless score #warped_stem c.x matches 1 if score #warped_stem c.vs > #m c.t run scoreboard players set #best c.t 37
execute if score #best c.t matches 37 run scoreboard players operation #m c.t = #warped_stem c.vs
execute unless score #bamboo_block c.x matches 1 if score #bamboo_block c.vs > #m c.t run scoreboard players set #best c.t 38
execute if score #best c.t matches 38 run scoreboard players operation #m c.t = #bamboo_block c.vs
execute unless score #apple c.x matches 1 if score #apple c.vs > #m c.t run scoreboard players set #best c.t 39
execute if score #best c.t matches 39 run scoreboard players operation #m c.t = #apple c.vs
execute unless score #oak_sapling c.x matches 1 if score #oak_sapling c.vs > #m c.t run scoreboard players set #best c.t 40
execute if score #best c.t matches 40 run scoreboard players operation #m c.t = #oak_sapling c.vs
execute unless score #coal c.x matches 1 if score #coal c.vs > #m c.t run scoreboard players set #best c.t 41
execute if score #best c.t matches 41 run scoreboard players operation #m c.t = #coal c.vs
execute unless score #raw_copper c.x matches 1 if score #raw_copper c.vs > #m c.t run scoreboard players set #best c.t 42
execute if score #best c.t matches 42 run scoreboard players operation #m c.t = #raw_copper c.vs
execute unless score #copper_ingot c.x matches 1 if score #copper_ingot c.vs > #m c.t run scoreboard players set #best c.t 43
execute if score #best c.t matches 43 run scoreboard players operation #m c.t = #copper_ingot c.vs
execute unless score #raw_iron c.x matches 1 if score #raw_iron c.vs > #m c.t run scoreboard players set #best c.t 44
execute if score #best c.t matches 44 run scoreboard players operation #m c.t = #raw_iron c.vs
execute unless score #iron_ingot c.x matches 1 if score #iron_ingot c.vs > #m c.t run scoreboard players set #best c.t 45
execute if score #best c.t matches 45 run scoreboard players operation #m c.t = #iron_ingot c.vs
execute unless score #raw_gold c.x matches 1 if score #raw_gold c.vs > #m c.t run scoreboard players set #best c.t 46
execute if score #best c.t matches 46 run scoreboard players operation #m c.t = #raw_gold c.vs
execute unless score #gold_ingot c.x matches 1 if score #gold_ingot c.vs > #m c.t run scoreboard players set #best c.t 47
execute if score #best c.t matches 47 run scoreboard players operation #m c.t = #gold_ingot c.vs
execute unless score #redstone c.x matches 1 if score #redstone c.vs > #m c.t run scoreboard players set #best c.t 48
execute if score #best c.t matches 48 run scoreboard players operation #m c.t = #redstone c.vs
execute unless score #lapis_lazuli c.x matches 1 if score #lapis_lazuli c.vs > #m c.t run scoreboard players set #best c.t 49
execute if score #best c.t matches 49 run scoreboard players operation #m c.t = #lapis_lazuli c.vs
execute unless score #quartz c.x matches 1 if score #quartz c.vs > #m c.t run scoreboard players set #best c.t 50
execute if score #best c.t matches 50 run scoreboard players operation #m c.t = #quartz c.vs
execute unless score #amethyst_shard c.x matches 1 if score #amethyst_shard c.vs > #m c.t run scoreboard players set #best c.t 51
execute if score #best c.t matches 51 run scoreboard players operation #m c.t = #amethyst_shard c.vs
execute unless score #glowstone_dust c.x matches 1 if score #glowstone_dust c.vs > #m c.t run scoreboard players set #best c.t 52
execute if score #best c.t matches 52 run scoreboard players operation #m c.t = #glowstone_dust c.vs
execute unless score #flint c.x matches 1 if score #flint c.vs > #m c.t run scoreboard players set #best c.t 53
execute if score #best c.t matches 53 run scoreboard players operation #m c.t = #flint c.vs
execute unless score #wheat c.x matches 1 if score #wheat c.vs > #m c.t run scoreboard players set #best c.t 54
execute if score #best c.t matches 54 run scoreboard players operation #m c.t = #wheat c.vs
execute unless score #wheat_seeds c.x matches 1 if score #wheat_seeds c.vs > #m c.t run scoreboard players set #best c.t 55
execute if score #best c.t matches 55 run scoreboard players operation #m c.t = #wheat_seeds c.vs
execute unless score #carrot c.x matches 1 if score #carrot c.vs > #m c.t run scoreboard players set #best c.t 56
execute if score #best c.t matches 56 run scoreboard players operation #m c.t = #carrot c.vs
execute unless score #potato c.x matches 1 if score #potato c.vs > #m c.t run scoreboard players set #best c.t 57
execute if score #best c.t matches 57 run scoreboard players operation #m c.t = #potato c.vs
execute unless score #beetroot c.x matches 1 if score #beetroot c.vs > #m c.t run scoreboard players set #best c.t 58
execute if score #best c.t matches 58 run scoreboard players operation #m c.t = #beetroot c.vs
execute unless score #melon_slice c.x matches 1 if score #melon_slice c.vs > #m c.t run scoreboard players set #best c.t 59
execute if score #best c.t matches 59 run scoreboard players operation #m c.t = #melon_slice c.vs
execute unless score #pumpkin c.x matches 1 if score #pumpkin c.vs > #m c.t run scoreboard players set #best c.t 60
execute if score #best c.t matches 60 run scoreboard players operation #m c.t = #pumpkin c.vs
execute unless score #sugar_cane c.x matches 1 if score #sugar_cane c.vs > #m c.t run scoreboard players set #best c.t 61
execute if score #best c.t matches 61 run scoreboard players operation #m c.t = #sugar_cane c.vs
execute unless score #cocoa_beans c.x matches 1 if score #cocoa_beans c.vs > #m c.t run scoreboard players set #best c.t 62
execute if score #best c.t matches 62 run scoreboard players operation #m c.t = #cocoa_beans c.vs
execute unless score #nether_wart c.x matches 1 if score #nether_wart c.vs > #m c.t run scoreboard players set #best c.t 63
execute if score #best c.t matches 63 run scoreboard players operation #m c.t = #nether_wart c.vs
execute unless score #sweet_berries c.x matches 1 if score #sweet_berries c.vs > #m c.t run scoreboard players set #best c.t 64
execute if score #best c.t matches 64 run scoreboard players operation #m c.t = #sweet_berries c.vs
execute unless score #cactus c.x matches 1 if score #cactus c.vs > #m c.t run scoreboard players set #best c.t 65
execute if score #best c.t matches 65 run scoreboard players operation #m c.t = #cactus c.vs
execute unless score #bamboo c.x matches 1 if score #bamboo c.vs > #m c.t run scoreboard players set #best c.t 66
execute if score #best c.t matches 66 run scoreboard players operation #m c.t = #bamboo c.vs
execute unless score #white_wool c.x matches 1 if score #white_wool c.vs > #m c.t run scoreboard players set #best c.t 67
execute if score #best c.t matches 67 run scoreboard players operation #m c.t = #white_wool c.vs
execute unless score #leather c.x matches 1 if score #leather c.vs > #m c.t run scoreboard players set #best c.t 68
execute if score #best c.t matches 68 run scoreboard players operation #m c.t = #leather c.vs
execute unless score #egg c.x matches 1 if score #egg c.vs > #m c.t run scoreboard players set #best c.t 69
execute if score #best c.t matches 69 run scoreboard players operation #m c.t = #egg c.vs
execute unless score #feather c.x matches 1 if score #feather c.vs > #m c.t run scoreboard players set #best c.t 70
execute if score #best c.t matches 70 run scoreboard players operation #m c.t = #feather c.vs
execute unless score #beef c.x matches 1 if score #beef c.vs > #m c.t run scoreboard players set #best c.t 71
execute if score #best c.t matches 71 run scoreboard players operation #m c.t = #beef c.vs
execute unless score #porkchop c.x matches 1 if score #porkchop c.vs > #m c.t run scoreboard players set #best c.t 72
execute if score #best c.t matches 72 run scoreboard players operation #m c.t = #porkchop c.vs
execute unless score #chicken c.x matches 1 if score #chicken c.vs > #m c.t run scoreboard players set #best c.t 73
execute if score #best c.t matches 73 run scoreboard players operation #m c.t = #chicken c.vs
execute unless score #mutton c.x matches 1 if score #mutton c.vs > #m c.t run scoreboard players set #best c.t 74
execute if score #best c.t matches 74 run scoreboard players operation #m c.t = #mutton c.vs
execute unless score #rabbit c.x matches 1 if score #rabbit c.vs > #m c.t run scoreboard players set #best c.t 75
execute if score #best c.t matches 75 run scoreboard players operation #m c.t = #rabbit c.vs
execute unless score #honeycomb c.x matches 1 if score #honeycomb c.vs > #m c.t run scoreboard players set #best c.t 76
execute if score #best c.t matches 76 run scoreboard players operation #m c.t = #honeycomb c.vs
execute unless score #rotten_flesh c.x matches 1 if score #rotten_flesh c.vs > #m c.t run scoreboard players set #best c.t 77
execute if score #best c.t matches 77 run scoreboard players operation #m c.t = #rotten_flesh c.vs
execute unless score #bone c.x matches 1 if score #bone c.vs > #m c.t run scoreboard players set #best c.t 78
execute if score #best c.t matches 78 run scoreboard players operation #m c.t = #bone c.vs
execute unless score #string c.x matches 1 if score #string c.vs > #m c.t run scoreboard players set #best c.t 79
execute if score #best c.t matches 79 run scoreboard players operation #m c.t = #string c.vs
execute unless score #gunpowder c.x matches 1 if score #gunpowder c.vs > #m c.t run scoreboard players set #best c.t 80
execute if score #best c.t matches 80 run scoreboard players operation #m c.t = #gunpowder c.vs
execute unless score #spider_eye c.x matches 1 if score #spider_eye c.vs > #m c.t run scoreboard players set #best c.t 81
execute if score #best c.t matches 81 run scoreboard players operation #m c.t = #spider_eye c.vs
execute unless score #slime_ball c.x matches 1 if score #slime_ball c.vs > #m c.t run scoreboard players set #best c.t 82
execute if score #best c.t matches 82 run scoreboard players operation #m c.t = #slime_ball c.vs
execute unless score #ender_pearl c.x matches 1 if score #ender_pearl c.vs > #m c.t run scoreboard players set #best c.t 83
execute if score #best c.t matches 83 run scoreboard players operation #m c.t = #ender_pearl c.vs
execute unless score #blaze_rod c.x matches 1 if score #blaze_rod c.vs > #m c.t run scoreboard players set #best c.t 84
execute if score #best c.t matches 84 run scoreboard players operation #m c.t = #blaze_rod c.vs
execute unless score #phantom_membrane c.x matches 1 if score #phantom_membrane c.vs > #m c.t run scoreboard players set #best c.t 85
execute if score #best c.t matches 85 run scoreboard players operation #m c.t = #phantom_membrane c.vs
execute unless score #cod c.x matches 1 if score #cod c.vs > #m c.t run scoreboard players set #best c.t 86
execute if score #best c.t matches 86 run scoreboard players operation #m c.t = #cod c.vs
execute unless score #salmon c.x matches 1 if score #salmon c.vs > #m c.t run scoreboard players set #best c.t 87
execute if score #best c.t matches 87 run scoreboard players operation #m c.t = #salmon c.vs
execute unless score #tropical_fish c.x matches 1 if score #tropical_fish c.vs > #m c.t run scoreboard players set #best c.t 88
execute if score #best c.t matches 88 run scoreboard players operation #m c.t = #tropical_fish c.vs
execute unless score #pufferfish c.x matches 1 if score #pufferfish c.vs > #m c.t run scoreboard players set #best c.t 89
execute if score #best c.t matches 89 run scoreboard players operation #m c.t = #pufferfish c.vs
execute unless score #ink_sac c.x matches 1 if score #ink_sac c.vs > #m c.t run scoreboard players set #best c.t 90
execute if score #best c.t matches 90 run scoreboard players operation #m c.t = #ink_sac c.vs
execute unless score #glow_ink_sac c.x matches 1 if score #glow_ink_sac c.vs > #m c.t run scoreboard players set #best c.t 91
execute if score #best c.t matches 91 run scoreboard players operation #m c.t = #glow_ink_sac c.vs
execute unless score #prismarine_shard c.x matches 1 if score #prismarine_shard c.vs > #m c.t run scoreboard players set #best c.t 92
execute if score #best c.t matches 92 run scoreboard players operation #m c.t = #prismarine_shard c.vs
execute unless score #prismarine_crystals c.x matches 1 if score #prismarine_crystals c.vs > #m c.t run scoreboard players set #best c.t 93
execute if score #best c.t matches 93 run scoreboard players operation #m c.t = #prismarine_crystals c.vs
execute unless score #lily_pad c.x matches 1 if score #lily_pad c.vs > #m c.t run scoreboard players set #best c.t 94
execute if score #best c.t matches 94 run scoreboard players operation #m c.t = #lily_pad c.vs
execute unless score #kelp c.x matches 1 if score #kelp c.vs > #m c.t run scoreboard players set #best c.t 95
execute if score #best c.t matches 95 run scoreboard players operation #m c.t = #kelp c.vs
execute unless score #bread c.x matches 1 if score #bread c.vs > #m c.t run scoreboard players set #best c.t 96
execute if score #best c.t matches 96 run scoreboard players operation #m c.t = #bread c.vs
execute unless score #baked_potato c.x matches 1 if score #baked_potato c.vs > #m c.t run scoreboard players set #best c.t 97
execute if score #best c.t matches 97 run scoreboard players operation #m c.t = #baked_potato c.vs
execute unless score #pumpkin_pie c.x matches 1 if score #pumpkin_pie c.vs > #m c.t run scoreboard players set #best c.t 98
execute if score #best c.t matches 98 run scoreboard players operation #m c.t = #pumpkin_pie c.vs
execute unless score #cookie c.x matches 1 if score #cookie c.vs > #m c.t run scoreboard players set #best c.t 99
execute if score #best c.t matches 99 run scoreboard players operation #m c.t = #cookie c.vs
execute unless score #cooked_beef c.x matches 1 if score #cooked_beef c.vs > #m c.t run scoreboard players set #best c.t 100
execute if score #best c.t matches 100 run scoreboard players operation #m c.t = #cooked_beef c.vs
execute unless score #cooked_porkchop c.x matches 1 if score #cooked_porkchop c.vs > #m c.t run scoreboard players set #best c.t 101
execute if score #best c.t matches 101 run scoreboard players operation #m c.t = #cooked_porkchop c.vs
execute unless score #cooked_chicken c.x matches 1 if score #cooked_chicken c.vs > #m c.t run scoreboard players set #best c.t 102
execute if score #best c.t matches 102 run scoreboard players operation #m c.t = #cooked_chicken c.vs
execute unless score #cooked_salmon c.x matches 1 if score #cooked_salmon c.vs > #m c.t run scoreboard players set #best c.t 103
execute if score #best c.t matches 103 run scoreboard players operation #m c.t = #cooked_salmon c.vs
execute unless score #golden_carrot c.x matches 1 if score #golden_carrot c.vs > #m c.t run scoreboard players set #best c.t 104
execute if score #best c.t matches 104 run scoreboard players operation #m c.t = #golden_carrot c.vs
execute unless score #golden_apple c.x matches 1 if score #golden_apple c.vs > #m c.t run scoreboard players set #best c.t 105
execute if score #best c.t matches 105 run scoreboard players operation #m c.t = #golden_apple c.vs
execute unless score #torch c.x matches 1 if score #torch c.vs > #m c.t run scoreboard players set #best c.t 106
execute if score #best c.t matches 106 run scoreboard players operation #m c.t = #torch c.vs
execute unless score #lantern c.x matches 1 if score #lantern c.vs > #m c.t run scoreboard players set #best c.t 107
execute if score #best c.t matches 107 run scoreboard players operation #m c.t = #lantern c.vs
execute unless score #chest c.x matches 1 if score #chest c.vs > #m c.t run scoreboard players set #best c.t 108
execute if score #best c.t matches 108 run scoreboard players operation #m c.t = #chest c.vs
execute unless score #barrel c.x matches 1 if score #barrel c.vs > #m c.t run scoreboard players set #best c.t 109
execute if score #best c.t matches 109 run scoreboard players operation #m c.t = #barrel c.vs
execute unless score #ladder c.x matches 1 if score #ladder c.vs > #m c.t run scoreboard players set #best c.t 110
execute if score #best c.t matches 110 run scoreboard players operation #m c.t = #ladder c.vs
execute unless score #rail c.x matches 1 if score #rail c.vs > #m c.t run scoreboard players set #best c.t 111
execute if score #best c.t matches 111 run scoreboard players operation #m c.t = #rail c.vs
execute unless score #piston c.x matches 1 if score #piston c.vs > #m c.t run scoreboard players set #best c.t 112
execute if score #best c.t matches 112 run scoreboard players operation #m c.t = #piston c.vs
execute unless score #observer c.x matches 1 if score #observer c.vs > #m c.t run scoreboard players set #best c.t 113
execute if score #best c.t matches 113 run scoreboard players operation #m c.t = #observer c.vs
execute unless score #hopper c.x matches 1 if score #hopper c.vs > #m c.t run scoreboard players set #best c.t 114
execute if score #best c.t matches 114 run scoreboard players operation #m c.t = #hopper c.vs
execute unless score #bucket c.x matches 1 if score #bucket c.vs > #m c.t run scoreboard players set #best c.t 115
execute if score #best c.t matches 115 run scoreboard players operation #m c.t = #bucket c.vs
execute unless score #name_tag c.x matches 1 if score #name_tag c.vs > #m c.t run scoreboard players set #best c.t 116
execute if score #best c.t matches 116 run scoreboard players operation #m c.t = #name_tag c.vs
execute unless score #saddle c.x matches 1 if score #saddle c.vs > #m c.t run scoreboard players set #best c.t 117
execute if score #best c.t matches 117 run scoreboard players operation #m c.t = #saddle c.vs
execute unless score #diamond c.x matches 1 if score #diamond c.vs > #m c.t run scoreboard players set #best c.t 118
execute if score #best c.t matches 118 run scoreboard players operation #m c.t = #diamond c.vs
execute unless score #emerald c.x matches 1 if score #emerald c.vs > #m c.t run scoreboard players set #best c.t 119
execute if score #best c.t matches 119 run scoreboard players operation #m c.t = #emerald c.vs
execute unless score #ancient_debris c.x matches 1 if score #ancient_debris c.vs > #m c.t run scoreboard players set #best c.t 120
execute if score #best c.t matches 120 run scoreboard players operation #m c.t = #ancient_debris c.vs
execute unless score #netherite_scrap c.x matches 1 if score #netherite_scrap c.vs > #m c.t run scoreboard players set #best c.t 121
execute if score #best c.t matches 121 run scoreboard players operation #m c.t = #netherite_scrap c.vs
execute unless score #netherite_ingot c.x matches 1 if score #netherite_ingot c.vs > #m c.t run scoreboard players set #best c.t 122
execute if score #best c.t matches 122 run scoreboard players operation #m c.t = #netherite_ingot c.vs
execute unless score #echo_shard c.x matches 1 if score #echo_shard c.vs > #m c.t run scoreboard players set #best c.t 123
execute if score #best c.t matches 123 run scoreboard players operation #m c.t = #echo_shard c.vs
execute unless score #nautilus_shell c.x matches 1 if score #nautilus_shell c.vs > #m c.t run scoreboard players set #best c.t 124
execute if score #best c.t matches 124 run scoreboard players operation #m c.t = #nautilus_shell c.vs
execute unless score #heart_of_the_sea c.x matches 1 if score #heart_of_the_sea c.vs > #m c.t run scoreboard players set #best c.t 125
execute if score #best c.t matches 125 run scoreboard players operation #m c.t = #heart_of_the_sea c.vs
execute unless score #ghast_tear c.x matches 1 if score #ghast_tear c.vs > #m c.t run scoreboard players set #best c.t 126
execute if score #best c.t matches 126 run scoreboard players operation #m c.t = #ghast_tear c.vs
execute unless score #shulker_shell c.x matches 1 if score #shulker_shell c.vs > #m c.t run scoreboard players set #best c.t 127
execute if score #best c.t matches 127 run scoreboard players operation #m c.t = #shulker_shell c.vs
execute unless score #totem_of_undying c.x matches 1 if score #totem_of_undying c.vs > #m c.t run scoreboard players set #best c.t 128
execute if score #best c.t matches 128 run scoreboard players operation #m c.t = #totem_of_undying c.vs
execute unless score #wither_skeleton_skull c.x matches 1 if score #wither_skeleton_skull c.vs > #m c.t run scoreboard players set #best c.t 129
execute if score #best c.t matches 129 run scoreboard players operation #m c.t = #wither_skeleton_skull c.vs
execute unless score #nether_star c.x matches 1 if score #nether_star c.vs > #m c.t run scoreboard players set #best c.t 130
execute if score #best c.t matches 130 run scoreboard players operation #m c.t = #nether_star c.vs
execute unless score #trident c.x matches 1 if score #trident c.vs > #m c.t run scoreboard players set #best c.t 131
execute if score #best c.t matches 131 run scoreboard players operation #m c.t = #trident c.vs
execute unless score #elytra c.x matches 1 if score #elytra c.vs > #m c.t run scoreboard players set #best c.t 132
execute if score #best c.t matches 132 run scoreboard players operation #m c.t = #elytra c.vs
execute unless score #enchanted_golden_apple c.x matches 1 if score #enchanted_golden_apple c.vs > #m c.t run scoreboard players set #best c.t 133
execute if score #best c.t matches 133 run scoreboard players operation #m c.t = #enchanted_golden_apple c.vs
