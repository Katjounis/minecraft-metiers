$data modify storage commerce:r C append value {text:"$(r). ",color:"gray"}
$data modify storage commerce:r C append value {text:"$(nom)",color:"white"}
$data modify storage commerce:r C append value {text:"   $(e) ¤\n",color:"gold"}
