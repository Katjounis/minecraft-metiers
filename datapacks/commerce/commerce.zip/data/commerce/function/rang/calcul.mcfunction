data modify storage commerce:r L set value []
data modify storage commerce:r R set value []
data modify storage commerce:r W set from storage commerce:j l
$data modify storage commerce:r obj set value "$(obj)"
$scoreboard players set #rn c.t $(n)
function commerce:rang/remplir
scoreboard players set #rk c.t 0
function commerce:rang/extraire
function commerce:rang/texte
