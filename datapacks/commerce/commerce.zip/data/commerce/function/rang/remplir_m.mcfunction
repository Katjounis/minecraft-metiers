scoreboard players set #e c.t 0
$execute store result score #e c.t run scoreboard players get $(nom) $(obj)
$data modify storage commerce:r L append value {nom:"$(nom)",e:0}
execute store result storage commerce:r L[-1].e int 1 run scoreboard players get #e c.t
