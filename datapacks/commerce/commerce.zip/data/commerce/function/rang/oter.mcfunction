$data remove storage commerce:r L[{nom:"$(nom)"}]
