execute unless data storage commerce:r W[0] run return 0
function commerce:rang/texte_m with storage commerce:r W[0]
data remove storage commerce:r W[0]
function commerce:rang/texte_boucle
