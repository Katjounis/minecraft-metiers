execute if score #rk c.t >= #rn c.t run return 0
execute unless data storage commerce:r L[0] run return 0
scoreboard players set #m c.t -1
data modify storage commerce:r W set from storage commerce:r L
function commerce:rang/max
scoreboard players add #rk c.t 1
data modify storage commerce:r R append from storage commerce:r best
execute store result storage commerce:r R[-1].r int 1 run scoreboard players get #rk c.t
function commerce:rang/oter with storage commerce:r best
function commerce:rang/extraire
