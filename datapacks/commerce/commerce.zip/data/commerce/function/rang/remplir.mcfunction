execute unless data storage commerce:r W[0] run return 0
data modify storage commerce:r cur set from storage commerce:r W[0]
data modify storage commerce:r cur.obj set from storage commerce:r obj
function commerce:rang/remplir_m with storage commerce:r cur
data remove storage commerce:r W[0]
function commerce:rang/remplir
