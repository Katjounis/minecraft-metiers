execute unless data storage commerce:r W[0] run return 0
execute store result score #x c.t run data get storage commerce:r W[0].e
execute if score #x c.t > #m c.t run data modify storage commerce:r best set from storage commerce:r W[0]
execute if score #x c.t > #m c.t run scoreboard players operation #m c.t = #x c.t
data remove storage commerce:r W[0]
function commerce:rang/max
