data modify storage commerce:r C set value [{text:""}]
execute unless data storage commerce:r R[0] run data modify storage commerce:r C append value {text:"Personne pour l'instant.",color:"gray"}
data modify storage commerce:r W set from storage commerce:r R
function commerce:rang/texte_boucle
