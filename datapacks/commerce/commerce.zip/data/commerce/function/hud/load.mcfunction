scoreboard objectives add c.hudv dummy
scoreboard objectives add c.hudr dummy
scoreboard objectives add c.quit minecraft.custom:minecraft.leave_game
execute unless score #hud c.g matches 1.. run function commerce:tableau/off
execute unless score #hud c.g matches 2.. run scoreboard players set #hud c.g 1
execute if score #hud c.g matches 2 run function commerce:tableau/off
execute if score #hud c.g matches 2 run scoreboard players set @a c.hudv -1
scoreboard players set #hud c.g 1
