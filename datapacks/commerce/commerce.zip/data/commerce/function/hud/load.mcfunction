scoreboard objectives add c.hudv dummy
scoreboard objectives add c.hudr dummy
scoreboard objectives add c.quit minecraft.custom:minecraft.leave_game
execute unless score #hud c.g matches 1 run function commerce:tableau/off
scoreboard players set #hud c.g 1
