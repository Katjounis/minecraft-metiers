title @s clear
scoreboard players set @s c.hudv -2
