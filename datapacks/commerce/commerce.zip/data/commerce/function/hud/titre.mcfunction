$title @s title [{text:"",font:"commerce:hud",color:"#FEFEFD",shadow_color:0,extra:[{text:""},{text:"$(d9)$(d8)$(d7)$(d6)$(d5)$(d4)$(d3)$(d2)$(d1)$(d0)$(c1)$(c0)",color:"#FEC841"}]}]
