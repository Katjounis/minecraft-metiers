scoreboard players operation @s c.hudv = #hv c.t
scoreboard players set @s c.hudr 0
scoreboard players operation #n c.t = @s c.ecus
execute if score #n c.t matches ..-1 run scoreboard players set #n c.t 0
scoreboard players operation #d c.t = #n c.t
scoreboard players operation #d c.t %= #10 c.g
execute if score #d c.t matches 0 run data modify storage commerce:h d0 set value ""
execute if score #d c.t matches 1 run data modify storage commerce:h d0 set value ""
execute if score #d c.t matches 2 run data modify storage commerce:h d0 set value ""
execute if score #d c.t matches 3 run data modify storage commerce:h d0 set value ""
execute if score #d c.t matches 4 run data modify storage commerce:h d0 set value ""
execute if score #d c.t matches 5 run data modify storage commerce:h d0 set value ""
execute if score #d c.t matches 6 run data modify storage commerce:h d0 set value ""
execute if score #d c.t matches 7 run data modify storage commerce:h d0 set value ""
execute if score #d c.t matches 8 run data modify storage commerce:h d0 set value ""
execute if score #d c.t matches 9 run data modify storage commerce:h d0 set value ""
scoreboard players operation #d c.t = #n c.t
scoreboard players set #p c.t 10
scoreboard players operation #d c.t /= #p c.t
scoreboard players operation #d c.t %= #10 c.g
execute if score #d c.t matches 0 run data modify storage commerce:h d1 set value ""
execute if score #d c.t matches 1 run data modify storage commerce:h d1 set value ""
execute if score #d c.t matches 2 run data modify storage commerce:h d1 set value ""
execute if score #d c.t matches 3 run data modify storage commerce:h d1 set value ""
execute if score #d c.t matches 4 run data modify storage commerce:h d1 set value ""
execute if score #d c.t matches 5 run data modify storage commerce:h d1 set value ""
execute if score #d c.t matches 6 run data modify storage commerce:h d1 set value ""
execute if score #d c.t matches 7 run data modify storage commerce:h d1 set value ""
execute if score #d c.t matches 8 run data modify storage commerce:h d1 set value ""
execute if score #d c.t matches 9 run data modify storage commerce:h d1 set value ""
execute if score #n c.t matches ..9 run data modify storage commerce:h d1 set value ""
scoreboard players operation #d c.t = #n c.t
scoreboard players set #p c.t 100
scoreboard players operation #d c.t /= #p c.t
scoreboard players operation #d c.t %= #10 c.g
execute if score #d c.t matches 0 run data modify storage commerce:h d2 set value ""
execute if score #d c.t matches 1 run data modify storage commerce:h d2 set value ""
execute if score #d c.t matches 2 run data modify storage commerce:h d2 set value ""
execute if score #d c.t matches 3 run data modify storage commerce:h d2 set value ""
execute if score #d c.t matches 4 run data modify storage commerce:h d2 set value ""
execute if score #d c.t matches 5 run data modify storage commerce:h d2 set value ""
execute if score #d c.t matches 6 run data modify storage commerce:h d2 set value ""
execute if score #d c.t matches 7 run data modify storage commerce:h d2 set value ""
execute if score #d c.t matches 8 run data modify storage commerce:h d2 set value ""
execute if score #d c.t matches 9 run data modify storage commerce:h d2 set value ""
execute if score #n c.t matches ..99 run data modify storage commerce:h d2 set value ""
scoreboard players operation #d c.t = #n c.t
scoreboard players set #p c.t 1000
scoreboard players operation #d c.t /= #p c.t
scoreboard players operation #d c.t %= #10 c.g
execute if score #d c.t matches 0 run data modify storage commerce:h d3 set value ""
execute if score #d c.t matches 1 run data modify storage commerce:h d3 set value ""
execute if score #d c.t matches 2 run data modify storage commerce:h d3 set value ""
execute if score #d c.t matches 3 run data modify storage commerce:h d3 set value ""
execute if score #d c.t matches 4 run data modify storage commerce:h d3 set value ""
execute if score #d c.t matches 5 run data modify storage commerce:h d3 set value ""
execute if score #d c.t matches 6 run data modify storage commerce:h d3 set value ""
execute if score #d c.t matches 7 run data modify storage commerce:h d3 set value ""
execute if score #d c.t matches 8 run data modify storage commerce:h d3 set value ""
execute if score #d c.t matches 9 run data modify storage commerce:h d3 set value ""
execute if score #n c.t matches ..999 run data modify storage commerce:h d3 set value ""
scoreboard players operation #d c.t = #n c.t
scoreboard players set #p c.t 10000
scoreboard players operation #d c.t /= #p c.t
scoreboard players operation #d c.t %= #10 c.g
execute if score #d c.t matches 0 run data modify storage commerce:h d4 set value ""
execute if score #d c.t matches 1 run data modify storage commerce:h d4 set value ""
execute if score #d c.t matches 2 run data modify storage commerce:h d4 set value ""
execute if score #d c.t matches 3 run data modify storage commerce:h d4 set value ""
execute if score #d c.t matches 4 run data modify storage commerce:h d4 set value ""
execute if score #d c.t matches 5 run data modify storage commerce:h d4 set value ""
execute if score #d c.t matches 6 run data modify storage commerce:h d4 set value ""
execute if score #d c.t matches 7 run data modify storage commerce:h d4 set value ""
execute if score #d c.t matches 8 run data modify storage commerce:h d4 set value ""
execute if score #d c.t matches 9 run data modify storage commerce:h d4 set value ""
execute if score #n c.t matches ..9999 run data modify storage commerce:h d4 set value ""
scoreboard players operation #d c.t = #n c.t
scoreboard players set #p c.t 100000
scoreboard players operation #d c.t /= #p c.t
scoreboard players operation #d c.t %= #10 c.g
execute if score #d c.t matches 0 run data modify storage commerce:h d5 set value ""
execute if score #d c.t matches 1 run data modify storage commerce:h d5 set value ""
execute if score #d c.t matches 2 run data modify storage commerce:h d5 set value ""
execute if score #d c.t matches 3 run data modify storage commerce:h d5 set value ""
execute if score #d c.t matches 4 run data modify storage commerce:h d5 set value ""
execute if score #d c.t matches 5 run data modify storage commerce:h d5 set value ""
execute if score #d c.t matches 6 run data modify storage commerce:h d5 set value ""
execute if score #d c.t matches 7 run data modify storage commerce:h d5 set value ""
execute if score #d c.t matches 8 run data modify storage commerce:h d5 set value ""
execute if score #d c.t matches 9 run data modify storage commerce:h d5 set value ""
execute if score #n c.t matches ..99999 run data modify storage commerce:h d5 set value ""
scoreboard players operation #d c.t = #n c.t
scoreboard players set #p c.t 1000000
scoreboard players operation #d c.t /= #p c.t
scoreboard players operation #d c.t %= #10 c.g
execute if score #d c.t matches 0 run data modify storage commerce:h d6 set value ""
execute if score #d c.t matches 1 run data modify storage commerce:h d6 set value ""
execute if score #d c.t matches 2 run data modify storage commerce:h d6 set value ""
execute if score #d c.t matches 3 run data modify storage commerce:h d6 set value ""
execute if score #d c.t matches 4 run data modify storage commerce:h d6 set value ""
execute if score #d c.t matches 5 run data modify storage commerce:h d6 set value ""
execute if score #d c.t matches 6 run data modify storage commerce:h d6 set value ""
execute if score #d c.t matches 7 run data modify storage commerce:h d6 set value ""
execute if score #d c.t matches 8 run data modify storage commerce:h d6 set value ""
execute if score #d c.t matches 9 run data modify storage commerce:h d6 set value ""
execute if score #n c.t matches ..999999 run data modify storage commerce:h d6 set value ""
scoreboard players operation #d c.t = #n c.t
scoreboard players set #p c.t 10000000
scoreboard players operation #d c.t /= #p c.t
scoreboard players operation #d c.t %= #10 c.g
execute if score #d c.t matches 0 run data modify storage commerce:h d7 set value ""
execute if score #d c.t matches 1 run data modify storage commerce:h d7 set value ""
execute if score #d c.t matches 2 run data modify storage commerce:h d7 set value ""
execute if score #d c.t matches 3 run data modify storage commerce:h d7 set value ""
execute if score #d c.t matches 4 run data modify storage commerce:h d7 set value ""
execute if score #d c.t matches 5 run data modify storage commerce:h d7 set value ""
execute if score #d c.t matches 6 run data modify storage commerce:h d7 set value ""
execute if score #d c.t matches 7 run data modify storage commerce:h d7 set value ""
execute if score #d c.t matches 8 run data modify storage commerce:h d7 set value ""
execute if score #d c.t matches 9 run data modify storage commerce:h d7 set value ""
execute if score #n c.t matches ..9999999 run data modify storage commerce:h d7 set value ""
scoreboard players operation #d c.t = #n c.t
scoreboard players set #p c.t 100000000
scoreboard players operation #d c.t /= #p c.t
scoreboard players operation #d c.t %= #10 c.g
execute if score #d c.t matches 0 run data modify storage commerce:h d8 set value ""
execute if score #d c.t matches 1 run data modify storage commerce:h d8 set value ""
execute if score #d c.t matches 2 run data modify storage commerce:h d8 set value ""
execute if score #d c.t matches 3 run data modify storage commerce:h d8 set value ""
execute if score #d c.t matches 4 run data modify storage commerce:h d8 set value ""
execute if score #d c.t matches 5 run data modify storage commerce:h d8 set value ""
execute if score #d c.t matches 6 run data modify storage commerce:h d8 set value ""
execute if score #d c.t matches 7 run data modify storage commerce:h d8 set value ""
execute if score #d c.t matches 8 run data modify storage commerce:h d8 set value ""
execute if score #d c.t matches 9 run data modify storage commerce:h d8 set value ""
execute if score #n c.t matches ..99999999 run data modify storage commerce:h d8 set value ""
scoreboard players operation #d c.t = #n c.t
scoreboard players set #p c.t 1000000000
scoreboard players operation #d c.t /= #p c.t
scoreboard players operation #d c.t %= #10 c.g
execute if score #d c.t matches 0 run data modify storage commerce:h d9 set value ""
execute if score #d c.t matches 1 run data modify storage commerce:h d9 set value ""
execute if score #d c.t matches 2 run data modify storage commerce:h d9 set value ""
execute if score #d c.t matches 3 run data modify storage commerce:h d9 set value ""
execute if score #d c.t matches 4 run data modify storage commerce:h d9 set value ""
execute if score #d c.t matches 5 run data modify storage commerce:h d9 set value ""
execute if score #d c.t matches 6 run data modify storage commerce:h d9 set value ""
execute if score #d c.t matches 7 run data modify storage commerce:h d9 set value ""
execute if score #d c.t matches 8 run data modify storage commerce:h d9 set value ""
execute if score #d c.t matches 9 run data modify storage commerce:h d9 set value ""
execute if score #n c.t matches ..999999999 run data modify storage commerce:h d9 set value ""
scoreboard players operation #d c.t = @s c.cts
scoreboard players operation #d c.t /= #10 c.g
execute if score #d c.t matches 0 run data modify storage commerce:h c1 set value ""
execute if score #d c.t matches 1 run data modify storage commerce:h c1 set value ""
execute if score #d c.t matches 2 run data modify storage commerce:h c1 set value ""
execute if score #d c.t matches 3 run data modify storage commerce:h c1 set value ""
execute if score #d c.t matches 4 run data modify storage commerce:h c1 set value ""
execute if score #d c.t matches 5 run data modify storage commerce:h c1 set value ""
execute if score #d c.t matches 6 run data modify storage commerce:h c1 set value ""
execute if score #d c.t matches 7 run data modify storage commerce:h c1 set value ""
execute if score #d c.t matches 8 run data modify storage commerce:h c1 set value ""
execute if score #d c.t matches 9 run data modify storage commerce:h c1 set value ""
scoreboard players operation #d c.t = @s c.cts
scoreboard players operation #d c.t %= #10 c.g
execute if score #d c.t matches 0 run data modify storage commerce:h c0 set value ""
execute if score #d c.t matches 1 run data modify storage commerce:h c0 set value ""
execute if score #d c.t matches 2 run data modify storage commerce:h c0 set value ""
execute if score #d c.t matches 3 run data modify storage commerce:h c0 set value ""
execute if score #d c.t matches 4 run data modify storage commerce:h c0 set value ""
execute if score #d c.t matches 5 run data modify storage commerce:h c0 set value ""
execute if score #d c.t matches 6 run data modify storage commerce:h c0 set value ""
execute if score #d c.t matches 7 run data modify storage commerce:h c0 set value ""
execute if score #d c.t matches 8 run data modify storage commerce:h c0 set value ""
execute if score #d c.t matches 9 run data modify storage commerce:h c0 set value ""
title @s times 0 2000000000 0
function commerce:hud/titre with storage commerce:h
