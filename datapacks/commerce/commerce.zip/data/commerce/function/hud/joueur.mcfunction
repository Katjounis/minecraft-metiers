execute if score @s c.quit matches 1.. run scoreboard players set @s c.hudv -1
scoreboard players set @s c.quit 0
scoreboard players operation #hv c.t = @s c.ecus
scoreboard players operation #hv c.t *= #100 c.g
scoreboard players operation #hv c.t += @s c.cts
scoreboard players add @s c.hudr 1
execute if score @s c.hudr matches 1200.. run scoreboard players set @s c.hudv -1
execute unless score #hv c.t = @s c.hudv run function commerce:hud/maj
