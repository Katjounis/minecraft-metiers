execute unless data storage commerce:t W2[0] run return 0
execute store result score #x c.t run data get storage commerce:t W2[0]
scoreboard players set #hh c.t 3
execute if score #hsp c.t matches 1.. run scoreboard players operation #x c.t -= #hmin c.t
execute if score #hsp c.t matches 1.. run scoreboard players operation #x c.t *= #7 c.g
execute if score #hsp c.t matches 1.. run scoreboard players operation #x c.t /= #hsp c.t
execute if score #hsp c.t matches 1.. run scoreboard players operation #hh c.t = #x c.t
execute if score #hh c.t matches 0 run data modify storage commerce:t SP append value {text:"",font:"commerce:recette"}
execute if score #hh c.t matches 1 run data modify storage commerce:t SP append value {text:"",font:"commerce:recette"}
execute if score #hh c.t matches 2 run data modify storage commerce:t SP append value {text:"",font:"commerce:recette"}
execute if score #hh c.t matches 3 run data modify storage commerce:t SP append value {text:"",font:"commerce:recette"}
execute if score #hh c.t matches 4 run data modify storage commerce:t SP append value {text:"",font:"commerce:recette"}
execute if score #hh c.t matches 5 run data modify storage commerce:t SP append value {text:"",font:"commerce:recette"}
execute if score #hh c.t matches 6 run data modify storage commerce:t SP append value {text:"",font:"commerce:recette"}
execute if score #hh c.t matches 7 run data modify storage commerce:t SP append value {text:"",font:"commerce:recette"}
data remove storage commerce:t W2[0]
function commerce:hist/barres
