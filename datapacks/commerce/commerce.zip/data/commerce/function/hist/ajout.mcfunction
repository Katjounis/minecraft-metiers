$data modify storage commerce:hist $(id) append value 0
$execute store result storage commerce:hist $(id)[-1] int 1 run scoreboard players get #h c.t
$execute if data storage commerce:hist $(id)[24] run data remove storage commerce:hist $(id)[0]
