execute unless data storage commerce:t W2[0] run return 0
execute store result score #x c.t run data get storage commerce:t W2[0]
scoreboard players operation #hmin c.t < #x c.t
scoreboard players operation #hmax c.t > #x c.t
data remove storage commerce:t W2[0]
function commerce:hist/minmax
