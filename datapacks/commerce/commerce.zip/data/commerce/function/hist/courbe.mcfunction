data modify storage commerce:t SP set value [{text:""}]
data modify storage commerce:t VAR set value ""
data modify storage commerce:t VARC set value "gray"
execute store result score #hn c.t run data get storage commerce:t H
execute if score #hn c.t matches ..1 run return run data modify storage commerce:t SP set value [{text:"pas encore assez de relevés (un par heure de jeu)",color:"dark_gray",italic:true}]
scoreboard players set #hmin c.t 2147483647
scoreboard players set #hmax c.t -2147483648
data modify storage commerce:t W2 set from storage commerce:t H
function commerce:hist/minmax
scoreboard players operation #hsp c.t = #hmax c.t
scoreboard players operation #hsp c.t -= #hmin c.t
data modify storage commerce:t W2 set from storage commerce:t H
function commerce:hist/barres
execute store result score #h0 c.t run data get storage commerce:t H[0]
execute store result score #h1 c.t run data get storage commerce:t H[-1]
execute if score #h0 c.t matches ..0 run scoreboard players set #h0 c.t 1
scoreboard players operation #hv c.t = #h1 c.t
scoreboard players operation #hv c.t -= #h0 c.t
scoreboard players operation #hv c.t *= #1000 c.g
scoreboard players operation #hv c.t /= #h0 c.t
execute if score #hv c.t matches 1.. run data modify storage commerce:t VARC set value "green"
execute if score #hv c.t matches ..-1 run data modify storage commerce:t VARC set value "red"
data modify storage commerce:t vs set value "+"
execute if score #hv c.t matches ..-1 run data modify storage commerce:t vs set value "-"
execute if score #hv c.t matches ..-1 run scoreboard players operation #hv c.t *= #-1 c.g
scoreboard players operation #hve c.t = #hv c.t
scoreboard players operation #hve c.t /= #10 c.g
scoreboard players operation #hvd c.t = #hv c.t
scoreboard players operation #hvd c.t %= #10 c.g
execute store result storage commerce:t ve int 1 run scoreboard players get #hve c.t
execute store result storage commerce:t vd int 1 run scoreboard players get #hvd c.t
function commerce:hist/var with storage commerce:t
