$data modify storage commerce:t VAR set value "  $(vs)$(ve),$(vd) %"
