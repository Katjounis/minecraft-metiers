scoreboard players set #t c.g 0
execute as @a at @s run function commerce:joueur/seconde
execute as @e[type=minecraft:villager,tag=commerce.comptoir] at @s run rotate @s facing entity @p[distance=..6,gamemode=!spectator] eyes
scoreboard players add #cv c.g 1
execute if score #cv c.g matches 5.. run function commerce:comptoir/verif_tous
scoreboard players add #dec c.g 1
execute if score #dec c.g matches 120.. run function commerce:marche/detente
scoreboard players add #hr c.g 1
execute if score #hr c.g matches 3600.. run function commerce:marche/heure
