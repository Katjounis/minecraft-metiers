scoreboard players add @s c.pp_e 1
scoreboard players operation #x c.t = @s c.pp_e
scoreboard players operation #x c.t *= #250 c.g
scoreboard players operation @s c.ecus += #x c.t
tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Prime de palier Éleveur : +",color:"light_purple",bold:false,italic:false},{score:{name:"#x",objective:"c.t"},color:"gold"},{text:" ¤",color:"gold",bold:false,italic:false}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 0.8
