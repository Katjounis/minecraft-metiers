scoreboard players add @s c.ecus 400
tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"+400 ¤",color:"gold",bold:true,italic:false},{text:" (défi collectif)",color:"gray",bold:false,italic:false}]
