scoreboard players add @s c.ecus 300
tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"+300 ¤",color:"gold",bold:true,italic:false},{text:" (tous les défis du jour)",color:"gray",bold:false,italic:false}]
