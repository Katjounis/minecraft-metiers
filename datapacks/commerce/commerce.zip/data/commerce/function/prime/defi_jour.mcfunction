scoreboard players add @s c.ecus 150
tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"+150 ¤",color:"gold",bold:true,italic:false},{text:" (défi du jour)",color:"gray",bold:false,italic:false}]
