scoreboard players add @s c.ecus 600
tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"+600 ¤",color:"gold",bold:true,italic:false},{text:" (boss terrassé)",color:"gray",bold:false,italic:false}]
execute if entity @s[tag=metiers.btop] run scoreboard players add @s c.ecus 600
execute if entity @s[tag=metiers.btop] run tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"+600 ¤",color:"gold",bold:true,italic:false},{text:" (plus gros dégâts)",color:"gray",bold:false,italic:false}]
