scoreboard players add @s c.ecus 1500
tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"+1500 ¤",color:"gold",bold:true,italic:false},{text:" (défi de la semaine)",color:"gray",bold:false,italic:false}]
