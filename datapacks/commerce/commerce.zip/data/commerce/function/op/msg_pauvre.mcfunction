$data modify storage commerce:t msg set value "Pas assez d'Écus : il te faut $(e) ¤ pour $(q)."
playsound minecraft:entity.villager.no master @s ~ ~ ~ 0.8 1
