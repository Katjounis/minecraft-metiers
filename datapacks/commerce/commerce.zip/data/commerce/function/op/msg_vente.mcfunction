$data modify storage commerce:t msg set value "Vendu : $(q) pour $(e),$(z)$(c) ¤."
