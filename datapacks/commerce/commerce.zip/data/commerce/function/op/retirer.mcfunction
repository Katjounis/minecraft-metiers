$clear @s minecraft:$(id)[!minecraft:custom_data,!minecraft:custom_name] $(q)
