scoreboard players operation #xe c.t = #tot c.t
scoreboard players operation #xe c.t /= #100 c.g
scoreboard players operation #xc c.t = #tot c.t
scoreboard players operation #xc c.t %= #100 c.g
scoreboard players operation @s c.ecus += #xe c.t
scoreboard players operation @s c.cts += #xc c.t
execute if score @s c.cts matches 100.. run scoreboard players add @s c.ecus 1
execute if score @s c.cts matches 100.. run scoreboard players remove @s c.cts 100
scoreboard players operation @s c.tv += #xe c.t
