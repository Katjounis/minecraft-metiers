scoreboard players operation #act c.t = #v c.t
scoreboard players operation #act c.t /= #1000000 c.g
scoreboard players operation #i c.t = #v c.t
scoreboard players operation #i c.t %= #1000000 c.g
scoreboard players operation #i c.t /= #1000 c.g
scoreboard players operation #q c.t = #v c.t
scoreboard players operation #q c.t %= #1000 c.g
execute unless score #i c.t matches 1..133 run return 0
execute if score #act c.t matches 1..2 unless score #q c.t matches 1..640 run return 0
execute if score #act c.t matches 1 run function commerce:op/acheter
execute if score #act c.t matches 2..3 run function commerce:op/vendre
function commerce:page/item
