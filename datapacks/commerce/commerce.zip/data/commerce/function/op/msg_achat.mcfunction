$data modify storage commerce:t msg set value "Acheté : $(q) pour $(e) ¤."
