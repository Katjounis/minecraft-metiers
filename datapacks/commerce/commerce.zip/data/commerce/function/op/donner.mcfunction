$give @s minecraft:$(id) $(q)
