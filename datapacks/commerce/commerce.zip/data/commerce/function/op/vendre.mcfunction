function commerce:item/charger
execute store result score #have c.t run function commerce:op/compter with storage commerce:t it
execute if score #act c.t matches 3 run scoreboard players operation #q c.t = #have c.t
execute if score #q c.t matches 641.. run scoreboard players set #q c.t 640
execute if score #q c.t > #have c.t run scoreboard players operation #q c.t = #have c.t
execute if score #q c.t matches ..0 run return run data modify storage commerce:t msg set value "Tu n'en as pas dans ton inventaire (les objets renommés ou spéciaux sont refusés)."
scoreboard players operation #d c.t = #q c.t
scoreboard players operation #d c.t *= #1000 c.g
scoreboard players operation #d c.t /= #V c.t
function commerce:prix/mid
function commerce:prix/bonus
function commerce:prix/vente
scoreboard players operation #tot c.t = #u c.t
scoreboard players operation #tot c.t *= #q c.t
execute store result storage commerce:t it.q int 1 run scoreboard players get #q c.t
function commerce:op/retirer with storage commerce:t it
scoreboard players operation #p c.t += #d c.t
execute if score #p c.t matches 701.. run scoreboard players set #p c.t 700
scoreboard players operation #vs c.t += #q c.t
function commerce:item/sauver
function commerce:op/crediter
scoreboard players operation #x c.t = #tot c.t
function commerce:fmt/centi
data modify storage commerce:t m e set from storage commerce:t f.e
data modify storage commerce:t m z set from storage commerce:t f.z
data modify storage commerce:t m c set from storage commerce:t f.c
data modify storage commerce:t m.q set from storage commerce:t it.q
function commerce:op/msg_vente with storage commerce:t m
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 0.8 1.2
playsound minecraft:block.chain.place master @s ~ ~ ~ 0.6 1.6
