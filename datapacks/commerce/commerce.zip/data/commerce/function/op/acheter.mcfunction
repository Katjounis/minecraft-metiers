function commerce:item/charger
execute if score #rare c.t matches 1 run return run data modify storage commerce:t msg set value "Le serveur ne revend pas cet objet, il le rachète seulement."
scoreboard players operation #d c.t = #q c.t
scoreboard players operation #d c.t *= #500 c.g
scoreboard players operation #d c.t /= #V c.t
scoreboard players operation #d c.t *= #-1 c.g
function commerce:prix/mid
function commerce:prix/sans_bonus
function commerce:prix/vente
scoreboard players operation #tot c.t = #a c.t
scoreboard players operation #tot c.t *= #q c.t
scoreboard players operation #ce c.t = #tot c.t
scoreboard players add #ce c.t 99
scoreboard players operation #ce c.t /= #100 c.g
execute store result storage commerce:t m.e int 1 run scoreboard players get #ce c.t
execute store result storage commerce:t it.q int 1 run scoreboard players get #q c.t
data modify storage commerce:t m.q set from storage commerce:t it.q
execute if score @s c.ecus < #ce c.t run return run function commerce:op/msg_pauvre with storage commerce:t m
scoreboard players operation @s c.ecus -= #ce c.t
scoreboard players operation @s c.ta += #ce c.t
function commerce:op/donner with storage commerce:t it
scoreboard players operation #p c.t += #d c.t
execute if score #p c.t matches ..-301 run scoreboard players set #p c.t -300
scoreboard players operation #as c.t += #q c.t
function commerce:item/sauver
function commerce:op/msg_achat with storage commerce:t m
playsound minecraft:entity.villager.trade master @s ~ ~ ~ 0.8 1
playsound minecraft:entity.item.pickup master @s ~ ~ ~ 0.6 0.8
