execute if score @s c.pend matches 1 run return run function commerce:saisie/virer
execute if score @s c.pend matches 2 run return run function commerce:hdv/prix
execute if score @s c.pend matches 3 run return run function commerce:boutique/prix
tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Ce montant ne correspond à rien en cours.",color:"red",bold:false,italic:false}]
