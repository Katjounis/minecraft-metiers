scoreboard players set #cv c.g 0
execute as @e[type=minecraft:villager,tag=commerce.comptoir] at @s run function commerce:comptoir/verif
