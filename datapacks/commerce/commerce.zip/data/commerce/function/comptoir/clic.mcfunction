advancement revoke @s only commerce:clic_comptoir
execute unless score @s c.deb matches 1 run return run function commerce:page/verrou
function commerce:page/accueil
