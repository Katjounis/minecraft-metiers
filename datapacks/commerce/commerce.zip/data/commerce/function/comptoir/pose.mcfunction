tag @s remove commerce.nouveau
tag @s add commerce.pose
execute unless entity @a[distance=..8,scores={c.oeuf=1..}] run return run kill @s
execute as @a[distance=..8,scores={c.oeuf=1..},limit=1,sort=nearest] at @s run function commerce:comptoir/proprio
tag @s remove commerce.pose
