execute unless score @s c.cmpt matches 1 run return run tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Tu n’as pas de comptoir posé. Crafte un œuf de comptoir pour en avoir un.",color:"red",bold:false,italic:false}]
scoreboard players operation #pid c.t = @s m.id
execute as @e[type=minecraft:villager,tag=commerce.comptoir] if score @s c.own = #pid c.t at @s run function commerce:comptoir/retirer
scoreboard players add @s c.ser 1
function commerce:comptoir/ser_maj
scoreboard players set @s c.cmpt 0
function commerce:oeuf/donner
playsound minecraft:item.bundle.insert master @s ~ ~ ~ 1 1
tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Ton comptoir est rangé dans ton inventaire : pose l'œuf où tu veux.",color:"green",bold:false,italic:false}]
