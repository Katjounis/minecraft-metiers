$execute unless score @s c.ser = #o$(id) c.ser run function commerce:comptoir/retirer
