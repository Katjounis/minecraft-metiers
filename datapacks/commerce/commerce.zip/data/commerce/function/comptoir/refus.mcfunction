kill @e[type=minecraft:villager,tag=commerce.pose,limit=1]
execute unless entity @s[gamemode=creative] run function commerce:oeuf/donner
tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Tu as déjà un comptoir. Pour le changer de place : touche G, Commerce, Mon comptoir. L'œuf t'est rendu.",color:"red",bold:false,italic:false}]
