execute if score @s c.cmpt matches 1 run return run function commerce:comptoir/refus
scoreboard players add @s c.ser 1
function commerce:comptoir/ser_maj
scoreboard players operation @e[type=minecraft:villager,tag=commerce.pose,limit=1] c.ser = @s c.ser
scoreboard players operation @e[type=minecraft:villager,tag=commerce.pose,limit=1] c.own = @s m.id
scoreboard players set @s c.cmpt 1
scoreboard players set @s c.deb 1
function commerce:joueur/inscrire
execute as @e[type=minecraft:villager,tag=commerce.pose,limit=1] run function commerce:comptoir/nommer with storage commerce:t
execute as @e[type=minecraft:villager,tag=commerce.pose,limit=1] run data modify entity @s Age set value 0
tag @e[type=minecraft:villager,tag=commerce.pose,limit=1] add commerce.comptoir
execute at @e[type=minecraft:villager,tag=commerce.pose,limit=1] run particle minecraft:happy_villager ~ ~1 ~ 0.5 1 0.5 0 30
playsound minecraft:entity.villager.celebrate master @s ~ ~ ~ 1 1
tellraw @s [{text:""},{text:"[Commerce] ",color:"gold",bold:false,italic:false},{text:"Ton comptoir est posé. Tout le monde peut l'utiliser (clic droit). Pour le déplacer : touche G, Commerce, Mon comptoir.",color:"green",bold:false,italic:false}]
