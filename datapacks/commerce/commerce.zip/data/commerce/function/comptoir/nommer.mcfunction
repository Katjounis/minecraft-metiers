$data modify entity @s CustomName set value {text:"Comptoir de $(nom)",color:"gold",bold:true}
