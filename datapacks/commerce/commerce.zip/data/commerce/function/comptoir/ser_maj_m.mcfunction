$scoreboard players operation #o$(id) c.ser = @s c.ser
