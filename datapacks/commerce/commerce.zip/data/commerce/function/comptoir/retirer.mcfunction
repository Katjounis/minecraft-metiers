particle minecraft:poof ~ ~1 ~ 0.3 0.6 0.3 0.02 20
tp @s ~ -400 ~
kill @s
