execute store result storage commerce:t o.id int 1 run scoreboard players get @s m.id
function commerce:comptoir/ser_maj_m with storage commerce:t o
