execute store result storage commerce:t o.id int 1 run scoreboard players get @s c.own
function commerce:comptoir/verif_m with storage commerce:t o
