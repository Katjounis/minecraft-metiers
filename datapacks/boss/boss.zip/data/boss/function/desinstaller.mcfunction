execute if score #etat bs.ev matches 1.. run function boss:ev/cloture
kill @e[tag=bs.e]
bossbar remove boss:combat
execute in boss:grimoire run forceload remove all
execute in boss:corbeau run forceload remove all
scoreboard objectives remove bs.ev
scoreboard objectives remove bs.tmp
scoreboard objectives remove bs.an
scoreboard objectives remove bs.g
scoreboard objectives remove bs.c
scoreboard objectives remove bs.k
scoreboard objectives remove bs.ins
scoreboard objectives remove bs.cid
scoreboard objectives remove bs.rx
scoreboard objectives remove bs.ry
scoreboard objectives remove bs.rz
scoreboard objectives remove bs.rd
scoreboard objectives remove bs.gm
scoreboard objectives remove bs.v1
scoreboard objectives remove bs.v2
scoreboard objectives remove bs.vu
scoreboard objectives remove bs.ok
scoreboard objectives remove bs.rejoindre
scoreboard objectives remove bs.pv
scoreboard objectives remove bs.mort
tellraw @s {"text":"Pack Boss retiré. Désactive-le avec /datapack disable.","color":"gray"}
