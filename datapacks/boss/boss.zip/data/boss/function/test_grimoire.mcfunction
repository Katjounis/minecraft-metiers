execute unless score #etat bs.ev matches 0 run return run tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Un événement de boss est déjà en cours.","color":"gray","bold":false}]
scoreboard players set #boss bs.ev 1
scoreboard players set #pvmax bs.ev 8
function boss:ev/ouvrir
scoreboard players operation @s bs.ins = #eid bs.ev
tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Test : tu es inscrit, départ dans 8 s.","color":"gray","bold":false}]
