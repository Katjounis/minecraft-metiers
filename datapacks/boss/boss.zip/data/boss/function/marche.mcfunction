scoreboard players set #on bs.ev 1
tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Événements de boss automatiques relancés.","color":"gray","bold":false}]
