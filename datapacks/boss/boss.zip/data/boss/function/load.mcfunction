scoreboard objectives add bs.ev dummy
scoreboard objectives add bs.tmp dummy
scoreboard objectives add bs.an dummy
scoreboard objectives add bs.g dummy
scoreboard objectives add bs.c dummy
scoreboard objectives add bs.k dummy
scoreboard objectives add bs.ins dummy
scoreboard objectives add bs.cid dummy
scoreboard objectives add bs.rx dummy
scoreboard objectives add bs.ry dummy
scoreboard objectives add bs.rz dummy
scoreboard objectives add bs.rd dummy
scoreboard objectives add bs.gm dummy
scoreboard objectives add bs.v1 dummy
scoreboard objectives add bs.v2 dummy
scoreboard objectives add bs.vu dummy
scoreboard objectives add bs.ok dummy
scoreboard objectives add bs.rejoindre trigger
scoreboard objectives add bs.pv health
scoreboard objectives add bs.mort deathCount
scoreboard players set #2 bs.tmp 2
scoreboard players set #10 bs.tmp 10
scoreboard players set #60 bs.tmp 60
scoreboard players set #100 bs.tmp 100
scoreboard players set #360 bs.tmp 360
execute unless score #on bs.ev matches 0..1 run scoreboard players set #on bs.ev 1
execute unless score #min bs.ev matches 1.. run scoreboard players set #min bs.ev 180
execute unless score #max bs.ev matches 1.. run scoreboard players set #max bs.ev 300
execute unless score #etat bs.ev matches 0.. run scoreboard players set #etat bs.ev 0
execute unless score #eid bs.ev matches 0.. run scoreboard players set #eid bs.ev 0
execute unless score #t bs.ev matches 0.. run function boss:ev/prochain
bossbar add boss:combat ""
kill @e[type=minecraft:item_display,tag=bs.mh]
bossbar set boss:combat style notched_10
execute if score #etat bs.ev matches 1.. run function boss:ev/interrompu
