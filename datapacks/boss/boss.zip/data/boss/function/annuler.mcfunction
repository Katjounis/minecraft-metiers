execute if score #etat bs.ev matches 0 run return run tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Aucun événement de boss en cours.","color":"gray","bold":false}]
tellraw @a [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Un administrateur a annulé l'événement de boss.","color":"gray","bold":false}]
function boss:ev/cloture
