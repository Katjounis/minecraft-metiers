execute if score #fmb_liche bs.an matches 8 run function boss:rig/mb_liche/a/attaque/k1
execute if score #fmb_liche bs.an matches 13 run function boss:rig/mb_liche/a/attaque/k2
execute if score #fmb_liche bs.an matches 25.. run function boss:metiers/mb_liche_defaut
