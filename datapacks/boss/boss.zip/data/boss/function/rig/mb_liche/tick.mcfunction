scoreboard players add #fmb_liche bs.an 1
execute if score #amb_liche bs.an matches 1 run function boss:rig/mb_liche/a/repos/t
execute if score #amb_liche bs.an matches 2 run function boss:rig/mb_liche/a/marche/t
execute if score #amb_liche bs.an matches 3 run function boss:rig/mb_liche/a/attaque/t
