execute if score #fmb_liche bs.an matches 10 run function boss:rig/mb_liche/a/marche/k1
execute if score #fmb_liche bs.an matches 20.. run scoreboard players set #fmb_liche bs.an 0
execute if score #fmb_liche bs.an matches 0 run function boss:rig/mb_liche/a/marche/k0
