scoreboard players set #amb_liche bs.an 1
scoreboard players set #fmb_liche bs.an 0
function boss:rig/mb_liche/a/repos/k0
