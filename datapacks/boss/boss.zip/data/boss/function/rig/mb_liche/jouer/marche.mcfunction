scoreboard players set #amb_liche bs.an 2
scoreboard players set #fmb_liche bs.an 0
function boss:rig/mb_liche/a/marche/k0
