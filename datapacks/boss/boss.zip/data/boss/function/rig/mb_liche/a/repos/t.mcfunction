execute if score #fmb_liche bs.an matches 20 run function boss:rig/mb_liche/a/repos/k1
execute if score #fmb_liche bs.an matches 40 run function boss:rig/mb_liche/a/repos/k2
execute if score #fmb_liche bs.an matches 60.. run scoreboard players set #fmb_liche bs.an 0
execute if score #fmb_liche bs.an matches 0 run function boss:rig/mb_liche/a/repos/k0
