scoreboard players add #fmb_brasier bs.an 1
execute if score #amb_brasier bs.an matches 1 run function boss:rig/mb_brasier/a/repos/t
execute if score #amb_brasier bs.an matches 2 run function boss:rig/mb_brasier/a/attaque/t
execute if score #amb_brasier bs.an matches 3 run function boss:rig/mb_brasier/a/marche/t
