execute if score #fmb_brasier bs.an matches 14 run function boss:rig/mb_brasier/a/repos/k1
execute if score #fmb_brasier bs.an matches 28 run function boss:rig/mb_brasier/a/repos/k2
execute if score #fmb_brasier bs.an matches 42.. run scoreboard players set #fmb_brasier bs.an 0
execute if score #fmb_brasier bs.an matches 0 run function boss:rig/mb_brasier/a/repos/k0
