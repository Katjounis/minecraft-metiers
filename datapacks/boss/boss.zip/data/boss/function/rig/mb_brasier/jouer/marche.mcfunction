scoreboard players set #amb_brasier bs.an 3
scoreboard players set #fmb_brasier bs.an 0
function boss:rig/mb_brasier/a/marche/k0
