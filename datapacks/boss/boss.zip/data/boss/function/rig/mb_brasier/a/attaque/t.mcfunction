execute if score #fmb_brasier bs.an matches 6 run function boss:rig/mb_brasier/a/attaque/k1
execute if score #fmb_brasier bs.an matches 12 run function boss:rig/mb_brasier/a/attaque/k2
execute if score #fmb_brasier bs.an matches 22.. run function boss:metiers/mb_brasier_defaut
