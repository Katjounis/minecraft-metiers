scoreboard players set #amb_brasier bs.an 2
scoreboard players set #fmb_brasier bs.an 0
function boss:rig/mb_brasier/a/attaque/k0
