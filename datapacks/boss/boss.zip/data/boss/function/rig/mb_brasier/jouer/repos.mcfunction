scoreboard players set #amb_brasier bs.an 1
scoreboard players set #fmb_brasier bs.an 0
function boss:rig/mb_brasier/a/repos/k0
