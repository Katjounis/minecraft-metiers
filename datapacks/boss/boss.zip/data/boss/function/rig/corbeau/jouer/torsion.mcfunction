scoreboard players set #acorbeau bs.an 3
scoreboard players set #fcorbeau bs.an 0
function boss:rig/corbeau/a/torsion/k0
