execute if score #fcorbeau bs.an matches 1.. run scoreboard players set #acorbeau bs.an 0
