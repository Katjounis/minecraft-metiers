execute if score #fcorbeau bs.an matches 4 run function boss:rig/corbeau/a/charge/k1
execute if score #fcorbeau bs.an matches 8.. run scoreboard players set #fcorbeau bs.an 0
execute if score #fcorbeau bs.an matches 0 run function boss:rig/corbeau/a/charge/k0
