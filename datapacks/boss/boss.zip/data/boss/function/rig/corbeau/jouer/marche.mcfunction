scoreboard players set #acorbeau bs.an 1
scoreboard players set #fcorbeau bs.an 0
function boss:rig/corbeau/a/marche/k0
