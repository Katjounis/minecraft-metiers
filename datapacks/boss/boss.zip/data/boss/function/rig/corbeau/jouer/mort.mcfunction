scoreboard players set #acorbeau bs.an 13
scoreboard players set #fcorbeau bs.an 0
function boss:rig/corbeau/a/mort/k0
