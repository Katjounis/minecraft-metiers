execute if score #fcorbeau bs.an matches 1 run function boss:rig/corbeau/a/reforme/k1
execute if score #fcorbeau bs.an matches 6 run function boss:rig/corbeau/a/reforme/k2
execute if score #fcorbeau bs.an matches 11 run function boss:rig/corbeau/a/reforme/k3
execute if score #fcorbeau bs.an matches 16 run function boss:rig/corbeau/a/reforme/k4
execute if score #fcorbeau bs.an matches 22 run function boss:rig/corbeau/a/reforme/k5
execute if score #fcorbeau bs.an matches 30.. run function boss:c/anim_defaut
