scoreboard players set #acorbeau bs.an 7
scoreboard players set #fcorbeau bs.an 0
function boss:rig/corbeau/a/cache/k0
