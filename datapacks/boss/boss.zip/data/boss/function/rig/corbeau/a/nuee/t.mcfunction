execute if score #fcorbeau bs.an matches 10 run function boss:rig/corbeau/a/nuee/k1
execute if score #fcorbeau bs.an matches 26 run function boss:rig/corbeau/a/nuee/k2
execute if score #fcorbeau bs.an matches 36.. run function boss:c/anim_defaut
