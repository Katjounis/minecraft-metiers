execute if score #fcorbeau bs.an matches 6 run function boss:rig/corbeau/a/dispersion/k1
execute if score #fcorbeau bs.an matches 11 run function boss:rig/corbeau/a/dispersion/k2
execute if score #fcorbeau bs.an matches 16 run function boss:rig/corbeau/a/dispersion/k3
execute if score #fcorbeau bs.an matches 21 run function boss:rig/corbeau/a/dispersion/k4
execute if score #fcorbeau bs.an matches 26.. run scoreboard players set #acorbeau bs.an 0
