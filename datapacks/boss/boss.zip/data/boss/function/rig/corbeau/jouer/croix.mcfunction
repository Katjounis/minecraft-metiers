scoreboard players set #acorbeau bs.an 9
scoreboard players set #fcorbeau bs.an 0
function boss:rig/corbeau/a/croix/k0
