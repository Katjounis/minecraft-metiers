execute if score #fcorbeau bs.an matches 12 run function boss:rig/corbeau/a/marche/k1
execute if score #fcorbeau bs.an matches 16 run function boss:rig/corbeau/a/marche/k2
execute if score #fcorbeau bs.an matches 28 run function boss:rig/corbeau/a/marche/k3
execute if score #fcorbeau bs.an matches 32.. run scoreboard players set #fcorbeau bs.an 0
execute if score #fcorbeau bs.an matches 0 run function boss:rig/corbeau/a/marche/k0
