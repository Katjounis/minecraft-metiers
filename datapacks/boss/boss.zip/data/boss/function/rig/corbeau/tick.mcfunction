scoreboard players add #fcorbeau bs.an 1
execute if score #acorbeau bs.an matches 1 run function boss:rig/corbeau/a/marche/t
execute if score #acorbeau bs.an matches 2 run function boss:rig/corbeau/a/repos/t
execute if score #acorbeau bs.an matches 3 run function boss:rig/corbeau/a/torsion/t
execute if score #acorbeau bs.an matches 4 run function boss:rig/corbeau/a/fauchage/t
execute if score #acorbeau bs.an matches 5 run function boss:rig/corbeau/a/nuee/t
execute if score #acorbeau bs.an matches 6 run function boss:rig/corbeau/a/dispersion/t
execute if score #acorbeau bs.an matches 7 run function boss:rig/corbeau/a/cache/t
execute if score #acorbeau bs.an matches 8 run function boss:rig/corbeau/a/reforme/t
execute if score #acorbeau bs.an matches 9 run function boss:rig/corbeau/a/croix/t
execute if score #acorbeau bs.an matches 10 run function boss:rig/corbeau/a/charge/t
execute if score #acorbeau bs.an matches 11 run function boss:rig/corbeau/a/sonne/t
execute if score #acorbeau bs.an matches 12 run function boss:rig/corbeau/a/apparition/t
execute if score #acorbeau bs.an matches 13 run function boss:rig/corbeau/a/mort/t
