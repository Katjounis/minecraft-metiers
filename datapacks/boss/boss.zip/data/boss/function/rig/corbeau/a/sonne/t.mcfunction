execute if score #fcorbeau bs.an matches 10 run function boss:rig/corbeau/a/sonne/k1
execute if score #fcorbeau bs.an matches 20.. run scoreboard players set #fcorbeau bs.an 0
execute if score #fcorbeau bs.an matches 0 run function boss:rig/corbeau/a/sonne/k0
