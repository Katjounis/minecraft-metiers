execute if score #fcorbeau bs.an matches 8 run function boss:rig/corbeau/a/mort/k1
execute if score #fcorbeau bs.an matches 24 run function boss:rig/corbeau/a/mort/k2
execute if score #fcorbeau bs.an matches 54.. run scoreboard players set #acorbeau bs.an 0
