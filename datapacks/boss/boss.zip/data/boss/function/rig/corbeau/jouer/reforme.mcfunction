scoreboard players set #acorbeau bs.an 8
scoreboard players set #fcorbeau bs.an 0
function boss:rig/corbeau/a/reforme/k0
