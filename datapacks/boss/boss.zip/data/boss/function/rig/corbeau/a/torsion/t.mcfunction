execute if score #fcorbeau bs.an matches 6 run function boss:rig/corbeau/a/torsion/k1
execute if score #fcorbeau bs.an matches 10 run function boss:rig/corbeau/a/torsion/k2
execute if score #fcorbeau bs.an matches 20 run function boss:rig/corbeau/a/torsion/k3
execute if score #fcorbeau bs.an matches 26.. run function boss:c/anim_defaut
