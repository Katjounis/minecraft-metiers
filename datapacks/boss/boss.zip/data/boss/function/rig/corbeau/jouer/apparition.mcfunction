scoreboard players set #acorbeau bs.an 12
scoreboard players set #fcorbeau bs.an 0
function boss:rig/corbeau/a/apparition/k0
