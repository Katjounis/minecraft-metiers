execute if score #fcorbeau bs.an matches 14 run function boss:rig/corbeau/a/fauchage/k1
execute if score #fcorbeau bs.an matches 20 run function boss:rig/corbeau/a/fauchage/k2
execute if score #fcorbeau bs.an matches 23 run function boss:rig/corbeau/a/fauchage/k3
execute if score #fcorbeau bs.an matches 26 run function boss:rig/corbeau/a/fauchage/k4
execute if score #fcorbeau bs.an matches 29 run function boss:rig/corbeau/a/fauchage/k5
execute if score #fcorbeau bs.an matches 32 run function boss:rig/corbeau/a/fauchage/k6
execute if score #fcorbeau bs.an matches 42.. run function boss:c/anim_defaut
