scoreboard players set #acorbeau bs.an 10
scoreboard players set #fcorbeau bs.an 0
function boss:rig/corbeau/a/charge/k0
