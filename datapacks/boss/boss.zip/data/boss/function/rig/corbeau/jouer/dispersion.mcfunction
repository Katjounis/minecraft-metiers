scoreboard players set #acorbeau bs.an 6
scoreboard players set #fcorbeau bs.an 0
function boss:rig/corbeau/a/dispersion/k0
