scoreboard players set #acorbeau bs.an 4
scoreboard players set #fcorbeau bs.an 0
function boss:rig/corbeau/a/fauchage/k0
