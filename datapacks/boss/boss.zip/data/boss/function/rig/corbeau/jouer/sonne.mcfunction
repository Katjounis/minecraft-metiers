scoreboard players set #acorbeau bs.an 11
scoreboard players set #fcorbeau bs.an 0
function boss:rig/corbeau/a/sonne/k0
