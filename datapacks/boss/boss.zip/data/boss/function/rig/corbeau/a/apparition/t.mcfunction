execute if score #fcorbeau bs.an matches 1 run function boss:rig/corbeau/a/apparition/k1
execute if score #fcorbeau bs.an matches 41 run function boss:rig/corbeau/a/apparition/k2
execute if score #fcorbeau bs.an matches 51 run function boss:rig/corbeau/a/apparition/k3
execute if score #fcorbeau bs.an matches 63.. run function boss:c/anim_defaut
