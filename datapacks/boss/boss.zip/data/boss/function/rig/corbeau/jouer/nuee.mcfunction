scoreboard players set #acorbeau bs.an 5
scoreboard players set #fcorbeau bs.an 0
function boss:rig/corbeau/a/nuee/k0
