scoreboard players set #acorbeau bs.an 2
scoreboard players set #fcorbeau bs.an 0
function boss:rig/corbeau/a/repos/k0
