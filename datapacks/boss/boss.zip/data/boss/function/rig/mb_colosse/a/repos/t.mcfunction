execute if score #fmb_colosse bs.an matches 30 run function boss:rig/mb_colosse/a/repos/k1
execute if score #fmb_colosse bs.an matches 60.. run scoreboard players set #fmb_colosse bs.an 0
execute if score #fmb_colosse bs.an matches 0 run function boss:rig/mb_colosse/a/repos/k0
