scoreboard players set #amb_colosse bs.an 3
scoreboard players set #fmb_colosse bs.an 0
function boss:rig/mb_colosse/a/attaque/k0
