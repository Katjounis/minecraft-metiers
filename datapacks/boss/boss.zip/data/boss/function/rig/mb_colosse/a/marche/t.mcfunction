execute if score #fmb_colosse bs.an matches 8 run function boss:rig/mb_colosse/a/marche/k1
execute if score #fmb_colosse bs.an matches 12 run function boss:rig/mb_colosse/a/marche/k2
execute if score #fmb_colosse bs.an matches 20 run function boss:rig/mb_colosse/a/marche/k3
execute if score #fmb_colosse bs.an matches 24.. run scoreboard players set #fmb_colosse bs.an 0
execute if score #fmb_colosse bs.an matches 0 run function boss:rig/mb_colosse/a/marche/k0
