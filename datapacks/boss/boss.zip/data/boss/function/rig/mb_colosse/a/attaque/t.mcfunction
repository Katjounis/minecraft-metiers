execute if score #fmb_colosse bs.an matches 8 run function boss:rig/mb_colosse/a/attaque/k1
execute if score #fmb_colosse bs.an matches 12 run function boss:rig/mb_colosse/a/attaque/k2
execute if score #fmb_colosse bs.an matches 24.. run function boss:metiers/mb_colosse_defaut
