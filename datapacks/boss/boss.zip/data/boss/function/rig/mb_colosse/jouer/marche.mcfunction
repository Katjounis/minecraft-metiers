scoreboard players set #amb_colosse bs.an 2
scoreboard players set #fmb_colosse bs.an 0
function boss:rig/mb_colosse/a/marche/k0
