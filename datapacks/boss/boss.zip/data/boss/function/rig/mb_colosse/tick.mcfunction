scoreboard players add #fmb_colosse bs.an 1
execute if score #amb_colosse bs.an matches 1 run function boss:rig/mb_colosse/a/repos/t
execute if score #amb_colosse bs.an matches 2 run function boss:rig/mb_colosse/a/marche/t
execute if score #amb_colosse bs.an matches 3 run function boss:rig/mb_colosse/a/attaque/t
