execute if score #fmb_reine bs.an matches 6 run function boss:rig/mb_reine/a/marche/k1
execute if score #fmb_reine bs.an matches 12.. run scoreboard players set #fmb_reine bs.an 0
execute if score #fmb_reine bs.an matches 0 run function boss:rig/mb_reine/a/marche/k0
