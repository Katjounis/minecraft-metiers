scoreboard players add #fmb_reine bs.an 1
execute if score #amb_reine bs.an matches 1 run function boss:rig/mb_reine/a/repos/t
execute if score #amb_reine bs.an matches 2 run function boss:rig/mb_reine/a/marche/t
execute if score #amb_reine bs.an matches 3 run function boss:rig/mb_reine/a/attaque/t
