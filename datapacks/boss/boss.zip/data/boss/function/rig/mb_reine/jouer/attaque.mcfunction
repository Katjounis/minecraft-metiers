scoreboard players set #amb_reine bs.an 3
scoreboard players set #fmb_reine bs.an 0
function boss:rig/mb_reine/a/attaque/k0
