execute if score #fmb_reine bs.an matches 6 run function boss:rig/mb_reine/a/attaque/k1
execute if score #fmb_reine bs.an matches 10 run function boss:rig/mb_reine/a/attaque/k2
execute if score #fmb_reine bs.an matches 20.. run function boss:metiers/mb_reine_defaut
