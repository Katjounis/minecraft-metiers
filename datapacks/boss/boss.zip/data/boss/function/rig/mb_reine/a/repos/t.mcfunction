execute if score #fmb_reine bs.an matches 24 run function boss:rig/mb_reine/a/repos/k1
execute if score #fmb_reine bs.an matches 48.. run scoreboard players set #fmb_reine bs.an 0
execute if score #fmb_reine bs.an matches 0 run function boss:rig/mb_reine/a/repos/k0
