kill @e[type=minecraft:item_display,tag=bs.os.mb_reine]
