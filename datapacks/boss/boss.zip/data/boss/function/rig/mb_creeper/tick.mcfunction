scoreboard players add #fmb_creeper bs.an 1
execute if score #amb_creeper bs.an matches 1 run function boss:rig/mb_creeper/a/repos/t
execute if score #amb_creeper bs.an matches 2 run function boss:rig/mb_creeper/a/marche/t
execute if score #amb_creeper bs.an matches 3 run function boss:rig/mb_creeper/a/attaque/t
