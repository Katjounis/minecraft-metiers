scoreboard players set #amb_creeper bs.an 3
scoreboard players set #fmb_creeper bs.an 0
function boss:rig/mb_creeper/a/attaque/k0
