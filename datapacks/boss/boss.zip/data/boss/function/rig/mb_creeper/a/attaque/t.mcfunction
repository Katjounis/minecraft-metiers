execute if score #fmb_creeper bs.an matches 10 run function boss:rig/mb_creeper/a/attaque/k1
execute if score #fmb_creeper bs.an matches 14 run function boss:rig/mb_creeper/a/attaque/k2
execute if score #fmb_creeper bs.an matches 20 run function boss:rig/mb_creeper/a/attaque/k3
execute if score #fmb_creeper bs.an matches 30.. run function boss:metiers/mb_creeper_defaut
