scoreboard players set #amb_creeper bs.an 2
scoreboard players set #fmb_creeper bs.an 0
function boss:rig/mb_creeper/a/marche/k0
