execute if score #fmb_creeper bs.an matches 7 run function boss:rig/mb_creeper/a/marche/k1
execute if score #fmb_creeper bs.an matches 14.. run scoreboard players set #fmb_creeper bs.an 0
execute if score #fmb_creeper bs.an matches 0 run function boss:rig/mb_creeper/a/marche/k0
