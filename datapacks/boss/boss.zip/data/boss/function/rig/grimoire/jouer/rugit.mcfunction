scoreboard players set #agrimoire bs.an 5
scoreboard players set #fgrimoire bs.an 0
function boss:rig/grimoire/a/rugit/k0
