scoreboard players set #agrimoire bs.an 6
scoreboard players set #fgrimoire bs.an 0
function boss:rig/grimoire/a/apparition/k0
