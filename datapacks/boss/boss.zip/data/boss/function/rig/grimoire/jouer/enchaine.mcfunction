scoreboard players set #agrimoire bs.an 4
scoreboard players set #fgrimoire bs.an 0
function boss:rig/grimoire/a/enchaine/k0
