scoreboard players set #agrimoire bs.an 7
scoreboard players set #fgrimoire bs.an 0
function boss:rig/grimoire/a/mort/k0
