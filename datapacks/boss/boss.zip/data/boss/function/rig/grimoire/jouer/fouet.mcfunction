scoreboard players set #agrimoire bs.an 3
scoreboard players set #fgrimoire bs.an 0
function boss:rig/grimoire/a/fouet/k0
