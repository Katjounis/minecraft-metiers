execute if score #fgrimoire bs.an matches 20 run function boss:rig/grimoire/a/vol/k1
execute if score #fgrimoire bs.an matches 40.. run scoreboard players set #fgrimoire bs.an 0
execute if score #fgrimoire bs.an matches 0 run function boss:rig/grimoire/a/vol/k0
