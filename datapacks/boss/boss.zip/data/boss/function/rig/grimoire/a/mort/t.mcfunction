execute if score #fgrimoire bs.an matches 6 run function boss:rig/grimoire/a/mort/k1
execute if score #fgrimoire bs.an matches 30 run function boss:rig/grimoire/a/mort/k2
execute if score #fgrimoire bs.an matches 60.. run scoreboard players set #agrimoire bs.an 0
