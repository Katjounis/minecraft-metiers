execute if score #fgrimoire bs.an matches 10 run function boss:rig/grimoire/a/fouet/k1
execute if score #fgrimoire bs.an matches 14 run function boss:rig/grimoire/a/fouet/k2
execute if score #fgrimoire bs.an matches 24.. run function boss:g/anim_defaut
