execute if score #fgrimoire bs.an matches 12 run function boss:rig/grimoire/a/pages/k1
execute if score #fgrimoire bs.an matches 16 run function boss:rig/grimoire/a/pages/k2
execute if score #fgrimoire bs.an matches 26.. run function boss:g/anim_defaut
