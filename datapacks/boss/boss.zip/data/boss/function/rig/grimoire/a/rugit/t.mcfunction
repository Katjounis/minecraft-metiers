execute if score #fgrimoire bs.an matches 8 run function boss:rig/grimoire/a/rugit/k1
execute if score #fgrimoire bs.an matches 32 run function boss:rig/grimoire/a/rugit/k2
execute if score #fgrimoire bs.an matches 42.. run function boss:g/anim_defaut
