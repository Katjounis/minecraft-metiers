scoreboard players set #agrimoire bs.an 2
scoreboard players set #fgrimoire bs.an 0
function boss:rig/grimoire/a/pages/k0
