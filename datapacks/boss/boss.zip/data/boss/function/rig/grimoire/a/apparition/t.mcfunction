execute if score #fgrimoire bs.an matches 1 run function boss:rig/grimoire/a/apparition/k1
execute if score #fgrimoire bs.an matches 21 run function boss:rig/grimoire/a/apparition/k2
execute if score #fgrimoire bs.an matches 35 run function boss:rig/grimoire/a/apparition/k3
execute if score #fgrimoire bs.an matches 43 run function boss:rig/grimoire/a/apparition/k4
execute if score #fgrimoire bs.an matches 53.. run function boss:g/anim_defaut
