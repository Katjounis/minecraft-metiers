execute if score #fgrimoire bs.an matches 4 run function boss:rig/grimoire/a/enchaine/k1
execute if score #fgrimoire bs.an matches 8.. run scoreboard players set #fgrimoire bs.an 0
execute if score #fgrimoire bs.an matches 0 run function boss:rig/grimoire/a/enchaine/k0
