scoreboard players set #agrimoire bs.an 1
scoreboard players set #fgrimoire bs.an 0
function boss:rig/grimoire/a/vol/k0
