scoreboard players add #fgrimoire bs.an 1
execute if score #agrimoire bs.an matches 1 run function boss:rig/grimoire/a/vol/t
execute if score #agrimoire bs.an matches 2 run function boss:rig/grimoire/a/pages/t
execute if score #agrimoire bs.an matches 3 run function boss:rig/grimoire/a/fouet/t
execute if score #agrimoire bs.an matches 4 run function boss:rig/grimoire/a/enchaine/t
execute if score #agrimoire bs.an matches 5 run function boss:rig/grimoire/a/rugit/t
execute if score #agrimoire bs.an matches 6 run function boss:rig/grimoire/a/apparition/t
execute if score #agrimoire bs.an matches 7 run function boss:rig/grimoire/a/mort/t
