tag @s remove bs.in
execute if score @s bs.ins = #eid bs.ev run tag @s add bs.in
