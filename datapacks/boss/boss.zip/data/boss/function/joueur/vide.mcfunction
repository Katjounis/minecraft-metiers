tellraw @a[tag=bs.joue] [{"text":"[Boss] ","color":"dark_red","bold":true},{"selector":"@s","color":"white"},{"text":" est tombé dans le vide !","color":"gray","bold":false}]
function boss:joueur/ko
