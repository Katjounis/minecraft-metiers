advancement revoke @s only boss:frappe
execute if score #boss bs.ev matches 1 run playsound minecraft:item.book.page_turn hostile @a[distance=..24] ~ ~ ~ 1.5 0.6
execute if score #boss bs.ev matches 2 run playsound minecraft:block.wood.break hostile @a[distance=..24] ~ ~ ~ 1.5 0.6
