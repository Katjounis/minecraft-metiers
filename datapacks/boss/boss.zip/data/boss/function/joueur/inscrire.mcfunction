execute if score #etat bs.ev matches 2..3 unless entity @s[tag=bs.joue] run return run tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Le combat a déjà commencé. ","color":"gray","bold":false},{"text":"[REGARDER]","color":"aqua","bold":true,"click_event":{"action":"run_command","command":"/trigger bs.rejoindre set 3"}}]
execute unless score #etat bs.ev matches 1 run return run tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Aucune arène de boss n’est ouverte pour le moment.","color":"gray","bold":false}]
execute if score @s bs.ins = #eid bs.ev run return run tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Tu es déjà inscrit.","color":"gray","bold":false}]
scoreboard players operation @s bs.ins = #eid bs.ev
execute as @a run function boss:joueur/est_inscrit
execute store result score #n bs.tmp if entity @a[tag=bs.in]
tellraw @a [{"text":"[Boss] ","color":"dark_red","bold":true},{"selector":"@s","color":"white"},{"text":" rejoint le combat (","color":"gray","bold":false},{"score":{"name":"#n","objective":"bs.tmp"},"color":"yellow"},{"text":" inscrit(s)).","color":"gray","bold":false}]
playsound minecraft:item.goat_horn.sound.1 master @s ~ ~ ~ 0.6 1
