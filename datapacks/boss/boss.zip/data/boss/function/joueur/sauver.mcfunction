execute store result score @s bs.rx run data get entity @s Pos[0] 10
execute store result score @s bs.ry run data get entity @s Pos[1] 10
execute store result score @s bs.rz run data get entity @s Pos[2] 10
scoreboard players set @s bs.rd 0
execute if dimension minecraft:the_nether run scoreboard players set @s bs.rd 1
execute if dimension minecraft:the_end run scoreboard players set @s bs.rd 2
scoreboard players set @s bs.gm 0
execute if entity @s[gamemode=creative] run scoreboard players set @s bs.gm 1
execute if entity @s[gamemode=adventure] run scoreboard players set @s bs.gm 2
