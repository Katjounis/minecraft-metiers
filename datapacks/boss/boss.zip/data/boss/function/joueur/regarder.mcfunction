execute unless score #etat bs.ev matches 3 run return run tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Pas de combat à regarder pour le moment.","color":"gray","bold":false}]
execute if entity @s[tag=bs.joue] run return 0
execute if entity @s[tag=bs.spec] run return 0
function boss:joueur/sauver
scoreboard players operation @s bs.cid = #eid bs.ev
tag @s add bs.spec
gamemode spectator @s
execute if score #boss bs.ev matches 1 in boss:grimoire run tp @s 0 114 22 180 30
execute if score #boss bs.ev matches 2 in boss:corbeau run tp @s 0 79 26 180 30
tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Tu regardes le combat. ","color":"gray","bold":false},{"text":"[QUITTER]","color":"red","click_event":{"action":"run_command","command":"/trigger bs.rejoindre set 4"}}]
