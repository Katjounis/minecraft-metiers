execute if score #etat bs.ev matches 1 if score @s bs.ins = #eid bs.ev run return run function boss:joueur/desinscrire
tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"D’accord, ce sera pour la prochaine fois.","color":"gray","bold":false}]
