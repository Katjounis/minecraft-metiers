execute if score @s bs.rejoindre matches 1 run function boss:joueur/inscrire
execute if score @s bs.rejoindre matches 2 run function boss:joueur/refuser
execute if score @s bs.rejoindre matches 3 run function boss:joueur/regarder
execute if score @s bs.rejoindre matches 4 run function boss:joueur/quitter
scoreboard players set @s bs.rejoindre 0
