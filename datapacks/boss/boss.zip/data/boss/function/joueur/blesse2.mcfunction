$damage @s $(d) minecraft:mob_attack
