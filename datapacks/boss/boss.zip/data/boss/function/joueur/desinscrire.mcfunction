scoreboard players set @s bs.ins 0
tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Tu ne participes plus à ce combat.","color":"gray","bold":false}]
