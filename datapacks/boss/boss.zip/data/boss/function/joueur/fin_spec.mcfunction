tag @s remove bs.spec
execute if score @s bs.gm matches 0 run gamemode survival @s
execute if score @s bs.gm matches 1 run gamemode creative @s
execute if score @s bs.gm matches 2 run gamemode adventure @s
