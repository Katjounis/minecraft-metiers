scoreboard players set @s bs.mort 0
execute unless score @s bs.cid = #eid bs.ev run return 0
execute unless score #etat bs.ev matches 2..4 run return 0
execute unless entity @s[tag=bs.joue] run return 0
tag @s remove bs.joue
function boss:joueur/retour
