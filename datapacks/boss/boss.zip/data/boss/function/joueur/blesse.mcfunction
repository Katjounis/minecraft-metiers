$scoreboard players set #d bs.tmp $(d)
scoreboard players operation #d bs.tmp *= #pw bs.ev
scoreboard players operation #d bs.tmp /= #100 bs.tmp
scoreboard players operation #lim bs.tmp = #d bs.tmp
scoreboard players add #lim bs.tmp 6
execute if score @s bs.pv <= #lim bs.tmp run return run function boss:joueur/ko
execute store result storage boss:t bl.d int 1 run scoreboard players get #d bs.tmp
function boss:joueur/blesse2 with storage boss:t bl
