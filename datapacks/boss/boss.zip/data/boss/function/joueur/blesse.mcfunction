$execute if score @s bs.pv matches ..$(lim) run return run function boss:joueur/ko
$damage @s $(d) minecraft:mob_attack
