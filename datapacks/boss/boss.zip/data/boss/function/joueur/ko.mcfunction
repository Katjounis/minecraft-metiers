tag @s remove bs.joue
tag @s add bs.ko
effect give @s minecraft:instant_health 1 3 true
effect give @s minecraft:regeneration 10 1 true
title @s times 8 60 16
title @s subtitle {"text":"Tu es renvoyé chez toi, sans rien perdre. Tu auras ta part si tes alliés gagnent.","color":"gray"}
title @s title {"text":"K.O.","color":"red","bold":true}
tellraw @a[tag=bs.joue] [{"text":"[Boss] ","color":"dark_red","bold":true},{"selector":"@s","color":"white"},{"text":" est K.O. !","color":"red","bold":false}]
playsound minecraft:entity.player.hurt_on_fire master @s ~ ~ ~ 1 0.6
function boss:joueur/retour
