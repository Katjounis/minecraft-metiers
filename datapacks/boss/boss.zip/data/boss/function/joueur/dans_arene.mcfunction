scoreboard players set #ok bs.tmp 0
execute if score #etat bs.ev matches 2..4 if score @s bs.cid = #eid bs.ev if entity @s[tag=bs.joue] run scoreboard players set #ok bs.tmp 1
execute if score #etat bs.ev matches 2..4 if score @s bs.cid = #eid bs.ev if entity @s[tag=bs.spec] run scoreboard players set #ok bs.tmp 1
execute if score #etat bs.ev matches 4 if score @s bs.cid = #eid bs.ev run scoreboard players set #ok bs.tmp 1
execute if entity @s[gamemode=creative] unless score @s bs.cid = #eid bs.ev run scoreboard players set #ok bs.tmp 1
execute if score #ok bs.tmp matches 0 run function boss:joueur/retour
