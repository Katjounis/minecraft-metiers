execute if entity @s[tag=bs.spec] run return run function boss:joueur/retour
execute unless entity @s[tag=bs.joue] run return 0
scoreboard players set @s bs.ins 0
tag @s remove bs.joue
tellraw @a [{"text":"[Boss] ","color":"dark_red","bold":true},{"selector":"@s","color":"white"},{"text":" abandonne le combat.","color":"gray","bold":false}]
function boss:joueur/retour
