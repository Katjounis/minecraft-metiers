tag @s remove bs.joue
tag @s remove bs.ko
execute if entity @s[tag=bs.spec] run function boss:joueur/fin_spec
execute if score @s bs.gm matches 0 if entity @s[gamemode=adventure] run gamemode survival @s
execute unless score @s bs.rx = @s bs.rx run return run execute in minecraft:overworld run spreadplayers 0 0 0 1 false @s
execute store result storage boss:r x double 0.1 run scoreboard players get @s bs.rx
execute store result storage boss:r y double 0.1 run scoreboard players get @s bs.ry
execute store result storage boss:r z double 0.1 run scoreboard players get @s bs.rz
data modify storage boss:r d set value "minecraft:overworld"
execute if score @s bs.rd matches 1 run data modify storage boss:r d set value "minecraft:the_nether"
execute if score @s bs.rd matches 2 run data modify storage boss:r d set value "minecraft:the_end"
function boss:joueur/retour_m with storage boss:r
effect clear @s minecraft:darkness
effect clear @s minecraft:slowness
effect clear @s minecraft:wither
effect give @s minecraft:resistance 5 4 true
effect give @s minecraft:slow_falling 5 0 true
