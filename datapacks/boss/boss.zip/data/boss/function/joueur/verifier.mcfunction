execute if dimension boss:grimoire run function boss:joueur/dans_arene
execute if dimension boss:corbeau run function boss:joueur/dans_arene
execute unless dimension boss:grimoire unless dimension boss:corbeau if entity @s[tag=bs.spec] run function boss:joueur/fin_spec
execute unless dimension boss:grimoire unless dimension boss:corbeau if entity @s[tag=bs.joue] run tag @s remove bs.joue
