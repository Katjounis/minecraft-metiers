function boss:joueur/sauver
scoreboard players operation @s bs.cid = #eid bs.ev
tag @s add bs.joue
tag @s remove bs.ko
execute if score #boss bs.ev matches 1 if score #slot bs.tmp matches 0 in boss:grimoire run tp @s 10.5 101 0.5 facing 0 104 0
execute if score #boss bs.ev matches 1 if score #slot bs.tmp matches 1 in boss:grimoire run tp @s 7.5 101 7.5 facing 0 104 0
execute if score #boss bs.ev matches 1 if score #slot bs.tmp matches 2 in boss:grimoire run tp @s 0.5 101 10.5 facing 0 104 0
execute if score #boss bs.ev matches 1 if score #slot bs.tmp matches 3 in boss:grimoire run tp @s -6.5 101 7.5 facing 0 104 0
execute if score #boss bs.ev matches 1 if score #slot bs.tmp matches 4 in boss:grimoire run tp @s -9.5 101 0.5 facing 0 104 0
execute if score #boss bs.ev matches 1 if score #slot bs.tmp matches 5 in boss:grimoire run tp @s -6.5 101 -6.5 facing 0 104 0
execute if score #boss bs.ev matches 1 if score #slot bs.tmp matches 6 in boss:grimoire run tp @s 0.5 101 -9.5 facing 0 104 0
execute if score #boss bs.ev matches 1 if score #slot bs.tmp matches 7 in boss:grimoire run tp @s 7.5 101 -6.5 facing 0 104 0
execute if score #boss bs.ev matches 2 if score #slot bs.tmp matches 0 in boss:corbeau run tp @s 12.5 64 0.5 facing 0 66 0
execute if score #boss bs.ev matches 2 if score #slot bs.tmp matches 1 in boss:corbeau run tp @s 8.5 64 8.5 facing 0 66 0
execute if score #boss bs.ev matches 2 if score #slot bs.tmp matches 2 in boss:corbeau run tp @s 0.5 64 12.5 facing 0 66 0
execute if score #boss bs.ev matches 2 if score #slot bs.tmp matches 3 in boss:corbeau run tp @s -7.5 64 8.5 facing 0 66 0
execute if score #boss bs.ev matches 2 if score #slot bs.tmp matches 4 in boss:corbeau run tp @s -11.5 64 0.5 facing 0 66 0
execute if score #boss bs.ev matches 2 if score #slot bs.tmp matches 5 in boss:corbeau run tp @s -7.5 64 -7.5 facing 0 66 0
execute if score #boss bs.ev matches 2 if score #slot bs.tmp matches 6 in boss:corbeau run tp @s 0.5 64 -11.5 facing 0 66 0
execute if score #boss bs.ev matches 2 if score #slot bs.tmp matches 7 in boss:corbeau run tp @s 8.5 64 -7.5 facing 0 66 0
scoreboard players add #slot bs.tmp 1
execute if score #slot bs.tmp matches 8.. run scoreboard players set #slot bs.tmp 0
execute if score @s bs.gm matches 0 run gamemode adventure @s
effect give @s minecraft:resistance 6 4 true
effect give @s minecraft:instant_health 1 2 true
scoreboard players set @s bs.vu 0
