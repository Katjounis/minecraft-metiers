scoreboard players set #rgj bs.ev 0
execute as @a[tag=bs.joue] if score @s m.total matches 1.. run scoreboard players operation #rgj bs.ev > @s m.total
scoreboard players operation #rg bs.ev = #rgj bs.ev
scoreboard players operation #rg bs.ev /= #50 bs.tmp
execute if score #rg bs.ev matches 25.. run scoreboard players set #rg bs.ev 24
scoreboard players operation #pw bs.ev = #rg bs.ev
scoreboard players operation #pw bs.ev *= #8 bs.tmp
scoreboard players add #pw bs.ev 100
scoreboard players operation #mul bs.ev = #rg bs.ev
scoreboard players operation #mul bs.ev *= #15 bs.tmp
scoreboard players add #mul bs.ev 100
tellraw @a[tag=bs.joue] [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Le boss se cale sur le meilleur d'entre vous (","color":"gray","bold":false},{"score":{"name":"#rgj","objective":"bs.ev"},"color":"yellow"},{"text":" points de métiers) : rang ","color":"gray","bold":false},{"score":{"name":"#rg","objective":"bs.ev"},"color":"red","bold":true},{"text":".","color":"gray","bold":false}]
