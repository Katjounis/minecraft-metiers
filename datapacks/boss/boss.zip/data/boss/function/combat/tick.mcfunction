execute if score #boss bs.ev matches 1 run function boss:g/tick
execute if score #boss bs.ev matches 2 run function boss:c/tick
function boss:min/tick
execute as @a[tag=bs.joue] if score @s bs.pv matches ..6 run function boss:joueur/ko
execute as @a[tag=bs.joue] at @s if dimension boss:grimoire if entity @s[y=-100,dy=190] run function boss:joueur/vide
execute as @a[tag=bs.joue] at @s if dimension boss:corbeau if entity @s[y=-100,dy=155] run function boss:joueur/vide
execute store result bossbar boss:combat value run data get entity @e[tag=bs.hb,limit=1] Health
execute if score #etat bs.ev matches 3 if score #lance bs.ev matches 1 unless entity @e[tag=bs.hb] run function boss:ev/victoire
