execute unless score #on bs.ev matches 1 run return 0
execute unless entity @a[gamemode=!spectator] run return 0
scoreboard players remove #t bs.ev 1
execute if score #t bs.ev matches ..0 run function boss:ev/declencher
