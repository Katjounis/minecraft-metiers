scoreboard players add #duree bs.ev 1
execute in boss:grimoire run bossbar set boss:combat players @a[distance=0..]
execute if score #boss bs.ev matches 2 in boss:corbeau run bossbar set boss:combat players @a[distance=0..]
execute unless entity @a[tag=bs.joue] run return run function boss:ev/defaite
execute if score #duree bs.ev matches 900.. run return run function boss:ev/defaite
