scoreboard players set #etat bs.ev 4
scoreboard players set #fin bs.ev 6
execute if score #boss bs.ev matches 1 run function boss:rig/grimoire/jouer/rugit
execute if score #boss bs.ev matches 2 run function boss:rig/corbeau/jouer/dispersion
tp @e[tag=bs.hb] ~ -500 ~
kill @e[tag=bs.hb]
kill @e[tag=bs.min]
kill @e[tag=bs.mind]
kill @e[tag=bs.fx]
bossbar set boss:combat visible false
execute if score #duree bs.ev matches 900.. run tellraw @a [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Le combat a trop duré : le boss s’en va. Il reviendra…","color":"gray","bold":false}]
execute if score #duree bs.ev matches ..899 run tellraw @a [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Tous les combattants sont K.O. : le boss l’emporte cette fois.","color":"gray","bold":false}]
title @a[tag=bs.joue] times 8 60 16
title @a[tag=bs.joue] subtitle {"text":"Retour dans quelques secondes","color":"gray"}
title @a[tag=bs.joue] title {"text":"Défaite…","color":"red","bold":true}
