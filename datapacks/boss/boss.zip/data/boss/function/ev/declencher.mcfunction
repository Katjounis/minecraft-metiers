scoreboard players set #occupe bs.tmp 0
execute if score #actif m.boss matches 1 run scoreboard players set #occupe bs.tmp 1
execute if score #compte m.boss matches 1.. run scoreboard players set #occupe bs.tmp 1
execute if entity @e[tag=hr.c.croque] run scoreboard players set #occupe bs.tmp 1
execute if score #occupe bs.tmp matches 1 run return run scoreboard players set #t bs.ev 300
execute unless score #force bs.ev matches 1..2 store result score #boss bs.ev run random value 1..2
execute if score #force bs.ev matches 1..2 run scoreboard players operation #boss bs.ev = #force bs.ev
scoreboard players set #force bs.ev 0
function boss:ev/ouvrir
