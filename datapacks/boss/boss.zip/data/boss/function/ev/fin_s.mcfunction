scoreboard players remove #fin bs.ev 1
execute if score #fin bs.ev matches 8 run kill @e[type=minecraft:item_display,tag=bs.os]
execute if score #fin bs.ev matches ..0 run function boss:ev/cloture
