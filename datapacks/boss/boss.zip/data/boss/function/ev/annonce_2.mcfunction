title @a times 8 60 16
title @a subtitle {"text":"Le Corbeau-Épouvantail apparaît dans 2 minutes","color":"gray"}
title @a title {"text":"Une lune rouge se lève…","color":"dark_red","bold":true}
dialog show @a boss:appel_corbeau
function boss:ev/chat_2
