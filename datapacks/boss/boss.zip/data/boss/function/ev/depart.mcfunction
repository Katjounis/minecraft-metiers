execute as @a run function boss:joueur/est_inscrit
execute store result score #n bs.ev if entity @a[tag=bs.in]
execute if score #n bs.ev matches 0 run return run function boss:ev/personne
scoreboard players set #etat bs.ev 2
scoreboard players set #intro bs.ev 6
scoreboard players set #slot bs.tmp 0
scoreboard players set #duree bs.ev 0
scoreboard players set #lance bs.ev 0
execute as @a[tag=bs.in] at @s run function boss:joueur/entrer
execute if score #boss bs.ev matches 1 run function boss:arene/g/preparer
execute if score #boss bs.ev matches 2 run function boss:arene/c/preparer
