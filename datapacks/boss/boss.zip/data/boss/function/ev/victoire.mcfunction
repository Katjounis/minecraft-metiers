scoreboard players set #etat bs.ev 4
scoreboard players set #fin bs.ev 12
execute if score #boss bs.ev matches 1 run function boss:rig/grimoire/jouer/mort
execute if score #boss bs.ev matches 2 run function boss:rig/corbeau/jouer/mort
execute as @a run function boss:joueur/est_inscrit
title @a[tag=bs.in] times 8 60 16
title @a[tag=bs.in] subtitle {"text":"Retour dans 12 s","color":"yellow"}
title @a[tag=bs.in] title {"text":"VICTOIRE !","color":"gold","bold":true}
execute as @a[tag=bs.in] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.8
execute as @a[tag=bs.in] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 0.6
execute if score #boss bs.ev matches 1 run tellraw @a [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Le Grimoire Vivant","color":"light_purple","bold":true},{"text":" est vaincu ! Bravo aux ","color":"gray","bold":false},{"score":{"name":"#n","objective":"bs.ev"},"color":"yellow"},{"text":" combattants.","color":"gray","bold":false}]
execute if score #boss bs.ev matches 2 run tellraw @a [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Le Corbeau-Épouvantail","color":"dark_red","bold":true},{"text":" est vaincu ! Bravo aux ","color":"gray","bold":false},{"score":{"name":"#n","objective":"bs.ev"},"color":"yellow"},{"text":" combattants.","color":"gray","bold":false}]
execute as @a[tag=bs.in] at @s run function boss:recompense/donner
kill @e[tag=bs.min]
kill @e[tag=bs.mind]
kill @e[tag=bs.fx]
bossbar set boss:combat visible false
