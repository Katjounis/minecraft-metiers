$execute store result score #t bs.ev run random value $(a)..$(b)
