scoreboard players remove #intro bs.ev 1
execute if score #intro bs.ev matches 1 run title @a[tag=bs.joue] title {"text":"1","color":"gold","bold":true}
execute if score #intro bs.ev matches 2 run title @a[tag=bs.joue] title {"text":"2","color":"gold","bold":true}
execute if score #intro bs.ev matches 3 run title @a[tag=bs.joue] title {"text":"3","color":"gold","bold":true}
execute if score #intro bs.ev matches 1..3 as @a[tag=bs.joue] at @s run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 1 0.7
execute if score #intro bs.ev matches 4 run title @a[tag=bs.joue] title {"text":"Préparez-vous…","color":"gray"}
execute if score #intro bs.ev matches ..0 run function boss:ev/lancer
