title @a times 8 60 16
title @a subtitle {"text":"Le Grimoire Vivant apparaît dans 2 minutes","color":"gray"}
title @a title {"text":"La Bibliothèque Interdite s'éveille…","color":"dark_purple","bold":true}
dialog show @a boss:appel_grimoire
function boss:ev/chat_1
