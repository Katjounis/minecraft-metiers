title @a times 8 60 16
title @a subtitle {"text":"Boss dans 2 minutes","color":"gray"}
title @a title {"text":"Le Grimoire","color":"dark_purple","bold":true}
dialog show @a boss:appel_grimoire
function boss:ev/chat_1
