scoreboard players remove #pv bs.ev 1
execute if score #pv bs.ev matches 90 if score #boss bs.ev matches 1 run function boss:ev/chat_1
execute if score #pv bs.ev matches 90 if score #boss bs.ev matches 2 run function boss:ev/chat_2
execute if score #pv bs.ev matches 60 if score #boss bs.ev matches 1 run function boss:ev/chat_1
execute if score #pv bs.ev matches 60 if score #boss bs.ev matches 2 run function boss:ev/chat_2
execute if score #pv bs.ev matches 30 if score #boss bs.ev matches 1 run function boss:ev/chat_1
execute if score #pv bs.ev matches 30 if score #boss bs.ev matches 2 run function boss:ev/chat_2
execute as @a run function boss:joueur/est_inscrit
execute if score #pv bs.ev matches 1..10 run title @a[tag=bs.in] actionbar [{"text":"Départ pour l'arène dans ","color":"gold"},{"score":{"name":"#pv","objective":"bs.ev"},"color":"yellow"},{"text":" s","color":"gold"}]
execute if score #pv bs.ev matches ..0 run function boss:ev/depart
