scoreboard players add #eid bs.ev 1
scoreboard players set #etat bs.ev 1
execute unless score #pvmax bs.ev matches 1.. run scoreboard players set #pvmax bs.ev 120
scoreboard players operation #pv bs.ev = #pvmax bs.ev
scoreboard players set #pvmax bs.ev 120
execute if score #boss bs.ev matches 1 in boss:grimoire run forceload add -64 -64 63 63
execute if score #boss bs.ev matches 2 in boss:corbeau run forceload add -48 -48 47 47
schedule function boss:arene/construire 60t replace
execute if score #boss bs.ev matches 1 run function boss:ev/annonce_1
execute if score #boss bs.ev matches 2 run function boss:ev/annonce_2
execute as @a at @s run playsound minecraft:entity.elder_guardian.curse master @s ~ ~ ~ 0.7 0.5
effect give @a[gamemode=!spectator] minecraft:darkness 3 0 true
