execute store result storage boss:t a int 60 run scoreboard players get #min bs.ev
execute store result storage boss:t b int 60 run scoreboard players get #max bs.ev
function boss:ev/prochain_m with storage boss:t
