execute as @a at @s if dimension boss:grimoire run function boss:joueur/retour
execute as @a at @s if dimension boss:corbeau run function boss:joueur/retour
tag @a remove bs.joue
tag @a remove bs.ko
execute as @a[tag=bs.spec] run function boss:joueur/fin_spec
kill @e[tag=bs.e]
kill @e[tag=bs.hb]
execute in boss:grimoire run kill @e[type=#minecraft:arrows,distance=0..]
execute in boss:corbeau run kill @e[type=#minecraft:arrows,distance=0..]
execute in boss:grimoire run kill @e[type=minecraft:item,distance=0..]
execute in boss:corbeau run kill @e[type=minecraft:item,distance=0..]
execute in boss:grimoire run forceload remove all
execute in boss:corbeau run forceload remove all
bossbar set boss:combat visible false
bossbar set boss:combat players
scoreboard players set #etat bs.ev 0
scoreboard players set #lance bs.ev 0
function boss:ev/prochain
