execute if score #boss bs.ev matches 1 run tellraw @a [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Personne n’a osé ouvrir le Grimoire. Il se referme dans un ricanement de pages… il reviendra.","color":"light_purple","bold":false}]
execute if score #boss bs.ev matches 2 run tellraw @a [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Personne n’est venu au champ. Le Corbeau-Épouvantail croasse de rire… il reviendra.","color":"dark_red","bold":false}]
function boss:ev/cloture
