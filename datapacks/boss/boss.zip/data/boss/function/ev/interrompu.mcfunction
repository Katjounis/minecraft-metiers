tellraw @a [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Le pack a été rechargé : l'événement de boss en cours est annulé.","color":"gray","bold":false}]
function boss:ev/cloture
