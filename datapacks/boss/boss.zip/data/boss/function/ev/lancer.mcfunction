scoreboard players set #etat bs.ev 3
scoreboard players set #lance bs.ev 1
execute if score #boss bs.ev matches 1 run function boss:g/lancer
execute if score #boss bs.ev matches 2 run function boss:c/lancer
execute store result bossbar boss:combat max run scoreboard players get #max bs.ev
execute store result bossbar boss:combat value run scoreboard players get #max bs.ev
bossbar set boss:combat visible true
