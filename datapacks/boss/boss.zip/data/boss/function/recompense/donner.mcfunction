scoreboard players set #ec bs.tmp 15000
scoreboard players operation #ec bs.tmp *= #mul bs.ev
scoreboard players operation #ec bs.tmp /= #100 bs.tmp
scoreboard players set #xc bs.tmp 600
scoreboard players operation #xc bs.tmp *= #mul bs.ev
scoreboard players operation #xc bs.tmp /= #100 bs.tmp
scoreboard players operation #el bs.tmp = #rg bs.ev
scoreboard players operation #el bs.tmp /= #4 bs.tmp
scoreboard players add #el bs.tmp 3
execute if score @s c.ecus matches -2147483648.. run scoreboard players operation @s c.ecus += #ec bs.tmp
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players operation @s m.c_bal += #xc bs.tmp
execute if score @s m.ecl matches -2147483648.. run scoreboard players operation @s m.ecl += #el bs.tmp
xp add @s 500 points
execute if score #boss bs.ev matches 1 run function boss:recompense/grimoire
execute if score #boss bs.ev matches 2 run function boss:recompense/corbeau
tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Récompense : ","color":"gold","bold":false},{"score":{"name":"#ec","objective":"bs.tmp"},"color":"yellow"},{"text":" Écus, ","color":"yellow","bold":false},{"score":{"name":"#xc","objective":"bs.tmp"},"color":"yellow"},{"text":" XP Chasseur, ","color":"yellow","bold":false},{"score":{"name":"#el","objective":"bs.tmp"},"color":"yellow"},{"text":" éclats de boss, 500 points d'XP.","color":"yellow","bold":false}]
