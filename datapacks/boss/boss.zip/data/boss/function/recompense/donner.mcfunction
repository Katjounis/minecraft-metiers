execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.ecus 15000
execute unless score @s m.afk matches 240.. if score @s m.c_bal matches -2147483648.. run scoreboard players add @s m.c_bal 600
execute if score @s m.ecl matches -2147483648.. run scoreboard players add @s m.ecl 3
xp add @s 500 points
execute if score #boss bs.ev matches 1 run function boss:recompense/grimoire
execute if score #boss bs.ev matches 2 run function boss:recompense/corbeau
tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Récompense : ","color":"gold","bold":false},{"text":"15 000 Écus, 600 XP Chasseur, 3 éclats de boss, 500 points d'XP.","color":"yellow","bold":false}]
