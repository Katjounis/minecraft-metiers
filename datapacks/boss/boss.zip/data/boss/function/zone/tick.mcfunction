scoreboard players add @s bs.k 1
execute if entity @s[tag=bs.z.marque] run return run function boss:zone/marque
execute if entity @s[tag=bs.z.pique] run return run function boss:zone/pique
kill @s
