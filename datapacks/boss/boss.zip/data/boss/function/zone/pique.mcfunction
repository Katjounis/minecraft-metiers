execute if score @s bs.k matches ..29 if score #m4 bs.ev matches 0 run function boss:zone/pique_a
execute if score @s bs.k matches ..29 run return 0
particle minecraft:crit ~ ~1 ~ 1 1 1 0.3 40
playsound minecraft:entity.phantom.bite hostile @a[distance=..24] ~ ~ ~ 2 0.7
execute as @a[tag=bs.joue,distance=..2.2] run function boss:joueur/blesse {d:8,lim:14}
kill @s
