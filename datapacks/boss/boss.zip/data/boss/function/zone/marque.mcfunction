execute if entity @a[tag=bs.marque] run tp @s @a[tag=bs.marque,limit=1]
execute if score @s bs.k matches ..49 if score #m4 bs.ev matches 0 at @s run function boss:zone/marque_a
execute if score @s bs.k matches ..49 run return 0
particle minecraft:squid_ink ~ ~1 ~ 1.5 0.6 1.5 0.1 80
particle minecraft:enchant ~ ~1 ~ 1.5 1 1.5 1 80
playsound minecraft:entity.generic.explode hostile @a[distance=..32] ~ ~ ~ 1.5 0.8
execute as @a[tag=bs.joue,distance=..3] run function boss:joueur/blesse {d:10,lim:16}
tag @a remove bs.marque
kill @s
