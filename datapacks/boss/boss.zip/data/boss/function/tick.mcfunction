scoreboard players add #tk bs.ev 1
scoreboard players operation #m4 bs.ev = #tk bs.ev
scoreboard players set #4 bs.tmp 4
scoreboard players operation #m4 bs.ev %= #4 bs.tmp
execute if score #tk bs.ev matches 20.. run function boss:seconde
execute if score #etat bs.ev matches 3..4 run function boss:combat/tick
execute if score #m4 bs.ev matches 0 run function boss:cape/tick
