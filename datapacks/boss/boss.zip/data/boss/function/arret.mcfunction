scoreboard players set #on bs.ev 0
tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Événements de boss automatiques coupés.","color":"gray","bold":false}]
