scoreboard players remove #pl bs.c 1
scoreboard players remove #ch bs.c 1
execute if score #pl bs.c matches ..0 run function boss:c/plumes
execute if score #ch bs.c matches ..0 run function boss:c/charge_debut
