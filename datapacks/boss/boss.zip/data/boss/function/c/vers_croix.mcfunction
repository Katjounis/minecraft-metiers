execute if score #t bs.c matches ..26 if score #m4 bs.ev matches 0 run particle minecraft:large_smoke ~ ~5 ~ 1 2 1 0.02 12
execute unless score #t bs.c matches 26 run return 0
data merge entity @s {Invulnerable:1b}
execute in boss:corbeau run tp @s 0 64 0 0 0
function boss:rig/corbeau/jouer/croix
scoreboard players set #etat bs.c 3
scoreboard players set #pl bs.c 60
scoreboard players set #ch bs.c 160
execute in boss:corbeau run particle minecraft:large_smoke 0 68 0 1 3 1 0.05 80
