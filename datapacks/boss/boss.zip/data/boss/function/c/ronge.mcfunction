function boss:joueur/blesse {d:1,lim:7}
title @s actionbar {"text":"La nuit te ronge : rapproche-toi d'une citrouille !","color":"dark_red"}
particle minecraft:dust{color:[0.1,0,0],scale:1} ~ ~1 ~ 0.3 0.5 0.3 0 8
