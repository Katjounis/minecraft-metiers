scoreboard players add @s bs.k 1
execute if score @s bs.k matches ..39 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.92,0.92,0.95],scale:1} ~2.50 ~0.1 ~0.00 0 0 0 0 1
execute if score @s bs.k matches ..39 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.92,0.92,0.95],scale:1} ~2.02 ~0.1 ~1.47 0 0 0 0 1
execute if score @s bs.k matches ..39 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.92,0.92,0.95],scale:1} ~0.77 ~0.1 ~2.38 0 0 0 0 1
execute if score @s bs.k matches ..39 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.92,0.92,0.95],scale:1} ~-0.77 ~0.1 ~2.38 0 0 0 0 1
execute if score @s bs.k matches ..39 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.92,0.92,0.95],scale:1} ~-2.02 ~0.1 ~1.47 0 0 0 0 1
execute if score @s bs.k matches ..39 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.92,0.92,0.95],scale:1} ~-2.50 ~0.1 ~0.00 0 0 0 0 1
execute if score @s bs.k matches ..39 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.92,0.92,0.95],scale:1} ~-2.02 ~0.1 ~-1.47 0 0 0 0 1
execute if score @s bs.k matches ..39 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.92,0.92,0.95],scale:1} ~-0.77 ~0.1 ~-2.38 0 0 0 0 1
execute if score @s bs.k matches ..39 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.92,0.92,0.95],scale:1} ~0.77 ~0.1 ~-2.38 0 0 0 0 1
execute if score @s bs.k matches ..39 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.92,0.92,0.95],scale:1} ~2.02 ~0.1 ~-1.47 0 0 0 0 1
execute if score @s bs.k matches ..39 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.05,0.05,0.08],scale:1.5} ~ ~6 ~ 1.2 0.5 1.2 0 6
execute if score @s bs.k matches ..39 if score #m4 bs.ev matches 0 run particle minecraft:white_ash ~ ~3 ~ 1.5 2 1.5 0 10
execute if score @s bs.k matches 40 run function boss:c/pique
execute if score @s bs.k matches 42.. run kill @s
