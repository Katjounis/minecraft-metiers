scoreboard players set #ph bs.c 2
scoreboard players set #disp bs.c 60
scoreboard players set #atk bs.c 150
title @a[tag=bs.joue] times 8 60 16
title @a[tag=bs.joue] subtitle {"text":"Il se disperse en corbeaux : tue-les avant qu'ils le rejoignent !","color":"white"}
title @a[tag=bs.joue] title {"text":"PHASE 2","color":"dark_red","bold":true}
title @a[tag=bs.joue] actionbar {"text":"Reste dans la lumière des citrouilles : la nuit te ronge.","color":"gold"}
execute as @a[tag=bs.joue] at @s run playsound minecraft:entity.ravager.roar master @s ~ ~ ~ 1 0.6
