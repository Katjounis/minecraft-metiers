scoreboard players set #ph bs.c 2
scoreboard players set #disp bs.c 60
scoreboard players set #atk bs.c 150
execute if score #rg bs.ev matches 10.. run effect give @s minecraft:absorption 60 4 true
title @a[tag=bs.joue] times 8 60 16
title @a[tag=bs.joue] subtitle {"text":"Tue les corbeaux en vol !","color":"white"}
title @a[tag=bs.joue] title {"text":"PHASE 2","color":"dark_red","bold":true}
title @a[tag=bs.joue] actionbar {"text":"Reste près des citrouilles","color":"gold"}
execute as @a[tag=bs.joue] at @s run playsound minecraft:entity.ravager.roar master @s ~ ~ ~ 1 0.6
