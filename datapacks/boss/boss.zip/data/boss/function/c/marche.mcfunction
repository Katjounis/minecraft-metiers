scoreboard players remove #atk bs.c 1
execute if score #ph bs.c matches 2 run scoreboard players remove #disp bs.c 1
execute if score #ph bs.c matches 2 if score #disp bs.c matches ..0 run return run function boss:c/disperser
execute if score #atk bs.c matches ..0 run function boss:c/attaque
