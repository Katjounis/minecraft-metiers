data merge entity @s {NoAI:0b}
scoreboard players set #etat bs.c 0
function boss:rig/corbeau/jouer/marche
