setblock 16 67 5 minecraft:jack_o_lantern[facing=west]
