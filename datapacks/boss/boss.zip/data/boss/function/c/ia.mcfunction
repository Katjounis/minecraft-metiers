execute if score #etat bs.ev matches 4 run return 0
tp @e[type=minecraft:item_display,tag=bs.os.corbeau] ~ ~ ~ ~ 0
scoreboard players add #t bs.c 1
execute if score #etat bs.c matches 0 run function boss:c/marche
execute if score #etat bs.c matches 1 run function boss:c/attaque_cours
execute if score #etat bs.c matches 2 run function boss:c/disperse
execute if score #etat bs.c matches 3 run function boss:c/crucifie
execute if score #etat bs.c matches 4 run function boss:c/charge
execute if score #etat bs.c matches 5 run function boss:c/sonne
execute if score #etat bs.c matches 6 run function boss:c/attente
execute if score #etat bs.c matches 8 run function boss:c/vers_croix
execute unless score #etat bs.c matches 0 run return 0
execute store result score #hp bs.c run data get entity @s Health
scoreboard players operation #pct bs.c = #hp bs.c
scoreboard players operation #pct bs.c *= #100 bs.tmp
scoreboard players operation #pct bs.c /= #max bs.ev
execute if score #ph bs.c matches 1 if score #pct bs.c matches ..60 run function boss:c/phase2
execute if score #ph bs.c matches 2 if score #pct bs.c matches ..30 run function boss:c/phase3
