setblock -16 67 5 minecraft:carved_pumpkin[facing=east]
