execute as @a[tag=bs.joue,sort=random,limit=3] at @s run summon minecraft:marker ~ ~0.1 ~ {Tags:["bs.e","bs.fx","bs.zone","bs.z.pique"]}
playsound minecraft:entity.parrot.imitate.phantom hostile @a[distance=..32] ~ ~ ~ 2 0.6
title @a[tag=bs.joue] actionbar {"text":"Les corbeaux visent les cercles : bouge !","color":"red"}
