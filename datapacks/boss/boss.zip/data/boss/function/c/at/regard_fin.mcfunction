execute if score @e[type=minecraft:marker,tag=bs.regarde,limit=1] bs.k matches 1 in boss:corbeau run function boss:c/yeux_off_1
execute if score @e[type=minecraft:marker,tag=bs.regarde,limit=1] bs.k matches 2 in boss:corbeau run function boss:c/yeux_off_2
execute if score @e[type=minecraft:marker,tag=bs.regarde,limit=1] bs.k matches 3 in boss:corbeau run function boss:c/yeux_off_3
execute if score @e[type=minecraft:marker,tag=bs.regarde,limit=1] bs.k matches 4 in boss:corbeau run function boss:c/yeux_off_4
execute if score @e[type=minecraft:marker,tag=bs.regarde,limit=1] bs.k matches 5 in boss:corbeau run function boss:c/yeux_off_5
tag @e[type=minecraft:marker,tag=bs.regarde] remove bs.regarde
tag @a remove bs.vise
scoreboard players set @a bs.vu 0
