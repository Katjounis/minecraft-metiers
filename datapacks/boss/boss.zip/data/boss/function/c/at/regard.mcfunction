execute if entity @e[type=minecraft:marker,tag=bs.regarde] run return 0
tag @e[type=minecraft:marker,tag=bs.epv,sort=random,limit=1] add bs.regarde
scoreboard players set #rg bs.c 0
tag @a remove bs.vise
tag @r[tag=bs.joue] add bs.vise
scoreboard players set @a bs.vu 0
execute if score @e[type=minecraft:marker,tag=bs.regarde,limit=1] bs.k matches 1 in boss:corbeau run function boss:c/yeux_on_1
execute if score @e[type=minecraft:marker,tag=bs.regarde,limit=1] bs.k matches 2 in boss:corbeau run function boss:c/yeux_on_2
execute if score @e[type=minecraft:marker,tag=bs.regarde,limit=1] bs.k matches 3 in boss:corbeau run function boss:c/yeux_on_3
execute if score @e[type=minecraft:marker,tag=bs.regarde,limit=1] bs.k matches 4 in boss:corbeau run function boss:c/yeux_on_4
execute if score @e[type=minecraft:marker,tag=bs.regarde,limit=1] bs.k matches 5 in boss:corbeau run function boss:c/yeux_on_5
function boss:rig/corbeau/jouer/torsion
title @a[tag=bs.vise] actionbar {"text":"Ne regarde pas l'épouvantail !","color":"gold"}
execute as @a[tag=bs.vise] at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 1 0.5
