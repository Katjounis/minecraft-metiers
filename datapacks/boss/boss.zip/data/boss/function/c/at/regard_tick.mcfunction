scoreboard players add #rg bs.c 1
execute if score #m4 bs.ev matches 0 as @a[tag=bs.vise] at @s anchored eyes if function boss:c/at/rayon run scoreboard players add @s bs.vu 4
execute if score #m4 bs.ev matches 0 at @e[type=minecraft:marker,tag=bs.regarde] run particle minecraft:dust{color:[1,0.35,0.1],scale:1} ~ ~ ~ 0.25 0.25 0.25 0 3
execute as @a[tag=bs.vise,scores={bs.vu=40..}] at @s run function boss:c/at/maudit
execute if score #rg bs.c matches 140.. run function boss:c/at/regard_fin
