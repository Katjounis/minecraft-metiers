function boss:c/geler
scoreboard players set #att bs.c 2
function boss:rig/corbeau/jouer/nuee
playsound minecraft:entity.phantom.ambient hostile @a[distance=..32] ~ ~ ~ 2 0.6
