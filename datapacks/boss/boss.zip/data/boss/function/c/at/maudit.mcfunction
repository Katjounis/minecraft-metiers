effect give @s minecraft:slowness 6 2
effect give @s minecraft:darkness 6 0
title @s actionbar {"text":"Tu l'as trop regardé…","color":"red"}
playsound minecraft:entity.warden.nearby_closest master @s ~ ~ ~ 1 0.8
scoreboard players set @s bs.vu 0
tag @s remove bs.vise
