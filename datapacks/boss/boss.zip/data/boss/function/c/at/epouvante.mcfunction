playsound minecraft:entity.phantom.death hostile @a[distance=..32] ~ ~ ~ 2 0.5
particle minecraft:large_smoke ~ ~4 ~ 3 2 3 0.05 80
execute as @a[tag=bs.joue,distance=..10] run function boss:joueur/blesse {d:5,lim:11}
effect give @a[tag=bs.joue,distance=..10] minecraft:darkness 4 0 true
effect give @a[tag=bs.joue,distance=..10] minecraft:slowness 3 1 true
title @a[tag=bs.joue] actionbar {"text":"Le Corbeau hurle : l'épouvante vous glace !","color":"dark_red"}
