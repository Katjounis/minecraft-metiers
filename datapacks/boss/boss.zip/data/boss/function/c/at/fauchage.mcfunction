function boss:c/geler
scoreboard players set #att bs.c 1
function boss:rig/corbeau/jouer/fauchage
playsound minecraft:entity.zombie.attack_wooden_door hostile @a[distance=..32] ~ ~ ~ 2 0.5
title @a[tag=bs.joue,distance=..10] actionbar {"text":"Sa croix craque : saute ou recule !","color":"red"}
