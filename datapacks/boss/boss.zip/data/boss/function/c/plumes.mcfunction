scoreboard players set #pl bs.c 90
execute as @a[tag=bs.joue] at @s run summon minecraft:marker ~ 64 ~ {Tags:["bs.e","bs.fx","bs.plume"]}
function boss:c/plume_hasard
function boss:c/plume_hasard
playsound minecraft:entity.phantom.ambient hostile @a[distance=0..] 0 70 0 3 0.5
title @a[tag=bs.joue] actionbar {"text":"Les plumes tombent : sors des cercles avant le piqué !","color":"gray"}
