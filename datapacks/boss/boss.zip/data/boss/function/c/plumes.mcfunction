scoreboard players set #pl bs.c 65
scoreboard players operation #nc bs.tmp = #n bs.ev
scoreboard players add #nc bs.tmp 1
execute positioned ~ ~6 ~ run function boss:c/at/corbeau_un
execute as @a[tag=bs.joue] at @s run summon minecraft:marker ~ 64 ~ {Tags:["bs.e","bs.fx","bs.plume"]}
function boss:c/plume_hasard
function boss:c/plume_hasard
playsound minecraft:entity.phantom.ambient hostile @a[distance=0..] 0 70 0 3 0.5
title @a[tag=bs.joue] actionbar {"text":"Sors des cercles !","color":"gray"}
