scoreboard players set #etat bs.c 5
scoreboard players set #t bs.c 0
data merge entity @s {Invulnerable:0b}
function boss:rig/corbeau/jouer/sonne
title @a[tag=bs.joue] times 8 60 16
title @a[tag=bs.joue] subtitle {"text":"Il est sonné : frappe !","color":"gold"}
title @a[tag=bs.joue] title {"text":"","color":"white","bold":true}
playsound minecraft:block.anvil.land hostile @a[distance=0..] ~ ~ ~ 2 0.5
