tag @s add bs.ch
function boss:joueur/blesse {d:9,lim:15}
effect give @s minecraft:levitation 1 1 true
