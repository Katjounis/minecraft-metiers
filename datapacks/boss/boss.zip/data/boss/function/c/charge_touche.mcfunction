tag @s add bs.ch
function boss:joueur/blesse {d:12,lim:18}
effect give @s minecraft:levitation 1 1 true
