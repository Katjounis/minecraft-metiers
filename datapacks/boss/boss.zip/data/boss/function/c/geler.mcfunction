data merge entity @s {NoAI:1b}
scoreboard players set #etat bs.c 1
scoreboard players set #t bs.c 0
rotate @s facing entity @p[tag=bs.joue] feet
execute rotated as @s run rotate @s ~ 0
