execute store result storage boss:t x int 1 run random value -15..15
execute store result storage boss:t z int 1 run random value -15..15
execute in boss:corbeau run function boss:c/plume_m with storage boss:t
