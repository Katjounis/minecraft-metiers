scoreboard players set #etat bs.c 4
scoreboard players set #t bs.c 0
tag @a remove bs.chc
tag @a remove bs.ch
tag @r[tag=bs.joue] add bs.chc
function boss:rig/corbeau/jouer/torsion
playsound minecraft:entity.zombie.attack_wooden_door hostile @a[distance=0..] ~ ~ ~ 3 0.4
title @a[tag=bs.joue] actionbar {"text":"Évite la ligne rouge !","color":"red"}
