scoreboard players set #ph bs.c 3
data merge entity @s {NoAI:1b}
scoreboard players set #etat bs.c 8
scoreboard players set #t bs.c 0
function boss:rig/corbeau/jouer/dispersion
title @a[tag=bs.joue] times 8 60 16
title @a[tag=bs.joue] subtitle {"text":"Esquive, puis frappe-le !","color":"white"}
title @a[tag=bs.joue] title {"text":"PHASE 3","color":"dark_red","bold":true}
execute as @a[tag=bs.joue] at @s run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 1 0.5
execute as @e[type=minecraft:item_display,tag=bs.lune] run data merge entity @s {start_interpolation:0,interpolation_duration:80,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[16f,16f,16f]}}
