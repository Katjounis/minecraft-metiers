execute if score #t bs.c matches ..26 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.05,0.05,0.08],scale:2} ~ ~5 ~ 1.5 3 1.5 0 30
execute if score #t bs.c matches ..26 if score #m4 bs.ev matches 0 run particle minecraft:large_smoke ~ ~5 ~ 1 2 1 0.02 10
execute if score #t bs.c matches 26 run function boss:c/fragments
execute if score #t bs.c matches 40.. unless entity @e[tag=bs.frag] run function boss:c/reformer
