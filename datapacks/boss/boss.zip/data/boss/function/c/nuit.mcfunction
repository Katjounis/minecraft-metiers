execute at @e[type=minecraft:marker,tag=bs.cit] run particle minecraft:dust{color:[1,0.6,0.1],scale:1.2} ~ ~0.3 ~ 3 0 3 0 14
scoreboard players add #nuit bs.c 1
execute if score #nuit bs.c matches ..1 run return 0
scoreboard players set #nuit bs.c 0
execute as @a[tag=bs.joue] at @s unless entity @e[type=minecraft:marker,tag=bs.cit,distance=..6] run function boss:c/ronge
