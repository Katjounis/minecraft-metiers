function boss:rig/corbeau/tick
execute as @e[type=minecraft:item_display,tag=bs.amb] at @s run tp @s ^ ^ ^0.35 ~2 ~
execute as @e[tag=bs.hb.c,limit=1] at @s run function boss:c/ia
function boss:c/effets
