execute at @e[type=minecraft:marker,tag=bs.cible,limit=1] positioned ~ 64 ~ facing 0 64 0 positioned ^ ^ ^2.5 run tp @s ~ ~ ~ ~ 0
data merge entity @s {Invulnerable:0b,NoGravity:0b}
execute store result score #hp bs.c run data get entity @s Health
scoreboard players operation #hp bs.c += #soin bs.c
execute if score #hp bs.c > #pvmax bs.ev run scoreboard players operation #hp bs.c = #pvmax bs.ev
execute store result entity @s Health float 1 run scoreboard players get #hp bs.c
function boss:rig/corbeau/jouer/reforme
execute at @e[type=minecraft:marker,tag=bs.cible,limit=1] run particle minecraft:large_smoke ~ ~ ~ 1 2 1 0.05 60
execute if score #arr bs.c matches 1.. run title @a[tag=bs.joue] actionbar [{"score":{"name":"#arr","objective":"bs.c"},"color":"red"},{"text":" corbeau(x) arrivés : il se soigne","color":"red"}]
execute if score #arr bs.c matches 0 run title @a[tag=bs.joue] actionbar {"text":"Aucun corbeau passé : pas de soin","color":"green"}
tag @e[type=minecraft:marker,tag=bs.cible] remove bs.cible
scoreboard players set #etat bs.c 6
scoreboard players set #t bs.c 18
scoreboard players set #disp bs.c 360
playsound minecraft:entity.zombie.attack_wooden_door hostile @a[distance=..48] ~ ~ ~ 2 0.4
