execute as @e[tag=bs.frag] at @s facing entity @e[type=minecraft:marker,tag=bs.cible,limit=1] feet run tp @s ^ ^ ^0.2 ~ ~
execute as @e[tag=bs.frag] at @s if entity @e[type=minecraft:marker,tag=bs.cible,distance=..1.6] run function boss:c/frag_arrive
execute as @e[type=minecraft:marker,tag=bs.plume] at @s run function boss:c/plume_tick
execute if entity @e[type=minecraft:marker,tag=bs.regarde] run function boss:c/at/regard_tick
execute if score #ph bs.c matches 2.. if score #tk bs.ev matches 0 run function boss:c/nuit
