execute if score #etat bs.ev matches 4 run return 0
execute if score #etat bs.c matches 3 run return run function boss:rig/corbeau/jouer/croix
execute if score #etat bs.c matches 4 run return run function boss:rig/corbeau/jouer/charge
execute if score #etat bs.c matches 5 run return run function boss:rig/corbeau/jouer/sonne
execute if score #etat bs.c matches 6 run return run function boss:rig/corbeau/jouer/repos
function boss:rig/corbeau/jouer/marche
