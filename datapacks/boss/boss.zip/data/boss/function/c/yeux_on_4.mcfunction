setblock -10 67 -14 minecraft:jack_o_lantern[facing=south]
