execute if score #t bs.c matches 50.. run data merge entity @s {NoAI:0b}
execute if score #t bs.c matches 50.. run scoreboard players set #etat bs.c 0
execute if score #t bs.c matches 50 run function boss:rig/corbeau/jouer/marche
