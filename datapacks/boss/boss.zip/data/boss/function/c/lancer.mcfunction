scoreboard players set #c bs.tmp 160
scoreboard players operation #max bs.ev = #n bs.ev
scoreboard players operation #max bs.ev *= #c bs.tmp
scoreboard players add #max bs.ev 350
scoreboard players set #res bs.ev 0
execute if score #max bs.ev matches 1100.. run scoreboard players set #res bs.ev 1
execute if score #max bs.ev matches 1500.. run scoreboard players set #res bs.ev 2
execute if score #max bs.ev matches 1001.. run scoreboard players set #max bs.ev 1000
execute store result storage boss:t hp int 1 run scoreboard players get #max bs.ev
execute in boss:corbeau positioned 0 64 -14 run function boss:c/invoquer with storage boss:t
execute if score #res bs.ev matches 1 run effect give @e[tag=bs.hb.c,limit=1] minecraft:resistance infinite 0 true
execute if score #res bs.ev matches 2 run effect give @e[tag=bs.hb.c,limit=1] minecraft:resistance infinite 1 true
execute at @e[tag=bs.hb.c,limit=1] run function boss:rig/corbeau/invoquer
function boss:rig/corbeau/jouer/apparition
bossbar set boss:combat name {"text":"Le Corbeau-Épouvantail","color":"dark_red","bold":true}
bossbar set boss:combat color red
scoreboard players set #etat bs.c 6
scoreboard players set #t bs.c -10
scoreboard players set #atk bs.c 120
scoreboard players set #ph bs.c 1
scoreboard players set #disp bs.c 0
scoreboard players set #soin bs.c 0
scoreboard players set #arr bs.c 0
scoreboard players operation #unite bs.c = #max bs.ev
scoreboard players operation #unite bs.c /= #60 bs.tmp
execute if score #unite bs.c matches ..0 run scoreboard players set #unite bs.c 1
title @a[tag=bs.joue] times 8 60 16
title @a[tag=bs.joue] subtitle {"text":"Saute ou recule quand sa croix craque !","color":"white"}
title @a[tag=bs.joue] title {"text":"LE CORBEAU-ÉPOUVANTAIL","color":"dark_red","bold":true}
execute as @a[tag=bs.joue] at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.7 0.6
tellraw @a[tag=bs.joue] [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Comment le vaincre : ","color":"gold","bold":false},{"text":"frappe-le quand il marche. Quand sa tête se tord et que sa croix craque, saute ou recule : il fauche tout autour de lui. ","color":"white","bold":false},{"text":"Sous 60 %, il se disperse en corbeaux qui filent vers un épouvantail : tue-les en vol, sinon il se soigne. ","color":"white","bold":false},{"text":"Sous 30 %, il se crucifie : esquive sa charge sur le côté, puis frappe le sac pendant qu'il est sonné.","color":"gray","bold":false}]
