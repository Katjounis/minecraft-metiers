scoreboard players set #c bs.tmp 250
scoreboard players operation #pvmax bs.ev = #n bs.ev
scoreboard players operation #pvmax bs.ev *= #c bs.tmp
scoreboard players add #pvmax bs.ev 600
scoreboard players operation #pvmax bs.ev *= #mul bs.ev
scoreboard players operation #pvmax bs.ev /= #100 bs.tmp
scoreboard players set #res bs.ev 0
execute if score #pvmax bs.ev matches 1100.. run scoreboard players set #res bs.ev 1
execute if score #pvmax bs.ev matches 1500.. run scoreboard players set #res bs.ev 2
execute if score #pvmax bs.ev matches 2400.. run scoreboard players set #res bs.ev 3
execute if score #pvmax bs.ev matches 1001.. run scoreboard players set #pvmax bs.ev 1000
execute store result storage boss:t hp int 1 run scoreboard players get #pvmax bs.ev
execute in boss:corbeau positioned 0 64 -14 run function boss:c/invoquer with storage boss:t
execute if score #res bs.ev matches 1 run effect give @e[tag=bs.hb.c,limit=1] minecraft:resistance infinite 0 true
execute if score #res bs.ev matches 2 run effect give @e[tag=bs.hb.c,limit=1] minecraft:resistance infinite 1 true
execute if score #res bs.ev matches 3 run effect give @e[tag=bs.hb.c,limit=1] minecraft:resistance infinite 2 true
execute as @e[tag=bs.hb.c,limit=1] run function boss:rang_boss
execute at @e[tag=bs.hb.c,limit=1] run function boss:rig/corbeau/invoquer
function boss:rig/corbeau/jouer/apparition
bossbar set boss:combat name {"text":"Le Corbeau-Épouvantail","color":"dark_red","bold":true}
bossbar set boss:combat color red
scoreboard players set #etat bs.c 6
scoreboard players set #t bs.c -10
scoreboard players set #atk bs.c 120
scoreboard players set #ph bs.c 1
scoreboard players set #disp bs.c 0
scoreboard players set #soin bs.c 0
scoreboard players set #arr bs.c 0
scoreboard players operation #unite bs.c = #pvmax bs.ev
scoreboard players set #c bs.tmp 40
scoreboard players operation #unite bs.c /= #c bs.tmp
execute if score #unite bs.c matches ..0 run scoreboard players set #unite bs.c 1
title @a[tag=bs.joue] times 8 60 16
title @a[tag=bs.joue] subtitle {"text":"Croix qui craque : saute !","color":"white"}
title @a[tag=bs.joue] title {"text":"LE CORBEAU","color":"dark_red","bold":true}
execute as @a[tag=bs.joue] at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.7 0.6
tellraw @a[tag=bs.joue] [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Croix qui craque : saute ou recule.","color":"white","bold":false}]
tellraw @a[tag=bs.joue] [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Phase 2 : tue les corbeaux en vol. Phase 3 : esquive la charge, frappe-le sonné.","color":"gray","bold":false}]
