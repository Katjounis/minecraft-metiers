scoreboard players set #atk bs.c 90
execute if score #ph bs.c matches 2 run scoreboard players set #atk bs.c 70
scoreboard players operation #red bs.tmp = #atk bs.c
scoreboard players operation #red bs.tmp *= #rg bs.ev
scoreboard players operation #red bs.tmp /= #40 bs.tmp
scoreboard players operation #atk bs.c -= #red bs.tmp
execute store result score #r2 bs.tmp run random value 1..4
execute if score #r2 bs.tmp matches 1 run return run function boss:c/at/epouvante
execute if score #r2 bs.tmp matches 2 if score #rg bs.ev matches 6.. run return run function boss:c/at/picorage
execute store result score #r bs.tmp run random value 1..4
execute if score #r bs.tmp matches 1..2 run return run function boss:c/at/fauchage
execute if score #r bs.tmp matches 3 run return run function boss:c/at/nuee
execute if score #r bs.tmp matches 4 run function boss:c/at/regard
