scoreboard players set #atk bs.c 130
execute if score #ph bs.c matches 2 run scoreboard players set #atk bs.c 110
execute store result score #r bs.tmp run random value 1..4
execute if score #r bs.tmp matches 1..2 run return run function boss:c/at/fauchage
execute if score #r bs.tmp matches 3 run return run function boss:c/at/nuee
execute if score #r bs.tmp matches 4 run function boss:c/at/regard
