scoreboard players operation #soin bs.c += #unite bs.c
scoreboard players add #arr bs.c 1
particle minecraft:large_smoke ~ ~ ~ 0.3 0.3 0.3 0.02 10
playsound minecraft:entity.phantom.flap hostile @a[distance=..24] ~ ~ ~ 1 0.6
execute on passengers run kill @s
kill @s
