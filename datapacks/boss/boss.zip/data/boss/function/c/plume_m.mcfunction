$summon minecraft:marker $(x) 64 $(z) {Tags:["bs.e","bs.fx","bs.plume"]}
