execute if score #att bs.c matches 1 if score #t bs.c matches 14 run playsound minecraft:entity.zombie.attack_wooden_door hostile @a[distance=..32] ~ ~ ~ 2 0.4
execute if score #att bs.c matches 1 if score #t bs.c matches 21..32 run particle minecraft:sweep_attack ~4.50 ~1.2 ~0.00 0 0 0 0 1
execute if score #att bs.c matches 1 if score #t bs.c matches 21..32 run particle minecraft:sweep_attack ~3.18 ~1.2 ~3.18 0 0 0 0 1
execute if score #att bs.c matches 1 if score #t bs.c matches 21..32 run particle minecraft:sweep_attack ~0.00 ~1.2 ~4.50 0 0 0 0 1
execute if score #att bs.c matches 1 if score #t bs.c matches 21..32 run particle minecraft:sweep_attack ~-3.18 ~1.2 ~3.18 0 0 0 0 1
execute if score #att bs.c matches 1 if score #t bs.c matches 21..32 run particle minecraft:sweep_attack ~-4.50 ~1.2 ~0.00 0 0 0 0 1
execute if score #att bs.c matches 1 if score #t bs.c matches 21..32 run particle minecraft:sweep_attack ~-3.18 ~1.2 ~-3.18 0 0 0 0 1
execute if score #att bs.c matches 1 if score #t bs.c matches 21..32 run particle minecraft:sweep_attack ~-0.00 ~1.2 ~-4.50 0 0 0 0 1
execute if score #att bs.c matches 1 if score #t bs.c matches 21..32 run particle minecraft:sweep_attack ~3.18 ~1.2 ~-3.18 0 0 0 0 1
execute if score #att bs.c matches 1 if score #t bs.c matches 24 as @a[tag=bs.joue,distance=..7.5] if predicate boss:au_sol run function boss:joueur/blesse {d:12,lim:18}
execute if score #att bs.c matches 1 if score #t bs.c matches 24 run playsound minecraft:entity.player.attack.sweep hostile @a[distance=..32] ~ ~ ~ 2 0.5
execute if score #att bs.c matches 2 if score #t bs.c matches 10 run scoreboard players operation #nc bs.tmp = #n bs.ev
execute if score #att bs.c matches 2 if score #t bs.c matches 10 run scoreboard players operation #nc bs.tmp += #n bs.ev
execute if score #att bs.c matches 2 if score #t bs.c matches 10 run scoreboard players add #nc bs.tmp 3
execute if score #att bs.c matches 2 if score #t bs.c matches 10 if score #nc bs.tmp matches 13.. run scoreboard players set #nc bs.tmp 12
execute if score #att bs.c matches 2 if score #t bs.c matches 10 positioned ~ ~5 ~ run function boss:c/at/corbeau_un
execute if score #att bs.c matches 2 if score #t bs.c matches 10 run particle minecraft:large_smoke ~ ~5 ~ 0.5 0.8 0.5 0.05 30
execute if score #t bs.c matches 40.. run function boss:c/fin_attaque
