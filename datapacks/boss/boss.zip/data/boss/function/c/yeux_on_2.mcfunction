setblock 0 67 17 minecraft:jack_o_lantern[facing=north]
