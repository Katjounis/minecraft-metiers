execute as @a[tag=bs.joue,distance=..2.9] run function boss:joueur/blesse {d:9,lim:15}
particle minecraft:large_smoke ~ ~1 ~ 1 1 1 0.05 30
particle minecraft:dust{color:[0.05,0.05,0.08],scale:2} ~ ~1 ~ 1 1 1 0 40
playsound minecraft:entity.phantom.bite hostile @a[distance=..24] ~ ~ ~ 2 0.7
