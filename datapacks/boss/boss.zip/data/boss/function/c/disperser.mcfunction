data merge entity @s {NoAI:1b}
scoreboard players set #etat bs.c 2
scoreboard players set #t bs.c 0
function boss:rig/corbeau/jouer/dispersion
playsound minecraft:entity.phantom.swoop hostile @a[distance=..48] ~ ~ ~ 2 0.5
playsound minecraft:entity.bat.takeoff hostile @a[distance=..48] ~ ~ ~ 2 0.5
tag @e[type=minecraft:marker,tag=bs.cible] remove bs.cible
tag @e[type=minecraft:marker,tag=bs.epv,sort=random,limit=1] add bs.cible
title @a[tag=bs.joue] times 8 60 16
title @a[tag=bs.joue] subtitle {"text":"Il se disperse ! Tue les corbeaux avant qu'ils le rejoignent.","color":"red"}
title @a[tag=bs.joue] title {"text":"","color":"white","bold":true}
