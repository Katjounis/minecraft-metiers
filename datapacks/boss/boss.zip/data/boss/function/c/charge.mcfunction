execute if score #t bs.c matches ..18 facing entity @a[tag=bs.chc,limit=1] feet run rotate @s ~ 0
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^1 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^2 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^3 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^4 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^5 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^6 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^7 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^8 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^9 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^10 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^11 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^12 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^13 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^14 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^15 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^16 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^17 0.1 0 0.1 0 1
execute if score #t bs.c matches ..20 if score #m4 bs.ev matches 0 rotated ~ 0 run particle minecraft:dust{color:[0.9,0.1,0.1],scale:1.3} ^ ^0.2 ^18 0.1 0 0.1 0 1
execute if score #t bs.c matches 20 run function boss:rig/corbeau/jouer/charge
execute if score #t bs.c matches 20 run playsound minecraft:entity.ravager.roar hostile @a[distance=0..] ~ ~ ~ 3 0.7
execute if score #t bs.c matches 21..46 rotated ~ 0 run tp @s ^ ^ ^0.85
execute if score #t bs.c matches 21..46 positioned 0 64 0 unless entity @s[distance=..21] run scoreboard players set #t bs.c 47
execute if score #t bs.c matches 21..46 as @a[tag=bs.joue,tag=!bs.ch,distance=..2.6] run function boss:c/charge_touche
execute if score #t bs.c matches 47.. run function boss:c/sonne_debut
