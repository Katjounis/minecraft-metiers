setblock 10 67 -14 minecraft:carved_pumpkin[facing=south]
