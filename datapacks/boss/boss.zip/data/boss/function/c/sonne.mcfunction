execute unless score #t bs.c matches 110.. run return 0
particle minecraft:large_smoke ~ ~2 ~ 1 2 1 0.05 50
data merge entity @s {Invulnerable:1b}
execute in boss:corbeau run tp @s 0 64 0 0 0
function boss:rig/corbeau/jouer/croix
scoreboard players set #etat bs.c 3
scoreboard players set #ch bs.c 220
tag @a remove bs.chc
