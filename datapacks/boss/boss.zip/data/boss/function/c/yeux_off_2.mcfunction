setblock 0 67 17 minecraft:carved_pumpkin[facing=north]
