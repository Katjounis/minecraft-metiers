function boss:rig/mb_liche/jouer/repos
