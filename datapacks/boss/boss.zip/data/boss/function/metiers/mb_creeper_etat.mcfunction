function boss:rig/mb_creeper/tick
execute if entity @s[tag=metiers.atk] run function boss:rig/mb_creeper/jouer/attaque
tag @s remove metiers.atk
execute if score #amb_creeper bs.an matches 3 run return 0
execute if predicate boss:bouge unless score #amb_creeper bs.an matches 2 run function boss:rig/mb_creeper/jouer/marche
execute unless predicate boss:bouge unless score #amb_creeper bs.an matches 1 run function boss:rig/mb_creeper/jouer/repos
