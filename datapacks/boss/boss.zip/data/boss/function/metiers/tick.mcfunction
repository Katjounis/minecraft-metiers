execute as @e[tag=metiers.boss,tag=!bs.hab] at @s run function boss:metiers/habiller
execute as @e[tag=metiers.boss,tag=bs.hab] run function boss:metiers/suivre
execute as @e[type=minecraft:item_display,tag=bs.mh] unless predicate boss:monte run kill @s
