execute as @e[tag=metiers.boss,tag=bs.hab,limit=1] unless entity @e[type=minecraft:item_display,tag=bs.mos] run tag @s remove bs.hab
execute as @e[tag=metiers.boss,tag=!bs.hab,limit=1] at @s run function boss:metiers/habiller
execute unless entity @e[tag=metiers.boss] run kill @e[type=minecraft:item_display,tag=bs.mos]
execute as @e[tag=metiers.boss,tag=bs.hab,limit=1] at @s run function boss:metiers/suivre
