summon minecraft:item_display ~ ~ ~ {Tags:["bs.mh", "bs.mhn"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:reine_couronne_racine"}},item_display:"none",view_range:3f,brightness:{sky:0,block:13},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,-0.9f,1.55f],scale:[3.2f,3.2f,3.2f]}}
ride @e[type=minecraft:item_display,tag=bs.mhn,limit=1] mount @s
tag @e[type=minecraft:item_display,tag=bs.mhn] remove bs.mhn
summon minecraft:item_display ~ ~ ~ {Tags:["bs.mh", "bs.mhn"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:reine_couronne_racine_l"}},item_display:"none",view_range:3f,brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,-0.9f,1.55f],scale:[3.2f,3.2f,3.2f]}}
ride @e[type=minecraft:item_display,tag=bs.mhn,limit=1] mount @s
tag @e[type=minecraft:item_display,tag=bs.mhn] remove bs.mhn
summon minecraft:item_display ~ ~ ~ {Tags:["bs.mh", "bs.mhn"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:reine_dos_racine"}},item_display:"none",view_range:3f,brightness:{sky:0,block:13},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,-0.55f,-1.2f],scale:[3f,3f,3f]}}
ride @e[type=minecraft:item_display,tag=bs.mhn,limit=1] mount @s
tag @e[type=minecraft:item_display,tag=bs.mhn] remove bs.mhn
summon minecraft:item_display ~ ~ ~ {Tags:["bs.mh", "bs.mhn"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:reine_dos_racine_l"}},item_display:"none",view_range:3f,brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,-0.55f,-1.2f],scale:[3f,3f,3f]}}
ride @e[type=minecraft:item_display,tag=bs.mhn,limit=1] mount @s
tag @e[type=minecraft:item_display,tag=bs.mhn] remove bs.mhn
