function boss:rig/mb_brasier/tick
execute if entity @s[tag=metiers.atk] run function boss:rig/mb_brasier/jouer/attaque
tag @s remove metiers.atk
execute if score #amb_brasier bs.an matches 2 run return 0
execute if predicate boss:bouge unless score #amb_brasier bs.an matches 3 run function boss:rig/mb_brasier/jouer/marche
execute unless predicate boss:bouge unless score #amb_brasier bs.an matches 1 run function boss:rig/mb_brasier/jouer/repos
