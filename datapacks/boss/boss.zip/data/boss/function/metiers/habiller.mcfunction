tag @s add bs.hab
data merge entity @s {drop_chances:{head:0f,chest:0f,legs:0f,feet:0f,mainhand:0f,offhand:0f}}
execute if entity @s[type=minecraft:zombie] run function boss:metiers/tenue_zombie
execute if entity @s[type=minecraft:stray] run function boss:metiers/tenue_stray
execute if entity @s[type=minecraft:spider] run function boss:metiers/parure_reine
execute if entity @s[type=minecraft:blaze] run function boss:metiers/parure_brasier
execute if entity @s[type=minecraft:creeper] run function boss:metiers/parure_creeper
