tag @s add bs.hab
effect give @s minecraft:invisibility infinite 0 true
data merge entity @s {drop_chances:{head:0f,chest:0f,legs:0f,feet:0f,mainhand:0f,offhand:0f}}
item replace entity @s armor.head with minecraft:air
item replace entity @s armor.chest with minecraft:air
item replace entity @s armor.legs with minecraft:air
item replace entity @s armor.feet with minecraft:air
execute if entity @s[type=minecraft:zombie] run item replace entity @s weapon.mainhand with minecraft:air
execute if entity @s[type=minecraft:stray] run item replace entity @s weapon.mainhand with minecraft:bow[minecraft:item_model="boss:vide"]
kill @e[type=minecraft:item_display,tag=bs.mos]
execute if entity @s[type=minecraft:zombie] run function boss:rig/mb_colosse/invoquer
execute if entity @s[type=minecraft:zombie] run function boss:rig/mb_colosse/jouer/repos
execute if entity @s[type=minecraft:spider] run function boss:rig/mb_reine/invoquer
execute if entity @s[type=minecraft:spider] run function boss:rig/mb_reine/jouer/repos
execute if entity @s[type=minecraft:stray] run function boss:rig/mb_liche/invoquer
execute if entity @s[type=minecraft:stray] run function boss:rig/mb_liche/jouer/repos
execute if entity @s[type=minecraft:blaze] run function boss:rig/mb_brasier/invoquer
execute if entity @s[type=minecraft:blaze] run function boss:rig/mb_brasier/jouer/repos
execute if entity @s[type=minecraft:creeper] run function boss:rig/mb_creeper/invoquer
execute if entity @s[type=minecraft:creeper] run function boss:rig/mb_creeper/jouer/repos
