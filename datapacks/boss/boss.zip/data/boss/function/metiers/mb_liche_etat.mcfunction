function boss:rig/mb_liche/tick
execute if entity @s[tag=metiers.atk] run function boss:rig/mb_liche/jouer/attaque
tag @s remove metiers.atk
execute if score #amb_liche bs.an matches 3 run return 0
execute if predicate boss:bouge unless score #amb_liche bs.an matches 2 run function boss:rig/mb_liche/jouer/marche
execute unless predicate boss:bouge unless score #amb_liche bs.an matches 1 run function boss:rig/mb_liche/jouer/repos
