function boss:rig/mb_colosse/jouer/repos
