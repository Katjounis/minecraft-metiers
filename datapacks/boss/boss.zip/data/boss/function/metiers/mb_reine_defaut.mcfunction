function boss:rig/mb_reine/jouer/repos
