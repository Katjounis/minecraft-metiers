function boss:rig/mb_reine/tick
execute if entity @s[tag=metiers.atk] run function boss:rig/mb_reine/jouer/attaque
tag @s remove metiers.atk
execute if score #amb_reine bs.an matches 3 run return 0
execute if predicate boss:bouge unless score #amb_reine bs.an matches 2 run function boss:rig/mb_reine/jouer/marche
execute unless predicate boss:bouge unless score #amb_reine bs.an matches 1 run function boss:rig/mb_reine/jouer/repos
