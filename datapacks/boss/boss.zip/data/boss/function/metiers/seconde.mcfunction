scoreboard players add #tour bs.ev 1
execute if score #tour bs.ev matches 6.. run scoreboard players set #tour bs.ev 0
execute if score #tour bs.ev matches 0 run function boss:metiers/tour_0
execute if score #tour bs.ev matches 2 run function boss:metiers/tour_1
execute if score #tour bs.ev matches 4 run function boss:metiers/tour_2
