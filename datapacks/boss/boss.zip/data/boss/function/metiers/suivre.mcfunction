data modify storage boss:t m set from entity @s Rotation[0]
execute on passengers if entity @s[tag=bs.mh,tag=!bs.tourne] run data modify entity @s Rotation[0] set from storage boss:t m
