tp @e[type=minecraft:item_display,tag=bs.mos] ~ ~ ~ ~ 0
execute if entity @s[type=minecraft:zombie] run function boss:metiers/mb_colosse_etat
execute if entity @s[type=minecraft:spider] run function boss:metiers/mb_reine_etat
execute if entity @s[type=minecraft:stray] run function boss:metiers/mb_liche_etat
execute if entity @s[type=minecraft:blaze] run function boss:metiers/mb_brasier_etat
execute if entity @s[type=minecraft:creeper] run function boss:metiers/mb_creeper_etat
