scoreboard players add @s bs.k 1
execute if entity @s[tag=!bs.frag] if score @s bs.k matches 600.. run return run function boss:min/fin
execute if entity @s[tag=bs.frag] if score @s bs.k matches 400.. run return run function boss:min/fin
data modify storage boss:t r set from entity @s Rotation[0]
execute on passengers run data modify entity @s Rotation[0] set from storage boss:t r
