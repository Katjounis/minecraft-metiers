execute at @s run particle minecraft:large_smoke ~ ~ ~ 0.2 0.2 0.2 0.02 8
execute on passengers run kill @s
kill @s
