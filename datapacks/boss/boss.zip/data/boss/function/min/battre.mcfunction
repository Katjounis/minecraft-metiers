scoreboard players add #aile bs.ev 1
execute if score #aile bs.ev matches 2.. run scoreboard players set #aile bs.ev 0
execute if score #aile bs.ev matches 1 as @e[type=minecraft:item_display,tag=bs.vol] run data modify entity @s item.components."minecraft:item_model" set value "boss:oiseau_b_racine"
execute if score #aile bs.ev matches 0 as @e[type=minecraft:item_display,tag=bs.vol] run data modify entity @s item.components."minecraft:item_model" set value "boss:oiseau_a_racine"
execute if score #aile bs.ev matches 1 as @e[type=minecraft:item_display,tag=bs.livd] run data modify entity @s item.components."minecraft:item_model" set value "boss:livre_b_racine"
execute if score #aile bs.ev matches 0 as @e[type=minecraft:item_display,tag=bs.livd] run data modify entity @s item.components."minecraft:item_model" set value "boss:livre_a_racine"
