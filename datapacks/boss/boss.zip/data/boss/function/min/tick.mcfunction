execute as @e[tag=bs.min] run function boss:min/un
execute if score #m4 bs.ev matches 0 run function boss:min/battre
execute as @e[type=minecraft:item_display,tag=bs.mind] unless predicate boss:monte run kill @s
