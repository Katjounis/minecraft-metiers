execute if score #rg bs.ev matches 3.. run effect give @s minecraft:regeneration infinite 0 true
