scoreboard players set #tk bs.ev 0
scoreboard players enable @a bs.rejoindre
execute as @a[scores={bs.rejoindre=1..}] at @s run function boss:joueur/trigger
execute as @a[scores={bs.mort=1..,bs.pv=1..}] at @s run function boss:joueur/mort
execute as @a at @s run function boss:joueur/verifier
function boss:metiers/seconde
execute if score #etat bs.ev matches 0 run function boss:ev/attente
execute if score #etat bs.ev matches 1 run function boss:ev/preavis
execute if score #etat bs.ev matches 2 run function boss:ev/intro
execute if score #etat bs.ev matches 3 run function boss:ev/combat_s
execute if score #etat bs.ev matches 4 run function boss:ev/fin_s
