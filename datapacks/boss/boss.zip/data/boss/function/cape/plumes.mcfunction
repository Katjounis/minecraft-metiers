particle minecraft:dust{color:[0.06,0.06,0.09],scale:1.4} ^ ^0.4 ^-0.9 0.35 0.15 0.35 0 3
particle minecraft:white_ash ^ ^0.4 ^-1.2 0.3 0.2 0.3 0 2
