particle minecraft:dust{color:[0.7,0.4,1.0],scale:0.7} ~ ~1.1 ~ 0.7 0.5 0.7 0 2
particle minecraft:enchant ~ ~1.6 ~ 0.4 0.3 0.4 0.6 2
effect give @s minecraft:strength 3 1 true
effect give @s minecraft:resistance 3 1 true
