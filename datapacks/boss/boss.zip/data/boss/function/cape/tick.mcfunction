execute as @a[predicate=boss:plane] if items entity @s armor.chest minecraft:elytra[minecraft:custom_data~{bs_cape:1b}] at @s run function boss:cape/plumes
execute as @a if items entity @s weapon.offhand minecraft:paper[minecraft:custom_data~{bs_familier:1b}] at @s run function boss:cape/runes
