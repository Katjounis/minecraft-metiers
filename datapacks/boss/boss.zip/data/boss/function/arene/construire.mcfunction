execute if score #boss bs.ev matches 1 run function boss:arene/g/construire
execute if score #boss bs.ev matches 2 run function boss:arene/c/construire
