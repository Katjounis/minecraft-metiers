particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 7 100.5 -12 0.4 0.3 0.4 0 12
fill 7 93 -12 7 104 -12 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 6 100.5 -10 0.4 0.3 0.4 0 12
fill 6 93 -10 6 104 -10 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 7 100.5 -11 0.4 0.3 0.4 0 12
fill 7 93 -11 7 104 -11 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 7 100.5 -10 0.4 0.3 0.4 0 12
fill 7 93 -10 7 104 -10 minecraft:air
playsound minecraft:block.deepslate.break hostile @a[distance=0..] 7 100 -12 1.5 0.6
