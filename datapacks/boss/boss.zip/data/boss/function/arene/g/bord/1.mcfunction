particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -14 100.5 -1 0.4 0.3 0.4 0 12
fill -14 93 -1 -14 104 -1 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -13 100.5 -1 0.4 0.3 0.4 0 12
fill -13 93 -1 -13 104 -1 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -14 100.5 -2 0.4 0.3 0.4 0 12
fill -14 93 -2 -14 104 -2 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -13 100.5 -2 0.4 0.3 0.4 0 12
fill -13 93 -2 -13 104 -2 minecraft:air
playsound minecraft:block.deepslate.break hostile @a[distance=0..] -14 100 -1 1.5 0.6
