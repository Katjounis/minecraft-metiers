setblock -6 101 -6 minecraft:air
setblock -6 100 -6 minecraft:cobbled_deepslate
particle minecraft:block{block_state:"minecraft:lectern"} -6 101.5 -6 0.5 0.5 0.5 0 40
playsound minecraft:block.wood.break hostile @a -6 101 -6 2 0.6
setblock -2 100 -2 minecraft:cracked_deepslate_tiles
setblock -3 100 -3 minecraft:cracked_deepslate_tiles
setblock -4 100 -4 minecraft:cracked_deepslate_tiles
setblock -5 100 -5 minecraft:cracked_deepslate_tiles
