particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -4 100.5 -12 0.4 0.3 0.4 0 12
fill -4 93 -12 -4 104 -12 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -4 100.5 -13 0.4 0.3 0.4 0 12
fill -4 93 -13 -4 104 -13 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -3 100.5 -12 0.4 0.3 0.4 0 12
fill -3 93 -12 -3 104 -12 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -3 100.5 -13 0.4 0.3 0.4 0 12
fill -3 93 -13 -3 104 -13 minecraft:air
playsound minecraft:block.deepslate.break hostile @a[distance=0..] -4 100 -12 1.5 0.6
