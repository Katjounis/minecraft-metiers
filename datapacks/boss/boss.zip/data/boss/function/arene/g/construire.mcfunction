execute in boss:grimoire run function boss:arene/g/blocs0
execute in boss:grimoire run function boss:arene/g/blocs1
