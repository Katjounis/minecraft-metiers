execute in boss:grimoire run kill @e[tag=bs.e,distance=0..]
execute in boss:grimoire run summon minecraft:marker 6.5 101 6.5 {Tags:["bs.e","bs.pu","bs.pu1"]}
execute in boss:grimoire run summon minecraft:marker -5.5 101 6.5 {Tags:["bs.e","bs.pu","bs.pu2"]}
execute in boss:grimoire run summon minecraft:marker -5.5 101 -5.5 {Tags:["bs.e","bs.pu","bs.pu3"]}
execute in boss:grimoire run summon minecraft:marker 6.5 101 -5.5 {Tags:["bs.e","bs.pu","bs.pu4"]}
scoreboard players set @e[type=minecraft:marker,tag=bs.pu1,limit=1] bs.k 1
scoreboard players set @e[type=minecraft:marker,tag=bs.pu2,limit=1] bs.k 2
scoreboard players set @e[type=minecraft:marker,tag=bs.pu3,limit=1] bs.k 3
scoreboard players set @e[type=minecraft:marker,tag=bs.pu4,limit=1] bs.k 4
scoreboard players set @e[type=minecraft:marker,tag=bs.pu] bs.g 0
execute in boss:grimoire run summon minecraft:marker 0 106 0 {Tags:["bs.e","bs.pivot"]}
function boss:arene/g/ligne_off_1
function boss:arene/g/ligne_off_2
function boss:arene/g/ligne_off_3
function boss:arene/g/ligne_off_4
