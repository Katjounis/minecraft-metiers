particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 8 100.5 -11 0.4 0.3 0.4 0 12
fill 8 93 -11 8 104 -11 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 8 100.5 -10 0.4 0.3 0.4 0 12
fill 8 93 -10 8 104 -10 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 9 100.5 -11 0.4 0.3 0.4 0 12
fill 9 93 -11 9 104 -11 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 8 100.5 -9 0.4 0.3 0.4 0 12
fill 8 93 -9 8 104 -9 minecraft:air
playsound minecraft:block.deepslate.break hostile @a[distance=0..] 8 100 -11 1.5 0.6
