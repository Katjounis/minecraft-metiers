particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 2 100.5 13 0.4 0.3 0.4 0 12
fill 2 93 13 2 104 13 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 2 100.5 14 0.4 0.3 0.4 0 12
fill 2 93 14 2 104 14 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 1 100.5 13 0.4 0.3 0.4 0 12
fill 1 93 13 1 104 13 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 1 100.5 14 0.4 0.3 0.4 0 12
fill 1 93 14 1 104 14 minecraft:air
playsound minecraft:block.deepslate.break hostile @a[distance=0..] 2 100 13 1.5 0.6
