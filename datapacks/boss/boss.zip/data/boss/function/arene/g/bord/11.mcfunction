particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -5 100.5 -11 0.4 0.3 0.4 0 12
fill -5 93 -11 -5 104 -11 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -5 100.5 -12 0.4 0.3 0.4 0 12
fill -5 93 -12 -5 104 -12 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -5 100.5 -13 0.4 0.3 0.4 0 12
fill -5 93 -13 -5 104 -13 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -4 100.5 -11 0.4 0.3 0.4 0 12
fill -4 93 -11 -4 104 -11 minecraft:air
playsound minecraft:block.deepslate.break hostile @a[distance=0..] -5 100 -11 1.5 0.6
