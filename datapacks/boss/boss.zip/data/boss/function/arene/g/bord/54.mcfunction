particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -13 100.5 3 0.4 0.3 0.4 0 12
fill -13 93 3 -13 104 3 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -14 100.5 3 0.4 0.3 0.4 0 12
fill -14 93 3 -14 104 3 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -12 100.5 2 0.4 0.3 0.4 0 12
fill -12 93 2 -12 104 2 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -13 100.5 2 0.4 0.3 0.4 0 12
fill -13 93 2 -13 104 2 minecraft:air
playsound minecraft:block.deepslate.break hostile @a[distance=0..] -13 100 3 1.5 0.6
