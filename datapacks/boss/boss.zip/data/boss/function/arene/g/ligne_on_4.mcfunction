setblock 2 100 -2 minecraft:crying_obsidian
setblock 3 100 -3 minecraft:crying_obsidian
setblock 4 100 -4 minecraft:crying_obsidian
setblock 5 100 -5 minecraft:crying_obsidian
