setblock 2 100 -2 minecraft:obsidian
setblock 3 100 -3 minecraft:obsidian
setblock 4 100 -4 minecraft:obsidian
setblock 5 100 -5 minecraft:obsidian
