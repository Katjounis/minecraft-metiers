particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 12 100.5 -5 0.4 0.3 0.4 0 12
fill 12 93 -5 12 104 -5 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 13 100.5 -5 0.4 0.3 0.4 0 12
fill 13 93 -5 13 104 -5 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 11 100.5 -4 0.4 0.3 0.4 0 12
fill 11 93 -4 11 104 -4 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 12 100.5 -4 0.4 0.3 0.4 0 12
fill 12 93 -4 12 104 -4 minecraft:air
playsound minecraft:block.deepslate.break hostile @a[distance=0..] 12 100 -5 1.5 0.6
