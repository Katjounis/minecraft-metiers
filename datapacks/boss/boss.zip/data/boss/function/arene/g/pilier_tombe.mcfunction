fill 10 103 -1 12 112 1 minecraft:air
setblock 11 101 1 minecraft:cobbled_deepslate_slab
setblock 8 101 -2 minecraft:polished_blackstone_bricks
setblock 13 101 2 minecraft:cobbled_deepslate_slab
setblock 9 101 -2 minecraft:polished_blackstone_bricks
setblock 10 101 2 minecraft:polished_blackstone_bricks
setblock 12 101 2 minecraft:cobbled_deepslate
setblock 8 101 2 minecraft:cobbled_deepslate
setblock 12 101 2 minecraft:polished_blackstone_bricks
particle minecraft:block{block_state:"minecraft:polished_blackstone_bricks"} 11 106 0 1.2 4 1.2 0 200
particle minecraft:explosion 11 104 0 1 3 1 0 6
playsound minecraft:entity.generic.explode hostile @a[distance=0..] 11 105 0 3 0.5
