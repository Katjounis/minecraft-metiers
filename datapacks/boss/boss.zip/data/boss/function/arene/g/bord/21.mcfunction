particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 9 100.5 -10 0.4 0.3 0.4 0 12
fill 9 93 -10 9 104 -10 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 9 100.5 -9 0.4 0.3 0.4 0 12
fill 9 93 -9 9 104 -9 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 10 100.5 -10 0.4 0.3 0.4 0 12
fill 10 93 -10 10 104 -10 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} 10 100.5 -9 0.4 0.3 0.4 0 12
fill 10 93 -9 10 104 -9 minecraft:air
playsound minecraft:block.deepslate.break hostile @a[distance=0..] 9 100 -10 1.5 0.6
