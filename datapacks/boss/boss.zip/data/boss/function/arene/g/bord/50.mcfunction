particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -10 100.5 8 0.4 0.3 0.4 0 12
fill -10 93 8 -10 104 8 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -11 100.5 8 0.4 0.3 0.4 0 12
fill -11 93 8 -11 104 8 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -10 100.5 7 0.4 0.3 0.4 0 12
fill -10 93 7 -10 104 7 minecraft:air
particle minecraft:block{block_state:"minecraft:deepslate_tiles"} -11 100.5 7 0.4 0.3 0.4 0 12
fill -11 93 7 -11 104 7 minecraft:air
playsound minecraft:block.deepslate.break hostile @a[distance=0..] -10 100 8 1.5 0.6
