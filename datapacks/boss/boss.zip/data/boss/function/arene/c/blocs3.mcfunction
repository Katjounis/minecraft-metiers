setblock 38 63 -5 minecraft:dirt
setblock 38 63 -4 minecraft:podzol
setblock 38 63 -3 minecraft:podzol
setblock 38 64 -3 minecraft:tall_dry_grass
setblock 38 63 -2 minecraft:coarse_dirt
setblock 38 63 -1 minecraft:coarse_dirt
setblock 38 64 -1 minecraft:tall_dry_grass
setblock 38 63 0 minecraft:podzol
setblock 38 64 0 minecraft:short_dry_grass
setblock 38 63 1 minecraft:coarse_dirt
setblock 38 63 2 minecraft:podzol
setblock 38 63 3 minecraft:coarse_dirt
setblock 38 64 3 minecraft:short_dry_grass
setblock 38 63 4 minecraft:podzol
setblock 38 64 4 minecraft:short_dry_grass
setblock 38 63 5 minecraft:podzol
setblock 38 64 5 minecraft:short_dry_grass
setblock 38 63 6 minecraft:mud
setblock 38 64 6 minecraft:short_dry_grass
setblock 38 63 7 minecraft:podzol
setblock 38 63 8 minecraft:coarse_dirt
setblock 38 64 8 minecraft:tall_dry_grass
setblock 38 63 9 minecraft:coarse_dirt
setblock 38 63 10 minecraft:podzol
setblock 38 63 11 minecraft:coarse_dirt
setblock 38 64 11 minecraft:tall_dry_grass
setblock 38 63 12 minecraft:coarse_dirt
setblock 38 64 12 minecraft:short_dry_grass
setblock 39 63 -8 minecraft:coarse_dirt
setblock 39 63 -7 minecraft:dirt
setblock 39 63 -6 minecraft:coarse_dirt
setblock 39 63 -5 minecraft:rooted_dirt
setblock 39 64 -5 minecraft:short_dry_grass
setblock 39 63 -4 minecraft:dirt
setblock 39 63 -3 minecraft:coarse_dirt
setblock 39 64 -3 minecraft:short_dry_grass
setblock 39 63 -2 minecraft:coarse_dirt
setblock 39 63 -1 minecraft:podzol
setblock 39 64 -1 minecraft:tall_dry_grass
setblock 39 63 0 minecraft:podzol
setblock 39 63 1 minecraft:coarse_dirt
setblock 39 64 1 minecraft:short_dry_grass
setblock 39 63 2 minecraft:rooted_dirt
setblock 39 63 3 minecraft:coarse_dirt
setblock 39 64 3 minecraft:short_dry_grass
setblock 39 63 4 minecraft:coarse_dirt
setblock 39 63 5 minecraft:coarse_dirt
setblock 39 64 5 minecraft:tall_dry_grass
setblock 39 63 6 minecraft:podzol
setblock 39 63 7 minecraft:podzol
setblock 39 63 8 minecraft:podzol
setblock 39 64 8 minecraft:short_dry_grass
setblock 40 63 0 minecraft:podzol
setblock 40 64 0 minecraft:short_dry_grass
setblock 0 63 -3 minecraft:mud
setblock 0 64 -3 minecraft:air
setblock 0 63 -4 minecraft:mud
setblock 0 64 -4 minecraft:air
setblock 0 63 -5 minecraft:mud
setblock 0 64 -5 minecraft:air
setblock 0 63 -6 minecraft:mud
setblock 0 64 -6 minecraft:air
setblock 0 63 -7 minecraft:mud
setblock 0 64 -7 minecraft:air
setblock 0 63 -8 minecraft:mud
setblock 0 64 -8 minecraft:air
setblock 0 63 -9 minecraft:mud
setblock 0 64 -9 minecraft:air
setblock 0 63 -10 minecraft:mud
setblock 0 64 -10 minecraft:air
setblock 0 63 -11 minecraft:mud
setblock 0 64 -11 minecraft:air
setblock 0 63 -12 minecraft:mud
setblock 0 64 -12 minecraft:air
setblock 0 63 -13 minecraft:mud
setblock 0 64 -13 minecraft:air
setblock 0 63 -14 minecraft:mud
setblock 0 64 -14 minecraft:air
setblock 0 63 -15 minecraft:mud
setblock 0 64 -15 minecraft:air
setblock 0 63 -16 minecraft:mud
setblock 0 64 -16 minecraft:air
setblock 0 63 -17 minecraft:mud
setblock 0 64 -17 minecraft:air
setblock 0 63 -18 minecraft:mud
setblock 0 64 -18 minecraft:air
setblock 0 63 -19 minecraft:mud
setblock 0 64 -19 minecraft:air
setblock -20 64 -8 minecraft:dark_oak_fence[north=true,south=true]
setblock -20 65 -8 minecraft:dark_oak_fence
setblock -20 64 -7 minecraft:dark_oak_fence[north=true,south=true]
setblock -20 65 -7 minecraft:dark_oak_fence
setblock -20 64 -5 minecraft:dark_oak_fence[north=true,south=true]
setblock -20 64 -3 minecraft:dark_oak_fence[north=true,south=true]
setblock -20 65 -3 minecraft:dark_oak_fence
setblock -20 64 -2 minecraft:dark_oak_fence[north=true,south=true]
setblock -20 64 -1 minecraft:dark_oak_fence[north=true,south=true]
setblock -20 64 0 minecraft:dark_oak_fence[north=true,south=true]
setblock -20 65 0 minecraft:dark_oak_fence
setblock 8 64 -21 minecraft:dark_oak_fence[east=true,west=true]
setblock 8 65 -21 minecraft:dark_oak_fence
setblock 9 64 -21 minecraft:dark_oak_fence[east=true,west=true]
setblock 10 64 -21 minecraft:dark_oak_fence[east=true,west=true]
setblock 12 64 -21 minecraft:dark_oak_fence[east=true,west=true]
setblock 12 65 -21 minecraft:dark_oak_fence
setblock 13 64 -21 minecraft:dark_oak_fence[east=true,west=true]
setblock 14 64 -21 minecraft:dark_oak_fence[east=true,west=true]
setblock 15 64 -21 minecraft:dark_oak_fence[east=true,west=true]
setblock 15 65 -21 minecraft:dark_oak_fence
setblock -14 64 18 minecraft:dark_oak_fence[east=true,west=true]
setblock -14 65 18 minecraft:dark_oak_fence
setblock -13 64 18 minecraft:dark_oak_fence[east=true,west=true]
setblock -11 64 18 minecraft:dark_oak_fence[east=true,west=true]
setblock -11 65 18 minecraft:dark_oak_fence
setblock -10 64 18 minecraft:dark_oak_fence[east=true,west=true]
setblock -10 65 18 minecraft:dark_oak_fence
setblock -9 64 18 minecraft:dark_oak_fence[east=true,west=true]
setblock -9 65 18 minecraft:dark_oak_fence
setblock -8 64 18 minecraft:dark_oak_fence[east=true,west=true]
setblock -8 65 18 minecraft:dark_oak_fence
setblock 20 64 6 minecraft:dark_oak_fence[north=true,south=true]
setblock 20 64 7 minecraft:dark_oak_fence[north=true,south=true]
setblock 20 64 8 minecraft:dark_oak_fence[north=true,south=true]
setblock 20 65 8 minecraft:dark_oak_fence
setblock 20 64 9 minecraft:dark_oak_fence[north=true,south=true]
setblock 20 65 9 minecraft:dark_oak_fence
setblock 20 64 10 minecraft:dark_oak_fence[north=true,south=true]
setblock 20 64 11 minecraft:dark_oak_fence[north=true,south=true]
setblock 16 64 5 minecraft:dark_oak_fence
setblock 16 65 5 minecraft:dark_oak_fence
setblock 16 66 5 minecraft:hay_block
setblock 16 67 5 minecraft:carved_pumpkin[facing=west]
setblock 16 68 5 minecraft:black_carpet
setblock 16 66 4 minecraft:dark_oak_fence[north=true,south=true]
setblock 16 66 6 minecraft:dark_oak_fence[north=true,south=true]
setblock 0 64 17 minecraft:dark_oak_fence
setblock 0 65 17 minecraft:dark_oak_fence
setblock 0 66 17 minecraft:hay_block
setblock 0 67 17 minecraft:carved_pumpkin[facing=north]
setblock 0 68 17 minecraft:black_carpet
setblock -1 66 17 minecraft:dark_oak_fence[east=true,west=true]
setblock 1 66 17 minecraft:dark_oak_fence[east=true,west=true]
setblock -16 64 5 minecraft:dark_oak_fence
setblock -16 65 5 minecraft:dark_oak_fence
setblock -16 66 5 minecraft:hay_block
setblock -16 67 5 minecraft:carved_pumpkin[facing=east]
setblock -16 68 5 minecraft:black_carpet
setblock -16 66 4 minecraft:dark_oak_fence[north=true,south=true]
setblock -16 66 6 minecraft:dark_oak_fence[north=true,south=true]
setblock -10 64 -14 minecraft:dark_oak_fence
setblock -10 65 -14 minecraft:dark_oak_fence
setblock -10 66 -14 minecraft:hay_block
setblock -10 67 -14 minecraft:carved_pumpkin[facing=south]
setblock -10 68 -14 minecraft:black_carpet
setblock -11 66 -14 minecraft:dark_oak_fence[east=true,west=true]
setblock -9 66 -14 minecraft:dark_oak_fence[east=true,west=true]
setblock 10 64 -14 minecraft:dark_oak_fence
setblock 10 65 -14 minecraft:dark_oak_fence
setblock 10 66 -14 minecraft:hay_block
setblock 10 67 -14 minecraft:carved_pumpkin[facing=south]
setblock 10 68 -14 minecraft:black_carpet
setblock 9 66 -14 minecraft:dark_oak_fence[east=true,west=true]
setblock 11 66 -14 minecraft:dark_oak_fence[east=true,west=true]
setblock 9 64 4 minecraft:jack_o_lantern[facing=west]
setblock -6 64 9 minecraft:jack_o_lantern[facing=north]
setblock -10 64 -5 minecraft:jack_o_lantern[facing=east]
setblock 4 64 -11 minecraft:jack_o_lantern[facing=south]
setblock 15 64 -2 minecraft:jack_o_lantern[facing=west]
setblock -2 64 16 minecraft:jack_o_lantern[facing=north]
setblock -16 64 6 minecraft:jack_o_lantern[facing=east]
setblock 12 64 12 minecraft:jack_o_lantern[facing=north]
fill -30 64 -14 -30 72 -14 minecraft:dark_oak_log
setblock -29 70 -14 minecraft:dark_oak_fence
setblock -28 71 -14 minecraft:dark_oak_fence
setblock -31 69 -13 minecraft:dark_oak_fence
setblock -30 71 -15 minecraft:dark_oak_fence
setblock -30 72 -16 minecraft:dark_oak_fence
setblock -32 70 -14 minecraft:dark_oak_fence
fill 31 64 -20 31 74 -20 minecraft:dark_oak_log
setblock 32 72 -20 minecraft:dark_oak_fence
setblock 33 73 -20 minecraft:dark_oak_fence
setblock 30 71 -19 minecraft:dark_oak_fence
setblock 31 73 -21 minecraft:dark_oak_fence
setblock 31 74 -22 minecraft:dark_oak_fence
setblock 29 72 -20 minecraft:dark_oak_fence
fill -27 64 24 -27 71 24 minecraft:dark_oak_log
setblock -26 69 24 minecraft:dark_oak_fence
setblock -25 70 24 minecraft:dark_oak_fence
setblock -28 68 25 minecraft:dark_oak_fence
setblock -27 70 23 minecraft:dark_oak_fence
setblock -27 71 22 minecraft:dark_oak_fence
setblock -29 69 24 minecraft:dark_oak_fence
fill 26 64 27 26 73 27 minecraft:dark_oak_log
setblock 27 71 27 minecraft:dark_oak_fence
setblock 28 72 27 minecraft:dark_oak_fence
setblock 25 70 28 minecraft:dark_oak_fence
setblock 26 72 26 minecraft:dark_oak_fence
setblock 26 73 25 minecraft:dark_oak_fence
setblock 24 71 27 minecraft:dark_oak_fence
fill 4 64 -34 4 75 -34 minecraft:dark_oak_log
setblock 5 73 -34 minecraft:dark_oak_fence
setblock 6 74 -34 minecraft:dark_oak_fence
setblock 3 72 -33 minecraft:dark_oak_fence
setblock 4 74 -35 minecraft:dark_oak_fence
setblock 4 75 -36 minecraft:dark_oak_fence
setblock 2 73 -34 minecraft:dark_oak_fence
fill -36 64 2 -36 70 2 minecraft:dark_oak_log
setblock -35 68 2 minecraft:dark_oak_fence
setblock -34 69 2 minecraft:dark_oak_fence
setblock -37 67 3 minecraft:dark_oak_fence
setblock -36 69 1 minecraft:dark_oak_fence
setblock -36 70 0 minecraft:dark_oak_fence
setblock -38 68 2 minecraft:dark_oak_fence
fill 24 64 0 24 71 0 minecraft:barrier
fill 24 64 1 24 71 1 minecraft:barrier
fill 24 64 2 24 71 2 minecraft:barrier
fill 24 64 3 24 71 3 minecraft:barrier
fill 24 64 3 24 71 3 minecraft:barrier
fill 24 64 4 24 71 4 minecraft:barrier
fill 23 64 5 23 71 5 minecraft:barrier
fill 23 64 6 23 71 6 minecraft:barrier
fill 23 64 7 23 71 7 minecraft:barrier
fill 23 64 7 23 71 7 minecraft:barrier
fill 23 64 8 23 71 8 minecraft:barrier
fill 22 64 9 22 71 9 minecraft:barrier
fill 22 64 10 22 71 10 minecraft:barrier
fill 22 64 11 22 71 11 minecraft:barrier
fill 21 64 11 21 71 11 minecraft:barrier
fill 21 64 12 21 71 12 minecraft:barrier
fill 20 64 13 20 71 13 minecraft:barrier
fill 20 64 13 20 71 13 minecraft:barrier
fill 19 64 14 19 71 14 minecraft:barrier
fill 19 64 15 19 71 15 minecraft:barrier
fill 18 64 15 18 71 15 minecraft:barrier
fill 18 64 16 18 71 16 minecraft:barrier
fill 17 64 17 17 71 17 minecraft:barrier
fill 17 64 17 17 71 17 minecraft:barrier
fill 16 64 18 16 71 18 minecraft:barrier
fill 15 64 18 15 71 18 minecraft:barrier
fill 15 64 19 15 71 19 minecraft:barrier
fill 14 64 19 14 71 19 minecraft:barrier
fill 13 64 20 13 71 20 minecraft:barrier
fill 13 64 20 13 71 20 minecraft:barrier
fill 12 64 21 12 71 21 minecraft:barrier
fill 11 64 21 11 71 21 minecraft:barrier
fill 11 64 22 11 71 22 minecraft:barrier
fill 10 64 22 10 71 22 minecraft:barrier
fill 9 64 22 9 71 22 minecraft:barrier
fill 8 64 23 8 71 23 minecraft:barrier
fill 7 64 23 7 71 23 minecraft:barrier
fill 7 64 23 7 71 23 minecraft:barrier
fill 6 64 23 6 71 23 minecraft:barrier
fill 5 64 23 5 71 23 minecraft:barrier
fill 4 64 24 4 71 24 minecraft:barrier
fill 3 64 24 3 71 24 minecraft:barrier
fill 3 64 24 3 71 24 minecraft:barrier
fill 2 64 24 2 71 24 minecraft:barrier
fill 1 64 24 1 71 24 minecraft:barrier
fill 0 64 24 0 71 24 minecraft:barrier
fill -1 64 24 -1 71 24 minecraft:barrier
fill -2 64 24 -2 71 24 minecraft:barrier
fill -3 64 24 -3 71 24 minecraft:barrier
fill -3 64 24 -3 71 24 minecraft:barrier
fill -4 64 24 -4 71 24 minecraft:barrier
fill -5 64 23 -5 71 23 minecraft:barrier
fill -6 64 23 -6 71 23 minecraft:barrier
fill -7 64 23 -7 71 23 minecraft:barrier
fill -7 64 23 -7 71 23 minecraft:barrier
fill -8 64 23 -8 71 23 minecraft:barrier
fill -9 64 22 -9 71 22 minecraft:barrier
fill -10 64 22 -10 71 22 minecraft:barrier
fill -11 64 22 -11 71 22 minecraft:barrier
fill -11 64 21 -11 71 21 minecraft:barrier
fill -12 64 21 -12 71 21 minecraft:barrier
fill -13 64 20 -13 71 20 minecraft:barrier
fill -13 64 20 -13 71 20 minecraft:barrier
fill -14 64 19 -14 71 19 minecraft:barrier
fill -15 64 19 -15 71 19 minecraft:barrier
fill -15 64 18 -15 71 18 minecraft:barrier
fill -16 64 18 -16 71 18 minecraft:barrier
fill -17 64 17 -17 71 17 minecraft:barrier
fill -17 64 17 -17 71 17 minecraft:barrier
fill -18 64 16 -18 71 16 minecraft:barrier
fill -18 64 15 -18 71 15 minecraft:barrier
fill -19 64 15 -19 71 15 minecraft:barrier
fill -19 64 14 -19 71 14 minecraft:barrier
fill -20 64 13 -20 71 13 minecraft:barrier
fill -20 64 13 -20 71 13 minecraft:barrier
fill -21 64 12 -21 71 12 minecraft:barrier
fill -21 64 11 -21 71 11 minecraft:barrier
fill -22 64 11 -22 71 11 minecraft:barrier
fill -22 64 10 -22 71 10 minecraft:barrier
fill -22 64 9 -22 71 9 minecraft:barrier
fill -23 64 8 -23 71 8 minecraft:barrier
fill -23 64 7 -23 71 7 minecraft:barrier
fill -23 64 7 -23 71 7 minecraft:barrier
fill -23 64 6 -23 71 6 minecraft:barrier
fill -23 64 5 -23 71 5 minecraft:barrier
fill -24 64 4 -24 71 4 minecraft:barrier
fill -24 64 3 -24 71 3 minecraft:barrier
fill -24 64 3 -24 71 3 minecraft:barrier
fill -24 64 2 -24 71 2 minecraft:barrier
fill -24 64 1 -24 71 1 minecraft:barrier
fill -24 64 0 -24 71 0 minecraft:barrier
fill -24 64 -1 -24 71 -1 minecraft:barrier
fill -24 64 -2 -24 71 -2 minecraft:barrier
fill -24 64 -3 -24 71 -3 minecraft:barrier
fill -24 64 -3 -24 71 -3 minecraft:barrier
fill -24 64 -4 -24 71 -4 minecraft:barrier
fill -23 64 -5 -23 71 -5 minecraft:barrier
fill -23 64 -6 -23 71 -6 minecraft:barrier
fill -23 64 -7 -23 71 -7 minecraft:barrier
fill -23 64 -7 -23 71 -7 minecraft:barrier
fill -23 64 -8 -23 71 -8 minecraft:barrier
fill -22 64 -9 -22 71 -9 minecraft:barrier
fill -22 64 -10 -22 71 -10 minecraft:barrier
fill -22 64 -11 -22 71 -11 minecraft:barrier
fill -21 64 -11 -21 71 -11 minecraft:barrier
fill -21 64 -12 -21 71 -12 minecraft:barrier
fill -20 64 -13 -20 71 -13 minecraft:barrier
fill -20 64 -13 -20 71 -13 minecraft:barrier
fill -19 64 -14 -19 71 -14 minecraft:barrier
fill -19 64 -15 -19 71 -15 minecraft:barrier
fill -18 64 -15 -18 71 -15 minecraft:barrier
fill -18 64 -16 -18 71 -16 minecraft:barrier
fill -17 64 -17 -17 71 -17 minecraft:barrier
fill -17 64 -17 -17 71 -17 minecraft:barrier
fill -16 64 -18 -16 71 -18 minecraft:barrier
fill -15 64 -18 -15 71 -18 minecraft:barrier
fill -15 64 -19 -15 71 -19 minecraft:barrier
fill -14 64 -19 -14 71 -19 minecraft:barrier
fill -13 64 -20 -13 71 -20 minecraft:barrier
fill -13 64 -20 -13 71 -20 minecraft:barrier
fill -12 64 -21 -12 71 -21 minecraft:barrier
fill -11 64 -21 -11 71 -21 minecraft:barrier
fill -11 64 -22 -11 71 -22 minecraft:barrier
fill -10 64 -22 -10 71 -22 minecraft:barrier
fill -9 64 -22 -9 71 -22 minecraft:barrier
fill -8 64 -23 -8 71 -23 minecraft:barrier
fill -7 64 -23 -7 71 -23 minecraft:barrier
fill -7 64 -23 -7 71 -23 minecraft:barrier
fill -6 64 -23 -6 71 -23 minecraft:barrier
fill -5 64 -23 -5 71 -23 minecraft:barrier
fill -4 64 -24 -4 71 -24 minecraft:barrier
fill -3 64 -24 -3 71 -24 minecraft:barrier
fill -3 64 -24 -3 71 -24 minecraft:barrier
fill -2 64 -24 -2 71 -24 minecraft:barrier
fill -1 64 -24 -1 71 -24 minecraft:barrier
fill 0 64 -24 0 71 -24 minecraft:barrier
fill 1 64 -24 1 71 -24 minecraft:barrier
fill 2 64 -24 2 71 -24 minecraft:barrier
fill 3 64 -24 3 71 -24 minecraft:barrier
fill 3 64 -24 3 71 -24 minecraft:barrier
fill 4 64 -24 4 71 -24 minecraft:barrier
fill 5 64 -23 5 71 -23 minecraft:barrier
fill 6 64 -23 6 71 -23 minecraft:barrier
fill 7 64 -23 7 71 -23 minecraft:barrier
fill 7 64 -23 7 71 -23 minecraft:barrier
fill 8 64 -23 8 71 -23 minecraft:barrier
fill 9 64 -22 9 71 -22 minecraft:barrier
fill 10 64 -22 10 71 -22 minecraft:barrier
fill 11 64 -22 11 71 -22 minecraft:barrier
fill 11 64 -21 11 71 -21 minecraft:barrier
fill 12 64 -21 12 71 -21 minecraft:barrier
fill 13 64 -20 13 71 -20 minecraft:barrier
fill 13 64 -20 13 71 -20 minecraft:barrier
fill 14 64 -19 14 71 -19 minecraft:barrier
fill 15 64 -19 15 71 -19 minecraft:barrier
fill 15 64 -18 15 71 -18 minecraft:barrier
fill 16 64 -18 16 71 -18 minecraft:barrier
fill 17 64 -17 17 71 -17 minecraft:barrier
fill 17 64 -17 17 71 -17 minecraft:barrier
fill 18 64 -16 18 71 -16 minecraft:barrier
fill 18 64 -15 18 71 -15 minecraft:barrier
fill 19 64 -15 19 71 -15 minecraft:barrier
fill 19 64 -14 19 71 -14 minecraft:barrier
fill 20 64 -13 20 71 -13 minecraft:barrier
fill 20 64 -13 20 71 -13 minecraft:barrier
fill 21 64 -12 21 71 -12 minecraft:barrier
fill 21 64 -11 21 71 -11 minecraft:barrier
fill 22 64 -11 22 71 -11 minecraft:barrier
fill 22 64 -10 22 71 -10 minecraft:barrier
fill 22 64 -9 22 71 -9 minecraft:barrier
fill 23 64 -8 23 71 -8 minecraft:barrier
fill 23 64 -7 23 71 -7 minecraft:barrier
fill 23 64 -7 23 71 -7 minecraft:barrier
fill 23 64 -6 23 71 -6 minecraft:barrier
fill 23 64 -5 23 71 -5 minecraft:barrier
fill 24 64 -4 24 71 -4 minecraft:barrier
fill 24 64 -3 24 71 -3 minecraft:barrier
fill 24 64 -3 24 71 -3 minecraft:barrier
fill 24 64 -2 24 71 -2 minecraft:barrier
fill 24 64 -1 24 71 -1 minecraft:barrier
setblock -18 70 -18 minecraft:light[level=5]
setblock -18 70 -9 minecraft:light[level=5]
setblock -18 70 0 minecraft:light[level=5]
setblock -18 70 9 minecraft:light[level=5]
setblock -18 70 18 minecraft:light[level=5]
setblock -9 70 -18 minecraft:light[level=5]
setblock -9 70 -9 minecraft:light[level=5]
setblock -9 70 0 minecraft:light[level=5]
setblock -9 70 9 minecraft:light[level=5]
setblock -9 70 18 minecraft:light[level=5]
setblock 0 70 -18 minecraft:light[level=5]
setblock 0 70 -9 minecraft:light[level=5]
setblock 0 70 0 minecraft:light[level=5]
setblock 0 70 9 minecraft:light[level=5]
setblock 0 70 18 minecraft:light[level=5]
setblock 9 70 -18 minecraft:light[level=5]
setblock 9 70 -9 minecraft:light[level=5]
setblock 9 70 0 minecraft:light[level=5]
setblock 9 70 9 minecraft:light[level=5]
setblock 9 70 18 minecraft:light[level=5]
setblock 18 70 -18 minecraft:light[level=5]
setblock 18 70 -9 minecraft:light[level=5]
setblock 18 70 0 minecraft:light[level=5]
setblock 18 70 9 minecraft:light[level=5]
setblock 18 70 18 minecraft:light[level=5]
