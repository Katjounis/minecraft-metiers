execute in boss:corbeau run function boss:arene/c/blocs0
execute in boss:corbeau run function boss:arene/c/blocs1
execute in boss:corbeau run function boss:arene/c/blocs2
execute in boss:corbeau run function boss:arene/c/blocs3
