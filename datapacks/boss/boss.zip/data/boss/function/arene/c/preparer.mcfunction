execute in boss:corbeau run kill @e[tag=bs.e,distance=0..]
execute in boss:corbeau run summon minecraft:marker 16.5 67.5 5.5 {Tags:["bs.e","bs.epv","bs.epv1"]}
execute in boss:corbeau run summon minecraft:marker 0.5 67.5 17.5 {Tags:["bs.e","bs.epv","bs.epv2"]}
execute in boss:corbeau run summon minecraft:marker -15.5 67.5 5.5 {Tags:["bs.e","bs.epv","bs.epv3"]}
execute in boss:corbeau run summon minecraft:marker -9.5 67.5 -13.5 {Tags:["bs.e","bs.epv","bs.epv4"]}
execute in boss:corbeau run summon minecraft:marker 10.5 67.5 -13.5 {Tags:["bs.e","bs.epv","bs.epv5"]}
scoreboard players set @e[type=minecraft:marker,tag=bs.epv1,limit=1] bs.k 1
scoreboard players set @e[type=minecraft:marker,tag=bs.epv2,limit=1] bs.k 2
scoreboard players set @e[type=minecraft:marker,tag=bs.epv3,limit=1] bs.k 3
scoreboard players set @e[type=minecraft:marker,tag=bs.epv4,limit=1] bs.k 4
scoreboard players set @e[type=minecraft:marker,tag=bs.epv5,limit=1] bs.k 5
execute as @e[type=minecraft:marker,tag=bs.epv1,limit=1] at @s run rotate @s facing 0 67.5 0
execute as @e[type=minecraft:marker,tag=bs.epv2,limit=1] at @s run rotate @s facing 0 67.5 0
execute as @e[type=minecraft:marker,tag=bs.epv3,limit=1] at @s run rotate @s facing 0 67.5 0
execute as @e[type=minecraft:marker,tag=bs.epv4,limit=1] at @s run rotate @s facing 0 67.5 0
execute as @e[type=minecraft:marker,tag=bs.epv5,limit=1] at @s run rotate @s facing 0 67.5 0
execute in boss:corbeau run summon minecraft:marker 9.5 64 4.5 {Tags:["bs.e","bs.cit"]}
execute in boss:corbeau run summon minecraft:marker -5.5 64 9.5 {Tags:["bs.e","bs.cit"]}
execute in boss:corbeau run summon minecraft:marker -9.5 64 -4.5 {Tags:["bs.e","bs.cit"]}
execute in boss:corbeau run summon minecraft:marker 4.5 64 -10.5 {Tags:["bs.e","bs.cit"]}
execute in boss:corbeau run summon minecraft:marker 15.5 64 -1.5 {Tags:["bs.e","bs.cit"]}
execute in boss:corbeau run summon minecraft:marker -1.5 64 16.5 {Tags:["bs.e","bs.cit"]}
execute in boss:corbeau run summon minecraft:marker -15.5 64 6.5 {Tags:["bs.e","bs.cit"]}
execute in boss:corbeau run summon minecraft:marker 12.5 64 12.5 {Tags:["bs.e","bs.cit"]}
execute in boss:corbeau run summon minecraft:item_display -40 103 -60 {id:"minecraft:item_display",Tags:["bs.e","bs.lune"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:lune_racine_l"}},item_display:"none",teleport_duration:1,view_range:8.0f,brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2f,2f,2f]}}
execute as @e[type=minecraft:item_display,tag=bs.lune] at @s run tp @s ~ ~ ~ facing 0 70 0
execute as @e[type=minecraft:item_display,tag=bs.lune] run data merge entity @s {transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[12f,12f,12f]}}
execute in boss:corbeau run summon minecraft:item_display 22.0 79 0.0 {Tags:["bs.e","bs.amb","bs.vol"],Rotation:[0f,0f],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:oiseau_a_racine"}},item_display:"none",teleport_duration:1,view_range:4f,brightness:{sky:0,block:6},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.4f,2.4f,2.4f]}}
execute in boss:corbeau run summon minecraft:item_display 15.6 82 15.6 {Tags:["bs.e","bs.amb","bs.vol"],Rotation:[45f,0f],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:oiseau_a_racine"}},item_display:"none",teleport_duration:1,view_range:4f,brightness:{sky:0,block:6},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.4f,2.4f,2.4f]}}
execute in boss:corbeau run summon minecraft:item_display 0.0 85 22.0 {Tags:["bs.e","bs.amb","bs.vol"],Rotation:[90f,0f],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:oiseau_a_racine"}},item_display:"none",teleport_duration:1,view_range:4f,brightness:{sky:0,block:6},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.4f,2.4f,2.4f]}}
execute in boss:corbeau run summon minecraft:item_display -15.5 79 15.6 {Tags:["bs.e","bs.amb","bs.vol"],Rotation:[135f,0f],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:oiseau_a_racine"}},item_display:"none",teleport_duration:1,view_range:4f,brightness:{sky:0,block:6},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.4f,2.4f,2.4f]}}
execute in boss:corbeau run summon minecraft:item_display -22.0 82 0.0 {Tags:["bs.e","bs.amb","bs.vol"],Rotation:[180f,0f],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:oiseau_a_racine"}},item_display:"none",teleport_duration:1,view_range:4f,brightness:{sky:0,block:6},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.4f,2.4f,2.4f]}}
execute in boss:corbeau run summon minecraft:item_display -15.6 85 -15.5 {Tags:["bs.e","bs.amb","bs.vol"],Rotation:[225f,0f],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:oiseau_a_racine"}},item_display:"none",teleport_duration:1,view_range:4f,brightness:{sky:0,block:6},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.4f,2.4f,2.4f]}}
execute in boss:corbeau run summon minecraft:item_display -0.1 79 -22.0 {Tags:["bs.e","bs.amb","bs.vol"],Rotation:[270f,0f],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:oiseau_a_racine"}},item_display:"none",teleport_duration:1,view_range:4f,brightness:{sky:0,block:6},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.4f,2.4f,2.4f]}}
execute in boss:corbeau run summon minecraft:item_display 15.5 82 -15.6 {Tags:["bs.e","bs.amb","bs.vol"],Rotation:[315f,0f],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:oiseau_a_racine"}},item_display:"none",teleport_duration:1,view_range:4f,brightness:{sky:0,block:6},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.4f,2.4f,2.4f]}}
