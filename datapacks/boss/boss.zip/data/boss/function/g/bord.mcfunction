execute in boss:grimoire run function boss:arene/g/bord_tick
execute if score #bord bs.g matches 55.. run scoreboard players set #bordon bs.g 0
