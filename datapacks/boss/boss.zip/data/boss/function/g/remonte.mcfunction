tp @s ~ ~0.25 ~
execute if entity @s[y=106,dy=50] run scoreboard players set #etat bs.g 0
execute if entity @s[y=106,dy=50] run scoreboard players set #t bs.g 61
