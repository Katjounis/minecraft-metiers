scoreboard players set #atk bs.g 130
execute if score #ph bs.g matches 2 run scoreboard players set #atk bs.g 105
execute if score #ph bs.g matches 3 run scoreboard players set #atk bs.g 80
execute if score #ph bs.g matches 1 store result score #r bs.tmp run random value 1..3
execute if score #ph bs.g matches 2.. store result score #r bs.tmp run random value 1..5
execute if score #r bs.tmp matches 1 run return run function boss:g/at/pages
execute if score #r bs.tmp matches 2..3 run return run function boss:g/at/tentacule
execute if score #r bs.tmp matches 4 run return run function boss:g/at/runes
execute if score #r bs.tmp matches 5 run return run function boss:g/at/livres
