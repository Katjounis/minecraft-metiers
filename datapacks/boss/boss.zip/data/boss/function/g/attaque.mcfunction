scoreboard players set #atk bs.g 95
execute if score #ph bs.g matches 2 run scoreboard players set #atk bs.g 75
execute if score #ph bs.g matches 3 run scoreboard players set #atk bs.g 55
execute if score #ph bs.g matches 2.. as @r[tag=bs.joue] at @s run summon minecraft:marker ~ 101 ~ {Tags:["bs.e","bs.fx","bs.encre"]}
execute if score #ph bs.g matches 3 as @r[tag=bs.joue] at @s run function boss:g/at/tent_cible
scoreboard players operation #red bs.tmp = #atk bs.g
scoreboard players operation #red bs.tmp *= #rg bs.ev
scoreboard players operation #red bs.tmp /= #40 bs.tmp
scoreboard players operation #atk bs.g -= #red bs.tmp
execute store result score #r2 bs.tmp run random value 1..4
execute if score #r2 bs.tmp matches 1 run return run function boss:g/at/marque
execute if score #r2 bs.tmp matches 2 if score #rg bs.ev matches 6.. run return run function boss:g/at/festin
execute if score #ph bs.g matches 1 store result score #r bs.tmp run random value 1..3
execute if score #ph bs.g matches 2.. store result score #r bs.tmp run random value 1..5
execute if score #r bs.tmp matches 1 run return run function boss:g/at/pages
execute if score #r bs.tmp matches 2..3 run return run function boss:g/at/tentacule
execute if score #r bs.tmp matches 4 run return run function boss:g/at/runes
execute if score #r bs.tmp matches 5 run return run function boss:g/at/livres
