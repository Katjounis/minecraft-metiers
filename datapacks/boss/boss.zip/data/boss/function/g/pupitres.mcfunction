execute as @e[type=minecraft:marker,tag=bs.pu,tag=!bs.pu.mort] at @s run function boss:g/pupitre/tick
execute store result score #nact bs.g if entity @e[type=minecraft:marker,tag=bs.pu.on]
execute if score #etat bs.g matches 0 if score #nact bs.g >= #need bs.g run function boss:g/enchainer
