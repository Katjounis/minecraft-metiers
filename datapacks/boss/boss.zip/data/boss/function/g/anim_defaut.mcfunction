execute if score #etat bs.g matches 1 run return run function boss:rig/grimoire/jouer/enchaine
function boss:rig/grimoire/jouer/vol
