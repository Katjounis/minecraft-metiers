scoreboard players set #ph bs.g 3
scoreboard players set #atk bs.g 70
execute unless score #etat bs.g matches 1 run function boss:rig/grimoire/jouer/rugit
title @a[tag=bs.joue] times 8 60 16
title @a[tag=bs.joue] subtitle {"text":"Le sol s'effondre ! Plus que 2 pupitres.","color":"white"}
title @a[tag=bs.joue] title {"text":"PHASE 3","color":"light_purple","bold":true}
title @a[tag=bs.joue] actionbar {"text":"Éloigne-toi du bord : il tombe dans le vide !","color":"gold"}
execute as @a[tag=bs.joue] at @s run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 1 0.9
execute as @e[type=minecraft:marker,tag=bs.pu3] run function boss:g/pupitre/eteindre
execute as @e[type=minecraft:marker,tag=bs.pu4] run function boss:g/pupitre/eteindre
tag @e[type=minecraft:marker,tag=bs.pu3] add bs.pu.mort
tag @e[type=minecraft:marker,tag=bs.pu4] add bs.pu.mort
execute in boss:grimoire run function boss:arene/g/pupitre_casse_3
execute in boss:grimoire run function boss:arene/g/pupitre_casse_4
execute if score #need bs.g matches 3.. run scoreboard players set #need bs.g 2
scoreboard players set #bord bs.g 0
scoreboard players set #bordon bs.g 1
