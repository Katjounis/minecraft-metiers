execute if score #etat bs.ev matches 4 run return 0
execute unless score #etat bs.g matches 1 run rotate @s facing entity @p[tag=bs.joue] feet
tp @e[type=minecraft:item_display,tag=bs.os.grimoire] ~ ~ ~ ~ 0
scoreboard players add #t bs.g 1
execute if score #etat bs.g matches 0 run function boss:g/vol
execute if score #etat bs.g matches 1 run function boss:g/enchaine
execute if score #etat bs.g matches 2 run function boss:g/remonte
execute if score #tk bs.ev matches 0 run function boss:g/pupitres
execute if score #tk bs.ev matches 10 run function boss:g/pupitres
execute store result score #hp bs.g run data get entity @s Health
scoreboard players operation #pct bs.g = #hp bs.g
scoreboard players operation #pct bs.g *= #100 bs.tmp
scoreboard players operation #pct bs.g /= #pvmax bs.ev
execute if score #ph bs.g matches 1 if score #pct bs.g matches ..60 run function boss:g/phase2
execute if score #ph bs.g matches 2 if score #pct bs.g matches ..30 run function boss:g/phase3
