execute as @e[type=minecraft:marker,tag=bs.ligne] at @s run function boss:g/at/ligne_tick
execute as @e[type=minecraft:marker,tag=bs.frappe] at @s run function boss:g/at/frappe_tick
execute as @e[type=minecraft:item_display,tag=bs.tentd0] at @s run function boss:g/at/tentd0
execute as @e[type=minecraft:item_display,tag=bs.tentd1] at @s run function boss:g/at/tentd1
execute as @e[type=minecraft:marker,tag=bs.encre] at @s run function boss:g/at/encre_tick
execute as @e[type=minecraft:item_display,tag=bs.proj] at @s run function boss:g/at/rune_tick
execute as @e[type=minecraft:marker,tag=bs.zone] at @s run function boss:zone/tick
