scoreboard players set #ph bs.g 2
scoreboard players set #atk bs.g 70
scoreboard players set #pilier bs.g 1
execute unless score #etat bs.g matches 1 run function boss:rig/grimoire/jouer/rugit
title @a[tag=bs.joue] times 8 60 16
title @a[tag=bs.joue] subtitle {"text":"Livres et runes !","color":"white"}
title @a[tag=bs.joue] title {"text":"PHASE 2","color":"light_purple","bold":true}
title @a[tag=bs.joue] actionbar {"text":"Un pilier s'effondre","color":"gold"}
execute as @a[tag=bs.joue] at @s run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.8 1.3
execute in boss:grimoire run function boss:arene/g/pilier_tombe
scoreboard players set #nl bs.tmp 2
execute in boss:grimoire run function boss:g/at/livre_un
