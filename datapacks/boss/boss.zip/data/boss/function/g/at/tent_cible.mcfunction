summon minecraft:marker ~ 101 ~ {Tags:["bs.e","bs.fx","bs.frappe"]}
summon minecraft:item_display ~ 101 ~ {Tags:["bs.e","bs.fx","bs.tentd","bs.tentd0"],Rotation:[0f,0f],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:tentacule_racine"}},item_display:"none",view_range:3f,brightness:{sky:0,block:10},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,-1f,0f],scale:[0.052f,0.052f,0.052f]}}
summon minecraft:item_display ~ 101 ~ {Tags:["bs.e","bs.fx","bs.tentd","bs.tentd1"],Rotation:[0f,0f],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"boss:tentacule_racine_l"}},item_display:"none",view_range:3f,brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,-1f,0f],scale:[0.052f,0.052f,0.052f]}}
execute as @e[type=minecraft:item_display,tag=bs.tentd,tag=!bs.tok] at @s facing entity @e[tag=bs.hb.g,limit=1] feet run rotate @s ~ 0
tag @e[type=minecraft:item_display,tag=bs.tentd] add bs.tok
title @s actionbar {"text":"Le sol gonfle : bouge !","color":"dark_purple"}
playsound minecraft:entity.warden.emerge hostile @a[distance=..24] ~ ~ ~ 1.2 1.3
