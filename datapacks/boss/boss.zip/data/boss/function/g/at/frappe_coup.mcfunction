execute as @a[tag=bs.joue,distance=..2.6] run function boss:joueur/blesse {d:9,lim:15}
effect give @a[tag=bs.joue,distance=..2.6] minecraft:levitation 1 1 true
particle minecraft:explosion ~ ~0.5 ~ 1 0.3 1 0 4
particle minecraft:squid_ink ~ ~0.5 ~ 1.2 0.4 1.2 0.1 60
playsound minecraft:entity.warden.attack_impact hostile @a[distance=..32] ~ ~ ~ 2 0.8
execute as @e[type=minecraft:marker,tag=bs.pu.on,distance=..4] run function boss:g/pupitre/eteindre
summon minecraft:marker ~ ~ ~ {Tags:["bs.e","bs.fx","bs.encre"]}
