scoreboard players add @s bs.k 1
execute if score @s bs.k matches ..33 if score #m4 bs.ev matches 0 run particle minecraft:squid_ink ~ ~0.2 ~ 1 0.1 1 0.02 6
execute if score @s bs.k matches ..33 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.55,0.2,0.9],scale:1.3} ~2.40 ~0.15 ~0.00 0 0 0 0 1
execute if score @s bs.k matches ..33 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.55,0.2,0.9],scale:1.3} ~2.08 ~0.15 ~1.20 0 0 0 0 1
execute if score @s bs.k matches ..33 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.55,0.2,0.9],scale:1.3} ~1.20 ~0.15 ~2.08 0 0 0 0 1
execute if score @s bs.k matches ..33 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.55,0.2,0.9],scale:1.3} ~0.00 ~0.15 ~2.40 0 0 0 0 1
execute if score @s bs.k matches ..33 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.55,0.2,0.9],scale:1.3} ~-1.20 ~0.15 ~2.08 0 0 0 0 1
execute if score @s bs.k matches ..33 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.55,0.2,0.9],scale:1.3} ~-2.08 ~0.15 ~1.20 0 0 0 0 1
execute if score @s bs.k matches ..33 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.55,0.2,0.9],scale:1.3} ~-2.40 ~0.15 ~0.00 0 0 0 0 1
execute if score @s bs.k matches ..33 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.55,0.2,0.9],scale:1.3} ~-2.08 ~0.15 ~-1.20 0 0 0 0 1
execute if score @s bs.k matches ..33 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.55,0.2,0.9],scale:1.3} ~-1.20 ~0.15 ~-2.08 0 0 0 0 1
execute if score @s bs.k matches ..33 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.55,0.2,0.9],scale:1.3} ~-0.00 ~0.15 ~-2.40 0 0 0 0 1
execute if score @s bs.k matches ..33 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.55,0.2,0.9],scale:1.3} ~1.20 ~0.15 ~-2.08 0 0 0 0 1
execute if score @s bs.k matches ..33 if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.55,0.2,0.9],scale:1.3} ~2.08 ~0.15 ~-1.20 0 0 0 0 1
execute if score @s bs.k matches 34 run function boss:g/at/frappe_coup
execute if score @s bs.k matches 36.. run kill @s
