tag @s remove bs.neuf
scoreboard players set @s bs.k 0
execute store result storage boss:t x int 1 run random value -6..6
execute store result storage boss:t z int 1 run random value -6..6
execute store result storage boss:t r int 1 run random value 0..179
function boss:g/at/ligne_m with storage boss:t
