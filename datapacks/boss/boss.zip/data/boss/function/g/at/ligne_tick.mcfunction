scoreboard players add @s bs.k 1
execute if score @s bs.k matches ..39 if score #m4 bs.ev matches 0 run function boss:g/at/ligne_brille
execute if score @s bs.k matches 40 run function boss:g/at/ligne_coupe
execute if score @s bs.k matches 42.. run kill @s
