scoreboard players add @s bs.k 1
execute if score @s bs.k matches 2 run data merge entity @s {start_interpolation:0,interpolation_duration:12,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[5.2f,5.2f,5.2f]}}
execute if score @s bs.k matches 30 run data merge entity @s {start_interpolation:0,interpolation_duration:4,transformation:{left_rotation:[-0.6428f,0f,0f,0.766f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[5.2f,5.2f,5.2f]}}
execute if score @s bs.k matches 46 run data merge entity @s {start_interpolation:0,interpolation_duration:10,transformation:{left_rotation:[-0.6428f,0f,0f,0.766f],right_rotation:[0f,0f,0f,1f],translation:[0f,-1f,0f],scale:[0.052f,0.052f,0.052f]}}
execute if score @s bs.k matches 58.. run kill @s
