tag @s remove bs.rnew
scoreboard players remove #st bs.tmp 6
scoreboard players operation @s bs.k = #st bs.tmp
execute facing entity @r[tag=bs.joue] eyes run tp @s ~ ~ ~ ~ ~
