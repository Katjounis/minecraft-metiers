function boss:rig/grimoire/jouer/fouet
execute as @r[tag=bs.joue] at @s run function boss:g/at/tent_cible
execute if score #ph bs.g matches 2.. as @r[tag=bs.joue] at @s run function boss:g/at/tent_cible
execute if score #ph bs.g matches 3 as @r[tag=bs.joue] at @s run function boss:g/at/tent_cible
