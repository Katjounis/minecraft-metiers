execute as @a[tag=bs.joue] run function boss:joueur/blesse {d:4,lim:10}
execute as @a[tag=bs.joue] at @s run particle minecraft:enchant ~ ~1 ~ 0.4 0.8 0.4 1.5 30
effect give @s minecraft:regeneration 4 2 true
playsound minecraft:item.book.page_turn hostile @a[tag=bs.joue] ~ ~ ~ 3 0.4
title @a[tag=bs.joue] actionbar {"text":"Le Grimoire se nourrit de vos pages de vie !","color":"light_purple"}
