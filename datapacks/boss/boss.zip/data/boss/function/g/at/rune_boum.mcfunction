execute positioned ~ ~-1 ~ as @a[tag=bs.joue,distance=..1.6] run function boss:joueur/blesse {d:7,lim:13}
function boss:g/at/rune_eclat
