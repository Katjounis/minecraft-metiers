execute positioned ~ ~-1 ~ as @a[tag=bs.joue,distance=..1.6] run function boss:joueur/blesse {d:5,lim:11}
function boss:g/at/rune_eclat
