tag @a remove bs.marque
tag @r[tag=bs.joue] add bs.marque
execute as @a[tag=bs.marque] at @s run summon minecraft:marker ~ ~ ~ {Tags:["bs.e","bs.fx","bs.zone","bs.z.marque"]}
playsound minecraft:block.enchantment_table.use hostile @a[tag=bs.joue] ~ ~ ~ 2 0.5
title @a[tag=bs.marque] actionbar {"text":"Une rune d'encre te marque : éloigne-toi des autres !","color":"light_purple"}
title @a[tag=bs.joue,tag=!bs.marque] actionbar {"text":"Un joueur est marqué : écartez-vous de lui !","color":"light_purple"}
