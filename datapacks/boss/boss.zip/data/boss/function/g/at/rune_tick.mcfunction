scoreboard players add @s bs.k 1
execute if score @s bs.k matches ..0 run return run particle minecraft:witch ~ ~ ~ 0.2 0.2 0.2 0 1
tp @s ^ ^ ^0.45
particle minecraft:witch ~ ~ ~ 0.1 0.1 0.1 0 2
execute positioned ~ ~-1 ~ if entity @a[tag=bs.joue,distance=..1.4] run return run function boss:g/at/rune_boum
execute unless block ~ ~ ~ #boss:passable run return run function boss:g/at/rune_eclat
execute if score @s bs.k matches 70.. run kill @s
