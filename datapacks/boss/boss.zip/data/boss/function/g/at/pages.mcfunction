function boss:rig/grimoire/jouer/pages
playsound minecraft:item.book.page_turn hostile @a[distance=..48] ~ ~ ~ 3 0.5
title @a[tag=bs.joue] actionbar {"text":"Les pages brillent : bouge !","color":"light_purple"}
execute in boss:grimoire run summon minecraft:marker 0 101.2 0 {Tags:["bs.e","bs.fx","bs.ligne","bs.neuf"]}
execute in boss:grimoire run summon minecraft:marker 0 101.2 0 {Tags:["bs.e","bs.fx","bs.ligne","bs.neuf"]}
execute in boss:grimoire run summon minecraft:marker 0 101.2 0 {Tags:["bs.e","bs.fx","bs.ligne","bs.neuf"]}
execute in boss:grimoire run summon minecraft:marker 0 101.2 0 {Tags:["bs.e","bs.fx","bs.ligne","bs.neuf"]}
execute if score #ph bs.g matches 2.. in boss:grimoire run summon minecraft:marker 0 101.2 0 {Tags:["bs.e","bs.fx","bs.ligne","bs.neuf"]}
execute if score #ph bs.g matches 3 in boss:grimoire run summon minecraft:marker 0 101.2 0 {Tags:["bs.e","bs.fx","bs.ligne","bs.neuf"]}
execute as @e[type=minecraft:marker,tag=bs.neuf] run function boss:g/at/ligne_init
