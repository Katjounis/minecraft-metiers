particle minecraft:dust{color:[0.7,0.4,1.0],scale:2} ~ ~ ~ 0.3 0.3 0.3 0 15
playsound minecraft:block.amethyst_block.break hostile @a[distance=..16] ~ ~ ~ 1 0.8
kill @s
