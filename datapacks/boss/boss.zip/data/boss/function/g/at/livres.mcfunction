scoreboard players operation #nl bs.tmp = #n bs.ev
scoreboard players operation #nl bs.tmp /= #2 bs.tmp
scoreboard players add #nl bs.tmp 1
execute if score #nl bs.tmp matches 5.. run scoreboard players set #nl bs.tmp 4
execute in boss:grimoire run function boss:g/at/livre_un
title @a[tag=bs.joue] actionbar {"text":"Les bibliothèques s'ouvrent : des livres maudits s'envolent !","color":"dark_purple"}
