scoreboard players operation #nl bs.tmp = #n bs.ev
scoreboard players add #nl bs.tmp 1
execute if score #nl bs.tmp matches 7.. run scoreboard players set #nl bs.tmp 6
execute in boss:grimoire run function boss:g/at/livre_un
title @a[tag=bs.joue] actionbar {"text":"Livres maudits !","color":"dark_purple"}
