scoreboard players add @s bs.k 1
execute if score #m4 bs.ev matches 0 run particle minecraft:squid_ink ~ ~0.1 ~ 1.1 0 1.1 0 3
execute if score #m4 bs.ev matches 0 run particle minecraft:dust{color:[0.18,0.05,0.3],scale:2} ~ ~0.05 ~ 1.2 0 1.2 0 6
execute if score #tk bs.ev matches 0 run effect give @a[tag=bs.joue,distance=..2] minecraft:slowness 2 1 true
execute if score #tk bs.ev matches 0 run effect give @a[tag=bs.joue,distance=..2] minecraft:wither 2 0 true
execute if score @s bs.k matches 300.. run kill @s
