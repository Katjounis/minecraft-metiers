execute if score #pilier bs.g matches 0 positioned 11.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^1 0 0 0 0 1
execute if score #pilier bs.g matches 0 positioned 11.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^2 0 0 0 0 1
execute if score #pilier bs.g matches 0 positioned 11.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^3 0 0 0 0 1
execute if score #pilier bs.g matches 0 positioned 11.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^4 0 0 0 0 1
execute if score #pilier bs.g matches 0 positioned 11.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^5 0 0 0 0 1
execute if score #pilier bs.g matches 0 positioned 11.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^6 0 0 0 0 1
execute if score #pilier bs.g matches 0 positioned 11.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^7 0 0 0 0 1
execute if score #pilier bs.g matches 0 positioned 11.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^8 0 0 0 0 1
execute if score #pilier bs.g matches 0 positioned 11.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^9 0 0 0 0 1
execute if score #pilier bs.g matches 0 positioned 11.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^10 0 0 0 0 1
execute if score #pilier bs.g matches 0 positioned 11.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^11 0 0 0 0 1
execute if score #pilier bs.g matches 0 positioned 11.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^12 0 0 0 0 1
execute positioned 0.5 111 11.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^1 0 0 0 0 1
execute positioned 0.5 111 11.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^2 0 0 0 0 1
execute positioned 0.5 111 11.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^3 0 0 0 0 1
execute positioned 0.5 111 11.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^4 0 0 0 0 1
execute positioned 0.5 111 11.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^5 0 0 0 0 1
execute positioned 0.5 111 11.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^6 0 0 0 0 1
execute positioned 0.5 111 11.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^7 0 0 0 0 1
execute positioned 0.5 111 11.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^8 0 0 0 0 1
execute positioned 0.5 111 11.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^9 0 0 0 0 1
execute positioned 0.5 111 11.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^10 0 0 0 0 1
execute positioned 0.5 111 11.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^11 0 0 0 0 1
execute positioned 0.5 111 11.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^12 0 0 0 0 1
execute positioned -10.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^1 0 0 0 0 1
execute positioned -10.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^2 0 0 0 0 1
execute positioned -10.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^3 0 0 0 0 1
execute positioned -10.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^4 0 0 0 0 1
execute positioned -10.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^5 0 0 0 0 1
execute positioned -10.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^6 0 0 0 0 1
execute positioned -10.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^7 0 0 0 0 1
execute positioned -10.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^8 0 0 0 0 1
execute positioned -10.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^9 0 0 0 0 1
execute positioned -10.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^10 0 0 0 0 1
execute positioned -10.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^11 0 0 0 0 1
execute positioned -10.5 111 0.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^12 0 0 0 0 1
execute positioned 0.5 111 -10.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^1 0 0 0 0 1
execute positioned 0.5 111 -10.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^2 0 0 0 0 1
execute positioned 0.5 111 -10.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^3 0 0 0 0 1
execute positioned 0.5 111 -10.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^4 0 0 0 0 1
execute positioned 0.5 111 -10.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^5 0 0 0 0 1
execute positioned 0.5 111 -10.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^6 0 0 0 0 1
execute positioned 0.5 111 -10.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^7 0 0 0 0 1
execute positioned 0.5 111 -10.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^8 0 0 0 0 1
execute positioned 0.5 111 -10.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^9 0 0 0 0 1
execute positioned 0.5 111 -10.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^10 0 0 0 0 1
execute positioned 0.5 111 -10.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^11 0 0 0 0 1
execute positioned 0.5 111 -10.5 facing entity @s eyes run particle minecraft:dust{color:[0.5,0.5,0.56],scale:1.3} ^ ^ ^12 0 0 0 0 1
