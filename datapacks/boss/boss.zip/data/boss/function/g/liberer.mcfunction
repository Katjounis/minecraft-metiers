scoreboard players set #etat bs.g 2
scoreboard players set #t bs.g 0
execute as @e[type=minecraft:marker,tag=bs.pu.on] at @s run function boss:g/pupitre/eteindre
function boss:rig/grimoire/jouer/vol
title @a[tag=bs.joue] actionbar {"text":"Il se libère : rallumez les pupitres","color":"light_purple"}
playsound minecraft:entity.evoker.prepare_summon hostile @a[distance=..48] ~ ~ ~ 2 0.6
