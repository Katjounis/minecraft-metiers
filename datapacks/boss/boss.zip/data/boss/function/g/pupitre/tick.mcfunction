execute if entity @s[tag=bs.pu.on] run return run function boss:g/pupitre/rayon
execute unless entity @a[tag=bs.joue,distance=..2.8,predicate=boss:accroupi] run return run scoreboard players set @s bs.g 0
scoreboard players add @s bs.g 1
particle minecraft:enchant ~ ~1.6 ~ 0.3 0.3 0.3 1 25
playsound minecraft:block.enchantment_table.use block @a[distance=..10] ~ ~ ~ 0.7 1.2
execute if score @s bs.g matches 1 run title @a[tag=bs.joue,distance=..2.8] actionbar {"text":"Scellement ▮▯▯▯▯▯","color":"light_purple"}
execute if score @s bs.g matches 2 run title @a[tag=bs.joue,distance=..2.8] actionbar {"text":"Scellement ▮▮▯▯▯▯","color":"light_purple"}
execute if score @s bs.g matches 3 run title @a[tag=bs.joue,distance=..2.8] actionbar {"text":"Scellement ▮▮▮▯▯▯","color":"light_purple"}
execute if score @s bs.g matches 4 run title @a[tag=bs.joue,distance=..2.8] actionbar {"text":"Scellement ▮▮▮▮▯▯","color":"light_purple"}
execute if score @s bs.g matches 5 run title @a[tag=bs.joue,distance=..2.8] actionbar {"text":"Scellement ▮▮▮▮▮▯","color":"light_purple"}
execute if score @s bs.g matches 6.. run function boss:g/pupitre/allumer
