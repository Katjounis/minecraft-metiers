tag @s add bs.pu.on
scoreboard players set @s bs.g 0
execute if score @s bs.k matches 1 run function boss:arene/g/ligne_on_1
execute if score @s bs.k matches 2 run function boss:arene/g/ligne_on_2
execute if score @s bs.k matches 3 run function boss:arene/g/ligne_on_3
execute if score @s bs.k matches 4 run function boss:arene/g/ligne_on_4
playsound minecraft:block.beacon.activate block @a[distance=0..] ~ ~ ~ 2 1.4
particle minecraft:end_rod ~ ~1.5 ~ 0.4 0.6 0.4 0.05 30
title @a[tag=bs.joue,distance=..3] actionbar {"text":"Pupitre activé !","color":"aqua"}
