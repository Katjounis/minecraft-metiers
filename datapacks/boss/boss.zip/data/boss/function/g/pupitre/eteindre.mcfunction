tag @s remove bs.pu.on
scoreboard players set @s bs.g 0
execute if score @s bs.k matches 1 run function boss:arene/g/ligne_off_1
execute if score @s bs.k matches 2 run function boss:arene/g/ligne_off_2
execute if score @s bs.k matches 3 run function boss:arene/g/ligne_off_3
execute if score @s bs.k matches 4 run function boss:arene/g/ligne_off_4
playsound minecraft:block.beacon.deactivate block @a[distance=0..] ~ ~ ~ 2 1
