scoreboard players add @s bs.g 1
execute if score @s bs.g matches 30.. run return run function boss:g/pupitre/eteindre
execute positioned ~ ~1.3 ~ facing entity @e[tag=bs.hb.g,limit=1] eyes run particle minecraft:end_rod ^ ^ ^1 0 0 0 0 1
execute positioned ~ ~1.3 ~ facing entity @e[tag=bs.hb.g,limit=1] eyes run particle minecraft:end_rod ^ ^ ^2 0 0 0 0 1
execute positioned ~ ~1.3 ~ facing entity @e[tag=bs.hb.g,limit=1] eyes run particle minecraft:end_rod ^ ^ ^3 0 0 0 0 1
execute positioned ~ ~1.3 ~ facing entity @e[tag=bs.hb.g,limit=1] eyes run particle minecraft:end_rod ^ ^ ^4 0 0 0 0 1
execute positioned ~ ~1.3 ~ facing entity @e[tag=bs.hb.g,limit=1] eyes run particle minecraft:end_rod ^ ^ ^5 0 0 0 0 1
execute positioned ~ ~1.3 ~ facing entity @e[tag=bs.hb.g,limit=1] eyes run particle minecraft:end_rod ^ ^ ^6 0 0 0 0 1
execute positioned ~ ~1.3 ~ facing entity @e[tag=bs.hb.g,limit=1] eyes run particle minecraft:end_rod ^ ^ ^7 0 0 0 0 1
execute positioned ~ ~1.3 ~ facing entity @e[tag=bs.hb.g,limit=1] eyes run particle minecraft:end_rod ^ ^ ^8 0 0 0 0 1
execute positioned ~ ~1.3 ~ facing entity @e[tag=bs.hb.g,limit=1] eyes run particle minecraft:end_rod ^ ^ ^9 0 0 0 0 1
execute positioned ~ ~1.3 ~ facing entity @e[tag=bs.hb.g,limit=1] eyes run particle minecraft:end_rod ^ ^ ^10 0 0 0 0 1
execute positioned ~ ~1.3 ~ facing entity @e[tag=bs.hb.g,limit=1] eyes run particle minecraft:end_rod ^ ^ ^11 0 0 0 0 1
execute positioned ~ ~1.3 ~ facing entity @e[tag=bs.hb.g,limit=1] eyes run particle minecraft:end_rod ^ ^ ^12 0 0 0 0 1
execute positioned ~ ~1.3 ~ facing entity @e[tag=bs.hb.g,limit=1] eyes run particle minecraft:end_rod ^ ^ ^13 0 0 0 0 1
execute positioned ~ ~1.3 ~ facing entity @e[tag=bs.hb.g,limit=1] eyes run particle minecraft:end_rod ^ ^ ^14 0 0 0 0 1
