execute if entity @s[y=101.6,dy=40] run tp @s ~ ~-0.3 ~
execute if score #m4 bs.ev matches 0 run function boss:g/chaines
execute if score #t bs.g matches 140.. run function boss:g/liberer
