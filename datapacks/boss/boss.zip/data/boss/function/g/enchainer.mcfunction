scoreboard players set #etat bs.g 1
scoreboard players set #t bs.g 0
function boss:rig/grimoire/jouer/enchaine
title @a[tag=bs.joue] times 8 60 16
title @a[tag=bs.joue] subtitle {"text":"Frappez-le !","color":"white"}
title @a[tag=bs.joue] title {"text":"ENCHAÎNÉ","color":"aqua","bold":true}
execute as @a[tag=bs.joue] at @s run playsound minecraft:block.chain.break master @s ~ ~ ~ 1 0.5
execute as @a[tag=bs.joue] at @s run playsound minecraft:entity.iron_golem.damage master @s ~ ~ ~ 1 0.5
