scoreboard players set #c bs.tmp 250
scoreboard players operation #pvmax bs.ev = #n bs.ev
scoreboard players operation #pvmax bs.ev *= #c bs.tmp
scoreboard players add #pvmax bs.ev 500
scoreboard players operation #pvmax bs.ev *= #mul bs.ev
scoreboard players operation #pvmax bs.ev /= #100 bs.tmp
scoreboard players set #res bs.ev 0
execute if score #pvmax bs.ev matches 1100.. run scoreboard players set #res bs.ev 1
execute if score #pvmax bs.ev matches 1500.. run scoreboard players set #res bs.ev 2
execute if score #pvmax bs.ev matches 2400.. run scoreboard players set #res bs.ev 3
execute if score #pvmax bs.ev matches 1001.. run scoreboard players set #pvmax bs.ev 1000
execute store result storage boss:t hp int 1 run scoreboard players get #pvmax bs.ev
execute in boss:grimoire positioned 0 106 0 run function boss:g/invoquer with storage boss:t
execute if score #res bs.ev matches 1 run effect give @e[tag=bs.hb.g,limit=1] minecraft:resistance infinite 0 true
execute if score #res bs.ev matches 2 run effect give @e[tag=bs.hb.g,limit=1] minecraft:resistance infinite 1 true
execute if score #res bs.ev matches 3 run effect give @e[tag=bs.hb.g,limit=1] minecraft:resistance infinite 2 true
execute as @e[tag=bs.hb.g,limit=1] run function boss:rang_boss
execute at @e[tag=bs.hb.g,limit=1] run function boss:rig/grimoire/invoquer
function boss:rig/grimoire/jouer/apparition
bossbar set boss:combat name {"text":"Le Grimoire Vivant","color":"light_purple","bold":true}
bossbar set boss:combat color purple
scoreboard players set #etat bs.g 0
scoreboard players set #t bs.g 0
scoreboard players set #atk bs.g 100
scoreboard players set #ph bs.g 1
scoreboard players set #pilier bs.g 0
scoreboard players set #bordon bs.g 0
scoreboard players operation #need bs.g = #n bs.ev
execute if score #need bs.g matches ..1 run scoreboard players set #need bs.g 2
execute if score #need bs.g matches 5.. run scoreboard players set #need bs.g 4
title @a[tag=bs.joue] times 8 60 16
title @a[tag=bs.joue] subtitle {"text":"Enchaîne-le aux pupitres !","color":"white"}
title @a[tag=bs.joue] title {"text":"LE GRIMOIRE","color":"light_purple","bold":true}
execute as @a[tag=bs.joue] at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.7 1.4
tellraw @a[tag=bs.joue] [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Accroupis-toi 4 s aux pupitres. ","color":"white","bold":false},{"score":{"name":"#need","objective":"bs.g"},"color":"yellow"},{"text":" allumés = il tombe : frappe !","color":"white","bold":false}]
tellraw @a[tag=bs.joue] [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Arc quand il flotte. Bouge quand ça brille.","color":"gray","bold":false}]
