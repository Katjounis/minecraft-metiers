execute as @e[type=minecraft:marker,tag=bs.pivot,limit=1] at @s run tp @s ~ ~ ~ ~1.5 ~
execute at @e[type=minecraft:marker,tag=bs.pivot,limit=1] rotated ~ 0 positioned ^ ^ ^3.5 run tp @s ~ ~ ~
execute if score #t bs.g matches ..60 run return 0
scoreboard players remove #atk bs.g 1
execute if score #atk bs.g matches ..0 run function boss:g/attaque
