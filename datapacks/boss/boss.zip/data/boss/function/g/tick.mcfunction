function boss:rig/grimoire/tick
execute as @e[tag=bs.hb.g,limit=1] at @s run function boss:g/ia
function boss:g/effets
execute if score #bordon bs.g matches 1 run function boss:g/bord
