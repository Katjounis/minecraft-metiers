$scoreboard players set #min bs.ev $(min)
$scoreboard players set #max bs.ev $(max)
function boss:ev/prochain
tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Nouvel intervalle enregistré, minuteur relancé.","color":"gray","bold":false}]
