execute unless score #etat bs.ev matches 0 run return run tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Un événement de boss est déjà en cours.","color":"gray","bold":false}]
scoreboard players set #t bs.ev 1
tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Un boss au hasard se réveille dans une seconde.","color":"gray","bold":false}]
