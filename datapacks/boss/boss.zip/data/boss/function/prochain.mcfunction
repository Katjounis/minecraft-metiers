scoreboard players operation #mn bs.tmp = #t bs.ev
scoreboard players operation #mn bs.tmp /= #60 bs.tmp
tellraw @s [{"text":"[Boss] ","color":"dark_red","bold":true},{"text":"Prochain boss dans ","color":"gray","bold":false},{"score":{"name":"#mn","objective":"bs.tmp"},"color":"yellow"},{"text":" min de jeu (avec au moins un joueur connecté).","color":"gray","bold":false}]
