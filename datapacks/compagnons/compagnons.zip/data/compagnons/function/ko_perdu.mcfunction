scoreboard players set @s cp.cd 60
scoreboard players set @s cp.hp 99999
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton compagnon est K.O. Il revient dans 60 secondes.","color":"red"}]
