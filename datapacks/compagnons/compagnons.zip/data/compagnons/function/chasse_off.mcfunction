scoreboard players set @s cp.ag 0
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Mode chasse coupé : ton loup te défend seulement.","color":"gray"}]
