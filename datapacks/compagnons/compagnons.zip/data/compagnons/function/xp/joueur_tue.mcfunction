scoreboard players operation #y cp.t = @s cp.out
scoreboard players operation #g cp.t = @s cp.mk
function compagnons:xp/gagner
