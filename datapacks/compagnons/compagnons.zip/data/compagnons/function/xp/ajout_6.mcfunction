execute if score @s cp.l6 matches 30.. run return 0
scoreboard players operation @s cp.x6 += #g cp.t
function compagnons:xp/monter_6
