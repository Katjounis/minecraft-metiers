execute if score @s cp.l9 matches 30.. run return 0
scoreboard players operation @s cp.x9 += #g cp.t
function compagnons:xp/monter_9
