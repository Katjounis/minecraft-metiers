execute if score @s cp.l5 matches 30.. run return 0
scoreboard players operation @s cp.x5 += #g cp.t
function compagnons:xp/monter_5
