execute if score @s cp.l8 matches 30.. run return 0
scoreboard players operation @s cp.x8 += #g cp.t
function compagnons:xp/monter_8
