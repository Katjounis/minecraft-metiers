execute if score @s cp.l7 matches 30.. run return 0
scoreboard players operation @s cp.x7 += #g cp.t
function compagnons:xp/monter_7
