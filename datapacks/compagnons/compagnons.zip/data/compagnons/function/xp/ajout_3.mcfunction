execute if score @s cp.l3 matches 30.. run return 0
scoreboard players operation @s cp.x3 += #g cp.t
function compagnons:xp/monter_3
