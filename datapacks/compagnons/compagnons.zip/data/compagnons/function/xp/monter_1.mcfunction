scoreboard players operation #n cp.t = @s cp.l1
scoreboard players operation #n cp.t *= #6 cp.t
scoreboard players operation #n cp.t += #20 cp.t
execute if score @s cp.x1 < #n cp.t run return 0
scoreboard players operation @s cp.x1 -= #n cp.t
scoreboard players add @s cp.l1 1
execute if score @s cp.l1 matches 30.. run scoreboard players set @s cp.x1 0
execute store result storage compagnons:t lv int 1 run scoreboard players get @s cp.l1
function compagnons:xp/annonce_1 with storage compagnons:t
playsound minecraft:entity.player.levelup neutral @s ~ ~ ~ 0.8 1.4
execute if score @s cp.out matches 1 run function compagnons:invoquer/maj
function compagnons:xp/monter_1
