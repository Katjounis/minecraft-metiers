scoreboard players operation #o cp.t = @s cp.own
scoreboard players operation #y cp.t = @s cp.typ
scoreboard players set #g cp.t 5
execute as @a if score @s cp.id = #o cp.t run function compagnons:xp/gagner
