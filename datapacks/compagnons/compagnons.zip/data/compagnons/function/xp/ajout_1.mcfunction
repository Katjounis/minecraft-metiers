execute if score @s cp.l1 matches 30.. run return 0
scoreboard players operation @s cp.x1 += #g cp.t
function compagnons:xp/monter_1
