execute if score @s cp.l4 matches 30.. run return 0
scoreboard players operation @s cp.x4 += #g cp.t
function compagnons:xp/monter_4
