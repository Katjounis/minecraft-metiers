scoreboard players set #e cp.t 0
execute if score @s m.e_lvl matches 1.. run scoreboard players operation #e cp.t = @s m.e_lvl
execute if score @s m.e_pr matches 1.. run scoreboard players set #e cp.t 100
scoreboard players operation #e cp.t *= #g cp.t
scoreboard players operation #e cp.t /= #100 cp.t
scoreboard players operation #g cp.t += #e cp.t
execute if score #y cp.t matches 1 run function compagnons:xp/ajout_1
execute if score #y cp.t matches 2 run function compagnons:xp/ajout_2
execute if score #y cp.t matches 3 run function compagnons:xp/ajout_3
execute if score #y cp.t matches 4 run function compagnons:xp/ajout_4
execute if score #y cp.t matches 5 run function compagnons:xp/ajout_5
execute if score #y cp.t matches 6 run function compagnons:xp/ajout_6
