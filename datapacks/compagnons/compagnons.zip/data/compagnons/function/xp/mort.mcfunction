tag @s add cp.mort
execute on attacker if entity @s[tag=cp.c] run function compagnons:xp/credit
