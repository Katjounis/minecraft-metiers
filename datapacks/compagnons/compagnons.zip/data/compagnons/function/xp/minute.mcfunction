scoreboard players set @s cp.min 0
scoreboard players operation #y cp.t = @s cp.out
scoreboard players set #g cp.t 2
function compagnons:xp/gagner
