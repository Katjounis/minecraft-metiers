execute if score @s cp.l2 matches 30.. run return 0
scoreboard players operation @s cp.x2 += #g cp.t
function compagnons:xp/monter_2
