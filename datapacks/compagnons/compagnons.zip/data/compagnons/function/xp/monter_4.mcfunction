scoreboard players operation #n cp.t = @s cp.l4
scoreboard players operation #n cp.t *= #6 cp.t
scoreboard players operation #n cp.t += #20 cp.t
execute if score @s cp.x4 < #n cp.t run return 0
scoreboard players operation @s cp.x4 -= #n cp.t
scoreboard players add @s cp.l4 1
execute if score @s cp.l4 matches 30.. run scoreboard players set @s cp.x4 0
execute store result storage compagnons:t lv int 1 run scoreboard players get @s cp.l4
function compagnons:xp/annonce_4 with storage compagnons:t
playsound minecraft:entity.player.levelup neutral @s ~ ~ ~ 0.8 1.4
execute if score @s cp.out matches 4 run function compagnons:invoquer/maj
function compagnons:xp/monter_4
