scoreboard players operation #n cp.t = @s cp.l6
scoreboard players operation #n cp.t *= #6 cp.t
scoreboard players operation #n cp.t += #20 cp.t
execute if score @s cp.x6 < #n cp.t run return 0
scoreboard players operation @s cp.x6 -= #n cp.t
scoreboard players add @s cp.l6 1
execute if score @s cp.l6 matches 30.. run scoreboard players set @s cp.x6 0
execute store result storage compagnons:t lv int 1 run scoreboard players get @s cp.l6
function compagnons:xp/annonce_6 with storage compagnons:t
playsound minecraft:entity.player.levelup neutral @s ~ ~ ~ 0.8 1.4
execute if score @s cp.out matches 6 run function compagnons:invoquer/maj
function compagnons:xp/monter_6
