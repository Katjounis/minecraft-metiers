$data modify storage compagnons:noms J[{id:$(id)}].n$(k) set value $(n)
