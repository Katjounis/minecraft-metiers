execute unless data entity @s SelectedItem.components."minecraft:custom_name" run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Tiens en main un objet renommé à l’enclume (une étiquette, un papier...), puis clique sur Renommer.","color":"red"}]
execute store result storage compagnons:t id int 1 run scoreboard players get @s cp.id
data modify storage compagnons:t k set value 3
function compagnons:noms/creer with storage compagnons:t
data modify storage compagnons:t n set from entity @s SelectedItem.components."minecraft:custom_name"
function compagnons:renommer/poser with storage compagnons:t
execute if score @s cp.out matches 3 run function compagnons:invoquer/maj
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton Perroquet a un nouveau nom.","color":"green"}]
function compagnons:menu/page_3
