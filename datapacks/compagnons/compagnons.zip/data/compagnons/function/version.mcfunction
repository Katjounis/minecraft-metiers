tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Version 4.2 : suivi au pas entre 3 et 5 blocs, et le compagnon attaque ce que tu frappes.","color":"gold"}]
