tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Version 4.5 : aide en grille de sujets, clic droit pour monter, suivi au pas.","color":"gold"}]
