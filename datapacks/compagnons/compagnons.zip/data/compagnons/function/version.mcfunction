tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Version 4 : tous les compagnons te suivent pour de vrai, derrière toi et sans collision.","color":"gold"}]
