tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Version 4.1 : tous les compagnons te suivent au pas, entre 3 et 5 blocs, sans collision.","color":"gold"}]
