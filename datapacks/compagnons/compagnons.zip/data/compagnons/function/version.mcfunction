tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Version 4.3 : suivi au pas entre 3 et 5 blocs, rattrapage s’il est coincé, et le compagnon attaque ce que tu frappes.","color":"gold"}]
