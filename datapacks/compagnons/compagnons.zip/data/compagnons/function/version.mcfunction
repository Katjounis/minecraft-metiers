tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Version 4.4 : clic droit sur le dragon ou le wither pour monter, suivi au pas, rattrapage, attaque ce que tu frappes.","color":"gold"}]
