function compagnons:ranger_silence
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le dragon refuse d’entrer dans l’End. Il t’attend dehors.","color":"light_purple"}]
