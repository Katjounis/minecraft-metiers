function compagnons:amel/6_r
function compagnons:menu/amel_6
