function compagnons:amel/4_f
function compagnons:menu/amel_4
