function compagnons:amel/2_r
function compagnons:menu/amel_2
