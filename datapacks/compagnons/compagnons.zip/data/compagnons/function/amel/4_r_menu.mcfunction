function compagnons:amel/4_r
function compagnons:menu/amel_4
