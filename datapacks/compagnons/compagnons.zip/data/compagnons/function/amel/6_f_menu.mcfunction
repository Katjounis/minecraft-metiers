function compagnons:amel/6_f
function compagnons:menu/amel_6
