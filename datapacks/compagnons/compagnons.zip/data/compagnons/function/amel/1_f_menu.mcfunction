function compagnons:amel/1_f
function compagnons:menu/amel_1
