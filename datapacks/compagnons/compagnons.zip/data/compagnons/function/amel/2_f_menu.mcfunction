function compagnons:amel/2_f
function compagnons:menu/amel_2
