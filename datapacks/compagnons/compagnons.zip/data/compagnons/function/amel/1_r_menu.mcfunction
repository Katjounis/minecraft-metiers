function compagnons:amel/1_r
function compagnons:menu/amel_1
