function compagnons:amel/8_f
function compagnons:menu/amel_8
