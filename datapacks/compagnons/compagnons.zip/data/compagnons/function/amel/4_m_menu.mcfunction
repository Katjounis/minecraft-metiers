function compagnons:amel/4_m
function compagnons:menu/amel_4
