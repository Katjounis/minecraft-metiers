function compagnons:amel/3_r
function compagnons:menu/amel_3
