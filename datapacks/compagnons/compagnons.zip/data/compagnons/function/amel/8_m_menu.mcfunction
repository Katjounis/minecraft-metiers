function compagnons:amel/8_m
function compagnons:menu/amel_8
