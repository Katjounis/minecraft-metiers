function compagnons:amel/3_f
function compagnons:menu/amel_3
