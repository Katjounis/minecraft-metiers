function compagnons:amel/3_m
function compagnons:menu/amel_3
