function compagnons:amel/7_f
function compagnons:menu/amel_7
