function compagnons:amel/8_r
function compagnons:menu/amel_8
