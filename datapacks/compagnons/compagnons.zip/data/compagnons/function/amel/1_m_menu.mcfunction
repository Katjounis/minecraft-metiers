function compagnons:amel/1_m
function compagnons:menu/amel_1
