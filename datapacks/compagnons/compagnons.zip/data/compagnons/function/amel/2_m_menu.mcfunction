function compagnons:amel/2_m
function compagnons:menu/amel_2
