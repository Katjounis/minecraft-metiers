function compagnons:amel/9_m
function compagnons:menu/amel_9
