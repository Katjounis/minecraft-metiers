function compagnons:amel/5_f
function compagnons:menu/amel_5
