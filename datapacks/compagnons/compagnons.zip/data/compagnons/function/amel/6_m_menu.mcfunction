function compagnons:amel/6_m
function compagnons:menu/amel_6
