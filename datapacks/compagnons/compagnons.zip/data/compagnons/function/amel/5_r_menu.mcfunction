function compagnons:amel/5_r
function compagnons:menu/amel_5
