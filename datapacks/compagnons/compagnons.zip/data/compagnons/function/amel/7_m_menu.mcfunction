function compagnons:amel/7_m
function compagnons:menu/amel_7
