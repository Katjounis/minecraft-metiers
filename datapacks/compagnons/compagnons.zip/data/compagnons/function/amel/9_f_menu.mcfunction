function compagnons:amel/9_f
function compagnons:menu/amel_9
