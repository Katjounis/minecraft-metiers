function compagnons:amel/5_m
function compagnons:menu/amel_5
