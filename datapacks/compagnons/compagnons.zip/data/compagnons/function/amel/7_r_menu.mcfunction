function compagnons:amel/7_r
function compagnons:menu/amel_7
