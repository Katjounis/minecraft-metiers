execute if score @s cp.m1 matches 5.. run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Maîtrise est déjà au maximum.","color":"red"}]
scoreboard players operation #pt cp.t = @s cp.l1
execute if score @s cp.r1 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.r1 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.r1 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.r1 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.r1 matches 5 run scoreboard players remove #pt cp.t 15
execute if score @s cp.f1 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.f1 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.f1 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.f1 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.f1 matches 5 run scoreboard players remove #pt cp.t 15
execute if score @s cp.m1 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.m1 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.m1 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.m1 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.m1 matches 5 run scoreboard players remove #pt cp.t 15
scoreboard players operation #c cp.t = @s cp.m1
scoreboard players add #c cp.t 1
execute if score #pt cp.t < #c cp.t run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Pas assez de points de dressage : fais monter ton compagnon de niveau.","color":"red"}]
scoreboard players operation #e cp.t = #c cp.t
scoreboard players set #1500 cp.t 4000
scoreboard players operation #e cp.t *= #1500 cp.t
scoreboard players set #ok cp.t 0
execute if score @s c.ecus >= #e cp.t run scoreboard players set #ok cp.t 1
execute if score #ok cp.t matches 0 run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Pas assez d’Écus sur ton compte.","color":"red"}]
scoreboard players operation @s c.ecus -= #e cp.t
scoreboard players operation @s c.a_cmp -= #e cp.t
scoreboard players add @s cp.m1 1
execute if score @s cp.out matches 1 run function compagnons:invoquer/maj
playsound minecraft:block.enchantment_table.use neutral @s ~ ~ ~ 1 1.2
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Maîtrise de ton Loup : un rang de plus !","color":"light_purple"}]
