scoreboard objectives add cp.id dummy
scoreboard objectives add cp.ser dummy
scoreboard objectives add cp.out dummy
scoreboard objectives add cp.cd dummy
scoreboard objectives add cp.cda dummy
scoreboard objectives add cp.mode dummy
scoreboard objectives add cp.ag dummy
scoreboard objectives add cp.own dummy
scoreboard objectives add cp.typ dummy
scoreboard objectives add cp.hp dummy
scoreboard objectives add cp.hpm dummy
scoreboard objectives add cp.min dummy
scoreboard objectives add cp.vie dummy
scoreboard objectives add cp.t dummy
scoreboard objectives add cp.tk dummy
scoreboard objectives add cp.ok dummy
scoreboard objectives add cp.l1 dummy
scoreboard objectives add cp.x1 dummy
scoreboard objectives add cp.v1 dummy
scoreboard objectives add cp.l2 dummy
scoreboard objectives add cp.x2 dummy
scoreboard objectives add cp.v2 dummy
scoreboard objectives add cp.l3 dummy
scoreboard objectives add cp.x3 dummy
scoreboard objectives add cp.v3 dummy
scoreboard objectives add cp.l4 dummy
scoreboard objectives add cp.x4 dummy
scoreboard objectives add cp.v4 dummy
scoreboard objectives add cp.l5 dummy
scoreboard objectives add cp.x5 dummy
scoreboard objectives add cp.v5 dummy
scoreboard objectives add cp.l6 dummy
scoreboard objectives add cp.x6 dummy
scoreboard objectives add cp.v6 dummy
scoreboard objectives add cp.vie_j dummy
scoreboard objectives add compagnons trigger
scoreboard objectives add cp.mk minecraft.custom:minecraft.mob_kills
scoreboard players add #next cp.t 0
scoreboard players set #6 cp.t 6
scoreboard players set #10 cp.t 10
scoreboard players set #20 cp.t 20
scoreboard players set #2 cp.t 2
scoreboard players set #5 cp.t 5
scoreboard players set #100 cp.t 100
execute unless data storage compagnons:noms J run data modify storage compagnons:noms J set value []
schedule function compagnons:seconde 1s replace
