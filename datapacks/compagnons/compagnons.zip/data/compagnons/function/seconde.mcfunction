schedule function compagnons:seconde 1s replace
scoreboard players add #s cp.tk 1
execute as @a at @s run function compagnons:joueur
execute as @e[tag=cp.c] run function compagnons:c/valide
execute as @e[tag=cp.renfort] run function compagnons:c/renfort
