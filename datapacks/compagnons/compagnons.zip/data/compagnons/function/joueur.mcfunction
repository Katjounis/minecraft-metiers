execute store result score @s cp.vie_j run data get entity @s Health
execute unless score @s cp.id matches 1.. run function compagnons:id
scoreboard players enable @s compagnons
scoreboard players add @s cp.out 0
scoreboard players add @s cp.mode 0
scoreboard players add @s cp.ag 0
scoreboard players add @s cp.min 0
execute unless score @s cp.l1 matches 1.. run scoreboard players set @s cp.l1 1
execute unless score @s cp.l2 matches 1.. run scoreboard players set @s cp.l2 1
execute unless score @s cp.l3 matches 1.. run scoreboard players set @s cp.l3 1
execute unless score @s cp.l4 matches 1.. run scoreboard players set @s cp.l4 1
execute unless score @s cp.l5 matches 1.. run scoreboard players set @s cp.l5 1
execute unless score @s cp.l6 matches 1.. run scoreboard players set @s cp.l6 1
execute unless score @s cp.l7 matches 1.. run scoreboard players set @s cp.l7 1
execute unless score @s cp.l8 matches 1.. run scoreboard players set @s cp.l8 1
execute unless score @s cp.l9 matches 1.. run scoreboard players set @s cp.l9 1
execute if score @s cp.cd matches 1.. run scoreboard players remove @s cp.cd 1
execute if score @s cp.cda matches 1.. run scoreboard players remove @s cp.cda 1
execute if score @s cp.out matches 1.. if score @s cp.mk matches 1.. run function compagnons:xp/joueur_tue
scoreboard players set @s cp.mk 0
execute if score @s cp.out matches 1.. run scoreboard players add @s cp.min 1
execute if score @s cp.min matches 60.. run function compagnons:xp/minute
execute if score @s cp.out matches 1.. if score @s cp.cd matches ..0 run function compagnons:suivi
