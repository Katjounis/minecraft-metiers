scoreboard players set @s cp.mode 0
function compagnons:marquer
execute as @e[tag=cp.cur] run data modify entity @s Sitting set value 0b
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton compagnon te suit.","color":"green"}]
