function compagnons:marquer
execute at @e[tag=cp.cur] run particle minecraft:poof ~ ~0.5 ~ 0.3 0.4 0.3 0.02 10
tp @e[tag=cp.cur] ~ -1000 ~
kill @e[tag=cp.cur]
scoreboard players set @s cp.out 0
scoreboard players add @s cp.ser 1
