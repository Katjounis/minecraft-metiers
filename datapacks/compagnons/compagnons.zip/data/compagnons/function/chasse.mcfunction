execute if score @s cp.ag matches 1 run return run function compagnons:chasse_off
scoreboard players set @s cp.ag 1
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Mode chasse : ton loup va chercher les monstres autour de toi (jamais les creepers).","color":"gold"}]
