function compagnons:ranger_silence
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton compagnon est rentré.","color":"gray"}]
playsound minecraft:entity.item.pickup neutral @s ~ ~ ~ 0.6 0.8
