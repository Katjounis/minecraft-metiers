execute if score @s cp.mode matches 1 run return run function compagnons:mode_suivre
scoreboard players set @s cp.mode 1
function compagnons:marquer
execute as @e[tag=cp.cur] run data modify entity @s Sitting set value 1b
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton compagnon reste ici (il défend la zone). Le même bouton le fait revenir.","color":"yellow"}]
