function compagnons:invoquer/8
function compagnons:menu/page_8
