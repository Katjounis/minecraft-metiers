tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"L’Allay se débloque au niveau 25 d’Enchanteur. Le prestige du métier compte aussi.","color":"red"}]
function compagnons:menu/accueil
