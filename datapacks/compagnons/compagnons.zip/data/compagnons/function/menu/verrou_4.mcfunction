tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Bonhomme de neige se débloque au niveau 20 de Pêcheur. Le prestige du métier compte aussi.","color":"red"}]
function compagnons:menu/accueil
