execute unless score @s cp.id matches 1.. run function compagnons:id
data modify storage compagnons:m dehors set value "aucun"
data modify storage compagnons:m md set value "Il te suit"
execute if score @s cp.mode matches 1 run data modify storage compagnons:m md set value "Il garde la zone"
scoreboard players set #deb cp.t 0
execute if score @s m.c_lvl matches 10.. run scoreboard players set #deb cp.t 1
execute if score @s m.c_pr matches 1.. run scoreboard players set #deb cp.t 1
execute store result storage compagnons:m l1 int 1 run scoreboard players get @s cp.l1
data modify storage compagnons:m b1 set value {text:"  Loup niv. ",color:"#C8C8C8"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b1 set value {text:"  ✖ Loup",color:"dark_gray"}
execute if score @s cp.out matches 1 run data modify storage compagnons:m dehors set value "Loup"
data modify storage compagnons:m s1 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s1 int 1 run scoreboard players get @s cp.l1
scoreboard players set #deb cp.t 0
execute if score @s m.f_lvl matches 10.. run scoreboard players set #deb cp.t 1
execute if score @s m.f_pr matches 1.. run scoreboard players set #deb cp.t 1
execute store result storage compagnons:m l2 int 1 run scoreboard players get @s cp.l2
data modify storage compagnons:m b2 set value {text:"  Chat niv. ",color:"#E0A040"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b2 set value {text:"  ✖ Chat",color:"dark_gray"}
execute if score @s cp.out matches 2 run data modify storage compagnons:m dehors set value "Chat"
data modify storage compagnons:m s2 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s2 int 1 run scoreboard players get @s cp.l2
scoreboard players set #deb cp.t 0
execute if score @s m.x_lvl matches 15.. run scoreboard players set #deb cp.t 1
execute if score @s m.x_pr matches 1.. run scoreboard players set #deb cp.t 1
execute store result storage compagnons:m l3 int 1 run scoreboard players get @s cp.l3
data modify storage compagnons:m b3 set value {text:"  Perroquet niv. ",color:"#40C860"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b3 set value {text:"  ✖ Perroquet",color:"dark_gray"}
execute if score @s cp.out matches 3 run data modify storage compagnons:m dehors set value "Perroquet"
data modify storage compagnons:m s3 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s3 int 1 run scoreboard players get @s cp.l3
scoreboard players set #deb cp.t 0
execute if score @s m.p_lvl matches 20.. run scoreboard players set #deb cp.t 1
execute if score @s m.p_pr matches 1.. run scoreboard players set #deb cp.t 1
execute store result storage compagnons:m l4 int 1 run scoreboard players get @s cp.l4
data modify storage compagnons:m b4 set value {text:"  Bonhomme niv. ",color:"#D8F0FF"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b4 set value {text:"  ✖ Bonhomme",color:"dark_gray"}
execute if score @s cp.out matches 4 run data modify storage compagnons:m dehors set value "Bonhomme de neige"
data modify storage compagnons:m s4 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s4 int 1 run scoreboard players get @s cp.l4
scoreboard players set #deb cp.t 0
execute if score @s m.n_lvl matches 25.. run scoreboard players set #deb cp.t 1
execute if score @s m.n_pr matches 1.. run scoreboard players set #deb cp.t 1
execute store result storage compagnons:m l5 int 1 run scoreboard players get @s cp.l5
data modify storage compagnons:m b5 set value {text:"  Allay niv. ",color:"#60C8FF"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b5 set value {text:"  ✖ Allay",color:"dark_gray"}
execute if score @s cp.out matches 5 run data modify storage compagnons:m dehors set value "Allay"
data modify storage compagnons:m s5 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s5 int 1 run scoreboard players get @s cp.l5
scoreboard players set #deb cp.t 0
execute if score @s m.m_lvl matches 30.. run scoreboard players set #deb cp.t 1
execute if score @s m.m_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score @s m.k_lvl matches 30.. run scoreboard players set #deb cp.t 1
execute store result storage compagnons:m l6 int 1 run scoreboard players get @s cp.l6
data modify storage compagnons:m b6 set value {text:"  Golem niv. ",color:"#D8CFC0"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b6 set value {text:"  ✖ Golem",color:"dark_gray"}
execute if score @s cp.out matches 6 run data modify storage compagnons:m dehors set value "Golem de fer"
data modify storage compagnons:m s6 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s6 int 1 run scoreboard players get @s cp.l6
function compagnons:menu/accueil_b with storage compagnons:m
