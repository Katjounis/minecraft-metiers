execute unless score @s cp.id matches 1.. run function compagnons:id
data modify storage compagnons:m dehors set value "aucun"
data modify storage compagnons:m md set value "Il te suit"
execute if score @s cp.mode matches 1 run data modify storage compagnons:m md set value "Il garde la zone"
scoreboard players set #deb cp.t 0
execute if score @s m.c_lvl matches 10.. run scoreboard players set #deb cp.t 1
execute if score @s m.c_pr matches 1.. run scoreboard players set #deb cp.t 1
execute store result storage compagnons:m l1 int 1 run scoreboard players get @s cp.l1
data modify storage compagnons:m b1 set value {text:"  Loup niv. ",color:"#C8C8C8"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b1 set value {text:"  ✖ Loup",color:"dark_gray"}
execute if score @s cp.out matches 1 run data modify storage compagnons:m dehors set value "Loup"
data modify storage compagnons:m s1 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s1 int 1 run scoreboard players get @s cp.l1
scoreboard players set #deb cp.t 0
execute if score @s m.f_lvl matches 10.. run scoreboard players set #deb cp.t 1
execute if score @s m.f_pr matches 1.. run scoreboard players set #deb cp.t 1
execute store result storage compagnons:m l2 int 1 run scoreboard players get @s cp.l2
data modify storage compagnons:m b2 set value {text:"  Chat niv. ",color:"#E0A040"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b2 set value {text:"  ✖ Chat",color:"dark_gray"}
execute if score @s cp.out matches 2 run data modify storage compagnons:m dehors set value "Chat"
data modify storage compagnons:m s2 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s2 int 1 run scoreboard players get @s cp.l2
scoreboard players set #deb cp.t 0
execute if score @s m.x_lvl matches 15.. run scoreboard players set #deb cp.t 1
execute if score @s m.x_pr matches 1.. run scoreboard players set #deb cp.t 1
execute store result storage compagnons:m l3 int 1 run scoreboard players get @s cp.l3
data modify storage compagnons:m b3 set value {text:"  Perroquet niv. ",color:"#40C860"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b3 set value {text:"  ✖ Perroquet",color:"dark_gray"}
execute if score @s cp.out matches 3 run data modify storage compagnons:m dehors set value "Perroquet"
data modify storage compagnons:m s3 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s3 int 1 run scoreboard players get @s cp.l3
scoreboard players set #deb cp.t 0
execute if score @s m.p_lvl matches 20.. run scoreboard players set #deb cp.t 1
execute if score @s m.p_pr matches 1.. run scoreboard players set #deb cp.t 1
execute store result storage compagnons:m l4 int 1 run scoreboard players get @s cp.l4
data modify storage compagnons:m b4 set value {text:"  Bonhomme niv. ",color:"#D8F0FF"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b4 set value {text:"  ✖ Bonhomme",color:"dark_gray"}
execute if score @s cp.out matches 4 run data modify storage compagnons:m dehors set value "Bonhomme de neige"
data modify storage compagnons:m s4 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s4 int 1 run scoreboard players get @s cp.l4
scoreboard players set #deb cp.t 0
execute if score @s m.n_lvl matches 25.. run scoreboard players set #deb cp.t 1
execute if score @s m.n_pr matches 1.. run scoreboard players set #deb cp.t 1
execute store result storage compagnons:m l5 int 1 run scoreboard players get @s cp.l5
data modify storage compagnons:m b5 set value {text:"  Allay niv. ",color:"#60C8FF"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b5 set value {text:"  ✖ Allay",color:"dark_gray"}
execute if score @s cp.out matches 5 run data modify storage compagnons:m dehors set value "Allay"
data modify storage compagnons:m s5 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s5 int 1 run scoreboard players get @s cp.l5
scoreboard players set #deb cp.t 0
execute if score @s m.m_lvl matches 30.. run scoreboard players set #deb cp.t 1
execute if score @s m.m_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score @s m.k_lvl matches 30.. run scoreboard players set #deb cp.t 1
execute store result storage compagnons:m l6 int 1 run scoreboard players get @s cp.l6
data modify storage compagnons:m b6 set value {text:"  Golem niv. ",color:"#D8CFC0"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b6 set value {text:"  ✖ Golem",color:"dark_gray"}
execute if score @s cp.out matches 6 run data modify storage compagnons:m dehors set value "Golem de fer"
data modify storage compagnons:m s6 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s6 int 1 run scoreboard players get @s cp.l6
scoreboard players set #deb cp.t 0
execute if score @s m.x_lvl matches 40.. run scoreboard players set #deb cp.t 1
execute if score @s m.x_pr matches 1.. run scoreboard players set #deb cp.t 1
execute store result storage compagnons:m l7 int 1 run scoreboard players get @s cp.l7
data modify storage compagnons:m b7 set value {text:"  Ghast niv. ",color:"#F4F4F4"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b7 set value {text:"  ✖ Ghast",color:"dark_gray"}
execute if score @s cp.out matches 7 run data modify storage compagnons:m dehors set value "Ghast joyeux"
data modify storage compagnons:m s7 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s7 int 1 run scoreboard players get @s cp.l7
scoreboard players set #deb cp.t 0
execute if score @s m.c_lvl matches 50.. run scoreboard players set #deb cp.t 1
execute if score @s m.c_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 1 unless entity @s[advancements={minecraft:end/kill_dragon=true}] run scoreboard players set #deb cp.t 0
execute store result storage compagnons:m l8 int 1 run scoreboard players get @s cp.l8
data modify storage compagnons:m b8 set value {text:"  Dragon niv. ",color:"#C060FF"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b8 set value {text:"  ✖ Dragon",color:"dark_gray"}
execute if score @s cp.out matches 8 run data modify storage compagnons:m dehors set value "Dragon de l’Ender"
data modify storage compagnons:m s8 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s8 int 1 run scoreboard players get @s cp.l8
scoreboard players set #deb cp.t 0
execute if score @s m.c_lvl matches 70.. run scoreboard players set #deb cp.t 1
execute if score @s m.c_pr matches 1.. run scoreboard players set #deb cp.t 1
scoreboard players set #bw cp.t 0
execute if entity @s[advancements={minecraft:nether/summon_wither=true}] run scoreboard players set #bw cp.t 1
execute if score @s cp.kwi matches 1.. run scoreboard players set #bw cp.t 1
execute if score #bw cp.t matches 0 run scoreboard players set #deb cp.t 0
execute store result storage compagnons:m l9 int 1 run scoreboard players get @s cp.l9
data modify storage compagnons:m b9 set value {text:"  Wither niv. ",color:"#8A8A8A"}
execute if score #deb cp.t matches 0 run data modify storage compagnons:m b9 set value {text:"  ✖ Wither",color:"dark_gray"}
execute if score @s cp.out matches 9 run data modify storage compagnons:m dehors set value "Wither"
data modify storage compagnons:m s9 set value ""
execute if score #deb cp.t matches 1 store result storage compagnons:m s9 int 1 run scoreboard players get @s cp.l9
data modify storage compagnons:m a1 set value ""
data modify storage compagnons:m v1 set value "verrouillé"
data modify storage compagnons:m l1 set value ""
scoreboard players set #deb cp.t 0
execute if score @s m.c_lvl matches 10.. run scoreboard players set #deb cp.t 1
execute if score @s m.c_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 1 run data modify storage compagnons:m a1 set value ""
execute if score @s cp.out matches 1 run data modify storage compagnons:m a1 set value ""
execute if score #deb cp.t matches 1 run data modify storage compagnons:m v1 set value "niv "
execute if score #deb cp.t matches 1 store result storage compagnons:m l1 int 1 run scoreboard players get @s cp.l1
execute if score #deb cp.t matches 0 run data modify storage compagnons:m p1 set value ""
execute if score #deb cp.t matches 0 run data modify storage compagnons:m r1 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l1 matches ..9 run data modify storage compagnons:m p1 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l1 matches ..9 run data modify storage compagnons:m r1 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l1 matches 10.. run data modify storage compagnons:m p1 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l1 matches 10.. run data modify storage compagnons:m r1 set value ""
data modify storage compagnons:m a2 set value ""
data modify storage compagnons:m v2 set value "verrouillé"
data modify storage compagnons:m l2 set value ""
scoreboard players set #deb cp.t 0
execute if score @s m.f_lvl matches 10.. run scoreboard players set #deb cp.t 1
execute if score @s m.f_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 1 run data modify storage compagnons:m a2 set value ""
execute if score @s cp.out matches 2 run data modify storage compagnons:m a2 set value ""
execute if score #deb cp.t matches 1 run data modify storage compagnons:m v2 set value "niv "
execute if score #deb cp.t matches 1 store result storage compagnons:m l2 int 1 run scoreboard players get @s cp.l2
execute if score #deb cp.t matches 0 run data modify storage compagnons:m p2 set value ""
execute if score #deb cp.t matches 0 run data modify storage compagnons:m r2 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l2 matches ..9 run data modify storage compagnons:m p2 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l2 matches ..9 run data modify storage compagnons:m r2 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l2 matches 10.. run data modify storage compagnons:m p2 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l2 matches 10.. run data modify storage compagnons:m r2 set value ""
data modify storage compagnons:m a3 set value ""
data modify storage compagnons:m v3 set value "verrouillé"
data modify storage compagnons:m l3 set value ""
scoreboard players set #deb cp.t 0
execute if score @s m.x_lvl matches 15.. run scoreboard players set #deb cp.t 1
execute if score @s m.x_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 1 run data modify storage compagnons:m a3 set value ""
execute if score @s cp.out matches 3 run data modify storage compagnons:m a3 set value ""
execute if score #deb cp.t matches 1 run data modify storage compagnons:m v3 set value "niv "
execute if score #deb cp.t matches 1 store result storage compagnons:m l3 int 1 run scoreboard players get @s cp.l3
execute if score #deb cp.t matches 0 run data modify storage compagnons:m p3 set value ""
execute if score #deb cp.t matches 0 run data modify storage compagnons:m r3 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l3 matches ..9 run data modify storage compagnons:m p3 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l3 matches ..9 run data modify storage compagnons:m r3 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l3 matches 10.. run data modify storage compagnons:m p3 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l3 matches 10.. run data modify storage compagnons:m r3 set value ""
data modify storage compagnons:m a4 set value ""
data modify storage compagnons:m v4 set value "verrouillé"
data modify storage compagnons:m l4 set value ""
scoreboard players set #deb cp.t 0
execute if score @s m.p_lvl matches 20.. run scoreboard players set #deb cp.t 1
execute if score @s m.p_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 1 run data modify storage compagnons:m a4 set value ""
execute if score @s cp.out matches 4 run data modify storage compagnons:m a4 set value ""
execute if score #deb cp.t matches 1 run data modify storage compagnons:m v4 set value "niv "
execute if score #deb cp.t matches 1 store result storage compagnons:m l4 int 1 run scoreboard players get @s cp.l4
execute if score #deb cp.t matches 0 run data modify storage compagnons:m p4 set value ""
execute if score #deb cp.t matches 0 run data modify storage compagnons:m r4 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l4 matches ..9 run data modify storage compagnons:m p4 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l4 matches ..9 run data modify storage compagnons:m r4 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l4 matches 10.. run data modify storage compagnons:m p4 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l4 matches 10.. run data modify storage compagnons:m r4 set value ""
data modify storage compagnons:m a5 set value ""
data modify storage compagnons:m v5 set value "verrouillé"
data modify storage compagnons:m l5 set value ""
scoreboard players set #deb cp.t 0
execute if score @s m.n_lvl matches 25.. run scoreboard players set #deb cp.t 1
execute if score @s m.n_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 1 run data modify storage compagnons:m a5 set value ""
execute if score @s cp.out matches 5 run data modify storage compagnons:m a5 set value ""
execute if score #deb cp.t matches 1 run data modify storage compagnons:m v5 set value "niv "
execute if score #deb cp.t matches 1 store result storage compagnons:m l5 int 1 run scoreboard players get @s cp.l5
execute if score #deb cp.t matches 0 run data modify storage compagnons:m p5 set value ""
execute if score #deb cp.t matches 0 run data modify storage compagnons:m r5 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l5 matches ..9 run data modify storage compagnons:m p5 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l5 matches ..9 run data modify storage compagnons:m r5 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l5 matches 10.. run data modify storage compagnons:m p5 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l5 matches 10.. run data modify storage compagnons:m r5 set value ""
data modify storage compagnons:m a6 set value ""
data modify storage compagnons:m v6 set value "verrouillé"
data modify storage compagnons:m l6 set value ""
scoreboard players set #deb cp.t 0
execute if score @s m.m_lvl matches 30.. run scoreboard players set #deb cp.t 1
execute if score @s m.m_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score @s m.k_lvl matches 30.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 1 run data modify storage compagnons:m a6 set value ""
execute if score @s cp.out matches 6 run data modify storage compagnons:m a6 set value ""
execute if score #deb cp.t matches 1 run data modify storage compagnons:m v6 set value "niv "
execute if score #deb cp.t matches 1 store result storage compagnons:m l6 int 1 run scoreboard players get @s cp.l6
execute if score #deb cp.t matches 0 run data modify storage compagnons:m p6 set value ""
execute if score #deb cp.t matches 0 run data modify storage compagnons:m r6 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l6 matches ..9 run data modify storage compagnons:m p6 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l6 matches ..9 run data modify storage compagnons:m r6 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l6 matches 10.. run data modify storage compagnons:m p6 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l6 matches 10.. run data modify storage compagnons:m r6 set value ""
data modify storage compagnons:m a7 set value ""
data modify storage compagnons:m v7 set value "verrouillé"
data modify storage compagnons:m l7 set value ""
scoreboard players set #deb cp.t 0
execute if score @s m.x_lvl matches 40.. run scoreboard players set #deb cp.t 1
execute if score @s m.x_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 1 run data modify storage compagnons:m a7 set value ""
execute if score @s cp.out matches 7 run data modify storage compagnons:m a7 set value ""
execute if score #deb cp.t matches 1 run data modify storage compagnons:m v7 set value "niv "
execute if score #deb cp.t matches 1 store result storage compagnons:m l7 int 1 run scoreboard players get @s cp.l7
execute if score #deb cp.t matches 0 run data modify storage compagnons:m p7 set value ""
execute if score #deb cp.t matches 0 run data modify storage compagnons:m r7 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l7 matches ..9 run data modify storage compagnons:m p7 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l7 matches ..9 run data modify storage compagnons:m r7 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l7 matches 10.. run data modify storage compagnons:m p7 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l7 matches 10.. run data modify storage compagnons:m r7 set value ""
data modify storage compagnons:m a8 set value ""
data modify storage compagnons:m v8 set value "verrouillé"
data modify storage compagnons:m l8 set value ""
scoreboard players set #deb cp.t 0
execute if score @s m.c_lvl matches 50.. run scoreboard players set #deb cp.t 1
execute if score @s m.c_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 1 unless entity @s[advancements={minecraft:end/kill_dragon=true}] run scoreboard players set #deb cp.t 0
execute if score #deb cp.t matches 1 run data modify storage compagnons:m a8 set value ""
execute if score @s cp.out matches 8 run data modify storage compagnons:m a8 set value ""
execute if score #deb cp.t matches 1 run data modify storage compagnons:m v8 set value "niv "
execute if score #deb cp.t matches 1 store result storage compagnons:m l8 int 1 run scoreboard players get @s cp.l8
execute if score #deb cp.t matches 0 run data modify storage compagnons:m p8 set value ""
execute if score #deb cp.t matches 0 run data modify storage compagnons:m r8 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l8 matches ..9 run data modify storage compagnons:m p8 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l8 matches ..9 run data modify storage compagnons:m r8 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l8 matches 10.. run data modify storage compagnons:m p8 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l8 matches 10.. run data modify storage compagnons:m r8 set value ""
data modify storage compagnons:m a9 set value ""
data modify storage compagnons:m v9 set value "verrouillé"
data modify storage compagnons:m l9 set value ""
scoreboard players set #deb cp.t 0
execute if score @s m.c_lvl matches 70.. run scoreboard players set #deb cp.t 1
execute if score @s m.c_pr matches 1.. run scoreboard players set #deb cp.t 1
scoreboard players set #bw cp.t 0
execute if entity @s[advancements={minecraft:nether/summon_wither=true}] run scoreboard players set #bw cp.t 1
execute if score @s cp.kwi matches 1.. run scoreboard players set #bw cp.t 1
execute if score #bw cp.t matches 0 run scoreboard players set #deb cp.t 0
execute if score #deb cp.t matches 1 run data modify storage compagnons:m a9 set value ""
execute if score @s cp.out matches 9 run data modify storage compagnons:m a9 set value ""
execute if score #deb cp.t matches 1 run data modify storage compagnons:m v9 set value "niv "
execute if score #deb cp.t matches 1 store result storage compagnons:m l9 int 1 run scoreboard players get @s cp.l9
execute if score #deb cp.t matches 0 run data modify storage compagnons:m p9 set value ""
execute if score #deb cp.t matches 0 run data modify storage compagnons:m r9 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l9 matches ..9 run data modify storage compagnons:m p9 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l9 matches ..9 run data modify storage compagnons:m r9 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l9 matches 10.. run data modify storage compagnons:m p9 set value ""
execute if score #deb cp.t matches 1 if score @s cp.l9 matches 10.. run data modify storage compagnons:m r9 set value ""
function compagnons:menu/accueil_b with storage compagnons:m
