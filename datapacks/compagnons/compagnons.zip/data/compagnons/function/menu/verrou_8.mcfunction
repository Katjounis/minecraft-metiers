tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Dragon de l’Ender se débloque au niveau 50 de Chasseur, après avoir vaincu l’Ender Dragon. Le prestige du métier compte aussi.","color":"red"}]
function compagnons:menu/accueil
