tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Loup se débloque au niveau 10 de Chasseur. Le prestige du métier compte aussi.","color":"red"}]
function compagnons:menu/accueil
