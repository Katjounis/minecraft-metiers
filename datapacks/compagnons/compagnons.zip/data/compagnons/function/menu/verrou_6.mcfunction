tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Golem de fer se débloque au niveau 30 de Mineur (ou Bâtisseur 30). Le prestige du métier compte aussi.","color":"red"}]
function compagnons:menu/accueil
