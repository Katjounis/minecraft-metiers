function compagnons:invoquer/7
function compagnons:menu/page_7
