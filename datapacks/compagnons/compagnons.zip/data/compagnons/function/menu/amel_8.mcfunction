scoreboard players add @s cp.r8 0
scoreboard players add @s cp.f8 0
scoreboard players add @s cp.m8 0
scoreboard players operation #pt cp.t = @s cp.l8
execute if score @s cp.r8 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.r8 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.r8 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.r8 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.r8 matches 5 run scoreboard players remove #pt cp.t 15
execute if score @s cp.f8 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.f8 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.f8 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.f8 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.f8 matches 5 run scoreboard players remove #pt cp.t 15
execute if score @s cp.m8 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.m8 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.m8 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.m8 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.m8 matches 5 run scoreboard players remove #pt cp.t 15
execute store result storage compagnons:a pt int 1 run scoreboard players get #pt cp.t
execute store result storage compagnons:a r int 1 run scoreboard players get @s cp.r8
data modify storage compagnons:a cr set value "red"
execute if score @s cp.r8 matches 5.. run data modify storage compagnons:a cr set value "dark_gray"
data modify storage compagnons:a pr set value "max"
execute if score @s cp.r8 matches 0 run data modify storage compagnons:a pr set value "1 pt + 1 500 Écus"
execute if score @s cp.r8 matches 1 run data modify storage compagnons:a pr set value "2 pt + 3 000 Écus"
execute if score @s cp.r8 matches 2 run data modify storage compagnons:a pr set value "3 pt + 4 500 Écus"
execute if score @s cp.r8 matches 3 run data modify storage compagnons:a pr set value "4 pt + 6 000 Écus"
execute if score @s cp.r8 matches 4 run data modify storage compagnons:a pr set value "5 pt + 7 500 Écus"
execute store result storage compagnons:a f int 1 run scoreboard players get @s cp.f8
data modify storage compagnons:a cf set value "gold"
execute if score @s cp.f8 matches 5.. run data modify storage compagnons:a cf set value "dark_gray"
data modify storage compagnons:a pf set value "max"
execute if score @s cp.f8 matches 0 run data modify storage compagnons:a pf set value "1 pt + 1 500 Écus"
execute if score @s cp.f8 matches 1 run data modify storage compagnons:a pf set value "2 pt + 3 000 Écus"
execute if score @s cp.f8 matches 2 run data modify storage compagnons:a pf set value "3 pt + 4 500 Écus"
execute if score @s cp.f8 matches 3 run data modify storage compagnons:a pf set value "4 pt + 6 000 Écus"
execute if score @s cp.f8 matches 4 run data modify storage compagnons:a pf set value "5 pt + 7 500 Écus"
execute store result storage compagnons:a m int 1 run scoreboard players get @s cp.m8
data modify storage compagnons:a cm set value "light_purple"
execute if score @s cp.m8 matches 5.. run data modify storage compagnons:a cm set value "dark_gray"
data modify storage compagnons:a pm set value "max"
execute if score @s cp.m8 matches 0 run data modify storage compagnons:a pm set value "1 pt + 1 500 Écus"
execute if score @s cp.m8 matches 1 run data modify storage compagnons:a pm set value "2 pt + 3 000 Écus"
execute if score @s cp.m8 matches 2 run data modify storage compagnons:a pm set value "3 pt + 4 500 Écus"
execute if score @s cp.m8 matches 3 run data modify storage compagnons:a pm set value "4 pt + 6 000 Écus"
execute if score @s cp.m8 matches 4 run data modify storage compagnons:a pm set value "5 pt + 7 500 Écus"
execute store result storage compagnons:a e int 1 run scoreboard players get @s c.ecus
function compagnons:menu/amel_8_d with storage compagnons:a
