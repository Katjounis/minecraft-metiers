scoreboard players set #deb cp.t 0
execute if score @s m.m_lvl matches 30.. run scoreboard players set #deb cp.t 1
execute if score @s m.m_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score @s m.k_lvl matches 30.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 0 run return run function compagnons:menu/verrou_6
execute store result storage compagnons:p lv int 1 run scoreboard players get @s cp.l6
execute store result storage compagnons:p xp int 1 run scoreboard players get @s cp.x6
function compagnons:xp/besoin_6
execute store result storage compagnons:p need int 1 run scoreboard players get #n cp.t
scoreboard players operation #b cp.t = @s cp.x6
scoreboard players operation #b cp.t *= #10 cp.t
scoreboard players operation #b cp.t /= #n cp.t
execute if score @s cp.l6 matches 30.. run scoreboard players set #b cp.t 10
execute if score #b cp.t matches 0 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 1 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 2 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 3 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 4 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 5 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 6 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 7 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 8 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 9 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 10 run data modify storage compagnons:p bar set value ""
data modify storage compagnons:p act set value "Invoquer"
data modify storage compagnons:p actc set value "green"
execute if score @s cp.out matches 6 run data modify storage compagnons:p act set value "Ranger"
execute if score @s cp.out matches 6 run data modify storage compagnons:p actc set value "gray"
execute if score @s cp.out matches 6 if score @s cp.mode matches 1 run data modify storage compagnons:p act set value "Ranger (il garde)"
data modify storage compagnons:p mdl set value "Il te suit"
execute if score @s cp.mode matches 1 run data modify storage compagnons:p mdl set value "Il garde la zone"
data modify storage compagnons:p ch set value "Chasse : non"
execute if score @s cp.ag matches 1 run data modify storage compagnons:p ch set value "Chasse : oui"
execute if score @s cp.l6 matches 1 run data modify storage compagnons:p st set value "32 cœurs · 10,5 dégâts"
execute if score @s cp.l6 matches 2 run data modify storage compagnons:p st set value "34 cœurs · 11,0 dégâts"
execute if score @s cp.l6 matches 3 run data modify storage compagnons:p st set value "36 cœurs · 11,5 dégâts · armure 1"
execute if score @s cp.l6 matches 4 run data modify storage compagnons:p st set value "38 cœurs · 12,0 dégâts · armure 1"
execute if score @s cp.l6 matches 5 run data modify storage compagnons:p st set value "40 cœurs · 12,5 dégâts · armure 1"
execute if score @s cp.l6 matches 6 run data modify storage compagnons:p st set value "42 cœurs · 13,0 dégâts · armure 2"
execute if score @s cp.l6 matches 7 run data modify storage compagnons:p st set value "44 cœurs · 13,5 dégâts · armure 2"
execute if score @s cp.l6 matches 8 run data modify storage compagnons:p st set value "46 cœurs · 14,0 dégâts · armure 2"
execute if score @s cp.l6 matches 9 run data modify storage compagnons:p st set value "48 cœurs · 14,5 dégâts · armure 3"
execute if score @s cp.l6 matches 10 run data modify storage compagnons:p st set value "50 cœurs · 15,0 dégâts · armure 3"
execute if score @s cp.l6 matches 11 run data modify storage compagnons:p st set value "52 cœurs · 15,5 dégâts · armure 3"
execute if score @s cp.l6 matches 12 run data modify storage compagnons:p st set value "54 cœurs · 16,0 dégâts · armure 4"
execute if score @s cp.l6 matches 13 run data modify storage compagnons:p st set value "56 cœurs · 16,5 dégâts · armure 4"
execute if score @s cp.l6 matches 14 run data modify storage compagnons:p st set value "58 cœurs · 17,0 dégâts · armure 4"
execute if score @s cp.l6 matches 15 run data modify storage compagnons:p st set value "60 cœurs · 17,5 dégâts · armure 5"
execute if score @s cp.l6 matches 16 run data modify storage compagnons:p st set value "62 cœurs · 18,0 dégâts · armure 5"
execute if score @s cp.l6 matches 17 run data modify storage compagnons:p st set value "64 cœurs · 18,5 dégâts · armure 5"
execute if score @s cp.l6 matches 18 run data modify storage compagnons:p st set value "66 cœurs · 19,0 dégâts · armure 6"
execute if score @s cp.l6 matches 19 run data modify storage compagnons:p st set value "68 cœurs · 19,5 dégâts · armure 6"
execute if score @s cp.l6 matches 20 run data modify storage compagnons:p st set value "70 cœurs · 20,0 dégâts · armure 6"
execute if score @s cp.l6 matches 21 run data modify storage compagnons:p st set value "72 cœurs · 20,5 dégâts · armure 7"
execute if score @s cp.l6 matches 22 run data modify storage compagnons:p st set value "74 cœurs · 21,0 dégâts · armure 7"
execute if score @s cp.l6 matches 23 run data modify storage compagnons:p st set value "76 cœurs · 21,5 dégâts · armure 7"
execute if score @s cp.l6 matches 24 run data modify storage compagnons:p st set value "78 cœurs · 22,0 dégâts · armure 8"
execute if score @s cp.l6 matches 25 run data modify storage compagnons:p st set value "80 cœurs · 22,5 dégâts · armure 8"
execute if score @s cp.l6 matches 26 run data modify storage compagnons:p st set value "82 cœurs · 23,0 dégâts · armure 8"
execute if score @s cp.l6 matches 27 run data modify storage compagnons:p st set value "84 cœurs · 23,5 dégâts · armure 9"
execute if score @s cp.l6 matches 28 run data modify storage compagnons:p st set value "86 cœurs · 24,0 dégâts · armure 9"
execute if score @s cp.l6 matches 29 run data modify storage compagnons:p st set value "88 cœurs · 24,5 dégâts · armure 9"
execute if score @s cp.l6 matches 30 run data modify storage compagnons:p st set value "90 cœurs · 25,0 dégâts · armure 10"
scoreboard players operation #E cp.t = @s cp.l6
scoreboard players operation #mm cp.t = @s cp.m6
scoreboard players operation #mm cp.t *= #2 cp.t
scoreboard players operation #E cp.t += #mm cp.t
scoreboard players operation #pt cp.t = @s cp.l6
execute if score @s cp.r6 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.r6 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.r6 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.r6 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.r6 matches 5 run scoreboard players remove #pt cp.t 15
execute if score @s cp.f6 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.f6 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.f6 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.f6 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.f6 matches 5 run scoreboard players remove #pt cp.t 15
execute if score @s cp.m6 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.m6 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.m6 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.m6 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.m6 matches 5 run scoreboard players remove #pt cp.t 15
execute store result storage compagnons:p pt int 1 run scoreboard players get #pt cp.t
data modify storage compagnons:p c0 set value "dark_gray"
data modify storage compagnons:p m0 set value "✖"
execute if score #E cp.t matches 5.. run data modify storage compagnons:p c0 set value "green"
execute if score #E cp.t matches 5.. run data modify storage compagnons:p m0 set value "✔"
data modify storage compagnons:p c1 set value "dark_gray"
data modify storage compagnons:p m1 set value "✖"
execute if score #E cp.t matches 10.. run data modify storage compagnons:p c1 set value "green"
execute if score #E cp.t matches 10.. run data modify storage compagnons:p m1 set value "✔"
data modify storage compagnons:p c2 set value "dark_gray"
data modify storage compagnons:p m2 set value "✖"
execute if score #E cp.t matches 20.. run data modify storage compagnons:p c2 set value "green"
execute if score #E cp.t matches 20.. run data modify storage compagnons:p m2 set value "✔"
data modify storage compagnons:p c3 set value "dark_gray"
data modify storage compagnons:p m3 set value "✖"
execute if score #E cp.t matches 30.. run data modify storage compagnons:p c3 set value "green"
execute if score #E cp.t matches 30.. run data modify storage compagnons:p m3 set value "✔"
function compagnons:menu/page_6_d with storage compagnons:p
