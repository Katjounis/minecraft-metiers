function compagnons:invoquer/1
function compagnons:menu/page_1
