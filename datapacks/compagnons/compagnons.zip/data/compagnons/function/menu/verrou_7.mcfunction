tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Ghast joyeux se débloque au niveau 40 d’Explorateur. Le prestige du métier compte aussi.","color":"red"}]
function compagnons:menu/accueil
