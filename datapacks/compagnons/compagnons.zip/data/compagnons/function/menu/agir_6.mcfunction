function compagnons:invoquer/6
function compagnons:menu/page_6
