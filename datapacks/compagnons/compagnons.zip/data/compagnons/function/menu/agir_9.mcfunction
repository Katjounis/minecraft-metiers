function compagnons:invoquer/9
function compagnons:menu/page_9
