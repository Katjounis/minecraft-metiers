tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Chat se débloque au niveau 10 de Fermier. Le prestige du métier compte aussi.","color":"red"}]
function compagnons:menu/accueil
