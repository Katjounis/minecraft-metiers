function compagnons:invoquer/2
function compagnons:menu/page_2
