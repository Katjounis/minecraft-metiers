function compagnons:invoquer/3
function compagnons:menu/page_3
