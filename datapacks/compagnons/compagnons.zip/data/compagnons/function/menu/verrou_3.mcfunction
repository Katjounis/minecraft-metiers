tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Perroquet se débloque au niveau 15 d’Explorateur. Le prestige du métier compte aussi.","color":"red"}]
function compagnons:menu/accueil
