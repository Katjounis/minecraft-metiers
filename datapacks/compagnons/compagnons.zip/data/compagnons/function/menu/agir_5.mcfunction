function compagnons:invoquer/5
function compagnons:menu/page_5
