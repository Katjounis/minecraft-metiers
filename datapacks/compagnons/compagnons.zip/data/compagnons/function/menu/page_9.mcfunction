scoreboard players set #deb cp.t 0
execute if score @s m.c_lvl matches 70.. run scoreboard players set #deb cp.t 1
execute if score @s m.c_pr matches 1.. run scoreboard players set #deb cp.t 1
scoreboard players set #bw cp.t 0
execute if entity @s[advancements={minecraft:nether/summon_wither=true}] run scoreboard players set #bw cp.t 1
execute if score @s cp.kwi matches 1.. run scoreboard players set #bw cp.t 1
execute if score #bw cp.t matches 0 run scoreboard players set #deb cp.t 0
execute if score #deb cp.t matches 0 run return run function compagnons:menu/verrou_9
execute store result storage compagnons:p lv int 1 run scoreboard players get @s cp.l9
execute store result storage compagnons:p xp int 1 run scoreboard players get @s cp.x9
scoreboard players operation #n cp.t = @s cp.l9
scoreboard players operation #n cp.t *= #6 cp.t
scoreboard players operation #n cp.t += #20 cp.t
execute store result storage compagnons:p need int 1 run scoreboard players get #n cp.t
scoreboard players operation #b cp.t = @s cp.x9
scoreboard players operation #b cp.t *= #10 cp.t
scoreboard players operation #b cp.t /= #n cp.t
execute if score @s cp.l9 matches 30.. run scoreboard players set #b cp.t 10
execute if score #b cp.t matches 0 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 1 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 2 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 3 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 4 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 5 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 6 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 7 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 8 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 9 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 10 run data modify storage compagnons:p bar set value ""
data modify storage compagnons:p act set value "Invoquer"
data modify storage compagnons:p actc set value "green"
execute if score @s cp.out matches 9 run data modify storage compagnons:p act set value "Ranger"
execute if score @s cp.out matches 9 run data modify storage compagnons:p actc set value "gray"
execute if score @s cp.out matches 9 if score @s cp.mode matches 1 run data modify storage compagnons:p act set value "Ranger (il garde)"
data modify storage compagnons:p mdl set value "Il te suit"
execute if score @s cp.mode matches 1 run data modify storage compagnons:p mdl set value "Il garde la zone"
data modify storage compagnons:p ch set value "Chasse : non"
execute if score @s cp.ag matches 1 run data modify storage compagnons:p ch set value "Chasse : oui"
execute if score @s cp.l9 matches 1 run data modify storage compagnons:p st set value "32 cœurs"
execute if score @s cp.l9 matches 2 run data modify storage compagnons:p st set value "35 cœurs"
execute if score @s cp.l9 matches 3 run data modify storage compagnons:p st set value "37 cœurs · armure 1"
execute if score @s cp.l9 matches 4 run data modify storage compagnons:p st set value "40 cœurs · armure 1"
execute if score @s cp.l9 matches 5 run data modify storage compagnons:p st set value "42 cœurs · armure 1"
execute if score @s cp.l9 matches 6 run data modify storage compagnons:p st set value "45 cœurs · armure 2"
execute if score @s cp.l9 matches 7 run data modify storage compagnons:p st set value "47 cœurs · armure 2"
execute if score @s cp.l9 matches 8 run data modify storage compagnons:p st set value "50 cœurs · armure 2"
execute if score @s cp.l9 matches 9 run data modify storage compagnons:p st set value "52 cœurs · armure 3"
execute if score @s cp.l9 matches 10 run data modify storage compagnons:p st set value "55 cœurs · armure 3"
execute if score @s cp.l9 matches 11 run data modify storage compagnons:p st set value "57 cœurs · armure 3"
execute if score @s cp.l9 matches 12 run data modify storage compagnons:p st set value "60 cœurs · armure 4"
execute if score @s cp.l9 matches 13 run data modify storage compagnons:p st set value "62 cœurs · armure 4"
execute if score @s cp.l9 matches 14 run data modify storage compagnons:p st set value "65 cœurs · armure 4"
execute if score @s cp.l9 matches 15 run data modify storage compagnons:p st set value "67 cœurs · armure 5"
execute if score @s cp.l9 matches 16 run data modify storage compagnons:p st set value "70 cœurs · armure 5"
execute if score @s cp.l9 matches 17 run data modify storage compagnons:p st set value "72 cœurs · armure 5"
execute if score @s cp.l9 matches 18 run data modify storage compagnons:p st set value "75 cœurs · armure 6"
execute if score @s cp.l9 matches 19 run data modify storage compagnons:p st set value "77 cœurs · armure 6"
execute if score @s cp.l9 matches 20 run data modify storage compagnons:p st set value "80 cœurs · armure 6"
execute if score @s cp.l9 matches 21 run data modify storage compagnons:p st set value "82 cœurs · armure 7"
execute if score @s cp.l9 matches 22 run data modify storage compagnons:p st set value "85 cœurs · armure 7"
execute if score @s cp.l9 matches 23 run data modify storage compagnons:p st set value "87 cœurs · armure 7"
execute if score @s cp.l9 matches 24 run data modify storage compagnons:p st set value "90 cœurs · armure 8"
execute if score @s cp.l9 matches 25 run data modify storage compagnons:p st set value "92 cœurs · armure 8"
execute if score @s cp.l9 matches 26 run data modify storage compagnons:p st set value "95 cœurs · armure 8"
execute if score @s cp.l9 matches 27 run data modify storage compagnons:p st set value "97 cœurs · armure 9"
execute if score @s cp.l9 matches 28 run data modify storage compagnons:p st set value "100 cœurs · armure 9"
execute if score @s cp.l9 matches 29 run data modify storage compagnons:p st set value "102 cœurs · armure 9"
execute if score @s cp.l9 matches 30 run data modify storage compagnons:p st set value "105 cœurs · armure 10"
scoreboard players operation #E cp.t = @s cp.l9
scoreboard players operation #mm cp.t = @s cp.m9
scoreboard players operation #mm cp.t *= #2 cp.t
scoreboard players operation #E cp.t += #mm cp.t
scoreboard players operation #pt cp.t = @s cp.l9
execute if score @s cp.r9 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.r9 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.r9 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.r9 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.r9 matches 5 run scoreboard players remove #pt cp.t 15
execute if score @s cp.f9 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.f9 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.f9 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.f9 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.f9 matches 5 run scoreboard players remove #pt cp.t 15
execute if score @s cp.m9 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.m9 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.m9 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.m9 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.m9 matches 5 run scoreboard players remove #pt cp.t 15
execute store result storage compagnons:p pt int 1 run scoreboard players get #pt cp.t
data modify storage compagnons:p c0 set value "dark_gray"
data modify storage compagnons:p m0 set value "✖"
execute if score #E cp.t matches 5.. run data modify storage compagnons:p c0 set value "green"
execute if score #E cp.t matches 5.. run data modify storage compagnons:p m0 set value "✔"
data modify storage compagnons:p c1 set value "dark_gray"
data modify storage compagnons:p m1 set value "✖"
execute if score #E cp.t matches 10.. run data modify storage compagnons:p c1 set value "green"
execute if score #E cp.t matches 10.. run data modify storage compagnons:p m1 set value "✔"
data modify storage compagnons:p c2 set value "dark_gray"
data modify storage compagnons:p m2 set value "✖"
execute if score #E cp.t matches 20.. run data modify storage compagnons:p c2 set value "green"
execute if score #E cp.t matches 20.. run data modify storage compagnons:p m2 set value "✔"
data modify storage compagnons:p c3 set value "dark_gray"
data modify storage compagnons:p m3 set value "✖"
execute if score #E cp.t matches 30.. run data modify storage compagnons:p c3 set value "green"
execute if score #E cp.t matches 30.. run data modify storage compagnons:p m3 set value "✔"
function compagnons:menu/page_9_d with storage compagnons:p
