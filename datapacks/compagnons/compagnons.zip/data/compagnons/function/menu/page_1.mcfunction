data modify storage compagnons:p ap set value "Pâle"
scoreboard players set #deb cp.t 0
execute if score @s m.c_lvl matches 10.. run scoreboard players set #deb cp.t 1
execute if score @s m.c_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 0 run return run function compagnons:menu/verrou_1
execute store result storage compagnons:p lv int 1 run scoreboard players get @s cp.l1
execute store result storage compagnons:p xp int 1 run scoreboard players get @s cp.x1
function compagnons:xp/besoin_1
execute store result storage compagnons:p need int 1 run scoreboard players get #n cp.t
scoreboard players operation #b cp.t = @s cp.x1
scoreboard players operation #b cp.t *= #10 cp.t
scoreboard players operation #b cp.t /= #n cp.t
execute if score @s cp.l1 matches 30.. run scoreboard players set #b cp.t 10
execute if score #b cp.t matches 0 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 1 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 2 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 3 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 4 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 5 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 6 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 7 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 8 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 9 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 10 run data modify storage compagnons:p bar set value ""
data modify storage compagnons:p act set value "Invoquer"
data modify storage compagnons:p actc set value "green"
execute if score @s cp.out matches 1 run data modify storage compagnons:p act set value "Ranger"
execute if score @s cp.out matches 1 run data modify storage compagnons:p actc set value "gray"
execute if score @s cp.out matches 1 if score @s cp.mode matches 1 run data modify storage compagnons:p act set value "Ranger (il garde)"
data modify storage compagnons:p mdl set value "Il te suit"
execute if score @s cp.mode matches 1 run data modify storage compagnons:p mdl set value "Il garde la zone"
data modify storage compagnons:p ch set value "Chasse : non"
execute if score @s cp.ag matches 1 run data modify storage compagnons:p ch set value "Chasse : oui"
execute if score @s cp.l1 matches 1 run data modify storage compagnons:p st set value "11 cœurs · 4,2 dégâts"
execute if score @s cp.l1 matches 2 run data modify storage compagnons:p st set value "12 cœurs · 4,5 dégâts"
execute if score @s cp.l1 matches 3 run data modify storage compagnons:p st set value "13 cœurs · 4,8 dégâts"
execute if score @s cp.l1 matches 4 run data modify storage compagnons:p st set value "14 cœurs · 5,0 dégâts"
execute if score @s cp.l1 matches 5 run data modify storage compagnons:p st set value "15 cœurs · 5,2 dégâts · armure 2"
execute if score @s cp.l1 matches 6 run data modify storage compagnons:p st set value "16 cœurs · 5,5 dégâts · armure 2"
execute if score @s cp.l1 matches 7 run data modify storage compagnons:p st set value "17 cœurs · 5,8 dégâts · armure 2"
execute if score @s cp.l1 matches 8 run data modify storage compagnons:p st set value "18 cœurs · 6,0 dégâts · armure 2"
execute if score @s cp.l1 matches 9 run data modify storage compagnons:p st set value "19 cœurs · 6,2 dégâts · armure 2"
execute if score @s cp.l1 matches 10 run data modify storage compagnons:p st set value "20 cœurs · 6,5 dégâts · armure 4"
execute if score @s cp.l1 matches 11 run data modify storage compagnons:p st set value "21 cœurs · 6,8 dégâts · armure 4"
execute if score @s cp.l1 matches 12 run data modify storage compagnons:p st set value "22 cœurs · 7,0 dégâts · armure 4"
execute if score @s cp.l1 matches 13 run data modify storage compagnons:p st set value "23 cœurs · 7,2 dégâts · armure 4"
execute if score @s cp.l1 matches 14 run data modify storage compagnons:p st set value "24 cœurs · 7,5 dégâts · armure 4"
execute if score @s cp.l1 matches 15 run data modify storage compagnons:p st set value "25 cœurs · 7,8 dégâts · armure 6"
execute if score @s cp.l1 matches 16 run data modify storage compagnons:p st set value "26 cœurs · 8,0 dégâts · armure 6"
execute if score @s cp.l1 matches 17 run data modify storage compagnons:p st set value "27 cœurs · 8,2 dégâts · armure 6"
execute if score @s cp.l1 matches 18 run data modify storage compagnons:p st set value "28 cœurs · 8,5 dégâts · armure 6"
execute if score @s cp.l1 matches 19 run data modify storage compagnons:p st set value "29 cœurs · 8,8 dégâts · armure 6"
execute if score @s cp.l1 matches 20 run data modify storage compagnons:p st set value "30 cœurs · 9,0 dégâts · armure 8"
execute if score @s cp.l1 matches 21 run data modify storage compagnons:p st set value "31 cœurs · 9,2 dégâts · armure 8"
execute if score @s cp.l1 matches 22 run data modify storage compagnons:p st set value "32 cœurs · 9,5 dégâts · armure 8"
execute if score @s cp.l1 matches 23 run data modify storage compagnons:p st set value "33 cœurs · 9,8 dégâts · armure 8"
execute if score @s cp.l1 matches 24 run data modify storage compagnons:p st set value "34 cœurs · 10,0 dégâts · armure 8"
execute if score @s cp.l1 matches 25 run data modify storage compagnons:p st set value "35 cœurs · 10,2 dégâts · armure 10"
execute if score @s cp.l1 matches 26 run data modify storage compagnons:p st set value "36 cœurs · 10,5 dégâts · armure 10"
execute if score @s cp.l1 matches 27 run data modify storage compagnons:p st set value "37 cœurs · 10,8 dégâts · armure 10"
execute if score @s cp.l1 matches 28 run data modify storage compagnons:p st set value "38 cœurs · 11,0 dégâts · armure 10"
execute if score @s cp.l1 matches 29 run data modify storage compagnons:p st set value "39 cœurs · 11,2 dégâts · armure 10"
execute if score @s cp.l1 matches 30 run data modify storage compagnons:p st set value "40 cœurs · 11,5 dégâts · armure 12"
scoreboard players operation #E cp.t = @s cp.l1
scoreboard players operation #mm cp.t = @s cp.m1
scoreboard players operation #mm cp.t *= #2 cp.t
scoreboard players operation #E cp.t += #mm cp.t
scoreboard players operation #pt cp.t = @s cp.l1
execute if score @s cp.r1 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.r1 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.r1 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.r1 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.r1 matches 5 run scoreboard players remove #pt cp.t 15
execute if score @s cp.f1 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.f1 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.f1 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.f1 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.f1 matches 5 run scoreboard players remove #pt cp.t 15
execute if score @s cp.m1 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.m1 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.m1 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.m1 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.m1 matches 5 run scoreboard players remove #pt cp.t 15
execute store result storage compagnons:p pt int 1 run scoreboard players get #pt cp.t
data modify storage compagnons:p c0 set value "dark_gray"
data modify storage compagnons:p m0 set value "✖"
execute if score #E cp.t matches 5.. run data modify storage compagnons:p c0 set value "green"
execute if score #E cp.t matches 5.. run data modify storage compagnons:p m0 set value "✔"
data modify storage compagnons:p c1 set value "dark_gray"
data modify storage compagnons:p m1 set value "✖"
execute if score #E cp.t matches 10.. run data modify storage compagnons:p c1 set value "green"
execute if score #E cp.t matches 10.. run data modify storage compagnons:p m1 set value "✔"
data modify storage compagnons:p c2 set value "dark_gray"
data modify storage compagnons:p m2 set value "✖"
execute if score #E cp.t matches 20.. run data modify storage compagnons:p c2 set value "green"
execute if score #E cp.t matches 20.. run data modify storage compagnons:p m2 set value "✔"
data modify storage compagnons:p c3 set value "dark_gray"
data modify storage compagnons:p m3 set value "✖"
execute if score #E cp.t matches 30.. run data modify storage compagnons:p c3 set value "green"
execute if score #E cp.t matches 30.. run data modify storage compagnons:p m3 set value "✔"
execute if score @s cp.v1 matches 0 run data modify storage compagnons:p ap set value "Pâle"
execute if score @s cp.v1 matches 1 run data modify storage compagnons:p ap set value "Des bois"
execute if score @s cp.v1 matches 2 run data modify storage compagnons:p ap set value "Cendré"
execute if score @s cp.v1 matches 3 run data modify storage compagnons:p ap set value "Noir"
execute if score @s cp.v1 matches 4 run data modify storage compagnons:p ap set value "Châtaigne"
execute if score @s cp.v1 matches 5 run data modify storage compagnons:p ap set value "Roux"
execute if score @s cp.v1 matches 6 run data modify storage compagnons:p ap set value "Tacheté"
execute if score @s cp.v1 matches 7 run data modify storage compagnons:p ap set value "Rayé"
execute if score @s cp.v1 matches 8 run data modify storage compagnons:p ap set value "Des neiges"
function compagnons:menu/page_1_d with storage compagnons:p
