data modify storage compagnons:p ap set value "Tigré"
scoreboard players set #deb cp.t 0
execute if score @s m.f_lvl matches 10.. run scoreboard players set #deb cp.t 1
execute if score @s m.f_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 0 run return run function compagnons:menu/verrou_2
execute store result storage compagnons:p lv int 1 run scoreboard players get @s cp.l2
execute store result storage compagnons:p xp int 1 run scoreboard players get @s cp.x2
scoreboard players operation #n cp.t = @s cp.l2
scoreboard players operation #n cp.t *= #6 cp.t
scoreboard players operation #n cp.t += #20 cp.t
execute store result storage compagnons:p need int 1 run scoreboard players get #n cp.t
scoreboard players operation #b cp.t = @s cp.x2
scoreboard players operation #b cp.t *= #10 cp.t
scoreboard players operation #b cp.t /= #n cp.t
execute if score @s cp.l2 matches 30.. run scoreboard players set #b cp.t 10
execute if score #b cp.t matches 0 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 1 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 2 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 3 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 4 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 5 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 6 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 7 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 8 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 9 run data modify storage compagnons:p bar set value ""
execute if score #b cp.t matches 10 run data modify storage compagnons:p bar set value ""
data modify storage compagnons:p act set value "Invoquer"
data modify storage compagnons:p actc set value "green"
execute if score @s cp.out matches 2 run data modify storage compagnons:p act set value "Ranger"
execute if score @s cp.out matches 2 run data modify storage compagnons:p actc set value "gray"
execute if score @s cp.out matches 2 if score @s cp.mode matches 1 run data modify storage compagnons:p act set value "Ranger (il garde)"
data modify storage compagnons:p mdl set value "Il te suit"
execute if score @s cp.mode matches 1 run data modify storage compagnons:p mdl set value "Il garde la zone"
data modify storage compagnons:p ch set value "Chasse : non"
execute if score @s cp.ag matches 1 run data modify storage compagnons:p ch set value "Chasse : oui"
execute if score @s cp.l2 matches 1 run data modify storage compagnons:p st set value "5 cœurs · 3,1 dégâts"
execute if score @s cp.l2 matches 2 run data modify storage compagnons:p st set value "6 cœurs · 3,2 dégâts"
execute if score @s cp.l2 matches 3 run data modify storage compagnons:p st set value "6 cœurs · 3,3 dégâts"
execute if score @s cp.l2 matches 4 run data modify storage compagnons:p st set value "7 cœurs · 3,4 dégâts"
execute if score @s cp.l2 matches 5 run data modify storage compagnons:p st set value "7 cœurs · 3,5 dégâts"
execute if score @s cp.l2 matches 6 run data modify storage compagnons:p st set value "8 cœurs · 3,6 dégâts · armure 1"
execute if score @s cp.l2 matches 7 run data modify storage compagnons:p st set value "8 cœurs · 3,7 dégâts · armure 1"
execute if score @s cp.l2 matches 8 run data modify storage compagnons:p st set value "9 cœurs · 3,8 dégâts · armure 1"
execute if score @s cp.l2 matches 9 run data modify storage compagnons:p st set value "9 cœurs · 3,9 dégâts · armure 1"
execute if score @s cp.l2 matches 10 run data modify storage compagnons:p st set value "10 cœurs · 4,0 dégâts · armure 1"
execute if score @s cp.l2 matches 11 run data modify storage compagnons:p st set value "10 cœurs · 4,1 dégâts · armure 1"
execute if score @s cp.l2 matches 12 run data modify storage compagnons:p st set value "11 cœurs · 4,2 dégâts · armure 2"
execute if score @s cp.l2 matches 13 run data modify storage compagnons:p st set value "11 cœurs · 4,3 dégâts · armure 2"
execute if score @s cp.l2 matches 14 run data modify storage compagnons:p st set value "12 cœurs · 4,4 dégâts · armure 2"
execute if score @s cp.l2 matches 15 run data modify storage compagnons:p st set value "12 cœurs · 4,5 dégâts · armure 2"
execute if score @s cp.l2 matches 16 run data modify storage compagnons:p st set value "13 cœurs · 4,6 dégâts · armure 2"
execute if score @s cp.l2 matches 17 run data modify storage compagnons:p st set value "13 cœurs · 4,7 dégâts · armure 2"
execute if score @s cp.l2 matches 18 run data modify storage compagnons:p st set value "14 cœurs · 4,8 dégâts · armure 3"
execute if score @s cp.l2 matches 19 run data modify storage compagnons:p st set value "14 cœurs · 4,9 dégâts · armure 3"
execute if score @s cp.l2 matches 20 run data modify storage compagnons:p st set value "15 cœurs · 5,0 dégâts · armure 3"
execute if score @s cp.l2 matches 21 run data modify storage compagnons:p st set value "15 cœurs · 5,1 dégâts · armure 3"
execute if score @s cp.l2 matches 22 run data modify storage compagnons:p st set value "16 cœurs · 5,2 dégâts · armure 3"
execute if score @s cp.l2 matches 23 run data modify storage compagnons:p st set value "16 cœurs · 5,3 dégâts · armure 3"
execute if score @s cp.l2 matches 24 run data modify storage compagnons:p st set value "17 cœurs · 5,4 dégâts · armure 4"
execute if score @s cp.l2 matches 25 run data modify storage compagnons:p st set value "17 cœurs · 5,5 dégâts · armure 4"
execute if score @s cp.l2 matches 26 run data modify storage compagnons:p st set value "18 cœurs · 5,6 dégâts · armure 4"
execute if score @s cp.l2 matches 27 run data modify storage compagnons:p st set value "18 cœurs · 5,7 dégâts · armure 4"
execute if score @s cp.l2 matches 28 run data modify storage compagnons:p st set value "19 cœurs · 5,8 dégâts · armure 4"
execute if score @s cp.l2 matches 29 run data modify storage compagnons:p st set value "19 cœurs · 5,9 dégâts · armure 4"
execute if score @s cp.l2 matches 30 run data modify storage compagnons:p st set value "20 cœurs · 6,0 dégâts · armure 5"
scoreboard players operation #E cp.t = @s cp.l2
scoreboard players operation #mm cp.t = @s cp.m2
scoreboard players operation #mm cp.t *= #2 cp.t
scoreboard players operation #E cp.t += #mm cp.t
scoreboard players operation #pt cp.t = @s cp.l2
execute if score @s cp.r2 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.r2 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.r2 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.r2 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.r2 matches 5 run scoreboard players remove #pt cp.t 15
execute if score @s cp.f2 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.f2 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.f2 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.f2 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.f2 matches 5 run scoreboard players remove #pt cp.t 15
execute if score @s cp.m2 matches 1 run scoreboard players remove #pt cp.t 1
execute if score @s cp.m2 matches 2 run scoreboard players remove #pt cp.t 3
execute if score @s cp.m2 matches 3 run scoreboard players remove #pt cp.t 6
execute if score @s cp.m2 matches 4 run scoreboard players remove #pt cp.t 10
execute if score @s cp.m2 matches 5 run scoreboard players remove #pt cp.t 15
execute store result storage compagnons:p pt int 1 run scoreboard players get #pt cp.t
data modify storage compagnons:p c0 set value "dark_gray"
data modify storage compagnons:p m0 set value "✖"
execute if score #E cp.t matches 5.. run data modify storage compagnons:p c0 set value "green"
execute if score #E cp.t matches 5.. run data modify storage compagnons:p m0 set value "✔"
data modify storage compagnons:p c1 set value "dark_gray"
data modify storage compagnons:p m1 set value "✖"
execute if score #E cp.t matches 10.. run data modify storage compagnons:p c1 set value "green"
execute if score #E cp.t matches 10.. run data modify storage compagnons:p m1 set value "✔"
data modify storage compagnons:p c2 set value "dark_gray"
data modify storage compagnons:p m2 set value "✖"
execute if score #E cp.t matches 20.. run data modify storage compagnons:p c2 set value "green"
execute if score #E cp.t matches 20.. run data modify storage compagnons:p m2 set value "✔"
data modify storage compagnons:p c3 set value "dark_gray"
data modify storage compagnons:p m3 set value "✖"
execute if score #E cp.t matches 30.. run data modify storage compagnons:p c3 set value "green"
execute if score #E cp.t matches 30.. run data modify storage compagnons:p m3 set value "✔"
execute if score @s cp.v2 matches 0 run data modify storage compagnons:p ap set value "Tigré"
execute if score @s cp.v2 matches 1 run data modify storage compagnons:p ap set value "Noir"
execute if score @s cp.v2 matches 2 run data modify storage compagnons:p ap set value "Roux"
execute if score @s cp.v2 matches 3 run data modify storage compagnons:p ap set value "Siamois"
execute if score @s cp.v2 matches 4 run data modify storage compagnons:p ap set value "British"
execute if score @s cp.v2 matches 5 run data modify storage compagnons:p ap set value "Calico"
execute if score @s cp.v2 matches 6 run data modify storage compagnons:p ap set value "Persan"
execute if score @s cp.v2 matches 7 run data modify storage compagnons:p ap set value "Ragdoll"
execute if score @s cp.v2 matches 8 run data modify storage compagnons:p ap set value "Blanc"
execute if score @s cp.v2 matches 9 run data modify storage compagnons:p ap set value "Jellie"
execute if score @s cp.v2 matches 10 run data modify storage compagnons:p ap set value "Tout noir"
function compagnons:menu/page_2_d with storage compagnons:p
