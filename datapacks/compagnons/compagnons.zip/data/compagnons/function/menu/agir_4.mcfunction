function compagnons:invoquer/4
function compagnons:menu/page_4
