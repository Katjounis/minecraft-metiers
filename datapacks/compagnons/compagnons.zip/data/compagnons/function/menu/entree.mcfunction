scoreboard players operation #v cp.t = @s compagnons
scoreboard players set @s compagnons 0
scoreboard players enable @s compagnons
execute if score #v cp.t matches 1 run return run function compagnons:menu/accueil
execute if score #v cp.t matches 2 run return run function compagnons:ranger
execute if score #v cp.t matches 3 run return run function compagnons:mode
execute if score #v cp.t matches 4 run return run function compagnons:menu/aide
execute if score #v cp.t matches 5 run return run function compagnons:chasse
execute if score #v cp.t matches 11 run return run function compagnons:menu/page_1
execute if score #v cp.t matches 21 run return run function compagnons:menu/agir_1
execute if score #v cp.t matches 41 run return run function compagnons:renommer/1
execute if score #v cp.t matches 31 run return run function compagnons:apparence/1
execute if score #v cp.t matches 12 run return run function compagnons:menu/page_2
execute if score #v cp.t matches 22 run return run function compagnons:menu/agir_2
execute if score #v cp.t matches 42 run return run function compagnons:renommer/2
execute if score #v cp.t matches 32 run return run function compagnons:apparence/2
execute if score #v cp.t matches 13 run return run function compagnons:menu/page_3
execute if score #v cp.t matches 23 run return run function compagnons:menu/agir_3
execute if score #v cp.t matches 43 run return run function compagnons:renommer/3
execute if score #v cp.t matches 33 run return run function compagnons:apparence/3
execute if score #v cp.t matches 14 run return run function compagnons:menu/page_4
execute if score #v cp.t matches 24 run return run function compagnons:menu/agir_4
execute if score #v cp.t matches 44 run return run function compagnons:renommer/4
execute if score #v cp.t matches 15 run return run function compagnons:menu/page_5
execute if score #v cp.t matches 25 run return run function compagnons:menu/agir_5
execute if score #v cp.t matches 45 run return run function compagnons:renommer/5
execute if score #v cp.t matches 16 run return run function compagnons:menu/page_6
execute if score #v cp.t matches 26 run return run function compagnons:menu/agir_6
execute if score #v cp.t matches 46 run return run function compagnons:renommer/6
