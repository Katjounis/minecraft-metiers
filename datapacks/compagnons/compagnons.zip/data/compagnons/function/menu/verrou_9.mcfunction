tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Wither se débloque au niveau 70 de Chasseur, après avoir affronté le Wither. Le prestige du métier compte aussi.","color":"red"}]
function compagnons:menu/accueil
