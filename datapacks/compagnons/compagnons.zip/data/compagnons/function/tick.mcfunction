execute as @a[scores={compagnons=1..}] at @s run function compagnons:menu/entree
scoreboard players add #t5 cp.t 1
execute if score #t5 cp.t matches 5.. run scoreboard players set #t5 cp.t 0
execute if score #t5 cp.t matches 0 as @e[tag=cp.c] at @s as @e[type=#compagnons:hostiles,distance=..24,tag=!cp.mort] if data entity @s {Health:0.0f} run function compagnons:xp/mort
execute as @e[tag=cp.porteur] at @s run function compagnons:c/visuel
execute as @e[tag=cp.c] at @s run function compagnons:c/suivre
execute as @e[type=minecraft:interaction,tag=cp.monter] if data entity @s interaction run function compagnons:c/monter_clic
