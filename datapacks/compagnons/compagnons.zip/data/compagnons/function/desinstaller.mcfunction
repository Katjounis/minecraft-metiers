tp @e[tag=cp.c] ~ -1000 ~
kill @e[tag=cp.c]
tp @e[tag=cp.renfort] ~ -1000 ~
kill @e[tag=cp.renfort]
schedule clear compagnons:seconde
scoreboard objectives remove cp.id
scoreboard objectives remove cp.ser
scoreboard objectives remove cp.out
scoreboard objectives remove cp.cd
scoreboard objectives remove cp.cda
scoreboard objectives remove cp.mode
scoreboard objectives remove cp.ag
scoreboard objectives remove cp.own
scoreboard objectives remove cp.typ
scoreboard objectives remove cp.hp
scoreboard objectives remove cp.hpm
scoreboard objectives remove cp.min
scoreboard objectives remove cp.vie
scoreboard objectives remove cp.t
scoreboard objectives remove cp.tk
scoreboard objectives remove cp.ok
scoreboard objectives remove cp.l1
scoreboard objectives remove cp.x1
scoreboard objectives remove cp.v1
scoreboard objectives remove cp.l2
scoreboard objectives remove cp.x2
scoreboard objectives remove cp.v2
scoreboard objectives remove cp.l3
scoreboard objectives remove cp.x3
scoreboard objectives remove cp.v3
scoreboard objectives remove cp.l4
scoreboard objectives remove cp.x4
scoreboard objectives remove cp.v4
scoreboard objectives remove cp.l5
scoreboard objectives remove cp.x5
scoreboard objectives remove cp.v5
scoreboard objectives remove cp.l6
scoreboard objectives remove cp.x6
scoreboard objectives remove cp.v6
scoreboard objectives remove cp.vie_j
scoreboard objectives remove compagnons
scoreboard objectives remove cp.mk
data remove storage compagnons:noms J
tellraw @s {"text":"[Compagnons] Désinstallé. Désactive maintenant le pack : /datapack disable \"file/compagnons.zip\"","color":"gray"}
