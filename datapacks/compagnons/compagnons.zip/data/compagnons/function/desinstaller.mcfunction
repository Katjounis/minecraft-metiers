tp @e[tag=cp.c] ~ -1000 ~
kill @e[tag=cp.c]
kill @e[tag=cp.vis]
tp @e[tag=cp.renfort] ~ -1000 ~
kill @e[tag=cp.renfort]
schedule clear compagnons:seconde
scoreboard objectives remove cp.id
scoreboard objectives remove cp.ser
scoreboard objectives remove cp.out
scoreboard objectives remove cp.cd
scoreboard objectives remove cp.cda
scoreboard objectives remove cp.mode
scoreboard objectives remove cp.ag
scoreboard objectives remove cp.own
scoreboard objectives remove cp.typ
scoreboard objectives remove cp.hp
scoreboard objectives remove cp.hpm
scoreboard objectives remove cp.min
scoreboard objectives remove cp.vie
scoreboard objectives remove cp.t
scoreboard objectives remove cp.tk
scoreboard objectives remove cp.ok
scoreboard objectives remove cp.mt
scoreboard objectives remove cp.att
scoreboard objectives remove cp.l1
scoreboard objectives remove cp.x1
scoreboard objectives remove cp.v1
scoreboard objectives remove cp.r1
scoreboard objectives remove cp.f1
scoreboard objectives remove cp.m1
scoreboard objectives remove cp.l2
scoreboard objectives remove cp.x2
scoreboard objectives remove cp.v2
scoreboard objectives remove cp.r2
scoreboard objectives remove cp.f2
scoreboard objectives remove cp.m2
scoreboard objectives remove cp.l3
scoreboard objectives remove cp.x3
scoreboard objectives remove cp.v3
scoreboard objectives remove cp.r3
scoreboard objectives remove cp.f3
scoreboard objectives remove cp.m3
scoreboard objectives remove cp.l4
scoreboard objectives remove cp.x4
scoreboard objectives remove cp.v4
scoreboard objectives remove cp.r4
scoreboard objectives remove cp.f4
scoreboard objectives remove cp.m4
scoreboard objectives remove cp.l5
scoreboard objectives remove cp.x5
scoreboard objectives remove cp.v5
scoreboard objectives remove cp.r5
scoreboard objectives remove cp.f5
scoreboard objectives remove cp.m5
scoreboard objectives remove cp.l6
scoreboard objectives remove cp.x6
scoreboard objectives remove cp.v6
scoreboard objectives remove cp.r6
scoreboard objectives remove cp.f6
scoreboard objectives remove cp.m6
scoreboard objectives remove cp.l7
scoreboard objectives remove cp.x7
scoreboard objectives remove cp.v7
scoreboard objectives remove cp.r7
scoreboard objectives remove cp.f7
scoreboard objectives remove cp.m7
scoreboard objectives remove cp.l8
scoreboard objectives remove cp.x8
scoreboard objectives remove cp.v8
scoreboard objectives remove cp.r8
scoreboard objectives remove cp.f8
scoreboard objectives remove cp.m8
scoreboard objectives remove cp.l9
scoreboard objectives remove cp.x9
scoreboard objectives remove cp.v9
scoreboard objectives remove cp.r9
scoreboard objectives remove cp.f9
scoreboard objectives remove cp.m9
scoreboard objectives remove cp.vie_j
scoreboard objectives remove compagnons
scoreboard objectives remove cp.mk
scoreboard objectives remove cp.kwi
data remove storage compagnons:noms J
tellraw @s {"text":"[Compagnons] Désinstallé. Désactive maintenant le pack : /datapack disable \"file/compagnons.zip\"","color":"gray"}
