scoreboard players set #deb cp.t 0
execute if score @s m.m_lvl matches 30.. run scoreboard players set #deb cp.t 1
execute if score @s m.m_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score @s m.k_lvl matches 30.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 0 run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Golem de fer se débloque au niveau 30 de Mineur (ou Bâtisseur 30).","color":"red"}]
execute if score @s cp.out matches 6 run return run function compagnons:ranger
execute if score @s cp.cd matches 1.. run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton compagnon se repose encore (K.O.). Patiente un peu.","color":"red"}]
function compagnons:ranger_silence
scoreboard players set @s cp.out 6
function compagnons:invoquer/actuel
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton Golem de fer t’accompagne.","color":"#D8CFC0"}]
