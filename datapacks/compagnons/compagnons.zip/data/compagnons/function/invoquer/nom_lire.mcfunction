$execute if data storage compagnons:noms J[{id:$(id)}].n$(k) run data modify storage compagnons:t n set from storage compagnons:noms J[{id:$(id)}].n$(k)
