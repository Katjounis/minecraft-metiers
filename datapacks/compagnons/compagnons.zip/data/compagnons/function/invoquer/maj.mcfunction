function compagnons:marquer
tag @e[tag=cp.cur] add cp.nouveau
execute as @e[tag=cp.cur] run function compagnons:invoquer/stats
function compagnons:invoquer/nom
tag @e[tag=cp.nouveau] remove cp.nouveau
execute at @e[tag=cp.cur] run particle minecraft:totem_of_undying ~ ~1 ~ 0.3 0.5 0.3 0.3 20
