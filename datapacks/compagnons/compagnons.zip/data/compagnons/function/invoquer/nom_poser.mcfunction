$data modify entity @e[tag=cp.nouveau,limit=1] CustomName set value [{text:"",color:"white",italic:false},$(n),{text:"  niv. $(lv)",color:"gray"}]
$data modify entity @e[tag=cp.nvis,limit=1] CustomName set value [{text:"",color:"white",italic:false},$(n),{text:"  niv. $(lv)",color:"gray"}]
