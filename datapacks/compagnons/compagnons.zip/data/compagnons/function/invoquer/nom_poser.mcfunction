$data modify entity @e[tag=cp.nouveau,limit=1] CustomName set value [{text:"",color:"white",italic:false},$(n),{text:"  niv. $(lv)",color:"gray"}]
