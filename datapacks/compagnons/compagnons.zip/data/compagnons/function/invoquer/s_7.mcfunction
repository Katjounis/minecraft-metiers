summon minecraft:happy_ghast ^ ^ ^-1.5 {Tags:["cp.c", "cp.nouveau", "cp.ghast", "cp.lent", "cp.vol"],DeathLootTable:"minecraft:empty",PersistenceRequired:1b,CanPickUpLoot:0b,CustomNameVisible:1b}
execute if score @s cp.v7 matches 0 run data modify entity @e[tag=cp.nouveau,limit=1] equipment.body set value {id:"minecraft:white_harness",count:1}
execute if score @s cp.v7 matches 1 run data modify entity @e[tag=cp.nouveau,limit=1] equipment.body set value {id:"minecraft:light_blue_harness",count:1}
execute if score @s cp.v7 matches 2 run data modify entity @e[tag=cp.nouveau,limit=1] equipment.body set value {id:"minecraft:yellow_harness",count:1}
execute if score @s cp.v7 matches 3 run data modify entity @e[tag=cp.nouveau,limit=1] equipment.body set value {id:"minecraft:lime_harness",count:1}
execute if score @s cp.v7 matches 4 run data modify entity @e[tag=cp.nouveau,limit=1] equipment.body set value {id:"minecraft:pink_harness",count:1}
execute if score @s cp.v7 matches 5 run data modify entity @e[tag=cp.nouveau,limit=1] equipment.body set value {id:"minecraft:orange_harness",count:1}
execute if score @s cp.v7 matches 6 run data modify entity @e[tag=cp.nouveau,limit=1] equipment.body set value {id:"minecraft:purple_harness",count:1}
execute if score @s cp.v7 matches 7 run data modify entity @e[tag=cp.nouveau,limit=1] equipment.body set value {id:"minecraft:red_harness",count:1}
execute if score @s cp.v7 matches 8 run data modify entity @e[tag=cp.nouveau,limit=1] equipment.body set value {id:"minecraft:black_harness",count:1}
