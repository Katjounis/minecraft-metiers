scoreboard players set #deb cp.t 0
execute if score @s m.c_lvl matches 50.. run scoreboard players set #deb cp.t 1
execute if score @s m.c_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 1 unless entity @s[advancements={minecraft:end/kill_dragon=true}] run scoreboard players set #deb cp.t 0
execute if score #deb cp.t matches 0 run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Dragon de l’Ender se débloque au niveau 50 de Chasseur, après avoir vaincu l’Ender Dragon.","color":"red"}]
execute if score @s cp.out matches 8 run return run function compagnons:ranger
execute if score @s cp.cd matches 1.. run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton compagnon se repose encore (K.O.). Patiente un peu.","color":"red"}]
execute if dimension minecraft:the_end run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le dragon refuse de voler dans l’End.","color":"light_purple"}]
function compagnons:ranger_silence
scoreboard players set @s cp.out 8
function compagnons:invoquer/actuel
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton Dragon de l’Ender t’accompagne.","color":"#C060FF"}]
