scoreboard players set #deb cp.t 0
execute if score @s m.x_lvl matches 40.. run scoreboard players set #deb cp.t 1
execute if score @s m.x_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 0 run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Ghast joyeux se débloque au niveau 40 d’Explorateur.","color":"red"}]
execute if score @s cp.out matches 7 run return run function compagnons:ranger
execute if score @s cp.cd matches 1.. run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton compagnon se repose encore (K.O.). Patiente un peu.","color":"red"}]
function compagnons:ranger_silence
scoreboard players set @s cp.out 7
function compagnons:invoquer/actuel
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton Ghast joyeux t’accompagne.","color":"#F4F4F4"}]
