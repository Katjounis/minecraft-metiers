scoreboard players set #deb cp.t 0
execute if score @s m.c_lvl matches 70.. run scoreboard players set #deb cp.t 1
execute if score @s m.c_pr matches 1.. run scoreboard players set #deb cp.t 1
scoreboard players set #bw cp.t 0
execute if entity @s[advancements={minecraft:nether/summon_wither=true}] run scoreboard players set #bw cp.t 1
execute if score @s cp.kwi matches 1.. run scoreboard players set #bw cp.t 1
execute if score #bw cp.t matches 0 run scoreboard players set #deb cp.t 0
execute if score #deb cp.t matches 0 run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Wither se débloque au niveau 70 de Chasseur, après avoir affronté le Wither.","color":"red"}]
execute if score @s cp.out matches 9 run return run function compagnons:ranger
execute if score @s cp.cd matches 1.. run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton compagnon se repose encore (K.O.). Patiente un peu.","color":"red"}]
function compagnons:ranger_silence
scoreboard players set @s cp.out 9
function compagnons:invoquer/actuel
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton Wither t’accompagne.","color":"#8A8A8A"}]
