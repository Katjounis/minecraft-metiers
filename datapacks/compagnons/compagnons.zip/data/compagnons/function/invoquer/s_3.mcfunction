summon minecraft:parrot ^ ^ ^-1.5 {Tags:["cp.c", "cp.nouveau", "cp.perroquet"],DeathLootTable:"minecraft:empty",PersistenceRequired:1b,CanPickUpLoot:0b,CustomNameVisible:1b}
data modify entity @e[tag=cp.nouveau,limit=1] Owner set from entity @s UUID
execute if score @s cp.v3 matches 0 run data modify entity @e[tag=cp.nouveau,limit=1] Variant set value 0
execute if score @s cp.v3 matches 1 run data modify entity @e[tag=cp.nouveau,limit=1] Variant set value 1
execute if score @s cp.v3 matches 2 run data modify entity @e[tag=cp.nouveau,limit=1] Variant set value 2
execute if score @s cp.v3 matches 3 run data modify entity @e[tag=cp.nouveau,limit=1] Variant set value 3
execute if score @s cp.v3 matches 4 run data modify entity @e[tag=cp.nouveau,limit=1] Variant set value 4
