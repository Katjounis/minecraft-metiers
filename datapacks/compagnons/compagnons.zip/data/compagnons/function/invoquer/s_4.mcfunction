summon minecraft:snow_golem ^ ^ ^-1.5 {Tags:["cp.c", "cp.nouveau", "cp.neige", "cp.lent"],DeathLootTable:"minecraft:empty",PersistenceRequired:1b,CanPickUpLoot:0b,CustomNameVisible:1b,Pumpkin:1b}
