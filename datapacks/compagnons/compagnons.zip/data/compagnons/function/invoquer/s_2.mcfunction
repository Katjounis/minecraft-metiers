summon minecraft:cat ^ ^ ^-1.5 {Tags:["cp.c", "cp.nouveau", "cp.chat"],DeathLootTable:"minecraft:empty",PersistenceRequired:1b,CanPickUpLoot:0b,CustomNameVisible:1b}
data modify entity @e[tag=cp.nouveau,limit=1] Owner set from entity @s UUID
execute if score @s cp.v2 matches 0 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:tabby"
execute if score @s cp.v2 matches 1 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:black"
execute if score @s cp.v2 matches 2 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:red"
execute if score @s cp.v2 matches 3 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:siamese"
execute if score @s cp.v2 matches 4 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:british_shorthair"
execute if score @s cp.v2 matches 5 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:calico"
execute if score @s cp.v2 matches 6 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:persian"
execute if score @s cp.v2 matches 7 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:ragdoll"
execute if score @s cp.v2 matches 8 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:white"
execute if score @s cp.v2 matches 9 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:jellie"
execute if score @s cp.v2 matches 10 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:all_black"
