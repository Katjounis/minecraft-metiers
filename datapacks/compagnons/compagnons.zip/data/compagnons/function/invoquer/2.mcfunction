scoreboard players set #deb cp.t 0
execute if score @s m.f_lvl matches 10.. run scoreboard players set #deb cp.t 1
execute if score @s m.f_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 0 run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Chat se débloque au niveau 10 de Fermier.","color":"red"}]
execute if score @s cp.out matches 2 run return run function compagnons:ranger
execute if score @s cp.cd matches 1.. run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton compagnon se repose encore (K.O.). Patiente un peu.","color":"red"}]
function compagnons:ranger_silence
scoreboard players set @s cp.out 2
function compagnons:invoquer/actuel
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton Chat t’accompagne.","color":"#E0A040"}]
