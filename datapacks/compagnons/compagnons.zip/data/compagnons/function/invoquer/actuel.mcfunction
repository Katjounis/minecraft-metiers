scoreboard players add @s cp.ser 1
scoreboard players set @s cp.hp 99999
execute if score @s cp.out matches 1 run function compagnons:invoquer/s_1
execute if score @s cp.out matches 2 run function compagnons:invoquer/s_2
execute if score @s cp.out matches 3 run function compagnons:invoquer/s_3
execute if score @s cp.out matches 4 run function compagnons:invoquer/s_4
execute if score @s cp.out matches 5 run function compagnons:invoquer/s_5
execute if score @s cp.out matches 6 run function compagnons:invoquer/s_6
execute if score @s cp.out matches 7 run function compagnons:invoquer/s_7
execute if score @s cp.out matches 8 run function compagnons:invoquer/s_8
execute if score @s cp.out matches 9 run function compagnons:invoquer/s_9
scoreboard players operation @e[tag=cp.nouveau] cp.own = @s cp.id
scoreboard players operation @e[tag=cp.nouveau] cp.ser = @s cp.ser
scoreboard players operation @e[tag=cp.nouveau] cp.typ = @s cp.out
scoreboard players operation @e[tag=cp.nvis] cp.own = @s cp.id
scoreboard players operation @e[tag=cp.nvis] cp.ser = @s cp.ser
execute as @e[tag=cp.nouveau] run function compagnons:invoquer/stats
function compagnons:invoquer/nom
tag @e[tag=cp.nouveau] remove cp.nouveau
tag @e[tag=cp.nvis] remove cp.nvis
particle minecraft:happy_villager ~ ~1 ~ 0.5 0.5 0.5 0 12
playsound minecraft:entity.allay.item_given neutral @s ~ ~ ~ 0.6 1.2
