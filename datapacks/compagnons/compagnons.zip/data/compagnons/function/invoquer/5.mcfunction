scoreboard players set #deb cp.t 0
execute if score @s m.n_lvl matches 25.. run scoreboard players set #deb cp.t 1
execute if score @s m.n_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 0 run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"L’Allay se débloque au niveau 25 d’Enchanteur.","color":"red"}]
execute if score @s cp.out matches 5 run return run function compagnons:ranger
execute if score @s cp.cd matches 1.. run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton compagnon se repose encore (K.O.). Patiente un peu.","color":"red"}]
function compagnons:ranger_silence
scoreboard players set @s cp.out 5
function compagnons:invoquer/actuel
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton Allay t’accompagne.","color":"#60C8FF"}]
