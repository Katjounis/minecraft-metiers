scoreboard players set #deb cp.t 0
execute if score @s m.p_lvl matches 20.. run scoreboard players set #deb cp.t 1
execute if score @s m.p_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 0 run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Bonhomme de neige se débloque au niveau 20 de Pêcheur.","color":"red"}]
execute if score @s cp.out matches 4 run return run function compagnons:ranger
execute if score @s cp.cd matches 1.. run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton compagnon se repose encore (K.O.). Patiente un peu.","color":"red"}]
function compagnons:ranger_silence
scoreboard players set @s cp.out 4
function compagnons:invoquer/actuel
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton Bonhomme de neige t’accompagne.","color":"#D8F0FF"}]
