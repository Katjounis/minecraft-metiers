summon minecraft:allay ^ ^ ^-1.5 {Tags:["cp.c", "cp.nouveau", "cp.allay"],DeathLootTable:"minecraft:empty",PersistenceRequired:1b,CanPickUpLoot:0b,CustomNameVisible:1b}
data modify entity @e[tag=cp.nouveau,limit=1] Brain.memories."minecraft:liked_player".value set from entity @s UUID
