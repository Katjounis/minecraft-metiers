scoreboard players operation #o cp.t = @s cp.own
scoreboard players operation #y cp.t = @s cp.typ
scoreboard players set #L cp.t 1
execute if score #y cp.t matches 1 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l1
execute if score #y cp.t matches 2 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l2
execute if score #y cp.t matches 3 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l3
execute if score #y cp.t matches 4 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l4
execute if score #y cp.t matches 5 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l5
execute if score #y cp.t matches 6 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l6
execute if score #y cp.t matches 1 run function compagnons:stats/1
execute if score #y cp.t matches 2 run function compagnons:stats/2
execute if score #y cp.t matches 3 run function compagnons:stats/3
execute if score #y cp.t matches 4 run function compagnons:stats/4
execute if score #y cp.t matches 5 run function compagnons:stats/5
execute if score #y cp.t matches 6 run function compagnons:stats/6
