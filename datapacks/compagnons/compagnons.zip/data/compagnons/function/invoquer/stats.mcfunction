scoreboard players set #P cp.t 0
scoreboard players set #R cp.t 0
scoreboard players operation #o cp.t = @s cp.own
scoreboard players operation #y cp.t = @s cp.typ
scoreboard players set #L cp.t 1
execute if score #y cp.t matches 1 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l1
execute if score #y cp.t matches 2 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l2
execute if score #y cp.t matches 3 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l3
execute if score #y cp.t matches 4 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l4
execute if score #y cp.t matches 5 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l5
execute if score #y cp.t matches 6 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l6
execute if score #y cp.t matches 7 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l7
execute if score #y cp.t matches 8 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l8
execute if score #y cp.t matches 9 as @a if score @s cp.id = #o cp.t run scoreboard players operation #L cp.t = @s cp.l9
execute if score #y cp.t matches 1 as @a if score @s cp.id = #o cp.t run scoreboard players operation #R cp.t = @s cp.r1
execute if score #y cp.t matches 2 as @a if score @s cp.id = #o cp.t run scoreboard players operation #R cp.t = @s cp.r2
execute if score #y cp.t matches 3 as @a if score @s cp.id = #o cp.t run scoreboard players operation #R cp.t = @s cp.r3
execute if score #y cp.t matches 4 as @a if score @s cp.id = #o cp.t run scoreboard players operation #R cp.t = @s cp.r4
execute if score #y cp.t matches 5 as @a if score @s cp.id = #o cp.t run scoreboard players operation #R cp.t = @s cp.r5
execute if score #y cp.t matches 6 as @a if score @s cp.id = #o cp.t run scoreboard players operation #R cp.t = @s cp.r6
execute if score #y cp.t matches 7 as @a if score @s cp.id = #o cp.t run scoreboard players operation #R cp.t = @s cp.r7
execute if score #y cp.t matches 8 as @a if score @s cp.id = #o cp.t run scoreboard players operation #R cp.t = @s cp.r8
execute if score #y cp.t matches 9 as @a if score @s cp.id = #o cp.t run scoreboard players operation #R cp.t = @s cp.r9
execute if score #y cp.t matches 1 as @a if score @s cp.id = #o cp.t run scoreboard players operation #P cp.t = @s cp.f1
execute if score #y cp.t matches 2 as @a if score @s cp.id = #o cp.t run scoreboard players operation #P cp.t = @s cp.f2
execute if score #y cp.t matches 3 as @a if score @s cp.id = #o cp.t run scoreboard players operation #P cp.t = @s cp.f3
execute if score #y cp.t matches 4 as @a if score @s cp.id = #o cp.t run scoreboard players operation #P cp.t = @s cp.f4
execute if score #y cp.t matches 5 as @a if score @s cp.id = #o cp.t run scoreboard players operation #P cp.t = @s cp.f5
execute if score #y cp.t matches 6 as @a if score @s cp.id = #o cp.t run scoreboard players operation #P cp.t = @s cp.f6
execute if score #y cp.t matches 7 as @a if score @s cp.id = #o cp.t run scoreboard players operation #P cp.t = @s cp.f7
execute if score #y cp.t matches 8 as @a if score @s cp.id = #o cp.t run scoreboard players operation #P cp.t = @s cp.f8
execute if score #y cp.t matches 9 as @a if score @s cp.id = #o cp.t run scoreboard players operation #P cp.t = @s cp.f9
execute if score #y cp.t matches 1 run function compagnons:stats/1
execute if score #y cp.t matches 2 run function compagnons:stats/2
execute if score #y cp.t matches 3 run function compagnons:stats/3
execute if score #y cp.t matches 4 run function compagnons:stats/4
execute if score #y cp.t matches 5 run function compagnons:stats/5
execute if score #y cp.t matches 6 run function compagnons:stats/6
execute if score #y cp.t matches 7 run function compagnons:stats/7
execute if score #y cp.t matches 8 run function compagnons:stats/8
execute if score #y cp.t matches 9 run function compagnons:stats/9
function compagnons:stats/rangs
