summon minecraft:wolf ^ ^ ^-1.5 {Tags:["cp.c", "cp.nouveau", "cp.loup"],DeathLootTable:"minecraft:empty",PersistenceRequired:1b,CanPickUpLoot:0b,CustomNameVisible:1b}
data modify entity @e[tag=cp.nouveau,limit=1] Owner set from entity @s UUID
execute if score @s cp.v1 matches 0 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:pale"
execute if score @s cp.v1 matches 1 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:woods"
execute if score @s cp.v1 matches 2 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:ashen"
execute if score @s cp.v1 matches 3 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:black"
execute if score @s cp.v1 matches 4 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:chestnut"
execute if score @s cp.v1 matches 5 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:rusty"
execute if score @s cp.v1 matches 6 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:spotted"
execute if score @s cp.v1 matches 7 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:striped"
execute if score @s cp.v1 matches 8 run data modify entity @e[tag=cp.nouveau,limit=1] variant set value "minecraft:snowy"
execute if score @s cp.l1 matches 15.. run data modify entity @e[tag=cp.nouveau,limit=1] equipment.body set value {id:"minecraft:wolf_armor",count:1}
