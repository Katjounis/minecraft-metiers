scoreboard players set #deb cp.t 0
execute if score @s m.x_lvl matches 15.. run scoreboard players set #deb cp.t 1
execute if score @s m.x_pr matches 1.. run scoreboard players set #deb cp.t 1
execute if score #deb cp.t matches 0 run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Le Perroquet se débloque au niveau 15 d’Explorateur.","color":"red"}]
execute if score @s cp.out matches 3 run return run function compagnons:ranger
execute if score @s cp.cd matches 1.. run return run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton compagnon se repose encore (K.O.). Patiente un peu.","color":"red"}]
function compagnons:ranger_silence
scoreboard players set @s cp.out 3
function compagnons:invoquer/actuel
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton Perroquet t’accompagne.","color":"#40C860"}]
