execute store result storage compagnons:t id int 1 run scoreboard players get @s cp.id
execute store result storage compagnons:t k int 1 run scoreboard players get @s cp.out
execute if score @s cp.out matches 1 store result storage compagnons:t lv int 1 run scoreboard players get @s cp.l1
execute if score @s cp.out matches 2 store result storage compagnons:t lv int 1 run scoreboard players get @s cp.l2
execute if score @s cp.out matches 3 store result storage compagnons:t lv int 1 run scoreboard players get @s cp.l3
execute if score @s cp.out matches 4 store result storage compagnons:t lv int 1 run scoreboard players get @s cp.l4
execute if score @s cp.out matches 5 store result storage compagnons:t lv int 1 run scoreboard players get @s cp.l5
execute if score @s cp.out matches 6 store result storage compagnons:t lv int 1 run scoreboard players get @s cp.l6
execute if score @s cp.out matches 1 run data modify storage compagnons:t n set value {text:"Loup",color:"#C8C8C8"}
execute if score @s cp.out matches 2 run data modify storage compagnons:t n set value {text:"Chat",color:"#E0A040"}
execute if score @s cp.out matches 3 run data modify storage compagnons:t n set value {text:"Perroquet",color:"#40C860"}
execute if score @s cp.out matches 4 run data modify storage compagnons:t n set value {text:"Bonhomme de neige",color:"#D8F0FF"}
execute if score @s cp.out matches 5 run data modify storage compagnons:t n set value {text:"Allay",color:"#60C8FF"}
execute if score @s cp.out matches 6 run data modify storage compagnons:t n set value {text:"Golem de fer",color:"#D8CFC0"}
function compagnons:invoquer/nom_lire with storage compagnons:t
function compagnons:invoquer/nom_poser with storage compagnons:t
