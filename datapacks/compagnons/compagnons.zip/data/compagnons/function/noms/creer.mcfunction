$execute unless data storage compagnons:noms J[{id:$(id)}] run data modify storage compagnons:noms J append value {id:$(id)}
