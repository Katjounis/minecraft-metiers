scoreboard players add @s cp.v7 1
execute if score @s cp.v7 matches 1 unless score @s cp.l7 matches 4.. run scoreboard players set @s cp.v7 0
execute if score @s cp.v7 matches 2 unless score @s cp.l7 matches 7.. run scoreboard players set @s cp.v7 0
execute if score @s cp.v7 matches 3 unless score @s cp.l7 matches 10.. run scoreboard players set @s cp.v7 0
execute if score @s cp.v7 matches 4 unless score @s cp.l7 matches 13.. run scoreboard players set @s cp.v7 0
execute if score @s cp.v7 matches 5 unless score @s cp.l7 matches 16.. run scoreboard players set @s cp.v7 0
execute if score @s cp.v7 matches 6 unless score @s cp.l7 matches 19.. run scoreboard players set @s cp.v7 0
execute if score @s cp.v7 matches 7 unless score @s cp.l7 matches 22.. run scoreboard players set @s cp.v7 0
execute if score @s cp.v7 matches 8 unless score @s cp.l7 matches 25.. run scoreboard players set @s cp.v7 0
execute if score @s cp.v7 matches 9.. run scoreboard players set @s cp.v7 0
execute if score @s cp.out matches 7 run function compagnons:invoquer/actuel
function compagnons:menu/page_7
