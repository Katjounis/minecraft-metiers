scoreboard players add @s cp.v1 1
execute if score @s cp.v1 matches 1 unless score @s cp.l1 matches 4.. run scoreboard players set @s cp.v1 0
execute if score @s cp.v1 matches 2 unless score @s cp.l1 matches 7.. run scoreboard players set @s cp.v1 0
execute if score @s cp.v1 matches 3 unless score @s cp.l1 matches 10.. run scoreboard players set @s cp.v1 0
execute if score @s cp.v1 matches 4 unless score @s cp.l1 matches 13.. run scoreboard players set @s cp.v1 0
execute if score @s cp.v1 matches 5 unless score @s cp.l1 matches 16.. run scoreboard players set @s cp.v1 0
execute if score @s cp.v1 matches 6 unless score @s cp.l1 matches 19.. run scoreboard players set @s cp.v1 0
execute if score @s cp.v1 matches 7 unless score @s cp.l1 matches 22.. run scoreboard players set @s cp.v1 0
execute if score @s cp.v1 matches 8 unless score @s cp.l1 matches 25.. run scoreboard players set @s cp.v1 0
execute if score @s cp.v1 matches 9.. run scoreboard players set @s cp.v1 0
execute if score @s cp.out matches 1 run function compagnons:invoquer/actuel
function compagnons:menu/page_1
