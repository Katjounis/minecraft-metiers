scoreboard players add @s cp.v2 1
execute if score @s cp.v2 matches 1 unless score @s cp.l2 matches 3.. run scoreboard players set @s cp.v2 0
execute if score @s cp.v2 matches 2 unless score @s cp.l2 matches 5.. run scoreboard players set @s cp.v2 0
execute if score @s cp.v2 matches 3 unless score @s cp.l2 matches 7.. run scoreboard players set @s cp.v2 0
execute if score @s cp.v2 matches 4 unless score @s cp.l2 matches 9.. run scoreboard players set @s cp.v2 0
execute if score @s cp.v2 matches 5 unless score @s cp.l2 matches 11.. run scoreboard players set @s cp.v2 0
execute if score @s cp.v2 matches 6 unless score @s cp.l2 matches 13.. run scoreboard players set @s cp.v2 0
execute if score @s cp.v2 matches 7 unless score @s cp.l2 matches 15.. run scoreboard players set @s cp.v2 0
execute if score @s cp.v2 matches 8 unless score @s cp.l2 matches 17.. run scoreboard players set @s cp.v2 0
execute if score @s cp.v2 matches 9 unless score @s cp.l2 matches 19.. run scoreboard players set @s cp.v2 0
execute if score @s cp.v2 matches 10 unless score @s cp.l2 matches 21.. run scoreboard players set @s cp.v2 0
execute if score @s cp.v2 matches 11.. run scoreboard players set @s cp.v2 0
execute if score @s cp.out matches 2 run function compagnons:invoquer/actuel
function compagnons:menu/page_2
