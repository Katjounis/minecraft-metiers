scoreboard players add @s cp.v3 1
execute if score @s cp.v3 matches 1 unless score @s cp.l3 matches 6.. run scoreboard players set @s cp.v3 0
execute if score @s cp.v3 matches 2 unless score @s cp.l3 matches 11.. run scoreboard players set @s cp.v3 0
execute if score @s cp.v3 matches 3 unless score @s cp.l3 matches 16.. run scoreboard players set @s cp.v3 0
execute if score @s cp.v3 matches 4 unless score @s cp.l3 matches 21.. run scoreboard players set @s cp.v3 0
execute if score @s cp.v3 matches 5.. run scoreboard players set @s cp.v3 0
execute if score @s cp.out matches 3 run function compagnons:invoquer/actuel
function compagnons:menu/page_3
