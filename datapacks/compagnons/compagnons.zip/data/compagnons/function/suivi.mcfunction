function compagnons:marquer
tag @s add cp.moi
scoreboard players operation #h cp.t = @s cp.hpm
scoreboard players operation #h cp.t /= #2 cp.t
execute unless entity @e[tag=cp.cur] if score @s cp.hp < #h cp.t run function compagnons:ko_perdu
execute unless entity @e[tag=cp.cur] if score @s cp.cd matches ..0 run function compagnons:invoquer/actuel
execute as @e[tag=cp.cur,limit=1] at @s run function compagnons:c/tour
tag @s remove cp.moi
