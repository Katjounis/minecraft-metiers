scoreboard players operation #L cp.t = @a[tag=cp.moi,limit=1] cp.l3
execute if score #L cp.t matches 5.. at @a[tag=cp.moi,limit=1] run effect give @e[type=#compagnons:hostiles,distance=..16] minecraft:glowing 2 0 true
execute if score #L cp.t matches 10.. as @a[tag=cp.moi,limit=1] at @s if block ~ ~-1 ~ #minecraft:air if block ~ ~-2 ~ #minecraft:air if block ~ ~-3 ~ #minecraft:air unless predicate compagnons:planeur run effect give @s minecraft:slow_falling 2 0 true
execute if score #L cp.t matches 20.. as @a[tag=cp.moi,limit=1] at @s if entity @e[type=minecraft:creeper,distance=..10] run function compagnons:c/alerte
execute if score #L cp.t matches 30.. run effect give @a[tag=cp.moi] minecraft:speed 2 0 true
execute if score #L cp.t matches 30.. run effect give @a[tag=cp.moi] minecraft:jump_boost 2 0 true
