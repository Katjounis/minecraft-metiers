scoreboard players operation #m cp.t = #s cp.tk
scoreboard players operation #m cp.t %= #10 cp.t
execute if score #m cp.t matches 0 as @a[tag=cp.moi,distance=..12] if predicate compagnons:blesse run effect give @s minecraft:regeneration 4 0 true
