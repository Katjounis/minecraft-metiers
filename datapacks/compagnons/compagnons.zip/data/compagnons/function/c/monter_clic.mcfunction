scoreboard players operation #o cp.t = @s cp.own
scoreboard players operation #s cp.t = @s cp.ser
execute on target run tag @s add cp.monteur
execute as @e[tag=cp.porteur] if score @s cp.own = #o cp.t if score @s cp.ser = #s cp.t run tag @s add cp.monture
ride @a[tag=cp.monteur,limit=1] mount @e[tag=cp.monture,limit=1]
tag @a remove cp.monteur
tag @e remove cp.monture
data remove entity @s interaction
data remove entity @s attack
