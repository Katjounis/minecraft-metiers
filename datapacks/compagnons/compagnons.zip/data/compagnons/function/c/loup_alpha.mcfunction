execute if score @s cp.cda matches 1.. run return 0
scoreboard players set @s cp.cda 120
summon minecraft:wolf ~1 ~ ~ {Tags:["cp.renfort","cp.nouveau"],DeathLootTable:"minecraft:empty",PersistenceRequired:1b,variant:"minecraft:black"}
summon minecraft:wolf ~-1 ~ ~ {Tags:["cp.renfort","cp.nouveau"],DeathLootTable:"minecraft:empty",PersistenceRequired:1b,variant:"minecraft:black"}
execute as @e[tag=cp.nouveau] run data modify entity @s Owner set from entity @a[tag=cp.moi,limit=1] UUID
scoreboard players set @e[tag=cp.nouveau] cp.vie 30
tag @e[tag=cp.nouveau] remove cp.nouveau
playsound minecraft:entity.wolf.howl neutral @a[distance=..32] ~ ~ ~ 1.5 0.8
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Alpha : la meute arrive en renfort !","color":"gold"}]
