tag @s add cp.teste
execute on attacker if entity @s[tag=cp.frappeur_j] run tag @e[tag=cp.teste,limit=1] add cp.proie
tag @s remove cp.teste
