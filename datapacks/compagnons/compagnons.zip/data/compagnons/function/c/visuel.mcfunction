scoreboard players operation #o cp.t = @s cp.own
scoreboard players operation #s cp.t = @s cp.ser
execute as @e[tag=cp.vdragon] if score @s cp.own = #o cp.t if score @s cp.ser = #s cp.t run tp @s ~ ~-0.6 ~ ~180 0
execute as @e[tag=cp.vwither] if score @s cp.own = #o cp.t if score @s cp.ser = #s cp.t run tp @s ~ ~-0.4 ~ ~0 0
execute as @e[type=minecraft:interaction,tag=cp.monter] if score @s cp.own = #o cp.t if score @s cp.ser = #s cp.t run tp @s ~ ~ ~
