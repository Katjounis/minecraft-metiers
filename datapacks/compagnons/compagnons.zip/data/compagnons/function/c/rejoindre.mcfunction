particle minecraft:poof ~ ~0.5 ~ 0.3 0.4 0.3 0.02 8
execute unless entity @s[tag=cp.vol] at @a[tag=cp.moi,limit=1] rotated ~ 0 run tp @s ^ ^ ^-3
execute if entity @s[tag=cp.vol] at @a[tag=cp.moi,limit=1] rotated ~ 0 run tp @s ^ ^2 ^-5
execute at @s run particle minecraft:poof ~ ~0.5 ~ 0.3 0.4 0.3 0.02 8
