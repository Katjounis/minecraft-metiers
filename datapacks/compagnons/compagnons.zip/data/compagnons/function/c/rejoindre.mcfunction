particle minecraft:poof ~ ~0.5 ~ 0.3 0.4 0.3 0.02 8
execute at @a[tag=cp.moi,limit=1] run tp @s ^ ^ ^-1.5
execute at @s run particle minecraft:poof ~ ~0.5 ~ 0.3 0.4 0.3 0.02 8
