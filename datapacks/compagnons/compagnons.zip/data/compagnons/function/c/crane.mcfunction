tag @s add cp.tireur
execute as @e[type=#compagnons:hostiles,distance=..16,sort=nearest,limit=1] at @s run function compagnons:c/crane_touche
playsound minecraft:entity.wither.shoot neutral @a[distance=..32] ~ ~ ~ 1 1
tag @s remove cp.tireur
