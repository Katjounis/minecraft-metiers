execute if score #L cp.t matches 5.. if score #s cp.tk matches 0.. run function compagnons:c/chat_ronron
execute if score #L cp.t matches 10.. run effect give @a[tag=cp.moi,distance=..24] minecraft:night_vision 15 0 true
execute if score #L cp.t matches 20.. as @a[tag=cp.moi,limit=1] if predicate compagnons:faible run function compagnons:c/sauvetage_120
execute if score #L cp.t matches 30.. run effect give @a[tag=cp.moi] minecraft:luck 3 1 true
