particle minecraft:large_smoke ~ ~1 ~ 0.3 0.5 0.3 0.02 15
particle minecraft:soul ~ ~1 ~ 0.3 0.5 0.3 0.02 6
damage @s 7 minecraft:wither_skull by @e[tag=cp.tireur,limit=1]
effect give @s minecraft:wither 4 1
