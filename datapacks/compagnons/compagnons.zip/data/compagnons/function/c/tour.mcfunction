execute store result score @s cp.hp run data get entity @s Health
execute store result score @s cp.hpm run attribute @s minecraft:max_health get
scoreboard players operation @a[tag=cp.moi] cp.hp = @s cp.hp
scoreboard players operation @a[tag=cp.moi] cp.hpm = @s cp.hpm
scoreboard players operation #q cp.t = @s cp.hp
scoreboard players operation #q cp.t *= #5 cp.t
execute if score #q cp.t <= @s cp.hpm run return run function compagnons:c/ko
execute if entity @a[tag=cp.moi,scores={cp.mode=0}] unless entity @a[tag=cp.moi,distance=..24] run function compagnons:c/rejoindre
execute if entity @s[tag=cp.lent] if entity @a[tag=cp.moi,scores={cp.mode=0}] unless entity @a[tag=cp.moi,distance=..8] run function compagnons:c/rejoindre
execute if score @s cp.typ matches 1 run function compagnons:c/cap_1
execute if score @s cp.typ matches 2 run function compagnons:c/cap_2
execute if score @s cp.typ matches 3 run function compagnons:c/cap_3
execute if score @s cp.typ matches 4 run function compagnons:c/cap_4
execute if score @s cp.typ matches 5 run function compagnons:c/cap_5
execute if score @s cp.typ matches 6 run function compagnons:c/cap_6
