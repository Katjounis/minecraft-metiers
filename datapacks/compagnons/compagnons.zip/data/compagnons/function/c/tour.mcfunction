execute store result score @s cp.hp run data get entity @s Health
execute store result score @s cp.hpm run attribute @s minecraft:max_health get
scoreboard players operation @a[tag=cp.moi] cp.hp = @s cp.hp
scoreboard players operation @a[tag=cp.moi] cp.hpm = @s cp.hpm
scoreboard players operation #q cp.t = @s cp.hp
scoreboard players operation #q cp.t *= #5 cp.t
execute if score #q cp.t <= @s cp.hpm run return run function compagnons:c/ko
scoreboard players set #monte cp.t 0
execute on passengers if entity @s[tag=cp.moi] run scoreboard players set #monte cp.t 1
execute if entity @s[tag=cp.vol] if score #monte cp.t matches 0 on passengers if entity @s[type=minecraft:player,tag=!cp.moi] run ride @s dismount
execute if entity @s[tag=cp.vol] if score #monte cp.t matches 0 as @a[tag=cp.moi,scores={cp.mt=1}] run effect give @s minecraft:slow_falling 8 0 true
scoreboard players operation @a[tag=cp.moi] cp.mt = #monte cp.t
execute if score #monte cp.t matches 0 if entity @a[tag=cp.moi,scores={cp.mode=0}] unless entity @a[tag=cp.moi,distance=..24] run function compagnons:c/rejoindre
execute if score #monte cp.t matches 0 if entity @s[tag=cp.lent,tag=!cp.vol] if entity @a[tag=cp.moi,scores={cp.mode=0}] unless entity @a[tag=cp.moi,distance=..16] run function compagnons:c/rejoindre
execute if score #monte cp.t matches 0 if entity @s[tag=cp.vol] if entity @a[tag=cp.moi,scores={cp.mode=0}] unless entity @a[tag=cp.moi,distance=..14] run function compagnons:c/rejoindre
execute if score @s cp.typ matches 8 if entity @a[tag=cp.moi,limit=1] as @a[tag=cp.moi] at @s if dimension minecraft:the_end run return run function compagnons:ranger_end
execute if score @s cp.typ matches 1 run function compagnons:c/niv_1
execute if score @s cp.typ matches 1 run function compagnons:c/cap_1
execute if score @s cp.typ matches 2 run function compagnons:c/niv_2
execute if score @s cp.typ matches 2 run function compagnons:c/cap_2
execute if score @s cp.typ matches 3 run function compagnons:c/niv_3
execute if score @s cp.typ matches 3 run function compagnons:c/cap_3
execute if score @s cp.typ matches 4 run function compagnons:c/niv_4
execute if score @s cp.typ matches 4 run function compagnons:c/cap_4
execute if score @s cp.typ matches 5 run function compagnons:c/niv_5
execute if score @s cp.typ matches 5 run function compagnons:c/cap_5
execute if score @s cp.typ matches 6 run function compagnons:c/niv_6
execute if score @s cp.typ matches 6 run function compagnons:c/cap_6
execute if score @s cp.typ matches 7 run function compagnons:c/niv_7
execute if score @s cp.typ matches 7 run function compagnons:c/cap_7
execute if score @s cp.typ matches 8 run function compagnons:c/niv_8
execute if score @s cp.typ matches 8 run function compagnons:c/cap_8
execute if score @s cp.typ matches 9 run function compagnons:c/niv_9
execute if score @s cp.typ matches 9 run function compagnons:c/cap_9
