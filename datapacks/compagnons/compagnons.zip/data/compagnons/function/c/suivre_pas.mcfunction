execute on passengers if entity @s[type=minecraft:player] run return 0
tag @s add cp.ici
execute as @a[tag=cp.guide,limit=1] at @s rotated ~ 0 positioned ^ ^ ^2.5 if entity @e[tag=cp.ici,distance=..2.6] run tag @e[tag=cp.ici] add cp.devant
tag @s remove cp.ici
execute if entity @s[tag=!cp.devant] if entity @a[tag=cp.guide,distance=..6] unless entity @a[tag=cp.guide,distance=..2.5] run return 0
tag @s remove cp.devant
execute if entity @e[type=#compagnons:hostiles,distance=..8] if entity @a[tag=cp.guide,distance=..14] run return 0
execute if entity @s[tag=!cp.vol,type=!minecraft:allay] as @a[tag=cp.guide,limit=1] at @s rotated ~ 0 run summon minecraft:marker ^ ^ ^-3.5 {Tags:["cp.cible"]}
execute if entity @s[tag=cp.vol] as @a[tag=cp.guide,limit=1] at @s rotated ~ 0 run summon minecraft:marker ^ ^2 ^-5 {Tags:["cp.cible"]}
execute if entity @s[type=minecraft:allay] as @a[tag=cp.guide,limit=1] at @s rotated ~ 0 run summon minecraft:marker ^ ^1.5 ^-3 {Tags:["cp.cible"]}
execute facing entity @e[type=minecraft:marker,tag=cp.cible,limit=1] feet positioned 0.0 0.0 0.0 run summon minecraft:marker ^ ^ ^0.3 {Tags:["cp.vec"]}
data modify entity @s Motion[0] set from entity @e[type=minecraft:marker,tag=cp.vec,limit=1] Pos[0]
data modify entity @s Motion[2] set from entity @e[type=minecraft:marker,tag=cp.vec,limit=1] Pos[2]
execute if entity @s[tag=cp.vol] run data modify entity @s Motion[1] set from entity @e[type=minecraft:marker,tag=cp.vec,limit=1] Pos[1]
execute if entity @s[type=minecraft:allay] run data modify entity @s Motion[1] set from entity @e[type=minecraft:marker,tag=cp.vec,limit=1] Pos[1]
execute if entity @s[tag=!cp.vol,type=!minecraft:allay] unless block ~ ~-0.2 ~ #minecraft:replaceable facing entity @e[type=minecraft:marker,tag=cp.cible,limit=1] feet rotated ~ 0 unless block ^ ^0.3 ^0.9 #minecraft:replaceable if block ^ ^1.3 ^0.9 #minecraft:replaceable if block ^ ^2.3 ^0.9 #minecraft:replaceable run data modify entity @s Motion[1] set value 0.42d
rotate @s facing entity @e[type=minecraft:marker,tag=cp.cible,limit=1] feet
kill @e[type=minecraft:marker,tag=cp.cible]
kill @e[type=minecraft:marker,tag=cp.vec]
