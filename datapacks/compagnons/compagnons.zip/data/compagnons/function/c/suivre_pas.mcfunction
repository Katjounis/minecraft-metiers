execute on passengers if entity @s[type=minecraft:player] run return 0
execute if entity @e[type=#compagnons:hostiles,distance=..8] if entity @a[tag=cp.guide,distance=..14] run return 0
execute unless entity @a[tag=cp.guide,distance=..5] run tag @s add cp.marche
execute if entity @a[tag=cp.guide,distance=..3] run tag @s remove cp.marche
execute if entity @s[tag=!cp.marche] run return run scoreboard players set @s cp.att 0
scoreboard players add @s cp.att 1
execute if score @s cp.att matches 100.. run return run function compagnons:c/rejoindre_pieds
execute if entity @s[tag=!cp.vol,type=!minecraft:allay] facing entity @a[tag=cp.guide,limit=1] feet rotated ~ 0 positioned 0.0 0.0 0.0 run summon minecraft:marker ^ ^ ^0.12 {Tags:["cp.vec"]}
execute if entity @s[tag=cp.vol] positioned as @a[tag=cp.guide,limit=1] positioned ~ ~2 ~ run summon minecraft:marker ~ ~ ~ {Tags:["cp.cible"]}
execute if entity @s[type=minecraft:allay] positioned as @a[tag=cp.guide,limit=1] positioned ~ ~1.5 ~ run summon minecraft:marker ~ ~ ~ {Tags:["cp.cible"]}
execute if entity @e[type=minecraft:marker,tag=cp.cible,distance=..30] facing entity @e[type=minecraft:marker,tag=cp.cible,limit=1] feet positioned 0.0 0.0 0.0 run summon minecraft:marker ^ ^ ^0.15 {Tags:["cp.vec"]}
data modify entity @s Motion[0] set from entity @e[type=minecraft:marker,tag=cp.vec,limit=1] Pos[0]
data modify entity @s Motion[2] set from entity @e[type=minecraft:marker,tag=cp.vec,limit=1] Pos[2]
execute if entity @s[tag=cp.vol] run data modify entity @s Motion[1] set from entity @e[type=minecraft:marker,tag=cp.vec,limit=1] Pos[1]
execute if entity @s[type=minecraft:allay] run data modify entity @s Motion[1] set from entity @e[type=minecraft:marker,tag=cp.vec,limit=1] Pos[1]
execute if entity @s[tag=!cp.vol,type=!minecraft:allay] unless block ~ ~-0.2 ~ #minecraft:replaceable facing entity @a[tag=cp.guide,limit=1] feet rotated ~ 0 unless block ^ ^0.3 ^0.9 #minecraft:replaceable if block ^ ^1.3 ^0.9 #minecraft:replaceable if block ^ ^2.3 ^0.9 #minecraft:replaceable run data modify entity @s Motion[1] set value 0.42d
rotate @s facing entity @a[tag=cp.guide,limit=1] feet
kill @e[type=minecraft:marker,tag=cp.cible]
kill @e[type=minecraft:marker,tag=cp.vec]
