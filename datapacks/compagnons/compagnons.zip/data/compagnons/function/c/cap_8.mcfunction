scoreboard players set #3 cp.t 3
scoreboard players operation #m cp.t = #s cp.tk
scoreboard players operation #m cp.t %= #3 cp.t
execute if score #L cp.t matches 5..29 if score #m cp.t matches 0 rotated as @s positioned ^ ^ ^5 if entity @e[type=#compagnons:hostiles,distance=..5] run function compagnons:c/souffle {r:5,d:6}
execute if score #L cp.t matches 30.. if score #m cp.t matches 0 rotated as @s positioned ^ ^ ^6 if entity @e[type=#compagnons:hostiles,distance=..8] run function compagnons:c/souffle {r:8,d:12}
execute if score #L cp.t matches 10.. if score #monte cp.t matches 1 run effect give @a[tag=cp.moi] minecraft:resistance 2 0 true
attribute @s minecraft:flying_speed modifier remove compagnons:envergure
execute if score #L cp.t matches 20.. run attribute @s minecraft:flying_speed modifier add compagnons:envergure 0.3 add_multiplied_base
