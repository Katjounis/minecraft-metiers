tag @s add cp.chasseur
execute as @e[type=#compagnons:chasse,distance=..12,sort=nearest,limit=1] run damage @s 1 minecraft:mob_attack by @e[tag=cp.chasseur,limit=1]
tag @s remove cp.chasseur
