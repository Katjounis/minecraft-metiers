execute if score #L cp.t matches 5.. if score #monte cp.t matches 1 run effect give @a[tag=cp.moi] minecraft:resistance 2 0 true
attribute @s minecraft:flying_speed modifier remove compagnons:rafale
execute if score #L cp.t matches 10.. run attribute @s minecraft:flying_speed modifier add compagnons:rafale 0.25 add_multiplied_base
execute if score #L cp.t matches 20.. if score #monte cp.t matches 1 run effect give @a[tag=cp.moi] minecraft:night_vision 15 0 true
execute if score #L cp.t matches 30.. if score #monte cp.t matches 1 run effect give @a[tag=cp.moi] minecraft:regeneration 2 0 true
execute if score #L cp.t matches 30.. if score #monte cp.t matches 1 run effect give @a[tag=cp.moi] minecraft:fire_resistance 2 0 true
