tag @s add cp.frappeur
particle minecraft:explosion ~ ~ ~ 2 0.2 2 0 6
playsound minecraft:entity.iron_golem.attack neutral @a[distance=..16] ~ ~ ~ 1.5 0.6
execute as @e[type=#compagnons:hostiles,distance=..4] run damage @s 4 minecraft:mob_attack by @e[tag=cp.frappeur,limit=1]
effect give @e[type=#compagnons:hostiles,distance=..4] minecraft:levitation 1 2 true
tag @s remove cp.frappeur
