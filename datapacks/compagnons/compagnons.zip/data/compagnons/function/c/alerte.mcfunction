title @s actionbar {"text":"Creeper tout près !","color":"green","bold":true}
playsound minecraft:entity.parrot.imitate.creeper neutral @s ~ ~ ~ 1 1
