scoreboard players operation #o cp.t = @s cp.own
execute as @a if score @s cp.id = #o cp.t run tag @s add cp.guide
execute if entity @a[tag=cp.guide,scores={cp.mode=0},distance=..24] run function compagnons:c/suivre_pas
tag @a remove cp.guide
