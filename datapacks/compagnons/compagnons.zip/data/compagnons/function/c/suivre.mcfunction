scoreboard players operation #o cp.t = @s cp.own
execute as @a if score @s cp.id = #o cp.t run tag @s add cp.guide
execute if entity @s[tag=!cp.lent,tag=!cp.vol] run return run tag @a remove cp.guide
execute if entity @a[tag=cp.guide,scores={cp.mode=0}] run function compagnons:c/suivre_pas
tag @a remove cp.guide
