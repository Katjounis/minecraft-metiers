tag @s add cp.souffleur
$particle minecraft:dragon_breath ~ ~1 ~ $(r) 1 $(r) 0.02 150
playsound minecraft:entity.ender_dragon.shoot neutral @a[distance=..32] ~ ~ ~ 1.5 1
$execute as @e[type=#compagnons:hostiles,distance=..$(r)] run damage @s $(d) minecraft:dragon_breath by @e[tag=cp.souffleur,limit=1]
tag @s remove cp.souffleur
