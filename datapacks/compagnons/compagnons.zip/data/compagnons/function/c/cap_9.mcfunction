scoreboard players set #3 cp.t 3
scoreboard players operation #m cp.t = #s cp.tk
scoreboard players operation #m cp.t %= #3 cp.t
execute if score #L cp.t matches 5.. if score #m cp.t matches 0 if entity @e[type=#compagnons:hostiles,distance=..16] run function compagnons:c/crane
execute if score #L cp.t matches 10.. if score #monte cp.t matches 1 run effect give @a[tag=cp.moi] minecraft:resistance 2 0 true
execute if score #L cp.t matches 20.. run effect give @e[type=#compagnons:hostiles,distance=..6] minecraft:wither 3 0
scoreboard players set #20 cp.t 20
scoreboard players operation #m cp.t = #s cp.tk
scoreboard players operation #m cp.t %= #20 cp.t
execute if score #L cp.t matches 30.. if score #m cp.t matches 0 if entity @e[type=#compagnons:hostiles,distance=..6] run function compagnons:c/onde
