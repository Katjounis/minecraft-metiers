scoreboard players operation #L cp.t = @a[tag=cp.moi,limit=1] cp.l8
scoreboard players operation #mm cp.t = @a[tag=cp.moi,limit=1] cp.m8
scoreboard players operation #mm cp.t *= #2 cp.t
scoreboard players operation #L cp.t += #mm cp.t
