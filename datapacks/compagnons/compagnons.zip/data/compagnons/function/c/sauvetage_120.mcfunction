execute if score @s cp.cda matches 1.. run return 0
scoreboard players set @s cp.cda 120
effect give @s minecraft:absorption 10 1 true
effect give @s minecraft:regeneration 5 1 true
particle minecraft:heart ~ ~1.5 ~ 0.4 0.4 0.4 0 8
playsound minecraft:item.totem.use neutral @s ~ ~ ~ 0.4 1.6
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton compagnon te sauve la mise !","color":"light_purple"}]
