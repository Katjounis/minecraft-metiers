scoreboard players operation #o cp.t = @s cp.own
scoreboard players operation #s cp.t = @s cp.ser
scoreboard players set #ok cp.t 0
execute as @e[tag=cp.porteur] if score @s cp.own = #o cp.t if score @s cp.ser = #s cp.t run scoreboard players set #ok cp.t 1
execute if score #ok cp.t matches 0 run tp @s ~ -1000 ~
execute if score #ok cp.t matches 0 run kill @s
