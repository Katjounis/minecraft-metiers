scoreboard players operation #L cp.t = @a[tag=cp.moi,limit=1] cp.l4
effect give @s minecraft:fire_resistance 3 0 true
execute if score #L cp.t matches 5.. run effect give @e[type=#compagnons:hostiles,distance=..6] minecraft:slowness 2 0 true
execute if score #L cp.t matches 10.. run effect give @s minecraft:regeneration 2 1 true
scoreboard players operation #m cp.t = #s cp.tk
scoreboard players operation #m cp.t %= #10 cp.t
execute if score #L cp.t matches 20..29 if score #m cp.t matches 0 run function compagnons:c/blizzard {r:8,d:3}
scoreboard players operation #m cp.t = #s cp.tk
scoreboard players set #5 cp.t 5
scoreboard players operation #m cp.t %= #5 cp.t
execute if score #L cp.t matches 30.. if score #m cp.t matches 0 run function compagnons:c/blizzard {r:12,d:5}
