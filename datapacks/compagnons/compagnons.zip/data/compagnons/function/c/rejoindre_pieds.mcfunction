particle minecraft:poof ~ ~0.5 ~ 0.3 0.4 0.3 0.02 8
tp @s @a[tag=cp.guide,limit=1]
scoreboard players set @s cp.att 0
tag @s remove cp.marche
execute at @s run particle minecraft:poof ~ ~0.5 ~ 0.3 0.4 0.3 0.02 8
