advancement revoke @s only compagnons:frappe
tag @s add cp.frappeur_j
execute as @e[type=!minecraft:player,tag=!cp.c,tag=!cp.vis,distance=..8,nbt={HurtTime:10s}] run function compagnons:c/frappe_victime
scoreboard players operation #o cp.t = @s cp.id
execute if entity @e[tag=cp.proie] as @e[tag=cp.c,type=#compagnons:combattants] if score @s cp.own = #o cp.t run damage @s 0.01 minecraft:mob_attack by @e[tag=cp.proie,limit=1]
tag @e[tag=cp.proie] remove cp.proie
tag @s remove cp.frappeur_j
