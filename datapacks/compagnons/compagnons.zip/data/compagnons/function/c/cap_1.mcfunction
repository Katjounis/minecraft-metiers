scoreboard players operation #L cp.t = @a[tag=cp.moi,limit=1] cp.l1
execute if score #L cp.t matches 5.. on target run effect give @s minecraft:slowness 2 1
execute if score #L cp.t matches 10.. run effect give @a[tag=cp.moi,distance=..16] minecraft:speed 2 0 true
execute if score #L cp.t matches 20.. on target run effect give @s minecraft:wither 3 0
execute if score #L cp.t matches 30.. as @a[tag=cp.moi,limit=1] if predicate compagnons:faible run function compagnons:c/loup_alpha
scoreboard players set #cible cp.t 0
execute if entity @a[tag=cp.moi,scores={cp.ag=1}] store success score #cible cp.t on target if entity @s
execute if entity @a[tag=cp.moi,scores={cp.ag=1}] unless score #cible cp.t matches 1 if score #s cp.tk matches 0.. run function compagnons:c/loup_chasse
