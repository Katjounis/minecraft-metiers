scoreboard players operation #o cp.t = @s cp.own
scoreboard players operation #s cp.t = @s cp.ser
scoreboard players operation #y cp.t = @s cp.typ
scoreboard players set #ok cp.t 0
execute as @a if score @s cp.id = #o cp.t if score @s cp.ser = #s cp.t if score @s cp.out = #y cp.t run scoreboard players set #ok cp.t 1
execute if score #ok cp.t matches 0 at @s run particle minecraft:poof ~ ~0.5 ~ 0.3 0.4 0.3 0.02 10
execute if score #ok cp.t matches 0 run tp @s ~ -1000 ~
execute if score #ok cp.t matches 0 run kill @s
