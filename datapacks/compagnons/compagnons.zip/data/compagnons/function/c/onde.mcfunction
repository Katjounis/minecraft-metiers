tag @s add cp.tireur
particle minecraft:explosion_emitter ~ ~1 ~ 0 0 0 0 1
playsound minecraft:entity.generic.explode neutral @a[distance=..32] ~ ~ ~ 1.5 0.8
execute as @e[type=#compagnons:hostiles,distance=..6] run damage @s 14 minecraft:explosion by @e[tag=cp.tireur,limit=1]
tag @s remove cp.tireur
