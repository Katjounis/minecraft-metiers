tag @s add cp.givreur
$particle minecraft:snowflake ~ ~1 ~ $(r) 1 $(r) 0.02 120
playsound minecraft:block.powder_snow.break neutral @a[distance=..24] ~ ~ ~ 1.5 0.6
$effect give @e[type=#compagnons:hostiles,distance=..$(r)] minecraft:slowness 4 2 true
$execute as @e[type=#compagnons:hostiles,distance=..$(r)] run damage @s $(d) minecraft:freeze by @e[tag=cp.givreur,limit=1]
tag @s remove cp.givreur
