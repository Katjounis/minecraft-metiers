particle minecraft:cloud ~ ~0.6 ~ 0.3 0.4 0.3 0.05 20
playsound minecraft:entity.player.hurt_sweet_berry_bush neutral @a[distance=..16] ~ ~ ~ 0.8 0.7
scoreboard players set @a[tag=cp.moi] cp.cd 60
scoreboard players set @a[tag=cp.moi] cp.hp 99999
execute as @a[tag=cp.moi] run tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Ton compagnon est K.O. Il se repose et revient dans 60 secondes.","color":"red"}]
tp @s ~ -1000 ~
kill @s
