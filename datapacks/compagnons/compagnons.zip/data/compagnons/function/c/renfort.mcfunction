scoreboard players remove @s cp.vie 1
execute if score @s cp.vie matches ..0 at @s run particle minecraft:poof ~ ~0.5 ~ 0.3 0.4 0.3 0.02 10
execute if score @s cp.vie matches ..0 run tp @s ~ -1000 ~
execute if score @s cp.vie matches ..0 run kill @s
