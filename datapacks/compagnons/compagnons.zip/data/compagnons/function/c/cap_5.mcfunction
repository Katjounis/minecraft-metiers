execute if score #L cp.t matches 5.. at @a[tag=cp.moi,limit=1] run tp @e[type=minecraft:item,distance=1.5..10] @a[tag=cp.moi,limit=1]
scoreboard players operation #m cp.t = #s cp.tk
scoreboard players operation #m cp.t %= #10 cp.t
execute if score #L cp.t matches 10.. if score #m cp.t matches 0 run effect give @a[tag=cp.moi,distance=..12] minecraft:regeneration 4 0 true
execute if score #L cp.t matches 20.. run effect give @a[tag=cp.moi] minecraft:luck 3 0 true
execute if score #L cp.t matches 30.. as @a[tag=cp.moi,limit=1] if predicate compagnons:tres_faible run function compagnons:c/sauvetage_300
