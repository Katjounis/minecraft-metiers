scoreboard players operation #L cp.t = @a[tag=cp.moi,limit=1] cp.l6
execute if score #L cp.t matches 5.. run effect give @a[tag=cp.moi,distance=..10] minecraft:resistance 2 0 true
scoreboard players set #8 cp.t 8
scoreboard players operation #m cp.t = #s cp.tk
scoreboard players operation #m cp.t %= #8 cp.t
execute if score #L cp.t matches 10.. if score #m cp.t matches 0 if entity @e[type=#compagnons:hostiles,distance=..4] run function compagnons:c/seisme
execute if score #L cp.t matches 20.. run effect give @s minecraft:resistance 2 1 true
scoreboard players set #60 cp.t 60
scoreboard players operation #m cp.t = #s cp.tk
scoreboard players operation #m cp.t %= #60 cp.t
execute if score #L cp.t matches 30.. if score #m cp.t matches 0 run effect give @a[tag=cp.moi,distance=..16] minecraft:absorption 60 1 true
