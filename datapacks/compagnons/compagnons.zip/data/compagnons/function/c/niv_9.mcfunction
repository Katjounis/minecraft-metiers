scoreboard players operation #L cp.t = @a[tag=cp.moi,limit=1] cp.l9
scoreboard players operation #mm cp.t = @a[tag=cp.moi,limit=1] cp.m9
scoreboard players operation #mm cp.t *= #2 cp.t
scoreboard players operation #L cp.t += #mm cp.t
