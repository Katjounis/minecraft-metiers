scoreboard players add #next cp.t 1
scoreboard players operation @s cp.id = #next cp.t
execute store result storage compagnons:t id int 1 run scoreboard players get @s cp.id
function compagnons:noms/creer with storage compagnons:t
