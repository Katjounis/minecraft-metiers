scoreboard players set @s cp.l1 1
scoreboard players set @s cp.l2 1
scoreboard players set @s cp.l3 1
scoreboard players set @s cp.l4 1
scoreboard players set @s cp.l5 1
scoreboard players set @s cp.l6 1
scoreboard players set @s cp.x1 0
scoreboard players set @s cp.x2 0
scoreboard players set @s cp.x3 0
scoreboard players set @s cp.x4 0
scoreboard players set @s cp.x5 0
scoreboard players set @s cp.x6 0
execute if score @s cp.out matches 1.. run function compagnons:invoquer/maj
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Tous tes compagnons repassent niveau 1.","color":"gray"}]
