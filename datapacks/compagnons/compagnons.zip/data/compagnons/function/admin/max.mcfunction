scoreboard players set @s cp.l1 30
scoreboard players set @s cp.l2 30
scoreboard players set @s cp.l3 30
scoreboard players set @s cp.l4 30
scoreboard players set @s cp.l5 30
scoreboard players set @s cp.l6 30
scoreboard players set @s cp.x1 0
scoreboard players set @s cp.x2 0
scoreboard players set @s cp.x3 0
scoreboard players set @s cp.x4 0
scoreboard players set @s cp.x5 0
scoreboard players set @s cp.x6 0
execute if score @s cp.out matches 1.. run function compagnons:invoquer/maj
tellraw @s [{"text":"[Compagnons] ","color":"#E0A040"},{"text":"Tous tes compagnons passent niveau 30 (test).","color":"gold"}]
