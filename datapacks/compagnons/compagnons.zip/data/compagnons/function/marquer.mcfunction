tag @e[tag=cp.cur] remove cp.cur
scoreboard players operation #o cp.t = @s cp.id
scoreboard players operation #s cp.t = @s cp.ser
execute as @e[tag=cp.c] if score @s cp.own = #o cp.t if score @s cp.ser = #s cp.t run tag @s add cp.cur
