attribute @s minecraft:max_health base set 36
attribute @s minecraft:armor base set 3
attribute @s minecraft:movement_speed base set 0.248
attribute @s minecraft:scale base set 1.160
data modify entity @s Health set value 36f
