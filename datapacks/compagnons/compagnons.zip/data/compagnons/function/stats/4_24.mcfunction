attribute @s minecraft:max_health base set 52
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.272
attribute @s minecraft:scale base set 1.240
data modify entity @s Health set value 52f
