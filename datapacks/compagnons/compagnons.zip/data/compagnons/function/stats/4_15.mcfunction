attribute @s minecraft:max_health base set 34
attribute @s minecraft:armor base set 3
attribute @s minecraft:movement_speed base set 0.245
attribute @s minecraft:scale base set 1.150
data modify entity @s Health set value 34f
