attribute @s minecraft:max_health base set 68
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.200
attribute @s minecraft:scale base set 0.550
data modify entity @s Health set value 68f
attribute @s minecraft:flying_speed base set 0.0840
