attribute @s minecraft:max_health base set 50
attribute @s minecraft:armor base set 5
attribute @s minecraft:movement_speed base set 0.160
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 50f
attribute @s minecraft:flying_speed base set 0.190
