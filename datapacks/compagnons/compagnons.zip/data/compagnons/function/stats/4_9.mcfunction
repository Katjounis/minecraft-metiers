attribute @s minecraft:max_health base set 22
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.227
attribute @s minecraft:scale base set 1.090
data modify entity @s Health set value 22f
