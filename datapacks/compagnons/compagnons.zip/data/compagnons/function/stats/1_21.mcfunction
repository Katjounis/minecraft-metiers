attribute @s minecraft:max_health base set 62
attribute @s minecraft:attack_damage base set 9.25
attribute @s minecraft:armor base set 8
attribute @s minecraft:movement_speed base set 0.342
attribute @s minecraft:scale base set 1.147
data modify entity @s Health set value 62f
