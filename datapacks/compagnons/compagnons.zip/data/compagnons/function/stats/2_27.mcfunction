attribute @s minecraft:max_health base set 37
attribute @s minecraft:attack_damage base set 5.70
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.354
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 37f
