attribute @s minecraft:max_health base set 70
attribute @s minecraft:attack_damage base set 10.25
attribute @s minecraft:armor base set 10
attribute @s minecraft:movement_speed base set 0.350
attribute @s minecraft:scale base set 1.175
data modify entity @s Health set value 70f
