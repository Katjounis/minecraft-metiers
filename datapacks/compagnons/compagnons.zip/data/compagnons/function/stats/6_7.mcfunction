attribute @s minecraft:max_health base set 88
attribute @s minecraft:attack_damage base set 13.50
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.264
attribute @s minecraft:scale base set 0.655
data modify entity @s Health set value 88f
