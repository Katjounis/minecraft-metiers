attribute @s minecraft:max_health base set 34
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.256
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 34f
