attribute @s minecraft:max_health base set 46
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.152
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 46f
attribute @s minecraft:flying_speed base set 0.1780
