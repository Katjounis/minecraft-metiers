attribute @s minecraft:max_health base set 160
attribute @s minecraft:attack_damage base set 22.50
attribute @s minecraft:armor base set 8
attribute @s minecraft:movement_speed base set 0.300
attribute @s minecraft:scale base set 0.925
data modify entity @s Health set value 160f
