attribute @s minecraft:max_health base set 17
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.222
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 17f
