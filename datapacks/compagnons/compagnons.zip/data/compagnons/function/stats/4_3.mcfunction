attribute @s minecraft:max_health base set 10
attribute @s minecraft:armor base set 0
attribute @s minecraft:movement_speed base set 0.209
attribute @s minecraft:scale base set 1.030
data modify entity @s Health set value 10f
