attribute @s minecraft:max_health base set 172
attribute @s minecraft:attack_damage base set 24.00
attribute @s minecraft:armor base set 9
attribute @s minecraft:movement_speed base set 0.306
attribute @s minecraft:scale base set 0.970
data modify entity @s Health set value 172f
