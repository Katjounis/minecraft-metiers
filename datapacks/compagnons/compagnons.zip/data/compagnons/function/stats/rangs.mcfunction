attribute @s minecraft:max_health modifier remove compagnons:robustesse
attribute @s minecraft:attack_damage modifier remove compagnons:puissance
attribute @s minecraft:movement_speed modifier remove compagnons:puissance
attribute @s minecraft:flying_speed modifier remove compagnons:puissance
execute if score #R cp.t matches 1 run attribute @s minecraft:max_health modifier add compagnons:robustesse 0.10 add_multiplied_base
execute if score #P cp.t matches 1 run attribute @s minecraft:attack_damage modifier add compagnons:puissance 0.15 add_multiplied_base
execute if score #P cp.t matches 1 run attribute @s minecraft:movement_speed modifier add compagnons:puissance 0.05 add_multiplied_base
execute if score #P cp.t matches 1 run attribute @s minecraft:flying_speed modifier add compagnons:puissance 0.10 add_multiplied_base
execute if score #R cp.t matches 2 run attribute @s minecraft:max_health modifier add compagnons:robustesse 0.20 add_multiplied_base
execute if score #P cp.t matches 2 run attribute @s minecraft:attack_damage modifier add compagnons:puissance 0.30 add_multiplied_base
execute if score #P cp.t matches 2 run attribute @s minecraft:movement_speed modifier add compagnons:puissance 0.10 add_multiplied_base
execute if score #P cp.t matches 2 run attribute @s minecraft:flying_speed modifier add compagnons:puissance 0.20 add_multiplied_base
execute if score #R cp.t matches 3 run attribute @s minecraft:max_health modifier add compagnons:robustesse 0.30 add_multiplied_base
execute if score #P cp.t matches 3 run attribute @s minecraft:attack_damage modifier add compagnons:puissance 0.45 add_multiplied_base
execute if score #P cp.t matches 3 run attribute @s minecraft:movement_speed modifier add compagnons:puissance 0.15 add_multiplied_base
execute if score #P cp.t matches 3 run attribute @s minecraft:flying_speed modifier add compagnons:puissance 0.30 add_multiplied_base
execute if score #R cp.t matches 4 run attribute @s minecraft:max_health modifier add compagnons:robustesse 0.40 add_multiplied_base
execute if score #P cp.t matches 4 run attribute @s minecraft:attack_damage modifier add compagnons:puissance 0.60 add_multiplied_base
execute if score #P cp.t matches 4 run attribute @s minecraft:movement_speed modifier add compagnons:puissance 0.20 add_multiplied_base
execute if score #P cp.t matches 4 run attribute @s minecraft:flying_speed modifier add compagnons:puissance 0.40 add_multiplied_base
execute if score #R cp.t matches 5 run attribute @s minecraft:max_health modifier add compagnons:robustesse 0.50 add_multiplied_base
execute if score #P cp.t matches 5 run attribute @s minecraft:attack_damage modifier add compagnons:puissance 0.75 add_multiplied_base
execute if score #P cp.t matches 5 run attribute @s minecraft:movement_speed modifier add compagnons:puissance 0.25 add_multiplied_base
execute if score #P cp.t matches 5 run attribute @s minecraft:flying_speed modifier add compagnons:puissance 0.50 add_multiplied_base
execute store result entity @s Health float 1 run attribute @s minecraft:max_health get
