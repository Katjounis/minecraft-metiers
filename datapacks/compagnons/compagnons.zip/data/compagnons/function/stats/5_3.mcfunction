attribute @s minecraft:max_health base set 23
attribute @s minecraft:armor base set 0
attribute @s minecraft:movement_speed base set 0.106
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 23f
attribute @s minecraft:flying_speed base set 0.1090
