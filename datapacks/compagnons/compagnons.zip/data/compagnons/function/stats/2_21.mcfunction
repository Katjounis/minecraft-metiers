attribute @s minecraft:max_health base set 31
attribute @s minecraft:attack_damage base set 5.10
attribute @s minecraft:armor base set 3
attribute @s minecraft:movement_speed base set 0.342
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 31f
