attribute @s minecraft:max_health base set 128
attribute @s minecraft:attack_damage base set 18.50
attribute @s minecraft:armor base set 5
attribute @s minecraft:movement_speed base set 0.284
attribute @s minecraft:scale base set 0.805
data modify entity @s Health set value 128f
