attribute @s minecraft:max_health base set 50
attribute @s minecraft:attack_damage base set 7.75
attribute @s minecraft:armor base set 6
attribute @s minecraft:movement_speed base set 0.330
attribute @s minecraft:scale base set 1.105
data modify entity @s Health set value 50f
