attribute @s minecraft:max_health base set 22
attribute @s minecraft:attack_damage base set 4.20
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.324
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 22f
