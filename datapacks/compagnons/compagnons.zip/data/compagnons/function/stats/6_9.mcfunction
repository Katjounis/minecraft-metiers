attribute @s minecraft:max_health base set 96
attribute @s minecraft:attack_damage base set 14.50
attribute @s minecraft:armor base set 3
attribute @s minecraft:movement_speed base set 0.268
attribute @s minecraft:scale base set 0.685
data modify entity @s Health set value 96f
