attribute @s minecraft:max_health base set 152
attribute @s minecraft:attack_damage base set 21.50
attribute @s minecraft:armor base set 7
attribute @s minecraft:movement_speed base set 0.296
attribute @s minecraft:scale base set 0.895
data modify entity @s Health set value 152f
