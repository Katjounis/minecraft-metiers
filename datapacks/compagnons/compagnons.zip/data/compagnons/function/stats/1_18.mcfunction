attribute @s minecraft:max_health base set 56
attribute @s minecraft:attack_damage base set 8.50
attribute @s minecraft:armor base set 6
attribute @s minecraft:movement_speed base set 0.336
attribute @s minecraft:scale base set 1.126
data modify entity @s Health set value 56f
