attribute @s minecraft:max_health base set 40
attribute @s minecraft:armor base set 3
attribute @s minecraft:movement_speed base set 0.254
attribute @s minecraft:scale base set 1.180
data modify entity @s Health set value 40f
