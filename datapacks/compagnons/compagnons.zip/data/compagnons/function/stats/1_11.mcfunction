attribute @s minecraft:max_health base set 42
attribute @s minecraft:attack_damage base set 6.75
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.322
attribute @s minecraft:scale base set 1.077
data modify entity @s Health set value 42f
