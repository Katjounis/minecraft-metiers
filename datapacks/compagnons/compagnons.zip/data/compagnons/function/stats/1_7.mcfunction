attribute @s minecraft:max_health base set 34
attribute @s minecraft:attack_damage base set 5.75
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.314
attribute @s minecraft:scale base set 1.049
data modify entity @s Health set value 34f
