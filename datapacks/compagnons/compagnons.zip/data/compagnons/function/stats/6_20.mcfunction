attribute @s minecraft:max_health base set 140
attribute @s minecraft:attack_damage base set 20.00
attribute @s minecraft:armor base set 6
attribute @s minecraft:movement_speed base set 0.290
attribute @s minecraft:scale base set 0.850
data modify entity @s Health set value 140f
