attribute @s minecraft:max_health base set 23
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.234
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 23f
