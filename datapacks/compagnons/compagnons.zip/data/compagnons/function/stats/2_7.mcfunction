attribute @s minecraft:max_health base set 17
attribute @s minecraft:attack_damage base set 3.70
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.314
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 17f
