attribute @s minecraft:max_health base set 160
attribute @s minecraft:armor base set 6
attribute @s minecraft:movement_speed base set 0.200
attribute @s minecraft:scale base set 0.550
data modify entity @s Health set value 160f
attribute @s minecraft:flying_speed base set 0.1050
