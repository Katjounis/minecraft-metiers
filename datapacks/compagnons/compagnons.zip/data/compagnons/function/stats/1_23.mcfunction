attribute @s minecraft:max_health base set 66
attribute @s minecraft:attack_damage base set 9.75
attribute @s minecraft:armor base set 8
attribute @s minecraft:movement_speed base set 0.346
attribute @s minecraft:scale base set 1.161
data modify entity @s Health set value 66f
