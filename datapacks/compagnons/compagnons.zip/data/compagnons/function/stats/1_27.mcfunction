attribute @s minecraft:max_health base set 74
attribute @s minecraft:attack_damage base set 10.75
attribute @s minecraft:armor base set 10
attribute @s minecraft:movement_speed base set 0.354
attribute @s minecraft:scale base set 1.189
data modify entity @s Health set value 74f
