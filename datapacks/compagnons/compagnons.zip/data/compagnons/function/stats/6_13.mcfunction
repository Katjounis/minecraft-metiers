attribute @s minecraft:max_health base set 112
attribute @s minecraft:attack_damage base set 16.50
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.276
attribute @s minecraft:scale base set 0.745
data modify entity @s Health set value 112f
