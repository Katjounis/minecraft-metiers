attribute @s minecraft:max_health base set 14
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.215
attribute @s minecraft:scale base set 1.050
data modify entity @s Health set value 14f
