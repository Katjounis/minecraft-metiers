attribute @s minecraft:max_health base set 29
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.118
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 29f
attribute @s minecraft:flying_speed base set 0.1270
