attribute @s minecraft:max_health base set 20
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.224
attribute @s minecraft:scale base set 1.080
data modify entity @s Health set value 20f
