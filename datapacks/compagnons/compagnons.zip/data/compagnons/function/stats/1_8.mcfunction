attribute @s minecraft:max_health base set 36
attribute @s minecraft:attack_damage base set 6.00
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.316
attribute @s minecraft:scale base set 1.056
data modify entity @s Health set value 36f
