attribute @s minecraft:max_health base set 16
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.220
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 16f
