attribute @s minecraft:max_health base set 38
attribute @s minecraft:armor base set 3
attribute @s minecraft:movement_speed base set 0.136
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 38f
attribute @s minecraft:flying_speed base set 0.154
