attribute @s minecraft:max_health base set 136
attribute @s minecraft:attack_damage base set 19.50
attribute @s minecraft:armor base set 6
attribute @s minecraft:movement_speed base set 0.288
attribute @s minecraft:scale base set 0.835
data modify entity @s Health set value 136f
