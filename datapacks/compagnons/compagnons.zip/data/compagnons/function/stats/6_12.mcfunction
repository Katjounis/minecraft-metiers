attribute @s minecraft:max_health base set 108
attribute @s minecraft:attack_damage base set 16.00
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.274
attribute @s minecraft:scale base set 0.730
data modify entity @s Health set value 108f
