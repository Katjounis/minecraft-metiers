attribute @s minecraft:max_health base set 68
attribute @s minecraft:attack_damage base set 10.00
attribute @s minecraft:armor base set 8
attribute @s minecraft:movement_speed base set 0.348
attribute @s minecraft:scale base set 1.168
data modify entity @s Health set value 68f
