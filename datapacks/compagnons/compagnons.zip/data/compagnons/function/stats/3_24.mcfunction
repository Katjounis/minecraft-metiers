attribute @s minecraft:max_health base set 30
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.248
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 30f
