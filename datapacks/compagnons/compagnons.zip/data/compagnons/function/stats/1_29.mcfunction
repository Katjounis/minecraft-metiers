attribute @s minecraft:max_health base set 78
attribute @s minecraft:attack_damage base set 11.25
attribute @s minecraft:armor base set 10
attribute @s minecraft:movement_speed base set 0.358
attribute @s minecraft:scale base set 1.203
data modify entity @s Health set value 78f
