attribute @s minecraft:max_health base set 80
attribute @s minecraft:attack_damage base set 12.50
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.260
attribute @s minecraft:scale base set 0.625
data modify entity @s Health set value 80f
