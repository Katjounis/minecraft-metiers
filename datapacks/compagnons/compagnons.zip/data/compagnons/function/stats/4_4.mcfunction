attribute @s minecraft:max_health base set 12
attribute @s minecraft:armor base set 0
attribute @s minecraft:movement_speed base set 0.212
attribute @s minecraft:scale base set 1.040
data modify entity @s Health set value 12f
