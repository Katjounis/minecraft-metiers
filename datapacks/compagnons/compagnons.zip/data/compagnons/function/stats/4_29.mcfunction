attribute @s minecraft:max_health base set 62
attribute @s minecraft:armor base set 5
attribute @s minecraft:movement_speed base set 0.287
attribute @s minecraft:scale base set 1.290
data modify entity @s Health set value 62f
