attribute @s minecraft:max_health base set 28
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.236
attribute @s minecraft:scale base set 1.120
data modify entity @s Health set value 28f
