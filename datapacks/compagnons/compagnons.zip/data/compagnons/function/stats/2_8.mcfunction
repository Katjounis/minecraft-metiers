attribute @s minecraft:max_health base set 18
attribute @s minecraft:attack_damage base set 3.80
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.316
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 18f
