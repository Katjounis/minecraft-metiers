attribute @s minecraft:max_health base set 124
attribute @s minecraft:attack_damage base set 18.00
attribute @s minecraft:armor base set 5
attribute @s minecraft:movement_speed base set 0.282
attribute @s minecraft:scale base set 0.790
data modify entity @s Health set value 124f
