attribute @s minecraft:max_health base set 24
attribute @s minecraft:attack_damage base set 4.40
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.328
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 24f
