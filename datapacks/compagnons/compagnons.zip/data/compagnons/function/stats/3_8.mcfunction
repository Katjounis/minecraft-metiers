attribute @s minecraft:max_health base set 14
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.216
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 14f
