attribute @s minecraft:max_health base set 28
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.116
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 28f
attribute @s minecraft:flying_speed base set 0.124
