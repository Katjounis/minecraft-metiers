attribute @s minecraft:max_health base set 32
attribute @s minecraft:attack_damage base set 5.50
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.312
attribute @s minecraft:scale base set 1.042
data modify entity @s Health set value 32f
