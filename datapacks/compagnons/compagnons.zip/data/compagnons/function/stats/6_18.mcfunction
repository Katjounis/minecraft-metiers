attribute @s minecraft:max_health base set 132
attribute @s minecraft:attack_damage base set 19.00
attribute @s minecraft:armor base set 6
attribute @s minecraft:movement_speed base set 0.286
attribute @s minecraft:scale base set 0.820
data modify entity @s Health set value 132f
