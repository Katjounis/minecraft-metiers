attribute @s minecraft:max_health base set 30
attribute @s minecraft:attack_damage base set 5.00
attribute @s minecraft:armor base set 3
attribute @s minecraft:movement_speed base set 0.340
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 30f
