attribute @s minecraft:max_health base set 40
attribute @s minecraft:attack_damage base set 6.50
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.320
attribute @s minecraft:scale base set 1.070
data modify entity @s Health set value 40f
