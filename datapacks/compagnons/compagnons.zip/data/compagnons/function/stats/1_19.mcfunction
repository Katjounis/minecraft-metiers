attribute @s minecraft:max_health base set 58
attribute @s minecraft:attack_damage base set 8.75
attribute @s minecraft:armor base set 6
attribute @s minecraft:movement_speed base set 0.338
attribute @s minecraft:scale base set 1.133
data modify entity @s Health set value 58f
