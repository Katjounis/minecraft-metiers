attribute @s minecraft:max_health base set 49
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.158
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 49f
attribute @s minecraft:flying_speed base set 0.1870
