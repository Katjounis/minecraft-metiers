attribute @s minecraft:max_health base set 180
attribute @s minecraft:attack_damage base set 25.00
attribute @s minecraft:armor base set 10
attribute @s minecraft:movement_speed base set 0.310
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 180f
