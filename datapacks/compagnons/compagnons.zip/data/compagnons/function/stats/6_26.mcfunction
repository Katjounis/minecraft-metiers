attribute @s minecraft:max_health base set 164
attribute @s minecraft:attack_damage base set 23.00
attribute @s minecraft:armor base set 8
attribute @s minecraft:movement_speed base set 0.302
attribute @s minecraft:scale base set 0.940
data modify entity @s Health set value 164f
