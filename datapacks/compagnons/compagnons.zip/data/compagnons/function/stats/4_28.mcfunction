attribute @s minecraft:max_health base set 60
attribute @s minecraft:armor base set 5
attribute @s minecraft:movement_speed base set 0.284
attribute @s minecraft:scale base set 1.280
data modify entity @s Health set value 60f
