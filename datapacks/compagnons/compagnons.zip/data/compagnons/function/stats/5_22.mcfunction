attribute @s minecraft:max_health base set 42
attribute @s minecraft:armor base set 3
attribute @s minecraft:movement_speed base set 0.144
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 42f
attribute @s minecraft:flying_speed base set 0.1660
