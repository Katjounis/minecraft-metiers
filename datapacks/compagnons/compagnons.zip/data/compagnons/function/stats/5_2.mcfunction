attribute @s minecraft:max_health base set 22
attribute @s minecraft:armor base set 0
attribute @s minecraft:movement_speed base set 0.104
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 22f
attribute @s minecraft:flying_speed base set 0.1060
