attribute @s minecraft:max_health base set 116
attribute @s minecraft:attack_damage base set 17.00
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.278
attribute @s minecraft:scale base set 0.760
data modify entity @s Health set value 116f
