attribute @s minecraft:max_health base set 44
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.260
attribute @s minecraft:scale base set 1.200
data modify entity @s Health set value 44f
