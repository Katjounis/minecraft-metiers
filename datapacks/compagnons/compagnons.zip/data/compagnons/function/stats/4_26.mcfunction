attribute @s minecraft:max_health base set 56
attribute @s minecraft:armor base set 5
attribute @s minecraft:movement_speed base set 0.278
attribute @s minecraft:scale base set 1.260
data modify entity @s Health set value 56f
