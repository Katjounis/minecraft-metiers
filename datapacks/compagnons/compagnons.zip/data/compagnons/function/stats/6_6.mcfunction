attribute @s minecraft:max_health base set 84
attribute @s minecraft:attack_damage base set 13.00
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.262
attribute @s minecraft:scale base set 0.640
data modify entity @s Health set value 84f
