attribute @s minecraft:max_health base set 30
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.239
attribute @s minecraft:scale base set 1.130
data modify entity @s Health set value 30f
