attribute @s minecraft:max_health base set 22
attribute @s minecraft:attack_damage base set 4.25
attribute @s minecraft:armor base set 0
attribute @s minecraft:movement_speed base set 0.302
attribute @s minecraft:scale base set 1.007
data modify entity @s Health set value 22f
