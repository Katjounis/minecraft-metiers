attribute @s minecraft:max_health base set 32
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.242
attribute @s minecraft:scale base set 1.140
data modify entity @s Health set value 32f
