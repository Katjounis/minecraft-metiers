attribute @s minecraft:max_health base set 52
attribute @s minecraft:attack_damage base set 8.00
attribute @s minecraft:armor base set 6
attribute @s minecraft:movement_speed base set 0.332
attribute @s minecraft:scale base set 1.112
data modify entity @s Health set value 52f
