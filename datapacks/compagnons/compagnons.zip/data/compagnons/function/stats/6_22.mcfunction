attribute @s minecraft:max_health base set 148
attribute @s minecraft:attack_damage base set 21.00
attribute @s minecraft:armor base set 7
attribute @s minecraft:movement_speed base set 0.294
attribute @s minecraft:scale base set 0.880
data modify entity @s Health set value 148f
