attribute @s minecraft:max_health base set 54
attribute @s minecraft:attack_damage base set 8.25
attribute @s minecraft:armor base set 6
attribute @s minecraft:movement_speed base set 0.334
attribute @s minecraft:scale base set 1.119
data modify entity @s Health set value 54f
