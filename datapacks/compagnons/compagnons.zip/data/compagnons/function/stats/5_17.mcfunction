attribute @s minecraft:max_health base set 37
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.134
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 37f
attribute @s minecraft:flying_speed base set 0.1510
