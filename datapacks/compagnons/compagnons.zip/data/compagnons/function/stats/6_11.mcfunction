attribute @s minecraft:max_health base set 104
attribute @s minecraft:attack_damage base set 15.50
attribute @s minecraft:armor base set 3
attribute @s minecraft:movement_speed base set 0.272
attribute @s minecraft:scale base set 0.715
data modify entity @s Health set value 104f
