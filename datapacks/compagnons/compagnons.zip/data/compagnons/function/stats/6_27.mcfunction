attribute @s minecraft:max_health base set 168
attribute @s minecraft:attack_damage base set 23.50
attribute @s minecraft:armor base set 9
attribute @s minecraft:movement_speed base set 0.304
attribute @s minecraft:scale base set 0.955
data modify entity @s Health set value 168f
