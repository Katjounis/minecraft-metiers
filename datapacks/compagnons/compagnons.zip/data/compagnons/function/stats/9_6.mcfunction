attribute @s minecraft:max_health base set 90
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.200
attribute @s minecraft:scale base set 0.550
data modify entity @s Health set value 90f
attribute @s minecraft:flying_speed base set 0.0770
