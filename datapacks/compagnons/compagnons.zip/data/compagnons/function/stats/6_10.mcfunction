attribute @s minecraft:max_health base set 100
attribute @s minecraft:attack_damage base set 15.00
attribute @s minecraft:armor base set 3
attribute @s minecraft:movement_speed base set 0.270
attribute @s minecraft:scale base set 0.700
data modify entity @s Health set value 100f
