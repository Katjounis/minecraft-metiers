attribute @s minecraft:max_health base set 64
attribute @s minecraft:armor base set 6
attribute @s minecraft:movement_speed base set 0.290
attribute @s minecraft:scale base set 1.300
data modify entity @s Health set value 64f
