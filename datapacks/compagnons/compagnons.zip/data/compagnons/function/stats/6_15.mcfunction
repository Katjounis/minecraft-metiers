attribute @s minecraft:max_health base set 120
attribute @s minecraft:attack_damage base set 17.50
attribute @s minecraft:armor base set 5
attribute @s minecraft:movement_speed base set 0.280
attribute @s minecraft:scale base set 0.775
data modify entity @s Health set value 120f
