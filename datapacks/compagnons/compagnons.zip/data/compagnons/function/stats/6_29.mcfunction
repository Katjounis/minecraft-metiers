attribute @s minecraft:max_health base set 176
attribute @s minecraft:attack_damage base set 24.50
attribute @s minecraft:armor base set 9
attribute @s minecraft:movement_speed base set 0.308
attribute @s minecraft:scale base set 0.985
data modify entity @s Health set value 176f
