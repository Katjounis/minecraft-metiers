attribute @s minecraft:max_health base set 13
attribute @s minecraft:attack_damage base set 3.30
attribute @s minecraft:armor base set 0
attribute @s minecraft:movement_speed base set 0.306
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 13f
