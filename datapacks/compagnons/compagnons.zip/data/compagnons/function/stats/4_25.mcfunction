attribute @s minecraft:max_health base set 54
attribute @s minecraft:armor base set 5
attribute @s minecraft:movement_speed base set 0.275
attribute @s minecraft:scale base set 1.250
data modify entity @s Health set value 54f
