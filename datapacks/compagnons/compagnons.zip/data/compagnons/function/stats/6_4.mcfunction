attribute @s minecraft:max_health base set 76
attribute @s minecraft:attack_damage base set 12.00
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.258
attribute @s minecraft:scale base set 0.610
data modify entity @s Health set value 76f
