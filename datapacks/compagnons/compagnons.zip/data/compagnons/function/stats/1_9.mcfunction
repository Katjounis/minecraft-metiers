attribute @s minecraft:max_health base set 38
attribute @s minecraft:attack_damage base set 6.25
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.318
attribute @s minecraft:scale base set 1.063
data modify entity @s Health set value 38f
