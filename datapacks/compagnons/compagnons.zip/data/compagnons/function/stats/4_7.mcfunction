attribute @s minecraft:max_health base set 18
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.221
attribute @s minecraft:scale base set 1.070
data modify entity @s Health set value 18f
