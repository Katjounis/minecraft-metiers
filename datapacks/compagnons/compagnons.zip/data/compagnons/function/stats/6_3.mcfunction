attribute @s minecraft:max_health base set 72
attribute @s minecraft:attack_damage base set 11.50
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.256
attribute @s minecraft:scale base set 0.595
data modify entity @s Health set value 72f
