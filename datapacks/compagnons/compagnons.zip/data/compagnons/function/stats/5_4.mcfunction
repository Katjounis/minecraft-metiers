attribute @s minecraft:max_health base set 24
attribute @s minecraft:armor base set 0
attribute @s minecraft:movement_speed base set 0.108
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 24f
attribute @s minecraft:flying_speed base set 0.112
