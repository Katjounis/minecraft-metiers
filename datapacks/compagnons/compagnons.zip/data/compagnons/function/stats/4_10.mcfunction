attribute @s minecraft:max_health base set 24
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.230
attribute @s minecraft:scale base set 1.100
data modify entity @s Health set value 24f
