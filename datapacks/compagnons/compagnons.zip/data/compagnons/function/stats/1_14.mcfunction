attribute @s minecraft:max_health base set 48
attribute @s minecraft:attack_damage base set 7.50
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.328
attribute @s minecraft:scale base set 1.098
data modify entity @s Health set value 48f
