attribute @s minecraft:max_health base set 11
attribute @s minecraft:attack_damage base set 3.10
attribute @s minecraft:armor base set 0
attribute @s minecraft:movement_speed base set 0.302
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 11f
