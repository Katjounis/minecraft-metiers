attribute @s minecraft:max_health base set 92
attribute @s minecraft:attack_damage base set 14.00
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.266
attribute @s minecraft:scale base set 0.670
data modify entity @s Health set value 92f
