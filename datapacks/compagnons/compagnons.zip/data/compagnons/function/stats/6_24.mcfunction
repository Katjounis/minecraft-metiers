attribute @s minecraft:max_health base set 156
attribute @s minecraft:attack_damage base set 22.00
attribute @s minecraft:armor base set 8
attribute @s minecraft:movement_speed base set 0.298
attribute @s minecraft:scale base set 0.910
data modify entity @s Health set value 156f
