attribute @s minecraft:max_health base set 64
attribute @s minecraft:attack_damage base set 10.50
attribute @s minecraft:armor base set 0
attribute @s minecraft:movement_speed base set 0.252
attribute @s minecraft:scale base set 0.565
data modify entity @s Health set value 64f
