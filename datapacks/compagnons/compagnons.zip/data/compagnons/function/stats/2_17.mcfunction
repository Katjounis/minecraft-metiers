attribute @s minecraft:max_health base set 27
attribute @s minecraft:attack_damage base set 4.70
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.334
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 27f
