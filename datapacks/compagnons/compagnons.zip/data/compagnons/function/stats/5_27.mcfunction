attribute @s minecraft:max_health base set 47
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.154
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 47f
attribute @s minecraft:flying_speed base set 0.181
