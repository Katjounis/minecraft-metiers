attribute @s minecraft:max_health base set 58
attribute @s minecraft:armor base set 5
attribute @s minecraft:movement_speed base set 0.281
attribute @s minecraft:scale base set 1.270
data modify entity @s Health set value 58f
