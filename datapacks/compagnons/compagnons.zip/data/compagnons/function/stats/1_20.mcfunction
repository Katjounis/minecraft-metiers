attribute @s minecraft:max_health base set 60
attribute @s minecraft:attack_damage base set 9.00
attribute @s minecraft:armor base set 8
attribute @s minecraft:movement_speed base set 0.340
attribute @s minecraft:scale base set 1.140
data modify entity @s Health set value 60f
