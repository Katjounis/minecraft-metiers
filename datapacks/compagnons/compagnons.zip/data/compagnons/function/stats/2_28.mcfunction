attribute @s minecraft:max_health base set 38
attribute @s minecraft:attack_damage base set 5.80
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.356
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 38f
