attribute @s minecraft:max_health base set 27
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.114
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 27f
attribute @s minecraft:flying_speed base set 0.1210
