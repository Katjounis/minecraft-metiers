attribute @s minecraft:max_health base set 29
attribute @s minecraft:armor base set 3
attribute @s minecraft:movement_speed base set 0.246
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 29f
