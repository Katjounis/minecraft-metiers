attribute @s minecraft:max_health base set 76
attribute @s minecraft:attack_damage base set 11.00
attribute @s minecraft:armor base set 10
attribute @s minecraft:movement_speed base set 0.356
attribute @s minecraft:scale base set 1.196
data modify entity @s Health set value 76f
