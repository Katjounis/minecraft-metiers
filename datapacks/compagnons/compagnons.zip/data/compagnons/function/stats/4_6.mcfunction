attribute @s minecraft:max_health base set 16
attribute @s minecraft:armor base set 1
attribute @s minecraft:movement_speed base set 0.218
attribute @s minecraft:scale base set 1.060
data modify entity @s Health set value 16f
