attribute @s minecraft:max_health base set 30
attribute @s minecraft:attack_damage base set 5.25
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.310
attribute @s minecraft:scale base set 1.035
data modify entity @s Health set value 30f
