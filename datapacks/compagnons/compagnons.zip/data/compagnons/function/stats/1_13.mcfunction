attribute @s minecraft:max_health base set 46
attribute @s minecraft:attack_damage base set 7.25
attribute @s minecraft:armor base set 4
attribute @s minecraft:movement_speed base set 0.326
attribute @s minecraft:scale base set 1.091
data modify entity @s Health set value 46f
