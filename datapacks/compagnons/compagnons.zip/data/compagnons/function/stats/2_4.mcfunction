attribute @s minecraft:max_health base set 14
attribute @s minecraft:attack_damage base set 3.40
attribute @s minecraft:armor base set 0
attribute @s minecraft:movement_speed base set 0.308
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 14f
