attribute @s minecraft:max_health base set 28
attribute @s minecraft:attack_damage base set 5.00
attribute @s minecraft:armor base set 0
attribute @s minecraft:movement_speed base set 0.308
attribute @s minecraft:scale base set 1.028
data modify entity @s Health set value 28f
