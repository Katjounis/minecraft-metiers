attribute @s minecraft:max_health base set 19
attribute @s minecraft:armor base set 2
attribute @s minecraft:movement_speed base set 0.226
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 19f
