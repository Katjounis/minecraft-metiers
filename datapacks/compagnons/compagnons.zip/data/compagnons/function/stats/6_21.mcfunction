attribute @s minecraft:max_health base set 144
attribute @s minecraft:attack_damage base set 20.50
attribute @s minecraft:armor base set 7
attribute @s minecraft:movement_speed base set 0.292
attribute @s minecraft:scale base set 0.865
data modify entity @s Health set value 144f
