attribute @s minecraft:max_health base set 72
attribute @s minecraft:attack_damage base set 10.50
attribute @s minecraft:armor base set 10
attribute @s minecraft:movement_speed base set 0.352
attribute @s minecraft:scale base set 1.182
data modify entity @s Health set value 72f
