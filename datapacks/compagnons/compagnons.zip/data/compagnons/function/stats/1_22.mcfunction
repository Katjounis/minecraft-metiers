attribute @s minecraft:max_health base set 64
attribute @s minecraft:attack_damage base set 9.50
attribute @s minecraft:armor base set 8
attribute @s minecraft:movement_speed base set 0.344
attribute @s minecraft:scale base set 1.154
data modify entity @s Health set value 64f
