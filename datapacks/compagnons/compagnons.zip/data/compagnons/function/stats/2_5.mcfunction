attribute @s minecraft:max_health base set 15
attribute @s minecraft:attack_damage base set 3.50
attribute @s minecraft:armor base set 0
attribute @s minecraft:movement_speed base set 0.310
attribute @s minecraft:scale base set 1.000
data modify entity @s Health set value 15f
