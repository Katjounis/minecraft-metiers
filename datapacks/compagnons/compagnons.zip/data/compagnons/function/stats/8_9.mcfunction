attribute @s minecraft:max_health base set 76
attribute @s minecraft:armor base set 3
attribute @s minecraft:movement_speed base set 0.200
attribute @s minecraft:scale base set 0.550
data modify entity @s Health set value 76f
attribute @s minecraft:flying_speed base set 0.0880
