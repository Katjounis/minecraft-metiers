tellraw @s {"text":"[Métiers] Version 25.8 : récompenses de palier relevées, Estomac solide toutes les 10 secondes","color":"gold"}
