tellraw @s {"text":"[Métiers] Version 27.0 : arbres à 18 compétences, objets de métier, capacités de la Forge sur les outils","color":"gold"}
