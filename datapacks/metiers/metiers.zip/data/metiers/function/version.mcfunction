tellraw @s {"text":"[Métiers] Version 25.3 : courbe d’XP exponentielle, 10e métier Bâtisseur, quêtes, guildes, synergies, boss plus durs, menu G commun","color":"gold"}
