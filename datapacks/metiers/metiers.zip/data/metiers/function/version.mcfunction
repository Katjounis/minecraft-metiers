tellraw @s {"text":"[Métiers] Version 25.13 : classement de chaque métier dans son onglet (top 10)","color":"gold"}
