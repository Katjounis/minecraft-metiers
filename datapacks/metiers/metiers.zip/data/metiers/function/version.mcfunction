tellraw @s {"text":"[Métiers] Version 25.11 : boss repris après déconnexion, pas d’XP en ramassant ses affaires après une mort","color":"gold"}
