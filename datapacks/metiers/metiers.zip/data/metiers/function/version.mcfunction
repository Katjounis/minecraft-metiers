tellraw @s {"text":"[Métiers] Version 26.3 : barèmes en grille de cases, arbre cliquable avec infobulles, Mes métiers sur 3 colonnes","color":"gold"}
