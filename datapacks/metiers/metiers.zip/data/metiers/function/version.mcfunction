tellraw @s {"text":"[Métiers] Version 25.10 : un boss toutes les 30 minutes, récompense Chasseur ramenée à 30 % du niveau en cours","color":"gold"}
