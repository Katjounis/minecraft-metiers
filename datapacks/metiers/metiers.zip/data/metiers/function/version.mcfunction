tellraw @s {"text":"[Métiers] Version 26.0 : arbre de compétences dessiné, onglets Outil et Progression, menus réorganisés","color":"gold"}
