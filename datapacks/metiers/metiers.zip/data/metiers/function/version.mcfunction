tellraw @s {"text":"[Métiers] Version 26.4 : menus avec décors encadrés, barèmes en grille, arbre cliquable","color":"gold"}
