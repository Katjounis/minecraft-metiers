tellraw @s {"text":"[Métiers] Version 25.9 : dette anti-triche plafonnée (XP de nouveau gagnée après de grosses constructions)","color":"gold"}
