tellraw @s {"text":"[Métiers] Version 25 : 10e métier Bâtisseur, quêtes, guildes, synergies, boss plus durs, barème illustré, menu G commun aux trois packs","color":"gold"}
