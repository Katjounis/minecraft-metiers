tellraw @s {"text":"[Métiers] Version 26.5 : récompenses de palier en grille, synergies au survol, menus allégés","color":"gold"}
