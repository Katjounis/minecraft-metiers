tellraw @s {"text":"[Métiers] Version 25.7 : niveaux recalculés sur la courbe exponentielle (+6 % par niveau), prestige à 15 000 XP par niveau et par étoile","color":"gold"}
