tellraw @s {"text":"[Métiers] Version 25.4 : courbe d’XP exponentielle (+6 % par niveau), 10e métier Bâtisseur, quêtes, guildes, synergies, boss plus durs, menu G commun","color":"gold"}
