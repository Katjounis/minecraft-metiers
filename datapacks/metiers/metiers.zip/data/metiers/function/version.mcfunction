tellraw @s {"text":"[Métiers] Version 25.14 : compétences en arbre cliquable, sommaire A à Z, classement par métier","color":"gold"}
