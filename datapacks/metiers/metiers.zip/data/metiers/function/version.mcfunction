tellraw @s {"text":"[Métiers] Version 26.1 : boss sans objets, récompense en éclats, Écus et XP","color":"gold"}
