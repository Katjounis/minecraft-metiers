tellraw @s {"text":"[Métiers] Version 26.2 : arbre cliquable avec infobulles, page de métier plus courte, Mes métiers sur 3 colonnes","color":"gold"}
