tellraw @s {"text":"[Métiers] Version 25.12 : boss tués à distance récompensés, mort du boss détectée à coup sûr","color":"gold"}
