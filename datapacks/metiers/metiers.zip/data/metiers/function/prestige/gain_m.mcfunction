function metiers:prestige/tags
execute if score @s m.m_pr matches 1 run scoreboard players add @s m.cr_m 100
execute if score @s m.m_pr matches 1 run scoreboard players add @s m.ecl 2
execute if score @s m.m_pr matches 1 run scoreboard players add @s c.ecus 5000
execute if score @s m.m_pr matches 1 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Récompense de l’étoile 1 : 100 cristaux de Mineur, 2 éclats de boss, 5 000 Écus.","color":"gold"}]
execute if score @s m.m_pr matches 2 run scoreboard players add @s m.cr_m 200
execute if score @s m.m_pr matches 2 run scoreboard players add @s m.ecl 4
execute if score @s m.m_pr matches 2 run scoreboard players add @s c.ecus 10000
execute if score @s m.m_pr matches 2 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Récompense de l’étoile 2 : 200 cristaux de Mineur, 4 éclats de boss, 10 000 Écus.","color":"gold"}]
execute if score @s m.m_pr matches 3 run scoreboard players add @s m.cr_m 300
execute if score @s m.m_pr matches 3 run scoreboard players add @s m.ecl 6
execute if score @s m.m_pr matches 3 run scoreboard players add @s c.ecus 15000
execute if score @s m.m_pr matches 3 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Récompense de l’étoile 3 : 300 cristaux de Mineur, 6 éclats de boss, 15 000 Écus.","color":"gold"}]
execute if score @s m.m_pr matches 4 run scoreboard players add @s m.cr_m 400
execute if score @s m.m_pr matches 4 run scoreboard players add @s m.ecl 8
execute if score @s m.m_pr matches 4 run scoreboard players add @s c.ecus 20000
execute if score @s m.m_pr matches 4 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Récompense de l’étoile 4 : 400 cristaux de Mineur, 8 éclats de boss, 20 000 Écus.","color":"gold"}]
execute if score @s m.m_pr matches 5 run scoreboard players add @s m.cr_m 500
execute if score @s m.m_pr matches 5 run scoreboard players add @s m.ecl 10
execute if score @s m.m_pr matches 5 run scoreboard players add @s c.ecus 25000
execute if score @s m.m_pr matches 5 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Récompense de l’étoile 5 : 500 cristaux de Mineur, 10 éclats de boss, 25 000 Écus.","color":"gold"}]
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"m"}] run function metiers:m/outil_donner
execute unless items entity @s container.* *[minecraft:custom_data~{metiers_outil:"m"}] if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"m"}] run function metiers:m/outil_donner
summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:22,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"star",colors:[I;16766720,16777215],fade_colors:[I;16753920],has_twinkle:true,has_trail:true},{shape:"large_ball",colors:[I;16766720],has_trail:true}]}}}}
tellraw @a [{"text":"✦ ","color":"gold","bold":true},{"selector":"@s","color":"white","bold":true},{"text":" débloque la capacité de prestige ","color":"gray","bold":false},{"text":"Filon","color":"gold","bold":true},{"text":" en Mineur ✦","color":"gray","bold":false}]
