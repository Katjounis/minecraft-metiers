tag @s remove metiers.aura_off
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aura de prestige active (si tu as au moins une étoile).","color":"green"}]
function metiers:menu
