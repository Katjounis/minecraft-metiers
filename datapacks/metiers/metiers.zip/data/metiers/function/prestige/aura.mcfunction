scoreboard players set #ap m.tmp 0
scoreboard players operation #ap m.tmp > @s m.b_pr
scoreboard players operation #ap m.tmp > @s m.f_pr
scoreboard players operation #ap m.tmp > @s m.m_pr
scoreboard players operation #ap m.tmp > @s m.c_pr
scoreboard players operation #ap m.tmp > @s m.p_pr
scoreboard players operation #ap m.tmp > @s m.e_pr
scoreboard players operation #ap m.tmp > @s m.n_pr
scoreboard players operation #ap m.tmp > @s m.x_pr
scoreboard players operation #ap m.tmp > @s m.t_pr
execute if score #ap m.tmp matches 1.. run particle minecraft:end_rod ~ ~1 ~ 0.4 0.6 0.4 0.01 2
execute if score #ap m.tmp matches 3.. run particle minecraft:enchant ~ ~1.2 ~ 0.4 0.5 0.4 0.5 6
execute if score #ap m.tmp matches 5.. run particle minecraft:dust{color:[1.0,0.82,0.2],scale:1.0} ~ ~0.2 ~ 0.45 0.05 0.45 0 6
