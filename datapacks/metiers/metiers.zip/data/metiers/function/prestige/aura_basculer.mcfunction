execute if entity @s[tag=metiers.aura_off] run return run function metiers:prestige/aura_on
tag @s add metiers.aura_off
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aura de prestige coupée. Le même bouton la remet.","color":"gold"}]
function metiers:menu
