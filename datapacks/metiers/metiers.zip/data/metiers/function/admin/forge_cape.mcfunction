scoreboard players set @s m.fo_cape 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu peux récupérer gratuitement : Cape-planeur (G, Forge, Boutique).","color":"green"}]
