scoreboard players set @s m.fo_parchemin 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu peux récupérer gratuitement : Parchemin de transfert (G, Forge, Boutique).","color":"green"}]
