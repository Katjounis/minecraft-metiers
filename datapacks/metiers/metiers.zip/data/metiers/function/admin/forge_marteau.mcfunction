scoreboard players set @s m.fo_marteau 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu peux récupérer gratuitement : Marteau du Mineur (G, Forge, Boutique).","color":"green"}]
