scoreboard players set @s m.fo_faux 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu peux récupérer gratuitement : Faux du Fermier (G, Forge, Boutique).","color":"green"}]
