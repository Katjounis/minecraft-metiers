scoreboard players set @s m.fo_lasso 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu peux récupérer gratuitement : Lasso de l'Éleveur (G, Forge, Boutique).","color":"green"}]
