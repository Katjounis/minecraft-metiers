scoreboard players set @s m.fo_arc3 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu peux récupérer gratuitement : Arc à triple tir (G, Forge, Boutique).","color":"green"}]
