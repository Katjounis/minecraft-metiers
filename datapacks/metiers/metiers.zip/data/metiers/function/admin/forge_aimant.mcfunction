scoreboard players set @s m.fo_aimant 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu peux récupérer gratuitement : Aimant à objets (G, Forge, Boutique).","color":"green"}]
