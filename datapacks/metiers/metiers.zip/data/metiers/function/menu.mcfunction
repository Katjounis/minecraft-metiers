scoreboard players add @s m.total 0
execute store result storage metiers:mn score int 1 run scoreboard players get @s m.total
execute store result storage metiers:mn ecl int 1 run scoreboard players get @s m.ecl
scoreboard players add @s m.arm 0
data modify storage metiers:mn arm set value "pas encore débloquée"
execute if score @s m.arm matches 1 run data modify storage metiers:mn arm set value "palier 0 (Diamant)"
execute if score @s m.arm matches 2 run data modify storage metiers:mn arm set value "palier 1 (Diamant forgé)"
execute if score @s m.arm matches 3 run data modify storage metiers:mn arm set value "palier 2 (Netherite)"
execute if score @s m.arm matches 4 run data modify storage metiers:mn arm set value "palier 3 (Netherite épineuse)"
execute if score @s m.arm matches 5 run data modify storage metiers:mn arm set value "palier 4 (Netherite d'améthyste)"
execute if score @s m.arm matches 6 run data modify storage metiers:mn arm set value "palier 5 (Netherite de braise)"
execute if score @s m.arm matches 7 run data modify storage metiers:mn arm set value "palier 6 (Netherite rubis)"
execute if score @s m.arm matches 8 run data modify storage metiers:mn arm set value "palier 7 (Netherite runique)"
execute if score @s m.arm matches 9 run data modify storage metiers:mn arm set value "palier 8 (Netherite du Vide)"
execute if score @s m.arm matches 10 run data modify storage metiers:mn arm set value "palier 9 (Mythique)"
execute if score @s m.arm matches 11 run data modify storage metiers:mn arm set value "palier 10 (Céleste)"
execute store result storage metiers:mn b_l int 1 run scoreboard players get @s m.b_lvl
scoreboard players operation @s m.tmp = @s m.b_xp
scoreboard players operation @s m.tmp *= #10 m.const
scoreboard players operation @s m.tmp /= @s m.b_need
execute if score @s m.b_lvl matches 100.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches 11.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches ..-1 run scoreboard players set @s m.tmp 0
data modify storage metiers:mn b_b set value ""
execute if score @s m.tmp matches 0 run data modify storage metiers:mn b_b set value ""
execute if score @s m.tmp matches 1 run data modify storage metiers:mn b_b set value ""
execute if score @s m.tmp matches 2 run data modify storage metiers:mn b_b set value ""
execute if score @s m.tmp matches 3 run data modify storage metiers:mn b_b set value ""
execute if score @s m.tmp matches 4 run data modify storage metiers:mn b_b set value ""
execute if score @s m.tmp matches 5 run data modify storage metiers:mn b_b set value ""
execute if score @s m.tmp matches 6 run data modify storage metiers:mn b_b set value ""
execute if score @s m.tmp matches 7 run data modify storage metiers:mn b_b set value ""
execute if score @s m.tmp matches 8 run data modify storage metiers:mn b_b set value ""
execute if score @s m.tmp matches 9 run data modify storage metiers:mn b_b set value ""
execute if score @s m.tmp matches 10 run data modify storage metiers:mn b_b set value ""
data modify storage metiers:mn b_d set value ""
function metiers:b/points
execute if score @s m.tmp matches 6.. unless entity @s[tag=metiers.sk.b1,tag=metiers.sk.b2,tag=metiers.sk.b3,tag=metiers.sk.b4,tag=metiers.sk.b5,tag=metiers.sk.b6] if score @s m.b_lvl matches 5.. run data modify storage metiers:mn b_d set value "●"
scoreboard players operation @s m.tmp = @s m.b_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.b_pal < @s m.tmp run data modify storage metiers:mn b_d set value "●"
execute store result storage metiers:mn f_l int 1 run scoreboard players get @s m.f_lvl
scoreboard players operation @s m.tmp = @s m.f_xp
scoreboard players operation @s m.tmp *= #10 m.const
scoreboard players operation @s m.tmp /= @s m.f_need
execute if score @s m.f_lvl matches 100.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches 11.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches ..-1 run scoreboard players set @s m.tmp 0
data modify storage metiers:mn f_b set value ""
execute if score @s m.tmp matches 0 run data modify storage metiers:mn f_b set value ""
execute if score @s m.tmp matches 1 run data modify storage metiers:mn f_b set value ""
execute if score @s m.tmp matches 2 run data modify storage metiers:mn f_b set value ""
execute if score @s m.tmp matches 3 run data modify storage metiers:mn f_b set value ""
execute if score @s m.tmp matches 4 run data modify storage metiers:mn f_b set value ""
execute if score @s m.tmp matches 5 run data modify storage metiers:mn f_b set value ""
execute if score @s m.tmp matches 6 run data modify storage metiers:mn f_b set value ""
execute if score @s m.tmp matches 7 run data modify storage metiers:mn f_b set value ""
execute if score @s m.tmp matches 8 run data modify storage metiers:mn f_b set value ""
execute if score @s m.tmp matches 9 run data modify storage metiers:mn f_b set value ""
execute if score @s m.tmp matches 10 run data modify storage metiers:mn f_b set value ""
data modify storage metiers:mn f_d set value ""
function metiers:f/points
execute if score @s m.tmp matches 6.. unless entity @s[tag=metiers.sk.f1,tag=metiers.sk.f2,tag=metiers.sk.f3,tag=metiers.sk.f4,tag=metiers.sk.f5,tag=metiers.sk.f6] if score @s m.f_lvl matches 5.. run data modify storage metiers:mn f_d set value "●"
scoreboard players operation @s m.tmp = @s m.f_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.f_pal < @s m.tmp run data modify storage metiers:mn f_d set value "●"
execute store result storage metiers:mn m_l int 1 run scoreboard players get @s m.m_lvl
scoreboard players operation @s m.tmp = @s m.m_xp
scoreboard players operation @s m.tmp *= #10 m.const
scoreboard players operation @s m.tmp /= @s m.m_need
execute if score @s m.m_lvl matches 100.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches 11.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches ..-1 run scoreboard players set @s m.tmp 0
data modify storage metiers:mn m_b set value ""
execute if score @s m.tmp matches 0 run data modify storage metiers:mn m_b set value ""
execute if score @s m.tmp matches 1 run data modify storage metiers:mn m_b set value ""
execute if score @s m.tmp matches 2 run data modify storage metiers:mn m_b set value ""
execute if score @s m.tmp matches 3 run data modify storage metiers:mn m_b set value ""
execute if score @s m.tmp matches 4 run data modify storage metiers:mn m_b set value ""
execute if score @s m.tmp matches 5 run data modify storage metiers:mn m_b set value ""
execute if score @s m.tmp matches 6 run data modify storage metiers:mn m_b set value ""
execute if score @s m.tmp matches 7 run data modify storage metiers:mn m_b set value ""
execute if score @s m.tmp matches 8 run data modify storage metiers:mn m_b set value ""
execute if score @s m.tmp matches 9 run data modify storage metiers:mn m_b set value ""
execute if score @s m.tmp matches 10 run data modify storage metiers:mn m_b set value ""
data modify storage metiers:mn m_d set value ""
function metiers:m/points
execute if score @s m.tmp matches 6.. unless entity @s[tag=metiers.sk.m1,tag=metiers.sk.m2,tag=metiers.sk.m3,tag=metiers.sk.m4,tag=metiers.sk.m5,tag=metiers.sk.m6] if score @s m.m_lvl matches 5.. run data modify storage metiers:mn m_d set value "●"
scoreboard players operation @s m.tmp = @s m.m_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.m_pal < @s m.tmp run data modify storage metiers:mn m_d set value "●"
execute store result storage metiers:mn c_l int 1 run scoreboard players get @s m.c_lvl
scoreboard players operation @s m.tmp = @s m.c_xp
scoreboard players operation @s m.tmp *= #10 m.const
scoreboard players operation @s m.tmp /= @s m.c_need
execute if score @s m.c_lvl matches 100.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches 11.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches ..-1 run scoreboard players set @s m.tmp 0
data modify storage metiers:mn c_b set value ""
execute if score @s m.tmp matches 0 run data modify storage metiers:mn c_b set value ""
execute if score @s m.tmp matches 1 run data modify storage metiers:mn c_b set value ""
execute if score @s m.tmp matches 2 run data modify storage metiers:mn c_b set value ""
execute if score @s m.tmp matches 3 run data modify storage metiers:mn c_b set value ""
execute if score @s m.tmp matches 4 run data modify storage metiers:mn c_b set value ""
execute if score @s m.tmp matches 5 run data modify storage metiers:mn c_b set value ""
execute if score @s m.tmp matches 6 run data modify storage metiers:mn c_b set value ""
execute if score @s m.tmp matches 7 run data modify storage metiers:mn c_b set value ""
execute if score @s m.tmp matches 8 run data modify storage metiers:mn c_b set value ""
execute if score @s m.tmp matches 9 run data modify storage metiers:mn c_b set value ""
execute if score @s m.tmp matches 10 run data modify storage metiers:mn c_b set value ""
data modify storage metiers:mn c_d set value ""
function metiers:c/points
execute if score @s m.tmp matches 6.. unless entity @s[tag=metiers.sk.c1,tag=metiers.sk.c2,tag=metiers.sk.c3,tag=metiers.sk.c4,tag=metiers.sk.c5,tag=metiers.sk.c6] if score @s m.c_lvl matches 5.. run data modify storage metiers:mn c_d set value "●"
scoreboard players operation @s m.tmp = @s m.c_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.c_pal < @s m.tmp run data modify storage metiers:mn c_d set value "●"
execute store result storage metiers:mn p_l int 1 run scoreboard players get @s m.p_lvl
scoreboard players operation @s m.tmp = @s m.p_xp
scoreboard players operation @s m.tmp *= #10 m.const
scoreboard players operation @s m.tmp /= @s m.p_need
execute if score @s m.p_lvl matches 100.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches 11.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches ..-1 run scoreboard players set @s m.tmp 0
data modify storage metiers:mn p_b set value ""
execute if score @s m.tmp matches 0 run data modify storage metiers:mn p_b set value ""
execute if score @s m.tmp matches 1 run data modify storage metiers:mn p_b set value ""
execute if score @s m.tmp matches 2 run data modify storage metiers:mn p_b set value ""
execute if score @s m.tmp matches 3 run data modify storage metiers:mn p_b set value ""
execute if score @s m.tmp matches 4 run data modify storage metiers:mn p_b set value ""
execute if score @s m.tmp matches 5 run data modify storage metiers:mn p_b set value ""
execute if score @s m.tmp matches 6 run data modify storage metiers:mn p_b set value ""
execute if score @s m.tmp matches 7 run data modify storage metiers:mn p_b set value ""
execute if score @s m.tmp matches 8 run data modify storage metiers:mn p_b set value ""
execute if score @s m.tmp matches 9 run data modify storage metiers:mn p_b set value ""
execute if score @s m.tmp matches 10 run data modify storage metiers:mn p_b set value ""
data modify storage metiers:mn p_d set value ""
function metiers:p/points
execute if score @s m.tmp matches 6.. unless entity @s[tag=metiers.sk.p1,tag=metiers.sk.p2,tag=metiers.sk.p3,tag=metiers.sk.p4,tag=metiers.sk.p5,tag=metiers.sk.p6] if score @s m.p_lvl matches 5.. run data modify storage metiers:mn p_d set value "●"
scoreboard players operation @s m.tmp = @s m.p_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.p_pal < @s m.tmp run data modify storage metiers:mn p_d set value "●"
execute store result storage metiers:mn e_l int 1 run scoreboard players get @s m.e_lvl
scoreboard players operation @s m.tmp = @s m.e_xp
scoreboard players operation @s m.tmp *= #10 m.const
scoreboard players operation @s m.tmp /= @s m.e_need
execute if score @s m.e_lvl matches 100.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches 11.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches ..-1 run scoreboard players set @s m.tmp 0
data modify storage metiers:mn e_b set value ""
execute if score @s m.tmp matches 0 run data modify storage metiers:mn e_b set value ""
execute if score @s m.tmp matches 1 run data modify storage metiers:mn e_b set value ""
execute if score @s m.tmp matches 2 run data modify storage metiers:mn e_b set value ""
execute if score @s m.tmp matches 3 run data modify storage metiers:mn e_b set value ""
execute if score @s m.tmp matches 4 run data modify storage metiers:mn e_b set value ""
execute if score @s m.tmp matches 5 run data modify storage metiers:mn e_b set value ""
execute if score @s m.tmp matches 6 run data modify storage metiers:mn e_b set value ""
execute if score @s m.tmp matches 7 run data modify storage metiers:mn e_b set value ""
execute if score @s m.tmp matches 8 run data modify storage metiers:mn e_b set value ""
execute if score @s m.tmp matches 9 run data modify storage metiers:mn e_b set value ""
execute if score @s m.tmp matches 10 run data modify storage metiers:mn e_b set value ""
data modify storage metiers:mn e_d set value ""
function metiers:e/points
execute if score @s m.tmp matches 6.. unless entity @s[tag=metiers.sk.e1,tag=metiers.sk.e2,tag=metiers.sk.e3,tag=metiers.sk.e4,tag=metiers.sk.e5,tag=metiers.sk.e6] if score @s m.e_lvl matches 5.. run data modify storage metiers:mn e_d set value "●"
scoreboard players operation @s m.tmp = @s m.e_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.e_pal < @s m.tmp run data modify storage metiers:mn e_d set value "●"
execute store result storage metiers:mn n_l int 1 run scoreboard players get @s m.n_lvl
scoreboard players operation @s m.tmp = @s m.n_xp
scoreboard players operation @s m.tmp *= #10 m.const
scoreboard players operation @s m.tmp /= @s m.n_need
execute if score @s m.n_lvl matches 100.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches 11.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches ..-1 run scoreboard players set @s m.tmp 0
data modify storage metiers:mn n_b set value ""
execute if score @s m.tmp matches 0 run data modify storage metiers:mn n_b set value ""
execute if score @s m.tmp matches 1 run data modify storage metiers:mn n_b set value ""
execute if score @s m.tmp matches 2 run data modify storage metiers:mn n_b set value ""
execute if score @s m.tmp matches 3 run data modify storage metiers:mn n_b set value ""
execute if score @s m.tmp matches 4 run data modify storage metiers:mn n_b set value ""
execute if score @s m.tmp matches 5 run data modify storage metiers:mn n_b set value ""
execute if score @s m.tmp matches 6 run data modify storage metiers:mn n_b set value ""
execute if score @s m.tmp matches 7 run data modify storage metiers:mn n_b set value ""
execute if score @s m.tmp matches 8 run data modify storage metiers:mn n_b set value ""
execute if score @s m.tmp matches 9 run data modify storage metiers:mn n_b set value ""
execute if score @s m.tmp matches 10 run data modify storage metiers:mn n_b set value ""
data modify storage metiers:mn n_d set value ""
function metiers:n/points
execute if score @s m.tmp matches 6.. unless entity @s[tag=metiers.sk.n1,tag=metiers.sk.n2,tag=metiers.sk.n3,tag=metiers.sk.n4,tag=metiers.sk.n5,tag=metiers.sk.n6] if score @s m.n_lvl matches 5.. run data modify storage metiers:mn n_d set value "●"
scoreboard players operation @s m.tmp = @s m.n_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.n_pal < @s m.tmp run data modify storage metiers:mn n_d set value "●"
execute store result storage metiers:mn x_l int 1 run scoreboard players get @s m.x_lvl
scoreboard players operation @s m.tmp = @s m.x_xp
scoreboard players operation @s m.tmp *= #10 m.const
scoreboard players operation @s m.tmp /= @s m.x_need
execute if score @s m.x_lvl matches 100.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches 11.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches ..-1 run scoreboard players set @s m.tmp 0
data modify storage metiers:mn x_b set value ""
execute if score @s m.tmp matches 0 run data modify storage metiers:mn x_b set value ""
execute if score @s m.tmp matches 1 run data modify storage metiers:mn x_b set value ""
execute if score @s m.tmp matches 2 run data modify storage metiers:mn x_b set value ""
execute if score @s m.tmp matches 3 run data modify storage metiers:mn x_b set value ""
execute if score @s m.tmp matches 4 run data modify storage metiers:mn x_b set value ""
execute if score @s m.tmp matches 5 run data modify storage metiers:mn x_b set value ""
execute if score @s m.tmp matches 6 run data modify storage metiers:mn x_b set value ""
execute if score @s m.tmp matches 7 run data modify storage metiers:mn x_b set value ""
execute if score @s m.tmp matches 8 run data modify storage metiers:mn x_b set value ""
execute if score @s m.tmp matches 9 run data modify storage metiers:mn x_b set value ""
execute if score @s m.tmp matches 10 run data modify storage metiers:mn x_b set value ""
data modify storage metiers:mn x_d set value ""
function metiers:x/points
execute if score @s m.tmp matches 6.. unless entity @s[tag=metiers.sk.x1,tag=metiers.sk.x2,tag=metiers.sk.x3,tag=metiers.sk.x4,tag=metiers.sk.x5,tag=metiers.sk.x6] if score @s m.x_lvl matches 5.. run data modify storage metiers:mn x_d set value "●"
scoreboard players operation @s m.tmp = @s m.x_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.x_pal < @s m.tmp run data modify storage metiers:mn x_d set value "●"
execute store result storage metiers:mn t_l int 1 run scoreboard players get @s m.t_lvl
scoreboard players operation @s m.tmp = @s m.t_xp
scoreboard players operation @s m.tmp *= #10 m.const
scoreboard players operation @s m.tmp /= @s m.t_need
execute if score @s m.t_lvl matches 100.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches 11.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches ..-1 run scoreboard players set @s m.tmp 0
data modify storage metiers:mn t_b set value ""
execute if score @s m.tmp matches 0 run data modify storage metiers:mn t_b set value ""
execute if score @s m.tmp matches 1 run data modify storage metiers:mn t_b set value ""
execute if score @s m.tmp matches 2 run data modify storage metiers:mn t_b set value ""
execute if score @s m.tmp matches 3 run data modify storage metiers:mn t_b set value ""
execute if score @s m.tmp matches 4 run data modify storage metiers:mn t_b set value ""
execute if score @s m.tmp matches 5 run data modify storage metiers:mn t_b set value ""
execute if score @s m.tmp matches 6 run data modify storage metiers:mn t_b set value ""
execute if score @s m.tmp matches 7 run data modify storage metiers:mn t_b set value ""
execute if score @s m.tmp matches 8 run data modify storage metiers:mn t_b set value ""
execute if score @s m.tmp matches 9 run data modify storage metiers:mn t_b set value ""
execute if score @s m.tmp matches 10 run data modify storage metiers:mn t_b set value ""
data modify storage metiers:mn t_d set value ""
function metiers:t/points
execute if score @s m.tmp matches 6.. unless entity @s[tag=metiers.sk.t1,tag=metiers.sk.t2,tag=metiers.sk.t3,tag=metiers.sk.t4,tag=metiers.sk.t5,tag=metiers.sk.t6] if score @s m.t_lvl matches 5.. run data modify storage metiers:mn t_d set value "●"
scoreboard players operation @s m.tmp = @s m.t_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.t_pal < @s m.tmp run data modify storage metiers:mn t_d set value "●"
execute store result storage metiers:mn k_l int 1 run scoreboard players get @s m.k_lvl
scoreboard players operation @s m.tmp = @s m.k_xp
scoreboard players operation @s m.tmp *= #10 m.const
scoreboard players operation @s m.tmp /= @s m.k_need
execute if score @s m.k_lvl matches 100.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches 11.. run scoreboard players set @s m.tmp 10
execute if score @s m.tmp matches ..-1 run scoreboard players set @s m.tmp 0
data modify storage metiers:mn k_b set value ""
execute if score @s m.tmp matches 0 run data modify storage metiers:mn k_b set value ""
execute if score @s m.tmp matches 1 run data modify storage metiers:mn k_b set value ""
execute if score @s m.tmp matches 2 run data modify storage metiers:mn k_b set value ""
execute if score @s m.tmp matches 3 run data modify storage metiers:mn k_b set value ""
execute if score @s m.tmp matches 4 run data modify storage metiers:mn k_b set value ""
execute if score @s m.tmp matches 5 run data modify storage metiers:mn k_b set value ""
execute if score @s m.tmp matches 6 run data modify storage metiers:mn k_b set value ""
execute if score @s m.tmp matches 7 run data modify storage metiers:mn k_b set value ""
execute if score @s m.tmp matches 8 run data modify storage metiers:mn k_b set value ""
execute if score @s m.tmp matches 9 run data modify storage metiers:mn k_b set value ""
execute if score @s m.tmp matches 10 run data modify storage metiers:mn k_b set value ""
data modify storage metiers:mn k_d set value ""
function metiers:k/points
execute if score @s m.tmp matches 6.. unless entity @s[tag=metiers.sk.k1,tag=metiers.sk.k2,tag=metiers.sk.k3,tag=metiers.sk.k4,tag=metiers.sk.k5,tag=metiers.sk.k6] if score @s m.k_lvl matches 5.. run data modify storage metiers:mn k_d set value "●"
scoreboard players operation @s m.tmp = @s m.k_lvl
scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s m.k_pal < @s m.tmp run data modify storage metiers:mn k_d set value "●"
data modify storage metiers:mn a1 set value ""
execute if data storage metiers:mn {b_d:"●"} run data modify storage metiers:mn a1 set value ""
execute if score @s m.b_lvl matches ..9 run data modify storage metiers:mn p1 set value ""
execute if score @s m.b_lvl matches ..9 run data modify storage metiers:mn r1 set value ""
execute if score @s m.b_lvl matches 10..99 run data modify storage metiers:mn p1 set value ""
execute if score @s m.b_lvl matches 10..99 run data modify storage metiers:mn r1 set value ""
execute if score @s m.b_lvl matches 100.. run data modify storage metiers:mn p1 set value ""
execute if score @s m.b_lvl matches 100.. run data modify storage metiers:mn r1 set value ""
data modify storage metiers:mn a2 set value ""
execute if data storage metiers:mn {f_d:"●"} run data modify storage metiers:mn a2 set value ""
execute if score @s m.f_lvl matches ..9 run data modify storage metiers:mn p2 set value ""
execute if score @s m.f_lvl matches ..9 run data modify storage metiers:mn r2 set value ""
execute if score @s m.f_lvl matches 10..99 run data modify storage metiers:mn p2 set value ""
execute if score @s m.f_lvl matches 10..99 run data modify storage metiers:mn r2 set value ""
execute if score @s m.f_lvl matches 100.. run data modify storage metiers:mn p2 set value ""
execute if score @s m.f_lvl matches 100.. run data modify storage metiers:mn r2 set value ""
data modify storage metiers:mn a3 set value ""
execute if data storage metiers:mn {m_d:"●"} run data modify storage metiers:mn a3 set value ""
execute if score @s m.m_lvl matches ..9 run data modify storage metiers:mn p3 set value ""
execute if score @s m.m_lvl matches ..9 run data modify storage metiers:mn r3 set value ""
execute if score @s m.m_lvl matches 10..99 run data modify storage metiers:mn p3 set value ""
execute if score @s m.m_lvl matches 10..99 run data modify storage metiers:mn r3 set value ""
execute if score @s m.m_lvl matches 100.. run data modify storage metiers:mn p3 set value ""
execute if score @s m.m_lvl matches 100.. run data modify storage metiers:mn r3 set value ""
data modify storage metiers:mn a4 set value ""
execute if data storage metiers:mn {c_d:"●"} run data modify storage metiers:mn a4 set value ""
execute if score @s m.c_lvl matches ..9 run data modify storage metiers:mn p4 set value ""
execute if score @s m.c_lvl matches ..9 run data modify storage metiers:mn r4 set value ""
execute if score @s m.c_lvl matches 10..99 run data modify storage metiers:mn p4 set value ""
execute if score @s m.c_lvl matches 10..99 run data modify storage metiers:mn r4 set value ""
execute if score @s m.c_lvl matches 100.. run data modify storage metiers:mn p4 set value ""
execute if score @s m.c_lvl matches 100.. run data modify storage metiers:mn r4 set value ""
data modify storage metiers:mn a5 set value ""
execute if data storage metiers:mn {p_d:"●"} run data modify storage metiers:mn a5 set value ""
execute if score @s m.p_lvl matches ..9 run data modify storage metiers:mn p5 set value ""
execute if score @s m.p_lvl matches ..9 run data modify storage metiers:mn r5 set value ""
execute if score @s m.p_lvl matches 10..99 run data modify storage metiers:mn p5 set value ""
execute if score @s m.p_lvl matches 10..99 run data modify storage metiers:mn r5 set value ""
execute if score @s m.p_lvl matches 100.. run data modify storage metiers:mn p5 set value ""
execute if score @s m.p_lvl matches 100.. run data modify storage metiers:mn r5 set value ""
data modify storage metiers:mn a6 set value ""
execute if data storage metiers:mn {e_d:"●"} run data modify storage metiers:mn a6 set value ""
execute if score @s m.e_lvl matches ..9 run data modify storage metiers:mn p6 set value ""
execute if score @s m.e_lvl matches ..9 run data modify storage metiers:mn r6 set value ""
execute if score @s m.e_lvl matches 10..99 run data modify storage metiers:mn p6 set value ""
execute if score @s m.e_lvl matches 10..99 run data modify storage metiers:mn r6 set value ""
execute if score @s m.e_lvl matches 100.. run data modify storage metiers:mn p6 set value ""
execute if score @s m.e_lvl matches 100.. run data modify storage metiers:mn r6 set value ""
data modify storage metiers:mn a7 set value ""
execute if data storage metiers:mn {n_d:"●"} run data modify storage metiers:mn a7 set value ""
execute if score @s m.n_lvl matches ..9 run data modify storage metiers:mn p7 set value ""
execute if score @s m.n_lvl matches ..9 run data modify storage metiers:mn r7 set value ""
execute if score @s m.n_lvl matches 10..99 run data modify storage metiers:mn p7 set value ""
execute if score @s m.n_lvl matches 10..99 run data modify storage metiers:mn r7 set value ""
execute if score @s m.n_lvl matches 100.. run data modify storage metiers:mn p7 set value ""
execute if score @s m.n_lvl matches 100.. run data modify storage metiers:mn r7 set value ""
data modify storage metiers:mn a8 set value ""
execute if data storage metiers:mn {x_d:"●"} run data modify storage metiers:mn a8 set value ""
execute if score @s m.x_lvl matches ..9 run data modify storage metiers:mn p8 set value ""
execute if score @s m.x_lvl matches ..9 run data modify storage metiers:mn r8 set value ""
execute if score @s m.x_lvl matches 10..99 run data modify storage metiers:mn p8 set value ""
execute if score @s m.x_lvl matches 10..99 run data modify storage metiers:mn r8 set value ""
execute if score @s m.x_lvl matches 100.. run data modify storage metiers:mn p8 set value ""
execute if score @s m.x_lvl matches 100.. run data modify storage metiers:mn r8 set value ""
data modify storage metiers:mn a9 set value ""
execute if data storage metiers:mn {t_d:"●"} run data modify storage metiers:mn a9 set value ""
execute if score @s m.t_lvl matches ..9 run data modify storage metiers:mn p9 set value ""
execute if score @s m.t_lvl matches ..9 run data modify storage metiers:mn r9 set value ""
execute if score @s m.t_lvl matches 10..99 run data modify storage metiers:mn p9 set value ""
execute if score @s m.t_lvl matches 10..99 run data modify storage metiers:mn r9 set value ""
execute if score @s m.t_lvl matches 100.. run data modify storage metiers:mn p9 set value ""
execute if score @s m.t_lvl matches 100.. run data modify storage metiers:mn r9 set value ""
data modify storage metiers:mn a10 set value ""
execute if data storage metiers:mn {k_d:"●"} run data modify storage metiers:mn a10 set value ""
execute if score @s m.k_lvl matches ..9 run data modify storage metiers:mn p10 set value ""
execute if score @s m.k_lvl matches ..9 run data modify storage metiers:mn r10 set value ""
execute if score @s m.k_lvl matches 10..99 run data modify storage metiers:mn p10 set value ""
execute if score @s m.k_lvl matches 10..99 run data modify storage metiers:mn r10 set value ""
execute if score @s m.k_lvl matches 100.. run data modify storage metiers:mn p10 set value ""
execute if score @s m.k_lvl matches 100.. run data modify storage metiers:mn r10 set value ""
function metiers:menu_dialog with storage metiers:mn
