tag @s remove metiers.sk.ybf
execute if score @s m.b_lvl matches 50.. if score @s m.f_lvl matches 50.. run tag @s add metiers.sk.ybf
execute if score @s m.b_pr matches 1.. if score @s m.f_lvl matches 50.. run tag @s add metiers.sk.ybf
execute if score @s m.b_lvl matches 50.. if score @s m.f_pr matches 1.. run tag @s add metiers.sk.ybf
execute if score @s m.b_pr matches 1.. if score @s m.f_pr matches 1.. run tag @s add metiers.sk.ybf
tag @s remove metiers.sk.ymx
execute if score @s m.m_lvl matches 50.. if score @s m.x_lvl matches 50.. run tag @s add metiers.sk.ymx
execute if score @s m.m_pr matches 1.. if score @s m.x_lvl matches 50.. run tag @s add metiers.sk.ymx
execute if score @s m.m_lvl matches 50.. if score @s m.x_pr matches 1.. run tag @s add metiers.sk.ymx
execute if score @s m.m_pr matches 1.. if score @s m.x_pr matches 1.. run tag @s add metiers.sk.ymx
tag @s remove metiers.sk.ycn
execute if score @s m.c_lvl matches 50.. if score @s m.n_lvl matches 50.. run tag @s add metiers.sk.ycn
execute if score @s m.c_pr matches 1.. if score @s m.n_lvl matches 50.. run tag @s add metiers.sk.ycn
execute if score @s m.c_lvl matches 50.. if score @s m.n_pr matches 1.. run tag @s add metiers.sk.ycn
execute if score @s m.c_pr matches 1.. if score @s m.n_pr matches 1.. run tag @s add metiers.sk.ycn
tag @s remove metiers.sk.ype
execute if score @s m.p_lvl matches 50.. if score @s m.e_lvl matches 50.. run tag @s add metiers.sk.ype
execute if score @s m.p_pr matches 1.. if score @s m.e_lvl matches 50.. run tag @s add metiers.sk.ype
execute if score @s m.p_lvl matches 50.. if score @s m.e_pr matches 1.. run tag @s add metiers.sk.ype
execute if score @s m.p_pr matches 1.. if score @s m.e_pr matches 1.. run tag @s add metiers.sk.ype
tag @s remove metiers.sk.ymt
execute if score @s m.m_lvl matches 50.. if score @s m.t_lvl matches 50.. run tag @s add metiers.sk.ymt
execute if score @s m.m_pr matches 1.. if score @s m.t_lvl matches 50.. run tag @s add metiers.sk.ymt
execute if score @s m.m_lvl matches 50.. if score @s m.t_pr matches 1.. run tag @s add metiers.sk.ymt
execute if score @s m.m_pr matches 1.. if score @s m.t_pr matches 1.. run tag @s add metiers.sk.ymt
tag @s remove metiers.sk.yfc
execute if score @s m.f_lvl matches 50.. if score @s m.c_lvl matches 50.. run tag @s add metiers.sk.yfc
execute if score @s m.f_pr matches 1.. if score @s m.c_lvl matches 50.. run tag @s add metiers.sk.yfc
execute if score @s m.f_lvl matches 50.. if score @s m.c_pr matches 1.. run tag @s add metiers.sk.yfc
execute if score @s m.f_pr matches 1.. if score @s m.c_pr matches 1.. run tag @s add metiers.sk.yfc
tag @s remove metiers.sk.ykb
execute if score @s m.k_lvl matches 50.. if score @s m.b_lvl matches 50.. run tag @s add metiers.sk.ykb
execute if score @s m.k_pr matches 1.. if score @s m.b_lvl matches 50.. run tag @s add metiers.sk.ykb
execute if score @s m.k_lvl matches 50.. if score @s m.b_pr matches 1.. run tag @s add metiers.sk.ykb
execute if score @s m.k_pr matches 1.. if score @s m.b_pr matches 1.. run tag @s add metiers.sk.ykb
execute if entity @s[tag=metiers.sk.ymx] if predicate {type:"minecraft:location_check",predicate:{position:{y:{max:0}}}} run effect give @s minecraft:night_vision 15 0 true
execute if entity @s[tag=metiers.sk.ymx] if predicate {type:"minecraft:location_check",predicate:{position:{y:{max:0}}}} run effect give @s minecraft:resistance 3 0 true
execute if entity @s[tag=metiers.sk.ype] run effect give @s minecraft:luck infinite 0 true
execute if entity @s[tag=metiers.sk.yfc] run effect give @s minecraft:saturation 1 0 true
scoreboard players set @s m.syn 0
execute if entity @s[tag=metiers.sk.ymt] run scoreboard players set @s m.syn 1
