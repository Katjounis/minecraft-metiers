execute unless entity @s[tag=metiers.sk.x1] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x2] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Coureur des bois, qui a besoin de Grand pas.","color":"red"}]
execute if entity @s[tag=metiers.sk.x7] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Endurance, qui a besoin de Grand pas.","color":"red"}]
execute if entity @s[tag=metiers.sk.x13] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Pilleur, qui a besoin de Grand pas.","color":"red"}]
tag @s remove metiers.sk.x1
tag @s remove metiers.skoff.x1
advancement revoke @s only metiers:x/competence_1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Grand pas est oubliée : 3 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
