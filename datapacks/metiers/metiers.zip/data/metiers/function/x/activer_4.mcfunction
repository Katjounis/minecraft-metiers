execute unless entity @s[tag=metiers.sk.x4] run return run function metiers:x/arbre
tag @s remove metiers.skoff.x4
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Foulée du vent est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:x/arbre
