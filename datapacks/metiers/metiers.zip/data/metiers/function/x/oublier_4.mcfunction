execute unless entity @s[tag=metiers.sk.x4] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x5] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Instinct, qui a besoin de Foulée du vent.","color":"red"}]
tag @s remove metiers.sk.x4
tag @s remove metiers.skoff.x4
advancement revoke @s only metiers:x/competence_4
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Foulée du vent est oubliée : 8 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
