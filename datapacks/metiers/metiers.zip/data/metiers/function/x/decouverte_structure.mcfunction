scoreboard players add @s m.x_bal 60
title @s actionbar {"text":"Nouvelle découverte : +60 XP Explorateur","color":"blue"}
playsound minecraft:ui.toast.in master @s ~ ~ ~ 0.6 1.4
