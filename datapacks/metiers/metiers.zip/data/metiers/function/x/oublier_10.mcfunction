execute unless entity @s[tag=metiers.sk.x10] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x11] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Propulseur, qui a besoin de Grimpeur.","color":"red"}]
tag @s remove metiers.sk.x10
tag @s remove metiers.skoff.x10
advancement revoke @s only metiers:x/competence_10
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Grimpeur est oubliée : 10 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
