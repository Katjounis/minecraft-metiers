execute if entity @s[tag=metiers.skoff.x15] run return run function metiers:x/choix_off_15
function metiers:x/choix_on_15
