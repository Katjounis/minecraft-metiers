execute if entity @s[tag=metiers.skoff.x15] run return run function metiers:x/activer_15
tag @s add metiers.skoff.x15
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tente est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
