execute if entity @s[tag=metiers.sk.x14] run return run function metiers:x/basculer_14
execute unless score @s m.x_lvl matches 20.. unless score @s m.x_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 20 en Explorateur.","color":"red"}]
execute unless score @s m.x_lvl matches 20.. unless score @s m.x_pr matches 1.. run return run function metiers:x/arbre
function metiers:x/points
execute unless entity @s[tag=metiers.sk.x13] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Pilleur.","color":"red"}]
execute unless entity @s[tag=metiers.sk.x13] run return run function metiers:x/arbre
execute if score @s m.tmp matches ..5 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (6 requis).","color":"red"}]
execute if score @s m.tmp matches ..5 run return run function metiers:x/arbre
scoreboard players add @s m.x_spent 6
tag @s add metiers.sk.x14
advancement grant @s only metiers:x/competence_14
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Œil clair","color":"blue","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:x/arbre
