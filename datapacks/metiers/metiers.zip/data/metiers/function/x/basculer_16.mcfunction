execute if entity @s[tag=metiers.skoff.x16] run return run function metiers:x/choix_16
tag @s add metiers.skoff.x16
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cartographe est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
