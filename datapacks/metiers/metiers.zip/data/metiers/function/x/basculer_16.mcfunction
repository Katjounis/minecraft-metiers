execute if entity @s[tag=metiers.skoff.x16] run return run function metiers:x/choix_off_16
function metiers:x/choix_on_16
