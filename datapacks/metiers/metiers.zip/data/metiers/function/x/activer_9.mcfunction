execute unless entity @s[tag=metiers.sk.x9] run return run function metiers:x/arbre
tag @s remove metiers.skoff.x9
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ailes est réactivée.","color":"green"}]
function metiers:objets/retirer_elytres
function metiers:objets/donner_elytres
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:x/arbre
