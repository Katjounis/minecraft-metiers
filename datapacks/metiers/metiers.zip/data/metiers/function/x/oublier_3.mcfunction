execute unless entity @s[tag=metiers.sk.x3] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x4] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Foulée du vent, qui a besoin de Bon pied.","color":"red"}]
tag @s remove metiers.sk.x3
tag @s remove metiers.skoff.x3
advancement revoke @s only metiers:x/competence_3
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Bon pied est oubliée : 6 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
