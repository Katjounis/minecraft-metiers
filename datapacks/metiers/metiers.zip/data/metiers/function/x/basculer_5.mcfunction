execute if entity @s[tag=metiers.skoff.x5] run return run function metiers:x/choix_off_5
function metiers:x/choix_on_5
