execute unless entity @s[tag=metiers.sk.x2] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x3] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Bon pied, qui a besoin de Coureur des bois.","color":"red"}]
tag @s remove metiers.sk.x2
tag @s remove metiers.skoff.x2
advancement revoke @s only metiers:x/competence_2
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Coureur des bois est oubliée : 4 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
