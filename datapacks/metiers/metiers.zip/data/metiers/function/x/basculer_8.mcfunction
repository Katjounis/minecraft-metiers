execute if entity @s[tag=metiers.skoff.x8] run return run function metiers:x/choix_off_8
function metiers:x/choix_on_8
