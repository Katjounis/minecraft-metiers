execute unless entity @s[tag=metiers.sk.x9] run return run function metiers:x/arbre
tag @s add metiers.skoff.x9
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ailes est désactivée.","color":"gold"}]
function metiers:objets/retirer_elytres
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
