execute unless entity @s[tag=metiers.sk.x14] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x15] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Tente, qui a besoin de Œil clair.","color":"red"}]
tag @s remove metiers.sk.x14
tag @s remove metiers.skoff.x14
advancement revoke @s only metiers:x/competence_14
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Œil clair est oubliée : 6 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
