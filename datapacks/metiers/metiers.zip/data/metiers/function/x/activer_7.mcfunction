execute unless entity @s[tag=metiers.sk.x7] run return run function metiers:x/arbre
tag @s remove metiers.skoff.x7
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Endurance est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:x/arbre
