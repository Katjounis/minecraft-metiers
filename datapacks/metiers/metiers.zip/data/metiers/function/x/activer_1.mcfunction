execute unless entity @s[tag=metiers.sk.x1] run return run function metiers:x/arbre
tag @s remove metiers.skoff.x1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Grand pas est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:x/arbre
