execute unless entity @s[tag=metiers.sk.x8] run return run function metiers:x/arbre
tag @s remove metiers.skoff.x8
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Saut de géant est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:x/arbre
