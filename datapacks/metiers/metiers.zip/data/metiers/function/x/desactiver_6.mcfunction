execute unless entity @s[tag=metiers.sk.x6] run return run function metiers:x/arbre
tag @s add metiers.skoff.x6
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Grand voyageur est désactivée.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
