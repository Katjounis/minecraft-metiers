execute unless entity @s[tag=metiers.sk.x6] run return run function metiers:x/arbre
tag @s remove metiers.sk.x6
tag @s remove metiers.skoff.x6
advancement revoke @s only metiers:x/competence_6
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Grand voyageur est oubliée : 16 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
