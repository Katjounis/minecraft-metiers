execute if entity @s[tag=metiers.skoff.x13] run return run function metiers:x/choix_off_13
function metiers:x/choix_on_13
