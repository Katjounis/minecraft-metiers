execute unless entity @s[tag=metiers.sk.x13] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x14] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Œil clair, qui a besoin de Pilleur.","color":"red"}]
tag @s remove metiers.sk.x13
tag @s remove metiers.skoff.x13
advancement revoke @s only metiers:x/competence_13
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pilleur est oubliée : 4 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
