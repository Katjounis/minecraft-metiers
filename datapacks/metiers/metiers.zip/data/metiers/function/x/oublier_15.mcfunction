execute unless entity @s[tag=metiers.sk.x15] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x16] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Cartographe, qui a besoin de Tente.","color":"red"}]
tag @s remove metiers.sk.x15
tag @s remove metiers.skoff.x15
advancement revoke @s only metiers:x/competence_15
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tente est oubliée : 8 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
