execute unless entity @s[tag=metiers.sk.x5] run return run function metiers:x/arbre
tag @s add metiers.skoff.x5
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Instinct est désactivée.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
