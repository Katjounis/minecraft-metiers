execute if entity @s[tag=metiers.sk.x9] run return run function metiers:x/basculer_9
execute unless score @s m.x_lvl matches 30.. unless score @s m.x_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 30 en Explorateur.","color":"red"}]
execute unless score @s m.x_lvl matches 30.. unless score @s m.x_pr matches 1.. run return run function metiers:x/arbre
function metiers:x/points
execute unless entity @s[tag=metiers.sk.x8] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Saut de géant.","color":"red"}]
execute unless entity @s[tag=metiers.sk.x8] run return run function metiers:x/arbre
execute if score @s m.tmp matches ..7 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (8 requis).","color":"red"}]
execute if score @s m.tmp matches ..7 run return run function metiers:x/arbre
scoreboard players add @s m.x_spent 8
tag @s add metiers.sk.x9
advancement grant @s only metiers:x/competence_9
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Grimpeur","color":"blue","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:x/arbre
