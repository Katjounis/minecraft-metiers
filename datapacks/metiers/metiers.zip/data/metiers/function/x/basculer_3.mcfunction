execute if entity @s[tag=metiers.skoff.x3] run return run function metiers:x/choix_off_3
function metiers:x/choix_on_3
