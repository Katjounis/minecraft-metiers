execute if entity @s[tag=metiers.skoff.x12] run return run function metiers:x/choix_off_12
function metiers:x/choix_on_12
