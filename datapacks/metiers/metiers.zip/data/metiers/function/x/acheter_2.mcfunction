execute if entity @s[tag=metiers.sk.x2] run return run function metiers:x/basculer_2
execute unless score @s m.x_lvl matches 20.. unless score @s m.x_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 20 en Explorateur.","color":"red"}]
execute unless score @s m.x_lvl matches 20.. unless score @s m.x_pr matches 1.. run return run function metiers:x/arbre
function metiers:x/points
execute unless entity @s[tag=metiers.sk.x1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Grand pas.","color":"red"}]
execute unless entity @s[tag=metiers.sk.x1] run return run function metiers:x/arbre
execute if score @s m.tmp matches ..3 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (4 requis).","color":"red"}]
execute if score @s m.tmp matches ..3 run return run function metiers:x/arbre
scoreboard players add @s m.x_spent 4
tag @s add metiers.sk.x2
advancement grant @s only metiers:x/competence_2
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Coureur des bois","color":"blue","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:x/arbre
