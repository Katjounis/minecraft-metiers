execute if entity @s[tag=metiers.skoff.x11] run return run function metiers:x/choix_off_11
function metiers:x/choix_on_11
