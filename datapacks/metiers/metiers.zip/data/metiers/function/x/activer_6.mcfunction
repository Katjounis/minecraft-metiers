tag @s remove metiers.skoff.x6
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Grand voyageur est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:x/arbre
