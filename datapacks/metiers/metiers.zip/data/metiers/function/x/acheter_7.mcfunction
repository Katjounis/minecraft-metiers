execute if entity @s[tag=metiers.sk.x7] run return run function metiers:x/basculer_7
execute unless score @s m.x_lvl matches 10.. unless score @s m.x_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 10 en Explorateur.","color":"red"}]
execute unless score @s m.x_lvl matches 10.. unless score @s m.x_pr matches 1.. run return run function metiers:x/arbre
function metiers:x/points
execute unless entity @s[tag=metiers.sk.x1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Grand pas.","color":"red"}]
execute unless entity @s[tag=metiers.sk.x1] run return run function metiers:x/arbre
execute if score @s m.tmp matches ..3 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (4 requis).","color":"red"}]
execute if score @s m.tmp matches ..3 run return run function metiers:x/arbre
scoreboard players add @s m.x_spent 4
tag @s add metiers.sk.x7
advancement grant @s only metiers:x/competence_7
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Endurance","color":"blue","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:x/arbre
