execute if entity @s[tag=metiers.skoff.x14] run return run function metiers:x/choix_off_14
function metiers:x/choix_on_14
