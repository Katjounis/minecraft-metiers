function metiers:places
execute if score @s m.tmp matches ..1 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Inventaire plein ! Libère 2 emplacements puis réessaie (/trigger metiers > Récompenses).","color":"red"}]
execute if score @s m.tmp matches ..1 run playsound minecraft:entity.villager.no master @s ~ ~ ~ 1 1
execute if score @s m.tmp matches ..1 run return 0
scoreboard players set @s m.x_pal 3
scoreboard players add @s m.cr_x 15
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.ecus 2000
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.a_met 2000
give @s minecraft:ender_pearl 8
give @s minecraft:experience_bottle 32
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" récupère sa récompense","color":"gray"},{"text":" (palier 30 Explorateur)","color":"gray"}]
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Dont +2000 Écus sur ton compte.","color":"gold"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 0.6
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.3 60
function metiers:recompenses
