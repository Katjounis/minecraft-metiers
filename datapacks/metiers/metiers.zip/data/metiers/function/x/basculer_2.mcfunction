execute if entity @s[tag=metiers.skoff.x2] run return run function metiers:x/activer_2
tag @s add metiers.skoff.x2
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Coureur des bois est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
