execute if entity @s[tag=metiers.skoff.x2] run return run function metiers:x/choix_off_2
function metiers:x/choix_on_2
