execute if entity @s[tag=metiers.skoff.x6] run return run function metiers:x/choix_off_6
function metiers:x/choix_on_6
