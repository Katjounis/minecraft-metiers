execute if entity @s[tag=metiers.skoff.x6] run return run function metiers:x/activer_6
tag @s add metiers.skoff.x6
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Grand voyageur est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
