execute unless entity @s[tag=metiers.sk.x9] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x10] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Grimpeur, qui a besoin de Ailes.","color":"red"}]
tag @s remove metiers.sk.x9
tag @s remove metiers.skoff.x9
advancement revoke @s only metiers:x/competence_9
function metiers:objets/retirer_elytres
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ailes est oubliée : 8 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
