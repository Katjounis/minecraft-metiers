scoreboard players operation @s m.gain = @s m.x_bal
scoreboard players set @s m.x_bal 0
scoreboard players operation @s m.tmp = @s m.gain
scoreboard players operation @s m.tmp *= @s m.x_pr
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.gain += @s m.tmp
execute if score @s c.gn matches 3..4 run scoreboard players operation @s m.tmp = @s m.gain
execute if score @s c.gn matches 3..4 run scoreboard players operation @s m.tmp /= #20 m.const
execute if score @s c.gn matches 5.. run scoreboard players operation @s m.tmp = @s m.gain
execute if score @s c.gn matches 5.. run scoreboard players operation @s m.tmp /= #10 m.const
execute if score @s c.gn matches 3.. run scoreboard players operation @s m.gain += @s m.tmp
execute if score #job m.heure matches 8 run scoreboard players operation @s m.gain *= #2 m.const
execute if score @s m.csag_x matches 1 run function metiers:refonte/sagesse
execute if score @s m.ceco_x matches 1 store result score #r m.tmp run random value 1..100
execute if score @s m.ceco_x matches 1 if score #r m.tmp matches ..5 run scoreboard players add @s m.cr_x 1
execute if score @s m.x_lvl matches 100.. run return 0
scoreboard players operation @s m.x_xp += @s m.gain
function metiers:x/check
title @s actionbar [{"text":"+","color":"green"},{"score":{"name":"@s","objective":"m.gain"},"color":"green"},{"text":" XP Explorateur","color":"blue"},{"text":"  |  niv ","color":"gray"},{"score":{"name":"@s","objective":"m.x_lvl"},"color":"white"},{"text":"  (","color":"gray"},{"score":{"name":"@s","objective":"m.x_xp"},"color":"white"},{"text":"/","color":"gray"},{"score":{"name":"@s","objective":"m.x_need"},"color":"white"},{"text":")","color":"gray"}]
execute if score @s m.gid matches 1.. run scoreboard players operation @s m.gxp += @s m.gain
