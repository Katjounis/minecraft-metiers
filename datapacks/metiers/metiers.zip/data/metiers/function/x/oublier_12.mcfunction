execute unless entity @s[tag=metiers.sk.x12] run return run function metiers:x/arbre
tag @s remove metiers.sk.x12
tag @s remove metiers.skoff.x12
advancement revoke @s only metiers:x/competence_12
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Vent arrière est oubliée : 14 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
