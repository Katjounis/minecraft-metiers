scoreboard players set #vue m.tmp 1
function metiers:x/arbre
