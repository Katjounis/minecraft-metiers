execute if entity @s[tag=metiers.skoff.x9] run return run function metiers:x/activer_9
tag @s add metiers.skoff.x9
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ailes est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
function metiers:objets/retirer_elytres
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
