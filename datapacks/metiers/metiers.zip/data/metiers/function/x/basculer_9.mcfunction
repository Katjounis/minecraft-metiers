execute if entity @s[tag=metiers.skoff.x9] run return run function metiers:x/choix_off_9
function metiers:x/choix_on_9
