execute unless entity @s[tag=metiers.sk.x17] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x18] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Butin légendaire, qui a besoin de Sac étanche.","color":"red"}]
tag @s remove metiers.sk.x17
tag @s remove metiers.skoff.x17
advancement revoke @s only metiers:x/competence_17
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Sac étanche est oubliée : 12 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
