execute if entity @s[tag=metiers.skoff.x1] run return run function metiers:x/choix_off_1
function metiers:x/choix_on_1
