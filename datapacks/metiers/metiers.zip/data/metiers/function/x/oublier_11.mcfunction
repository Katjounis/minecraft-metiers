execute unless entity @s[tag=metiers.sk.x11] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x12] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Vent arrière, qui a besoin de Propulseur.","color":"red"}]
tag @s remove metiers.sk.x11
tag @s remove metiers.skoff.x11
advancement revoke @s only metiers:x/competence_11
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Propulseur est oubliée : 12 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
