execute unless entity @s[tag=metiers.sk.x16] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x17] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Sac étanche, qui a besoin de Cartographe.","color":"red"}]
tag @s remove metiers.sk.x16
tag @s remove metiers.skoff.x16
advancement revoke @s only metiers:x/competence_16
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cartographe est oubliée : 10 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
