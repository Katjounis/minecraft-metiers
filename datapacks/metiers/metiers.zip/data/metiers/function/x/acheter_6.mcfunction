execute if entity @s[tag=metiers.sk.x6] run return run function metiers:x/basculer_6
execute unless score @s m.x_lvl matches 70.. unless score @s m.x_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 70 en Explorateur.","color":"red"}]
execute unless score @s m.x_lvl matches 70.. unless score @s m.x_pr matches 1.. run return run function metiers:x/arbre
function metiers:x/points
execute unless entity @s[tag=metiers.sk.x4,tag=metiers.sk.x5] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Foulée du vent + Instinct.","color":"red"}]
execute unless entity @s[tag=metiers.sk.x4,tag=metiers.sk.x5] run return run function metiers:x/arbre
execute if score @s m.tmp matches ..31 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (32 requis).","color":"red"}]
execute if score @s m.tmp matches ..31 run return run function metiers:x/arbre
scoreboard players add @s m.x_spent 32
tag @s add metiers.sk.x6
advancement grant @s only metiers:x/competence_6
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Grand voyageur","color":"blue","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:x/arbre
