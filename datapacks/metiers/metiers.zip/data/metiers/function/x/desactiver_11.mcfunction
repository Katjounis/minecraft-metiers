execute unless entity @s[tag=metiers.sk.x11] run return run function metiers:x/arbre
tag @s add metiers.skoff.x11
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Propulseur est désactivée.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
