execute if entity @s[tag=metiers.skoff.x4] run return run function metiers:x/activer_4
tag @s add metiers.skoff.x4
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Foulée du vent est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
