execute if entity @s[tag=metiers.skoff.x4] run return run function metiers:x/choix_off_4
function metiers:x/choix_on_4
