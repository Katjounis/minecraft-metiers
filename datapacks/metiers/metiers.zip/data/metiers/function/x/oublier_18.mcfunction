execute unless entity @s[tag=metiers.sk.x18] run return run function metiers:x/arbre
tag @s remove metiers.sk.x18
tag @s remove metiers.skoff.x18
advancement revoke @s only metiers:x/competence_18
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Butin légendaire est oubliée : 14 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
