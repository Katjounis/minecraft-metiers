execute if entity @s[tag=metiers.skoff.x17] run return run function metiers:x/choix_off_17
function metiers:x/choix_on_17
