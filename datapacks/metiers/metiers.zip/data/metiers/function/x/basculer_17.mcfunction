execute if entity @s[tag=metiers.skoff.x17] run return run function metiers:x/activer_17
tag @s add metiers.skoff.x17
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Sac étanche est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
