execute if entity @s[tag=metiers.skoff.x7] run return run function metiers:x/choix_off_7
function metiers:x/choix_on_7
