execute if entity @s[tag=metiers.skoff.x18] run return run function metiers:x/activer_18
tag @s add metiers.skoff.x18
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Butin légendaire est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
