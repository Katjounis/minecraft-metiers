execute if entity @s[tag=metiers.skoff.x18] run return run function metiers:x/choix_off_18
function metiers:x/choix_on_18
