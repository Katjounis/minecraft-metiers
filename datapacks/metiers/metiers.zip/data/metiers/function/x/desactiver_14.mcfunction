execute unless entity @s[tag=metiers.sk.x14] run return run function metiers:x/arbre
tag @s add metiers.skoff.x14
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Œil clair est désactivée.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
