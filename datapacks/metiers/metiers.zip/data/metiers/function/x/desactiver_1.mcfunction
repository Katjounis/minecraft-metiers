execute unless entity @s[tag=metiers.sk.x1] run return run function metiers:x/arbre
tag @s add metiers.skoff.x1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Grand pas est désactivée.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
