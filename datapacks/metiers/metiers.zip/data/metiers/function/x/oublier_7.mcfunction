execute unless entity @s[tag=metiers.sk.x7] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x8] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Saut de géant, qui a besoin de Endurance.","color":"red"}]
tag @s remove metiers.sk.x7
tag @s remove metiers.skoff.x7
advancement revoke @s only metiers:x/competence_7
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Endurance est oubliée : 4 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
