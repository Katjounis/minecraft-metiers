execute if entity @s[tag=metiers.skoff.x10] run return run function metiers:x/choix_off_10
function metiers:x/choix_on_10
