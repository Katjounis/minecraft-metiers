scoreboard players add @s m.x_bal 40
title @s actionbar {"text":"Nouvelle découverte : +40 XP Explorateur","color":"blue"}
playsound minecraft:ui.toast.in master @s ~ ~ ~ 0.6 1.4
