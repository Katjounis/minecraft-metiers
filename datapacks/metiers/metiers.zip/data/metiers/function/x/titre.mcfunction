execute if score @s m.pref matches 8 run scoreboard players set @s m.trig 10
execute unless score @s m.pref matches 8 run scoreboard players set @s m.trig 18
function metiers:prefixe/choisir
scoreboard players set #vue m.tmp 2
function metiers:x/arbre
