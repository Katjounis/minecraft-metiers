scoreboard players operation #L m.tmp = @s m.x_lvl
function metiers:xp/table
scoreboard players operation @s m.x_need = #N m.tmp
scoreboard players operation #N m.tmp = @s m.x_pr
scoreboard players operation #N m.tmp *= #F99 m.const
scoreboard players operation @s m.x_need > #N m.tmp
execute if score @s m.x_lvl matches ..99 if score @s m.x_xp >= @s m.x_need run function metiers:x/levelup
