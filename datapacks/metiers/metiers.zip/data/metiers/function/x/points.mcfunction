scoreboard players set @s m.x_spent 0
execute if entity @s[tag=metiers.sk.x1] run scoreboard players add @s m.x_spent 3
execute if entity @s[tag=metiers.sk.x2] run scoreboard players add @s m.x_spent 4
execute if entity @s[tag=metiers.sk.x3] run scoreboard players add @s m.x_spent 6
execute if entity @s[tag=metiers.sk.x4] run scoreboard players add @s m.x_spent 8
execute if entity @s[tag=metiers.sk.x5] run scoreboard players add @s m.x_spent 12
execute if entity @s[tag=metiers.sk.x6] run scoreboard players add @s m.x_spent 16
execute if entity @s[tag=metiers.sk.x7] run scoreboard players add @s m.x_spent 4
execute if entity @s[tag=metiers.sk.x8] run scoreboard players add @s m.x_spent 6
execute if entity @s[tag=metiers.sk.x9] run scoreboard players add @s m.x_spent 8
execute if entity @s[tag=metiers.sk.x10] run scoreboard players add @s m.x_spent 10
execute if entity @s[tag=metiers.sk.x11] run scoreboard players add @s m.x_spent 12
execute if entity @s[tag=metiers.sk.x12] run scoreboard players add @s m.x_spent 14
execute if entity @s[tag=metiers.sk.x13] run scoreboard players add @s m.x_spent 4
execute if entity @s[tag=metiers.sk.x14] run scoreboard players add @s m.x_spent 6
execute if entity @s[tag=metiers.sk.x15] run scoreboard players add @s m.x_spent 8
execute if entity @s[tag=metiers.sk.x16] run scoreboard players add @s m.x_spent 10
execute if entity @s[tag=metiers.sk.x17] run scoreboard players add @s m.x_spent 12
execute if entity @s[tag=metiers.sk.x18] run scoreboard players add @s m.x_spent 14
scoreboard players operation @s m.tmp = @s m.x_lvl
scoreboard players remove @s m.tmp 1
scoreboard players operation @s m.tmp -= @s m.x_spent
scoreboard players operation #ppr m.tmp = @s m.x_pr
scoreboard players operation #ppr m.tmp *= #99 m.const
scoreboard players operation @s m.tmp += #ppr m.tmp
