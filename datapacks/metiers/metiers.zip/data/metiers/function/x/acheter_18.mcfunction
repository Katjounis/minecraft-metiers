execute if entity @s[tag=metiers.sk.x18] run return run function metiers:x/basculer_18
execute unless score @s m.x_lvl matches 80.. unless score @s m.x_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 80 en Explorateur.","color":"red"}]
execute unless score @s m.x_lvl matches 80.. unless score @s m.x_pr matches 1.. run return run function metiers:x/arbre
function metiers:x/points
execute unless entity @s[tag=metiers.sk.x17] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Sac étanche.","color":"red"}]
execute unless entity @s[tag=metiers.sk.x17] run return run function metiers:x/arbre
execute if score @s m.tmp matches ..13 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (14 requis).","color":"red"}]
execute if score @s m.tmp matches ..13 run return run function metiers:x/arbre
scoreboard players add @s m.x_spent 14
tag @s add metiers.sk.x18
advancement grant @s only metiers:x/competence_18
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Butin légendaire","color":"blue","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:x/arbre
