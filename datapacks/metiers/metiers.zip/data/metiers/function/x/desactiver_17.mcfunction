execute unless entity @s[tag=metiers.sk.x17] run return run function metiers:x/arbre
tag @s add metiers.skoff.x17
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Sac étanche est désactivée.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
