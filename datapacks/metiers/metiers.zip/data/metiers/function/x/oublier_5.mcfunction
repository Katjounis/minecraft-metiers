execute unless entity @s[tag=metiers.sk.x5] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x6] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Grand voyageur, qui a besoin de Instinct.","color":"red"}]
tag @s remove metiers.sk.x5
tag @s remove metiers.skoff.x5
advancement revoke @s only metiers:x/competence_5
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Instinct est oubliée : 12 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
