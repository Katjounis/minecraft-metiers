execute unless entity @s[tag=metiers.sk.x14] run return run function metiers:x/arbre
tag @s remove metiers.skoff.x14
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Œil clair est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:x/arbre
