tag @s remove metiers.skoff.x16
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cartographe est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:x/arbre
