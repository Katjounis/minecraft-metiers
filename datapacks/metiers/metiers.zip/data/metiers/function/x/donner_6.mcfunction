function metiers:places
execute if score @s m.tmp matches ..1 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Inventaire plein ! Libère 2 emplacements puis réessaie (/trigger metiers > Récompenses).","color":"red"}]
execute if score @s m.tmp matches ..1 run playsound minecraft:entity.villager.no master @s ~ ~ ~ 1 1
execute if score @s m.tmp matches ..1 run return 0
scoreboard players set @s m.x_pal 6
scoreboard players add @s m.cr_x 45
scoreboard players add @s m.ecl 2
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.ecus 8000
give @s minecraft:ender_pearl 16
give @s minecraft:enchanted_golden_apple 1
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" récupère sa récompense","color":"gray"},{"text":" (palier 60 Explorateur)","color":"gray"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 0.6
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.3 60
function metiers:recompenses
function metiers:objets/donner_elytres
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Palier 6 : des élytres incassables sont dans ton inventaire.","color":"blue"}]
