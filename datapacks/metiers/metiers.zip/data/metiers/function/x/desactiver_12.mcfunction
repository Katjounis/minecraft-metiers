execute unless entity @s[tag=metiers.sk.x12] run return run function metiers:x/arbre
tag @s add metiers.skoff.x12
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Vent arrière est désactivée.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
