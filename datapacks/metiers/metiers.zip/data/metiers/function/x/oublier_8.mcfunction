execute unless entity @s[tag=metiers.sk.x8] run return run function metiers:x/arbre
execute if entity @s[tag=metiers.sk.x9] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Ailes, qui a besoin de Saut de géant.","color":"red"}]
tag @s remove metiers.sk.x8
tag @s remove metiers.skoff.x8
advancement revoke @s only metiers:x/competence_8
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Saut de géant est oubliée : 6 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:x/arbre
