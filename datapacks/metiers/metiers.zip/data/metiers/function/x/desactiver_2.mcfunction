execute unless entity @s[tag=metiers.sk.x2] run return run function metiers:x/arbre
tag @s add metiers.skoff.x2
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Coureur des bois est désactivée.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:x/arbre
