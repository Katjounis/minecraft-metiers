function metiers:guilde/nom
execute store result storage metiers:gu a.g int 1 run scoreboard players get @s m.gid
execute store result storage metiers:gu a.id int 1 run scoreboard players get @s m.id
data modify storage metiers:gu a.nom set from storage metiers:gu moi
function metiers:guilde/ajouter_m with storage metiers:gu a
