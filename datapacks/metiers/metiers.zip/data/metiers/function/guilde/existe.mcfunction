return run function metiers:guilde/existe_m with storage metiers:gu a
