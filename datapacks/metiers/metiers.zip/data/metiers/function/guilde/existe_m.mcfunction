$execute if data storage metiers:gu L[{id:$(g)}] run return 1
return fail
