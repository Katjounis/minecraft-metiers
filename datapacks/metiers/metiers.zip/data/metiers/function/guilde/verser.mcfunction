execute store result storage metiers:gu a.g int 1 run scoreboard players get @s m.gid
execute store result storage metiers:gu a.x int 1 run scoreboard players get @s m.gxp
scoreboard players set @s m.gxp 0
function metiers:guilde/verser_m with storage metiers:gu a
