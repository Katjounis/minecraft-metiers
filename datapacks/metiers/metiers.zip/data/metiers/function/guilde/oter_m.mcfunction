$data remove storage metiers:gu L[{id:$(g)}].mem[{id:$(id)}]
$execute unless data storage metiers:gu L[{id:$(g)}].mem[0] run return run data remove storage metiers:gu L[{id:$(g)}]
$execute if data storage metiers:gu L[{id:$(g),chef:$(id)}] run data modify storage metiers:gu L[{id:$(g)}].chef set from storage metiers:gu L[{id:$(g)}].mem[0].id
