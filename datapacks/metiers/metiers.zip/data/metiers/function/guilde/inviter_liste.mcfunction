execute unless function metiers:guilde/suis_chef run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Seul le chef de la guilde invite.","color":"red"}]
data modify storage metiers:gu D set value [{text:""}]
execute as @a[scores={m.gid=..0}] run function metiers:guilde/inviter_ligne
execute as @a unless score @s m.gid matches -2147483648.. run function metiers:guilde/inviter_ligne
function metiers:guilde/inviter_d with storage metiers:gu
