$data modify storage metiers:gu L[{id:$(g)}].mem append value {id:$(id),nom:"$(nom)"}
