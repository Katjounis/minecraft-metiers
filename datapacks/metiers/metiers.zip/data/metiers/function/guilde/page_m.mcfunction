$data modify storage metiers:gu p set from storage metiers:gu L[{id:$(g)}]
function metiers:guilde/objectif with storage metiers:gu a
execute store result storage metiers:gu p.x int 1 run scoreboard players get #gx m.tmp
execute store result storage metiers:gu p.o int 1 run scoreboard players get #gobj m.tmp
data modify storage metiers:gu p.ok set value ""
execute if score @s m.gwk = #gweek m.const run data modify storage metiers:gu p.ok set value "  ✔ réussi"
data modify storage metiers:gu M set value [{text:""}]
data modify storage metiers:gu W set from storage metiers:gu p.mem
function metiers:guilde/membres
function metiers:guilde/classement
function metiers:guilde/page_d with storage metiers:gu p
