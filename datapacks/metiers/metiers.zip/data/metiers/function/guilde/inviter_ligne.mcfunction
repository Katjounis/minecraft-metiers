function metiers:guilde/nom
execute store result storage metiers:gu b.id int 1 run scoreboard players get @s m.id
scoreboard players set #tv m.tmp 7100000
scoreboard players operation #tv m.tmp += @s m.id
execute store result storage metiers:gu b.v int 1 run scoreboard players get #tv m.tmp
data modify storage metiers:gu b.nom set from storage metiers:gu moi
function metiers:guilde/inviter_ligne_m with storage metiers:gu b
