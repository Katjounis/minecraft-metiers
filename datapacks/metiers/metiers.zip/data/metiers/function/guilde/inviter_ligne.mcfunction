function metiers:guilde/nom
execute store result storage metiers:gu b.id int 1 run scoreboard players get @s m.id
data modify storage metiers:gu b.nom set from storage metiers:gu moi
function metiers:guilde/inviter_ligne_m with storage metiers:gu b
