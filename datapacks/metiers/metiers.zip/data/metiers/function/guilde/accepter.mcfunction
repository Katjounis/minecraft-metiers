execute if score @s m.gid matches 1.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Quitte d’abord ta guilde.","color":"red"}]
execute unless score @s m.ginv matches 1.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucune invitation en attente.","color":"red"}]
execute store result storage metiers:gu a.g int 1 run scoreboard players get @s m.ginv
execute unless function metiers:guilde/existe run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cette guilde n’existe plus.","color":"red"}]
scoreboard players operation @s m.gid = @s m.ginv
scoreboard players set @s m.ginv 0
scoreboard players operation @s m.gwk = #gweek m.const
function metiers:guilde/ajouter_moi
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" rejoint une guilde.","color":"gold"}]
function metiers:guilde/page
