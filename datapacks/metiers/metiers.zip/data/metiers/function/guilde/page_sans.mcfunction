function metiers:guilde/classement
function metiers:guilde/page_sans_d with storage metiers:gu
