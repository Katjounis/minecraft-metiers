execute unless function metiers:guilde/suis_chef run return 0
scoreboard players operation #cible m.tmp = @s m.trig
scoreboard players remove #cible m.tmp 7100000
scoreboard players operation #g m.tmp = @s m.gid
execute as @a if score @s m.id = #cible m.tmp run function metiers:guilde/invite_recu
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Invitation envoyée.","color":"green"}]
