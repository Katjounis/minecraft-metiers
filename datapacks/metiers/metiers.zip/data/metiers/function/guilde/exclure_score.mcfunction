$scoreboard players set $(nom) m.gid 0
$tellraw @a[name=$(nom)] [{"text":"[Métiers] ","color":"gold"},{"text":"Tu as été exclu de ta guilde.","color":"red"}]
