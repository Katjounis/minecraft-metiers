execute unless function metiers:guilde/suis_chef run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Seul le chef exclut.","color":"red"}]
scoreboard players operation #cible m.tmp = @s m.trig
scoreboard players remove #cible m.tmp 7200000
execute if score #cible m.tmp = @s m.id run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pour partir, utilise « Quitter ».","color":"red"}]
execute store result storage metiers:gu a.id int 1 run scoreboard players get #cible m.tmp
data modify storage metiers:gu a.nom set value ""
function metiers:guilde/exclure_m with storage metiers:gu a
function metiers:guilde/page
