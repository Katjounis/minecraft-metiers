execute unless data storage metiers:gu W2[0] run return 0
execute store result score #x m.tmp run data get storage metiers:gu W2[0].pts
execute if score #x m.tmp > #m m.tmp run data modify storage metiers:gu best set from storage metiers:gu W2[0]
execute if score #x m.tmp > #m m.tmp run scoreboard players operation #m m.tmp = #x m.tmp
data remove storage metiers:gu W2[0]
function metiers:guilde/max
