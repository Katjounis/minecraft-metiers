execute if score #rk m.tmp matches 5.. run return 0
execute unless data storage metiers:gu W[0] run return 0
scoreboard players set #m m.tmp -1
data modify storage metiers:gu W2 set from storage metiers:gu W
function metiers:guilde/max
scoreboard players add #rk m.tmp 1
execute store result storage metiers:gu best.r int 1 run scoreboard players get #rk m.tmp
function metiers:guilde/rang_ligne with storage metiers:gu best
function metiers:guilde/rang_oter with storage metiers:gu best
function metiers:guilde/rang
