execute unless score @s m.gid matches 1.. run return run function metiers:guilde/page_sans
execute store result storage metiers:gu a.g int 1 run scoreboard players get @s m.gid
function metiers:guilde/page_m with storage metiers:gu a
