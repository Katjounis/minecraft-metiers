$data modify storage metiers:gu a.nom set from storage metiers:gu L[{id:$(g)}].mem[{id:$(id)}].nom
$data remove storage metiers:gu L[{id:$(g)}].mem[{id:$(id)}]
function metiers:guilde/exclure_score with storage metiers:gu a
