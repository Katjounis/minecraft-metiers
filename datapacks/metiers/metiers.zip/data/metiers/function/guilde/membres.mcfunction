execute unless data storage metiers:gu W[0] run return 0
scoreboard players set #tv m.tmp 7200000
execute store result score #ti m.tmp run data get storage metiers:gu W[0].id
scoreboard players operation #tv m.tmp += #ti m.tmp
execute store result storage metiers:gu W[0].v int 1 run scoreboard players get #tv m.tmp
function metiers:guilde/membre_m with storage metiers:gu W[0]
data remove storage metiers:gu W[0]
function metiers:guilde/membres
