execute unless data storage metiers:gu W[0] run return 0
function metiers:guilde/membre_m with storage metiers:gu W[0]
data remove storage metiers:gu W[0]
function metiers:guilde/membres
