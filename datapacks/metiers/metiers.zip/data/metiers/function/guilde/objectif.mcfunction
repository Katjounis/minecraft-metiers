scoreboard players set #gx m.tmp 0
$execute store result score #gx m.tmp run scoreboard players get #g$(g) m.gxpt
$execute store result score #gobj m.tmp run data get storage metiers:gu L[{id:$(g)}].mem
scoreboard players operation #gobj m.tmp *= #5000 m.const
