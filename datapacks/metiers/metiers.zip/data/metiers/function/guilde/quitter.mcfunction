execute unless score @s m.gid matches 1.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu n’es dans aucune guilde.","color":"red"}]
execute store result storage metiers:gu a.g int 1 run scoreboard players get @s m.gid
execute store result storage metiers:gu a.id int 1 run scoreboard players get @s m.id
function metiers:guilde/oter_m with storage metiers:gu a
scoreboard players set @s m.gid 0
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu as quitté ta guilde.","color":"yellow"}]
function metiers:guilde/page
