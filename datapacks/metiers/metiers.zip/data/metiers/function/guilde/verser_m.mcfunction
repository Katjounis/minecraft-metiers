$scoreboard players add #g$(g) m.gxpt $(x)
$execute store result score #p m.tmp run data get storage metiers:gu L[{id:$(g)}].pts
$scoreboard players add #p m.tmp $(x)
$execute store result storage metiers:gu L[{id:$(g)}].pts int 1 run scoreboard players get #p m.tmp
