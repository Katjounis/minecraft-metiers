execute unless score @s m.gid matches 1.. run return fail
execute store result storage metiers:gu a.g int 1 run scoreboard players get @s m.gid
execute store result storage metiers:gu a.id int 1 run scoreboard players get @s m.id
return run function metiers:guilde/suis_chef_m with storage metiers:gu a
