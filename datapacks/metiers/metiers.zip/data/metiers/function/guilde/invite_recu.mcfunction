scoreboard players operation @s m.ginv = #g m.tmp
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu es invité dans une guilde ! ","color":"gold"},{"text":"[Accepter]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger metiers set 705"}}]
playsound minecraft:block.note_block.bell master @s ~ ~ ~ 1 1.5
