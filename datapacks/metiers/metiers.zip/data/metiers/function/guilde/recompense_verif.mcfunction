execute store result storage metiers:gu a.g int 1 run scoreboard players get @s m.gid
function metiers:guilde/objectif with storage metiers:gu a
execute unless score #gx m.tmp >= #gobj m.tmp run return 0
scoreboard players operation @s m.gwk = #gweek m.const
scoreboard players add @s m.ecl 3
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Défi de guilde de la semaine réussi : +3 éclats de boss !","color":"gold"}]
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.1
