data modify storage metiers:gu R set value [{text:""}]
data modify storage metiers:gu W set from storage metiers:gu L
scoreboard players set #rk m.tmp 0
function metiers:guilde/rang
