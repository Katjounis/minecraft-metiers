execute if score @s m.gid matches 1.. if score @s m.gxp matches 1.. run function metiers:guilde/verser
execute if score @s m.gid matches 1.. unless score @s m.gwk = #gweek m.const run function metiers:guilde/recompense_verif
