$data modify storage metiers:gu n.nomc set value {text:"Guilde de $(moi)"}
