$execute if data storage metiers:gu L[{id:$(g),chef:$(id)}] run return 1
return fail
