$data remove storage metiers:gu W[{id:$(id)}]
