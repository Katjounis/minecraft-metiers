$data modify storage metiers:gu R append value {text:"$(r). ",color:"gray"}
$data modify storage metiers:gu R append value $(nomc)
$data modify storage metiers:gu R append value {text:"   $(pts) XP\n",color:"gold"}
