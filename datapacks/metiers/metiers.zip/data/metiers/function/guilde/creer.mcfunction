execute if score @s m.gid matches 1.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu es déjà dans une guilde.","color":"red"}]
scoreboard players add #gidn m.const 1
scoreboard players operation @s m.gid = #gidn m.const
function metiers:guilde/nom
data modify storage metiers:gu n set value {mem:[],pts:0}
execute store result storage metiers:gu n.id int 1 run scoreboard players get #gidn m.const
execute store result storage metiers:gu n.chef int 1 run scoreboard players get @s m.id
function metiers:guilde/nom_guilde with storage metiers:gu
execute if data entity @s SelectedItem.components."minecraft:custom_name" run data modify storage metiers:gu n.nomc set from entity @s SelectedItem.components."minecraft:custom_name"
data modify storage metiers:gu L append from storage metiers:gu n
function metiers:guilde/ajouter_moi
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" fonde une guilde !","color":"gold","bold":true}]
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
function metiers:guilde/page
