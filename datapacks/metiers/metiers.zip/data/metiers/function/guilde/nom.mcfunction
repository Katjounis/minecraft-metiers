data modify storage metiers:gu moi set value "?"
summon minecraft:item_display ~ ~-2 ~ {Tags:["metiers.nomeur"],item:{id:"minecraft:paper",count:1}}
item modify entity @e[type=minecraft:item_display,tag=metiers.nomeur,limit=1] contents {function:"minecraft:set_name",type:"minecraft:set_name",entity:"this",target:"custom_name",name:{selector:"@s"}}
data modify storage metiers:gu moi set from entity @e[type=minecraft:item_display,tag=metiers.nomeur,limit=1] item.components."minecraft:custom_name".text
execute unless data entity @e[type=minecraft:item_display,tag=metiers.nomeur,limit=1] item.components."minecraft:custom_name".text run data modify storage metiers:gu moi set from entity @e[type=minecraft:item_display,tag=metiers.nomeur,limit=1] item.components."minecraft:custom_name"
kill @e[type=minecraft:item_display,tag=metiers.nomeur]
