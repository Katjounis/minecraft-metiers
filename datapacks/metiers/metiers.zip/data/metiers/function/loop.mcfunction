scoreboard players add #t m.timer 1
scoreboard players operation #pair m.timer = #t m.timer
scoreboard players operation #pair m.timer %= #2 m.const
scoreboard players operation #quatre m.timer = #t m.timer
scoreboard players operation #quatre m.timer %= #4 m.const
scoreboard players operation #huit m.timer = #t m.timer
scoreboard players operation #huit m.timer %= #8 m.const
scoreboard players operation #soixante m.timer = #t m.timer
scoreboard players operation #soixante m.timer %= #60 m.const
scoreboard players operation #vingt m.timer = #t m.timer
scoreboard players operation #vingt m.timer %= #20 m.const
function metiers:appel {f:"heure/tick"}
function metiers:appel {f:"defis/tick"}
function metiers:appel {f:"boss/tick"}
execute as @a[tag=!metiers.ok] run function metiers:init
execute as @a at @s run function metiers:joueur
execute if score #t m.timer matches 120.. run scoreboard players set #t m.timer 0
schedule function metiers:loop 10t replace
execute as @e[scores={m.saig=1..}] at @s run function metiers:comp/saigne
function metiers:objets/poses
execute as @a if score @s m.ocd matches 1.. run scoreboard players remove @s m.ocd 1
