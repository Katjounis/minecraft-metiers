execute if score @s m.so_x3 matches 1 if score @s m.skin_x matches 3 run return run function metiers:skins/equiper {t:"x",i:0}
execute if score @s m.so_x3 matches 1 run return run function metiers:skins/equiper {t:"x",i:3}
execute unless score @s m.cr_x matches 180.. if score @s m.ecl matches 2.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore débloqué : regarde le prix ou la condition au survol.","color":"red"}]
scoreboard players remove @s m.cr_x 180
scoreboard players remove @s m.ecl 2
scoreboard players set @s m.so_x3 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Or royal débloqué.","color":"light_purple"}]
function metiers:skins/equiper {t:"x",i:3}
