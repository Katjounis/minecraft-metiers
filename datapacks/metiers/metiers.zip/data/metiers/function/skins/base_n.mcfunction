function metiers:skins/equiper {t:"n",i:0}
