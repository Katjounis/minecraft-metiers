execute if score @s m.so_a12 matches 1 if score @s m.skin_a matches 12 run return run function metiers:skins/equiper {t:"a",i:0}
execute if score @s m.so_a12 matches 1 run return run function metiers:skins/equiper {t:"a",i:12}
scoreboard players set #ok m.tmp 0
execute if score @s m.prtot matches 5.. if score @s m.ecl matches 25.. if score @s c.ecus matches 250000.. run scoreboard players set #ok m.tmp 1
execute if score #ok m.tmp matches 0 run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore : 5 prestiges au total, puis 25 éclats de boss et 250 000 Écus.","color":"red"}]
scoreboard players remove @s m.ecl 25
scoreboard players remove @s c.ecus 250000
scoreboard players remove @s c.a_met 250000
scoreboard players set @s m.so_a12 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Éclipse débloqué !","color":"light_purple"}]
execute at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.8 0.4 0.3 40
function metiers:skins/equiper {t:"a",i:12}
