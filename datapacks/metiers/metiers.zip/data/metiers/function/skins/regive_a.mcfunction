execute if score @s m.arm matches 1.. if items entity @s armor.* *[minecraft:custom_data~{metiers_armure:1b}] run function metiers:armure/donner
execute if score @s m.arm matches 1.. if items entity @s container.* *[minecraft:custom_data~{metiers_armure:1b}] run function metiers:armure/donner
