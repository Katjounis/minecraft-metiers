scoreboard players add @s m.skt 0
scoreboard players set @s m.prtot 0
scoreboard players operation @s m.prtot += @s m.b_pr
scoreboard players operation @s m.prtot += @s m.f_pr
scoreboard players operation @s m.prtot += @s m.m_pr
scoreboard players operation @s m.prtot += @s m.c_pr
scoreboard players operation @s m.prtot += @s m.p_pr
scoreboard players operation @s m.prtot += @s m.e_pr
scoreboard players operation @s m.prtot += @s m.n_pr
scoreboard players operation @s m.prtot += @s m.x_pr
scoreboard players operation @s m.prtot += @s m.t_pr
execute store result storage metiers:sk ecl int 1 run scoreboard players get @s m.ecl
scoreboard players add @s m.cd_1 0
execute if score @s m.skt matches 0 run data modify storage metiers:sk cible set value "Armure des Guildes"
execute if score @s m.skt matches 0 run function metiers:skins/infos_a
execute if score @s m.skt matches 1 run data modify storage metiers:sk cible set value "Hache de Bûcheron"
execute if score @s m.skt matches 1 run function metiers:skins/infos_b
execute if score @s m.skt matches 2 run data modify storage metiers:sk cible set value "Houe de Fermier"
execute if score @s m.skt matches 2 run function metiers:skins/infos_f
execute if score @s m.skt matches 3 run data modify storage metiers:sk cible set value "Pioche de Mineur"
execute if score @s m.skt matches 3 run function metiers:skins/infos_m
execute if score @s m.skt matches 4 run data modify storage metiers:sk cible set value "Lame de Chasseur"
execute if score @s m.skt matches 4 run function metiers:skins/infos_c
execute if score @s m.skt matches 5 run data modify storage metiers:sk cible set value "Canne de Pêcheur"
execute if score @s m.skt matches 5 run function metiers:skins/infos_p
execute if score @s m.skt matches 6 run data modify storage metiers:sk cible set value "Houlette d'Éleveur"
execute if score @s m.skt matches 6 run function metiers:skins/infos_e
execute if score @s m.skt matches 7 run data modify storage metiers:sk cible set value "Grimoire d'Enchanteur"
execute if score @s m.skt matches 7 run function metiers:skins/infos_n
execute if score @s m.skt matches 8 run data modify storage metiers:sk cible set value "Pelle d'Explorateur"
execute if score @s m.skt matches 8 run function metiers:skins/infos_x
execute if score @s m.skt matches 9 run data modify storage metiers:sk cible set value "Bourse de Marchand"
execute if score @s m.skt matches 9 run function metiers:skins/infos_t
data modify storage metiers:sk f1 set value "dark_gray"
data modify storage metiers:sk f1 set value "yellow"
data modify storage metiers:sk e1 set value ""
execute if score @s m.cd_1 matches 1 run data modify storage metiers:sk f1 set value "green"
execute if score @s m.cadre matches 1 run data modify storage metiers:sk e1 set value " ★"
data modify storage metiers:sk f2 set value "dark_gray"
execute if score @s m.ecl matches 3.. run data modify storage metiers:sk f2 set value "yellow"
execute unless score @s m.ecl matches 3.. run data modify storage metiers:sk f2 set value "red"
data modify storage metiers:sk e2 set value ""
execute if score @s m.cd_2 matches 1 run data modify storage metiers:sk f2 set value "green"
execute if score @s m.cadre matches 2 run data modify storage metiers:sk e2 set value " ★"
data modify storage metiers:sk f3 set value "dark_gray"
execute if score @s m.ecl matches 6.. run data modify storage metiers:sk f3 set value "yellow"
execute unless score @s m.ecl matches 6.. run data modify storage metiers:sk f3 set value "red"
data modify storage metiers:sk e3 set value ""
execute if score @s m.cd_3 matches 1 run data modify storage metiers:sk f3 set value "green"
execute if score @s m.cadre matches 3 run data modify storage metiers:sk e3 set value " ★"
data modify storage metiers:sk f4 set value "dark_gray"
execute if score @s m.ecl matches 10.. run data modify storage metiers:sk f4 set value "yellow"
execute unless score @s m.ecl matches 10.. run data modify storage metiers:sk f4 set value "red"
data modify storage metiers:sk e4 set value ""
execute if score @s m.cd_4 matches 1 run data modify storage metiers:sk f4 set value "green"
execute if score @s m.cadre matches 4 run data modify storage metiers:sk e4 set value " ★"
data modify storage metiers:sk f5 set value "dark_gray"
execute if score @s m.bk4 matches 5.. run data modify storage metiers:sk f5 set value "yellow"
data modify storage metiers:sk e5 set value ""
execute if score @s m.cd_5 matches 1 run data modify storage metiers:sk f5 set value "green"
execute if score @s m.cadre matches 5 run data modify storage metiers:sk e5 set value " ★"
data modify storage metiers:sk f6 set value "dark_gray"
execute if score @s m.prtot matches 3.. run data modify storage metiers:sk f6 set value "yellow"
data modify storage metiers:sk e6 set value ""
execute if score @s m.cd_6 matches 1 run data modify storage metiers:sk f6 set value "green"
execute if score @s m.cadre matches 6 run data modify storage metiers:sk e6 set value " ★"
scoreboard players set #p5 m.tmp 0
execute if score @s m.b_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.f_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.m_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.c_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.p_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.e_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.n_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.x_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.t_pr matches 5.. run scoreboard players set #p5 m.tmp 1
data modify storage metiers:sk f7 set value "dark_gray"
execute if score #p5 m.tmp matches 1 run data modify storage metiers:sk f7 set value "yellow"
data modify storage metiers:sk e7 set value ""
scoreboard players add @s m.cd_7 0
execute if score @s m.cd_7 matches 1 run data modify storage metiers:sk f7 set value "green"
execute if score @s m.cadre matches 7 run data modify storage metiers:sk e7 set value " ★"
