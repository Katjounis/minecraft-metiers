execute if score @s m.so_t1 matches 1 if score @s m.skin_t matches 1 run return run function metiers:skins/equiper {t:"t",i:0}
execute if score @s m.so_t1 matches 1 run return run function metiers:skins/equiper {t:"t",i:1}
execute unless score @s m.cr_t matches 120.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore débloqué : regarde le prix ou la condition au survol.","color":"red"}]
scoreboard players remove @s m.cr_t 120
scoreboard players set @s m.so_t1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Givre débloqué.","color":"light_purple"}]
function metiers:skins/equiper {t:"t",i:1}
