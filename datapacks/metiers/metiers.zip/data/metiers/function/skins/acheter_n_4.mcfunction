execute if score @s m.so_n4 matches 1 if score @s m.skin_n matches 4 run return run function metiers:skins/equiper {t:"n",i:0}
execute if score @s m.so_n4 matches 1 run return run function metiers:skins/equiper {t:"n",i:4}
execute unless score @s m.bk2 matches 3.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore débloqué : regarde le prix ou la condition au survol.","color":"red"}]
scoreboard players set @s m.so_n4 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Ossements débloqué.","color":"light_purple"}]
function metiers:skins/equiper {t:"n",i:4}
