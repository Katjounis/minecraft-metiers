execute if score @s m.so_c3 matches 1 if score @s m.skin_c matches 3 run return run function metiers:skins/equiper {t:"c",i:0}
execute if score @s m.so_c3 matches 1 run return run function metiers:skins/equiper {t:"c",i:3}
scoreboard players set #ok m.tmp 0
execute if score @s m.ecl matches 5.. if score @s c.ecus matches 30000.. run scoreboard players set #ok m.tmp 1
execute if score #ok m.tmp matches 0 run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore : 5 éclats de boss et 30 000 Écus.","color":"red"}]
scoreboard players remove @s m.ecl 5
scoreboard players remove @s c.ecus 30000
scoreboard players set @s m.so_c3 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Or royal débloqué !","color":"light_purple"}]
execute at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.8 0.4 0.3 40
function metiers:skins/equiper {t:"c",i:3}
