execute if score @s m.so_m1 matches 1 if score @s m.skin_m matches 1 run return run function metiers:skins/equiper {t:"m",i:0}
execute if score @s m.so_m1 matches 1 run return run function metiers:skins/equiper {t:"m",i:1}
execute unless score @s m.cr_m matches 120.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore débloqué : regarde le prix ou la condition au survol.","color":"red"}]
scoreboard players remove @s m.cr_m 120
scoreboard players set @s m.so_m1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Givre débloqué.","color":"light_purple"}]
function metiers:skins/equiper {t:"m",i:1}
