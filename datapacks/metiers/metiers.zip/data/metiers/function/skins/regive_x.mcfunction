execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"x"}] run function metiers:x/outil_donner
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"x"}] run function metiers:x/outil_donner
