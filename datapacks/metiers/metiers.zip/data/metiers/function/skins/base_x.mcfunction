function metiers:skins/equiper {t:"x",i:0}
