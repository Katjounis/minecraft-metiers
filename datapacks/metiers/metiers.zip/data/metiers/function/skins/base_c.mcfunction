function metiers:skins/equiper {t:"c",i:0}
