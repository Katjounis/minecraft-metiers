function metiers:skins/equiper {t:"e",i:0}
