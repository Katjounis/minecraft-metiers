execute if score @s m.so_c5 matches 1 if score @s m.skin_c matches 5 run return run function metiers:skins/equiper {t:"c",i:0}
execute if score @s m.so_c5 matches 1 run return run function metiers:skins/equiper {t:"c",i:5}
scoreboard players set #ok m.tmp 0
execute if score @s m.bk4 matches 3.. if score @s m.ecl matches 6.. if score @s c.ecus matches 40000.. run scoreboard players set #ok m.tmp 1
execute if score #ok m.tmp matches 0 run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore : Vaincre 3 fois le Brasier ancestral, puis 6 éclats de boss et 40 000 Écus.","color":"red"}]
scoreboard players remove @s m.ecl 6
scoreboard players remove @s c.ecus 40000
scoreboard players remove @s c.a_met 40000
scoreboard players set @s m.so_c5 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Magma débloqué !","color":"light_purple"}]
execute at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.8 0.4 0.3 40
function metiers:skins/equiper {t:"c",i:5}
