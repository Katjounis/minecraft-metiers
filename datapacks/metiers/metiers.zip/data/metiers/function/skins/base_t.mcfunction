function metiers:skins/equiper {t:"t",i:0}
