$scoreboard players set @s m.skin_$(t) $(i)
$function metiers:skins/regive_$(t)
playsound minecraft:item.armor.equip_leather master @s ~ ~ ~ 1 1.2
function metiers:skins/menu
