execute if score @s m.cd_5 matches 1 run return run function metiers:skins/cadre {i:5}
execute unless score @s m.bk4 matches 5.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Trophée : vaincre 5 fois le Brasier ancestral.","color":"red"}]
scoreboard players set @s m.cd_5 1
function metiers:skins/cadre {i:5}
