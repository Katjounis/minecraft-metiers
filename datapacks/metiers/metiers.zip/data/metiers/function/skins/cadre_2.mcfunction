execute if score @s m.cd_2 matches 1 run return run function metiers:skins/cadre {i:2}
execute unless score @s m.ecl matches 3.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez d’éclats de boss.","color":"red"}]
scoreboard players remove @s m.ecl 3
scoreboard players set @s m.cd_2 1
function metiers:skins/cadre {i:2}
