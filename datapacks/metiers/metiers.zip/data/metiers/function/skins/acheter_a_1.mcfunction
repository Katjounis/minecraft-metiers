execute if score @s m.so_a1 matches 1 if score @s m.skin_a matches 1 run return run function metiers:skins/equiper {t:"a",i:0}
execute if score @s m.so_a1 matches 1 run return run function metiers:skins/equiper {t:"a",i:1}
execute unless score @s m.ecl matches 6.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore débloqué : regarde le prix ou la condition au survol.","color":"red"}]
scoreboard players remove @s m.ecl 6
scoreboard players set @s m.so_a1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Givre débloqué.","color":"light_purple"}]
function metiers:skins/equiper {t:"a",i:1}
