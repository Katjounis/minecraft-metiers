function metiers:skins/equiper {t:"f",i:0}
