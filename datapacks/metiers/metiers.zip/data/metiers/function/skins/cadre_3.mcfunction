execute if score @s m.cd_3 matches 1 run return run function metiers:skins/cadre {i:3}
execute unless score @s m.ecl matches 6.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez d’éclats de boss.","color":"red"}]
scoreboard players remove @s m.ecl 6
scoreboard players set @s m.cd_3 1
function metiers:skins/cadre {i:3}
