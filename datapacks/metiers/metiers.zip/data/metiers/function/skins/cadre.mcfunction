$scoreboard players set @s m.cadre $(i)
tag @s add metiers.maj
function metiers:prefixe/maj
function metiers:skins/cadres
