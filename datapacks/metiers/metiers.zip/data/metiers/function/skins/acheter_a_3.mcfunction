execute if score @s m.so_a3 matches 1 if score @s m.skin_a matches 3 run return run function metiers:skins/equiper {t:"a",i:0}
execute if score @s m.so_a3 matches 1 run return run function metiers:skins/equiper {t:"a",i:3}
execute unless score @s m.ecl matches 10.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore débloqué : regarde le prix ou la condition au survol.","color":"red"}]
scoreboard players remove @s m.ecl 10
scoreboard players set @s m.so_a3 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Or royal débloqué.","color":"light_purple"}]
function metiers:skins/equiper {t:"a",i:3}
