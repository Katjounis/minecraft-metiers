function metiers:skins/calcul
function metiers:skins/menu_dialog with storage metiers:sk
