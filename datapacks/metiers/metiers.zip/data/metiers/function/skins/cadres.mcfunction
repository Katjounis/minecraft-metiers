function metiers:skins/calcul
function metiers:skins/cadres_dialog with storage metiers:sk
