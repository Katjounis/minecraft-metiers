execute if score @s m.so_x1 matches 1 if score @s m.skin_x matches 1 run return run function metiers:skins/equiper {t:"x",i:0}
execute if score @s m.so_x1 matches 1 run return run function metiers:skins/equiper {t:"x",i:1}
execute unless score @s m.cr_x matches 120.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore débloqué : regarde le prix ou la condition au survol.","color":"red"}]
scoreboard players remove @s m.cr_x 120
scoreboard players set @s m.so_x1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Givre débloqué.","color":"light_purple"}]
function metiers:skins/equiper {t:"x",i:1}
