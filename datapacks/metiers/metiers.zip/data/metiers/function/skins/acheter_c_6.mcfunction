execute if score @s m.so_c6 matches 1 if score @s m.skin_c matches 6 run return run function metiers:skins/equiper {t:"c",i:0}
execute if score @s m.so_c6 matches 1 run return run function metiers:skins/equiper {t:"c",i:6}
execute unless score @s m.c_pr matches 1.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore débloqué : regarde le prix ou la condition au survol.","color":"red"}]
scoreboard players set @s m.so_c6 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Ombre débloqué.","color":"light_purple"}]
function metiers:skins/equiper {t:"c",i:6}
