execute if score @s m.so_a6 matches 1 if score @s m.skin_a matches 6 run return run function metiers:skins/equiper {t:"a",i:0}
execute if score @s m.so_a6 matches 1 run return run function metiers:skins/equiper {t:"a",i:6}
scoreboard players set #ok m.tmp 0
execute if score @s m.prtot matches 1.. if score @s m.ecl matches 8.. if score @s c.ecus matches 60000.. run scoreboard players set #ok m.tmp 1
execute if score #ok m.tmp matches 0 run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore : Un prestige dans n’importe quel métier, puis 8 éclats de boss et 60 000 Écus.","color":"red"}]
scoreboard players remove @s m.ecl 8
scoreboard players remove @s c.ecus 60000
scoreboard players set @s m.so_a6 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Ombre débloqué !","color":"light_purple"}]
execute at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.8 0.4 0.3 40
function metiers:skins/equiper {t:"a",i:6}
