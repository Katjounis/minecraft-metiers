function metiers:skins/equiper {t:"m",i:0}
