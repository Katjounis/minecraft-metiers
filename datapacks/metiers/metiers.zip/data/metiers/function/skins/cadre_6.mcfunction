execute if score @s m.cd_6 matches 1 run return run function metiers:skins/cadre {i:6}
execute unless score @s m.prtot matches 3.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut 3 prestiges au total.","color":"red"}]
scoreboard players set @s m.cd_6 1
function metiers:skins/cadre {i:6}
