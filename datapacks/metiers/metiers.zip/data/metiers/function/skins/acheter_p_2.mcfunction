execute if score @s m.so_p2 matches 1 if score @s m.skin_p matches 2 run return run function metiers:skins/equiper {t:"p",i:0}
execute if score @s m.so_p2 matches 1 run return run function metiers:skins/equiper {t:"p",i:2}
execute unless score @s m.cr_p matches 120.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore débloqué : regarde le prix ou la condition au survol.","color":"red"}]
scoreboard players remove @s m.cr_p 120
scoreboard players set @s m.so_p2 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Corail débloqué.","color":"light_purple"}]
function metiers:skins/equiper {t:"p",i:2}
