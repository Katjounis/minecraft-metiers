function metiers:skins/equiper {t:"b",i:0}
