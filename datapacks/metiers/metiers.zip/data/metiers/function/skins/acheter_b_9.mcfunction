execute if score @s m.so_b9 matches 1 if score @s m.skin_b matches 9 run return run function metiers:skins/equiper {t:"b",i:0}
execute if score @s m.so_b9 matches 1 run return run function metiers:skins/equiper {t:"b",i:9}
scoreboard players set #ok m.tmp 0
execute if score @s m.bk3 matches 10.. if score @s m.ecl matches 15.. if score @s c.ecus matches 120000.. run scoreboard players set #ok m.tmp 1
execute if score #ok m.tmp matches 0 run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore : Vaincre 10 fois la Liche du givre, puis 15 éclats de boss et 120 000 Écus.","color":"red"}]
scoreboard players remove @s m.ecl 15
scoreboard players remove @s c.ecus 120000
scoreboard players remove @s c.a_met 120000
scoreboard players set @s m.so_b9 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Abysses débloqué !","color":"light_purple"}]
execute at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.8 0.4 0.3 40
function metiers:skins/equiper {t:"b",i:9}
