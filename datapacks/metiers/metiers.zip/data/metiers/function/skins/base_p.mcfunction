function metiers:skins/equiper {t:"p",i:0}
