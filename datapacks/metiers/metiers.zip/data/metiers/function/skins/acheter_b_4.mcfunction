execute if score @s m.so_b4 matches 1 if score @s m.skin_b matches 4 run return run function metiers:skins/equiper {t:"b",i:0}
execute if score @s m.so_b4 matches 1 run return run function metiers:skins/equiper {t:"b",i:4}
scoreboard players set #ok m.tmp 0
execute if score @s m.bk2 matches 3.. if score @s m.ecl matches 6.. if score @s c.ecus matches 40000.. run scoreboard players set #ok m.tmp 1
execute if score #ok m.tmp matches 0 run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore : Vaincre 3 fois la Reine arachnide, puis 6 éclats de boss et 40 000 Écus.","color":"red"}]
scoreboard players remove @s m.ecl 6
scoreboard players remove @s c.ecus 40000
scoreboard players set @s m.so_b4 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Ossements débloqué !","color":"light_purple"}]
execute at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.8 0.4 0.3 40
function metiers:skins/equiper {t:"b",i:4}
