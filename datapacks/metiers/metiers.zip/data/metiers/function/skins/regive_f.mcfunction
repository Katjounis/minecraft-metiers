execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"f"}] run function metiers:f/outil_donner
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"f"}] run function metiers:f/outil_donner
