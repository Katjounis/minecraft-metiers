execute if score @s m.so_b8 matches 1 if score @s m.skin_b matches 8 run return run function metiers:skins/equiper {t:"b",i:0}
execute if score @s m.so_b8 matches 1 run return run function metiers:skins/equiper {t:"b",i:8}
scoreboard players set #ok m.tmp 0
execute if score @s m.cr_b matches 400.. if score @s m.ecl matches 12.. if score @s c.ecus matches 100000.. run scoreboard players set #ok m.tmp 1
execute if score #ok m.tmp matches 0 run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore : 400 cristaux, 12 éclats et 100 000 Écus.","color":"red"}]
scoreboard players remove @s m.cr_b 400
scoreboard players remove @s m.ecl 12
scoreboard players remove @s c.ecus 100000
scoreboard players set @s m.so_b8 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Céleste débloqué !","color":"light_purple"}]
execute at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.8 0.4 0.3 40
function metiers:skins/equiper {t:"b",i:8}
