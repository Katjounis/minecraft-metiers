execute if score @s m.so_a11 matches 1 if score @s m.skin_a matches 11 run return run function metiers:skins/equiper {t:"a",i:0}
execute if score @s m.so_a11 matches 1 run return run function metiers:skins/equiper {t:"a",i:11}
scoreboard players set #ok m.tmp 0
execute if score @s m.kdragon matches 3.. if score @s m.ecl matches 20.. if score @s c.ecus matches 150000.. run scoreboard players set #ok m.tmp 1
execute if score #ok m.tmp matches 0 run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore : Tuer 3 fois l’Ender Dragon, puis 20 éclats de boss et 150 000 Écus.","color":"red"}]
scoreboard players remove @s m.ecl 20
scoreboard players remove @s c.ecus 150000
scoreboard players set @s m.so_a11 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Dragon de l'End débloqué !","color":"light_purple"}]
execute at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.8 0.4 0.3 40
function metiers:skins/equiper {t:"a",i:11}
