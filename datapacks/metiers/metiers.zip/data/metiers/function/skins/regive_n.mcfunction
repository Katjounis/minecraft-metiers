execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"n"}] run function metiers:n/outil_donner
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"n"}] run function metiers:n/outil_donner
