execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"e"}] run function metiers:e/outil_donner
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"e"}] run function metiers:e/outil_donner
