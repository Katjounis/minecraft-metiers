execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"b"}] run function metiers:b/outil_donner
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"b"}] run function metiers:b/outil_donner
