function metiers:skins/equiper {t:"a",i:0}
