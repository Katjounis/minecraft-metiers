execute if score @s m.cd_7 matches 1 run return run function metiers:skins/cadre {i:7}
scoreboard players set #p5 m.tmp 0
execute if score @s m.b_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.f_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.m_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.c_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.p_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.e_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.n_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.x_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.t_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score @s m.k_pr matches 5.. run scoreboard players set #p5 m.tmp 1
execute if score #p5 m.tmp matches 0 run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Le cadre Étoilé demande 5 étoiles de prestige dans un métier.","color":"red"}]
scoreboard players set @s m.cd_7 1
function metiers:skins/cadre {i:7}
