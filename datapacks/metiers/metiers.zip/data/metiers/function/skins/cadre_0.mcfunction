function metiers:skins/cadre {i:0}
