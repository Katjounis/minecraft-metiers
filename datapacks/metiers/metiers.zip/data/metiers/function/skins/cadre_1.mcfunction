execute if score @s m.cd_1 matches 1 run return run function metiers:skins/cadre {i:1}
scoreboard players set @s m.cd_1 1
function metiers:skins/cadre {i:1}
