execute if score @s m.so_x6 matches 1 if score @s m.skin_x matches 6 run return run function metiers:skins/equiper {t:"x",i:0}
execute if score @s m.so_x6 matches 1 run return run function metiers:skins/equiper {t:"x",i:6}
execute unless score @s m.x_pr matches 1.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore débloqué : regarde le prix ou la condition au survol.","color":"red"}]
scoreboard players set @s m.so_x6 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Ombre débloqué.","color":"light_purple"}]
function metiers:skins/equiper {t:"x",i:6}
