execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"t"}] run function metiers:t/outil_donner
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"t"}] run function metiers:t/outil_donner
