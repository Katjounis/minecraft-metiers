execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"m"}] run function metiers:m/outil_donner
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"m"}] run function metiers:m/outil_donner
