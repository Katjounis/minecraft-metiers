execute if score @s m.so_t5 matches 1 if score @s m.skin_t matches 5 run return run function metiers:skins/equiper {t:"t",i:0}
execute if score @s m.so_t5 matches 1 run return run function metiers:skins/equiper {t:"t",i:5}
execute unless score @s m.bk4 matches 3.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore débloqué : regarde le prix ou la condition au survol.","color":"red"}]
scoreboard players set @s m.so_t5 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Magma débloqué.","color":"light_purple"}]
function metiers:skins/equiper {t:"t",i:5}
