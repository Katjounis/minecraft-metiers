execute if score @s m.so_e2 matches 1 if score @s m.skin_e matches 2 run return run function metiers:skins/equiper {t:"e",i:0}
execute if score @s m.so_e2 matches 1 run return run function metiers:skins/equiper {t:"e",i:2}
execute unless score @s m.cr_e matches 120.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas encore débloqué : regarde le prix ou la condition au survol.","color":"red"}]
scoreboard players remove @s m.cr_e 120
scoreboard players set @s m.so_e2 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Skin Corail débloqué.","color":"light_purple"}]
function metiers:skins/equiper {t:"e",i:2}
