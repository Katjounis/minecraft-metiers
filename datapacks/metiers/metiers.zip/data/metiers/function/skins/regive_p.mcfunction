execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"p"}] run function metiers:p/outil_donner
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"p"}] run function metiers:p/outil_donner
