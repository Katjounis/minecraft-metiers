scoreboard players add @s m.skt 1
execute if score @s m.skt matches 10.. run scoreboard players set @s m.skt 0
function metiers:skins/menu
