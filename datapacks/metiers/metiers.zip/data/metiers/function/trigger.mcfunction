scoreboard players operation @s m.trig = @s metiers
scoreboard players set @s metiers 0
scoreboard players enable @s metiers
execute if score @s m.trig matches 1 run function metiers:menu
execute if score @s m.trig matches 2 run function metiers:prefixe/menu
execute if score @s m.trig matches 3 unless function metiers:recompenses run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucune récompense en attente.","color":"gray"}]
execute if score @s m.trig matches 10..20 run function metiers:prefixe/choisir
execute if score @s m.trig matches 4 run function metiers:appel {f:"defis/menu"}
execute if score @s m.trig matches 5 run function metiers:appel {f:"classement/menu"}
execute if score @s m.trig matches 7 run function metiers:appel {f:"defis/basculer"}
execute if score @s m.trig matches 6 run function metiers:appel {f:"armure/menu"}
execute if score @s m.trig matches 8 run function metiers:appel {f:"armure/recup"}
execute if score @s m.trig matches 70 run function metiers:appel {f:"p/carnet"}
execute if score @s m.trig matches 301 run function metiers:appel {f:"b/outil_recup"}
execute if score @s m.trig matches 311 run function metiers:appel {f:"b/prestige_confirmer"}
execute if score @s m.trig matches 321 run function metiers:appel {f:"b/prestige"}
execute if score @s m.trig matches 331 run function metiers:appel {f:"b/outil_reparer"}
execute if score @s m.trig matches 341 run function metiers:appel {f:"b/recompenses_menu"}
execute if score @s m.trig matches 302 run function metiers:appel {f:"f/outil_recup"}
execute if score @s m.trig matches 312 run function metiers:appel {f:"f/prestige_confirmer"}
execute if score @s m.trig matches 322 run function metiers:appel {f:"f/prestige"}
execute if score @s m.trig matches 332 run function metiers:appel {f:"f/outil_reparer"}
execute if score @s m.trig matches 342 run function metiers:appel {f:"f/recompenses_menu"}
execute if score @s m.trig matches 303 run function metiers:appel {f:"m/outil_recup"}
execute if score @s m.trig matches 313 run function metiers:appel {f:"m/prestige_confirmer"}
execute if score @s m.trig matches 323 run function metiers:appel {f:"m/prestige"}
execute if score @s m.trig matches 333 run function metiers:appel {f:"m/outil_reparer"}
execute if score @s m.trig matches 343 run function metiers:appel {f:"m/recompenses_menu"}
execute if score @s m.trig matches 304 run function metiers:appel {f:"c/outil_recup"}
execute if score @s m.trig matches 314 run function metiers:appel {f:"c/prestige_confirmer"}
execute if score @s m.trig matches 324 run function metiers:appel {f:"c/prestige"}
execute if score @s m.trig matches 334 run function metiers:appel {f:"c/outil_reparer"}
execute if score @s m.trig matches 344 run function metiers:appel {f:"c/recompenses_menu"}
execute if score @s m.trig matches 305 run function metiers:appel {f:"p/outil_recup"}
execute if score @s m.trig matches 315 run function metiers:appel {f:"p/prestige_confirmer"}
execute if score @s m.trig matches 325 run function metiers:appel {f:"p/prestige"}
execute if score @s m.trig matches 335 run function metiers:appel {f:"p/outil_reparer"}
execute if score @s m.trig matches 345 run function metiers:appel {f:"p/recompenses_menu"}
execute if score @s m.trig matches 306 run function metiers:appel {f:"e/outil_recup"}
execute if score @s m.trig matches 316 run function metiers:appel {f:"e/prestige_confirmer"}
execute if score @s m.trig matches 326 run function metiers:appel {f:"e/prestige"}
execute if score @s m.trig matches 336 run function metiers:appel {f:"e/outil_reparer"}
execute if score @s m.trig matches 346 run function metiers:appel {f:"e/recompenses_menu"}
execute if score @s m.trig matches 307 run function metiers:appel {f:"n/outil_recup"}
execute if score @s m.trig matches 317 run function metiers:appel {f:"n/prestige_confirmer"}
execute if score @s m.trig matches 327 run function metiers:appel {f:"n/prestige"}
execute if score @s m.trig matches 337 run function metiers:appel {f:"n/outil_reparer"}
execute if score @s m.trig matches 347 run function metiers:appel {f:"n/recompenses_menu"}
execute if score @s m.trig matches 308 run function metiers:appel {f:"x/outil_recup"}
execute if score @s m.trig matches 318 run function metiers:appel {f:"x/prestige_confirmer"}
execute if score @s m.trig matches 328 run function metiers:appel {f:"x/prestige"}
execute if score @s m.trig matches 338 run function metiers:appel {f:"x/outil_reparer"}
execute if score @s m.trig matches 348 run function metiers:appel {f:"x/recompenses_menu"}
execute if score @s m.trig matches 309 run function metiers:appel {f:"t/outil_recup"}
execute if score @s m.trig matches 319 run function metiers:appel {f:"t/prestige_confirmer"}
execute if score @s m.trig matches 329 run function metiers:appel {f:"t/prestige"}
execute if score @s m.trig matches 339 run function metiers:appel {f:"t/outil_reparer"}
execute if score @s m.trig matches 349 run function metiers:appel {f:"t/recompenses_menu"}
execute if score @s m.trig matches 310 run function metiers:appel {f:"k/outil_recup"}
execute if score @s m.trig matches 320 run function metiers:appel {f:"k/prestige_confirmer"}
execute if score @s m.trig matches 330 run function metiers:appel {f:"k/prestige"}
execute if score @s m.trig matches 340 run function metiers:appel {f:"k/outil_reparer"}
execute if score @s m.trig matches 350 run function metiers:appel {f:"k/recompenses_menu"}
execute if score @s m.trig matches 21 run function metiers:b/arbre
execute if score @s m.trig matches 201 run function metiers:b/reclamer
execute if score @s m.trig matches 111 run function metiers:b/acheter_1
execute if score @s m.trig matches 112 run function metiers:b/acheter_2
execute if score @s m.trig matches 113 run function metiers:b/acheter_3
execute if score @s m.trig matches 114 run function metiers:b/acheter_4
execute if score @s m.trig matches 115 run function metiers:b/acheter_5
execute if score @s m.trig matches 116 run function metiers:b/acheter_6
execute if score @s m.trig matches 3027 run function metiers:b/acheter_7
execute if score @s m.trig matches 3028 run function metiers:b/acheter_8
execute if score @s m.trig matches 3029 run function metiers:b/acheter_9
execute if score @s m.trig matches 3030 run function metiers:b/acheter_10
execute if score @s m.trig matches 3031 run function metiers:b/acheter_11
execute if score @s m.trig matches 3032 run function metiers:b/acheter_12
execute if score @s m.trig matches 3033 run function metiers:b/acheter_13
execute if score @s m.trig matches 3034 run function metiers:b/acheter_14
execute if score @s m.trig matches 3035 run function metiers:b/acheter_15
execute if score @s m.trig matches 3036 run function metiers:b/acheter_16
execute if score @s m.trig matches 3037 run function metiers:b/acheter_17
execute if score @s m.trig matches 3038 run function metiers:b/acheter_18
execute if score @s m.trig matches 22 run function metiers:f/arbre
execute if score @s m.trig matches 202 run function metiers:f/reclamer
execute if score @s m.trig matches 121 run function metiers:f/acheter_1
execute if score @s m.trig matches 122 run function metiers:f/acheter_2
execute if score @s m.trig matches 123 run function metiers:f/acheter_3
execute if score @s m.trig matches 124 run function metiers:f/acheter_4
execute if score @s m.trig matches 125 run function metiers:f/acheter_5
execute if score @s m.trig matches 126 run function metiers:f/acheter_6
execute if score @s m.trig matches 3047 run function metiers:f/acheter_7
execute if score @s m.trig matches 3048 run function metiers:f/acheter_8
execute if score @s m.trig matches 3049 run function metiers:f/acheter_9
execute if score @s m.trig matches 3050 run function metiers:f/acheter_10
execute if score @s m.trig matches 3051 run function metiers:f/acheter_11
execute if score @s m.trig matches 3052 run function metiers:f/acheter_12
execute if score @s m.trig matches 3053 run function metiers:f/acheter_13
execute if score @s m.trig matches 3054 run function metiers:f/acheter_14
execute if score @s m.trig matches 3055 run function metiers:f/acheter_15
execute if score @s m.trig matches 3056 run function metiers:f/acheter_16
execute if score @s m.trig matches 3057 run function metiers:f/acheter_17
execute if score @s m.trig matches 3058 run function metiers:f/acheter_18
execute if score @s m.trig matches 23 run function metiers:m/arbre
execute if score @s m.trig matches 203 run function metiers:m/reclamer
execute if score @s m.trig matches 131 run function metiers:m/acheter_1
execute if score @s m.trig matches 132 run function metiers:m/acheter_2
execute if score @s m.trig matches 133 run function metiers:m/acheter_3
execute if score @s m.trig matches 134 run function metiers:m/acheter_4
execute if score @s m.trig matches 135 run function metiers:m/acheter_5
execute if score @s m.trig matches 136 run function metiers:m/acheter_6
execute if score @s m.trig matches 3067 run function metiers:m/acheter_7
execute if score @s m.trig matches 3068 run function metiers:m/acheter_8
execute if score @s m.trig matches 3069 run function metiers:m/acheter_9
execute if score @s m.trig matches 3070 run function metiers:m/acheter_10
execute if score @s m.trig matches 3071 run function metiers:m/acheter_11
execute if score @s m.trig matches 3072 run function metiers:m/acheter_12
execute if score @s m.trig matches 3073 run function metiers:m/acheter_13
execute if score @s m.trig matches 3074 run function metiers:m/acheter_14
execute if score @s m.trig matches 3075 run function metiers:m/acheter_15
execute if score @s m.trig matches 3076 run function metiers:m/acheter_16
execute if score @s m.trig matches 3077 run function metiers:m/acheter_17
execute if score @s m.trig matches 3078 run function metiers:m/acheter_18
execute if score @s m.trig matches 24 run function metiers:c/arbre
execute if score @s m.trig matches 204 run function metiers:c/reclamer
execute if score @s m.trig matches 141 run function metiers:c/acheter_1
execute if score @s m.trig matches 142 run function metiers:c/acheter_2
execute if score @s m.trig matches 143 run function metiers:c/acheter_3
execute if score @s m.trig matches 144 run function metiers:c/acheter_4
execute if score @s m.trig matches 145 run function metiers:c/acheter_5
execute if score @s m.trig matches 146 run function metiers:c/acheter_6
execute if score @s m.trig matches 3087 run function metiers:c/acheter_7
execute if score @s m.trig matches 3088 run function metiers:c/acheter_8
execute if score @s m.trig matches 3089 run function metiers:c/acheter_9
execute if score @s m.trig matches 3090 run function metiers:c/acheter_10
execute if score @s m.trig matches 3091 run function metiers:c/acheter_11
execute if score @s m.trig matches 3092 run function metiers:c/acheter_12
execute if score @s m.trig matches 3093 run function metiers:c/acheter_13
execute if score @s m.trig matches 3094 run function metiers:c/acheter_14
execute if score @s m.trig matches 3095 run function metiers:c/acheter_15
execute if score @s m.trig matches 3096 run function metiers:c/acheter_16
execute if score @s m.trig matches 3097 run function metiers:c/acheter_17
execute if score @s m.trig matches 3098 run function metiers:c/acheter_18
execute if score @s m.trig matches 25 run function metiers:p/arbre
execute if score @s m.trig matches 205 run function metiers:p/reclamer
execute if score @s m.trig matches 151 run function metiers:p/acheter_1
execute if score @s m.trig matches 152 run function metiers:p/acheter_2
execute if score @s m.trig matches 153 run function metiers:p/acheter_3
execute if score @s m.trig matches 154 run function metiers:p/acheter_4
execute if score @s m.trig matches 155 run function metiers:p/acheter_5
execute if score @s m.trig matches 156 run function metiers:p/acheter_6
execute if score @s m.trig matches 3107 run function metiers:p/acheter_7
execute if score @s m.trig matches 3108 run function metiers:p/acheter_8
execute if score @s m.trig matches 3109 run function metiers:p/acheter_9
execute if score @s m.trig matches 3110 run function metiers:p/acheter_10
execute if score @s m.trig matches 3111 run function metiers:p/acheter_11
execute if score @s m.trig matches 3112 run function metiers:p/acheter_12
execute if score @s m.trig matches 3113 run function metiers:p/acheter_13
execute if score @s m.trig matches 3114 run function metiers:p/acheter_14
execute if score @s m.trig matches 3115 run function metiers:p/acheter_15
execute if score @s m.trig matches 3116 run function metiers:p/acheter_16
execute if score @s m.trig matches 3117 run function metiers:p/acheter_17
execute if score @s m.trig matches 3118 run function metiers:p/acheter_18
execute if score @s m.trig matches 26 run function metiers:e/arbre
execute if score @s m.trig matches 206 run function metiers:e/reclamer
execute if score @s m.trig matches 161 run function metiers:e/acheter_1
execute if score @s m.trig matches 162 run function metiers:e/acheter_2
execute if score @s m.trig matches 163 run function metiers:e/acheter_3
execute if score @s m.trig matches 164 run function metiers:e/acheter_4
execute if score @s m.trig matches 165 run function metiers:e/acheter_5
execute if score @s m.trig matches 166 run function metiers:e/acheter_6
execute if score @s m.trig matches 3127 run function metiers:e/acheter_7
execute if score @s m.trig matches 3128 run function metiers:e/acheter_8
execute if score @s m.trig matches 3129 run function metiers:e/acheter_9
execute if score @s m.trig matches 3130 run function metiers:e/acheter_10
execute if score @s m.trig matches 3131 run function metiers:e/acheter_11
execute if score @s m.trig matches 3132 run function metiers:e/acheter_12
execute if score @s m.trig matches 3133 run function metiers:e/acheter_13
execute if score @s m.trig matches 3134 run function metiers:e/acheter_14
execute if score @s m.trig matches 3135 run function metiers:e/acheter_15
execute if score @s m.trig matches 3136 run function metiers:e/acheter_16
execute if score @s m.trig matches 3137 run function metiers:e/acheter_17
execute if score @s m.trig matches 3138 run function metiers:e/acheter_18
execute if score @s m.trig matches 27 run function metiers:n/arbre
execute if score @s m.trig matches 207 run function metiers:n/reclamer
execute if score @s m.trig matches 171 run function metiers:n/acheter_1
execute if score @s m.trig matches 172 run function metiers:n/acheter_2
execute if score @s m.trig matches 173 run function metiers:n/acheter_3
execute if score @s m.trig matches 174 run function metiers:n/acheter_4
execute if score @s m.trig matches 175 run function metiers:n/acheter_5
execute if score @s m.trig matches 176 run function metiers:n/acheter_6
execute if score @s m.trig matches 3147 run function metiers:n/acheter_7
execute if score @s m.trig matches 3148 run function metiers:n/acheter_8
execute if score @s m.trig matches 3149 run function metiers:n/acheter_9
execute if score @s m.trig matches 3150 run function metiers:n/acheter_10
execute if score @s m.trig matches 3151 run function metiers:n/acheter_11
execute if score @s m.trig matches 3152 run function metiers:n/acheter_12
execute if score @s m.trig matches 3153 run function metiers:n/acheter_13
execute if score @s m.trig matches 3154 run function metiers:n/acheter_14
execute if score @s m.trig matches 3155 run function metiers:n/acheter_15
execute if score @s m.trig matches 3156 run function metiers:n/acheter_16
execute if score @s m.trig matches 3157 run function metiers:n/acheter_17
execute if score @s m.trig matches 3158 run function metiers:n/acheter_18
execute if score @s m.trig matches 28 run function metiers:x/arbre
execute if score @s m.trig matches 208 run function metiers:x/reclamer
execute if score @s m.trig matches 181 run function metiers:x/acheter_1
execute if score @s m.trig matches 182 run function metiers:x/acheter_2
execute if score @s m.trig matches 183 run function metiers:x/acheter_3
execute if score @s m.trig matches 184 run function metiers:x/acheter_4
execute if score @s m.trig matches 185 run function metiers:x/acheter_5
execute if score @s m.trig matches 186 run function metiers:x/acheter_6
execute if score @s m.trig matches 3167 run function metiers:x/acheter_7
execute if score @s m.trig matches 3168 run function metiers:x/acheter_8
execute if score @s m.trig matches 3169 run function metiers:x/acheter_9
execute if score @s m.trig matches 3170 run function metiers:x/acheter_10
execute if score @s m.trig matches 3171 run function metiers:x/acheter_11
execute if score @s m.trig matches 3172 run function metiers:x/acheter_12
execute if score @s m.trig matches 3173 run function metiers:x/acheter_13
execute if score @s m.trig matches 3174 run function metiers:x/acheter_14
execute if score @s m.trig matches 3175 run function metiers:x/acheter_15
execute if score @s m.trig matches 3176 run function metiers:x/acheter_16
execute if score @s m.trig matches 3177 run function metiers:x/acheter_17
execute if score @s m.trig matches 3178 run function metiers:x/acheter_18
execute if score @s m.trig matches 29 run function metiers:t/arbre
execute if score @s m.trig matches 209 run function metiers:t/reclamer
execute if score @s m.trig matches 191 run function metiers:t/acheter_1
execute if score @s m.trig matches 192 run function metiers:t/acheter_2
execute if score @s m.trig matches 193 run function metiers:t/acheter_3
execute if score @s m.trig matches 194 run function metiers:t/acheter_4
execute if score @s m.trig matches 195 run function metiers:t/acheter_5
execute if score @s m.trig matches 196 run function metiers:t/acheter_6
execute if score @s m.trig matches 3187 run function metiers:t/acheter_7
execute if score @s m.trig matches 3188 run function metiers:t/acheter_8
execute if score @s m.trig matches 3189 run function metiers:t/acheter_9
execute if score @s m.trig matches 3190 run function metiers:t/acheter_10
execute if score @s m.trig matches 3191 run function metiers:t/acheter_11
execute if score @s m.trig matches 3192 run function metiers:t/acheter_12
execute if score @s m.trig matches 3193 run function metiers:t/acheter_13
execute if score @s m.trig matches 3194 run function metiers:t/acheter_14
execute if score @s m.trig matches 3195 run function metiers:t/acheter_15
execute if score @s m.trig matches 3196 run function metiers:t/acheter_16
execute if score @s m.trig matches 3197 run function metiers:t/acheter_17
execute if score @s m.trig matches 3198 run function metiers:t/acheter_18
execute if score @s m.trig matches 30 run function metiers:k/arbre
execute if score @s m.trig matches 210 run function metiers:k/reclamer
execute if score @s m.trig matches 1001 run function metiers:k/acheter_1
execute if score @s m.trig matches 1002 run function metiers:k/acheter_2
execute if score @s m.trig matches 1003 run function metiers:k/acheter_3
execute if score @s m.trig matches 1004 run function metiers:k/acheter_4
execute if score @s m.trig matches 1005 run function metiers:k/acheter_5
execute if score @s m.trig matches 1006 run function metiers:k/acheter_6
execute if score @s m.trig matches 3500 run function metiers:appel {f:"objets/acheter_graine"}
execute if score @s m.trig matches 3481 run function metiers:appel {f:"objets/boutique_b"}
execute if score @s m.trig matches 3501 run function metiers:appel {f:"objets/acheter_bombe"}
execute if score @s m.trig matches 3502 run function metiers:appel {f:"objets/acheter_arrosoir"}
execute if score @s m.trig matches 3503 run function metiers:appel {f:"objets/acheter_epouvantail"}
execute if score @s m.trig matches 3482 run function metiers:appel {f:"objets/boutique_f"}
execute if score @s m.trig matches 3504 run function metiers:appel {f:"objets/acheter_dynamite"}
execute if score @s m.trig matches 3505 run function metiers:appel {f:"objets/acheter_lanterne"}
execute if score @s m.trig matches 3483 run function metiers:appel {f:"objets/boutique_m"}
execute if score @s m.trig matches 3506 run function metiers:appel {f:"objets/acheter_piege"}
execute if score @s m.trig matches 3484 run function metiers:appel {f:"objets/boutique_c"}
execute if score @s m.trig matches 3507 run function metiers:appel {f:"objets/acheter_filet"}
execute if score @s m.trig matches 3485 run function metiers:appel {f:"objets/boutique_p"}
execute if score @s m.trig matches 3508 run function metiers:appel {f:"objets/acheter_sifflet"}
execute if score @s m.trig matches 3509 run function metiers:appel {f:"objets/acheter_mangeoire"}
execute if score @s m.trig matches 3486 run function metiers:appel {f:"objets/boutique_e"}
execute if score @s m.trig matches 3510 run function metiers:appel {f:"objets/acheter_tente"}
execute if score @s m.trig matches 3488 run function metiers:appel {f:"objets/boutique_x"}
execute if score @s m.trig matches 3490 run function metiers:appel {f:"comp/n_forge"}
execute if score @s m.trig matches 3492 run function metiers:appel {f:"objets/recup_elytres"}
execute if score @s m.trig matches 4321 if entity @s[tag=metiers.skoff.b1] run function metiers:b/activer_1
execute if score @s m.trig matches 4021 run function metiers:b/oublier_1
execute if score @s m.trig matches 4322 if entity @s[tag=metiers.skoff.b2] run function metiers:b/activer_2
execute if score @s m.trig matches 4022 run function metiers:b/oublier_2
execute if score @s m.trig matches 4323 if entity @s[tag=metiers.skoff.b3] run function metiers:b/activer_3
execute if score @s m.trig matches 4023 run function metiers:b/oublier_3
execute if score @s m.trig matches 4324 if entity @s[tag=metiers.skoff.b4] run function metiers:b/activer_4
execute if score @s m.trig matches 4024 run function metiers:b/oublier_4
execute if score @s m.trig matches 4325 if entity @s[tag=metiers.skoff.b5] run function metiers:b/activer_5
execute if score @s m.trig matches 4025 run function metiers:b/oublier_5
execute if score @s m.trig matches 4326 if entity @s[tag=metiers.skoff.b6] run function metiers:b/activer_6
execute if score @s m.trig matches 4026 run function metiers:b/oublier_6
execute if score @s m.trig matches 4327 if entity @s[tag=metiers.skoff.b7] run function metiers:b/activer_7
execute if score @s m.trig matches 4027 run function metiers:b/oublier_7
execute if score @s m.trig matches 4328 if entity @s[tag=metiers.skoff.b8] run function metiers:b/activer_8
execute if score @s m.trig matches 4028 run function metiers:b/oublier_8
execute if score @s m.trig matches 4329 if entity @s[tag=metiers.skoff.b9] run function metiers:b/activer_9
execute if score @s m.trig matches 4029 run function metiers:b/oublier_9
execute if score @s m.trig matches 4330 if entity @s[tag=metiers.skoff.b10] run function metiers:b/activer_10
execute if score @s m.trig matches 4030 run function metiers:b/oublier_10
execute if score @s m.trig matches 4331 if entity @s[tag=metiers.skoff.b11] run function metiers:b/activer_11
execute if score @s m.trig matches 4031 run function metiers:b/oublier_11
execute if score @s m.trig matches 4332 if entity @s[tag=metiers.skoff.b12] run function metiers:b/activer_12
execute if score @s m.trig matches 4032 run function metiers:b/oublier_12
execute if score @s m.trig matches 4333 if entity @s[tag=metiers.skoff.b13] run function metiers:b/activer_13
execute if score @s m.trig matches 4033 run function metiers:b/oublier_13
execute if score @s m.trig matches 4334 if entity @s[tag=metiers.skoff.b14] run function metiers:b/activer_14
execute if score @s m.trig matches 4034 run function metiers:b/oublier_14
execute if score @s m.trig matches 4335 if entity @s[tag=metiers.skoff.b15] run function metiers:b/activer_15
execute if score @s m.trig matches 4035 run function metiers:b/oublier_15
execute if score @s m.trig matches 4336 if entity @s[tag=metiers.skoff.b16] run function metiers:b/activer_16
execute if score @s m.trig matches 4036 run function metiers:b/oublier_16
execute if score @s m.trig matches 4337 if entity @s[tag=metiers.skoff.b17] run function metiers:b/activer_17
execute if score @s m.trig matches 4037 run function metiers:b/oublier_17
execute if score @s m.trig matches 4338 if entity @s[tag=metiers.skoff.b18] run function metiers:b/activer_18
execute if score @s m.trig matches 4038 run function metiers:b/oublier_18
execute if score @s m.trig matches 4341 if entity @s[tag=metiers.skoff.f1] run function metiers:f/activer_1
execute if score @s m.trig matches 4041 run function metiers:f/oublier_1
execute if score @s m.trig matches 4342 if entity @s[tag=metiers.skoff.f2] run function metiers:f/activer_2
execute if score @s m.trig matches 4042 run function metiers:f/oublier_2
execute if score @s m.trig matches 4343 if entity @s[tag=metiers.skoff.f3] run function metiers:f/activer_3
execute if score @s m.trig matches 4043 run function metiers:f/oublier_3
execute if score @s m.trig matches 4344 if entity @s[tag=metiers.skoff.f4] run function metiers:f/activer_4
execute if score @s m.trig matches 4044 run function metiers:f/oublier_4
execute if score @s m.trig matches 4345 if entity @s[tag=metiers.skoff.f5] run function metiers:f/activer_5
execute if score @s m.trig matches 4045 run function metiers:f/oublier_5
execute if score @s m.trig matches 4346 if entity @s[tag=metiers.skoff.f6] run function metiers:f/activer_6
execute if score @s m.trig matches 4046 run function metiers:f/oublier_6
execute if score @s m.trig matches 4347 if entity @s[tag=metiers.skoff.f7] run function metiers:f/activer_7
execute if score @s m.trig matches 4047 run function metiers:f/oublier_7
execute if score @s m.trig matches 4348 if entity @s[tag=metiers.skoff.f8] run function metiers:f/activer_8
execute if score @s m.trig matches 4048 run function metiers:f/oublier_8
execute if score @s m.trig matches 4349 if entity @s[tag=metiers.skoff.f9] run function metiers:f/activer_9
execute if score @s m.trig matches 4049 run function metiers:f/oublier_9
execute if score @s m.trig matches 4350 if entity @s[tag=metiers.skoff.f10] run function metiers:f/activer_10
execute if score @s m.trig matches 4050 run function metiers:f/oublier_10
execute if score @s m.trig matches 4351 if entity @s[tag=metiers.skoff.f11] run function metiers:f/activer_11
execute if score @s m.trig matches 4051 run function metiers:f/oublier_11
execute if score @s m.trig matches 4352 if entity @s[tag=metiers.skoff.f12] run function metiers:f/activer_12
execute if score @s m.trig matches 4052 run function metiers:f/oublier_12
execute if score @s m.trig matches 4353 if entity @s[tag=metiers.skoff.f13] run function metiers:f/activer_13
execute if score @s m.trig matches 4053 run function metiers:f/oublier_13
execute if score @s m.trig matches 4354 if entity @s[tag=metiers.skoff.f14] run function metiers:f/activer_14
execute if score @s m.trig matches 4054 run function metiers:f/oublier_14
execute if score @s m.trig matches 4355 if entity @s[tag=metiers.skoff.f15] run function metiers:f/activer_15
execute if score @s m.trig matches 4055 run function metiers:f/oublier_15
execute if score @s m.trig matches 4356 if entity @s[tag=metiers.skoff.f16] run function metiers:f/activer_16
execute if score @s m.trig matches 4056 run function metiers:f/oublier_16
execute if score @s m.trig matches 4357 if entity @s[tag=metiers.skoff.f17] run function metiers:f/activer_17
execute if score @s m.trig matches 4057 run function metiers:f/oublier_17
execute if score @s m.trig matches 4358 if entity @s[tag=metiers.skoff.f18] run function metiers:f/activer_18
execute if score @s m.trig matches 4058 run function metiers:f/oublier_18
execute if score @s m.trig matches 4361 if entity @s[tag=metiers.skoff.m1] run function metiers:m/activer_1
execute if score @s m.trig matches 4061 run function metiers:m/oublier_1
execute if score @s m.trig matches 4362 if entity @s[tag=metiers.skoff.m2] run function metiers:m/activer_2
execute if score @s m.trig matches 4062 run function metiers:m/oublier_2
execute if score @s m.trig matches 4363 if entity @s[tag=metiers.skoff.m3] run function metiers:m/activer_3
execute if score @s m.trig matches 4063 run function metiers:m/oublier_3
execute if score @s m.trig matches 4364 if entity @s[tag=metiers.skoff.m4] run function metiers:m/activer_4
execute if score @s m.trig matches 4064 run function metiers:m/oublier_4
execute if score @s m.trig matches 4365 if entity @s[tag=metiers.skoff.m5] run function metiers:m/activer_5
execute if score @s m.trig matches 4065 run function metiers:m/oublier_5
execute if score @s m.trig matches 4366 if entity @s[tag=metiers.skoff.m6] run function metiers:m/activer_6
execute if score @s m.trig matches 4066 run function metiers:m/oublier_6
execute if score @s m.trig matches 4367 if entity @s[tag=metiers.skoff.m7] run function metiers:m/activer_7
execute if score @s m.trig matches 4067 run function metiers:m/oublier_7
execute if score @s m.trig matches 4368 if entity @s[tag=metiers.skoff.m8] run function metiers:m/activer_8
execute if score @s m.trig matches 4068 run function metiers:m/oublier_8
execute if score @s m.trig matches 4369 if entity @s[tag=metiers.skoff.m9] run function metiers:m/activer_9
execute if score @s m.trig matches 4069 run function metiers:m/oublier_9
execute if score @s m.trig matches 4370 if entity @s[tag=metiers.skoff.m10] run function metiers:m/activer_10
execute if score @s m.trig matches 4070 run function metiers:m/oublier_10
execute if score @s m.trig matches 4371 if entity @s[tag=metiers.skoff.m11] run function metiers:m/activer_11
execute if score @s m.trig matches 4071 run function metiers:m/oublier_11
execute if score @s m.trig matches 4372 if entity @s[tag=metiers.skoff.m12] run function metiers:m/activer_12
execute if score @s m.trig matches 4072 run function metiers:m/oublier_12
execute if score @s m.trig matches 4373 if entity @s[tag=metiers.skoff.m13] run function metiers:m/activer_13
execute if score @s m.trig matches 4073 run function metiers:m/oublier_13
execute if score @s m.trig matches 4374 if entity @s[tag=metiers.skoff.m14] run function metiers:m/activer_14
execute if score @s m.trig matches 4074 run function metiers:m/oublier_14
execute if score @s m.trig matches 4375 if entity @s[tag=metiers.skoff.m15] run function metiers:m/activer_15
execute if score @s m.trig matches 4075 run function metiers:m/oublier_15
execute if score @s m.trig matches 4376 if entity @s[tag=metiers.skoff.m16] run function metiers:m/activer_16
execute if score @s m.trig matches 4076 run function metiers:m/oublier_16
execute if score @s m.trig matches 4377 if entity @s[tag=metiers.skoff.m17] run function metiers:m/activer_17
execute if score @s m.trig matches 4077 run function metiers:m/oublier_17
execute if score @s m.trig matches 4378 if entity @s[tag=metiers.skoff.m18] run function metiers:m/activer_18
execute if score @s m.trig matches 4078 run function metiers:m/oublier_18
execute if score @s m.trig matches 4381 if entity @s[tag=metiers.skoff.c1] run function metiers:c/activer_1
execute if score @s m.trig matches 4081 run function metiers:c/oublier_1
execute if score @s m.trig matches 4382 if entity @s[tag=metiers.skoff.c2] run function metiers:c/activer_2
execute if score @s m.trig matches 4082 run function metiers:c/oublier_2
execute if score @s m.trig matches 4383 if entity @s[tag=metiers.skoff.c3] run function metiers:c/activer_3
execute if score @s m.trig matches 4083 run function metiers:c/oublier_3
execute if score @s m.trig matches 4384 if entity @s[tag=metiers.skoff.c4] run function metiers:c/activer_4
execute if score @s m.trig matches 4084 run function metiers:c/oublier_4
execute if score @s m.trig matches 4385 if entity @s[tag=metiers.skoff.c5] run function metiers:c/activer_5
execute if score @s m.trig matches 4085 run function metiers:c/oublier_5
execute if score @s m.trig matches 4386 if entity @s[tag=metiers.skoff.c6] run function metiers:c/activer_6
execute if score @s m.trig matches 4086 run function metiers:c/oublier_6
execute if score @s m.trig matches 4387 if entity @s[tag=metiers.skoff.c7] run function metiers:c/activer_7
execute if score @s m.trig matches 4087 run function metiers:c/oublier_7
execute if score @s m.trig matches 4388 if entity @s[tag=metiers.skoff.c8] run function metiers:c/activer_8
execute if score @s m.trig matches 4088 run function metiers:c/oublier_8
execute if score @s m.trig matches 4389 if entity @s[tag=metiers.skoff.c9] run function metiers:c/activer_9
execute if score @s m.trig matches 4089 run function metiers:c/oublier_9
execute if score @s m.trig matches 4390 if entity @s[tag=metiers.skoff.c10] run function metiers:c/activer_10
execute if score @s m.trig matches 4090 run function metiers:c/oublier_10
execute if score @s m.trig matches 4391 if entity @s[tag=metiers.skoff.c11] run function metiers:c/activer_11
execute if score @s m.trig matches 4091 run function metiers:c/oublier_11
execute if score @s m.trig matches 4392 if entity @s[tag=metiers.skoff.c12] run function metiers:c/activer_12
execute if score @s m.trig matches 4092 run function metiers:c/oublier_12
execute if score @s m.trig matches 4393 if entity @s[tag=metiers.skoff.c13] run function metiers:c/activer_13
execute if score @s m.trig matches 4093 run function metiers:c/oublier_13
execute if score @s m.trig matches 4394 if entity @s[tag=metiers.skoff.c14] run function metiers:c/activer_14
execute if score @s m.trig matches 4094 run function metiers:c/oublier_14
execute if score @s m.trig matches 4395 if entity @s[tag=metiers.skoff.c15] run function metiers:c/activer_15
execute if score @s m.trig matches 4095 run function metiers:c/oublier_15
execute if score @s m.trig matches 4396 if entity @s[tag=metiers.skoff.c16] run function metiers:c/activer_16
execute if score @s m.trig matches 4096 run function metiers:c/oublier_16
execute if score @s m.trig matches 4397 if entity @s[tag=metiers.skoff.c17] run function metiers:c/activer_17
execute if score @s m.trig matches 4097 run function metiers:c/oublier_17
execute if score @s m.trig matches 4398 if entity @s[tag=metiers.skoff.c18] run function metiers:c/activer_18
execute if score @s m.trig matches 4098 run function metiers:c/oublier_18
execute if score @s m.trig matches 4401 if entity @s[tag=metiers.skoff.p1] run function metiers:p/activer_1
execute if score @s m.trig matches 4101 run function metiers:p/oublier_1
execute if score @s m.trig matches 4402 if entity @s[tag=metiers.skoff.p2] run function metiers:p/activer_2
execute if score @s m.trig matches 4102 run function metiers:p/oublier_2
execute if score @s m.trig matches 4403 if entity @s[tag=metiers.skoff.p3] run function metiers:p/activer_3
execute if score @s m.trig matches 4103 run function metiers:p/oublier_3
execute if score @s m.trig matches 4404 if entity @s[tag=metiers.skoff.p4] run function metiers:p/activer_4
execute if score @s m.trig matches 4104 run function metiers:p/oublier_4
execute if score @s m.trig matches 4405 if entity @s[tag=metiers.skoff.p5] run function metiers:p/activer_5
execute if score @s m.trig matches 4105 run function metiers:p/oublier_5
execute if score @s m.trig matches 4406 if entity @s[tag=metiers.skoff.p6] run function metiers:p/activer_6
execute if score @s m.trig matches 4106 run function metiers:p/oublier_6
execute if score @s m.trig matches 4407 if entity @s[tag=metiers.skoff.p7] run function metiers:p/activer_7
execute if score @s m.trig matches 4107 run function metiers:p/oublier_7
execute if score @s m.trig matches 4408 if entity @s[tag=metiers.skoff.p8] run function metiers:p/activer_8
execute if score @s m.trig matches 4108 run function metiers:p/oublier_8
execute if score @s m.trig matches 4409 if entity @s[tag=metiers.skoff.p9] run function metiers:p/activer_9
execute if score @s m.trig matches 4109 run function metiers:p/oublier_9
execute if score @s m.trig matches 4410 if entity @s[tag=metiers.skoff.p10] run function metiers:p/activer_10
execute if score @s m.trig matches 4110 run function metiers:p/oublier_10
execute if score @s m.trig matches 4411 if entity @s[tag=metiers.skoff.p11] run function metiers:p/activer_11
execute if score @s m.trig matches 4111 run function metiers:p/oublier_11
execute if score @s m.trig matches 4412 if entity @s[tag=metiers.skoff.p12] run function metiers:p/activer_12
execute if score @s m.trig matches 4112 run function metiers:p/oublier_12
execute if score @s m.trig matches 4413 if entity @s[tag=metiers.skoff.p13] run function metiers:p/activer_13
execute if score @s m.trig matches 4113 run function metiers:p/oublier_13
execute if score @s m.trig matches 4414 if entity @s[tag=metiers.skoff.p14] run function metiers:p/activer_14
execute if score @s m.trig matches 4114 run function metiers:p/oublier_14
execute if score @s m.trig matches 4415 if entity @s[tag=metiers.skoff.p15] run function metiers:p/activer_15
execute if score @s m.trig matches 4115 run function metiers:p/oublier_15
execute if score @s m.trig matches 4416 if entity @s[tag=metiers.skoff.p16] run function metiers:p/activer_16
execute if score @s m.trig matches 4116 run function metiers:p/oublier_16
execute if score @s m.trig matches 4417 if entity @s[tag=metiers.skoff.p17] run function metiers:p/activer_17
execute if score @s m.trig matches 4117 run function metiers:p/oublier_17
execute if score @s m.trig matches 4418 if entity @s[tag=metiers.skoff.p18] run function metiers:p/activer_18
execute if score @s m.trig matches 4118 run function metiers:p/oublier_18
execute if score @s m.trig matches 4421 if entity @s[tag=metiers.skoff.e1] run function metiers:e/activer_1
execute if score @s m.trig matches 4121 run function metiers:e/oublier_1
execute if score @s m.trig matches 4422 if entity @s[tag=metiers.skoff.e2] run function metiers:e/activer_2
execute if score @s m.trig matches 4122 run function metiers:e/oublier_2
execute if score @s m.trig matches 4423 if entity @s[tag=metiers.skoff.e3] run function metiers:e/activer_3
execute if score @s m.trig matches 4123 run function metiers:e/oublier_3
execute if score @s m.trig matches 4424 if entity @s[tag=metiers.skoff.e4] run function metiers:e/activer_4
execute if score @s m.trig matches 4124 run function metiers:e/oublier_4
execute if score @s m.trig matches 4425 if entity @s[tag=metiers.skoff.e5] run function metiers:e/activer_5
execute if score @s m.trig matches 4125 run function metiers:e/oublier_5
execute if score @s m.trig matches 4426 if entity @s[tag=metiers.skoff.e6] run function metiers:e/activer_6
execute if score @s m.trig matches 4126 run function metiers:e/oublier_6
execute if score @s m.trig matches 4427 if entity @s[tag=metiers.skoff.e7] run function metiers:e/activer_7
execute if score @s m.trig matches 4127 run function metiers:e/oublier_7
execute if score @s m.trig matches 4428 if entity @s[tag=metiers.skoff.e8] run function metiers:e/activer_8
execute if score @s m.trig matches 4128 run function metiers:e/oublier_8
execute if score @s m.trig matches 4429 if entity @s[tag=metiers.skoff.e9] run function metiers:e/activer_9
execute if score @s m.trig matches 4129 run function metiers:e/oublier_9
execute if score @s m.trig matches 4430 if entity @s[tag=metiers.skoff.e10] run function metiers:e/activer_10
execute if score @s m.trig matches 4130 run function metiers:e/oublier_10
execute if score @s m.trig matches 4431 if entity @s[tag=metiers.skoff.e11] run function metiers:e/activer_11
execute if score @s m.trig matches 4131 run function metiers:e/oublier_11
execute if score @s m.trig matches 4432 if entity @s[tag=metiers.skoff.e12] run function metiers:e/activer_12
execute if score @s m.trig matches 4132 run function metiers:e/oublier_12
execute if score @s m.trig matches 4433 if entity @s[tag=metiers.skoff.e13] run function metiers:e/activer_13
execute if score @s m.trig matches 4133 run function metiers:e/oublier_13
execute if score @s m.trig matches 4434 if entity @s[tag=metiers.skoff.e14] run function metiers:e/activer_14
execute if score @s m.trig matches 4134 run function metiers:e/oublier_14
execute if score @s m.trig matches 4435 if entity @s[tag=metiers.skoff.e15] run function metiers:e/activer_15
execute if score @s m.trig matches 4135 run function metiers:e/oublier_15
execute if score @s m.trig matches 4436 if entity @s[tag=metiers.skoff.e16] run function metiers:e/activer_16
execute if score @s m.trig matches 4136 run function metiers:e/oublier_16
execute if score @s m.trig matches 4437 if entity @s[tag=metiers.skoff.e17] run function metiers:e/activer_17
execute if score @s m.trig matches 4137 run function metiers:e/oublier_17
execute if score @s m.trig matches 4438 if entity @s[tag=metiers.skoff.e18] run function metiers:e/activer_18
execute if score @s m.trig matches 4138 run function metiers:e/oublier_18
execute if score @s m.trig matches 4441 if entity @s[tag=metiers.skoff.n1] run function metiers:n/activer_1
execute if score @s m.trig matches 4141 run function metiers:n/oublier_1
execute if score @s m.trig matches 4442 if entity @s[tag=metiers.skoff.n2] run function metiers:n/activer_2
execute if score @s m.trig matches 4142 run function metiers:n/oublier_2
execute if score @s m.trig matches 4443 if entity @s[tag=metiers.skoff.n3] run function metiers:n/activer_3
execute if score @s m.trig matches 4143 run function metiers:n/oublier_3
execute if score @s m.trig matches 4444 if entity @s[tag=metiers.skoff.n4] run function metiers:n/activer_4
execute if score @s m.trig matches 4144 run function metiers:n/oublier_4
execute if score @s m.trig matches 4445 if entity @s[tag=metiers.skoff.n5] run function metiers:n/activer_5
execute if score @s m.trig matches 4145 run function metiers:n/oublier_5
execute if score @s m.trig matches 4446 if entity @s[tag=metiers.skoff.n6] run function metiers:n/activer_6
execute if score @s m.trig matches 4146 run function metiers:n/oublier_6
execute if score @s m.trig matches 4447 if entity @s[tag=metiers.skoff.n7] run function metiers:n/activer_7
execute if score @s m.trig matches 4147 run function metiers:n/oublier_7
execute if score @s m.trig matches 4448 if entity @s[tag=metiers.skoff.n8] run function metiers:n/activer_8
execute if score @s m.trig matches 4148 run function metiers:n/oublier_8
execute if score @s m.trig matches 4449 if entity @s[tag=metiers.skoff.n9] run function metiers:n/activer_9
execute if score @s m.trig matches 4149 run function metiers:n/oublier_9
execute if score @s m.trig matches 4450 if entity @s[tag=metiers.skoff.n10] run function metiers:n/activer_10
execute if score @s m.trig matches 4150 run function metiers:n/oublier_10
execute if score @s m.trig matches 4451 if entity @s[tag=metiers.skoff.n11] run function metiers:n/activer_11
execute if score @s m.trig matches 4151 run function metiers:n/oublier_11
execute if score @s m.trig matches 4452 if entity @s[tag=metiers.skoff.n12] run function metiers:n/activer_12
execute if score @s m.trig matches 4152 run function metiers:n/oublier_12
execute if score @s m.trig matches 4453 if entity @s[tag=metiers.skoff.n13] run function metiers:n/activer_13
execute if score @s m.trig matches 4153 run function metiers:n/oublier_13
execute if score @s m.trig matches 4454 if entity @s[tag=metiers.skoff.n14] run function metiers:n/activer_14
execute if score @s m.trig matches 4154 run function metiers:n/oublier_14
execute if score @s m.trig matches 4455 if entity @s[tag=metiers.skoff.n15] run function metiers:n/activer_15
execute if score @s m.trig matches 4155 run function metiers:n/oublier_15
execute if score @s m.trig matches 4456 if entity @s[tag=metiers.skoff.n16] run function metiers:n/activer_16
execute if score @s m.trig matches 4156 run function metiers:n/oublier_16
execute if score @s m.trig matches 4457 if entity @s[tag=metiers.skoff.n17] run function metiers:n/activer_17
execute if score @s m.trig matches 4157 run function metiers:n/oublier_17
execute if score @s m.trig matches 4458 if entity @s[tag=metiers.skoff.n18] run function metiers:n/activer_18
execute if score @s m.trig matches 4158 run function metiers:n/oublier_18
execute if score @s m.trig matches 4461 if entity @s[tag=metiers.skoff.x1] run function metiers:x/activer_1
execute if score @s m.trig matches 4161 run function metiers:x/oublier_1
execute if score @s m.trig matches 4462 if entity @s[tag=metiers.skoff.x2] run function metiers:x/activer_2
execute if score @s m.trig matches 4162 run function metiers:x/oublier_2
execute if score @s m.trig matches 4463 if entity @s[tag=metiers.skoff.x3] run function metiers:x/activer_3
execute if score @s m.trig matches 4163 run function metiers:x/oublier_3
execute if score @s m.trig matches 4464 if entity @s[tag=metiers.skoff.x4] run function metiers:x/activer_4
execute if score @s m.trig matches 4164 run function metiers:x/oublier_4
execute if score @s m.trig matches 4465 if entity @s[tag=metiers.skoff.x5] run function metiers:x/activer_5
execute if score @s m.trig matches 4165 run function metiers:x/oublier_5
execute if score @s m.trig matches 4466 if entity @s[tag=metiers.skoff.x6] run function metiers:x/activer_6
execute if score @s m.trig matches 4166 run function metiers:x/oublier_6
execute if score @s m.trig matches 4467 if entity @s[tag=metiers.skoff.x7] run function metiers:x/activer_7
execute if score @s m.trig matches 4167 run function metiers:x/oublier_7
execute if score @s m.trig matches 4468 if entity @s[tag=metiers.skoff.x8] run function metiers:x/activer_8
execute if score @s m.trig matches 4168 run function metiers:x/oublier_8
execute if score @s m.trig matches 4469 if entity @s[tag=metiers.skoff.x9] run function metiers:x/activer_9
execute if score @s m.trig matches 4169 run function metiers:x/oublier_9
execute if score @s m.trig matches 4470 if entity @s[tag=metiers.skoff.x10] run function metiers:x/activer_10
execute if score @s m.trig matches 4170 run function metiers:x/oublier_10
execute if score @s m.trig matches 4471 if entity @s[tag=metiers.skoff.x11] run function metiers:x/activer_11
execute if score @s m.trig matches 4171 run function metiers:x/oublier_11
execute if score @s m.trig matches 4472 if entity @s[tag=metiers.skoff.x12] run function metiers:x/activer_12
execute if score @s m.trig matches 4172 run function metiers:x/oublier_12
execute if score @s m.trig matches 4473 if entity @s[tag=metiers.skoff.x13] run function metiers:x/activer_13
execute if score @s m.trig matches 4173 run function metiers:x/oublier_13
execute if score @s m.trig matches 4474 if entity @s[tag=metiers.skoff.x14] run function metiers:x/activer_14
execute if score @s m.trig matches 4174 run function metiers:x/oublier_14
execute if score @s m.trig matches 4475 if entity @s[tag=metiers.skoff.x15] run function metiers:x/activer_15
execute if score @s m.trig matches 4175 run function metiers:x/oublier_15
execute if score @s m.trig matches 4476 if entity @s[tag=metiers.skoff.x16] run function metiers:x/activer_16
execute if score @s m.trig matches 4176 run function metiers:x/oublier_16
execute if score @s m.trig matches 4477 if entity @s[tag=metiers.skoff.x17] run function metiers:x/activer_17
execute if score @s m.trig matches 4177 run function metiers:x/oublier_17
execute if score @s m.trig matches 4478 if entity @s[tag=metiers.skoff.x18] run function metiers:x/activer_18
execute if score @s m.trig matches 4178 run function metiers:x/oublier_18
execute if score @s m.trig matches 4481 if entity @s[tag=metiers.skoff.t1] run function metiers:t/activer_1
execute if score @s m.trig matches 4181 run function metiers:t/oublier_1
execute if score @s m.trig matches 4482 if entity @s[tag=metiers.skoff.t2] run function metiers:t/activer_2
execute if score @s m.trig matches 4182 run function metiers:t/oublier_2
execute if score @s m.trig matches 4483 if entity @s[tag=metiers.skoff.t3] run function metiers:t/activer_3
execute if score @s m.trig matches 4183 run function metiers:t/oublier_3
execute if score @s m.trig matches 4484 if entity @s[tag=metiers.skoff.t4] run function metiers:t/activer_4
execute if score @s m.trig matches 4184 run function metiers:t/oublier_4
execute if score @s m.trig matches 4485 if entity @s[tag=metiers.skoff.t5] run function metiers:t/activer_5
execute if score @s m.trig matches 4185 run function metiers:t/oublier_5
execute if score @s m.trig matches 4486 if entity @s[tag=metiers.skoff.t6] run function metiers:t/activer_6
execute if score @s m.trig matches 4186 run function metiers:t/oublier_6
execute if score @s m.trig matches 4487 if entity @s[tag=metiers.skoff.t7] run function metiers:t/activer_7
execute if score @s m.trig matches 4187 run function metiers:t/oublier_7
execute if score @s m.trig matches 4488 if entity @s[tag=metiers.skoff.t8] run function metiers:t/activer_8
execute if score @s m.trig matches 4188 run function metiers:t/oublier_8
execute if score @s m.trig matches 4489 if entity @s[tag=metiers.skoff.t9] run function metiers:t/activer_9
execute if score @s m.trig matches 4189 run function metiers:t/oublier_9
execute if score @s m.trig matches 4490 if entity @s[tag=metiers.skoff.t10] run function metiers:t/activer_10
execute if score @s m.trig matches 4190 run function metiers:t/oublier_10
execute if score @s m.trig matches 4491 if entity @s[tag=metiers.skoff.t11] run function metiers:t/activer_11
execute if score @s m.trig matches 4191 run function metiers:t/oublier_11
execute if score @s m.trig matches 4492 if entity @s[tag=metiers.skoff.t12] run function metiers:t/activer_12
execute if score @s m.trig matches 4192 run function metiers:t/oublier_12
execute if score @s m.trig matches 4493 if entity @s[tag=metiers.skoff.t13] run function metiers:t/activer_13
execute if score @s m.trig matches 4193 run function metiers:t/oublier_13
execute if score @s m.trig matches 4494 if entity @s[tag=metiers.skoff.t14] run function metiers:t/activer_14
execute if score @s m.trig matches 4194 run function metiers:t/oublier_14
execute if score @s m.trig matches 4495 if entity @s[tag=metiers.skoff.t15] run function metiers:t/activer_15
execute if score @s m.trig matches 4195 run function metiers:t/oublier_15
execute if score @s m.trig matches 4496 if entity @s[tag=metiers.skoff.t16] run function metiers:t/activer_16
execute if score @s m.trig matches 4196 run function metiers:t/oublier_16
execute if score @s m.trig matches 4497 if entity @s[tag=metiers.skoff.t17] run function metiers:t/activer_17
execute if score @s m.trig matches 4197 run function metiers:t/oublier_17
execute if score @s m.trig matches 4498 if entity @s[tag=metiers.skoff.t18] run function metiers:t/activer_18
execute if score @s m.trig matches 4198 run function metiers:t/oublier_18
execute if score @s m.trig matches 4501 if entity @s[tag=metiers.skoff.k1] run function metiers:k/activer_1
execute if score @s m.trig matches 4201 run function metiers:k/oublier_1
execute if score @s m.trig matches 4502 if entity @s[tag=metiers.skoff.k2] run function metiers:k/activer_2
execute if score @s m.trig matches 4202 run function metiers:k/oublier_2
execute if score @s m.trig matches 4503 if entity @s[tag=metiers.skoff.k3] run function metiers:k/activer_3
execute if score @s m.trig matches 4203 run function metiers:k/oublier_3
execute if score @s m.trig matches 4504 if entity @s[tag=metiers.skoff.k4] run function metiers:k/activer_4
execute if score @s m.trig matches 4204 run function metiers:k/oublier_4
execute if score @s m.trig matches 4505 if entity @s[tag=metiers.skoff.k5] run function metiers:k/activer_5
execute if score @s m.trig matches 4205 run function metiers:k/oublier_5
execute if score @s m.trig matches 4506 if entity @s[tag=metiers.skoff.k6] run function metiers:k/activer_6
execute if score @s m.trig matches 4206 run function metiers:k/oublier_6
execute if score @s m.trig matches 400 run function metiers:appel {f:"forge/menu"}
execute if score @s m.trig matches 470 run function metiers:appel {f:"forge/outil"}
execute if score @s m.trig matches 471 run function metiers:appel {f:"forge/menu"}
execute if score @s m.trig matches 472 run function metiers:appel {f:"skins/cadres"}
execute if score @s m.trig matches 411 run function metiers:appel {f:"forge/sertir_sagesse"}
execute if score @s m.trig matches 412 run function metiers:appel {f:"forge/sertir_fortune"}
execute if score @s m.trig matches 413 run function metiers:appel {f:"forge/sertir_echo"}
execute if score @s m.trig matches 414 run function metiers:appel {f:"forge/eff"}
execute if score @s m.trig matches 415 run function metiers:appel {f:"forge/retirer"}
execute if score @s m.trig matches 420 run function metiers:appel {f:"skins/menu"}
execute if score @s m.trig matches 421 run function metiers:appel {f:"skins/cycle"}
execute if score @s m.trig matches 430 run function metiers:appel {f:"skins/choix_0"}
execute if score @s m.trig matches 431 run function metiers:appel {f:"skins/choix_1"}
execute if score @s m.trig matches 432 run function metiers:appel {f:"skins/choix_2"}
execute if score @s m.trig matches 433 run function metiers:appel {f:"skins/choix_3"}
execute if score @s m.trig matches 434 run function metiers:appel {f:"skins/choix_4"}
execute if score @s m.trig matches 435 run function metiers:appel {f:"skins/choix_5"}
execute if score @s m.trig matches 436 run function metiers:appel {f:"skins/choix_6"}
execute if score @s m.trig matches 440 run function metiers:appel {f:"skins/cadre_0"}
execute if score @s m.trig matches 441 run function metiers:appel {f:"skins/cadre_1"}
execute if score @s m.trig matches 442 run function metiers:appel {f:"skins/cadre_2"}
execute if score @s m.trig matches 443 run function metiers:appel {f:"skins/cadre_3"}
execute if score @s m.trig matches 444 run function metiers:appel {f:"skins/cadre_4"}
execute if score @s m.trig matches 445 run function metiers:appel {f:"skins/cadre_5"}
execute if score @s m.trig matches 446 run function metiers:appel {f:"skins/cadre_6"}
execute if score @s m.trig matches 601 run function metiers:appel {f:"b/titre"}
execute if score @s m.trig matches 602 run function metiers:appel {f:"f/titre"}
execute if score @s m.trig matches 603 run function metiers:appel {f:"m/titre"}
execute if score @s m.trig matches 604 run function metiers:appel {f:"c/titre"}
execute if score @s m.trig matches 605 run function metiers:appel {f:"p/titre"}
execute if score @s m.trig matches 606 run function metiers:appel {f:"e/titre"}
execute if score @s m.trig matches 607 run function metiers:appel {f:"n/titre"}
execute if score @s m.trig matches 608 run function metiers:appel {f:"x/titre"}
execute if score @s m.trig matches 609 run function metiers:appel {f:"t/titre"}
execute if score @s m.trig matches 620 run function metiers:appel {f:"k/titre"}
execute if score @s m.trig matches 497 run function metiers:appel {f:"activites"}
execute if score @s m.trig matches 614 run function metiers:appel {f:"k/kit"}
execute if score @s m.trig matches 610 run function metiers:appel {f:"f/saison"}
execute if score @s m.trig matches 611 run function metiers:appel {f:"n/surpuissance"}
execute if score @s m.trig matches 612 run function metiers:appel {f:"sac/donner"}
execute if score @s m.trig matches 613 run function metiers:appel {f:"c/arc_recup"}
execute if score @s m.trig matches 701 run function metiers:appel {f:"tp/enregistrer"}
execute if score @s m.trig matches 702 run function metiers:appel {f:"tp/effacer"}
execute if score @s m.trig matches 721..730 run function metiers:appel {f:"tp/aller"}
execute if score @s m.trig matches 741..750 run function metiers:appel {f:"tp/renommer"}
execute if score @s m.trig matches 460 run function metiers:appel {f:"aide"}
execute if score @s m.trig matches 761 run function metiers:appel {f:"m/soie"}
execute if score @s m.trig matches 551 run function metiers:appel {f:"b/onglet_outil"}
execute if score @s m.trig matches 552 run function metiers:appel {f:"f/onglet_outil"}
execute if score @s m.trig matches 553 run function metiers:appel {f:"m/onglet_outil"}
execute if score @s m.trig matches 554 run function metiers:appel {f:"c/onglet_outil"}
execute if score @s m.trig matches 555 run function metiers:appel {f:"p/onglet_outil"}
execute if score @s m.trig matches 556 run function metiers:appel {f:"e/onglet_outil"}
execute if score @s m.trig matches 557 run function metiers:appel {f:"n/onglet_outil"}
execute if score @s m.trig matches 558 run function metiers:appel {f:"x/onglet_outil"}
execute if score @s m.trig matches 559 run function metiers:appel {f:"t/onglet_outil"}
execute if score @s m.trig matches 560 run function metiers:appel {f:"k/onglet_outil"}
execute if score @s m.trig matches 561 run function metiers:appel {f:"b/onglet_prog"}
execute if score @s m.trig matches 562 run function metiers:appel {f:"f/onglet_prog"}
execute if score @s m.trig matches 563 run function metiers:appel {f:"m/onglet_prog"}
execute if score @s m.trig matches 564 run function metiers:appel {f:"c/onglet_prog"}
execute if score @s m.trig matches 565 run function metiers:appel {f:"p/onglet_prog"}
execute if score @s m.trig matches 566 run function metiers:appel {f:"e/onglet_prog"}
execute if score @s m.trig matches 567 run function metiers:appel {f:"n/onglet_prog"}
execute if score @s m.trig matches 568 run function metiers:appel {f:"x/onglet_prog"}
execute if score @s m.trig matches 569 run function metiers:appel {f:"t/onglet_prog"}
execute if score @s m.trig matches 570 run function metiers:appel {f:"k/onglet_prog"}
execute if score @s m.trig matches 491 run function metiers:appel {f:"bareme/c2"}
execute if score @s m.trig matches 492 run function metiers:appel {f:"bareme/m2"}
execute if score @s m.trig matches 480 run function metiers:appel {f:"bareme/menu"}
execute if score @s m.trig matches 481 run function metiers:appel {f:"bareme/b"}
execute if score @s m.trig matches 482 run function metiers:appel {f:"bareme/f"}
execute if score @s m.trig matches 483 run function metiers:appel {f:"bareme/m"}
execute if score @s m.trig matches 484 run function metiers:appel {f:"bareme/c"}
execute if score @s m.trig matches 485 run function metiers:appel {f:"bareme/p"}
execute if score @s m.trig matches 486 run function metiers:appel {f:"bareme/e"}
execute if score @s m.trig matches 487 run function metiers:appel {f:"bareme/n"}
execute if score @s m.trig matches 488 run function metiers:appel {f:"bareme/x"}
execute if score @s m.trig matches 489 run function metiers:appel {f:"bareme/t"}
execute if score @s m.trig matches 490 run function metiers:appel {f:"bareme/k"}
execute if score @s m.trig matches 447 run function metiers:appel {f:"skins/cadre_7"}
execute if score @s m.trig matches 499 run function metiers:appel {f:"prestige/aura_basculer"}
execute if score @s m.trig matches 495 run function metiers:appel {f:"quete/page"}
execute if score @s m.trig matches 496 run function metiers:appel {f:"synergie/page"}
execute if score @s m.trig matches 770 run function metiers:appel {f:"guilde/page"}
execute if score @s m.trig matches 771 run function metiers:appel {f:"guilde/creer"}
execute if score @s m.trig matches 772 run function metiers:appel {f:"guilde/quitter"}
execute if score @s m.trig matches 773 run function metiers:appel {f:"guilde/inviter_liste"}
execute if score @s m.trig matches 775 run function metiers:appel {f:"guilde/accepter"}
execute if score @s m.trig matches 7100000..7199999 run function metiers:appel {f:"guilde/inviter"}
execute if score @s m.trig matches 7200000..7299999 run function metiers:appel {f:"guilde/exclure"}
execute if score @s m.trig matches 521 run function metiers:appel {f:"classement/metier_b"}
execute if score @s m.trig matches 522 run function metiers:appel {f:"classement/metier_f"}
execute if score @s m.trig matches 523 run function metiers:appel {f:"classement/metier_m"}
execute if score @s m.trig matches 524 run function metiers:appel {f:"classement/metier_c"}
execute if score @s m.trig matches 525 run function metiers:appel {f:"classement/metier_p"}
execute if score @s m.trig matches 526 run function metiers:appel {f:"classement/metier_e"}
execute if score @s m.trig matches 527 run function metiers:appel {f:"classement/metier_n"}
execute if score @s m.trig matches 528 run function metiers:appel {f:"classement/metier_x"}
execute if score @s m.trig matches 529 run function metiers:appel {f:"classement/metier_t"}
execute if score @s m.trig matches 530 run function metiers:appel {f:"classement/metier_k"}
execute if score @s m.trig matches 540 run function metiers:sommaire
