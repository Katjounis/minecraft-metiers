scoreboard players operation @s m.trig = @s metiers
scoreboard players set @s metiers 0
scoreboard players enable @s metiers
execute if score @s m.trig matches 1 run function metiers:menu
execute if score @s m.trig matches 2 run function metiers:prefixe/menu
execute if score @s m.trig matches 3 unless function metiers:recompenses run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucune récompense en attente.","color":"gray"}]
execute if score @s m.trig matches 10..20 run function metiers:prefixe/choisir
execute if score @s m.trig matches 4 run function metiers:appel {f:"defis/menu"}
execute if score @s m.trig matches 5 run function metiers:appel {f:"classement/menu"}
execute if score @s m.trig matches 7 run function metiers:appel {f:"defis/basculer"}
execute if score @s m.trig matches 6 run function metiers:appel {f:"armure/menu"}
execute if score @s m.trig matches 8 run function metiers:appel {f:"armure/recup"}
execute if score @s m.trig matches 70 run function metiers:appel {f:"p/carnet"}
execute if score @s m.trig matches 301 run function metiers:appel {f:"b/outil_recup"}
execute if score @s m.trig matches 311 run function metiers:appel {f:"b/prestige_confirmer"}
execute if score @s m.trig matches 321 run function metiers:appel {f:"b/prestige"}
execute if score @s m.trig matches 331 run function metiers:appel {f:"b/outil_reparer"}
execute if score @s m.trig matches 341 run function metiers:appel {f:"b/recompenses_menu"}
execute if score @s m.trig matches 302 run function metiers:appel {f:"f/outil_recup"}
execute if score @s m.trig matches 312 run function metiers:appel {f:"f/prestige_confirmer"}
execute if score @s m.trig matches 322 run function metiers:appel {f:"f/prestige"}
execute if score @s m.trig matches 332 run function metiers:appel {f:"f/outil_reparer"}
execute if score @s m.trig matches 342 run function metiers:appel {f:"f/recompenses_menu"}
execute if score @s m.trig matches 303 run function metiers:appel {f:"m/outil_recup"}
execute if score @s m.trig matches 313 run function metiers:appel {f:"m/prestige_confirmer"}
execute if score @s m.trig matches 323 run function metiers:appel {f:"m/prestige"}
execute if score @s m.trig matches 333 run function metiers:appel {f:"m/outil_reparer"}
execute if score @s m.trig matches 343 run function metiers:appel {f:"m/recompenses_menu"}
execute if score @s m.trig matches 304 run function metiers:appel {f:"c/outil_recup"}
execute if score @s m.trig matches 314 run function metiers:appel {f:"c/prestige_confirmer"}
execute if score @s m.trig matches 324 run function metiers:appel {f:"c/prestige"}
execute if score @s m.trig matches 334 run function metiers:appel {f:"c/outil_reparer"}
execute if score @s m.trig matches 344 run function metiers:appel {f:"c/recompenses_menu"}
execute if score @s m.trig matches 305 run function metiers:appel {f:"p/outil_recup"}
execute if score @s m.trig matches 315 run function metiers:appel {f:"p/prestige_confirmer"}
execute if score @s m.trig matches 325 run function metiers:appel {f:"p/prestige"}
execute if score @s m.trig matches 335 run function metiers:appel {f:"p/outil_reparer"}
execute if score @s m.trig matches 345 run function metiers:appel {f:"p/recompenses_menu"}
execute if score @s m.trig matches 306 run function metiers:appel {f:"e/outil_recup"}
execute if score @s m.trig matches 316 run function metiers:appel {f:"e/prestige_confirmer"}
execute if score @s m.trig matches 326 run function metiers:appel {f:"e/prestige"}
execute if score @s m.trig matches 336 run function metiers:appel {f:"e/outil_reparer"}
execute if score @s m.trig matches 346 run function metiers:appel {f:"e/recompenses_menu"}
execute if score @s m.trig matches 307 run function metiers:appel {f:"n/outil_recup"}
execute if score @s m.trig matches 317 run function metiers:appel {f:"n/prestige_confirmer"}
execute if score @s m.trig matches 327 run function metiers:appel {f:"n/prestige"}
execute if score @s m.trig matches 337 run function metiers:appel {f:"n/outil_reparer"}
execute if score @s m.trig matches 347 run function metiers:appel {f:"n/recompenses_menu"}
execute if score @s m.trig matches 308 run function metiers:appel {f:"x/outil_recup"}
execute if score @s m.trig matches 318 run function metiers:appel {f:"x/prestige_confirmer"}
execute if score @s m.trig matches 328 run function metiers:appel {f:"x/prestige"}
execute if score @s m.trig matches 338 run function metiers:appel {f:"x/outil_reparer"}
execute if score @s m.trig matches 348 run function metiers:appel {f:"x/recompenses_menu"}
execute if score @s m.trig matches 309 run function metiers:appel {f:"t/outil_recup"}
execute if score @s m.trig matches 319 run function metiers:appel {f:"t/prestige_confirmer"}
execute if score @s m.trig matches 329 run function metiers:appel {f:"t/prestige"}
execute if score @s m.trig matches 339 run function metiers:appel {f:"t/outil_reparer"}
execute if score @s m.trig matches 349 run function metiers:appel {f:"t/recompenses_menu"}
execute if score @s m.trig matches 310 run function metiers:appel {f:"k/outil_recup"}
execute if score @s m.trig matches 320 run function metiers:appel {f:"k/prestige_confirmer"}
execute if score @s m.trig matches 330 run function metiers:appel {f:"k/prestige"}
execute if score @s m.trig matches 340 run function metiers:appel {f:"k/outil_reparer"}
execute if score @s m.trig matches 350 run function metiers:appel {f:"k/recompenses_menu"}
execute if score @s m.trig matches 21 run function metiers:b/arbre
execute if score @s m.trig matches 201 run function metiers:b/reclamer
execute if score @s m.trig matches 111 run function metiers:b/acheter_1
execute if score @s m.trig matches 112 run function metiers:b/acheter_2
execute if score @s m.trig matches 113 run function metiers:b/acheter_3
execute if score @s m.trig matches 114 run function metiers:b/acheter_4
execute if score @s m.trig matches 115 run function metiers:b/acheter_5
execute if score @s m.trig matches 116 run function metiers:b/acheter_6
execute if score @s m.trig matches 3027 run function metiers:b/acheter_7
execute if score @s m.trig matches 3028 run function metiers:b/acheter_8
execute if score @s m.trig matches 3029 run function metiers:b/acheter_9
execute if score @s m.trig matches 3030 run function metiers:b/acheter_10
execute if score @s m.trig matches 3031 run function metiers:b/acheter_11
execute if score @s m.trig matches 3032 run function metiers:b/acheter_12
execute if score @s m.trig matches 3033 run function metiers:b/acheter_13
execute if score @s m.trig matches 3034 run function metiers:b/acheter_14
execute if score @s m.trig matches 3035 run function metiers:b/acheter_15
execute if score @s m.trig matches 3036 run function metiers:b/acheter_16
execute if score @s m.trig matches 3037 run function metiers:b/acheter_17
execute if score @s m.trig matches 3038 run function metiers:b/acheter_18
execute if score @s m.trig matches 22 run function metiers:f/arbre
execute if score @s m.trig matches 202 run function metiers:f/reclamer
execute if score @s m.trig matches 121 run function metiers:f/acheter_1
execute if score @s m.trig matches 122 run function metiers:f/acheter_2
execute if score @s m.trig matches 123 run function metiers:f/acheter_3
execute if score @s m.trig matches 124 run function metiers:f/acheter_4
execute if score @s m.trig matches 125 run function metiers:f/acheter_5
execute if score @s m.trig matches 126 run function metiers:f/acheter_6
execute if score @s m.trig matches 3047 run function metiers:f/acheter_7
execute if score @s m.trig matches 3048 run function metiers:f/acheter_8
execute if score @s m.trig matches 3049 run function metiers:f/acheter_9
execute if score @s m.trig matches 3050 run function metiers:f/acheter_10
execute if score @s m.trig matches 3051 run function metiers:f/acheter_11
execute if score @s m.trig matches 3052 run function metiers:f/acheter_12
execute if score @s m.trig matches 3053 run function metiers:f/acheter_13
execute if score @s m.trig matches 3054 run function metiers:f/acheter_14
execute if score @s m.trig matches 3055 run function metiers:f/acheter_15
execute if score @s m.trig matches 3056 run function metiers:f/acheter_16
execute if score @s m.trig matches 3057 run function metiers:f/acheter_17
execute if score @s m.trig matches 3058 run function metiers:f/acheter_18
execute if score @s m.trig matches 23 run function metiers:m/arbre
execute if score @s m.trig matches 203 run function metiers:m/reclamer
execute if score @s m.trig matches 131 run function metiers:m/acheter_1
execute if score @s m.trig matches 132 run function metiers:m/acheter_2
execute if score @s m.trig matches 133 run function metiers:m/acheter_3
execute if score @s m.trig matches 134 run function metiers:m/acheter_4
execute if score @s m.trig matches 135 run function metiers:m/acheter_5
execute if score @s m.trig matches 136 run function metiers:m/acheter_6
execute if score @s m.trig matches 3067 run function metiers:m/acheter_7
execute if score @s m.trig matches 3068 run function metiers:m/acheter_8
execute if score @s m.trig matches 3069 run function metiers:m/acheter_9
execute if score @s m.trig matches 3070 run function metiers:m/acheter_10
execute if score @s m.trig matches 3071 run function metiers:m/acheter_11
execute if score @s m.trig matches 3072 run function metiers:m/acheter_12
execute if score @s m.trig matches 3073 run function metiers:m/acheter_13
execute if score @s m.trig matches 3074 run function metiers:m/acheter_14
execute if score @s m.trig matches 3075 run function metiers:m/acheter_15
execute if score @s m.trig matches 3076 run function metiers:m/acheter_16
execute if score @s m.trig matches 3077 run function metiers:m/acheter_17
execute if score @s m.trig matches 3078 run function metiers:m/acheter_18
execute if score @s m.trig matches 24 run function metiers:c/arbre
execute if score @s m.trig matches 204 run function metiers:c/reclamer
execute if score @s m.trig matches 141 run function metiers:c/acheter_1
execute if score @s m.trig matches 142 run function metiers:c/acheter_2
execute if score @s m.trig matches 143 run function metiers:c/acheter_3
execute if score @s m.trig matches 144 run function metiers:c/acheter_4
execute if score @s m.trig matches 145 run function metiers:c/acheter_5
execute if score @s m.trig matches 146 run function metiers:c/acheter_6
execute if score @s m.trig matches 3087 run function metiers:c/acheter_7
execute if score @s m.trig matches 3088 run function metiers:c/acheter_8
execute if score @s m.trig matches 3089 run function metiers:c/acheter_9
execute if score @s m.trig matches 3090 run function metiers:c/acheter_10
execute if score @s m.trig matches 3091 run function metiers:c/acheter_11
execute if score @s m.trig matches 3092 run function metiers:c/acheter_12
execute if score @s m.trig matches 3093 run function metiers:c/acheter_13
execute if score @s m.trig matches 3094 run function metiers:c/acheter_14
execute if score @s m.trig matches 3095 run function metiers:c/acheter_15
execute if score @s m.trig matches 3096 run function metiers:c/acheter_16
execute if score @s m.trig matches 3097 run function metiers:c/acheter_17
execute if score @s m.trig matches 3098 run function metiers:c/acheter_18
execute if score @s m.trig matches 25 run function metiers:p/arbre
execute if score @s m.trig matches 205 run function metiers:p/reclamer
execute if score @s m.trig matches 151 run function metiers:p/acheter_1
execute if score @s m.trig matches 152 run function metiers:p/acheter_2
execute if score @s m.trig matches 153 run function metiers:p/acheter_3
execute if score @s m.trig matches 154 run function metiers:p/acheter_4
execute if score @s m.trig matches 155 run function metiers:p/acheter_5
execute if score @s m.trig matches 156 run function metiers:p/acheter_6
execute if score @s m.trig matches 3107 run function metiers:p/acheter_7
execute if score @s m.trig matches 3108 run function metiers:p/acheter_8
execute if score @s m.trig matches 3109 run function metiers:p/acheter_9
execute if score @s m.trig matches 3110 run function metiers:p/acheter_10
execute if score @s m.trig matches 3111 run function metiers:p/acheter_11
execute if score @s m.trig matches 3112 run function metiers:p/acheter_12
execute if score @s m.trig matches 3113 run function metiers:p/acheter_13
execute if score @s m.trig matches 3114 run function metiers:p/acheter_14
execute if score @s m.trig matches 3115 run function metiers:p/acheter_15
execute if score @s m.trig matches 3116 run function metiers:p/acheter_16
execute if score @s m.trig matches 3117 run function metiers:p/acheter_17
execute if score @s m.trig matches 3118 run function metiers:p/acheter_18
execute if score @s m.trig matches 26 run function metiers:e/arbre
execute if score @s m.trig matches 206 run function metiers:e/reclamer
execute if score @s m.trig matches 161 run function metiers:e/acheter_1
execute if score @s m.trig matches 162 run function metiers:e/acheter_2
execute if score @s m.trig matches 163 run function metiers:e/acheter_3
execute if score @s m.trig matches 164 run function metiers:e/acheter_4
execute if score @s m.trig matches 165 run function metiers:e/acheter_5
execute if score @s m.trig matches 166 run function metiers:e/acheter_6
execute if score @s m.trig matches 3127 run function metiers:e/acheter_7
execute if score @s m.trig matches 3128 run function metiers:e/acheter_8
execute if score @s m.trig matches 3129 run function metiers:e/acheter_9
execute if score @s m.trig matches 3130 run function metiers:e/acheter_10
execute if score @s m.trig matches 3131 run function metiers:e/acheter_11
execute if score @s m.trig matches 3132 run function metiers:e/acheter_12
execute if score @s m.trig matches 3133 run function metiers:e/acheter_13
execute if score @s m.trig matches 3134 run function metiers:e/acheter_14
execute if score @s m.trig matches 3135 run function metiers:e/acheter_15
execute if score @s m.trig matches 3136 run function metiers:e/acheter_16
execute if score @s m.trig matches 3137 run function metiers:e/acheter_17
execute if score @s m.trig matches 3138 run function metiers:e/acheter_18
execute if score @s m.trig matches 27 run function metiers:n/arbre
execute if score @s m.trig matches 207 run function metiers:n/reclamer
execute if score @s m.trig matches 171 run function metiers:n/acheter_1
execute if score @s m.trig matches 172 run function metiers:n/acheter_2
execute if score @s m.trig matches 173 run function metiers:n/acheter_3
execute if score @s m.trig matches 174 run function metiers:n/acheter_4
execute if score @s m.trig matches 175 run function metiers:n/acheter_5
execute if score @s m.trig matches 176 run function metiers:n/acheter_6
execute if score @s m.trig matches 3147 run function metiers:n/acheter_7
execute if score @s m.trig matches 3148 run function metiers:n/acheter_8
execute if score @s m.trig matches 3149 run function metiers:n/acheter_9
execute if score @s m.trig matches 3150 run function metiers:n/acheter_10
execute if score @s m.trig matches 3151 run function metiers:n/acheter_11
execute if score @s m.trig matches 3152 run function metiers:n/acheter_12
execute if score @s m.trig matches 3153 run function metiers:n/acheter_13
execute if score @s m.trig matches 3154 run function metiers:n/acheter_14
execute if score @s m.trig matches 3155 run function metiers:n/acheter_15
execute if score @s m.trig matches 3156 run function metiers:n/acheter_16
execute if score @s m.trig matches 3157 run function metiers:n/acheter_17
execute if score @s m.trig matches 3158 run function metiers:n/acheter_18
execute if score @s m.trig matches 28 run function metiers:x/arbre
execute if score @s m.trig matches 208 run function metiers:x/reclamer
execute if score @s m.trig matches 181 run function metiers:x/acheter_1
execute if score @s m.trig matches 182 run function metiers:x/acheter_2
execute if score @s m.trig matches 183 run function metiers:x/acheter_3
execute if score @s m.trig matches 184 run function metiers:x/acheter_4
execute if score @s m.trig matches 185 run function metiers:x/acheter_5
execute if score @s m.trig matches 186 run function metiers:x/acheter_6
execute if score @s m.trig matches 3167 run function metiers:x/acheter_7
execute if score @s m.trig matches 3168 run function metiers:x/acheter_8
execute if score @s m.trig matches 3169 run function metiers:x/acheter_9
execute if score @s m.trig matches 3170 run function metiers:x/acheter_10
execute if score @s m.trig matches 3171 run function metiers:x/acheter_11
execute if score @s m.trig matches 3172 run function metiers:x/acheter_12
execute if score @s m.trig matches 3173 run function metiers:x/acheter_13
execute if score @s m.trig matches 3174 run function metiers:x/acheter_14
execute if score @s m.trig matches 3175 run function metiers:x/acheter_15
execute if score @s m.trig matches 3176 run function metiers:x/acheter_16
execute if score @s m.trig matches 3177 run function metiers:x/acheter_17
execute if score @s m.trig matches 3178 run function metiers:x/acheter_18
execute if score @s m.trig matches 29 run function metiers:t/arbre
execute if score @s m.trig matches 209 run function metiers:t/reclamer
execute if score @s m.trig matches 191 run function metiers:t/acheter_1
execute if score @s m.trig matches 192 run function metiers:t/acheter_2
execute if score @s m.trig matches 193 run function metiers:t/acheter_3
execute if score @s m.trig matches 194 run function metiers:t/acheter_4
execute if score @s m.trig matches 195 run function metiers:t/acheter_5
execute if score @s m.trig matches 196 run function metiers:t/acheter_6
execute if score @s m.trig matches 3187 run function metiers:t/acheter_7
execute if score @s m.trig matches 3188 run function metiers:t/acheter_8
execute if score @s m.trig matches 3189 run function metiers:t/acheter_9
execute if score @s m.trig matches 3190 run function metiers:t/acheter_10
execute if score @s m.trig matches 3191 run function metiers:t/acheter_11
execute if score @s m.trig matches 3192 run function metiers:t/acheter_12
execute if score @s m.trig matches 3193 run function metiers:t/acheter_13
execute if score @s m.trig matches 3194 run function metiers:t/acheter_14
execute if score @s m.trig matches 3195 run function metiers:t/acheter_15
execute if score @s m.trig matches 3196 run function metiers:t/acheter_16
execute if score @s m.trig matches 3197 run function metiers:t/acheter_17
execute if score @s m.trig matches 3198 run function metiers:t/acheter_18
execute if score @s m.trig matches 30 run function metiers:k/arbre
execute if score @s m.trig matches 210 run function metiers:k/reclamer
execute if score @s m.trig matches 1001 run function metiers:k/acheter_1
execute if score @s m.trig matches 1002 run function metiers:k/acheter_2
execute if score @s m.trig matches 1003 run function metiers:k/acheter_3
execute if score @s m.trig matches 1004 run function metiers:k/acheter_4
execute if score @s m.trig matches 1005 run function metiers:k/acheter_5
execute if score @s m.trig matches 1006 run function metiers:k/acheter_6
execute if score @s m.trig matches 3500 run function metiers:appel {f:"objets/acheter_graine"}
execute if score @s m.trig matches 3481 run function metiers:appel {f:"objets/boutique_b"}
execute if score @s m.trig matches 3501 run function metiers:appel {f:"objets/acheter_bombe"}
execute if score @s m.trig matches 3502 run function metiers:appel {f:"objets/acheter_arrosoir"}
execute if score @s m.trig matches 3503 run function metiers:appel {f:"objets/acheter_epouvantail"}
execute if score @s m.trig matches 3482 run function metiers:appel {f:"objets/boutique_f"}
execute if score @s m.trig matches 3504 run function metiers:appel {f:"objets/acheter_dynamite"}
execute if score @s m.trig matches 3505 run function metiers:appel {f:"objets/acheter_lanterne"}
execute if score @s m.trig matches 3483 run function metiers:appel {f:"objets/boutique_m"}
execute if score @s m.trig matches 3506 run function metiers:appel {f:"objets/acheter_piege"}
execute if score @s m.trig matches 3484 run function metiers:appel {f:"objets/boutique_c"}
execute if score @s m.trig matches 3507 run function metiers:appel {f:"objets/acheter_filet"}
execute if score @s m.trig matches 3485 run function metiers:appel {f:"objets/boutique_p"}
execute if score @s m.trig matches 3508 run function metiers:appel {f:"objets/acheter_sifflet"}
execute if score @s m.trig matches 3509 run function metiers:appel {f:"objets/acheter_mangeoire"}
execute if score @s m.trig matches 3486 run function metiers:appel {f:"objets/boutique_e"}
execute if score @s m.trig matches 3510 run function metiers:appel {f:"objets/acheter_tente"}
execute if score @s m.trig matches 3488 run function metiers:appel {f:"objets/boutique_x"}
execute if score @s m.trig matches 3490 run function metiers:appel {f:"comp/n_forge"}
execute if score @s m.trig matches 3492 run function metiers:appel {f:"objets/recup_elytres"}
execute if score @s m.trig matches 4621 run function metiers:b/desactiver_1
execute if score @s m.trig matches 4321 run function metiers:b/activer_1
execute if score @s m.trig matches 4021 run function metiers:b/oublier_1
execute if score @s m.trig matches 4622 run function metiers:b/desactiver_2
execute if score @s m.trig matches 4322 run function metiers:b/activer_2
execute if score @s m.trig matches 4022 run function metiers:b/oublier_2
execute if score @s m.trig matches 4623 run function metiers:b/desactiver_3
execute if score @s m.trig matches 4323 run function metiers:b/activer_3
execute if score @s m.trig matches 4023 run function metiers:b/oublier_3
execute if score @s m.trig matches 4624 run function metiers:b/desactiver_4
execute if score @s m.trig matches 4324 run function metiers:b/activer_4
execute if score @s m.trig matches 4024 run function metiers:b/oublier_4
execute if score @s m.trig matches 4625 run function metiers:b/desactiver_5
execute if score @s m.trig matches 4325 run function metiers:b/activer_5
execute if score @s m.trig matches 4025 run function metiers:b/oublier_5
execute if score @s m.trig matches 4626 run function metiers:b/desactiver_6
execute if score @s m.trig matches 4326 run function metiers:b/activer_6
execute if score @s m.trig matches 4026 run function metiers:b/oublier_6
execute if score @s m.trig matches 4627 run function metiers:b/desactiver_7
execute if score @s m.trig matches 4327 run function metiers:b/activer_7
execute if score @s m.trig matches 4027 run function metiers:b/oublier_7
execute if score @s m.trig matches 4628 run function metiers:b/desactiver_8
execute if score @s m.trig matches 4328 run function metiers:b/activer_8
execute if score @s m.trig matches 4028 run function metiers:b/oublier_8
execute if score @s m.trig matches 4629 run function metiers:b/desactiver_9
execute if score @s m.trig matches 4329 run function metiers:b/activer_9
execute if score @s m.trig matches 4029 run function metiers:b/oublier_9
execute if score @s m.trig matches 4630 run function metiers:b/desactiver_10
execute if score @s m.trig matches 4330 run function metiers:b/activer_10
execute if score @s m.trig matches 4030 run function metiers:b/oublier_10
execute if score @s m.trig matches 4631 run function metiers:b/desactiver_11
execute if score @s m.trig matches 4331 run function metiers:b/activer_11
execute if score @s m.trig matches 4031 run function metiers:b/oublier_11
execute if score @s m.trig matches 4632 run function metiers:b/desactiver_12
execute if score @s m.trig matches 4332 run function metiers:b/activer_12
execute if score @s m.trig matches 4032 run function metiers:b/oublier_12
execute if score @s m.trig matches 4633 run function metiers:b/desactiver_13
execute if score @s m.trig matches 4333 run function metiers:b/activer_13
execute if score @s m.trig matches 4033 run function metiers:b/oublier_13
execute if score @s m.trig matches 4634 run function metiers:b/desactiver_14
execute if score @s m.trig matches 4334 run function metiers:b/activer_14
execute if score @s m.trig matches 4034 run function metiers:b/oublier_14
execute if score @s m.trig matches 4635 run function metiers:b/desactiver_15
execute if score @s m.trig matches 4335 run function metiers:b/activer_15
execute if score @s m.trig matches 4035 run function metiers:b/oublier_15
execute if score @s m.trig matches 4636 run function metiers:b/desactiver_16
execute if score @s m.trig matches 4336 run function metiers:b/activer_16
execute if score @s m.trig matches 4036 run function metiers:b/oublier_16
execute if score @s m.trig matches 4637 run function metiers:b/desactiver_17
execute if score @s m.trig matches 4337 run function metiers:b/activer_17
execute if score @s m.trig matches 4037 run function metiers:b/oublier_17
execute if score @s m.trig matches 4638 run function metiers:b/desactiver_18
execute if score @s m.trig matches 4338 run function metiers:b/activer_18
execute if score @s m.trig matches 4038 run function metiers:b/oublier_18
execute if score @s m.trig matches 4641 run function metiers:f/desactiver_1
execute if score @s m.trig matches 4341 run function metiers:f/activer_1
execute if score @s m.trig matches 4041 run function metiers:f/oublier_1
execute if score @s m.trig matches 4642 run function metiers:f/desactiver_2
execute if score @s m.trig matches 4342 run function metiers:f/activer_2
execute if score @s m.trig matches 4042 run function metiers:f/oublier_2
execute if score @s m.trig matches 4643 run function metiers:f/desactiver_3
execute if score @s m.trig matches 4343 run function metiers:f/activer_3
execute if score @s m.trig matches 4043 run function metiers:f/oublier_3
execute if score @s m.trig matches 4644 run function metiers:f/desactiver_4
execute if score @s m.trig matches 4344 run function metiers:f/activer_4
execute if score @s m.trig matches 4044 run function metiers:f/oublier_4
execute if score @s m.trig matches 4645 run function metiers:f/desactiver_5
execute if score @s m.trig matches 4345 run function metiers:f/activer_5
execute if score @s m.trig matches 4045 run function metiers:f/oublier_5
execute if score @s m.trig matches 4646 run function metiers:f/desactiver_6
execute if score @s m.trig matches 4346 run function metiers:f/activer_6
execute if score @s m.trig matches 4046 run function metiers:f/oublier_6
execute if score @s m.trig matches 4647 run function metiers:f/desactiver_7
execute if score @s m.trig matches 4347 run function metiers:f/activer_7
execute if score @s m.trig matches 4047 run function metiers:f/oublier_7
execute if score @s m.trig matches 4648 run function metiers:f/desactiver_8
execute if score @s m.trig matches 4348 run function metiers:f/activer_8
execute if score @s m.trig matches 4048 run function metiers:f/oublier_8
execute if score @s m.trig matches 4649 run function metiers:f/desactiver_9
execute if score @s m.trig matches 4349 run function metiers:f/activer_9
execute if score @s m.trig matches 4049 run function metiers:f/oublier_9
execute if score @s m.trig matches 4650 run function metiers:f/desactiver_10
execute if score @s m.trig matches 4350 run function metiers:f/activer_10
execute if score @s m.trig matches 4050 run function metiers:f/oublier_10
execute if score @s m.trig matches 4651 run function metiers:f/desactiver_11
execute if score @s m.trig matches 4351 run function metiers:f/activer_11
execute if score @s m.trig matches 4051 run function metiers:f/oublier_11
execute if score @s m.trig matches 4652 run function metiers:f/desactiver_12
execute if score @s m.trig matches 4352 run function metiers:f/activer_12
execute if score @s m.trig matches 4052 run function metiers:f/oublier_12
execute if score @s m.trig matches 4653 run function metiers:f/desactiver_13
execute if score @s m.trig matches 4353 run function metiers:f/activer_13
execute if score @s m.trig matches 4053 run function metiers:f/oublier_13
execute if score @s m.trig matches 4654 run function metiers:f/desactiver_14
execute if score @s m.trig matches 4354 run function metiers:f/activer_14
execute if score @s m.trig matches 4054 run function metiers:f/oublier_14
execute if score @s m.trig matches 4655 run function metiers:f/desactiver_15
execute if score @s m.trig matches 4355 run function metiers:f/activer_15
execute if score @s m.trig matches 4055 run function metiers:f/oublier_15
execute if score @s m.trig matches 4656 run function metiers:f/desactiver_16
execute if score @s m.trig matches 4356 run function metiers:f/activer_16
execute if score @s m.trig matches 4056 run function metiers:f/oublier_16
execute if score @s m.trig matches 4657 run function metiers:f/desactiver_17
execute if score @s m.trig matches 4357 run function metiers:f/activer_17
execute if score @s m.trig matches 4057 run function metiers:f/oublier_17
execute if score @s m.trig matches 4658 run function metiers:f/desactiver_18
execute if score @s m.trig matches 4358 run function metiers:f/activer_18
execute if score @s m.trig matches 4058 run function metiers:f/oublier_18
execute if score @s m.trig matches 4661 run function metiers:m/desactiver_1
execute if score @s m.trig matches 4361 run function metiers:m/activer_1
execute if score @s m.trig matches 4061 run function metiers:m/oublier_1
execute if score @s m.trig matches 4662 run function metiers:m/desactiver_2
execute if score @s m.trig matches 4362 run function metiers:m/activer_2
execute if score @s m.trig matches 4062 run function metiers:m/oublier_2
execute if score @s m.trig matches 4663 run function metiers:m/desactiver_3
execute if score @s m.trig matches 4363 run function metiers:m/activer_3
execute if score @s m.trig matches 4063 run function metiers:m/oublier_3
execute if score @s m.trig matches 4664 run function metiers:m/desactiver_4
execute if score @s m.trig matches 4364 run function metiers:m/activer_4
execute if score @s m.trig matches 4064 run function metiers:m/oublier_4
execute if score @s m.trig matches 4665 run function metiers:m/desactiver_5
execute if score @s m.trig matches 4365 run function metiers:m/activer_5
execute if score @s m.trig matches 4065 run function metiers:m/oublier_5
execute if score @s m.trig matches 4666 run function metiers:m/desactiver_6
execute if score @s m.trig matches 4366 run function metiers:m/activer_6
execute if score @s m.trig matches 4066 run function metiers:m/oublier_6
execute if score @s m.trig matches 4667 run function metiers:m/desactiver_7
execute if score @s m.trig matches 4367 run function metiers:m/activer_7
execute if score @s m.trig matches 4067 run function metiers:m/oublier_7
execute if score @s m.trig matches 4668 run function metiers:m/desactiver_8
execute if score @s m.trig matches 4368 run function metiers:m/activer_8
execute if score @s m.trig matches 4068 run function metiers:m/oublier_8
execute if score @s m.trig matches 4669 run function metiers:m/desactiver_9
execute if score @s m.trig matches 4369 run function metiers:m/activer_9
execute if score @s m.trig matches 4069 run function metiers:m/oublier_9
execute if score @s m.trig matches 4670 run function metiers:m/desactiver_10
execute if score @s m.trig matches 4370 run function metiers:m/activer_10
execute if score @s m.trig matches 4070 run function metiers:m/oublier_10
execute if score @s m.trig matches 4671 run function metiers:m/desactiver_11
execute if score @s m.trig matches 4371 run function metiers:m/activer_11
execute if score @s m.trig matches 4071 run function metiers:m/oublier_11
execute if score @s m.trig matches 4672 run function metiers:m/desactiver_12
execute if score @s m.trig matches 4372 run function metiers:m/activer_12
execute if score @s m.trig matches 4072 run function metiers:m/oublier_12
execute if score @s m.trig matches 4673 run function metiers:m/desactiver_13
execute if score @s m.trig matches 4373 run function metiers:m/activer_13
execute if score @s m.trig matches 4073 run function metiers:m/oublier_13
execute if score @s m.trig matches 4674 run function metiers:m/desactiver_14
execute if score @s m.trig matches 4374 run function metiers:m/activer_14
execute if score @s m.trig matches 4074 run function metiers:m/oublier_14
execute if score @s m.trig matches 4675 run function metiers:m/desactiver_15
execute if score @s m.trig matches 4375 run function metiers:m/activer_15
execute if score @s m.trig matches 4075 run function metiers:m/oublier_15
execute if score @s m.trig matches 4676 run function metiers:m/desactiver_16
execute if score @s m.trig matches 4376 run function metiers:m/activer_16
execute if score @s m.trig matches 4076 run function metiers:m/oublier_16
execute if score @s m.trig matches 4677 run function metiers:m/desactiver_17
execute if score @s m.trig matches 4377 run function metiers:m/activer_17
execute if score @s m.trig matches 4077 run function metiers:m/oublier_17
execute if score @s m.trig matches 4678 run function metiers:m/desactiver_18
execute if score @s m.trig matches 4378 run function metiers:m/activer_18
execute if score @s m.trig matches 4078 run function metiers:m/oublier_18
execute if score @s m.trig matches 4681 run function metiers:c/desactiver_1
execute if score @s m.trig matches 4381 run function metiers:c/activer_1
execute if score @s m.trig matches 4081 run function metiers:c/oublier_1
execute if score @s m.trig matches 4682 run function metiers:c/desactiver_2
execute if score @s m.trig matches 4382 run function metiers:c/activer_2
execute if score @s m.trig matches 4082 run function metiers:c/oublier_2
execute if score @s m.trig matches 4683 run function metiers:c/desactiver_3
execute if score @s m.trig matches 4383 run function metiers:c/activer_3
execute if score @s m.trig matches 4083 run function metiers:c/oublier_3
execute if score @s m.trig matches 4684 run function metiers:c/desactiver_4
execute if score @s m.trig matches 4384 run function metiers:c/activer_4
execute if score @s m.trig matches 4084 run function metiers:c/oublier_4
execute if score @s m.trig matches 4685 run function metiers:c/desactiver_5
execute if score @s m.trig matches 4385 run function metiers:c/activer_5
execute if score @s m.trig matches 4085 run function metiers:c/oublier_5
execute if score @s m.trig matches 4686 run function metiers:c/desactiver_6
execute if score @s m.trig matches 4386 run function metiers:c/activer_6
execute if score @s m.trig matches 4086 run function metiers:c/oublier_6
execute if score @s m.trig matches 4687 run function metiers:c/desactiver_7
execute if score @s m.trig matches 4387 run function metiers:c/activer_7
execute if score @s m.trig matches 4087 run function metiers:c/oublier_7
execute if score @s m.trig matches 4688 run function metiers:c/desactiver_8
execute if score @s m.trig matches 4388 run function metiers:c/activer_8
execute if score @s m.trig matches 4088 run function metiers:c/oublier_8
execute if score @s m.trig matches 4689 run function metiers:c/desactiver_9
execute if score @s m.trig matches 4389 run function metiers:c/activer_9
execute if score @s m.trig matches 4089 run function metiers:c/oublier_9
execute if score @s m.trig matches 4690 run function metiers:c/desactiver_10
execute if score @s m.trig matches 4390 run function metiers:c/activer_10
execute if score @s m.trig matches 4090 run function metiers:c/oublier_10
execute if score @s m.trig matches 4691 run function metiers:c/desactiver_11
execute if score @s m.trig matches 4391 run function metiers:c/activer_11
execute if score @s m.trig matches 4091 run function metiers:c/oublier_11
execute if score @s m.trig matches 4692 run function metiers:c/desactiver_12
execute if score @s m.trig matches 4392 run function metiers:c/activer_12
execute if score @s m.trig matches 4092 run function metiers:c/oublier_12
execute if score @s m.trig matches 4693 run function metiers:c/desactiver_13
execute if score @s m.trig matches 4393 run function metiers:c/activer_13
execute if score @s m.trig matches 4093 run function metiers:c/oublier_13
execute if score @s m.trig matches 4694 run function metiers:c/desactiver_14
execute if score @s m.trig matches 4394 run function metiers:c/activer_14
execute if score @s m.trig matches 4094 run function metiers:c/oublier_14
execute if score @s m.trig matches 4695 run function metiers:c/desactiver_15
execute if score @s m.trig matches 4395 run function metiers:c/activer_15
execute if score @s m.trig matches 4095 run function metiers:c/oublier_15
execute if score @s m.trig matches 4696 run function metiers:c/desactiver_16
execute if score @s m.trig matches 4396 run function metiers:c/activer_16
execute if score @s m.trig matches 4096 run function metiers:c/oublier_16
execute if score @s m.trig matches 4697 run function metiers:c/desactiver_17
execute if score @s m.trig matches 4397 run function metiers:c/activer_17
execute if score @s m.trig matches 4097 run function metiers:c/oublier_17
execute if score @s m.trig matches 4698 run function metiers:c/desactiver_18
execute if score @s m.trig matches 4398 run function metiers:c/activer_18
execute if score @s m.trig matches 4098 run function metiers:c/oublier_18
execute if score @s m.trig matches 4701 run function metiers:p/desactiver_1
execute if score @s m.trig matches 4401 run function metiers:p/activer_1
execute if score @s m.trig matches 4101 run function metiers:p/oublier_1
execute if score @s m.trig matches 4702 run function metiers:p/desactiver_2
execute if score @s m.trig matches 4402 run function metiers:p/activer_2
execute if score @s m.trig matches 4102 run function metiers:p/oublier_2
execute if score @s m.trig matches 4703 run function metiers:p/desactiver_3
execute if score @s m.trig matches 4403 run function metiers:p/activer_3
execute if score @s m.trig matches 4103 run function metiers:p/oublier_3
execute if score @s m.trig matches 4704 run function metiers:p/desactiver_4
execute if score @s m.trig matches 4404 run function metiers:p/activer_4
execute if score @s m.trig matches 4104 run function metiers:p/oublier_4
execute if score @s m.trig matches 4705 run function metiers:p/desactiver_5
execute if score @s m.trig matches 4405 run function metiers:p/activer_5
execute if score @s m.trig matches 4105 run function metiers:p/oublier_5
execute if score @s m.trig matches 4706 run function metiers:p/desactiver_6
execute if score @s m.trig matches 4406 run function metiers:p/activer_6
execute if score @s m.trig matches 4106 run function metiers:p/oublier_6
execute if score @s m.trig matches 4707 run function metiers:p/desactiver_7
execute if score @s m.trig matches 4407 run function metiers:p/activer_7
execute if score @s m.trig matches 4107 run function metiers:p/oublier_7
execute if score @s m.trig matches 4708 run function metiers:p/desactiver_8
execute if score @s m.trig matches 4408 run function metiers:p/activer_8
execute if score @s m.trig matches 4108 run function metiers:p/oublier_8
execute if score @s m.trig matches 4709 run function metiers:p/desactiver_9
execute if score @s m.trig matches 4409 run function metiers:p/activer_9
execute if score @s m.trig matches 4109 run function metiers:p/oublier_9
execute if score @s m.trig matches 4710 run function metiers:p/desactiver_10
execute if score @s m.trig matches 4410 run function metiers:p/activer_10
execute if score @s m.trig matches 4110 run function metiers:p/oublier_10
execute if score @s m.trig matches 4711 run function metiers:p/desactiver_11
execute if score @s m.trig matches 4411 run function metiers:p/activer_11
execute if score @s m.trig matches 4111 run function metiers:p/oublier_11
execute if score @s m.trig matches 4712 run function metiers:p/desactiver_12
execute if score @s m.trig matches 4412 run function metiers:p/activer_12
execute if score @s m.trig matches 4112 run function metiers:p/oublier_12
execute if score @s m.trig matches 4713 run function metiers:p/desactiver_13
execute if score @s m.trig matches 4413 run function metiers:p/activer_13
execute if score @s m.trig matches 4113 run function metiers:p/oublier_13
execute if score @s m.trig matches 4714 run function metiers:p/desactiver_14
execute if score @s m.trig matches 4414 run function metiers:p/activer_14
execute if score @s m.trig matches 4114 run function metiers:p/oublier_14
execute if score @s m.trig matches 4715 run function metiers:p/desactiver_15
execute if score @s m.trig matches 4415 run function metiers:p/activer_15
execute if score @s m.trig matches 4115 run function metiers:p/oublier_15
execute if score @s m.trig matches 4716 run function metiers:p/desactiver_16
execute if score @s m.trig matches 4416 run function metiers:p/activer_16
execute if score @s m.trig matches 4116 run function metiers:p/oublier_16
execute if score @s m.trig matches 4717 run function metiers:p/desactiver_17
execute if score @s m.trig matches 4417 run function metiers:p/activer_17
execute if score @s m.trig matches 4117 run function metiers:p/oublier_17
execute if score @s m.trig matches 4718 run function metiers:p/desactiver_18
execute if score @s m.trig matches 4418 run function metiers:p/activer_18
execute if score @s m.trig matches 4118 run function metiers:p/oublier_18
execute if score @s m.trig matches 4721 run function metiers:e/desactiver_1
execute if score @s m.trig matches 4421 run function metiers:e/activer_1
execute if score @s m.trig matches 4121 run function metiers:e/oublier_1
execute if score @s m.trig matches 4722 run function metiers:e/desactiver_2
execute if score @s m.trig matches 4422 run function metiers:e/activer_2
execute if score @s m.trig matches 4122 run function metiers:e/oublier_2
execute if score @s m.trig matches 4723 run function metiers:e/desactiver_3
execute if score @s m.trig matches 4423 run function metiers:e/activer_3
execute if score @s m.trig matches 4123 run function metiers:e/oublier_3
execute if score @s m.trig matches 4724 run function metiers:e/desactiver_4
execute if score @s m.trig matches 4424 run function metiers:e/activer_4
execute if score @s m.trig matches 4124 run function metiers:e/oublier_4
execute if score @s m.trig matches 4725 run function metiers:e/desactiver_5
execute if score @s m.trig matches 4425 run function metiers:e/activer_5
execute if score @s m.trig matches 4125 run function metiers:e/oublier_5
execute if score @s m.trig matches 4726 run function metiers:e/desactiver_6
execute if score @s m.trig matches 4426 run function metiers:e/activer_6
execute if score @s m.trig matches 4126 run function metiers:e/oublier_6
execute if score @s m.trig matches 4727 run function metiers:e/desactiver_7
execute if score @s m.trig matches 4427 run function metiers:e/activer_7
execute if score @s m.trig matches 4127 run function metiers:e/oublier_7
execute if score @s m.trig matches 4728 run function metiers:e/desactiver_8
execute if score @s m.trig matches 4428 run function metiers:e/activer_8
execute if score @s m.trig matches 4128 run function metiers:e/oublier_8
execute if score @s m.trig matches 4729 run function metiers:e/desactiver_9
execute if score @s m.trig matches 4429 run function metiers:e/activer_9
execute if score @s m.trig matches 4129 run function metiers:e/oublier_9
execute if score @s m.trig matches 4730 run function metiers:e/desactiver_10
execute if score @s m.trig matches 4430 run function metiers:e/activer_10
execute if score @s m.trig matches 4130 run function metiers:e/oublier_10
execute if score @s m.trig matches 4731 run function metiers:e/desactiver_11
execute if score @s m.trig matches 4431 run function metiers:e/activer_11
execute if score @s m.trig matches 4131 run function metiers:e/oublier_11
execute if score @s m.trig matches 4732 run function metiers:e/desactiver_12
execute if score @s m.trig matches 4432 run function metiers:e/activer_12
execute if score @s m.trig matches 4132 run function metiers:e/oublier_12
execute if score @s m.trig matches 4733 run function metiers:e/desactiver_13
execute if score @s m.trig matches 4433 run function metiers:e/activer_13
execute if score @s m.trig matches 4133 run function metiers:e/oublier_13
execute if score @s m.trig matches 4734 run function metiers:e/desactiver_14
execute if score @s m.trig matches 4434 run function metiers:e/activer_14
execute if score @s m.trig matches 4134 run function metiers:e/oublier_14
execute if score @s m.trig matches 4735 run function metiers:e/desactiver_15
execute if score @s m.trig matches 4435 run function metiers:e/activer_15
execute if score @s m.trig matches 4135 run function metiers:e/oublier_15
execute if score @s m.trig matches 4736 run function metiers:e/desactiver_16
execute if score @s m.trig matches 4436 run function metiers:e/activer_16
execute if score @s m.trig matches 4136 run function metiers:e/oublier_16
execute if score @s m.trig matches 4737 run function metiers:e/desactiver_17
execute if score @s m.trig matches 4437 run function metiers:e/activer_17
execute if score @s m.trig matches 4137 run function metiers:e/oublier_17
execute if score @s m.trig matches 4738 run function metiers:e/desactiver_18
execute if score @s m.trig matches 4438 run function metiers:e/activer_18
execute if score @s m.trig matches 4138 run function metiers:e/oublier_18
execute if score @s m.trig matches 4741 run function metiers:n/desactiver_1
execute if score @s m.trig matches 4441 run function metiers:n/activer_1
execute if score @s m.trig matches 4141 run function metiers:n/oublier_1
execute if score @s m.trig matches 4742 run function metiers:n/desactiver_2
execute if score @s m.trig matches 4442 run function metiers:n/activer_2
execute if score @s m.trig matches 4142 run function metiers:n/oublier_2
execute if score @s m.trig matches 4743 run function metiers:n/desactiver_3
execute if score @s m.trig matches 4443 run function metiers:n/activer_3
execute if score @s m.trig matches 4143 run function metiers:n/oublier_3
execute if score @s m.trig matches 4744 run function metiers:n/desactiver_4
execute if score @s m.trig matches 4444 run function metiers:n/activer_4
execute if score @s m.trig matches 4144 run function metiers:n/oublier_4
execute if score @s m.trig matches 4745 run function metiers:n/desactiver_5
execute if score @s m.trig matches 4445 run function metiers:n/activer_5
execute if score @s m.trig matches 4145 run function metiers:n/oublier_5
execute if score @s m.trig matches 4746 run function metiers:n/desactiver_6
execute if score @s m.trig matches 4446 run function metiers:n/activer_6
execute if score @s m.trig matches 4146 run function metiers:n/oublier_6
execute if score @s m.trig matches 4747 run function metiers:n/desactiver_7
execute if score @s m.trig matches 4447 run function metiers:n/activer_7
execute if score @s m.trig matches 4147 run function metiers:n/oublier_7
execute if score @s m.trig matches 4748 run function metiers:n/desactiver_8
execute if score @s m.trig matches 4448 run function metiers:n/activer_8
execute if score @s m.trig matches 4148 run function metiers:n/oublier_8
execute if score @s m.trig matches 4749 run function metiers:n/desactiver_9
execute if score @s m.trig matches 4449 run function metiers:n/activer_9
execute if score @s m.trig matches 4149 run function metiers:n/oublier_9
execute if score @s m.trig matches 4750 run function metiers:n/desactiver_10
execute if score @s m.trig matches 4450 run function metiers:n/activer_10
execute if score @s m.trig matches 4150 run function metiers:n/oublier_10
execute if score @s m.trig matches 4751 run function metiers:n/desactiver_11
execute if score @s m.trig matches 4451 run function metiers:n/activer_11
execute if score @s m.trig matches 4151 run function metiers:n/oublier_11
execute if score @s m.trig matches 4752 run function metiers:n/desactiver_12
execute if score @s m.trig matches 4452 run function metiers:n/activer_12
execute if score @s m.trig matches 4152 run function metiers:n/oublier_12
execute if score @s m.trig matches 4753 run function metiers:n/desactiver_13
execute if score @s m.trig matches 4453 run function metiers:n/activer_13
execute if score @s m.trig matches 4153 run function metiers:n/oublier_13
execute if score @s m.trig matches 4754 run function metiers:n/desactiver_14
execute if score @s m.trig matches 4454 run function metiers:n/activer_14
execute if score @s m.trig matches 4154 run function metiers:n/oublier_14
execute if score @s m.trig matches 4755 run function metiers:n/desactiver_15
execute if score @s m.trig matches 4455 run function metiers:n/activer_15
execute if score @s m.trig matches 4155 run function metiers:n/oublier_15
execute if score @s m.trig matches 4756 run function metiers:n/desactiver_16
execute if score @s m.trig matches 4456 run function metiers:n/activer_16
execute if score @s m.trig matches 4156 run function metiers:n/oublier_16
execute if score @s m.trig matches 4757 run function metiers:n/desactiver_17
execute if score @s m.trig matches 4457 run function metiers:n/activer_17
execute if score @s m.trig matches 4157 run function metiers:n/oublier_17
execute if score @s m.trig matches 4758 run function metiers:n/desactiver_18
execute if score @s m.trig matches 4458 run function metiers:n/activer_18
execute if score @s m.trig matches 4158 run function metiers:n/oublier_18
execute if score @s m.trig matches 4761 run function metiers:x/desactiver_1
execute if score @s m.trig matches 4461 run function metiers:x/activer_1
execute if score @s m.trig matches 4161 run function metiers:x/oublier_1
execute if score @s m.trig matches 4762 run function metiers:x/desactiver_2
execute if score @s m.trig matches 4462 run function metiers:x/activer_2
execute if score @s m.trig matches 4162 run function metiers:x/oublier_2
execute if score @s m.trig matches 4763 run function metiers:x/desactiver_3
execute if score @s m.trig matches 4463 run function metiers:x/activer_3
execute if score @s m.trig matches 4163 run function metiers:x/oublier_3
execute if score @s m.trig matches 4764 run function metiers:x/desactiver_4
execute if score @s m.trig matches 4464 run function metiers:x/activer_4
execute if score @s m.trig matches 4164 run function metiers:x/oublier_4
execute if score @s m.trig matches 4765 run function metiers:x/desactiver_5
execute if score @s m.trig matches 4465 run function metiers:x/activer_5
execute if score @s m.trig matches 4165 run function metiers:x/oublier_5
execute if score @s m.trig matches 4766 run function metiers:x/desactiver_6
execute if score @s m.trig matches 4466 run function metiers:x/activer_6
execute if score @s m.trig matches 4166 run function metiers:x/oublier_6
execute if score @s m.trig matches 4767 run function metiers:x/desactiver_7
execute if score @s m.trig matches 4467 run function metiers:x/activer_7
execute if score @s m.trig matches 4167 run function metiers:x/oublier_7
execute if score @s m.trig matches 4768 run function metiers:x/desactiver_8
execute if score @s m.trig matches 4468 run function metiers:x/activer_8
execute if score @s m.trig matches 4168 run function metiers:x/oublier_8
execute if score @s m.trig matches 4769 run function metiers:x/desactiver_9
execute if score @s m.trig matches 4469 run function metiers:x/activer_9
execute if score @s m.trig matches 4169 run function metiers:x/oublier_9
execute if score @s m.trig matches 4770 run function metiers:x/desactiver_10
execute if score @s m.trig matches 4470 run function metiers:x/activer_10
execute if score @s m.trig matches 4170 run function metiers:x/oublier_10
execute if score @s m.trig matches 4771 run function metiers:x/desactiver_11
execute if score @s m.trig matches 4471 run function metiers:x/activer_11
execute if score @s m.trig matches 4171 run function metiers:x/oublier_11
execute if score @s m.trig matches 4772 run function metiers:x/desactiver_12
execute if score @s m.trig matches 4472 run function metiers:x/activer_12
execute if score @s m.trig matches 4172 run function metiers:x/oublier_12
execute if score @s m.trig matches 4773 run function metiers:x/desactiver_13
execute if score @s m.trig matches 4473 run function metiers:x/activer_13
execute if score @s m.trig matches 4173 run function metiers:x/oublier_13
execute if score @s m.trig matches 4774 run function metiers:x/desactiver_14
execute if score @s m.trig matches 4474 run function metiers:x/activer_14
execute if score @s m.trig matches 4174 run function metiers:x/oublier_14
execute if score @s m.trig matches 4775 run function metiers:x/desactiver_15
execute if score @s m.trig matches 4475 run function metiers:x/activer_15
execute if score @s m.trig matches 4175 run function metiers:x/oublier_15
execute if score @s m.trig matches 4776 run function metiers:x/desactiver_16
execute if score @s m.trig matches 4476 run function metiers:x/activer_16
execute if score @s m.trig matches 4176 run function metiers:x/oublier_16
execute if score @s m.trig matches 4777 run function metiers:x/desactiver_17
execute if score @s m.trig matches 4477 run function metiers:x/activer_17
execute if score @s m.trig matches 4177 run function metiers:x/oublier_17
execute if score @s m.trig matches 4778 run function metiers:x/desactiver_18
execute if score @s m.trig matches 4478 run function metiers:x/activer_18
execute if score @s m.trig matches 4178 run function metiers:x/oublier_18
execute if score @s m.trig matches 4781 run function metiers:t/desactiver_1
execute if score @s m.trig matches 4481 run function metiers:t/activer_1
execute if score @s m.trig matches 4181 run function metiers:t/oublier_1
execute if score @s m.trig matches 4782 run function metiers:t/desactiver_2
execute if score @s m.trig matches 4482 run function metiers:t/activer_2
execute if score @s m.trig matches 4182 run function metiers:t/oublier_2
execute if score @s m.trig matches 4783 run function metiers:t/desactiver_3
execute if score @s m.trig matches 4483 run function metiers:t/activer_3
execute if score @s m.trig matches 4183 run function metiers:t/oublier_3
execute if score @s m.trig matches 4784 run function metiers:t/desactiver_4
execute if score @s m.trig matches 4484 run function metiers:t/activer_4
execute if score @s m.trig matches 4184 run function metiers:t/oublier_4
execute if score @s m.trig matches 4785 run function metiers:t/desactiver_5
execute if score @s m.trig matches 4485 run function metiers:t/activer_5
execute if score @s m.trig matches 4185 run function metiers:t/oublier_5
execute if score @s m.trig matches 4786 run function metiers:t/desactiver_6
execute if score @s m.trig matches 4486 run function metiers:t/activer_6
execute if score @s m.trig matches 4186 run function metiers:t/oublier_6
execute if score @s m.trig matches 4787 run function metiers:t/desactiver_7
execute if score @s m.trig matches 4487 run function metiers:t/activer_7
execute if score @s m.trig matches 4187 run function metiers:t/oublier_7
execute if score @s m.trig matches 4788 run function metiers:t/desactiver_8
execute if score @s m.trig matches 4488 run function metiers:t/activer_8
execute if score @s m.trig matches 4188 run function metiers:t/oublier_8
execute if score @s m.trig matches 4789 run function metiers:t/desactiver_9
execute if score @s m.trig matches 4489 run function metiers:t/activer_9
execute if score @s m.trig matches 4189 run function metiers:t/oublier_9
execute if score @s m.trig matches 4790 run function metiers:t/desactiver_10
execute if score @s m.trig matches 4490 run function metiers:t/activer_10
execute if score @s m.trig matches 4190 run function metiers:t/oublier_10
execute if score @s m.trig matches 4791 run function metiers:t/desactiver_11
execute if score @s m.trig matches 4491 run function metiers:t/activer_11
execute if score @s m.trig matches 4191 run function metiers:t/oublier_11
execute if score @s m.trig matches 4792 run function metiers:t/desactiver_12
execute if score @s m.trig matches 4492 run function metiers:t/activer_12
execute if score @s m.trig matches 4192 run function metiers:t/oublier_12
execute if score @s m.trig matches 4793 run function metiers:t/desactiver_13
execute if score @s m.trig matches 4493 run function metiers:t/activer_13
execute if score @s m.trig matches 4193 run function metiers:t/oublier_13
execute if score @s m.trig matches 4794 run function metiers:t/desactiver_14
execute if score @s m.trig matches 4494 run function metiers:t/activer_14
execute if score @s m.trig matches 4194 run function metiers:t/oublier_14
execute if score @s m.trig matches 4795 run function metiers:t/desactiver_15
execute if score @s m.trig matches 4495 run function metiers:t/activer_15
execute if score @s m.trig matches 4195 run function metiers:t/oublier_15
execute if score @s m.trig matches 4796 run function metiers:t/desactiver_16
execute if score @s m.trig matches 4496 run function metiers:t/activer_16
execute if score @s m.trig matches 4196 run function metiers:t/oublier_16
execute if score @s m.trig matches 4797 run function metiers:t/desactiver_17
execute if score @s m.trig matches 4497 run function metiers:t/activer_17
execute if score @s m.trig matches 4197 run function metiers:t/oublier_17
execute if score @s m.trig matches 4798 run function metiers:t/desactiver_18
execute if score @s m.trig matches 4498 run function metiers:t/activer_18
execute if score @s m.trig matches 4198 run function metiers:t/oublier_18
execute if score @s m.trig matches 4801 run function metiers:k/desactiver_1
execute if score @s m.trig matches 4501 run function metiers:k/activer_1
execute if score @s m.trig matches 4201 run function metiers:k/oublier_1
execute if score @s m.trig matches 4802 run function metiers:k/desactiver_2
execute if score @s m.trig matches 4502 run function metiers:k/activer_2
execute if score @s m.trig matches 4202 run function metiers:k/oublier_2
execute if score @s m.trig matches 4803 run function metiers:k/desactiver_3
execute if score @s m.trig matches 4503 run function metiers:k/activer_3
execute if score @s m.trig matches 4203 run function metiers:k/oublier_3
execute if score @s m.trig matches 4804 run function metiers:k/desactiver_4
execute if score @s m.trig matches 4504 run function metiers:k/activer_4
execute if score @s m.trig matches 4204 run function metiers:k/oublier_4
execute if score @s m.trig matches 4805 run function metiers:k/desactiver_5
execute if score @s m.trig matches 4505 run function metiers:k/activer_5
execute if score @s m.trig matches 4205 run function metiers:k/oublier_5
execute if score @s m.trig matches 4806 run function metiers:k/desactiver_6
execute if score @s m.trig matches 4506 run function metiers:k/activer_6
execute if score @s m.trig matches 4206 run function metiers:k/oublier_6
execute if score @s m.trig matches 400 run function metiers:appel {f:"forge/menu"}
execute if score @s m.trig matches 470 run function metiers:appel {f:"forge/outil"}
execute if score @s m.trig matches 471 run function metiers:appel {f:"forge/menu"}
execute if score @s m.trig matches 472 run function metiers:appel {f:"skins/cadres"}
execute if score @s m.trig matches 411 run function metiers:appel {f:"forge/sertir_sagesse"}
execute if score @s m.trig matches 412 run function metiers:appel {f:"forge/sertir_fortune"}
execute if score @s m.trig matches 413 run function metiers:appel {f:"forge/sertir_echo"}
execute if score @s m.trig matches 414 run function metiers:appel {f:"forge/eff"}
execute if score @s m.trig matches 415 run function metiers:appel {f:"forge/retirer"}
execute if score @s m.trig matches 420 run function metiers:appel {f:"skins/menu"}
execute if score @s m.trig matches 421 run function metiers:appel {f:"skins/cycle"}
execute if score @s m.trig matches 430 run function metiers:appel {f:"skins/choix_0"}
execute if score @s m.trig matches 431 run function metiers:appel {f:"skins/choix_1"}
execute if score @s m.trig matches 432 run function metiers:appel {f:"skins/choix_2"}
execute if score @s m.trig matches 433 run function metiers:appel {f:"skins/choix_3"}
execute if score @s m.trig matches 434 run function metiers:appel {f:"skins/choix_4"}
execute if score @s m.trig matches 435 run function metiers:appel {f:"skins/choix_5"}
execute if score @s m.trig matches 436 run function metiers:appel {f:"skins/choix_6"}
execute if score @s m.trig matches 440 run function metiers:appel {f:"skins/cadre_0"}
execute if score @s m.trig matches 441 run function metiers:appel {f:"skins/cadre_1"}
execute if score @s m.trig matches 442 run function metiers:appel {f:"skins/cadre_2"}
execute if score @s m.trig matches 443 run function metiers:appel {f:"skins/cadre_3"}
execute if score @s m.trig matches 444 run function metiers:appel {f:"skins/cadre_4"}
execute if score @s m.trig matches 445 run function metiers:appel {f:"skins/cadre_5"}
execute if score @s m.trig matches 446 run function metiers:appel {f:"skins/cadre_6"}
execute if score @s m.trig matches 601 run function metiers:appel {f:"b/titre"}
execute if score @s m.trig matches 602 run function metiers:appel {f:"f/titre"}
execute if score @s m.trig matches 603 run function metiers:appel {f:"m/titre"}
execute if score @s m.trig matches 604 run function metiers:appel {f:"c/titre"}
execute if score @s m.trig matches 605 run function metiers:appel {f:"p/titre"}
execute if score @s m.trig matches 606 run function metiers:appel {f:"e/titre"}
execute if score @s m.trig matches 607 run function metiers:appel {f:"n/titre"}
execute if score @s m.trig matches 608 run function metiers:appel {f:"x/titre"}
execute if score @s m.trig matches 609 run function metiers:appel {f:"t/titre"}
execute if score @s m.trig matches 620 run function metiers:appel {f:"k/titre"}
execute if score @s m.trig matches 497 run function metiers:appel {f:"activites"}
execute if score @s m.trig matches 614 run function metiers:appel {f:"k/kit"}
execute if score @s m.trig matches 610 run function metiers:appel {f:"f/saison"}
execute if score @s m.trig matches 611 run function metiers:appel {f:"n/surpuissance"}
execute if score @s m.trig matches 612 run function metiers:appel {f:"sac/donner"}
execute if score @s m.trig matches 613 run function metiers:appel {f:"c/arc_recup"}
execute if score @s m.trig matches 701 run function metiers:appel {f:"tp/enregistrer"}
execute if score @s m.trig matches 702 run function metiers:appel {f:"tp/effacer"}
execute if score @s m.trig matches 721..730 run function metiers:appel {f:"tp/aller"}
execute if score @s m.trig matches 741..750 run function metiers:appel {f:"tp/renommer"}
execute if score @s m.trig matches 460 run function metiers:appel {f:"aide"}
execute if score @s m.trig matches 761 run function metiers:appel {f:"m/soie"}
execute if score @s m.trig matches 551 run function metiers:appel {f:"b/onglet_outil"}
execute if score @s m.trig matches 552 run function metiers:appel {f:"f/onglet_outil"}
execute if score @s m.trig matches 553 run function metiers:appel {f:"m/onglet_outil"}
execute if score @s m.trig matches 554 run function metiers:appel {f:"c/onglet_outil"}
execute if score @s m.trig matches 555 run function metiers:appel {f:"p/onglet_outil"}
execute if score @s m.trig matches 556 run function metiers:appel {f:"e/onglet_outil"}
execute if score @s m.trig matches 557 run function metiers:appel {f:"n/onglet_outil"}
execute if score @s m.trig matches 558 run function metiers:appel {f:"x/onglet_outil"}
execute if score @s m.trig matches 559 run function metiers:appel {f:"t/onglet_outil"}
execute if score @s m.trig matches 560 run function metiers:appel {f:"k/onglet_outil"}
execute if score @s m.trig matches 561 run function metiers:appel {f:"b/onglet_prog"}
execute if score @s m.trig matches 562 run function metiers:appel {f:"f/onglet_prog"}
execute if score @s m.trig matches 563 run function metiers:appel {f:"m/onglet_prog"}
execute if score @s m.trig matches 564 run function metiers:appel {f:"c/onglet_prog"}
execute if score @s m.trig matches 565 run function metiers:appel {f:"p/onglet_prog"}
execute if score @s m.trig matches 566 run function metiers:appel {f:"e/onglet_prog"}
execute if score @s m.trig matches 567 run function metiers:appel {f:"n/onglet_prog"}
execute if score @s m.trig matches 568 run function metiers:appel {f:"x/onglet_prog"}
execute if score @s m.trig matches 569 run function metiers:appel {f:"t/onglet_prog"}
execute if score @s m.trig matches 570 run function metiers:appel {f:"k/onglet_prog"}
execute if score @s m.trig matches 4300 run function metiers:appel {f:"skins/fiche_0"}
execute if score @s m.trig matches 4301 run function metiers:appel {f:"skins/fiche_1"}
execute if score @s m.trig matches 4302 run function metiers:appel {f:"skins/fiche_2"}
execute if score @s m.trig matches 4303 run function metiers:appel {f:"skins/fiche_3"}
execute if score @s m.trig matches 4304 run function metiers:appel {f:"skins/fiche_4"}
execute if score @s m.trig matches 4305 run function metiers:appel {f:"skins/fiche_5"}
execute if score @s m.trig matches 4306 run function metiers:appel {f:"skins/fiche_6"}
execute if score @s m.trig matches 4307 run function metiers:appel {f:"skins/fiche_7"}
execute if score @s m.trig matches 4308 run function metiers:appel {f:"skins/fiche_8"}
execute if score @s m.trig matches 4309 run function metiers:appel {f:"skins/fiche_9"}
execute if score @s m.trig matches 4310 run function metiers:appel {f:"skins/fiche_10"}
execute if score @s m.trig matches 4311 run function metiers:appel {f:"skins/fiche_11"}
execute if score @s m.trig matches 4312 run function metiers:appel {f:"skins/fiche_12"}
execute if score @s m.trig matches 4320 run function metiers:appel {f:"skins/choix_0"}
execute if score @s m.trig matches 4321 run function metiers:appel {f:"skins/choix_1"}
execute if score @s m.trig matches 4322 run function metiers:appel {f:"skins/choix_2"}
execute if score @s m.trig matches 4323 run function metiers:appel {f:"skins/choix_3"}
execute if score @s m.trig matches 4324 run function metiers:appel {f:"skins/choix_4"}
execute if score @s m.trig matches 4325 run function metiers:appel {f:"skins/choix_5"}
execute if score @s m.trig matches 4326 run function metiers:appel {f:"skins/choix_6"}
execute if score @s m.trig matches 4327 run function metiers:appel {f:"skins/choix_7"}
execute if score @s m.trig matches 4328 run function metiers:appel {f:"skins/choix_8"}
execute if score @s m.trig matches 4329 run function metiers:appel {f:"skins/choix_9"}
execute if score @s m.trig matches 4330 run function metiers:appel {f:"skins/choix_10"}
execute if score @s m.trig matches 4331 run function metiers:appel {f:"skins/choix_11"}
execute if score @s m.trig matches 4332 run function metiers:appel {f:"skins/choix_12"}
execute if score @s m.trig matches 491 run function metiers:appel {f:"bareme/c2"}
execute if score @s m.trig matches 492 run function metiers:appel {f:"bareme/m2"}
execute if score @s m.trig matches 480 run function metiers:appel {f:"bareme/menu"}
execute if score @s m.trig matches 481 run function metiers:appel {f:"bareme/b"}
execute if score @s m.trig matches 482 run function metiers:appel {f:"bareme/f"}
execute if score @s m.trig matches 483 run function metiers:appel {f:"bareme/m"}
execute if score @s m.trig matches 484 run function metiers:appel {f:"bareme/c"}
execute if score @s m.trig matches 485 run function metiers:appel {f:"bareme/p"}
execute if score @s m.trig matches 486 run function metiers:appel {f:"bareme/e"}
execute if score @s m.trig matches 487 run function metiers:appel {f:"bareme/n"}
execute if score @s m.trig matches 488 run function metiers:appel {f:"bareme/x"}
execute if score @s m.trig matches 489 run function metiers:appel {f:"bareme/t"}
execute if score @s m.trig matches 490 run function metiers:appel {f:"bareme/k"}
execute if score @s m.trig matches 447 run function metiers:appel {f:"skins/cadre_7"}
execute if score @s m.trig matches 499 run function metiers:appel {f:"prestige/aura_basculer"}
execute if score @s m.trig matches 495 run function metiers:appel {f:"quete/page"}
execute if score @s m.trig matches 496 run function metiers:appel {f:"synergie/page"}
execute if score @s m.trig matches 770 run function metiers:appel {f:"guilde/page"}
execute if score @s m.trig matches 771 run function metiers:appel {f:"guilde/creer"}
execute if score @s m.trig matches 772 run function metiers:appel {f:"guilde/quitter"}
execute if score @s m.trig matches 773 run function metiers:appel {f:"guilde/inviter_liste"}
execute if score @s m.trig matches 775 run function metiers:appel {f:"guilde/accepter"}
execute if score @s m.trig matches 7100000..7199999 run function metiers:appel {f:"guilde/inviter"}
execute if score @s m.trig matches 7200000..7299999 run function metiers:appel {f:"guilde/exclure"}
execute if score @s m.trig matches 521 run function metiers:appel {f:"classement/metier_b"}
execute if score @s m.trig matches 522 run function metiers:appel {f:"classement/metier_f"}
execute if score @s m.trig matches 523 run function metiers:appel {f:"classement/metier_m"}
execute if score @s m.trig matches 524 run function metiers:appel {f:"classement/metier_c"}
execute if score @s m.trig matches 525 run function metiers:appel {f:"classement/metier_p"}
execute if score @s m.trig matches 526 run function metiers:appel {f:"classement/metier_e"}
execute if score @s m.trig matches 527 run function metiers:appel {f:"classement/metier_n"}
execute if score @s m.trig matches 528 run function metiers:appel {f:"classement/metier_x"}
execute if score @s m.trig matches 529 run function metiers:appel {f:"classement/metier_t"}
execute if score @s m.trig matches 530 run function metiers:appel {f:"classement/metier_k"}
execute if score @s m.trig matches 540 run function metiers:sommaire
