scoreboard players operation @s m.trig = @s metiers
scoreboard players set @s metiers 0
scoreboard players enable @s metiers
execute if score @s m.trig matches 1 run function metiers:menu
execute if score @s m.trig matches 2 run function metiers:prefixe/menu
execute if score @s m.trig matches 3 unless function metiers:recompenses run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aucune récompense en attente.","color":"gray"}]
execute if score @s m.trig matches 10..20 run function metiers:prefixe/choisir
execute if score @s m.trig matches 4 run function metiers:appel {f:"defis/menu"}
execute if score @s m.trig matches 5 run function metiers:appel {f:"classement/menu"}
execute if score @s m.trig matches 7 run function metiers:appel {f:"defis/basculer"}
execute if score @s m.trig matches 6 run function metiers:appel {f:"armure/menu"}
execute if score @s m.trig matches 8 run function metiers:appel {f:"armure/recup"}
execute if score @s m.trig matches 70 run function metiers:appel {f:"p/carnet"}
execute if score @s m.trig matches 301 run function metiers:appel {f:"b/outil_recup"}
execute if score @s m.trig matches 311 run function metiers:appel {f:"b/prestige_confirmer"}
execute if score @s m.trig matches 321 run function metiers:appel {f:"b/prestige"}
execute if score @s m.trig matches 331 run function metiers:appel {f:"b/outil_reparer"}
execute if score @s m.trig matches 341 run function metiers:appel {f:"b/recompenses_menu"}
execute if score @s m.trig matches 302 run function metiers:appel {f:"f/outil_recup"}
execute if score @s m.trig matches 312 run function metiers:appel {f:"f/prestige_confirmer"}
execute if score @s m.trig matches 322 run function metiers:appel {f:"f/prestige"}
execute if score @s m.trig matches 332 run function metiers:appel {f:"f/outil_reparer"}
execute if score @s m.trig matches 342 run function metiers:appel {f:"f/recompenses_menu"}
execute if score @s m.trig matches 303 run function metiers:appel {f:"m/outil_recup"}
execute if score @s m.trig matches 313 run function metiers:appel {f:"m/prestige_confirmer"}
execute if score @s m.trig matches 323 run function metiers:appel {f:"m/prestige"}
execute if score @s m.trig matches 333 run function metiers:appel {f:"m/outil_reparer"}
execute if score @s m.trig matches 343 run function metiers:appel {f:"m/recompenses_menu"}
execute if score @s m.trig matches 304 run function metiers:appel {f:"c/outil_recup"}
execute if score @s m.trig matches 314 run function metiers:appel {f:"c/prestige_confirmer"}
execute if score @s m.trig matches 324 run function metiers:appel {f:"c/prestige"}
execute if score @s m.trig matches 334 run function metiers:appel {f:"c/outil_reparer"}
execute if score @s m.trig matches 344 run function metiers:appel {f:"c/recompenses_menu"}
execute if score @s m.trig matches 305 run function metiers:appel {f:"p/outil_recup"}
execute if score @s m.trig matches 315 run function metiers:appel {f:"p/prestige_confirmer"}
execute if score @s m.trig matches 325 run function metiers:appel {f:"p/prestige"}
execute if score @s m.trig matches 335 run function metiers:appel {f:"p/outil_reparer"}
execute if score @s m.trig matches 345 run function metiers:appel {f:"p/recompenses_menu"}
execute if score @s m.trig matches 306 run function metiers:appel {f:"e/outil_recup"}
execute if score @s m.trig matches 316 run function metiers:appel {f:"e/prestige_confirmer"}
execute if score @s m.trig matches 326 run function metiers:appel {f:"e/prestige"}
execute if score @s m.trig matches 336 run function metiers:appel {f:"e/outil_reparer"}
execute if score @s m.trig matches 346 run function metiers:appel {f:"e/recompenses_menu"}
execute if score @s m.trig matches 307 run function metiers:appel {f:"n/outil_recup"}
execute if score @s m.trig matches 317 run function metiers:appel {f:"n/prestige_confirmer"}
execute if score @s m.trig matches 327 run function metiers:appel {f:"n/prestige"}
execute if score @s m.trig matches 337 run function metiers:appel {f:"n/outil_reparer"}
execute if score @s m.trig matches 347 run function metiers:appel {f:"n/recompenses_menu"}
execute if score @s m.trig matches 308 run function metiers:appel {f:"x/outil_recup"}
execute if score @s m.trig matches 318 run function metiers:appel {f:"x/prestige_confirmer"}
execute if score @s m.trig matches 328 run function metiers:appel {f:"x/prestige"}
execute if score @s m.trig matches 338 run function metiers:appel {f:"x/outil_reparer"}
execute if score @s m.trig matches 348 run function metiers:appel {f:"x/recompenses_menu"}
execute if score @s m.trig matches 309 run function metiers:appel {f:"t/outil_recup"}
execute if score @s m.trig matches 319 run function metiers:appel {f:"t/prestige_confirmer"}
execute if score @s m.trig matches 329 run function metiers:appel {f:"t/prestige"}
execute if score @s m.trig matches 339 run function metiers:appel {f:"t/outil_reparer"}
execute if score @s m.trig matches 349 run function metiers:appel {f:"t/recompenses_menu"}
execute if score @s m.trig matches 310 run function metiers:appel {f:"k/outil_recup"}
execute if score @s m.trig matches 320 run function metiers:appel {f:"k/prestige_confirmer"}
execute if score @s m.trig matches 330 run function metiers:appel {f:"k/prestige"}
execute if score @s m.trig matches 340 run function metiers:appel {f:"k/outil_reparer"}
execute if score @s m.trig matches 350 run function metiers:appel {f:"k/recompenses_menu"}
execute if score @s m.trig matches 21 run function metiers:b/arbre
execute if score @s m.trig matches 201 run function metiers:b/reclamer
execute if score @s m.trig matches 111 run function metiers:b/acheter_1
execute if score @s m.trig matches 112 run function metiers:b/acheter_2
execute if score @s m.trig matches 113 run function metiers:b/acheter_3
execute if score @s m.trig matches 114 run function metiers:b/acheter_4
execute if score @s m.trig matches 115 run function metiers:b/acheter_5
execute if score @s m.trig matches 116 run function metiers:b/acheter_6
execute if score @s m.trig matches 3027 run function metiers:b/acheter_7
execute if score @s m.trig matches 3028 run function metiers:b/acheter_8
execute if score @s m.trig matches 3029 run function metiers:b/acheter_9
execute if score @s m.trig matches 3030 run function metiers:b/acheter_10
execute if score @s m.trig matches 3031 run function metiers:b/acheter_11
execute if score @s m.trig matches 3032 run function metiers:b/acheter_12
execute if score @s m.trig matches 3033 run function metiers:b/acheter_13
execute if score @s m.trig matches 3034 run function metiers:b/acheter_14
execute if score @s m.trig matches 3035 run function metiers:b/acheter_15
execute if score @s m.trig matches 3036 run function metiers:b/acheter_16
execute if score @s m.trig matches 3037 run function metiers:b/acheter_17
execute if score @s m.trig matches 3038 run function metiers:b/acheter_18
execute if score @s m.trig matches 22 run function metiers:f/arbre
execute if score @s m.trig matches 202 run function metiers:f/reclamer
execute if score @s m.trig matches 121 run function metiers:f/acheter_1
execute if score @s m.trig matches 122 run function metiers:f/acheter_2
execute if score @s m.trig matches 123 run function metiers:f/acheter_3
execute if score @s m.trig matches 124 run function metiers:f/acheter_4
execute if score @s m.trig matches 125 run function metiers:f/acheter_5
execute if score @s m.trig matches 126 run function metiers:f/acheter_6
execute if score @s m.trig matches 3047 run function metiers:f/acheter_7
execute if score @s m.trig matches 3048 run function metiers:f/acheter_8
execute if score @s m.trig matches 3049 run function metiers:f/acheter_9
execute if score @s m.trig matches 3050 run function metiers:f/acheter_10
execute if score @s m.trig matches 3051 run function metiers:f/acheter_11
execute if score @s m.trig matches 3052 run function metiers:f/acheter_12
execute if score @s m.trig matches 3053 run function metiers:f/acheter_13
execute if score @s m.trig matches 3054 run function metiers:f/acheter_14
execute if score @s m.trig matches 3055 run function metiers:f/acheter_15
execute if score @s m.trig matches 3056 run function metiers:f/acheter_16
execute if score @s m.trig matches 3057 run function metiers:f/acheter_17
execute if score @s m.trig matches 3058 run function metiers:f/acheter_18
execute if score @s m.trig matches 23 run function metiers:m/arbre
execute if score @s m.trig matches 203 run function metiers:m/reclamer
execute if score @s m.trig matches 131 run function metiers:m/acheter_1
execute if score @s m.trig matches 132 run function metiers:m/acheter_2
execute if score @s m.trig matches 133 run function metiers:m/acheter_3
execute if score @s m.trig matches 134 run function metiers:m/acheter_4
execute if score @s m.trig matches 135 run function metiers:m/acheter_5
execute if score @s m.trig matches 136 run function metiers:m/acheter_6
execute if score @s m.trig matches 3067 run function metiers:m/acheter_7
execute if score @s m.trig matches 3068 run function metiers:m/acheter_8
execute if score @s m.trig matches 3069 run function metiers:m/acheter_9
execute if score @s m.trig matches 3070 run function metiers:m/acheter_10
execute if score @s m.trig matches 3071 run function metiers:m/acheter_11
execute if score @s m.trig matches 3072 run function metiers:m/acheter_12
execute if score @s m.trig matches 3073 run function metiers:m/acheter_13
execute if score @s m.trig matches 3074 run function metiers:m/acheter_14
execute if score @s m.trig matches 3075 run function metiers:m/acheter_15
execute if score @s m.trig matches 3076 run function metiers:m/acheter_16
execute if score @s m.trig matches 3077 run function metiers:m/acheter_17
execute if score @s m.trig matches 3078 run function metiers:m/acheter_18
execute if score @s m.trig matches 24 run function metiers:c/arbre
execute if score @s m.trig matches 204 run function metiers:c/reclamer
execute if score @s m.trig matches 141 run function metiers:c/acheter_1
execute if score @s m.trig matches 142 run function metiers:c/acheter_2
execute if score @s m.trig matches 143 run function metiers:c/acheter_3
execute if score @s m.trig matches 144 run function metiers:c/acheter_4
execute if score @s m.trig matches 145 run function metiers:c/acheter_5
execute if score @s m.trig matches 146 run function metiers:c/acheter_6
execute if score @s m.trig matches 3087 run function metiers:c/acheter_7
execute if score @s m.trig matches 3088 run function metiers:c/acheter_8
execute if score @s m.trig matches 3089 run function metiers:c/acheter_9
execute if score @s m.trig matches 3090 run function metiers:c/acheter_10
execute if score @s m.trig matches 3091 run function metiers:c/acheter_11
execute if score @s m.trig matches 3092 run function metiers:c/acheter_12
execute if score @s m.trig matches 3093 run function metiers:c/acheter_13
execute if score @s m.trig matches 3094 run function metiers:c/acheter_14
execute if score @s m.trig matches 3095 run function metiers:c/acheter_15
execute if score @s m.trig matches 3096 run function metiers:c/acheter_16
execute if score @s m.trig matches 3097 run function metiers:c/acheter_17
execute if score @s m.trig matches 3098 run function metiers:c/acheter_18
execute if score @s m.trig matches 25 run function metiers:p/arbre
execute if score @s m.trig matches 205 run function metiers:p/reclamer
execute if score @s m.trig matches 151 run function metiers:p/acheter_1
execute if score @s m.trig matches 152 run function metiers:p/acheter_2
execute if score @s m.trig matches 153 run function metiers:p/acheter_3
execute if score @s m.trig matches 154 run function metiers:p/acheter_4
execute if score @s m.trig matches 155 run function metiers:p/acheter_5
execute if score @s m.trig matches 156 run function metiers:p/acheter_6
execute if score @s m.trig matches 3107 run function metiers:p/acheter_7
execute if score @s m.trig matches 3108 run function metiers:p/acheter_8
execute if score @s m.trig matches 3109 run function metiers:p/acheter_9
execute if score @s m.trig matches 3110 run function metiers:p/acheter_10
execute if score @s m.trig matches 3111 run function metiers:p/acheter_11
execute if score @s m.trig matches 3112 run function metiers:p/acheter_12
execute if score @s m.trig matches 3113 run function metiers:p/acheter_13
execute if score @s m.trig matches 3114 run function metiers:p/acheter_14
execute if score @s m.trig matches 3115 run function metiers:p/acheter_15
execute if score @s m.trig matches 3116 run function metiers:p/acheter_16
execute if score @s m.trig matches 3117 run function metiers:p/acheter_17
execute if score @s m.trig matches 3118 run function metiers:p/acheter_18
execute if score @s m.trig matches 26 run function metiers:e/arbre
execute if score @s m.trig matches 206 run function metiers:e/reclamer
execute if score @s m.trig matches 161 run function metiers:e/acheter_1
execute if score @s m.trig matches 162 run function metiers:e/acheter_2
execute if score @s m.trig matches 163 run function metiers:e/acheter_3
execute if score @s m.trig matches 164 run function metiers:e/acheter_4
execute if score @s m.trig matches 165 run function metiers:e/acheter_5
execute if score @s m.trig matches 166 run function metiers:e/acheter_6
execute if score @s m.trig matches 3127 run function metiers:e/acheter_7
execute if score @s m.trig matches 3128 run function metiers:e/acheter_8
execute if score @s m.trig matches 3129 run function metiers:e/acheter_9
execute if score @s m.trig matches 3130 run function metiers:e/acheter_10
execute if score @s m.trig matches 3131 run function metiers:e/acheter_11
execute if score @s m.trig matches 3132 run function metiers:e/acheter_12
execute if score @s m.trig matches 3133 run function metiers:e/acheter_13
execute if score @s m.trig matches 3134 run function metiers:e/acheter_14
execute if score @s m.trig matches 3135 run function metiers:e/acheter_15
execute if score @s m.trig matches 3136 run function metiers:e/acheter_16
execute if score @s m.trig matches 3137 run function metiers:e/acheter_17
execute if score @s m.trig matches 3138 run function metiers:e/acheter_18
execute if score @s m.trig matches 27 run function metiers:n/arbre
execute if score @s m.trig matches 207 run function metiers:n/reclamer
execute if score @s m.trig matches 171 run function metiers:n/acheter_1
execute if score @s m.trig matches 172 run function metiers:n/acheter_2
execute if score @s m.trig matches 173 run function metiers:n/acheter_3
execute if score @s m.trig matches 174 run function metiers:n/acheter_4
execute if score @s m.trig matches 175 run function metiers:n/acheter_5
execute if score @s m.trig matches 176 run function metiers:n/acheter_6
execute if score @s m.trig matches 3147 run function metiers:n/acheter_7
execute if score @s m.trig matches 3148 run function metiers:n/acheter_8
execute if score @s m.trig matches 3149 run function metiers:n/acheter_9
execute if score @s m.trig matches 3150 run function metiers:n/acheter_10
execute if score @s m.trig matches 3151 run function metiers:n/acheter_11
execute if score @s m.trig matches 3152 run function metiers:n/acheter_12
execute if score @s m.trig matches 3153 run function metiers:n/acheter_13
execute if score @s m.trig matches 3154 run function metiers:n/acheter_14
execute if score @s m.trig matches 3155 run function metiers:n/acheter_15
execute if score @s m.trig matches 3156 run function metiers:n/acheter_16
execute if score @s m.trig matches 3157 run function metiers:n/acheter_17
execute if score @s m.trig matches 3158 run function metiers:n/acheter_18
execute if score @s m.trig matches 28 run function metiers:x/arbre
execute if score @s m.trig matches 208 run function metiers:x/reclamer
execute if score @s m.trig matches 181 run function metiers:x/acheter_1
execute if score @s m.trig matches 182 run function metiers:x/acheter_2
execute if score @s m.trig matches 183 run function metiers:x/acheter_3
execute if score @s m.trig matches 184 run function metiers:x/acheter_4
execute if score @s m.trig matches 185 run function metiers:x/acheter_5
execute if score @s m.trig matches 186 run function metiers:x/acheter_6
execute if score @s m.trig matches 3167 run function metiers:x/acheter_7
execute if score @s m.trig matches 3168 run function metiers:x/acheter_8
execute if score @s m.trig matches 3169 run function metiers:x/acheter_9
execute if score @s m.trig matches 3170 run function metiers:x/acheter_10
execute if score @s m.trig matches 3171 run function metiers:x/acheter_11
execute if score @s m.trig matches 3172 run function metiers:x/acheter_12
execute if score @s m.trig matches 3173 run function metiers:x/acheter_13
execute if score @s m.trig matches 3174 run function metiers:x/acheter_14
execute if score @s m.trig matches 3175 run function metiers:x/acheter_15
execute if score @s m.trig matches 3176 run function metiers:x/acheter_16
execute if score @s m.trig matches 3177 run function metiers:x/acheter_17
execute if score @s m.trig matches 3178 run function metiers:x/acheter_18
execute if score @s m.trig matches 29 run function metiers:t/arbre
execute if score @s m.trig matches 209 run function metiers:t/reclamer
execute if score @s m.trig matches 191 run function metiers:t/acheter_1
execute if score @s m.trig matches 192 run function metiers:t/acheter_2
execute if score @s m.trig matches 193 run function metiers:t/acheter_3
execute if score @s m.trig matches 194 run function metiers:t/acheter_4
execute if score @s m.trig matches 195 run function metiers:t/acheter_5
execute if score @s m.trig matches 196 run function metiers:t/acheter_6
execute if score @s m.trig matches 3187 run function metiers:t/acheter_7
execute if score @s m.trig matches 3188 run function metiers:t/acheter_8
execute if score @s m.trig matches 3189 run function metiers:t/acheter_9
execute if score @s m.trig matches 3190 run function metiers:t/acheter_10
execute if score @s m.trig matches 3191 run function metiers:t/acheter_11
execute if score @s m.trig matches 3192 run function metiers:t/acheter_12
execute if score @s m.trig matches 3193 run function metiers:t/acheter_13
execute if score @s m.trig matches 3194 run function metiers:t/acheter_14
execute if score @s m.trig matches 3195 run function metiers:t/acheter_15
execute if score @s m.trig matches 3196 run function metiers:t/acheter_16
execute if score @s m.trig matches 3197 run function metiers:t/acheter_17
execute if score @s m.trig matches 3198 run function metiers:t/acheter_18
execute if score @s m.trig matches 30 run function metiers:k/arbre
execute if score @s m.trig matches 210 run function metiers:k/reclamer
execute if score @s m.trig matches 1001 run function metiers:k/acheter_1
execute if score @s m.trig matches 1002 run function metiers:k/acheter_2
execute if score @s m.trig matches 1003 run function metiers:k/acheter_3
execute if score @s m.trig matches 1004 run function metiers:k/acheter_4
execute if score @s m.trig matches 1005 run function metiers:k/acheter_5
execute if score @s m.trig matches 1006 run function metiers:k/acheter_6
execute if score @s m.trig matches 3500 run function metiers:appel {f:"objets/acheter_graine"}
execute if score @s m.trig matches 3481 run function metiers:appel {f:"objets/boutique_b"}
execute if score @s m.trig matches 3501 run function metiers:appel {f:"objets/acheter_bombe"}
execute if score @s m.trig matches 3502 run function metiers:appel {f:"objets/acheter_arrosoir"}
execute if score @s m.trig matches 3503 run function metiers:appel {f:"objets/acheter_epouvantail"}
execute if score @s m.trig matches 3482 run function metiers:appel {f:"objets/boutique_f"}
execute if score @s m.trig matches 3504 run function metiers:appel {f:"objets/acheter_dynamite"}
execute if score @s m.trig matches 3505 run function metiers:appel {f:"objets/acheter_lanterne"}
execute if score @s m.trig matches 3483 run function metiers:appel {f:"objets/boutique_m"}
execute if score @s m.trig matches 3506 run function metiers:appel {f:"objets/acheter_piege"}
execute if score @s m.trig matches 3484 run function metiers:appel {f:"objets/boutique_c"}
execute if score @s m.trig matches 3507 run function metiers:appel {f:"objets/acheter_filet"}
execute if score @s m.trig matches 3485 run function metiers:appel {f:"objets/boutique_p"}
execute if score @s m.trig matches 3508 run function metiers:appel {f:"objets/acheter_sifflet"}
execute if score @s m.trig matches 3509 run function metiers:appel {f:"objets/acheter_mangeoire"}
execute if score @s m.trig matches 3486 run function metiers:appel {f:"objets/boutique_e"}
execute if score @s m.trig matches 3510 run function metiers:appel {f:"objets/acheter_tente"}
execute if score @s m.trig matches 3488 run function metiers:appel {f:"objets/boutique_x"}
execute if score @s m.trig matches 3490 run function metiers:appel {f:"comp/n_forge"}
execute if score @s m.trig matches 3492 run function metiers:appel {f:"objets/recup_elytres"}
execute if score @s m.trig matches 400 run function metiers:appel {f:"forge/menu"}
execute if score @s m.trig matches 470 run function metiers:appel {f:"forge/outil"}
execute if score @s m.trig matches 471 run function metiers:appel {f:"forge/menu"}
execute if score @s m.trig matches 472 run function metiers:appel {f:"skins/cadres"}
execute if score @s m.trig matches 411 run function metiers:appel {f:"forge/sertir_sagesse"}
execute if score @s m.trig matches 412 run function metiers:appel {f:"forge/sertir_fortune"}
execute if score @s m.trig matches 413 run function metiers:appel {f:"forge/sertir_echo"}
execute if score @s m.trig matches 414 run function metiers:appel {f:"forge/eff"}
execute if score @s m.trig matches 415 run function metiers:appel {f:"forge/retirer"}
execute if score @s m.trig matches 420 run function metiers:appel {f:"skins/menu"}
execute if score @s m.trig matches 421 run function metiers:appel {f:"skins/cycle"}
execute if score @s m.trig matches 430 run function metiers:appel {f:"skins/choix_0"}
execute if score @s m.trig matches 431 run function metiers:appel {f:"skins/choix_1"}
execute if score @s m.trig matches 432 run function metiers:appel {f:"skins/choix_2"}
execute if score @s m.trig matches 433 run function metiers:appel {f:"skins/choix_3"}
execute if score @s m.trig matches 434 run function metiers:appel {f:"skins/choix_4"}
execute if score @s m.trig matches 435 run function metiers:appel {f:"skins/choix_5"}
execute if score @s m.trig matches 436 run function metiers:appel {f:"skins/choix_6"}
execute if score @s m.trig matches 440 run function metiers:appel {f:"skins/cadre_0"}
execute if score @s m.trig matches 441 run function metiers:appel {f:"skins/cadre_1"}
execute if score @s m.trig matches 442 run function metiers:appel {f:"skins/cadre_2"}
execute if score @s m.trig matches 443 run function metiers:appel {f:"skins/cadre_3"}
execute if score @s m.trig matches 444 run function metiers:appel {f:"skins/cadre_4"}
execute if score @s m.trig matches 445 run function metiers:appel {f:"skins/cadre_5"}
execute if score @s m.trig matches 446 run function metiers:appel {f:"skins/cadre_6"}
execute if score @s m.trig matches 601 run function metiers:appel {f:"b/titre"}
execute if score @s m.trig matches 602 run function metiers:appel {f:"f/titre"}
execute if score @s m.trig matches 603 run function metiers:appel {f:"m/titre"}
execute if score @s m.trig matches 604 run function metiers:appel {f:"c/titre"}
execute if score @s m.trig matches 605 run function metiers:appel {f:"p/titre"}
execute if score @s m.trig matches 606 run function metiers:appel {f:"e/titre"}
execute if score @s m.trig matches 607 run function metiers:appel {f:"n/titre"}
execute if score @s m.trig matches 608 run function metiers:appel {f:"x/titre"}
execute if score @s m.trig matches 609 run function metiers:appel {f:"t/titre"}
execute if score @s m.trig matches 620 run function metiers:appel {f:"k/titre"}
execute if score @s m.trig matches 497 run function metiers:appel {f:"activites"}
execute if score @s m.trig matches 614 run function metiers:appel {f:"k/kit"}
execute if score @s m.trig matches 610 run function metiers:appel {f:"f/saison"}
execute if score @s m.trig matches 611 run function metiers:appel {f:"n/surpuissance"}
execute if score @s m.trig matches 612 run function metiers:appel {f:"sac/donner"}
execute if score @s m.trig matches 613 run function metiers:appel {f:"c/arc_recup"}
execute if score @s m.trig matches 701 run function metiers:appel {f:"tp/enregistrer"}
execute if score @s m.trig matches 702 run function metiers:appel {f:"tp/effacer"}
execute if score @s m.trig matches 721..730 run function metiers:appel {f:"tp/aller"}
execute if score @s m.trig matches 741..750 run function metiers:appel {f:"tp/renommer"}
execute if score @s m.trig matches 460 run function metiers:appel {f:"aide"}
execute if score @s m.trig matches 761 run function metiers:appel {f:"m/soie"}
execute if score @s m.trig matches 551 run function metiers:appel {f:"b/onglet_outil"}
execute if score @s m.trig matches 552 run function metiers:appel {f:"f/onglet_outil"}
execute if score @s m.trig matches 553 run function metiers:appel {f:"m/onglet_outil"}
execute if score @s m.trig matches 554 run function metiers:appel {f:"c/onglet_outil"}
execute if score @s m.trig matches 555 run function metiers:appel {f:"p/onglet_outil"}
execute if score @s m.trig matches 556 run function metiers:appel {f:"e/onglet_outil"}
execute if score @s m.trig matches 557 run function metiers:appel {f:"n/onglet_outil"}
execute if score @s m.trig matches 558 run function metiers:appel {f:"x/onglet_outil"}
execute if score @s m.trig matches 559 run function metiers:appel {f:"t/onglet_outil"}
execute if score @s m.trig matches 560 run function metiers:appel {f:"k/onglet_outil"}
execute if score @s m.trig matches 561 run function metiers:appel {f:"b/onglet_prog"}
execute if score @s m.trig matches 562 run function metiers:appel {f:"f/onglet_prog"}
execute if score @s m.trig matches 563 run function metiers:appel {f:"m/onglet_prog"}
execute if score @s m.trig matches 564 run function metiers:appel {f:"c/onglet_prog"}
execute if score @s m.trig matches 565 run function metiers:appel {f:"p/onglet_prog"}
execute if score @s m.trig matches 566 run function metiers:appel {f:"e/onglet_prog"}
execute if score @s m.trig matches 567 run function metiers:appel {f:"n/onglet_prog"}
execute if score @s m.trig matches 568 run function metiers:appel {f:"x/onglet_prog"}
execute if score @s m.trig matches 569 run function metiers:appel {f:"t/onglet_prog"}
execute if score @s m.trig matches 570 run function metiers:appel {f:"k/onglet_prog"}
execute if score @s m.trig matches 491 run function metiers:appel {f:"bareme/c2"}
execute if score @s m.trig matches 492 run function metiers:appel {f:"bareme/m2"}
execute if score @s m.trig matches 480 run function metiers:appel {f:"bareme/menu"}
execute if score @s m.trig matches 481 run function metiers:appel {f:"bareme/b"}
execute if score @s m.trig matches 482 run function metiers:appel {f:"bareme/f"}
execute if score @s m.trig matches 483 run function metiers:appel {f:"bareme/m"}
execute if score @s m.trig matches 484 run function metiers:appel {f:"bareme/c"}
execute if score @s m.trig matches 485 run function metiers:appel {f:"bareme/p"}
execute if score @s m.trig matches 486 run function metiers:appel {f:"bareme/e"}
execute if score @s m.trig matches 487 run function metiers:appel {f:"bareme/n"}
execute if score @s m.trig matches 488 run function metiers:appel {f:"bareme/x"}
execute if score @s m.trig matches 489 run function metiers:appel {f:"bareme/t"}
execute if score @s m.trig matches 490 run function metiers:appel {f:"bareme/k"}
execute if score @s m.trig matches 447 run function metiers:appel {f:"skins/cadre_7"}
execute if score @s m.trig matches 499 run function metiers:appel {f:"prestige/aura_basculer"}
execute if score @s m.trig matches 495 run function metiers:appel {f:"quete/page"}
execute if score @s m.trig matches 496 run function metiers:appel {f:"synergie/page"}
execute if score @s m.trig matches 770 run function metiers:appel {f:"guilde/page"}
execute if score @s m.trig matches 771 run function metiers:appel {f:"guilde/creer"}
execute if score @s m.trig matches 772 run function metiers:appel {f:"guilde/quitter"}
execute if score @s m.trig matches 773 run function metiers:appel {f:"guilde/inviter_liste"}
execute if score @s m.trig matches 775 run function metiers:appel {f:"guilde/accepter"}
execute if score @s m.trig matches 7100000..7199999 run function metiers:appel {f:"guilde/inviter"}
execute if score @s m.trig matches 7200000..7299999 run function metiers:appel {f:"guilde/exclure"}
execute if score @s m.trig matches 521 run function metiers:appel {f:"classement/metier_b"}
execute if score @s m.trig matches 522 run function metiers:appel {f:"classement/metier_f"}
execute if score @s m.trig matches 523 run function metiers:appel {f:"classement/metier_m"}
execute if score @s m.trig matches 524 run function metiers:appel {f:"classement/metier_c"}
execute if score @s m.trig matches 525 run function metiers:appel {f:"classement/metier_p"}
execute if score @s m.trig matches 526 run function metiers:appel {f:"classement/metier_e"}
execute if score @s m.trig matches 527 run function metiers:appel {f:"classement/metier_n"}
execute if score @s m.trig matches 528 run function metiers:appel {f:"classement/metier_x"}
execute if score @s m.trig matches 529 run function metiers:appel {f:"classement/metier_t"}
execute if score @s m.trig matches 530 run function metiers:appel {f:"classement/metier_k"}
execute if score @s m.trig matches 540 run function metiers:sommaire
