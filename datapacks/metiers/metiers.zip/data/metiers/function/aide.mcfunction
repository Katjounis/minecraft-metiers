dialog show @s metiers:aide
