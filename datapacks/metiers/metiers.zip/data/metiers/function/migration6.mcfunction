tag @s add metiers.v7
tag @s add metiers.v6
scoreboard players add @s m.b_pr 0
scoreboard players add @s m.b_cd 0
execute unless score @s m.b_out matches 0.. run scoreboard players set @s m.b_out 0
scoreboard players operation @s m.b_out > @s m.b_pal
scoreboard players operation @s m.tmp = @s m.b_lvl
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.b_out > @s m.tmp
execute if score @s m.b_out matches 1.. run function metiers:appel {f:"b/outil_donner"}
scoreboard players add @s m.f_pr 0
scoreboard players add @s m.f_cd 0
execute unless score @s m.f_out matches 0.. run scoreboard players set @s m.f_out 0
scoreboard players operation @s m.f_out > @s m.f_pal
scoreboard players operation @s m.tmp = @s m.f_lvl
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.f_out > @s m.tmp
execute if score @s m.f_out matches 1.. run function metiers:appel {f:"f/outil_donner"}
scoreboard players add @s m.m_pr 0
scoreboard players add @s m.m_cd 0
execute unless score @s m.m_out matches 0.. run scoreboard players set @s m.m_out 0
scoreboard players operation @s m.m_out > @s m.m_pal
scoreboard players operation @s m.tmp = @s m.m_lvl
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.m_out > @s m.tmp
execute if score @s m.m_out matches 1.. run function metiers:appel {f:"m/outil_donner"}
scoreboard players add @s m.c_pr 0
scoreboard players add @s m.c_cd 0
execute unless score @s m.c_out matches 0.. run scoreboard players set @s m.c_out 0
scoreboard players operation @s m.c_out > @s m.c_pal
scoreboard players operation @s m.tmp = @s m.c_lvl
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.c_out > @s m.tmp
execute if score @s m.c_out matches 1.. run function metiers:appel {f:"c/outil_donner"}
scoreboard players add @s m.p_pr 0
scoreboard players add @s m.p_cd 0
execute unless score @s m.p_out matches 0.. run scoreboard players set @s m.p_out 0
scoreboard players operation @s m.p_out > @s m.p_pal
scoreboard players operation @s m.tmp = @s m.p_lvl
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.p_out > @s m.tmp
execute if score @s m.p_out matches 1.. run function metiers:appel {f:"p/outil_donner"}
scoreboard players add @s m.e_pr 0
scoreboard players add @s m.e_cd 0
execute unless score @s m.e_out matches 0.. run scoreboard players set @s m.e_out 0
scoreboard players operation @s m.e_out > @s m.e_pal
scoreboard players operation @s m.tmp = @s m.e_lvl
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.e_out > @s m.tmp
execute if score @s m.e_out matches 1.. run function metiers:appel {f:"e/outil_donner"}
scoreboard players add @s m.n_pr 0
scoreboard players add @s m.n_cd 0
execute unless score @s m.n_out matches 0.. run scoreboard players set @s m.n_out 0
scoreboard players operation @s m.n_out > @s m.n_pal
scoreboard players operation @s m.tmp = @s m.n_lvl
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.n_out > @s m.tmp
execute if score @s m.n_out matches 1.. run function metiers:appel {f:"n/outil_donner"}
scoreboard players add @s m.x_pr 0
scoreboard players add @s m.x_cd 0
execute unless score @s m.x_out matches 0.. run scoreboard players set @s m.x_out 0
scoreboard players operation @s m.x_out > @s m.x_pal
scoreboard players operation @s m.tmp = @s m.x_lvl
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.x_out > @s m.tmp
execute if score @s m.x_out matches 1.. run function metiers:appel {f:"x/outil_donner"}
scoreboard players add @s m.t_pr 0
scoreboard players add @s m.t_cd 0
execute unless score @s m.t_out matches 0.. run scoreboard players set @s m.t_out 0
scoreboard players operation @s m.t_out > @s m.t_pal
scoreboard players operation @s m.tmp = @s m.t_lvl
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.t_out > @s m.tmp
execute if score @s m.t_out matches 1.. run function metiers:appel {f:"t/outil_donner"}
scoreboard players add @s m.k_pr 0
scoreboard players add @s m.k_cd 0
execute unless score @s m.k_out matches 0.. run scoreboard players set @s m.k_out 0
scoreboard players operation @s m.k_out > @s m.k_pal
scoreboard players operation @s m.tmp = @s m.k_lvl
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.k_out > @s m.tmp
execute if score @s m.k_out matches 1.. run function metiers:appel {f:"k/outil_donner"}
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Nouveau : chaque métier a son outil qui évolue avec toi ! Tu viens de recevoir ceux des métiers où tu es niveau 10 ou plus, au palier qui correspond à ton niveau. Pour les autres : touche G, le métier, puis « Récupérer mon outil ». Défis du jour, classement, prestige et boss de serveur sont aussi arrivés.","color":"yellow"}]
