tag @s add metiers.v3
execute if entity @s[tag=metiers.sk.b1,tag=!metiers.skoff.b1] run advancement grant @s only metiers:b/competence_1
execute if entity @s[tag=metiers.sk.b2,tag=!metiers.skoff.b2] run advancement grant @s only metiers:b/competence_2
execute if entity @s[tag=metiers.sk.b3,tag=!metiers.skoff.b3] run advancement grant @s only metiers:b/competence_3
execute if entity @s[tag=metiers.sk.b4,tag=!metiers.skoff.b4] run advancement grant @s only metiers:b/competence_4
execute if entity @s[tag=metiers.sk.b5,tag=!metiers.skoff.b5] run advancement grant @s only metiers:b/competence_5
execute if entity @s[tag=metiers.sk.b6,tag=!metiers.skoff.b6] run advancement grant @s only metiers:b/competence_6
execute if score @s m.b_lvl matches 10.. run advancement grant @s only metiers:b/niveau_10
execute if score @s m.b_lvl matches 20.. run advancement grant @s only metiers:b/niveau_20
execute if score @s m.b_lvl matches 30.. run advancement grant @s only metiers:b/niveau_30
execute if score @s m.b_lvl matches 40.. run advancement grant @s only metiers:b/niveau_40
execute if score @s m.b_lvl matches 50.. run advancement grant @s only metiers:b/niveau_50
execute if score @s m.b_lvl matches 60.. run advancement grant @s only metiers:b/niveau_60
execute if score @s m.b_lvl matches 70.. run advancement grant @s only metiers:b/niveau_70
execute if score @s m.b_lvl matches 80.. run advancement grant @s only metiers:b/niveau_80
execute if score @s m.b_lvl matches 90.. run advancement grant @s only metiers:b/niveau_90
execute if score @s m.b_lvl matches 100.. run advancement grant @s only metiers:b/niveau_100
execute if entity @s[tag=metiers.sk.f1,tag=!metiers.skoff.f1] run advancement grant @s only metiers:f/competence_1
execute if entity @s[tag=metiers.sk.f2,tag=!metiers.skoff.f2] run advancement grant @s only metiers:f/competence_2
execute if entity @s[tag=metiers.sk.f3,tag=!metiers.skoff.f3] run advancement grant @s only metiers:f/competence_3
execute if entity @s[tag=metiers.sk.f4,tag=!metiers.skoff.f4] run advancement grant @s only metiers:f/competence_4
execute if entity @s[tag=metiers.sk.f5,tag=!metiers.skoff.f5] run advancement grant @s only metiers:f/competence_5
execute if entity @s[tag=metiers.sk.f6,tag=!metiers.skoff.f6] run advancement grant @s only metiers:f/competence_6
execute if score @s m.f_lvl matches 10.. run advancement grant @s only metiers:f/niveau_10
execute if score @s m.f_lvl matches 20.. run advancement grant @s only metiers:f/niveau_20
execute if score @s m.f_lvl matches 30.. run advancement grant @s only metiers:f/niveau_30
execute if score @s m.f_lvl matches 40.. run advancement grant @s only metiers:f/niveau_40
execute if score @s m.f_lvl matches 50.. run advancement grant @s only metiers:f/niveau_50
execute if score @s m.f_lvl matches 60.. run advancement grant @s only metiers:f/niveau_60
execute if score @s m.f_lvl matches 70.. run advancement grant @s only metiers:f/niveau_70
execute if score @s m.f_lvl matches 80.. run advancement grant @s only metiers:f/niveau_80
execute if score @s m.f_lvl matches 90.. run advancement grant @s only metiers:f/niveau_90
execute if score @s m.f_lvl matches 100.. run advancement grant @s only metiers:f/niveau_100
execute if entity @s[tag=metiers.sk.m1,tag=!metiers.skoff.m1] run advancement grant @s only metiers:m/competence_1
execute if entity @s[tag=metiers.sk.m2,tag=!metiers.skoff.m2] run advancement grant @s only metiers:m/competence_2
execute if entity @s[tag=metiers.sk.m3,tag=!metiers.skoff.m3] run advancement grant @s only metiers:m/competence_3
execute if entity @s[tag=metiers.sk.m4,tag=!metiers.skoff.m4] run advancement grant @s only metiers:m/competence_4
execute if entity @s[tag=metiers.sk.m5,tag=!metiers.skoff.m5] run advancement grant @s only metiers:m/competence_5
execute if entity @s[tag=metiers.sk.m6,tag=!metiers.skoff.m6] run advancement grant @s only metiers:m/competence_6
execute if score @s m.m_lvl matches 10.. run advancement grant @s only metiers:m/niveau_10
execute if score @s m.m_lvl matches 20.. run advancement grant @s only metiers:m/niveau_20
execute if score @s m.m_lvl matches 30.. run advancement grant @s only metiers:m/niveau_30
execute if score @s m.m_lvl matches 40.. run advancement grant @s only metiers:m/niveau_40
execute if score @s m.m_lvl matches 50.. run advancement grant @s only metiers:m/niveau_50
execute if score @s m.m_lvl matches 60.. run advancement grant @s only metiers:m/niveau_60
execute if score @s m.m_lvl matches 70.. run advancement grant @s only metiers:m/niveau_70
execute if score @s m.m_lvl matches 80.. run advancement grant @s only metiers:m/niveau_80
execute if score @s m.m_lvl matches 90.. run advancement grant @s only metiers:m/niveau_90
execute if score @s m.m_lvl matches 100.. run advancement grant @s only metiers:m/niveau_100
execute if entity @s[tag=metiers.sk.c1,tag=!metiers.skoff.c1] run advancement grant @s only metiers:c/competence_1
execute if entity @s[tag=metiers.sk.c2,tag=!metiers.skoff.c2] run advancement grant @s only metiers:c/competence_2
execute if entity @s[tag=metiers.sk.c3,tag=!metiers.skoff.c3] run advancement grant @s only metiers:c/competence_3
execute if entity @s[tag=metiers.sk.c4,tag=!metiers.skoff.c4] run advancement grant @s only metiers:c/competence_4
execute if entity @s[tag=metiers.sk.c5,tag=!metiers.skoff.c5] run advancement grant @s only metiers:c/competence_5
execute if entity @s[tag=metiers.sk.c6,tag=!metiers.skoff.c6] run advancement grant @s only metiers:c/competence_6
execute if score @s m.c_lvl matches 10.. run advancement grant @s only metiers:c/niveau_10
execute if score @s m.c_lvl matches 20.. run advancement grant @s only metiers:c/niveau_20
execute if score @s m.c_lvl matches 30.. run advancement grant @s only metiers:c/niveau_30
execute if score @s m.c_lvl matches 40.. run advancement grant @s only metiers:c/niveau_40
execute if score @s m.c_lvl matches 50.. run advancement grant @s only metiers:c/niveau_50
execute if score @s m.c_lvl matches 60.. run advancement grant @s only metiers:c/niveau_60
execute if score @s m.c_lvl matches 70.. run advancement grant @s only metiers:c/niveau_70
execute if score @s m.c_lvl matches 80.. run advancement grant @s only metiers:c/niveau_80
execute if score @s m.c_lvl matches 90.. run advancement grant @s only metiers:c/niveau_90
execute if score @s m.c_lvl matches 100.. run advancement grant @s only metiers:c/niveau_100
execute if entity @s[tag=metiers.sk.p1,tag=!metiers.skoff.p1] run advancement grant @s only metiers:p/competence_1
execute if entity @s[tag=metiers.sk.p2,tag=!metiers.skoff.p2] run advancement grant @s only metiers:p/competence_2
execute if entity @s[tag=metiers.sk.p3,tag=!metiers.skoff.p3] run advancement grant @s only metiers:p/competence_3
execute if entity @s[tag=metiers.sk.p4,tag=!metiers.skoff.p4] run advancement grant @s only metiers:p/competence_4
execute if entity @s[tag=metiers.sk.p5,tag=!metiers.skoff.p5] run advancement grant @s only metiers:p/competence_5
execute if entity @s[tag=metiers.sk.p6,tag=!metiers.skoff.p6] run advancement grant @s only metiers:p/competence_6
execute if score @s m.p_lvl matches 10.. run advancement grant @s only metiers:p/niveau_10
execute if score @s m.p_lvl matches 20.. run advancement grant @s only metiers:p/niveau_20
execute if score @s m.p_lvl matches 30.. run advancement grant @s only metiers:p/niveau_30
execute if score @s m.p_lvl matches 40.. run advancement grant @s only metiers:p/niveau_40
execute if score @s m.p_lvl matches 50.. run advancement grant @s only metiers:p/niveau_50
execute if score @s m.p_lvl matches 60.. run advancement grant @s only metiers:p/niveau_60
execute if score @s m.p_lvl matches 70.. run advancement grant @s only metiers:p/niveau_70
execute if score @s m.p_lvl matches 80.. run advancement grant @s only metiers:p/niveau_80
execute if score @s m.p_lvl matches 90.. run advancement grant @s only metiers:p/niveau_90
execute if score @s m.p_lvl matches 100.. run advancement grant @s only metiers:p/niveau_100
execute if entity @s[tag=metiers.sk.e1,tag=!metiers.skoff.e1] run advancement grant @s only metiers:e/competence_1
execute if entity @s[tag=metiers.sk.e2,tag=!metiers.skoff.e2] run advancement grant @s only metiers:e/competence_2
execute if entity @s[tag=metiers.sk.e3,tag=!metiers.skoff.e3] run advancement grant @s only metiers:e/competence_3
execute if entity @s[tag=metiers.sk.e4,tag=!metiers.skoff.e4] run advancement grant @s only metiers:e/competence_4
execute if entity @s[tag=metiers.sk.e5,tag=!metiers.skoff.e5] run advancement grant @s only metiers:e/competence_5
execute if entity @s[tag=metiers.sk.e6,tag=!metiers.skoff.e6] run advancement grant @s only metiers:e/competence_6
execute if score @s m.e_lvl matches 10.. run advancement grant @s only metiers:e/niveau_10
execute if score @s m.e_lvl matches 20.. run advancement grant @s only metiers:e/niveau_20
execute if score @s m.e_lvl matches 30.. run advancement grant @s only metiers:e/niveau_30
execute if score @s m.e_lvl matches 40.. run advancement grant @s only metiers:e/niveau_40
execute if score @s m.e_lvl matches 50.. run advancement grant @s only metiers:e/niveau_50
execute if score @s m.e_lvl matches 60.. run advancement grant @s only metiers:e/niveau_60
execute if score @s m.e_lvl matches 70.. run advancement grant @s only metiers:e/niveau_70
execute if score @s m.e_lvl matches 80.. run advancement grant @s only metiers:e/niveau_80
execute if score @s m.e_lvl matches 90.. run advancement grant @s only metiers:e/niveau_90
execute if score @s m.e_lvl matches 100.. run advancement grant @s only metiers:e/niveau_100
execute if entity @s[tag=metiers.sk.n1,tag=!metiers.skoff.n1] run advancement grant @s only metiers:n/competence_1
execute if entity @s[tag=metiers.sk.n2,tag=!metiers.skoff.n2] run advancement grant @s only metiers:n/competence_2
execute if entity @s[tag=metiers.sk.n3,tag=!metiers.skoff.n3] run advancement grant @s only metiers:n/competence_3
execute if entity @s[tag=metiers.sk.n4,tag=!metiers.skoff.n4] run advancement grant @s only metiers:n/competence_4
execute if entity @s[tag=metiers.sk.n5,tag=!metiers.skoff.n5] run advancement grant @s only metiers:n/competence_5
execute if entity @s[tag=metiers.sk.n6,tag=!metiers.skoff.n6] run advancement grant @s only metiers:n/competence_6
execute if score @s m.n_lvl matches 10.. run advancement grant @s only metiers:n/niveau_10
execute if score @s m.n_lvl matches 20.. run advancement grant @s only metiers:n/niveau_20
execute if score @s m.n_lvl matches 30.. run advancement grant @s only metiers:n/niveau_30
execute if score @s m.n_lvl matches 40.. run advancement grant @s only metiers:n/niveau_40
execute if score @s m.n_lvl matches 50.. run advancement grant @s only metiers:n/niveau_50
execute if score @s m.n_lvl matches 60.. run advancement grant @s only metiers:n/niveau_60
execute if score @s m.n_lvl matches 70.. run advancement grant @s only metiers:n/niveau_70
execute if score @s m.n_lvl matches 80.. run advancement grant @s only metiers:n/niveau_80
execute if score @s m.n_lvl matches 90.. run advancement grant @s only metiers:n/niveau_90
execute if score @s m.n_lvl matches 100.. run advancement grant @s only metiers:n/niveau_100
execute if entity @s[tag=metiers.sk.x1,tag=!metiers.skoff.x1] run advancement grant @s only metiers:x/competence_1
execute if entity @s[tag=metiers.sk.x2,tag=!metiers.skoff.x2] run advancement grant @s only metiers:x/competence_2
execute if entity @s[tag=metiers.sk.x3,tag=!metiers.skoff.x3] run advancement grant @s only metiers:x/competence_3
execute if entity @s[tag=metiers.sk.x4,tag=!metiers.skoff.x4] run advancement grant @s only metiers:x/competence_4
execute if entity @s[tag=metiers.sk.x5,tag=!metiers.skoff.x5] run advancement grant @s only metiers:x/competence_5
execute if entity @s[tag=metiers.sk.x6,tag=!metiers.skoff.x6] run advancement grant @s only metiers:x/competence_6
execute if score @s m.x_lvl matches 10.. run advancement grant @s only metiers:x/niveau_10
execute if score @s m.x_lvl matches 20.. run advancement grant @s only metiers:x/niveau_20
execute if score @s m.x_lvl matches 30.. run advancement grant @s only metiers:x/niveau_30
execute if score @s m.x_lvl matches 40.. run advancement grant @s only metiers:x/niveau_40
execute if score @s m.x_lvl matches 50.. run advancement grant @s only metiers:x/niveau_50
execute if score @s m.x_lvl matches 60.. run advancement grant @s only metiers:x/niveau_60
execute if score @s m.x_lvl matches 70.. run advancement grant @s only metiers:x/niveau_70
execute if score @s m.x_lvl matches 80.. run advancement grant @s only metiers:x/niveau_80
execute if score @s m.x_lvl matches 90.. run advancement grant @s only metiers:x/niveau_90
execute if score @s m.x_lvl matches 100.. run advancement grant @s only metiers:x/niveau_100
execute if entity @s[tag=metiers.sk.t1,tag=!metiers.skoff.t1] run advancement grant @s only metiers:t/competence_1
execute if entity @s[tag=metiers.sk.t2,tag=!metiers.skoff.t2] run advancement grant @s only metiers:t/competence_2
execute if entity @s[tag=metiers.sk.t3,tag=!metiers.skoff.t3] run advancement grant @s only metiers:t/competence_3
execute if entity @s[tag=metiers.sk.t4,tag=!metiers.skoff.t4] run advancement grant @s only metiers:t/competence_4
execute if entity @s[tag=metiers.sk.t5,tag=!metiers.skoff.t5] run advancement grant @s only metiers:t/competence_5
execute if entity @s[tag=metiers.sk.t6,tag=!metiers.skoff.t6] run advancement grant @s only metiers:t/competence_6
execute if score @s m.t_lvl matches 10.. run advancement grant @s only metiers:t/niveau_10
execute if score @s m.t_lvl matches 20.. run advancement grant @s only metiers:t/niveau_20
execute if score @s m.t_lvl matches 30.. run advancement grant @s only metiers:t/niveau_30
execute if score @s m.t_lvl matches 40.. run advancement grant @s only metiers:t/niveau_40
execute if score @s m.t_lvl matches 50.. run advancement grant @s only metiers:t/niveau_50
execute if score @s m.t_lvl matches 60.. run advancement grant @s only metiers:t/niveau_60
execute if score @s m.t_lvl matches 70.. run advancement grant @s only metiers:t/niveau_70
execute if score @s m.t_lvl matches 80.. run advancement grant @s only metiers:t/niveau_80
execute if score @s m.t_lvl matches 90.. run advancement grant @s only metiers:t/niveau_90
execute if score @s m.t_lvl matches 100.. run advancement grant @s only metiers:t/niveau_100
execute if entity @s[tag=metiers.sk.k1,tag=!metiers.skoff.k1] run advancement grant @s only metiers:k/competence_1
execute if entity @s[tag=metiers.sk.k2,tag=!metiers.skoff.k2] run advancement grant @s only metiers:k/competence_2
execute if entity @s[tag=metiers.sk.k3,tag=!metiers.skoff.k3] run advancement grant @s only metiers:k/competence_3
execute if entity @s[tag=metiers.sk.k4,tag=!metiers.skoff.k4] run advancement grant @s only metiers:k/competence_4
execute if entity @s[tag=metiers.sk.k5,tag=!metiers.skoff.k5] run advancement grant @s only metiers:k/competence_5
execute if entity @s[tag=metiers.sk.k6,tag=!metiers.skoff.k6] run advancement grant @s only metiers:k/competence_6
execute if score @s m.k_lvl matches 10.. run advancement grant @s only metiers:k/niveau_10
execute if score @s m.k_lvl matches 20.. run advancement grant @s only metiers:k/niveau_20
execute if score @s m.k_lvl matches 30.. run advancement grant @s only metiers:k/niveau_30
execute if score @s m.k_lvl matches 40.. run advancement grant @s only metiers:k/niveau_40
execute if score @s m.k_lvl matches 50.. run advancement grant @s only metiers:k/niveau_50
execute if score @s m.k_lvl matches 60.. run advancement grant @s only metiers:k/niveau_60
execute if score @s m.k_lvl matches 70.. run advancement grant @s only metiers:k/niveau_70
execute if score @s m.k_lvl matches 80.. run advancement grant @s only metiers:k/niveau_80
execute if score @s m.k_lvl matches 90.. run advancement grant @s only metiers:k/niveau_90
execute if score @s m.k_lvl matches 100.. run advancement grant @s only metiers:k/niveau_100
