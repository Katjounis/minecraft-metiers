tag @s add metiers.v3
execute if entity @s[tag=metiers.sk.b1,tag=!metiers.skoff.b1] run advancement grant @s only metiers:b/competence_1
execute if entity @s[tag=metiers.sk.b2,tag=!metiers.skoff.b2] run advancement grant @s only metiers:b/competence_2
execute if entity @s[tag=metiers.sk.b3,tag=!metiers.skoff.b3] run advancement grant @s only metiers:b/competence_3
execute if entity @s[tag=metiers.sk.b4,tag=!metiers.skoff.b4] run advancement grant @s only metiers:b/competence_4
execute if entity @s[tag=metiers.sk.b5,tag=!metiers.skoff.b5] run advancement grant @s only metiers:b/competence_5
execute if entity @s[tag=metiers.sk.b6,tag=!metiers.skoff.b6] run advancement grant @s only metiers:b/competence_6
execute if entity @s[tag=metiers.sk.b7,tag=!metiers.skoff.b7] run advancement grant @s only metiers:b/competence_7
execute if entity @s[tag=metiers.sk.b8,tag=!metiers.skoff.b8] run advancement grant @s only metiers:b/competence_8
execute if entity @s[tag=metiers.sk.b9,tag=!metiers.skoff.b9] run advancement grant @s only metiers:b/competence_9
execute if entity @s[tag=metiers.sk.b10,tag=!metiers.skoff.b10] run advancement grant @s only metiers:b/competence_10
execute if entity @s[tag=metiers.sk.b11,tag=!metiers.skoff.b11] run advancement grant @s only metiers:b/competence_11
execute if entity @s[tag=metiers.sk.b12,tag=!metiers.skoff.b12] run advancement grant @s only metiers:b/competence_12
execute if entity @s[tag=metiers.sk.b13,tag=!metiers.skoff.b13] run advancement grant @s only metiers:b/competence_13
execute if entity @s[tag=metiers.sk.b14,tag=!metiers.skoff.b14] run advancement grant @s only metiers:b/competence_14
execute if entity @s[tag=metiers.sk.b15,tag=!metiers.skoff.b15] run advancement grant @s only metiers:b/competence_15
execute if entity @s[tag=metiers.sk.b16,tag=!metiers.skoff.b16] run advancement grant @s only metiers:b/competence_16
execute if entity @s[tag=metiers.sk.b17,tag=!metiers.skoff.b17] run advancement grant @s only metiers:b/competence_17
execute if entity @s[tag=metiers.sk.b18,tag=!metiers.skoff.b18] run advancement grant @s only metiers:b/competence_18
execute if score @s m.b_lvl matches 10.. run advancement grant @s only metiers:b/niveau_10
execute if score @s m.b_lvl matches 20.. run advancement grant @s only metiers:b/niveau_20
execute if score @s m.b_lvl matches 30.. run advancement grant @s only metiers:b/niveau_30
execute if score @s m.b_lvl matches 40.. run advancement grant @s only metiers:b/niveau_40
execute if score @s m.b_lvl matches 50.. run advancement grant @s only metiers:b/niveau_50
execute if score @s m.b_lvl matches 60.. run advancement grant @s only metiers:b/niveau_60
execute if score @s m.b_lvl matches 70.. run advancement grant @s only metiers:b/niveau_70
execute if score @s m.b_lvl matches 80.. run advancement grant @s only metiers:b/niveau_80
execute if score @s m.b_lvl matches 90.. run advancement grant @s only metiers:b/niveau_90
execute if score @s m.b_lvl matches 100.. run advancement grant @s only metiers:b/niveau_100
execute if entity @s[tag=metiers.sk.f1,tag=!metiers.skoff.f1] run advancement grant @s only metiers:f/competence_1
execute if entity @s[tag=metiers.sk.f2,tag=!metiers.skoff.f2] run advancement grant @s only metiers:f/competence_2
execute if entity @s[tag=metiers.sk.f3,tag=!metiers.skoff.f3] run advancement grant @s only metiers:f/competence_3
execute if entity @s[tag=metiers.sk.f4,tag=!metiers.skoff.f4] run advancement grant @s only metiers:f/competence_4
execute if entity @s[tag=metiers.sk.f5,tag=!metiers.skoff.f5] run advancement grant @s only metiers:f/competence_5
execute if entity @s[tag=metiers.sk.f6,tag=!metiers.skoff.f6] run advancement grant @s only metiers:f/competence_6
execute if entity @s[tag=metiers.sk.f7,tag=!metiers.skoff.f7] run advancement grant @s only metiers:f/competence_7
execute if entity @s[tag=metiers.sk.f8,tag=!metiers.skoff.f8] run advancement grant @s only metiers:f/competence_8
execute if entity @s[tag=metiers.sk.f9,tag=!metiers.skoff.f9] run advancement grant @s only metiers:f/competence_9
execute if entity @s[tag=metiers.sk.f10,tag=!metiers.skoff.f10] run advancement grant @s only metiers:f/competence_10
execute if entity @s[tag=metiers.sk.f11,tag=!metiers.skoff.f11] run advancement grant @s only metiers:f/competence_11
execute if entity @s[tag=metiers.sk.f12,tag=!metiers.skoff.f12] run advancement grant @s only metiers:f/competence_12
execute if entity @s[tag=metiers.sk.f13,tag=!metiers.skoff.f13] run advancement grant @s only metiers:f/competence_13
execute if entity @s[tag=metiers.sk.f14,tag=!metiers.skoff.f14] run advancement grant @s only metiers:f/competence_14
execute if entity @s[tag=metiers.sk.f15,tag=!metiers.skoff.f15] run advancement grant @s only metiers:f/competence_15
execute if entity @s[tag=metiers.sk.f16,tag=!metiers.skoff.f16] run advancement grant @s only metiers:f/competence_16
execute if entity @s[tag=metiers.sk.f17,tag=!metiers.skoff.f17] run advancement grant @s only metiers:f/competence_17
execute if entity @s[tag=metiers.sk.f18,tag=!metiers.skoff.f18] run advancement grant @s only metiers:f/competence_18
execute if score @s m.f_lvl matches 10.. run advancement grant @s only metiers:f/niveau_10
execute if score @s m.f_lvl matches 20.. run advancement grant @s only metiers:f/niveau_20
execute if score @s m.f_lvl matches 30.. run advancement grant @s only metiers:f/niveau_30
execute if score @s m.f_lvl matches 40.. run advancement grant @s only metiers:f/niveau_40
execute if score @s m.f_lvl matches 50.. run advancement grant @s only metiers:f/niveau_50
execute if score @s m.f_lvl matches 60.. run advancement grant @s only metiers:f/niveau_60
execute if score @s m.f_lvl matches 70.. run advancement grant @s only metiers:f/niveau_70
execute if score @s m.f_lvl matches 80.. run advancement grant @s only metiers:f/niveau_80
execute if score @s m.f_lvl matches 90.. run advancement grant @s only metiers:f/niveau_90
execute if score @s m.f_lvl matches 100.. run advancement grant @s only metiers:f/niveau_100
execute if entity @s[tag=metiers.sk.m1,tag=!metiers.skoff.m1] run advancement grant @s only metiers:m/competence_1
execute if entity @s[tag=metiers.sk.m2,tag=!metiers.skoff.m2] run advancement grant @s only metiers:m/competence_2
execute if entity @s[tag=metiers.sk.m3,tag=!metiers.skoff.m3] run advancement grant @s only metiers:m/competence_3
execute if entity @s[tag=metiers.sk.m4,tag=!metiers.skoff.m4] run advancement grant @s only metiers:m/competence_4
execute if entity @s[tag=metiers.sk.m5,tag=!metiers.skoff.m5] run advancement grant @s only metiers:m/competence_5
execute if entity @s[tag=metiers.sk.m6,tag=!metiers.skoff.m6] run advancement grant @s only metiers:m/competence_6
execute if entity @s[tag=metiers.sk.m7,tag=!metiers.skoff.m7] run advancement grant @s only metiers:m/competence_7
execute if entity @s[tag=metiers.sk.m8,tag=!metiers.skoff.m8] run advancement grant @s only metiers:m/competence_8
execute if entity @s[tag=metiers.sk.m9,tag=!metiers.skoff.m9] run advancement grant @s only metiers:m/competence_9
execute if entity @s[tag=metiers.sk.m10,tag=!metiers.skoff.m10] run advancement grant @s only metiers:m/competence_10
execute if entity @s[tag=metiers.sk.m11,tag=!metiers.skoff.m11] run advancement grant @s only metiers:m/competence_11
execute if entity @s[tag=metiers.sk.m12,tag=!metiers.skoff.m12] run advancement grant @s only metiers:m/competence_12
execute if entity @s[tag=metiers.sk.m13,tag=!metiers.skoff.m13] run advancement grant @s only metiers:m/competence_13
execute if entity @s[tag=metiers.sk.m14,tag=!metiers.skoff.m14] run advancement grant @s only metiers:m/competence_14
execute if entity @s[tag=metiers.sk.m15,tag=!metiers.skoff.m15] run advancement grant @s only metiers:m/competence_15
execute if entity @s[tag=metiers.sk.m16,tag=!metiers.skoff.m16] run advancement grant @s only metiers:m/competence_16
execute if entity @s[tag=metiers.sk.m17,tag=!metiers.skoff.m17] run advancement grant @s only metiers:m/competence_17
execute if entity @s[tag=metiers.sk.m18,tag=!metiers.skoff.m18] run advancement grant @s only metiers:m/competence_18
execute if score @s m.m_lvl matches 10.. run advancement grant @s only metiers:m/niveau_10
execute if score @s m.m_lvl matches 20.. run advancement grant @s only metiers:m/niveau_20
execute if score @s m.m_lvl matches 30.. run advancement grant @s only metiers:m/niveau_30
execute if score @s m.m_lvl matches 40.. run advancement grant @s only metiers:m/niveau_40
execute if score @s m.m_lvl matches 50.. run advancement grant @s only metiers:m/niveau_50
execute if score @s m.m_lvl matches 60.. run advancement grant @s only metiers:m/niveau_60
execute if score @s m.m_lvl matches 70.. run advancement grant @s only metiers:m/niveau_70
execute if score @s m.m_lvl matches 80.. run advancement grant @s only metiers:m/niveau_80
execute if score @s m.m_lvl matches 90.. run advancement grant @s only metiers:m/niveau_90
execute if score @s m.m_lvl matches 100.. run advancement grant @s only metiers:m/niveau_100
execute if entity @s[tag=metiers.sk.c1,tag=!metiers.skoff.c1] run advancement grant @s only metiers:c/competence_1
execute if entity @s[tag=metiers.sk.c2,tag=!metiers.skoff.c2] run advancement grant @s only metiers:c/competence_2
execute if entity @s[tag=metiers.sk.c3,tag=!metiers.skoff.c3] run advancement grant @s only metiers:c/competence_3
execute if entity @s[tag=metiers.sk.c4,tag=!metiers.skoff.c4] run advancement grant @s only metiers:c/competence_4
execute if entity @s[tag=metiers.sk.c5,tag=!metiers.skoff.c5] run advancement grant @s only metiers:c/competence_5
execute if entity @s[tag=metiers.sk.c6,tag=!metiers.skoff.c6] run advancement grant @s only metiers:c/competence_6
execute if entity @s[tag=metiers.sk.c7,tag=!metiers.skoff.c7] run advancement grant @s only metiers:c/competence_7
execute if entity @s[tag=metiers.sk.c8,tag=!metiers.skoff.c8] run advancement grant @s only metiers:c/competence_8
execute if entity @s[tag=metiers.sk.c9,tag=!metiers.skoff.c9] run advancement grant @s only metiers:c/competence_9
execute if entity @s[tag=metiers.sk.c10,tag=!metiers.skoff.c10] run advancement grant @s only metiers:c/competence_10
execute if entity @s[tag=metiers.sk.c11,tag=!metiers.skoff.c11] run advancement grant @s only metiers:c/competence_11
execute if entity @s[tag=metiers.sk.c12,tag=!metiers.skoff.c12] run advancement grant @s only metiers:c/competence_12
execute if entity @s[tag=metiers.sk.c13,tag=!metiers.skoff.c13] run advancement grant @s only metiers:c/competence_13
execute if entity @s[tag=metiers.sk.c14,tag=!metiers.skoff.c14] run advancement grant @s only metiers:c/competence_14
execute if entity @s[tag=metiers.sk.c15,tag=!metiers.skoff.c15] run advancement grant @s only metiers:c/competence_15
execute if entity @s[tag=metiers.sk.c16,tag=!metiers.skoff.c16] run advancement grant @s only metiers:c/competence_16
execute if entity @s[tag=metiers.sk.c17,tag=!metiers.skoff.c17] run advancement grant @s only metiers:c/competence_17
execute if entity @s[tag=metiers.sk.c18,tag=!metiers.skoff.c18] run advancement grant @s only metiers:c/competence_18
execute if score @s m.c_lvl matches 10.. run advancement grant @s only metiers:c/niveau_10
execute if score @s m.c_lvl matches 20.. run advancement grant @s only metiers:c/niveau_20
execute if score @s m.c_lvl matches 30.. run advancement grant @s only metiers:c/niveau_30
execute if score @s m.c_lvl matches 40.. run advancement grant @s only metiers:c/niveau_40
execute if score @s m.c_lvl matches 50.. run advancement grant @s only metiers:c/niveau_50
execute if score @s m.c_lvl matches 60.. run advancement grant @s only metiers:c/niveau_60
execute if score @s m.c_lvl matches 70.. run advancement grant @s only metiers:c/niveau_70
execute if score @s m.c_lvl matches 80.. run advancement grant @s only metiers:c/niveau_80
execute if score @s m.c_lvl matches 90.. run advancement grant @s only metiers:c/niveau_90
execute if score @s m.c_lvl matches 100.. run advancement grant @s only metiers:c/niveau_100
execute if entity @s[tag=metiers.sk.p1,tag=!metiers.skoff.p1] run advancement grant @s only metiers:p/competence_1
execute if entity @s[tag=metiers.sk.p2,tag=!metiers.skoff.p2] run advancement grant @s only metiers:p/competence_2
execute if entity @s[tag=metiers.sk.p3,tag=!metiers.skoff.p3] run advancement grant @s only metiers:p/competence_3
execute if entity @s[tag=metiers.sk.p4,tag=!metiers.skoff.p4] run advancement grant @s only metiers:p/competence_4
execute if entity @s[tag=metiers.sk.p5,tag=!metiers.skoff.p5] run advancement grant @s only metiers:p/competence_5
execute if entity @s[tag=metiers.sk.p6,tag=!metiers.skoff.p6] run advancement grant @s only metiers:p/competence_6
execute if entity @s[tag=metiers.sk.p7,tag=!metiers.skoff.p7] run advancement grant @s only metiers:p/competence_7
execute if entity @s[tag=metiers.sk.p8,tag=!metiers.skoff.p8] run advancement grant @s only metiers:p/competence_8
execute if entity @s[tag=metiers.sk.p9,tag=!metiers.skoff.p9] run advancement grant @s only metiers:p/competence_9
execute if entity @s[tag=metiers.sk.p10,tag=!metiers.skoff.p10] run advancement grant @s only metiers:p/competence_10
execute if entity @s[tag=metiers.sk.p11,tag=!metiers.skoff.p11] run advancement grant @s only metiers:p/competence_11
execute if entity @s[tag=metiers.sk.p12,tag=!metiers.skoff.p12] run advancement grant @s only metiers:p/competence_12
execute if entity @s[tag=metiers.sk.p13,tag=!metiers.skoff.p13] run advancement grant @s only metiers:p/competence_13
execute if entity @s[tag=metiers.sk.p14,tag=!metiers.skoff.p14] run advancement grant @s only metiers:p/competence_14
execute if entity @s[tag=metiers.sk.p15,tag=!metiers.skoff.p15] run advancement grant @s only metiers:p/competence_15
execute if entity @s[tag=metiers.sk.p16,tag=!metiers.skoff.p16] run advancement grant @s only metiers:p/competence_16
execute if entity @s[tag=metiers.sk.p17,tag=!metiers.skoff.p17] run advancement grant @s only metiers:p/competence_17
execute if entity @s[tag=metiers.sk.p18,tag=!metiers.skoff.p18] run advancement grant @s only metiers:p/competence_18
execute if score @s m.p_lvl matches 10.. run advancement grant @s only metiers:p/niveau_10
execute if score @s m.p_lvl matches 20.. run advancement grant @s only metiers:p/niveau_20
execute if score @s m.p_lvl matches 30.. run advancement grant @s only metiers:p/niveau_30
execute if score @s m.p_lvl matches 40.. run advancement grant @s only metiers:p/niveau_40
execute if score @s m.p_lvl matches 50.. run advancement grant @s only metiers:p/niveau_50
execute if score @s m.p_lvl matches 60.. run advancement grant @s only metiers:p/niveau_60
execute if score @s m.p_lvl matches 70.. run advancement grant @s only metiers:p/niveau_70
execute if score @s m.p_lvl matches 80.. run advancement grant @s only metiers:p/niveau_80
execute if score @s m.p_lvl matches 90.. run advancement grant @s only metiers:p/niveau_90
execute if score @s m.p_lvl matches 100.. run advancement grant @s only metiers:p/niveau_100
execute if entity @s[tag=metiers.sk.e1,tag=!metiers.skoff.e1] run advancement grant @s only metiers:e/competence_1
execute if entity @s[tag=metiers.sk.e2,tag=!metiers.skoff.e2] run advancement grant @s only metiers:e/competence_2
execute if entity @s[tag=metiers.sk.e3,tag=!metiers.skoff.e3] run advancement grant @s only metiers:e/competence_3
execute if entity @s[tag=metiers.sk.e4,tag=!metiers.skoff.e4] run advancement grant @s only metiers:e/competence_4
execute if entity @s[tag=metiers.sk.e5,tag=!metiers.skoff.e5] run advancement grant @s only metiers:e/competence_5
execute if entity @s[tag=metiers.sk.e6,tag=!metiers.skoff.e6] run advancement grant @s only metiers:e/competence_6
execute if entity @s[tag=metiers.sk.e7,tag=!metiers.skoff.e7] run advancement grant @s only metiers:e/competence_7
execute if entity @s[tag=metiers.sk.e8,tag=!metiers.skoff.e8] run advancement grant @s only metiers:e/competence_8
execute if entity @s[tag=metiers.sk.e9,tag=!metiers.skoff.e9] run advancement grant @s only metiers:e/competence_9
execute if entity @s[tag=metiers.sk.e10,tag=!metiers.skoff.e10] run advancement grant @s only metiers:e/competence_10
execute if entity @s[tag=metiers.sk.e11,tag=!metiers.skoff.e11] run advancement grant @s only metiers:e/competence_11
execute if entity @s[tag=metiers.sk.e12,tag=!metiers.skoff.e12] run advancement grant @s only metiers:e/competence_12
execute if entity @s[tag=metiers.sk.e13,tag=!metiers.skoff.e13] run advancement grant @s only metiers:e/competence_13
execute if entity @s[tag=metiers.sk.e14,tag=!metiers.skoff.e14] run advancement grant @s only metiers:e/competence_14
execute if entity @s[tag=metiers.sk.e15,tag=!metiers.skoff.e15] run advancement grant @s only metiers:e/competence_15
execute if entity @s[tag=metiers.sk.e16,tag=!metiers.skoff.e16] run advancement grant @s only metiers:e/competence_16
execute if entity @s[tag=metiers.sk.e17,tag=!metiers.skoff.e17] run advancement grant @s only metiers:e/competence_17
execute if entity @s[tag=metiers.sk.e18,tag=!metiers.skoff.e18] run advancement grant @s only metiers:e/competence_18
execute if score @s m.e_lvl matches 10.. run advancement grant @s only metiers:e/niveau_10
execute if score @s m.e_lvl matches 20.. run advancement grant @s only metiers:e/niveau_20
execute if score @s m.e_lvl matches 30.. run advancement grant @s only metiers:e/niveau_30
execute if score @s m.e_lvl matches 40.. run advancement grant @s only metiers:e/niveau_40
execute if score @s m.e_lvl matches 50.. run advancement grant @s only metiers:e/niveau_50
execute if score @s m.e_lvl matches 60.. run advancement grant @s only metiers:e/niveau_60
execute if score @s m.e_lvl matches 70.. run advancement grant @s only metiers:e/niveau_70
execute if score @s m.e_lvl matches 80.. run advancement grant @s only metiers:e/niveau_80
execute if score @s m.e_lvl matches 90.. run advancement grant @s only metiers:e/niveau_90
execute if score @s m.e_lvl matches 100.. run advancement grant @s only metiers:e/niveau_100
execute if entity @s[tag=metiers.sk.n1,tag=!metiers.skoff.n1] run advancement grant @s only metiers:n/competence_1
execute if entity @s[tag=metiers.sk.n2,tag=!metiers.skoff.n2] run advancement grant @s only metiers:n/competence_2
execute if entity @s[tag=metiers.sk.n3,tag=!metiers.skoff.n3] run advancement grant @s only metiers:n/competence_3
execute if entity @s[tag=metiers.sk.n4,tag=!metiers.skoff.n4] run advancement grant @s only metiers:n/competence_4
execute if entity @s[tag=metiers.sk.n5,tag=!metiers.skoff.n5] run advancement grant @s only metiers:n/competence_5
execute if entity @s[tag=metiers.sk.n6,tag=!metiers.skoff.n6] run advancement grant @s only metiers:n/competence_6
execute if entity @s[tag=metiers.sk.n7,tag=!metiers.skoff.n7] run advancement grant @s only metiers:n/competence_7
execute if entity @s[tag=metiers.sk.n8,tag=!metiers.skoff.n8] run advancement grant @s only metiers:n/competence_8
execute if entity @s[tag=metiers.sk.n9,tag=!metiers.skoff.n9] run advancement grant @s only metiers:n/competence_9
execute if entity @s[tag=metiers.sk.n10,tag=!metiers.skoff.n10] run advancement grant @s only metiers:n/competence_10
execute if entity @s[tag=metiers.sk.n11,tag=!metiers.skoff.n11] run advancement grant @s only metiers:n/competence_11
execute if entity @s[tag=metiers.sk.n12,tag=!metiers.skoff.n12] run advancement grant @s only metiers:n/competence_12
execute if entity @s[tag=metiers.sk.n13,tag=!metiers.skoff.n13] run advancement grant @s only metiers:n/competence_13
execute if entity @s[tag=metiers.sk.n14,tag=!metiers.skoff.n14] run advancement grant @s only metiers:n/competence_14
execute if entity @s[tag=metiers.sk.n15,tag=!metiers.skoff.n15] run advancement grant @s only metiers:n/competence_15
execute if entity @s[tag=metiers.sk.n16,tag=!metiers.skoff.n16] run advancement grant @s only metiers:n/competence_16
execute if entity @s[tag=metiers.sk.n17,tag=!metiers.skoff.n17] run advancement grant @s only metiers:n/competence_17
execute if entity @s[tag=metiers.sk.n18,tag=!metiers.skoff.n18] run advancement grant @s only metiers:n/competence_18
execute if score @s m.n_lvl matches 10.. run advancement grant @s only metiers:n/niveau_10
execute if score @s m.n_lvl matches 20.. run advancement grant @s only metiers:n/niveau_20
execute if score @s m.n_lvl matches 30.. run advancement grant @s only metiers:n/niveau_30
execute if score @s m.n_lvl matches 40.. run advancement grant @s only metiers:n/niveau_40
execute if score @s m.n_lvl matches 50.. run advancement grant @s only metiers:n/niveau_50
execute if score @s m.n_lvl matches 60.. run advancement grant @s only metiers:n/niveau_60
execute if score @s m.n_lvl matches 70.. run advancement grant @s only metiers:n/niveau_70
execute if score @s m.n_lvl matches 80.. run advancement grant @s only metiers:n/niveau_80
execute if score @s m.n_lvl matches 90.. run advancement grant @s only metiers:n/niveau_90
execute if score @s m.n_lvl matches 100.. run advancement grant @s only metiers:n/niveau_100
execute if entity @s[tag=metiers.sk.x1,tag=!metiers.skoff.x1] run advancement grant @s only metiers:x/competence_1
execute if entity @s[tag=metiers.sk.x2,tag=!metiers.skoff.x2] run advancement grant @s only metiers:x/competence_2
execute if entity @s[tag=metiers.sk.x3,tag=!metiers.skoff.x3] run advancement grant @s only metiers:x/competence_3
execute if entity @s[tag=metiers.sk.x4,tag=!metiers.skoff.x4] run advancement grant @s only metiers:x/competence_4
execute if entity @s[tag=metiers.sk.x5,tag=!metiers.skoff.x5] run advancement grant @s only metiers:x/competence_5
execute if entity @s[tag=metiers.sk.x6,tag=!metiers.skoff.x6] run advancement grant @s only metiers:x/competence_6
execute if entity @s[tag=metiers.sk.x7,tag=!metiers.skoff.x7] run advancement grant @s only metiers:x/competence_7
execute if entity @s[tag=metiers.sk.x8,tag=!metiers.skoff.x8] run advancement grant @s only metiers:x/competence_8
execute if entity @s[tag=metiers.sk.x9,tag=!metiers.skoff.x9] run advancement grant @s only metiers:x/competence_9
execute if entity @s[tag=metiers.sk.x10,tag=!metiers.skoff.x10] run advancement grant @s only metiers:x/competence_10
execute if entity @s[tag=metiers.sk.x11,tag=!metiers.skoff.x11] run advancement grant @s only metiers:x/competence_11
execute if entity @s[tag=metiers.sk.x12,tag=!metiers.skoff.x12] run advancement grant @s only metiers:x/competence_12
execute if entity @s[tag=metiers.sk.x13,tag=!metiers.skoff.x13] run advancement grant @s only metiers:x/competence_13
execute if entity @s[tag=metiers.sk.x14,tag=!metiers.skoff.x14] run advancement grant @s only metiers:x/competence_14
execute if entity @s[tag=metiers.sk.x15,tag=!metiers.skoff.x15] run advancement grant @s only metiers:x/competence_15
execute if entity @s[tag=metiers.sk.x16,tag=!metiers.skoff.x16] run advancement grant @s only metiers:x/competence_16
execute if entity @s[tag=metiers.sk.x17,tag=!metiers.skoff.x17] run advancement grant @s only metiers:x/competence_17
execute if entity @s[tag=metiers.sk.x18,tag=!metiers.skoff.x18] run advancement grant @s only metiers:x/competence_18
execute if score @s m.x_lvl matches 10.. run advancement grant @s only metiers:x/niveau_10
execute if score @s m.x_lvl matches 20.. run advancement grant @s only metiers:x/niveau_20
execute if score @s m.x_lvl matches 30.. run advancement grant @s only metiers:x/niveau_30
execute if score @s m.x_lvl matches 40.. run advancement grant @s only metiers:x/niveau_40
execute if score @s m.x_lvl matches 50.. run advancement grant @s only metiers:x/niveau_50
execute if score @s m.x_lvl matches 60.. run advancement grant @s only metiers:x/niveau_60
execute if score @s m.x_lvl matches 70.. run advancement grant @s only metiers:x/niveau_70
execute if score @s m.x_lvl matches 80.. run advancement grant @s only metiers:x/niveau_80
execute if score @s m.x_lvl matches 90.. run advancement grant @s only metiers:x/niveau_90
execute if score @s m.x_lvl matches 100.. run advancement grant @s only metiers:x/niveau_100
execute if entity @s[tag=metiers.sk.t1,tag=!metiers.skoff.t1] run advancement grant @s only metiers:t/competence_1
execute if entity @s[tag=metiers.sk.t2,tag=!metiers.skoff.t2] run advancement grant @s only metiers:t/competence_2
execute if entity @s[tag=metiers.sk.t3,tag=!metiers.skoff.t3] run advancement grant @s only metiers:t/competence_3
execute if entity @s[tag=metiers.sk.t4,tag=!metiers.skoff.t4] run advancement grant @s only metiers:t/competence_4
execute if entity @s[tag=metiers.sk.t5,tag=!metiers.skoff.t5] run advancement grant @s only metiers:t/competence_5
execute if entity @s[tag=metiers.sk.t6,tag=!metiers.skoff.t6] run advancement grant @s only metiers:t/competence_6
execute if entity @s[tag=metiers.sk.t7,tag=!metiers.skoff.t7] run advancement grant @s only metiers:t/competence_7
execute if entity @s[tag=metiers.sk.t8,tag=!metiers.skoff.t8] run advancement grant @s only metiers:t/competence_8
execute if entity @s[tag=metiers.sk.t9,tag=!metiers.skoff.t9] run advancement grant @s only metiers:t/competence_9
execute if entity @s[tag=metiers.sk.t10,tag=!metiers.skoff.t10] run advancement grant @s only metiers:t/competence_10
execute if entity @s[tag=metiers.sk.t11,tag=!metiers.skoff.t11] run advancement grant @s only metiers:t/competence_11
execute if entity @s[tag=metiers.sk.t12,tag=!metiers.skoff.t12] run advancement grant @s only metiers:t/competence_12
execute if entity @s[tag=metiers.sk.t13,tag=!metiers.skoff.t13] run advancement grant @s only metiers:t/competence_13
execute if entity @s[tag=metiers.sk.t14,tag=!metiers.skoff.t14] run advancement grant @s only metiers:t/competence_14
execute if entity @s[tag=metiers.sk.t15,tag=!metiers.skoff.t15] run advancement grant @s only metiers:t/competence_15
execute if entity @s[tag=metiers.sk.t16,tag=!metiers.skoff.t16] run advancement grant @s only metiers:t/competence_16
execute if entity @s[tag=metiers.sk.t17,tag=!metiers.skoff.t17] run advancement grant @s only metiers:t/competence_17
execute if entity @s[tag=metiers.sk.t18,tag=!metiers.skoff.t18] run advancement grant @s only metiers:t/competence_18
execute if score @s m.t_lvl matches 10.. run advancement grant @s only metiers:t/niveau_10
execute if score @s m.t_lvl matches 20.. run advancement grant @s only metiers:t/niveau_20
execute if score @s m.t_lvl matches 30.. run advancement grant @s only metiers:t/niveau_30
execute if score @s m.t_lvl matches 40.. run advancement grant @s only metiers:t/niveau_40
execute if score @s m.t_lvl matches 50.. run advancement grant @s only metiers:t/niveau_50
execute if score @s m.t_lvl matches 60.. run advancement grant @s only metiers:t/niveau_60
execute if score @s m.t_lvl matches 70.. run advancement grant @s only metiers:t/niveau_70
execute if score @s m.t_lvl matches 80.. run advancement grant @s only metiers:t/niveau_80
execute if score @s m.t_lvl matches 90.. run advancement grant @s only metiers:t/niveau_90
execute if score @s m.t_lvl matches 100.. run advancement grant @s only metiers:t/niveau_100
execute if entity @s[tag=metiers.sk.k1,tag=!metiers.skoff.k1] run advancement grant @s only metiers:k/competence_1
execute if entity @s[tag=metiers.sk.k2,tag=!metiers.skoff.k2] run advancement grant @s only metiers:k/competence_2
execute if entity @s[tag=metiers.sk.k3,tag=!metiers.skoff.k3] run advancement grant @s only metiers:k/competence_3
execute if entity @s[tag=metiers.sk.k4,tag=!metiers.skoff.k4] run advancement grant @s only metiers:k/competence_4
execute if entity @s[tag=metiers.sk.k5,tag=!metiers.skoff.k5] run advancement grant @s only metiers:k/competence_5
execute if entity @s[tag=metiers.sk.k6,tag=!metiers.skoff.k6] run advancement grant @s only metiers:k/competence_6
execute if score @s m.k_lvl matches 10.. run advancement grant @s only metiers:k/niveau_10
execute if score @s m.k_lvl matches 20.. run advancement grant @s only metiers:k/niveau_20
execute if score @s m.k_lvl matches 30.. run advancement grant @s only metiers:k/niveau_30
execute if score @s m.k_lvl matches 40.. run advancement grant @s only metiers:k/niveau_40
execute if score @s m.k_lvl matches 50.. run advancement grant @s only metiers:k/niveau_50
execute if score @s m.k_lvl matches 60.. run advancement grant @s only metiers:k/niveau_60
execute if score @s m.k_lvl matches 70.. run advancement grant @s only metiers:k/niveau_70
execute if score @s m.k_lvl matches 80.. run advancement grant @s only metiers:k/niveau_80
execute if score @s m.k_lvl matches 90.. run advancement grant @s only metiers:k/niveau_90
execute if score @s m.k_lvl matches 100.. run advancement grant @s only metiers:k/niveau_100
