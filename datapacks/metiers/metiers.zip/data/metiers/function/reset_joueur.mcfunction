tag @s remove metiers.ok
tag @s remove metiers.v2
tag @s remove metiers.v3
team leave @s
advancement revoke @s from metiers:b/racine
advancement revoke @s from metiers:f/racine
advancement revoke @s from metiers:m/racine
advancement revoke @s from metiers:c/racine
advancement revoke @s from metiers:p/racine
scoreboard players set @s m.pref 0
tag @s remove metiers.sk.b1
tag @s remove metiers.sk.b2
tag @s remove metiers.sk.b3
tag @s remove metiers.sk.b4
tag @s remove metiers.sk.b5
tag @s remove metiers.sk.b6
tag @s remove metiers.sk.b7
tag @s remove metiers.sk.b8
tag @s remove metiers.sk.b9
tag @s remove metiers.sk.b10
tag @s remove metiers.sk.b11
tag @s remove metiers.sk.b12
tag @s remove metiers.sk.b13
tag @s remove metiers.sk.b14
tag @s remove metiers.sk.b15
tag @s remove metiers.sk.b16
tag @s remove metiers.sk.b17
tag @s remove metiers.sk.b18
tag @s remove metiers.sk.f1
tag @s remove metiers.sk.f2
tag @s remove metiers.sk.f3
tag @s remove metiers.sk.f4
tag @s remove metiers.sk.f5
tag @s remove metiers.sk.f6
tag @s remove metiers.sk.f7
tag @s remove metiers.sk.f8
tag @s remove metiers.sk.f9
tag @s remove metiers.sk.f10
tag @s remove metiers.sk.f11
tag @s remove metiers.sk.f12
tag @s remove metiers.sk.f13
tag @s remove metiers.sk.f14
tag @s remove metiers.sk.f15
tag @s remove metiers.sk.f16
tag @s remove metiers.sk.f17
tag @s remove metiers.sk.f18
tag @s remove metiers.sk.m1
tag @s remove metiers.sk.m2
tag @s remove metiers.sk.m3
tag @s remove metiers.sk.m4
tag @s remove metiers.sk.m5
tag @s remove metiers.sk.m6
tag @s remove metiers.sk.m7
tag @s remove metiers.sk.m8
tag @s remove metiers.sk.m9
tag @s remove metiers.sk.m10
tag @s remove metiers.sk.m11
tag @s remove metiers.sk.m12
tag @s remove metiers.sk.m13
tag @s remove metiers.sk.m14
tag @s remove metiers.sk.m15
tag @s remove metiers.sk.m16
tag @s remove metiers.sk.m17
tag @s remove metiers.sk.m18
tag @s remove metiers.sk.c1
tag @s remove metiers.sk.c2
tag @s remove metiers.sk.c3
tag @s remove metiers.sk.c4
tag @s remove metiers.sk.c5
tag @s remove metiers.sk.c6
tag @s remove metiers.sk.c7
tag @s remove metiers.sk.c8
tag @s remove metiers.sk.c9
tag @s remove metiers.sk.c10
tag @s remove metiers.sk.c11
tag @s remove metiers.sk.c12
tag @s remove metiers.sk.c13
tag @s remove metiers.sk.c14
tag @s remove metiers.sk.c15
tag @s remove metiers.sk.c16
tag @s remove metiers.sk.c17
tag @s remove metiers.sk.c18
tag @s remove metiers.sk.p1
tag @s remove metiers.sk.p2
tag @s remove metiers.sk.p3
tag @s remove metiers.sk.p4
tag @s remove metiers.sk.p5
tag @s remove metiers.sk.p6
tag @s remove metiers.sk.p7
tag @s remove metiers.sk.p8
tag @s remove metiers.sk.p9
tag @s remove metiers.sk.p10
tag @s remove metiers.sk.p11
tag @s remove metiers.sk.p12
tag @s remove metiers.sk.p13
tag @s remove metiers.sk.p14
tag @s remove metiers.sk.p15
tag @s remove metiers.sk.p16
tag @s remove metiers.sk.p17
tag @s remove metiers.sk.p18
tag @s remove metiers.sk.e1
tag @s remove metiers.sk.e2
tag @s remove metiers.sk.e3
tag @s remove metiers.sk.e4
tag @s remove metiers.sk.e5
tag @s remove metiers.sk.e6
tag @s remove metiers.sk.e7
tag @s remove metiers.sk.e8
tag @s remove metiers.sk.e9
tag @s remove metiers.sk.e10
tag @s remove metiers.sk.e11
tag @s remove metiers.sk.e12
tag @s remove metiers.sk.e13
tag @s remove metiers.sk.e14
tag @s remove metiers.sk.e15
tag @s remove metiers.sk.e16
tag @s remove metiers.sk.e17
tag @s remove metiers.sk.e18
tag @s remove metiers.sk.n1
tag @s remove metiers.sk.n2
tag @s remove metiers.sk.n3
tag @s remove metiers.sk.n4
tag @s remove metiers.sk.n5
tag @s remove metiers.sk.n6
tag @s remove metiers.sk.n7
tag @s remove metiers.sk.n8
tag @s remove metiers.sk.n9
tag @s remove metiers.sk.n10
tag @s remove metiers.sk.n11
tag @s remove metiers.sk.n12
tag @s remove metiers.sk.n13
tag @s remove metiers.sk.n14
tag @s remove metiers.sk.n15
tag @s remove metiers.sk.n16
tag @s remove metiers.sk.n17
tag @s remove metiers.sk.n18
tag @s remove metiers.sk.x1
tag @s remove metiers.sk.x2
tag @s remove metiers.sk.x3
tag @s remove metiers.sk.x4
tag @s remove metiers.sk.x5
tag @s remove metiers.sk.x6
tag @s remove metiers.sk.x7
tag @s remove metiers.sk.x8
tag @s remove metiers.sk.x9
tag @s remove metiers.sk.x10
tag @s remove metiers.sk.x11
tag @s remove metiers.sk.x12
tag @s remove metiers.sk.x13
tag @s remove metiers.sk.x14
tag @s remove metiers.sk.x15
tag @s remove metiers.sk.x16
tag @s remove metiers.sk.x17
tag @s remove metiers.sk.x18
tag @s remove metiers.sk.t1
tag @s remove metiers.sk.t2
tag @s remove metiers.sk.t3
tag @s remove metiers.sk.t4
tag @s remove metiers.sk.t5
tag @s remove metiers.sk.t6
tag @s remove metiers.sk.t7
tag @s remove metiers.sk.t8
tag @s remove metiers.sk.t9
tag @s remove metiers.sk.t10
tag @s remove metiers.sk.t11
tag @s remove metiers.sk.t12
tag @s remove metiers.sk.t13
tag @s remove metiers.sk.t14
tag @s remove metiers.sk.t15
tag @s remove metiers.sk.t16
tag @s remove metiers.sk.t17
tag @s remove metiers.sk.t18
tag @s remove metiers.sk.k1
tag @s remove metiers.sk.k2
tag @s remove metiers.sk.k3
tag @s remove metiers.sk.k4
tag @s remove metiers.sk.k5
tag @s remove metiers.sk.k6
scoreboard players set @s m.b_spent 0
scoreboard players set @s m.b_pal 0
scoreboard players set @s m.f_spent 0
scoreboard players set @s m.f_pal 0
scoreboard players set @s m.m_spent 0
scoreboard players set @s m.m_pal 0
scoreboard players set @s m.c_spent 0
scoreboard players set @s m.c_pal 0
scoreboard players set @s m.p_spent 0
scoreboard players set @s m.p_pal 0
scoreboard players set @s m.e_spent 0
scoreboard players set @s m.e_pal 0
scoreboard players set @s m.n_spent 0
scoreboard players set @s m.n_pal 0
scoreboard players set @s m.x_spent 0
scoreboard players set @s m.x_pal 0
scoreboard players set @s m.t_spent 0
scoreboard players set @s m.t_pal 0
scoreboard players set @s m.k_spent 0
scoreboard players set @s m.k_pal 0
function metiers:init
function metiers:migration
