scoreboard players add @s m.arm 0
scoreboard players add @s m.total 0
execute store result storage metiers:arm score int 1 run scoreboard players get @s m.total
data modify storage metiers:arm nom set value "Pas encore débloquée"
data modify storage metiers:arm col set value "gray"
data modify storage metiers:arm next set value "Débloquée à 30 points"
data modify storage metiers:arm model set value "heaume_0"
data modify storage metiers:arm bar set value ""
scoreboard players set #lo m.tmp 0
scoreboard players set #hi m.tmp 30
execute if score @s m.arm matches 1 run data modify storage metiers:arm nom set value "Diamant"
execute if score @s m.arm matches 1 run data modify storage metiers:arm col set value "#33C4CB"
execute if score @s m.arm matches 1 run data modify storage metiers:arm next set value "Prochain palier à 60 points"
execute if score @s m.arm matches 1 run data modify storage metiers:arm model set value "heaume_0"
execute if score @s m.arm matches 1 run scoreboard players set #lo m.tmp 30
execute if score @s m.arm matches 1 run scoreboard players set #hi m.tmp 60
data modify storage metiers:arm t0 set value "0. Diamant"
data modify storage metiers:arm c0 set value "dark_gray"
execute if score @s m.arm matches 2.. run data modify storage metiers:arm t0 set value "✔ Diamant"
execute if score @s m.arm matches 2.. run data modify storage metiers:arm c0 set value "#33C4CB"
execute if score @s m.arm matches 1 run data modify storage metiers:arm t0 set value "★ Diamant"
execute if score @s m.arm matches 1 run data modify storage metiers:arm c0 set value "#33C4CB"
execute if score @s m.arm matches 2 run data modify storage metiers:arm nom set value "Diamant forgé"
execute if score @s m.arm matches 2 run data modify storage metiers:arm col set value "#8CEFED"
execute if score @s m.arm matches 2 run data modify storage metiers:arm next set value "Prochain palier à 100 points"
execute if score @s m.arm matches 2 run data modify storage metiers:arm model set value "heaume_1"
execute if score @s m.arm matches 2 run scoreboard players set #lo m.tmp 60
execute if score @s m.arm matches 2 run scoreboard players set #hi m.tmp 100
data modify storage metiers:arm t1 set value "1. Diamant forgé"
data modify storage metiers:arm c1 set value "dark_gray"
execute if score @s m.arm matches 3.. run data modify storage metiers:arm t1 set value "✔ Diamant forgé"
execute if score @s m.arm matches 3.. run data modify storage metiers:arm c1 set value "#8CEFED"
execute if score @s m.arm matches 2 run data modify storage metiers:arm t1 set value "★ Diamant forgé"
execute if score @s m.arm matches 2 run data modify storage metiers:arm c1 set value "#8CEFED"
execute if score @s m.arm matches 3 run data modify storage metiers:arm nom set value "Netherite"
execute if score @s m.arm matches 3 run data modify storage metiers:arm col set value "#9A8790"
execute if score @s m.arm matches 3 run data modify storage metiers:arm next set value "Prochain palier à 150 points"
execute if score @s m.arm matches 3 run data modify storage metiers:arm model set value "heaume_2"
execute if score @s m.arm matches 3 run scoreboard players set #lo m.tmp 100
execute if score @s m.arm matches 3 run scoreboard players set #hi m.tmp 150
data modify storage metiers:arm t2 set value "2. Netherite"
data modify storage metiers:arm c2 set value "dark_gray"
execute if score @s m.arm matches 4.. run data modify storage metiers:arm t2 set value "✔ Netherite"
execute if score @s m.arm matches 4.. run data modify storage metiers:arm c2 set value "#9A8790"
execute if score @s m.arm matches 3 run data modify storage metiers:arm t2 set value "★ Netherite"
execute if score @s m.arm matches 3 run data modify storage metiers:arm c2 set value "#9A8790"
execute if score @s m.arm matches 4 run data modify storage metiers:arm nom set value "Netherite épineuse"
execute if score @s m.arm matches 4 run data modify storage metiers:arm col set value "#C83A3A"
execute if score @s m.arm matches 4 run data modify storage metiers:arm next set value "Prochain palier à 210 points"
execute if score @s m.arm matches 4 run data modify storage metiers:arm model set value "heaume_3"
execute if score @s m.arm matches 4 run scoreboard players set #lo m.tmp 150
execute if score @s m.arm matches 4 run scoreboard players set #hi m.tmp 210
data modify storage metiers:arm t3 set value "3. Netherite épineuse"
data modify storage metiers:arm c3 set value "dark_gray"
execute if score @s m.arm matches 5.. run data modify storage metiers:arm t3 set value "✔ Netherite épineuse"
execute if score @s m.arm matches 5.. run data modify storage metiers:arm c3 set value "#C83A3A"
execute if score @s m.arm matches 4 run data modify storage metiers:arm t3 set value "★ Netherite épineuse"
execute if score @s m.arm matches 4 run data modify storage metiers:arm c3 set value "#C83A3A"
execute if score @s m.arm matches 5 run data modify storage metiers:arm nom set value "Netherite d'améthyste"
execute if score @s m.arm matches 5 run data modify storage metiers:arm col set value "#B787EC"
execute if score @s m.arm matches 5 run data modify storage metiers:arm next set value "Prochain palier à 280 points"
execute if score @s m.arm matches 5 run data modify storage metiers:arm model set value "heaume_4"
execute if score @s m.arm matches 5 run scoreboard players set #lo m.tmp 210
execute if score @s m.arm matches 5 run scoreboard players set #hi m.tmp 280
data modify storage metiers:arm t4 set value "4. Netherite d'améthyste"
data modify storage metiers:arm c4 set value "dark_gray"
execute if score @s m.arm matches 6.. run data modify storage metiers:arm t4 set value "✔ Netherite d'améthyste"
execute if score @s m.arm matches 6.. run data modify storage metiers:arm c4 set value "#B787EC"
execute if score @s m.arm matches 5 run data modify storage metiers:arm t4 set value "★ Netherite d'améthyste"
execute if score @s m.arm matches 5 run data modify storage metiers:arm c4 set value "#B787EC"
execute if score @s m.arm matches 6 run data modify storage metiers:arm nom set value "Netherite de braise"
execute if score @s m.arm matches 6 run data modify storage metiers:arm col set value "#FF8A2E"
execute if score @s m.arm matches 6 run data modify storage metiers:arm next set value "Prochain palier à 360 points"
execute if score @s m.arm matches 6 run data modify storage metiers:arm model set value "heaume_5"
execute if score @s m.arm matches 6 run scoreboard players set #lo m.tmp 280
execute if score @s m.arm matches 6 run scoreboard players set #hi m.tmp 360
data modify storage metiers:arm t5 set value "5. Netherite de braise"
data modify storage metiers:arm c5 set value "dark_gray"
execute if score @s m.arm matches 7.. run data modify storage metiers:arm t5 set value "✔ Netherite de braise"
execute if score @s m.arm matches 7.. run data modify storage metiers:arm c5 set value "#FF8A2E"
execute if score @s m.arm matches 6 run data modify storage metiers:arm t5 set value "★ Netherite de braise"
execute if score @s m.arm matches 6 run data modify storage metiers:arm c5 set value "#FF8A2E"
execute if score @s m.arm matches 7 run data modify storage metiers:arm nom set value "Netherite rubis"
execute if score @s m.arm matches 7 run data modify storage metiers:arm col set value "#FF3030"
execute if score @s m.arm matches 7 run data modify storage metiers:arm next set value "Prochain palier à 450 points"
execute if score @s m.arm matches 7 run data modify storage metiers:arm model set value "heaume_6"
execute if score @s m.arm matches 7 run scoreboard players set #lo m.tmp 360
execute if score @s m.arm matches 7 run scoreboard players set #hi m.tmp 450
data modify storage metiers:arm t6 set value "6. Netherite rubis"
data modify storage metiers:arm c6 set value "dark_gray"
execute if score @s m.arm matches 8.. run data modify storage metiers:arm t6 set value "✔ Netherite rubis"
execute if score @s m.arm matches 8.. run data modify storage metiers:arm c6 set value "#FF3030"
execute if score @s m.arm matches 7 run data modify storage metiers:arm t6 set value "★ Netherite rubis"
execute if score @s m.arm matches 7 run data modify storage metiers:arm c6 set value "#FF3030"
execute if score @s m.arm matches 8 run data modify storage metiers:arm nom set value "Netherite runique"
execute if score @s m.arm matches 8 run data modify storage metiers:arm col set value "#2FE6FF"
execute if score @s m.arm matches 8 run data modify storage metiers:arm next set value "Prochain palier à 560 points"
execute if score @s m.arm matches 8 run data modify storage metiers:arm model set value "heaume_7"
execute if score @s m.arm matches 8 run scoreboard players set #lo m.tmp 450
execute if score @s m.arm matches 8 run scoreboard players set #hi m.tmp 560
data modify storage metiers:arm t7 set value "7. Netherite runique"
data modify storage metiers:arm c7 set value "dark_gray"
execute if score @s m.arm matches 9.. run data modify storage metiers:arm t7 set value "✔ Netherite runique"
execute if score @s m.arm matches 9.. run data modify storage metiers:arm c7 set value "#2FE6FF"
execute if score @s m.arm matches 8 run data modify storage metiers:arm t7 set value "★ Netherite runique"
execute if score @s m.arm matches 8 run data modify storage metiers:arm c7 set value "#2FE6FF"
execute if score @s m.arm matches 9 run data modify storage metiers:arm nom set value "Netherite du Vide"
execute if score @s m.arm matches 9 run data modify storage metiers:arm col set value "#8A3CFF"
execute if score @s m.arm matches 9 run data modify storage metiers:arm next set value "Prochain palier à 700 points"
execute if score @s m.arm matches 9 run data modify storage metiers:arm model set value "heaume_8"
execute if score @s m.arm matches 9 run scoreboard players set #lo m.tmp 560
execute if score @s m.arm matches 9 run scoreboard players set #hi m.tmp 700
data modify storage metiers:arm t8 set value "8. Netherite du Vide"
data modify storage metiers:arm c8 set value "dark_gray"
execute if score @s m.arm matches 10.. run data modify storage metiers:arm t8 set value "✔ Netherite du Vide"
execute if score @s m.arm matches 10.. run data modify storage metiers:arm c8 set value "#8A3CFF"
execute if score @s m.arm matches 9 run data modify storage metiers:arm t8 set value "★ Netherite du Vide"
execute if score @s m.arm matches 9 run data modify storage metiers:arm c8 set value "#8A3CFF"
execute if score @s m.arm matches 10 run data modify storage metiers:arm nom set value "Mythique"
execute if score @s m.arm matches 10 run data modify storage metiers:arm col set value "#5FF5DC"
execute if score @s m.arm matches 10 run data modify storage metiers:arm next set value "Prochain palier à 850 points"
execute if score @s m.arm matches 10 run data modify storage metiers:arm model set value "heaume_9"
execute if score @s m.arm matches 10 run scoreboard players set #lo m.tmp 700
execute if score @s m.arm matches 10 run scoreboard players set #hi m.tmp 850
data modify storage metiers:arm t9 set value "9. Mythique"
data modify storage metiers:arm c9 set value "dark_gray"
execute if score @s m.arm matches 11.. run data modify storage metiers:arm t9 set value "✔ Mythique"
execute if score @s m.arm matches 11.. run data modify storage metiers:arm c9 set value "#5FF5DC"
execute if score @s m.arm matches 10 run data modify storage metiers:arm t9 set value "★ Mythique"
execute if score @s m.arm matches 10 run data modify storage metiers:arm c9 set value "#5FF5DC"
execute if score @s m.arm matches 11 run data modify storage metiers:arm nom set value "Céleste"
execute if score @s m.arm matches 11 run data modify storage metiers:arm col set value "#FFF4D2"
execute if score @s m.arm matches 11 run data modify storage metiers:arm next set value "Palier maximum atteint"
execute if score @s m.arm matches 11 run data modify storage metiers:arm model set value "heaume_10"
execute if score @s m.arm matches 11 run scoreboard players set #lo m.tmp 850
execute if score @s m.arm matches 11 run scoreboard players set #hi m.tmp 850
data modify storage metiers:arm t10 set value "10. Céleste"
data modify storage metiers:arm c10 set value "dark_gray"
execute if score @s m.arm matches 12.. run data modify storage metiers:arm t10 set value "✔ Céleste"
execute if score @s m.arm matches 12.. run data modify storage metiers:arm c10 set value "#FFF4D2"
execute if score @s m.arm matches 11 run data modify storage metiers:arm t10 set value "★ Céleste"
execute if score @s m.arm matches 11 run data modify storage metiers:arm c10 set value "#FFF4D2"
scoreboard players operation #d m.tmp = #hi m.tmp
scoreboard players operation #d m.tmp -= #lo m.tmp
scoreboard players operation #v m.tmp = @s m.total
scoreboard players operation #v m.tmp -= #lo m.tmp
scoreboard players operation #v m.tmp *= #10 m.const
execute if score #d m.tmp matches 1.. run scoreboard players operation #v m.tmp /= #d m.tmp
execute if score #d m.tmp matches ..0 run scoreboard players set #v m.tmp 10
execute if score #v m.tmp matches 11.. run scoreboard players set #v m.tmp 10
execute if score #v m.tmp matches ..-1 run scoreboard players set #v m.tmp 0
execute if score #v m.tmp matches 0 run data modify storage metiers:arm bar set value ""
execute if score #v m.tmp matches 1 run data modify storage metiers:arm bar set value ""
execute if score #v m.tmp matches 2 run data modify storage metiers:arm bar set value ""
execute if score #v m.tmp matches 3 run data modify storage metiers:arm bar set value ""
execute if score #v m.tmp matches 4 run data modify storage metiers:arm bar set value ""
execute if score #v m.tmp matches 5 run data modify storage metiers:arm bar set value ""
execute if score #v m.tmp matches 6 run data modify storage metiers:arm bar set value ""
execute if score #v m.tmp matches 7 run data modify storage metiers:arm bar set value ""
execute if score #v m.tmp matches 8 run data modify storage metiers:arm bar set value ""
execute if score #v m.tmp matches 9 run data modify storage metiers:arm bar set value ""
execute if score #v m.tmp matches 10 run data modify storage metiers:arm bar set value ""
function metiers:armure/menu_dialog with storage metiers:arm
