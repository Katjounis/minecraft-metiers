tag @s remove metiers.a_head
tag @s remove metiers.a_chest
tag @s remove metiers.a_legs
tag @s remove metiers.a_feet
execute if items entity @s armor.head *[minecraft:custom_data~{metiers_armure:1b}] run tag @s add metiers.a_head
execute if items entity @s armor.chest *[minecraft:custom_data~{metiers_armure:1b}] run tag @s add metiers.a_chest
execute if items entity @s armor.legs *[minecraft:custom_data~{metiers_armure:1b}] run tag @s add metiers.a_legs
execute if items entity @s armor.feet *[minecraft:custom_data~{metiers_armure:1b}] run tag @s add metiers.a_feet
execute if items entity @s armor.head *[minecraft:custom_data~{metiers_armure:1b}] run item replace entity @s armor.head with minecraft:air
execute if items entity @s armor.chest *[minecraft:custom_data~{metiers_armure:1b}] run item replace entity @s armor.chest with minecraft:air
execute if items entity @s armor.legs *[minecraft:custom_data~{metiers_armure:1b}] run item replace entity @s armor.legs with minecraft:air
execute if items entity @s armor.feet *[minecraft:custom_data~{metiers_armure:1b}] run item replace entity @s armor.feet with minecraft:air
clear @s *[minecraft:custom_data~{metiers_armure:1b}]
scoreboard players add @s m.aser 1
execute store result storage metiers:tmp o int 1 run scoreboard players get @s m.id
execute store result storage metiers:tmp s int 1 run scoreboard players get @s m.aser
data modify storage metiers:tmp skin set value ""
data modify storage metiers:tmp askin set value ""
execute if score @s m.skin_a matches 1 run data modify storage metiers:tmp skin set value "givre"
execute if score @s m.skin_a matches 1 run data modify storage metiers:tmp askin set value "_givre"
execute if score @s m.skin_a matches 2 run data modify storage metiers:tmp skin set value "corail"
execute if score @s m.skin_a matches 2 run data modify storage metiers:tmp askin set value "_corail"
execute if score @s m.skin_a matches 3 run data modify storage metiers:tmp skin set value "or_royal"
execute if score @s m.skin_a matches 3 run data modify storage metiers:tmp askin set value "_or_royal"
execute if score @s m.skin_a matches 4 run data modify storage metiers:tmp skin set value "ossements"
execute if score @s m.skin_a matches 4 run data modify storage metiers:tmp askin set value "_ossements"
execute if score @s m.skin_a matches 5 run data modify storage metiers:tmp skin set value "magma"
execute if score @s m.skin_a matches 5 run data modify storage metiers:tmp askin set value "_magma"
execute if score @s m.skin_a matches 6 run data modify storage metiers:tmp skin set value "ombre"
execute if score @s m.skin_a matches 6 run data modify storage metiers:tmp askin set value "_ombre"
execute if score @s m.skin_a matches 7 run data modify storage metiers:tmp skin set value "sakura"
execute if score @s m.skin_a matches 7 run data modify storage metiers:tmp askin set value "_sakura"
execute if score @s m.skin_a matches 8 run data modify storage metiers:tmp skin set value "celeste"
execute if score @s m.skin_a matches 8 run data modify storage metiers:tmp askin set value "_celeste"
execute if score @s m.skin_a matches 9 run data modify storage metiers:tmp skin set value "abysses"
execute if score @s m.skin_a matches 9 run data modify storage metiers:tmp askin set value "_abysses"
execute if score @s m.skin_a matches 10 run data modify storage metiers:tmp skin set value "sculk"
execute if score @s m.skin_a matches 10 run data modify storage metiers:tmp askin set value "_sculk"
execute if score @s m.skin_a matches 11 run data modify storage metiers:tmp skin set value "dragon"
execute if score @s m.skin_a matches 11 run data modify storage metiers:tmp askin set value "_dragon"
execute if score @s m.skin_a matches 12 run data modify storage metiers:tmp skin set value "eclipse"
execute if score @s m.skin_a matches 12 run data modify storage metiers:tmp askin set value "_eclipse"
function metiers:armure/donner_m with storage metiers:tmp
tag @s remove metiers.a_head
tag @s remove metiers.a_chest
tag @s remove metiers.a_legs
tag @s remove metiers.a_feet
playsound minecraft:item.armor.equip_netherite master @s ~ ~ ~ 1 0.8
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 1 0.4 0.3 60
