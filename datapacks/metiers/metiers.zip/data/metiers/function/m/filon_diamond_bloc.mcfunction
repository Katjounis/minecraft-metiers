scoreboard players add #fn m.tmp 1
execute if block ~ ~ ~ minecraft:diamond_ore run scoreboard players add @s m.m_raw 80
execute if block ~ ~ ~ minecraft:deepslate_diamond_ore run scoreboard players add @s m.m_raw 90
loot give @s mine ~ ~ ~ mainhand
setblock ~ ~ ~ minecraft:air
particle minecraft:block{block_state:"minecraft:stone"} ~ ~ ~ 0.3 0.3 0.3 0 4
function metiers:m/filon_diamond_voisins
