scoreboard players operation #L m.tmp = @s m.m_lvl
function metiers:xp/table
scoreboard players operation @s m.m_need = #N m.tmp
scoreboard players operation #N m.tmp = @s m.m_pr
scoreboard players operation #N m.tmp *= #F99 m.const
scoreboard players operation @s m.m_need > #N m.tmp
execute if score @s m.m_lvl matches ..99 if score @s m.m_xp >= @s m.m_need run function metiers:m/levelup
