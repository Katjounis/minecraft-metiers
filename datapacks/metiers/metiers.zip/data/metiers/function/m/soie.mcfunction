scoreboard players add @s m.silk 0
execute if score @s m.silk matches 1 run scoreboard players set #s m.tmp 0
execute unless score @s m.silk matches 1 run scoreboard players set #s m.tmp 1
scoreboard players operation @s m.silk = #s m.tmp
execute if items entity @s container.* *[minecraft:custom_data~{metiers_outil:"m"}] run function metiers:m/outil_donner
execute if items entity @s weapon.offhand *[minecraft:custom_data~{metiers_outil:"m"}] run function metiers:m/outil_donner
execute if score @s m.silk matches 1 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pioche en Toucher de soie.","color":"aqua"}]
execute if score @s m.silk matches 0 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pioche en Fortune.","color":"aqua"}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.6 1.4
function metiers:m/arbre
