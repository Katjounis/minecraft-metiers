scoreboard players add #fn m.tmp 1
execute if block ~ ~ ~ minecraft:coal_ore run scoreboard players add @s m.m_raw 8
execute if block ~ ~ ~ minecraft:deepslate_coal_ore run scoreboard players add @s m.m_raw 10
loot give @s mine ~ ~ ~ mainhand
setblock ~ ~ ~ minecraft:air
particle minecraft:block{block_state:"minecraft:stone"} ~ ~ ~ 0.3 0.3 0.3 0 4
function metiers:m/filon_coal_voisins
