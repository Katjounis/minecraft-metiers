execute if entity @s[tag=metiers.skoff.m14] run return run function metiers:m/activer_14
tag @s add metiers.skoff.m14
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Aimant est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:m/arbre
