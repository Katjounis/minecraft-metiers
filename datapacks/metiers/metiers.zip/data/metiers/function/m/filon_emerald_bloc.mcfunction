scoreboard players add #fn m.tmp 1
execute if block ~ ~ ~ minecraft:emerald_ore run scoreboard players add @s m.m_raw 100
execute if block ~ ~ ~ minecraft:deepslate_emerald_ore run scoreboard players add @s m.m_raw 110
loot give @s mine ~ ~ ~ mainhand
setblock ~ ~ ~ minecraft:air
particle minecraft:block{block_state:"minecraft:stone"} ~ ~ ~ 0.3 0.3 0.3 0 4
function metiers:m/filon_emerald_voisins
