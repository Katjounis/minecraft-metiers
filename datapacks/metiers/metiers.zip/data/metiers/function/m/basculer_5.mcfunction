execute if entity @s[tag=metiers.skoff.m5] run return run function metiers:m/activer_5
tag @s add metiers.skoff.m5
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Fonte automatique est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:m/arbre
