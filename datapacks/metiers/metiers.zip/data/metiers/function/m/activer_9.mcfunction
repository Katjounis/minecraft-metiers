tag @s remove metiers.skoff.m9
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Gemmes est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:m/arbre
