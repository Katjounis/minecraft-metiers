tag @s remove metiers.skoff.m2
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Bras de fer est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:m/arbre
