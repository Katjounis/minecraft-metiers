scoreboard players add #fn m.tmp 1
execute if block ~ ~ ~ minecraft:ancient_debris run scoreboard players add @s m.m_raw 480
loot give @s mine ~ ~ ~ mainhand
setblock ~ ~ ~ minecraft:air
particle minecraft:block{block_state:"minecraft:stone"} ~ ~ ~ 0.3 0.3 0.3 0 4
function metiers:m/filon_ancient_debris_voisins
