tag @s remove metiers.skoff.m4
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Filon chanceux est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:m/arbre
