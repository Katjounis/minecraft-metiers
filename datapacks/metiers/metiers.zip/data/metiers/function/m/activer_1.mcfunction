tag @s remove metiers.skoff.m1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Coup de pioche est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:m/arbre
