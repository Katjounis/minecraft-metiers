execute if score @s m.pref matches 3 run scoreboard players set @s m.trig 10
execute unless score @s m.pref matches 3 run scoreboard players set @s m.trig 13
function metiers:prefixe/choisir
scoreboard players set #vue m.tmp 2
function metiers:m/arbre
