execute if entity @s[tag=metiers.sk.m3] run return run function metiers:m/basculer_3
execute unless score @s m.m_lvl matches 20.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 20 en Mineur.","color":"red"}]
execute unless score @s m.m_lvl matches 20.. run return run function metiers:m/arbre
function metiers:m/points
execute unless entity @s[tag=metiers.sk.m1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Coup de pioche.","color":"red"}]
execute unless entity @s[tag=metiers.sk.m1] run return run function metiers:m/arbre
execute if score @s m.tmp matches ..11 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (12 requis).","color":"red"}]
execute if score @s m.tmp matches ..11 run return run function metiers:m/arbre
scoreboard players add @s m.m_spent 12
tag @s add metiers.sk.m3
advancement grant @s only metiers:m/competence_3
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Nyctalope","color":"gray","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:m/arbre
