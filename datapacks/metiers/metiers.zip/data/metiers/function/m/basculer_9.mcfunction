execute if entity @s[tag=metiers.skoff.m9] run return run function metiers:m/activer_9
tag @s add metiers.skoff.m9
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Gemmes est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:m/arbre
