tag @s remove metiers.skoff.m16
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pioche large est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:m/arbre
