execute if entity @s[tag=metiers.skoff.m18] run return run function metiers:m/activer_18
tag @s add metiers.skoff.m18
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Stature de pierre est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:m/arbre
