scoreboard players operation #fgo m.tmp = @s m.fk
tag @s add metiers.fgo
scoreboard players set @s m.fk 0
