scoreboard players operation @s m.tmp = @s m.m_lvl
scoreboard players remove @s m.tmp 1
scoreboard players operation @s m.tmp -= @s m.m_spent
scoreboard players operation #ppr m.tmp = @s m.m_pr
scoreboard players operation #ppr m.tmp *= #99 m.const
scoreboard players operation @s m.tmp += #ppr m.tmp
