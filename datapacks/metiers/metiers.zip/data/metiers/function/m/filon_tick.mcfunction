scoreboard players operation #pid m.tmp = @s m.id
scoreboard players set #fgo m.tmp 0
execute as @e[type=minecraft:marker,tag=metiers.fvise] if score @s m.own = #pid m.tmp if score @s m.fk matches 1.. at @s if block ~ ~ ~ #metiers:vide run function metiers:m/filon_casse
execute if score #fgo m.tmp matches 1.. at @e[type=minecraft:marker,tag=metiers.fgo,limit=1] run function metiers:m/filon_depart
tag @e[type=minecraft:marker,tag=metiers.fgo] remove metiers.fgo
execute as @e[type=minecraft:marker,tag=metiers.fvise,distance=16..] if score @s m.own = #pid m.tmp run kill @s
scoreboard players set #fm m.tmp 0
execute as @e[type=minecraft:marker,tag=metiers.fvise] if score @s m.own = #pid m.tmp run scoreboard players set #fm m.tmp 1
execute if score #fm m.tmp matches 0 run summon minecraft:marker ~ ~ ~ {Tags:["metiers.fvise","metiers.fnew"]}
scoreboard players operation @e[type=minecraft:marker,tag=metiers.fnew] m.own = #pid m.tmp
tag @e[type=minecraft:marker,tag=metiers.fnew] remove metiers.fnew
scoreboard players set #fk m.tmp 0
scoreboard players set #fpas m.tmp 0
execute anchored eyes positioned ^ ^ ^ run function metiers:m/filon_rayon
execute as @e[type=minecraft:marker,tag=metiers.fvise] if score @s m.own = #pid m.tmp run scoreboard players operation @s m.fk = #fk m.tmp
