execute if entity @s[tag=metiers.skoff.m4] run return run function metiers:m/activer_4
tag @s add metiers.skoff.m4
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Filon chanceux est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:m/arbre
