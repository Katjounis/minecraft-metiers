execute if entity @s[tag=metiers.sk.m2] run return run function metiers:m/basculer_2
execute unless score @s m.m_lvl matches 20.. unless score @s m.m_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 20 en Mineur.","color":"red"}]
execute unless score @s m.m_lvl matches 20.. unless score @s m.m_pr matches 1.. run return run function metiers:m/arbre
function metiers:m/points
execute unless entity @s[tag=metiers.sk.m1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Coup de pioche.","color":"red"}]
execute unless entity @s[tag=metiers.sk.m1] run return run function metiers:m/arbre
execute if score @s m.tmp matches ..3 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (4 requis).","color":"red"}]
execute if score @s m.tmp matches ..3 run return run function metiers:m/arbre
scoreboard players add @s m.m_spent 4
tag @s add metiers.sk.m2
advancement grant @s only metiers:m/competence_2
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Bras de fer","color":"gray","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:m/arbre
