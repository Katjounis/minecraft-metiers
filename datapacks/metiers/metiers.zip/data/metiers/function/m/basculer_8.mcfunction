execute if entity @s[tag=metiers.skoff.m8] run return run function metiers:m/activer_8
tag @s add metiers.skoff.m8
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Fortune bonus est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:m/arbre
