execute if entity @s[tag=metiers.sk.m12] run return run function metiers:m/basculer_12
execute unless score @s m.m_lvl matches 80.. unless score @s m.m_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 80 en Mineur.","color":"red"}]
execute unless score @s m.m_lvl matches 80.. unless score @s m.m_pr matches 1.. run return run function metiers:m/arbre
function metiers:m/points
execute unless entity @s[tag=metiers.sk.m11] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Diamant brut.","color":"red"}]
execute unless entity @s[tag=metiers.sk.m11] run return run function metiers:m/arbre
execute if score @s m.tmp matches ..13 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (14 requis).","color":"red"}]
execute if score @s m.tmp matches ..13 run return run function metiers:m/arbre
scoreboard players add @s m.m_spent 14
tag @s add metiers.sk.m12
advancement grant @s only metiers:m/competence_12
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Cœur de diamant","color":"gray","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:m/arbre
