execute if entity @s[tag=metiers.skoff.m13] run return run function metiers:m/activer_13
tag @s add metiers.skoff.m13
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Allumeur est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:m/arbre
