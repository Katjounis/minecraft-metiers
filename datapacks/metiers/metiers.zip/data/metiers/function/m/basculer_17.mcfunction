execute if entity @s[tag=metiers.skoff.m17] run return run function metiers:m/activer_17
tag @s add metiers.skoff.m17
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Lave apprivoisée est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:m/arbre
