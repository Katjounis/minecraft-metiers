execute unless block ~ ~ ~ #metiers:vide run return run function metiers:m/filon_viser
scoreboard players add #fpas m.tmp 1
execute if score #fpas m.tmp matches ..55 positioned ^ ^ ^0.1 run function metiers:m/filon_rayon
