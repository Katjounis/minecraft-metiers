tag @s remove metiers.skoff.m13
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Allumeur est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:m/arbre
