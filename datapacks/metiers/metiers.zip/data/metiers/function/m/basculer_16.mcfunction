execute if entity @s[tag=metiers.skoff.m16] run return run function metiers:m/activer_16
tag @s add metiers.skoff.m16
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pied de montagne est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:m/arbre
