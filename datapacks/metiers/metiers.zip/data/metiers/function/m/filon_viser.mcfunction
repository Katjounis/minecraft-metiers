execute if block ~ ~ ~ #metiers:filon_coal run scoreboard players set #fk m.tmp 1
execute if block ~ ~ ~ #metiers:filon_copper run scoreboard players set #fk m.tmp 2
execute if block ~ ~ ~ #metiers:filon_iron run scoreboard players set #fk m.tmp 3
execute if block ~ ~ ~ #metiers:filon_gold run scoreboard players set #fk m.tmp 4
execute if block ~ ~ ~ #metiers:filon_redstone run scoreboard players set #fk m.tmp 5
execute if block ~ ~ ~ #metiers:filon_lapis run scoreboard players set #fk m.tmp 6
execute if block ~ ~ ~ #metiers:filon_diamond run scoreboard players set #fk m.tmp 7
execute if block ~ ~ ~ #metiers:filon_emerald run scoreboard players set #fk m.tmp 8
execute if block ~ ~ ~ #metiers:filon_nether_gold run scoreboard players set #fk m.tmp 9
execute if block ~ ~ ~ #metiers:filon_nether_quartz run scoreboard players set #fk m.tmp 10
execute if block ~ ~ ~ #metiers:filon_ancient_debris run scoreboard players set #fk m.tmp 11
execute if score #fk m.tmp matches 1.. align xyz positioned ~0.5 ~0.5 ~0.5 as @e[type=minecraft:marker,tag=metiers.fvise] if score @s m.own = #pid m.tmp run tp @s ~ ~ ~
