execute if entity @s[tag=metiers.skoff.m6] run return run function metiers:m/activer_6
tag @s add metiers.skoff.m6
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cœur de la montagne est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:m/arbre
