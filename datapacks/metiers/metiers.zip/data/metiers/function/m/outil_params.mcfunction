scoreboard players add @s m.ceff_m 0
scoreboard players add @s m.cfor_m 0
scoreboard players add @s m.skin_m 0
execute if score @s m.m_out matches 0 run scoreboard players set #be m.tmp 2
execute if score @s m.m_out matches 0 run scoreboard players set #bf m.tmp 0
execute if score @s m.m_out matches 1 run scoreboard players set #be m.tmp 3
execute if score @s m.m_out matches 1 run scoreboard players set #bf m.tmp 1
execute if score @s m.m_out matches 2 run scoreboard players set #be m.tmp 4
execute if score @s m.m_out matches 2 run scoreboard players set #bf m.tmp 2
execute if score @s m.m_out matches 3 run scoreboard players set #be m.tmp 4
execute if score @s m.m_out matches 3 run scoreboard players set #bf m.tmp 2
execute if score @s m.m_out matches 4 run scoreboard players set #be m.tmp 4
execute if score @s m.m_out matches 4 run scoreboard players set #bf m.tmp 3
execute if score @s m.m_out matches 5 run scoreboard players set #be m.tmp 5
execute if score @s m.m_out matches 5 run scoreboard players set #bf m.tmp 3
execute if score @s m.m_out matches 6 run scoreboard players set #be m.tmp 5
execute if score @s m.m_out matches 6 run scoreboard players set #bf m.tmp 3
execute if score @s m.m_out matches 7 run scoreboard players set #be m.tmp 5
execute if score @s m.m_out matches 7 run scoreboard players set #bf m.tmp 4
execute if score @s m.m_out matches 8 run scoreboard players set #be m.tmp 5
execute if score @s m.m_out matches 8 run scoreboard players set #bf m.tmp 4
execute if score @s m.m_out matches 9 run scoreboard players set #be m.tmp 5
execute if score @s m.m_out matches 9 run scoreboard players set #bf m.tmp 4
execute if score @s m.m_out matches 10 run scoreboard players set #be m.tmp 5
execute if score @s m.m_out matches 10 run scoreboard players set #bf m.tmp 5
scoreboard players operation #be m.tmp > @s m.ceff_m
scoreboard players operation #bf m.tmp += @s m.cfor_m
execute store result storage metiers:tmp eff int 1 run scoreboard players get #be m.tmp
execute store result storage metiers:tmp fort int 1 run scoreboard players get #bf m.tmp
data modify storage metiers:tmp skin set value ""
data modify storage metiers:tmp fk set value "fortune"
scoreboard players add @s m.silk 0
execute if score @s m.silk matches 1 run data modify storage metiers:tmp fk set value "silk_touch"
execute if score @s m.silk matches 1 run data modify storage metiers:tmp fort set value 1
execute if score @s m.skin_m matches 1 run data modify storage metiers:tmp skin set value "givre"
execute if score @s m.skin_m matches 2 run data modify storage metiers:tmp skin set value "corail"
execute if score @s m.skin_m matches 3 run data modify storage metiers:tmp skin set value "or_royal"
execute if score @s m.skin_m matches 4 run data modify storage metiers:tmp skin set value "ossements"
execute if score @s m.skin_m matches 5 run data modify storage metiers:tmp skin set value "magma"
execute if score @s m.skin_m matches 6 run data modify storage metiers:tmp skin set value "ombre"
data modify storage metiers:tmp et set value ""
data modify storage metiers:tmp gl set value "false"
execute if score @s m.m_pr matches 1 run data modify storage metiers:tmp et set value "★ "
execute if score @s m.m_pr matches 1 run data modify storage metiers:tmp gl set value "true"
execute if score @s m.m_pr matches 2 run data modify storage metiers:tmp et set value "★★ "
execute if score @s m.m_pr matches 2 run data modify storage metiers:tmp gl set value "true"
execute if score @s m.m_pr matches 3 run data modify storage metiers:tmp et set value "★★★ "
execute if score @s m.m_pr matches 3 run data modify storage metiers:tmp gl set value "true"
execute if score @s m.m_pr matches 4 run data modify storage metiers:tmp et set value "★★★★ "
execute if score @s m.m_pr matches 4 run data modify storage metiers:tmp gl set value "true"
execute if score @s m.m_pr matches 5 run data modify storage metiers:tmp et set value "★★★★★ "
execute if score @s m.m_pr matches 5 run data modify storage metiers:tmp gl set value "true"
