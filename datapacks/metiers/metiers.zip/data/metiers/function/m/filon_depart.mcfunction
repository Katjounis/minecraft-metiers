scoreboard players set #fn m.tmp 0
scoreboard players set #fmax m.tmp 8
execute if entity @s[tag=metiers.sk.pm3] run scoreboard players set #fmax m.tmp 16
execute if entity @s[tag=metiers.sk.pm5] run scoreboard players set #fmax m.tmp 32
execute if score #fgo m.tmp matches 1 run function metiers:m/filon_coal_voisins
execute if score #fgo m.tmp matches 2 run function metiers:m/filon_copper_voisins
execute if score #fgo m.tmp matches 3 run function metiers:m/filon_iron_voisins
execute if score #fgo m.tmp matches 4 run function metiers:m/filon_gold_voisins
execute if score #fgo m.tmp matches 5 run function metiers:m/filon_redstone_voisins
execute if score #fgo m.tmp matches 6 run function metiers:m/filon_lapis_voisins
execute if score #fgo m.tmp matches 7 run function metiers:m/filon_diamond_voisins
execute if score #fgo m.tmp matches 8 run function metiers:m/filon_emerald_voisins
execute if score #fgo m.tmp matches 9 run function metiers:m/filon_nether_gold_voisins
execute if score #fgo m.tmp matches 10 run function metiers:m/filon_nether_quartz_voisins
execute if score #fgo m.tmp matches 11 run function metiers:m/filon_ancient_debris_voisins
execute if score #fn m.tmp matches 1.. run playsound minecraft:block.deepslate.break master @s ~ ~ ~ 1 0.7
