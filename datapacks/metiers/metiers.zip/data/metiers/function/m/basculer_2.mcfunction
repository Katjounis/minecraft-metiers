execute if entity @s[tag=metiers.skoff.m2] run return run function metiers:m/activer_2
tag @s add metiers.skoff.m2
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Bras de fer est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:m/arbre
