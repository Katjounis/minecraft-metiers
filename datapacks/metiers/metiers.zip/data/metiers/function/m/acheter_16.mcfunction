execute if entity @s[tag=metiers.sk.m16] run return run function metiers:m/basculer_16
execute unless score @s m.m_lvl matches 45.. unless score @s m.m_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 45 en Mineur.","color":"red"}]
execute unless score @s m.m_lvl matches 45.. unless score @s m.m_pr matches 1.. run return run function metiers:m/arbre
function metiers:m/points
execute unless entity @s[tag=metiers.sk.m15] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Lanterne.","color":"red"}]
execute unless entity @s[tag=metiers.sk.m15] run return run function metiers:m/arbre
execute if score @s m.tmp matches ..9 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (10 requis).","color":"red"}]
execute if score @s m.tmp matches ..9 run return run function metiers:m/arbre
scoreboard players add @s m.m_spent 10
tag @s add metiers.sk.m16
advancement grant @s only metiers:m/competence_16
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Pied de montagne","color":"gray","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:m/arbre
