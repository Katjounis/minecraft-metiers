execute if entity @s[tag=metiers.skoff.m7] run return run function metiers:m/activer_7
tag @s add metiers.skoff.m7
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tri automatique est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:m/arbre
