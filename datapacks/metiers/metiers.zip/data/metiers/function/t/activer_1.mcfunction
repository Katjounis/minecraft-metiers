tag @s remove metiers.skoff.t1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pourboire est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:t/arbre
