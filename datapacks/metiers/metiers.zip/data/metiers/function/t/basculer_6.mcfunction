execute if entity @s[tag=metiers.skoff.t6] run return run function metiers:t/activer_6
tag @s add metiers.skoff.t6
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Magnat est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:t/arbre
