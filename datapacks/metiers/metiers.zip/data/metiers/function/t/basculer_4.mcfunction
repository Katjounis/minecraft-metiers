execute if entity @s[tag=metiers.skoff.t4] run return run function metiers:t/activer_4
tag @s add metiers.skoff.t4
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Notable est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:t/arbre
