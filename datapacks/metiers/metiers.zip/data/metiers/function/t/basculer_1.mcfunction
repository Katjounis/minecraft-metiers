execute if entity @s[tag=metiers.skoff.t1] run return run function metiers:t/activer_1
tag @s add metiers.skoff.t1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pourboire est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:t/arbre
