tag @s remove metiers.skoff.t5
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Colporteur est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:t/arbre
