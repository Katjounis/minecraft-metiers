tag @s remove metiers.skoff.t3
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Marché noir est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:t/arbre
