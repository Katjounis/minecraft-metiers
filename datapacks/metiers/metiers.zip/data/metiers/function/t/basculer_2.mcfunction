execute if entity @s[tag=metiers.skoff.t2] run return run function metiers:t/activer_2
tag @s add metiers.skoff.t2
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Réputation est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:t/arbre
