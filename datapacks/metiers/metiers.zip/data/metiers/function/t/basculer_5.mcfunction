execute if entity @s[tag=metiers.skoff.t5] run return run function metiers:t/activer_5
tag @s add metiers.skoff.t5
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Colporteur est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:t/arbre
