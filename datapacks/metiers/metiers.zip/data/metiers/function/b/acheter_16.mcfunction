execute if entity @s[tag=metiers.sk.b16] run return run function metiers:b/basculer_16
execute unless score @s m.b_lvl matches 45.. unless score @s m.b_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 45 en Bûcheron.","color":"red"}]
execute unless score @s m.b_lvl matches 45.. unless score @s m.b_pr matches 1.. run return run function metiers:b/arbre
function metiers:b/points
execute unless entity @s[tag=metiers.sk.b15] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Écorce.","color":"red"}]
execute unless entity @s[tag=metiers.sk.b15] run return run function metiers:b/arbre
execute if score @s m.tmp matches ..9 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (10 requis).","color":"red"}]
execute if score @s m.tmp matches ..9 run return run function metiers:b/arbre
scoreboard players add @s m.b_spent 10
tag @s add metiers.sk.b16
advancement grant @s only metiers:b/competence_16
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Tourbillon","color":"gold","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:b/arbre
