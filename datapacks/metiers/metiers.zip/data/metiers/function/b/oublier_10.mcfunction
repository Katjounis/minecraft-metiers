execute unless entity @s[tag=metiers.sk.b10] run return run function metiers:b/arbre
execute if entity @s[tag=metiers.sk.b11] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Graine de forêt, qui a besoin de Sève.","color":"red"}]
tag @s remove metiers.sk.b10
tag @s remove metiers.skoff.b10
advancement revoke @s only metiers:b/competence_10
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Sève est oubliée : 10 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
