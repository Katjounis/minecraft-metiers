execute unless entity @s[tag=metiers.sk.b6] run return run function metiers:b/arbre
tag @s remove metiers.skoff.b6
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Esprit de la forêt est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:b/arbre
