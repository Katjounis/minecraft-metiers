execute unless entity @s[tag=metiers.sk.b8] run return run function metiers:b/arbre
execute if entity @s[tag=metiers.sk.b9] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Abattage étendu, qui a besoin de Ramasse-tout.","color":"red"}]
tag @s remove metiers.sk.b8
tag @s remove metiers.skoff.b8
advancement revoke @s only metiers:b/competence_8
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ramasse-tout est oubliée : 6 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
