scoreboard players add #pas m.tmp 1
execute if block ~ ~ ~ #minecraft:air if block ~ ~-1 ~ #minecraft:dirt align xyz positioned ~0.5 ~ ~0.5 run return run function metiers:b/replante/poser with storage metiers:bois
execute if block ~ ~ ~ #minecraft:air if block ~ ~-1 ~ #minecraft:nylium align xyz positioned ~0.5 ~ ~0.5 run return run function metiers:b/replante/poser with storage metiers:bois
execute if score #pas m.tmp matches ..55 positioned ^ ^ ^0.1 run function metiers:b/replante/rayon
