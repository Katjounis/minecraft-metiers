scoreboard players set #sum m.tmp 0
scoreboard players operation #sum m.tmp += @s a.oak_log
scoreboard players operation #sum m.tmp += @s a.spruce_log
scoreboard players operation #sum m.tmp += @s a.birch_log
scoreboard players operation #sum m.tmp += @s a.jungle_log
scoreboard players operation #sum m.tmp += @s a.acacia_log
scoreboard players operation #sum m.tmp += @s a.dark_oak_log
scoreboard players operation #sum m.tmp += @s a.mangrove_log
scoreboard players operation #sum m.tmp += @s a.cherry_log
scoreboard players operation #sum m.tmp += @s a.pale_oak_log
scoreboard players operation #sum m.tmp += @s a.crimson_stem
scoreboard players operation #sum m.tmp += @s a.warped_stem
execute if score @s a.oak_log matches 1.. run data modify storage metiers:bois pousse set value "oak_sapling"
execute if score @s a.spruce_log matches 1.. run data modify storage metiers:bois pousse set value "spruce_sapling"
execute if score @s a.birch_log matches 1.. run data modify storage metiers:bois pousse set value "birch_sapling"
execute if score @s a.jungle_log matches 1.. run data modify storage metiers:bois pousse set value "jungle_sapling"
execute if score @s a.acacia_log matches 1.. run data modify storage metiers:bois pousse set value "acacia_sapling"
execute if score @s a.dark_oak_log matches 1.. run data modify storage metiers:bois pousse set value "dark_oak_sapling"
execute if score @s a.mangrove_log matches 1.. run data modify storage metiers:bois pousse set value "mangrove_propagule"
execute if score @s a.cherry_log matches 1.. run data modify storage metiers:bois pousse set value "cherry_sapling"
execute if score @s a.pale_oak_log matches 1.. run data modify storage metiers:bois pousse set value "pale_oak_sapling"
execute if score @s a.crimson_stem matches 1.. run data modify storage metiers:bois pousse set value "crimson_fungus"
execute if score @s a.warped_stem matches 1.. run data modify storage metiers:bois pousse set value "warped_fungus"
scoreboard players set @s a.oak_log 0
scoreboard players set @s a.spruce_log 0
scoreboard players set @s a.birch_log 0
scoreboard players set @s a.jungle_log 0
scoreboard players set @s a.acacia_log 0
scoreboard players set @s a.dark_oak_log 0
scoreboard players set @s a.mangrove_log 0
scoreboard players set @s a.cherry_log 0
scoreboard players set @s a.pale_oak_log 0
scoreboard players set @s a.crimson_stem 0
scoreboard players set @s a.warped_stem 0
execute if score #sum m.tmp matches 1.. if score @s a.sneak matches 1.. if entity @s[tag=metiers.sk.b2,tag=!metiers.skoff.b2] if items entity @s weapon.mainhand #minecraft:axes run function metiers:b/abattage/debut
execute if score #sum m.tmp matches 1.. if entity @s[tag=metiers.sk.b3,tag=!metiers.skoff.b3] run function metiers:b/replante/debut
scoreboard players set @s a.sneak 0
