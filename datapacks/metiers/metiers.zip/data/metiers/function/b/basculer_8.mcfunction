execute if entity @s[tag=metiers.skoff.b8] run return run function metiers:b/activer_8
tag @s add metiers.skoff.b8
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ramasse-tout est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:b/arbre
