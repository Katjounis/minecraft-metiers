execute if entity @s[tag=metiers.skoff.b8] run return run function metiers:b/choix_off_8
function metiers:b/choix_on_8
