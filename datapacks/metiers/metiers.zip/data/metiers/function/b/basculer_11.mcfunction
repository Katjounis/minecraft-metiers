execute if entity @s[tag=metiers.skoff.b11] run return run function metiers:b/choix_off_11
function metiers:b/choix_on_11
