execute if entity @s[tag=metiers.skoff.b11] run return run function metiers:b/choix_11
tag @s add metiers.skoff.b11
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Graine de forêt est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:b/arbre
