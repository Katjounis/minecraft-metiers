execute unless entity @s[tag=metiers.sk.b9] run return run function metiers:b/arbre
execute if entity @s[tag=metiers.sk.b10] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Sève, qui a besoin de Abattage étendu.","color":"red"}]
tag @s remove metiers.sk.b9
tag @s remove metiers.skoff.b9
advancement revoke @s only metiers:b/competence_9
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Abattage étendu est oubliée : 8 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
