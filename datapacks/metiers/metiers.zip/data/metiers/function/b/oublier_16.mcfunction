execute unless entity @s[tag=metiers.sk.b16] run return run function metiers:b/arbre
execute if entity @s[tag=metiers.sk.b17] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Cœur de chêne, qui a besoin de Tourbillon.","color":"red"}]
tag @s remove metiers.sk.b16
tag @s remove metiers.skoff.b16
advancement revoke @s only metiers:b/competence_16
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tourbillon est oubliée : 10 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
