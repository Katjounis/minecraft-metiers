execute unless entity @s[tag=metiers.sk.b12] run return run function metiers:b/arbre
tag @s remove metiers.skoff.b12
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Grande coupe est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:b/arbre
