execute unless entity @s[tag=metiers.sk.b4] run return run function metiers:b/arbre
execute if entity @s[tag=metiers.sk.b5] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Charbonnier, qui a besoin de Effeuillage.","color":"red"}]
tag @s remove metiers.sk.b4
tag @s remove metiers.skoff.b4
advancement revoke @s only metiers:b/competence_4
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Effeuillage est oubliée : 8 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
