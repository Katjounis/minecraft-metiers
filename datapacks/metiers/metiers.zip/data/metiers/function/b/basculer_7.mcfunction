execute if entity @s[tag=metiers.skoff.b7] run return run function metiers:b/activer_7
tag @s add metiers.skoff.b7
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Coupe nette est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:b/arbre
