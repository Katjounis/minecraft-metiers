execute if entity @s[tag=metiers.skoff.b7] run return run function metiers:b/choix_off_7
function metiers:b/choix_on_7
