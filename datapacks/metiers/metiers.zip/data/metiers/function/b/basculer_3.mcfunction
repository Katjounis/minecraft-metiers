execute if entity @s[tag=metiers.skoff.b3] run return run function metiers:b/choix_off_3
function metiers:b/choix_on_3
