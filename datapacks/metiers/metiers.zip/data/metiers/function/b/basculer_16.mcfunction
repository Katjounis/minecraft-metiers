execute if entity @s[tag=metiers.skoff.b16] run return run function metiers:b/choix_off_16
function metiers:b/choix_on_16
