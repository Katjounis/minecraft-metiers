scoreboard players operation #L m.tmp = @s m.b_lvl
function metiers:xp/table
scoreboard players operation @s m.b_need = #N m.tmp
scoreboard players operation #N m.tmp = @s m.b_pr
scoreboard players operation #N m.tmp *= #F99 m.const
scoreboard players operation @s m.b_need += #N m.tmp
execute if score @s m.b_lvl matches ..99 if score @s m.b_xp >= @s m.b_need run function metiers:b/levelup
