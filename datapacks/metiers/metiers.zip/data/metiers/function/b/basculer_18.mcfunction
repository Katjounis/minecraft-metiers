execute if entity @s[tag=metiers.skoff.b18] run return run function metiers:b/choix_off_18
function metiers:b/choix_on_18
