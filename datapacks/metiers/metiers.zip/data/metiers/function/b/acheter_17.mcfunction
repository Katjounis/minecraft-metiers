execute if entity @s[tag=metiers.sk.b17] run return run function metiers:b/basculer_17
execute unless score @s m.b_lvl matches 60.. unless score @s m.b_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 60 en Bûcheron.","color":"red"}]
execute unless score @s m.b_lvl matches 60.. unless score @s m.b_pr matches 1.. run return run function metiers:b/arbre
function metiers:b/points
execute unless entity @s[tag=metiers.sk.b16] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Tourbillon.","color":"red"}]
execute unless entity @s[tag=metiers.sk.b16] run return run function metiers:b/arbre
execute if score @s m.tmp matches ..11 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (12 requis).","color":"red"}]
execute if score @s m.tmp matches ..11 run return run function metiers:b/arbre
scoreboard players add @s m.b_spent 12
tag @s add metiers.sk.b17
advancement grant @s only metiers:b/competence_17
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Cœur de chêne","color":"gold","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:b/arbre
