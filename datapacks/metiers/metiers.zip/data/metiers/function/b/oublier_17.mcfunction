execute unless entity @s[tag=metiers.sk.b17] run return run function metiers:b/arbre
execute if entity @s[tag=metiers.sk.b18] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Colosse, qui a besoin de Cœur de chêne.","color":"red"}]
tag @s remove metiers.sk.b17
tag @s remove metiers.skoff.b17
advancement revoke @s only metiers:b/competence_17
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cœur de chêne est oubliée : 12 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
