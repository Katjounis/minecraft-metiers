execute if entity @s[tag=metiers.skoff.b1] run return run function metiers:b/choix_off_1
function metiers:b/choix_on_1
