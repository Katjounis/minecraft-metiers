execute if entity @s[tag=metiers.skoff.b1] run return run function metiers:b/activer_1
tag @s add metiers.skoff.b1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Double coupe est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:b/arbre
