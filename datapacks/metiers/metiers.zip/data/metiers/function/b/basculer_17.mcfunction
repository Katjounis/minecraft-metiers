execute if entity @s[tag=metiers.skoff.b17] run return run function metiers:b/choix_off_17
function metiers:b/choix_on_17
