execute if entity @s[tag=metiers.skoff.b17] run return run function metiers:b/choix_17
tag @s add metiers.skoff.b17
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cœur de chêne est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:b/arbre
