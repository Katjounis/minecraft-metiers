execute unless entity @s[tag=metiers.sk.b7] run return run function metiers:b/arbre
execute if entity @s[tag=metiers.sk.b8] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Ramasse-tout, qui a besoin de Coupe nette.","color":"red"}]
tag @s remove metiers.sk.b7
tag @s remove metiers.skoff.b7
advancement revoke @s only metiers:b/competence_7
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Coupe nette est oubliée : 4 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
