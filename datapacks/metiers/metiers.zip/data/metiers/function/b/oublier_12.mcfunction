execute unless entity @s[tag=metiers.sk.b12] run return run function metiers:b/arbre
tag @s remove metiers.sk.b12
tag @s remove metiers.skoff.b12
advancement revoke @s only metiers:b/competence_12
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Grande coupe est oubliée : 14 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
