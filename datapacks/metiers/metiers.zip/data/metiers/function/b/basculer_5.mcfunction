execute if entity @s[tag=metiers.skoff.b5] run return run function metiers:b/activer_5
tag @s add metiers.skoff.b5
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Charbonnier est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:b/arbre
