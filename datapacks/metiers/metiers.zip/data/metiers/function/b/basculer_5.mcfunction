execute if entity @s[tag=metiers.skoff.b5] run return run function metiers:b/choix_off_5
function metiers:b/choix_on_5
