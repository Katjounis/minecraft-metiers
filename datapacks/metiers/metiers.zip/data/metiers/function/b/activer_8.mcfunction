execute unless entity @s[tag=metiers.sk.b8] run return run function metiers:b/arbre
tag @s remove metiers.skoff.b8
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ramasse-tout est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:b/arbre
