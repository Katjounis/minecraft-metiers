execute if entity @s[tag=metiers.sk.b14] run return run function metiers:b/basculer_14
execute unless score @s m.b_lvl matches 20.. unless score @s m.b_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 20 en Bûcheron.","color":"red"}]
execute unless score @s m.b_lvl matches 20.. unless score @s m.b_pr matches 1.. run return run function metiers:b/arbre
function metiers:b/points
execute unless entity @s[tag=metiers.sk.b13] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Hache de guerre.","color":"red"}]
execute unless entity @s[tag=metiers.sk.b13] run return run function metiers:b/arbre
execute if score @s m.tmp matches ..5 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (6 requis).","color":"red"}]
execute if score @s m.tmp matches ..5 run return run function metiers:b/arbre
scoreboard players add @s m.b_spent 6
tag @s add metiers.sk.b14
advancement grant @s only metiers:b/competence_14
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Bras de géant","color":"gold","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:b/arbre
