execute if entity @s[tag=metiers.sk.b9] run return run function metiers:b/basculer_9
execute unless score @s m.b_lvl matches 30.. unless score @s m.b_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 30 en Bûcheron.","color":"red"}]
execute unless score @s m.b_lvl matches 30.. unless score @s m.b_pr matches 1.. run return run function metiers:b/arbre
function metiers:b/points
execute unless entity @s[tag=metiers.sk.b8] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Ramasse-tout.","color":"red"}]
execute unless entity @s[tag=metiers.sk.b8] run return run function metiers:b/arbre
execute if score @s m.tmp matches ..7 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (8 requis).","color":"red"}]
execute if score @s m.tmp matches ..7 run return run function metiers:b/arbre
scoreboard players add @s m.b_spent 8
tag @s add metiers.sk.b9
advancement grant @s only metiers:b/competence_9
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Abattage étendu","color":"gold","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:b/arbre
