function metiers:places
execute if score @s m.tmp matches ..1 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Inventaire plein ! Libère 2 emplacements puis réessaie (/trigger metiers > Récompenses).","color":"red"}]
execute if score @s m.tmp matches ..1 run playsound minecraft:entity.villager.no master @s ~ ~ ~ 1 1
execute if score @s m.tmp matches ..1 run return 0
scoreboard players set @s m.b_pal 4
scoreboard players add @s m.cr_b 20
scoreboard players add @s m.ecl 1
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.ecus 3500
execute if score @s c.ecus matches -2147483648.. run scoreboard players add @s c.a_met 3500
give @s minecraft:pale_oak_log 64
give @s minecraft:golden_apple 6
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" récupère sa récompense","color":"gray"},{"text":" (palier 40 Bûcheron)","color":"gray"}]
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Dont +3500 Écus sur ton compte.","color":"gold"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 0.6
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.3 60
function metiers:recompenses
