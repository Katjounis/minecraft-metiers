execute unless entity @s[tag=metiers.sk.b13] run return run function metiers:b/arbre
execute if entity @s[tag=metiers.sk.b14] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Bras de géant, qui a besoin de Hache de guerre.","color":"red"}]
tag @s remove metiers.sk.b13
tag @s remove metiers.skoff.b13
advancement revoke @s only metiers:b/competence_13
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Hache de guerre est oubliée : 4 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
