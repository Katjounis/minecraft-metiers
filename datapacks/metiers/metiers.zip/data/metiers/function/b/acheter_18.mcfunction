execute if entity @s[tag=metiers.sk.b18] run return run function metiers:b/basculer_18
execute unless score @s m.b_lvl matches 80.. unless score @s m.b_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 80 en Bûcheron.","color":"red"}]
execute unless score @s m.b_lvl matches 80.. unless score @s m.b_pr matches 1.. run return run function metiers:b/arbre
function metiers:b/points
execute unless entity @s[tag=metiers.sk.b17] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Cœur de chêne.","color":"red"}]
execute unless entity @s[tag=metiers.sk.b17] run return run function metiers:b/arbre
execute if score @s m.tmp matches ..13 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (14 requis).","color":"red"}]
execute if score @s m.tmp matches ..13 run return run function metiers:b/arbre
scoreboard players add @s m.b_spent 14
tag @s add metiers.sk.b18
advancement grant @s only metiers:b/competence_18
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Colosse","color":"gold","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:b/arbre
