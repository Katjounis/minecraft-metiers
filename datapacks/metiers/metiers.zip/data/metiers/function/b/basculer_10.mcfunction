execute if entity @s[tag=metiers.skoff.b10] run return run function metiers:b/choix_off_10
function metiers:b/choix_on_10
