execute if entity @s[tag=metiers.skoff.b12] run return run function metiers:b/choix_12
tag @s add metiers.skoff.b12
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Grande coupe est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:b/arbre
