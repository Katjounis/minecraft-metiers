scoreboard players set @s m.b_spent 0
execute if entity @s[tag=metiers.sk.b1] run scoreboard players add @s m.b_spent 3
execute if entity @s[tag=metiers.sk.b2] run scoreboard players add @s m.b_spent 4
execute if entity @s[tag=metiers.sk.b3] run scoreboard players add @s m.b_spent 6
execute if entity @s[tag=metiers.sk.b4] run scoreboard players add @s m.b_spent 8
execute if entity @s[tag=metiers.sk.b5] run scoreboard players add @s m.b_spent 12
execute if entity @s[tag=metiers.sk.b6] run scoreboard players add @s m.b_spent 16
execute if entity @s[tag=metiers.sk.b7] run scoreboard players add @s m.b_spent 4
execute if entity @s[tag=metiers.sk.b8] run scoreboard players add @s m.b_spent 6
execute if entity @s[tag=metiers.sk.b9] run scoreboard players add @s m.b_spent 8
execute if entity @s[tag=metiers.sk.b10] run scoreboard players add @s m.b_spent 10
execute if entity @s[tag=metiers.sk.b11] run scoreboard players add @s m.b_spent 12
execute if entity @s[tag=metiers.sk.b12] run scoreboard players add @s m.b_spent 14
execute if entity @s[tag=metiers.sk.b13] run scoreboard players add @s m.b_spent 4
execute if entity @s[tag=metiers.sk.b14] run scoreboard players add @s m.b_spent 6
execute if entity @s[tag=metiers.sk.b15] run scoreboard players add @s m.b_spent 8
execute if entity @s[tag=metiers.sk.b16] run scoreboard players add @s m.b_spent 10
execute if entity @s[tag=metiers.sk.b17] run scoreboard players add @s m.b_spent 12
execute if entity @s[tag=metiers.sk.b18] run scoreboard players add @s m.b_spent 14
scoreboard players operation @s m.tmp = @s m.b_lvl
scoreboard players remove @s m.tmp 1
scoreboard players operation @s m.tmp -= @s m.b_spent
scoreboard players operation #ppr m.tmp = @s m.b_pr
scoreboard players operation #ppr m.tmp *= #99 m.const
scoreboard players operation @s m.tmp += #ppr m.tmp
