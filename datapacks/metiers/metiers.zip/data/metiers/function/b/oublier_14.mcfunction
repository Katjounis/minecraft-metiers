execute unless entity @s[tag=metiers.sk.b14] run return run function metiers:b/arbre
execute if entity @s[tag=metiers.sk.b15] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Écorce, qui a besoin de Bras de géant.","color":"red"}]
tag @s remove metiers.sk.b14
tag @s remove metiers.skoff.b14
advancement revoke @s only metiers:b/competence_14
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Bras de géant est oubliée : 6 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
