execute if entity @s[tag=metiers.skoff.b2] run return run function metiers:b/choix_off_2
function metiers:b/choix_on_2
