execute if entity @s[tag=metiers.skoff.b2] run return run function metiers:b/choix_2
tag @s add metiers.skoff.b2
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Abattage est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:b/arbre
