execute if entity @s[tag=metiers.skoff.b6] run return run function metiers:b/choix_off_6
function metiers:b/choix_on_6
