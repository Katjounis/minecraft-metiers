execute if entity @s[tag=metiers.skoff.b6] run return run function metiers:b/choix_6
tag @s add metiers.skoff.b6
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Esprit de la forêt est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:b/arbre
