execute unless entity @s[tag=metiers.sk.b15] run return run function metiers:b/arbre
execute if entity @s[tag=metiers.sk.b16] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Tourbillon, qui a besoin de Écorce.","color":"red"}]
tag @s remove metiers.sk.b15
tag @s remove metiers.skoff.b15
advancement revoke @s only metiers:b/competence_15
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Écorce est oubliée : 8 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
