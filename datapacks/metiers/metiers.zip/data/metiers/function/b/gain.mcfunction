scoreboard players operation @s m.gain = @s m.b_bal
scoreboard players set @s m.b_bal 0
scoreboard players operation @s m.tmp = @s m.gain
scoreboard players operation @s m.tmp *= @s m.b_pr
scoreboard players operation @s m.tmp /= #10 m.const
scoreboard players operation @s m.gain += @s m.tmp
execute if score #job m.heure matches 1 run scoreboard players operation @s m.gain *= #2 m.const
execute if score @s m.csag_b matches 1 run function metiers:refonte/sagesse
execute if score @s m.ceco_b matches 1 store result score #r m.tmp run random value 1..100
execute if score @s m.ceco_b matches 1 if score #r m.tmp matches ..5 run scoreboard players add @s m.cr_b 1
execute if score @s m.b_lvl matches 100.. run return 0
scoreboard players operation @s m.b_xp += @s m.gain
function metiers:b/check
title @s actionbar [{"text":"+","color":"green"},{"score":{"name":"@s","objective":"m.gain"},"color":"green"},{"text":" XP Bûcheron","color":"gold"},{"text":"  |  niv ","color":"gray"},{"score":{"name":"@s","objective":"m.b_lvl"},"color":"white"},{"text":"  (","color":"gray"},{"score":{"name":"@s","objective":"m.b_xp"},"color":"white"},{"text":"/","color":"gray"},{"score":{"name":"@s","objective":"m.b_need"},"color":"white"},{"text":")","color":"gray"}]
execute if score @s m.gid matches 1.. run scoreboard players operation @s m.gxp += @s m.gain
