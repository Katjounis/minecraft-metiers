execute unless entity @s[tag=metiers.sk.b10] run return run function metiers:b/arbre
tag @s add metiers.skoff.b10
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Sève est désactivée.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:b/arbre
