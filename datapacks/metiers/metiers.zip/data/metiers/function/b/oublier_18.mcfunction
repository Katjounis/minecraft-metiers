execute unless entity @s[tag=metiers.sk.b18] run return run function metiers:b/arbre
tag @s remove metiers.sk.b18
tag @s remove metiers.skoff.b18
advancement revoke @s only metiers:b/competence_18
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Colosse est oubliée : 14 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
