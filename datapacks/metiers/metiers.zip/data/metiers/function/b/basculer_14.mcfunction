execute if entity @s[tag=metiers.skoff.b14] run return run function metiers:b/choix_off_14
function metiers:b/choix_on_14
