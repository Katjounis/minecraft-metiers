execute if entity @s[tag=metiers.skoff.b14] run return run function metiers:b/activer_14
tag @s add metiers.skoff.b14
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Bras de géant est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:b/arbre
