execute unless entity @s[tag=metiers.sk.b6] run return run function metiers:b/arbre
tag @s remove metiers.sk.b6
tag @s remove metiers.skoff.b6
advancement revoke @s only metiers:b/competence_6
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Esprit de la forêt est oubliée : 16 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
