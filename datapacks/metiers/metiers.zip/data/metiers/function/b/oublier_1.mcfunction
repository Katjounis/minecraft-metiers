execute unless entity @s[tag=metiers.sk.b1] run return run function metiers:b/arbre
execute if entity @s[tag=metiers.sk.b2] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Abattage, qui a besoin de Double coupe.","color":"red"}]
execute if entity @s[tag=metiers.sk.b7] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Coupe nette, qui a besoin de Double coupe.","color":"red"}]
execute if entity @s[tag=metiers.sk.b13] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Hache de guerre, qui a besoin de Double coupe.","color":"red"}]
tag @s remove metiers.sk.b1
tag @s remove metiers.skoff.b1
advancement revoke @s only metiers:b/competence_1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Double coupe est oubliée : 3 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
