execute unless entity @s[tag=metiers.sk.b3] run return run function metiers:b/arbre
execute if entity @s[tag=metiers.sk.b4] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Effeuillage, qui a besoin de Replanteur.","color":"red"}]
tag @s remove metiers.sk.b3
tag @s remove metiers.skoff.b3
advancement revoke @s only metiers:b/competence_3
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Replanteur est oubliée : 6 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
