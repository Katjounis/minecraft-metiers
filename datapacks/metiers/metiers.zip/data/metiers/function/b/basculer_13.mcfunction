execute if entity @s[tag=metiers.skoff.b13] run return run function metiers:b/activer_13
tag @s add metiers.skoff.b13
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Hache de guerre est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:b/arbre
