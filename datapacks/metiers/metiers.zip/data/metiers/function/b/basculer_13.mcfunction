execute if entity @s[tag=metiers.skoff.b13] run return run function metiers:b/choix_off_13
function metiers:b/choix_on_13
