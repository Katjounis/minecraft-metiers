execute if entity @s[tag=metiers.sk.b2] run return run function metiers:b/basculer_2
execute unless score @s m.b_lvl matches 20.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 20 en Bûcheron.","color":"red"}]
execute unless score @s m.b_lvl matches 20.. run return run function metiers:b/arbre
function metiers:b/points
execute unless entity @s[tag=metiers.sk.b1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Double coupe.","color":"red"}]
execute unless entity @s[tag=metiers.sk.b1] run return run function metiers:b/arbre
execute if score @s m.tmp matches ..7 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (8 requis).","color":"red"}]
execute if score @s m.tmp matches ..7 run return run function metiers:b/arbre
scoreboard players add @s m.b_spent 8
tag @s add metiers.sk.b2
advancement grant @s only metiers:b/competence_2
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Abattage","color":"gold","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
scoreboard players set @s a.oak_log 0
scoreboard players set @s a.spruce_log 0
scoreboard players set @s a.birch_log 0
scoreboard players set @s a.jungle_log 0
scoreboard players set @s a.acacia_log 0
scoreboard players set @s a.dark_oak_log 0
scoreboard players set @s a.mangrove_log 0
scoreboard players set @s a.cherry_log 0
scoreboard players set @s a.pale_oak_log 0
scoreboard players set @s a.crimson_stem 0
scoreboard players set @s a.warped_stem 0
function metiers:b/arbre
