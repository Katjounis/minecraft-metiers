execute unless entity @s[tag=metiers.sk.b11] run return run function metiers:b/arbre
tag @s remove metiers.skoff.b11
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Graine de forêt est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:b/arbre
