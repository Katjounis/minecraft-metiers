execute unless entity @s[tag=metiers.sk.b14] run return run function metiers:b/arbre
tag @s remove metiers.skoff.b14
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Bras de géant est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:b/arbre
