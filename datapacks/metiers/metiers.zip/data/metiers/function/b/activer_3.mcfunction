tag @s remove metiers.skoff.b3
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Replanteur est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:b/arbre
