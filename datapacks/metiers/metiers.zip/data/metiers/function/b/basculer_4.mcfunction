execute if entity @s[tag=metiers.skoff.b4] run return run function metiers:b/choix_4
tag @s add metiers.skoff.b4
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Effeuillage est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:b/arbre
