execute if entity @s[tag=metiers.skoff.b4] run return run function metiers:b/choix_off_4
function metiers:b/choix_on_4
