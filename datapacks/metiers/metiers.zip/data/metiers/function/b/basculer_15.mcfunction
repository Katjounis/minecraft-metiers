execute if entity @s[tag=metiers.skoff.b15] run return run function metiers:b/choix_off_15
function metiers:b/choix_on_15
