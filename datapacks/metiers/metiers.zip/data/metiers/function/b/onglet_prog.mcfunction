scoreboard players set #vue m.tmp 2
function metiers:b/arbre
