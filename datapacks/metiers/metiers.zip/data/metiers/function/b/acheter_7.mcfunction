execute if entity @s[tag=metiers.sk.b7] run return run function metiers:b/basculer_7
execute unless score @s m.b_lvl matches 10.. unless score @s m.b_pr matches 1.. run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 10 en Bûcheron.","color":"red"}]
execute unless score @s m.b_lvl matches 10.. unless score @s m.b_pr matches 1.. run return run function metiers:b/arbre
function metiers:b/points
execute unless entity @s[tag=metiers.sk.b1] run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut d'abord débloquer : Double coupe.","color":"red"}]
execute unless entity @s[tag=metiers.sk.b1] run return run function metiers:b/arbre
execute if score @s m.tmp matches ..3 run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de points (4 requis).","color":"red"}]
execute if score @s m.tmp matches ..3 run return run function metiers:b/arbre
scoreboard players add @s m.b_spent 4
tag @s add metiers.sk.b7
advancement grant @s only metiers:b/competence_7
tellraw @a [{"text":"[Métiers] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" débloque la compétence ","color":"gray"},{"text":"Coupe nette","color":"gold","bold":true}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1
function metiers:b/arbre
