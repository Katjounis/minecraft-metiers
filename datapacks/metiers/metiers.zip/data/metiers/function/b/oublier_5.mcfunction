execute unless entity @s[tag=metiers.sk.b5] run return run function metiers:b/arbre
execute if entity @s[tag=metiers.sk.b6] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Esprit de la forêt, qui a besoin de Charbonnier.","color":"red"}]
tag @s remove metiers.sk.b5
tag @s remove metiers.skoff.b5
advancement revoke @s only metiers:b/competence_5
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Charbonnier est oubliée : 12 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
