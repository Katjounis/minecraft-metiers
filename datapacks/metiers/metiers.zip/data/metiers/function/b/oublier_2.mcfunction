execute unless entity @s[tag=metiers.sk.b2] run return run function metiers:b/arbre
execute if entity @s[tag=metiers.sk.b3] run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Oublie d’abord Replanteur, qui a besoin de Abattage.","color":"red"}]
tag @s remove metiers.sk.b2
tag @s remove metiers.skoff.b2
advancement revoke @s only metiers:b/competence_2
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Abattage est oubliée : 4 points te sont rendus.","color":"gold"}]
playsound minecraft:entity.item.break master @s ~ ~ ~ 0.8 1.2
function metiers:b/arbre
