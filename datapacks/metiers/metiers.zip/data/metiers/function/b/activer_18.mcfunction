tag @s remove metiers.skoff.b18
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Colosse est réactivée.","color":"green"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 1.2
function metiers:b/arbre
