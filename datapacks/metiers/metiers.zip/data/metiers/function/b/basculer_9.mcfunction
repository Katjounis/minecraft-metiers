execute if entity @s[tag=metiers.skoff.b9] run return run function metiers:b/choix_9
tag @s add metiers.skoff.b9
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Abattage étendu est désactivée. Tu la gardes : reclique pour la réactiver.","color":"gold"}]
playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.7
function metiers:b/arbre
