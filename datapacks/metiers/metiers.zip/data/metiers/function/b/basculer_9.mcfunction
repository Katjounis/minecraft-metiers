execute if entity @s[tag=metiers.skoff.b9] run return run function metiers:b/choix_off_9
function metiers:b/choix_on_9
