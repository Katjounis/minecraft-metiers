scoreboard players set @s m.cfor_f 0
scoreboard players add @s m.cr_f 160
function metiers:f/outil_donner
playsound minecraft:block.grindstone.use master @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cristal retiré : 160 cristaux remboursés.","color":"aqua"}]
function metiers:forge/outil
