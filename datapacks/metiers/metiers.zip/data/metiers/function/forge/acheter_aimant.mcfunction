execute unless score @s m.ecl matches 6.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez d’éclats de boss.","color":"red"}]
scoreboard players remove @s m.ecl 6
function metiers:forge/donner_aimant
playsound minecraft:block.anvil.use master @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu as forgé : Aimant à objets.","color":"gold"}]
function metiers:forge/boutique
