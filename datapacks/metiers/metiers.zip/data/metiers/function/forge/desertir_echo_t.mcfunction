scoreboard players set @s m.ceco_t 0
scoreboard players add @s m.cr_t 240
function metiers:t/outil_donner
playsound minecraft:block.grindstone.use master @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cristal retiré : 240 cristaux remboursés.","color":"aqua"}]
function metiers:forge/outil
