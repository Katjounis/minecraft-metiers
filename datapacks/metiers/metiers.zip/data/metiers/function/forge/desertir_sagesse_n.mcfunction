scoreboard players set @s m.csag_n 0
scoreboard players add @s m.cr_n 90
function metiers:n/outil_donner
playsound minecraft:block.grindstone.use master @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cristal retiré : 90 cristaux remboursés.","color":"aqua"}]
function metiers:forge/outil
