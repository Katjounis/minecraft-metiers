function metiers:forge/calcul
function metiers:forge/outil_dialog with storage metiers:fg
