execute if score @s m.fo_cape matches 1 run return run function metiers:forge/recup_cape
execute unless score @s m.ecl matches 12.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez d’éclats de boss.","color":"red"}]
scoreboard players remove @s m.ecl 12
function metiers:forge/donner_cape
scoreboard players set @s m.fo_cape 1
playsound minecraft:block.anvil.use master @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu as forgé : Cape-planeur.","color":"gold"}]
function metiers:forge/boutique
