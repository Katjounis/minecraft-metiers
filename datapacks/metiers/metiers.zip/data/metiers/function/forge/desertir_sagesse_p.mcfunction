scoreboard players set @s m.csag_p 0
scoreboard players add @s m.cr_p 90
function metiers:p/outil_donner
playsound minecraft:block.grindstone.use master @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cristal retiré : 90 cristaux remboursés.","color":"aqua"}]
function metiers:forge/outil
