execute if score @s m.fo_arc3 matches 1 run return run function metiers:forge/recup_arc3
execute unless score @s m.c_lvl matches 60.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 60 en Chasseur.","color":"red"}]
execute unless score @s m.cr_c matches 300.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
execute unless score @s m.ecl matches 5.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez d’éclats de boss.","color":"red"}]
scoreboard players remove @s m.cr_c 300
scoreboard players remove @s m.ecl 5
function metiers:forge/donner_arc3
scoreboard players set @s m.fo_arc3 1
playsound minecraft:block.anvil.use master @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu as forgé : Arc à triple tir.","color":"gold"}]
function metiers:forge/boutique
