scoreboard players set @s m.cfor_t 0
scoreboard players add @s m.cr_t 160
function metiers:t/outil_donner
playsound minecraft:block.grindstone.use master @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cristal retiré : 160 cristaux remboursés.","color":"aqua"}]
function metiers:forge/outil
