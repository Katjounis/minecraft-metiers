execute if score @s m.fo_marteau matches 1 run return run function metiers:forge/recup_marteau
execute unless score @s m.m_lvl matches 50.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 50 en Mineur.","color":"red"}]
execute unless score @s m.cr_m matches 260.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
execute unless score @s m.ecl matches 4.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez d’éclats de boss.","color":"red"}]
scoreboard players remove @s m.cr_m 260
scoreboard players remove @s m.ecl 4
function metiers:forge/donner_marteau
scoreboard players set @s m.fo_marteau 1
playsound minecraft:block.anvil.use master @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Tu as forgé : Marteau du Mineur.","color":"gold"}]
function metiers:forge/boutique
