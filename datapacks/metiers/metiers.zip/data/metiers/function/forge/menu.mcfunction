function metiers:forge/calcul
function metiers:forge/menu_dialog with storage metiers:fg
