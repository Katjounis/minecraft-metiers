function metiers:forge/calcul
function metiers:forge/boutique_dialog with storage metiers:fg
