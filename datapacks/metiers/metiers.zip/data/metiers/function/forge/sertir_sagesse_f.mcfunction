execute if score @s m.csag_f matches 1 run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Ce cristal est déjà serti.","color":"red"}]
execute unless score @s m.f_lvl matches 20.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Il faut être niveau 20 dans ce métier.","color":"red"}]
scoreboard players set #sl m.tmp 0
execute if score @s m.f_out matches 3.. run scoreboard players add #sl m.tmp 1
execute if score @s m.f_out matches 6.. run scoreboard players add #sl m.tmp 1
execute if score @s m.f_out matches 9.. run scoreboard players add #sl m.tmp 1
scoreboard players operation #us m.tmp = @s m.csag_f
scoreboard players operation #us m.tmp += @s m.cfor_f
scoreboard players operation #us m.tmp += @s m.ceco_f
execute if score #us m.tmp >= #sl m.tmp run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Plus d’emplacement libre : il en faut un nouveau (paliers 3, 6 et 9).","color":"red"}]
execute unless score @s m.cr_f matches 90.. run return run tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Pas assez de cristaux.","color":"red"}]
scoreboard players remove @s m.cr_f 90
scoreboard players set @s m.csag_f 1
function metiers:f/outil_donner
playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 1 1.2
tellraw @s [{"text":"[Métiers] ","color":"gold"},{"text":"Cristal serti dans ton outil.","color":"aqua"}]
function metiers:forge/outil
