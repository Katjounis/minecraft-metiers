schedule clear metiers:loop
execute as @a run attribute @s minecraft:attack_damage modifier remove metiers:c1
execute as @a run attribute @s minecraft:attack_damage modifier remove metiers:c5
execute as @a run attribute @s minecraft:attack_damage modifier remove metiers:chasseur
execute as @a run attribute @s minecraft:luck modifier remove metiers:p1
execute as @a run attribute @s minecraft:luck modifier remove metiers:p6
execute as @a run attribute @s minecraft:luck modifier remove metiers:pecheur
tag @a remove metiers.ok
tag @a remove metiers.v2
tag @a remove metiers.v3
advancement revoke @a from metiers:b/racine
advancement revoke @a from metiers:f/racine
advancement revoke @a from metiers:m/racine
advancement revoke @a from metiers:c/racine
advancement revoke @a from metiers:p/racine
tag @a remove metiers.sk.b1
tag @a remove metiers.sk.b2
tag @a remove metiers.sk.b3
tag @a remove metiers.sk.b4
tag @a remove metiers.sk.b5
tag @a remove metiers.sk.b6
tag @a remove metiers.sk.f1
tag @a remove metiers.sk.f2
tag @a remove metiers.sk.f3
tag @a remove metiers.sk.f4
tag @a remove metiers.sk.f5
tag @a remove metiers.sk.f6
tag @a remove metiers.sk.m1
tag @a remove metiers.sk.m2
tag @a remove metiers.sk.m3
tag @a remove metiers.sk.m4
tag @a remove metiers.sk.m5
tag @a remove metiers.sk.m6
tag @a remove metiers.sk.c1
tag @a remove metiers.sk.c2
tag @a remove metiers.sk.c3
tag @a remove metiers.sk.c4
tag @a remove metiers.sk.c5
tag @a remove metiers.sk.c6
tag @a remove metiers.sk.p1
tag @a remove metiers.sk.p2
tag @a remove metiers.sk.p3
tag @a remove metiers.sk.p4
tag @a remove metiers.sk.p5
tag @a remove metiers.sk.p6
tag @a remove metiers.sk.e1
tag @a remove metiers.sk.e2
tag @a remove metiers.sk.e3
tag @a remove metiers.sk.e4
tag @a remove metiers.sk.e5
tag @a remove metiers.sk.e6
tag @a remove metiers.sk.n1
tag @a remove metiers.sk.n2
tag @a remove metiers.sk.n3
tag @a remove metiers.sk.n4
tag @a remove metiers.sk.n5
tag @a remove metiers.sk.n6
tag @a remove metiers.sk.x1
tag @a remove metiers.sk.x2
tag @a remove metiers.sk.x3
tag @a remove metiers.sk.x4
tag @a remove metiers.sk.x5
tag @a remove metiers.sk.x6
tag @a remove metiers.sk.t1
tag @a remove metiers.sk.t2
tag @a remove metiers.sk.t3
tag @a remove metiers.sk.t4
tag @a remove metiers.sk.t5
tag @a remove metiers.sk.t6
tag @a remove metiers.sk.k1
tag @a remove metiers.sk.k2
tag @a remove metiers.sk.k3
tag @a remove metiers.sk.k4
tag @a remove metiers.sk.k5
tag @a remove metiers.sk.k6
scoreboard objectives remove m.tmp
scoreboard objectives remove m.gain
scoreboard objectives remove m.const
scoreboard objectives remove m.timer
scoreboard objectives remove m.pref
scoreboard objectives remove m.trig
scoreboard objectives remove metiers
scoreboard objectives remove m.b_lvl
scoreboard objectives remove m.b_xp
scoreboard objectives remove m.b_need
scoreboard objectives remove m.b_bal
scoreboard objectives remove m.b_spent
scoreboard objectives remove m.b_pal
team remove m.b0_0
team remove m.b0_1
team remove m.b0_2
team remove m.b0_3
team remove m.b0_4
team remove m.b0_5
team remove m.b1_0
team remove m.b1_1
team remove m.b1_2
team remove m.b1_3
team remove m.b1_4
team remove m.b1_5
team remove m.b2_0
team remove m.b2_1
team remove m.b2_2
team remove m.b2_3
team remove m.b2_4
team remove m.b2_5
team remove m.b3_0
team remove m.b3_1
team remove m.b3_2
team remove m.b3_3
team remove m.b3_4
team remove m.b3_5
team remove m.b4_0
team remove m.b4_1
team remove m.b4_2
team remove m.b4_3
team remove m.b4_4
team remove m.b4_5
team remove m.b5_0
team remove m.b5_1
team remove m.b5_2
team remove m.b5_3
team remove m.b5_4
team remove m.b5_5
team remove m.b6_0
team remove m.b6_1
team remove m.b6_2
team remove m.b6_3
team remove m.b6_4
team remove m.b6_5
team remove m.b7_0
team remove m.b7_1
team remove m.b7_2
team remove m.b7_3
team remove m.b7_4
team remove m.b7_5
team remove m.b8_0
team remove m.b8_1
team remove m.b8_2
team remove m.b8_3
team remove m.b8_4
team remove m.b8_5
team remove m.b9_0
team remove m.b9_1
team remove m.b9_2
team remove m.b9_3
team remove m.b9_4
team remove m.b9_5
team remove m.b10_0
team remove m.b10_1
team remove m.b10_2
team remove m.b10_3
team remove m.b10_4
team remove m.b10_5
scoreboard objectives remove m.f_lvl
scoreboard objectives remove m.f_xp
scoreboard objectives remove m.f_need
scoreboard objectives remove m.f_bal
scoreboard objectives remove m.f_spent
scoreboard objectives remove m.f_pal
team remove m.f0_0
team remove m.f0_1
team remove m.f0_2
team remove m.f0_3
team remove m.f0_4
team remove m.f0_5
team remove m.f1_0
team remove m.f1_1
team remove m.f1_2
team remove m.f1_3
team remove m.f1_4
team remove m.f1_5
team remove m.f2_0
team remove m.f2_1
team remove m.f2_2
team remove m.f2_3
team remove m.f2_4
team remove m.f2_5
team remove m.f3_0
team remove m.f3_1
team remove m.f3_2
team remove m.f3_3
team remove m.f3_4
team remove m.f3_5
team remove m.f4_0
team remove m.f4_1
team remove m.f4_2
team remove m.f4_3
team remove m.f4_4
team remove m.f4_5
team remove m.f5_0
team remove m.f5_1
team remove m.f5_2
team remove m.f5_3
team remove m.f5_4
team remove m.f5_5
team remove m.f6_0
team remove m.f6_1
team remove m.f6_2
team remove m.f6_3
team remove m.f6_4
team remove m.f6_5
team remove m.f7_0
team remove m.f7_1
team remove m.f7_2
team remove m.f7_3
team remove m.f7_4
team remove m.f7_5
team remove m.f8_0
team remove m.f8_1
team remove m.f8_2
team remove m.f8_3
team remove m.f8_4
team remove m.f8_5
team remove m.f9_0
team remove m.f9_1
team remove m.f9_2
team remove m.f9_3
team remove m.f9_4
team remove m.f9_5
team remove m.f10_0
team remove m.f10_1
team remove m.f10_2
team remove m.f10_3
team remove m.f10_4
team remove m.f10_5
scoreboard objectives remove m.m_lvl
scoreboard objectives remove m.m_xp
scoreboard objectives remove m.m_need
scoreboard objectives remove m.m_bal
scoreboard objectives remove m.m_spent
scoreboard objectives remove m.m_pal
team remove m.m0_0
team remove m.m0_1
team remove m.m0_2
team remove m.m0_3
team remove m.m0_4
team remove m.m0_5
team remove m.m1_0
team remove m.m1_1
team remove m.m1_2
team remove m.m1_3
team remove m.m1_4
team remove m.m1_5
team remove m.m2_0
team remove m.m2_1
team remove m.m2_2
team remove m.m2_3
team remove m.m2_4
team remove m.m2_5
team remove m.m3_0
team remove m.m3_1
team remove m.m3_2
team remove m.m3_3
team remove m.m3_4
team remove m.m3_5
team remove m.m4_0
team remove m.m4_1
team remove m.m4_2
team remove m.m4_3
team remove m.m4_4
team remove m.m4_5
team remove m.m5_0
team remove m.m5_1
team remove m.m5_2
team remove m.m5_3
team remove m.m5_4
team remove m.m5_5
team remove m.m6_0
team remove m.m6_1
team remove m.m6_2
team remove m.m6_3
team remove m.m6_4
team remove m.m6_5
team remove m.m7_0
team remove m.m7_1
team remove m.m7_2
team remove m.m7_3
team remove m.m7_4
team remove m.m7_5
team remove m.m8_0
team remove m.m8_1
team remove m.m8_2
team remove m.m8_3
team remove m.m8_4
team remove m.m8_5
team remove m.m9_0
team remove m.m9_1
team remove m.m9_2
team remove m.m9_3
team remove m.m9_4
team remove m.m9_5
team remove m.m10_0
team remove m.m10_1
team remove m.m10_2
team remove m.m10_3
team remove m.m10_4
team remove m.m10_5
scoreboard objectives remove m.c_lvl
scoreboard objectives remove m.c_xp
scoreboard objectives remove m.c_need
scoreboard objectives remove m.c_bal
scoreboard objectives remove m.c_spent
scoreboard objectives remove m.c_pal
team remove m.c0_0
team remove m.c0_1
team remove m.c0_2
team remove m.c0_3
team remove m.c0_4
team remove m.c0_5
team remove m.c1_0
team remove m.c1_1
team remove m.c1_2
team remove m.c1_3
team remove m.c1_4
team remove m.c1_5
team remove m.c2_0
team remove m.c2_1
team remove m.c2_2
team remove m.c2_3
team remove m.c2_4
team remove m.c2_5
team remove m.c3_0
team remove m.c3_1
team remove m.c3_2
team remove m.c3_3
team remove m.c3_4
team remove m.c3_5
team remove m.c4_0
team remove m.c4_1
team remove m.c4_2
team remove m.c4_3
team remove m.c4_4
team remove m.c4_5
team remove m.c5_0
team remove m.c5_1
team remove m.c5_2
team remove m.c5_3
team remove m.c5_4
team remove m.c5_5
team remove m.c6_0
team remove m.c6_1
team remove m.c6_2
team remove m.c6_3
team remove m.c6_4
team remove m.c6_5
team remove m.c7_0
team remove m.c7_1
team remove m.c7_2
team remove m.c7_3
team remove m.c7_4
team remove m.c7_5
team remove m.c8_0
team remove m.c8_1
team remove m.c8_2
team remove m.c8_3
team remove m.c8_4
team remove m.c8_5
team remove m.c9_0
team remove m.c9_1
team remove m.c9_2
team remove m.c9_3
team remove m.c9_4
team remove m.c9_5
team remove m.c10_0
team remove m.c10_1
team remove m.c10_2
team remove m.c10_3
team remove m.c10_4
team remove m.c10_5
scoreboard objectives remove m.p_lvl
scoreboard objectives remove m.p_xp
scoreboard objectives remove m.p_need
scoreboard objectives remove m.p_bal
scoreboard objectives remove m.p_spent
scoreboard objectives remove m.p_pal
team remove m.p0_0
team remove m.p0_1
team remove m.p0_2
team remove m.p0_3
team remove m.p0_4
team remove m.p0_5
team remove m.p1_0
team remove m.p1_1
team remove m.p1_2
team remove m.p1_3
team remove m.p1_4
team remove m.p1_5
team remove m.p2_0
team remove m.p2_1
team remove m.p2_2
team remove m.p2_3
team remove m.p2_4
team remove m.p2_5
team remove m.p3_0
team remove m.p3_1
team remove m.p3_2
team remove m.p3_3
team remove m.p3_4
team remove m.p3_5
team remove m.p4_0
team remove m.p4_1
team remove m.p4_2
team remove m.p4_3
team remove m.p4_4
team remove m.p4_5
team remove m.p5_0
team remove m.p5_1
team remove m.p5_2
team remove m.p5_3
team remove m.p5_4
team remove m.p5_5
team remove m.p6_0
team remove m.p6_1
team remove m.p6_2
team remove m.p6_3
team remove m.p6_4
team remove m.p6_5
team remove m.p7_0
team remove m.p7_1
team remove m.p7_2
team remove m.p7_3
team remove m.p7_4
team remove m.p7_5
team remove m.p8_0
team remove m.p8_1
team remove m.p8_2
team remove m.p8_3
team remove m.p8_4
team remove m.p8_5
team remove m.p9_0
team remove m.p9_1
team remove m.p9_2
team remove m.p9_3
team remove m.p9_4
team remove m.p9_5
team remove m.p10_0
team remove m.p10_1
team remove m.p10_2
team remove m.p10_3
team remove m.p10_4
team remove m.p10_5
scoreboard objectives remove m.e_lvl
scoreboard objectives remove m.e_xp
scoreboard objectives remove m.e_need
scoreboard objectives remove m.e_bal
scoreboard objectives remove m.e_spent
scoreboard objectives remove m.e_pal
team remove m.e0_0
team remove m.e0_1
team remove m.e0_2
team remove m.e0_3
team remove m.e0_4
team remove m.e0_5
team remove m.e1_0
team remove m.e1_1
team remove m.e1_2
team remove m.e1_3
team remove m.e1_4
team remove m.e1_5
team remove m.e2_0
team remove m.e2_1
team remove m.e2_2
team remove m.e2_3
team remove m.e2_4
team remove m.e2_5
team remove m.e3_0
team remove m.e3_1
team remove m.e3_2
team remove m.e3_3
team remove m.e3_4
team remove m.e3_5
team remove m.e4_0
team remove m.e4_1
team remove m.e4_2
team remove m.e4_3
team remove m.e4_4
team remove m.e4_5
team remove m.e5_0
team remove m.e5_1
team remove m.e5_2
team remove m.e5_3
team remove m.e5_4
team remove m.e5_5
team remove m.e6_0
team remove m.e6_1
team remove m.e6_2
team remove m.e6_3
team remove m.e6_4
team remove m.e6_5
team remove m.e7_0
team remove m.e7_1
team remove m.e7_2
team remove m.e7_3
team remove m.e7_4
team remove m.e7_5
team remove m.e8_0
team remove m.e8_1
team remove m.e8_2
team remove m.e8_3
team remove m.e8_4
team remove m.e8_5
team remove m.e9_0
team remove m.e9_1
team remove m.e9_2
team remove m.e9_3
team remove m.e9_4
team remove m.e9_5
team remove m.e10_0
team remove m.e10_1
team remove m.e10_2
team remove m.e10_3
team remove m.e10_4
team remove m.e10_5
scoreboard objectives remove m.n_lvl
scoreboard objectives remove m.n_xp
scoreboard objectives remove m.n_need
scoreboard objectives remove m.n_bal
scoreboard objectives remove m.n_spent
scoreboard objectives remove m.n_pal
team remove m.n0_0
team remove m.n0_1
team remove m.n0_2
team remove m.n0_3
team remove m.n0_4
team remove m.n0_5
team remove m.n1_0
team remove m.n1_1
team remove m.n1_2
team remove m.n1_3
team remove m.n1_4
team remove m.n1_5
team remove m.n2_0
team remove m.n2_1
team remove m.n2_2
team remove m.n2_3
team remove m.n2_4
team remove m.n2_5
team remove m.n3_0
team remove m.n3_1
team remove m.n3_2
team remove m.n3_3
team remove m.n3_4
team remove m.n3_5
team remove m.n4_0
team remove m.n4_1
team remove m.n4_2
team remove m.n4_3
team remove m.n4_4
team remove m.n4_5
team remove m.n5_0
team remove m.n5_1
team remove m.n5_2
team remove m.n5_3
team remove m.n5_4
team remove m.n5_5
team remove m.n6_0
team remove m.n6_1
team remove m.n6_2
team remove m.n6_3
team remove m.n6_4
team remove m.n6_5
team remove m.n7_0
team remove m.n7_1
team remove m.n7_2
team remove m.n7_3
team remove m.n7_4
team remove m.n7_5
team remove m.n8_0
team remove m.n8_1
team remove m.n8_2
team remove m.n8_3
team remove m.n8_4
team remove m.n8_5
team remove m.n9_0
team remove m.n9_1
team remove m.n9_2
team remove m.n9_3
team remove m.n9_4
team remove m.n9_5
team remove m.n10_0
team remove m.n10_1
team remove m.n10_2
team remove m.n10_3
team remove m.n10_4
team remove m.n10_5
scoreboard objectives remove m.x_lvl
scoreboard objectives remove m.x_xp
scoreboard objectives remove m.x_need
scoreboard objectives remove m.x_bal
scoreboard objectives remove m.x_spent
scoreboard objectives remove m.x_pal
team remove m.x0_0
team remove m.x0_1
team remove m.x0_2
team remove m.x0_3
team remove m.x0_4
team remove m.x0_5
team remove m.x1_0
team remove m.x1_1
team remove m.x1_2
team remove m.x1_3
team remove m.x1_4
team remove m.x1_5
team remove m.x2_0
team remove m.x2_1
team remove m.x2_2
team remove m.x2_3
team remove m.x2_4
team remove m.x2_5
team remove m.x3_0
team remove m.x3_1
team remove m.x3_2
team remove m.x3_3
team remove m.x3_4
team remove m.x3_5
team remove m.x4_0
team remove m.x4_1
team remove m.x4_2
team remove m.x4_3
team remove m.x4_4
team remove m.x4_5
team remove m.x5_0
team remove m.x5_1
team remove m.x5_2
team remove m.x5_3
team remove m.x5_4
team remove m.x5_5
team remove m.x6_0
team remove m.x6_1
team remove m.x6_2
team remove m.x6_3
team remove m.x6_4
team remove m.x6_5
team remove m.x7_0
team remove m.x7_1
team remove m.x7_2
team remove m.x7_3
team remove m.x7_4
team remove m.x7_5
team remove m.x8_0
team remove m.x8_1
team remove m.x8_2
team remove m.x8_3
team remove m.x8_4
team remove m.x8_5
team remove m.x9_0
team remove m.x9_1
team remove m.x9_2
team remove m.x9_3
team remove m.x9_4
team remove m.x9_5
team remove m.x10_0
team remove m.x10_1
team remove m.x10_2
team remove m.x10_3
team remove m.x10_4
team remove m.x10_5
scoreboard objectives remove m.t_lvl
scoreboard objectives remove m.t_xp
scoreboard objectives remove m.t_need
scoreboard objectives remove m.t_bal
scoreboard objectives remove m.t_spent
scoreboard objectives remove m.t_pal
team remove m.t0_0
team remove m.t0_1
team remove m.t0_2
team remove m.t0_3
team remove m.t0_4
team remove m.t0_5
team remove m.t1_0
team remove m.t1_1
team remove m.t1_2
team remove m.t1_3
team remove m.t1_4
team remove m.t1_5
team remove m.t2_0
team remove m.t2_1
team remove m.t2_2
team remove m.t2_3
team remove m.t2_4
team remove m.t2_5
team remove m.t3_0
team remove m.t3_1
team remove m.t3_2
team remove m.t3_3
team remove m.t3_4
team remove m.t3_5
team remove m.t4_0
team remove m.t4_1
team remove m.t4_2
team remove m.t4_3
team remove m.t4_4
team remove m.t4_5
team remove m.t5_0
team remove m.t5_1
team remove m.t5_2
team remove m.t5_3
team remove m.t5_4
team remove m.t5_5
team remove m.t6_0
team remove m.t6_1
team remove m.t6_2
team remove m.t6_3
team remove m.t6_4
team remove m.t6_5
team remove m.t7_0
team remove m.t7_1
team remove m.t7_2
team remove m.t7_3
team remove m.t7_4
team remove m.t7_5
team remove m.t8_0
team remove m.t8_1
team remove m.t8_2
team remove m.t8_3
team remove m.t8_4
team remove m.t8_5
team remove m.t9_0
team remove m.t9_1
team remove m.t9_2
team remove m.t9_3
team remove m.t9_4
team remove m.t9_5
team remove m.t10_0
team remove m.t10_1
team remove m.t10_2
team remove m.t10_3
team remove m.t10_4
team remove m.t10_5
scoreboard objectives remove m.k_lvl
scoreboard objectives remove m.k_xp
scoreboard objectives remove m.k_need
scoreboard objectives remove m.k_bal
scoreboard objectives remove m.k_spent
scoreboard objectives remove m.k_pal
team remove m.k0_0
team remove m.k0_1
team remove m.k0_2
team remove m.k0_3
team remove m.k0_4
team remove m.k0_5
team remove m.k1_0
team remove m.k1_1
team remove m.k1_2
team remove m.k1_3
team remove m.k1_4
team remove m.k1_5
team remove m.k2_0
team remove m.k2_1
team remove m.k2_2
team remove m.k2_3
team remove m.k2_4
team remove m.k2_5
team remove m.k3_0
team remove m.k3_1
team remove m.k3_2
team remove m.k3_3
team remove m.k3_4
team remove m.k3_5
team remove m.k4_0
team remove m.k4_1
team remove m.k4_2
team remove m.k4_3
team remove m.k4_4
team remove m.k4_5
team remove m.k5_0
team remove m.k5_1
team remove m.k5_2
team remove m.k5_3
team remove m.k5_4
team remove m.k5_5
team remove m.k6_0
team remove m.k6_1
team remove m.k6_2
team remove m.k6_3
team remove m.k6_4
team remove m.k6_5
team remove m.k7_0
team remove m.k7_1
team remove m.k7_2
team remove m.k7_3
team remove m.k7_4
team remove m.k7_5
team remove m.k8_0
team remove m.k8_1
team remove m.k8_2
team remove m.k8_3
team remove m.k8_4
team remove m.k8_5
team remove m.k9_0
team remove m.k9_1
team remove m.k9_2
team remove m.k9_3
team remove m.k9_4
team remove m.k9_5
team remove m.k10_0
team remove m.k10_1
team remove m.k10_2
team remove m.k10_3
team remove m.k10_4
team remove m.k10_5
scoreboard objectives remove s.b.mi.oak_log
scoreboard objectives remove s.b.us.oak_log
scoreboard objectives remove s.b.mi.stripped_oak_log
scoreboard objectives remove s.b.us.stripped_oak_log
scoreboard objectives remove s.b.mi.oak_wood
scoreboard objectives remove s.b.us.oak_wood
scoreboard objectives remove s.b.mi.stripped_oak_wood
scoreboard objectives remove s.b.us.stripped_oak_wood
scoreboard objectives remove s.b.mi.spruce_log
scoreboard objectives remove s.b.us.spruce_log
scoreboard objectives remove s.b.mi.stripped_spruce_log
scoreboard objectives remove s.b.us.stripped_spruce_log
scoreboard objectives remove s.b.mi.spruce_wood
scoreboard objectives remove s.b.us.spruce_wood
scoreboard objectives remove s.b.mi.stripped_spruce_wood
scoreboard objectives remove s.b.us.stripped_spruce_wood
scoreboard objectives remove s.b.mi.birch_log
scoreboard objectives remove s.b.us.birch_log
scoreboard objectives remove s.b.mi.stripped_birch_log
scoreboard objectives remove s.b.us.stripped_birch_log
scoreboard objectives remove s.b.mi.birch_wood
scoreboard objectives remove s.b.us.birch_wood
scoreboard objectives remove s.b.mi.stripped_birch_wood
scoreboard objectives remove s.b.us.stripped_birch_wood
scoreboard objectives remove s.b.mi.jungle_log
scoreboard objectives remove s.b.us.jungle_log
scoreboard objectives remove s.b.mi.stripped_jungle_log
scoreboard objectives remove s.b.us.stripped_jungle_log
scoreboard objectives remove s.b.mi.jungle_wood
scoreboard objectives remove s.b.us.jungle_wood
scoreboard objectives remove s.b.mi.stripped_jungle_wood
scoreboard objectives remove s.b.us.stripped_jungle_wood
scoreboard objectives remove s.b.mi.acacia_log
scoreboard objectives remove s.b.us.acacia_log
scoreboard objectives remove s.b.mi.stripped_acacia_log
scoreboard objectives remove s.b.us.stripped_acacia_log
scoreboard objectives remove s.b.mi.acacia_wood
scoreboard objectives remove s.b.us.acacia_wood
scoreboard objectives remove s.b.mi.stripped_acacia_wood
scoreboard objectives remove s.b.us.stripped_acacia_wood
scoreboard objectives remove s.b.mi.dark_oak_log
scoreboard objectives remove s.b.us.dark_oak_log
scoreboard objectives remove s.b.mi.stripped_dark_oak_log
scoreboard objectives remove s.b.us.stripped_dark_oak_log
scoreboard objectives remove s.b.mi.dark_oak_wood
scoreboard objectives remove s.b.us.dark_oak_wood
scoreboard objectives remove s.b.mi.stripped_dark_oak_wood
scoreboard objectives remove s.b.us.stripped_dark_oak_wood
scoreboard objectives remove s.b.mi.mangrove_log
scoreboard objectives remove s.b.us.mangrove_log
scoreboard objectives remove s.b.mi.stripped_mangrove_log
scoreboard objectives remove s.b.us.stripped_mangrove_log
scoreboard objectives remove s.b.mi.mangrove_wood
scoreboard objectives remove s.b.us.mangrove_wood
scoreboard objectives remove s.b.mi.stripped_mangrove_wood
scoreboard objectives remove s.b.us.stripped_mangrove_wood
scoreboard objectives remove s.b.mi.cherry_log
scoreboard objectives remove s.b.us.cherry_log
scoreboard objectives remove s.b.mi.stripped_cherry_log
scoreboard objectives remove s.b.us.stripped_cherry_log
scoreboard objectives remove s.b.mi.cherry_wood
scoreboard objectives remove s.b.us.cherry_wood
scoreboard objectives remove s.b.mi.stripped_cherry_wood
scoreboard objectives remove s.b.us.stripped_cherry_wood
scoreboard objectives remove s.b.mi.pale_oak_log
scoreboard objectives remove s.b.us.pale_oak_log
scoreboard objectives remove s.b.mi.stripped_pale_oak_log
scoreboard objectives remove s.b.us.stripped_pale_oak_log
scoreboard objectives remove s.b.mi.pale_oak_wood
scoreboard objectives remove s.b.us.pale_oak_wood
scoreboard objectives remove s.b.mi.stripped_pale_oak_wood
scoreboard objectives remove s.b.us.stripped_pale_oak_wood
scoreboard objectives remove s.b.mi.crimson_stem
scoreboard objectives remove s.b.us.crimson_stem
scoreboard objectives remove s.b.mi.stripped_crimson_stem
scoreboard objectives remove s.b.us.stripped_crimson_stem
scoreboard objectives remove s.b.mi.crimson_hyphae
scoreboard objectives remove s.b.us.crimson_hyphae
scoreboard objectives remove s.b.mi.stripped_crimson_hyphae
scoreboard objectives remove s.b.us.stripped_crimson_hyphae
scoreboard objectives remove s.b.mi.warped_stem
scoreboard objectives remove s.b.us.warped_stem
scoreboard objectives remove s.b.mi.stripped_warped_stem
scoreboard objectives remove s.b.us.stripped_warped_stem
scoreboard objectives remove s.b.mi.warped_hyphae
scoreboard objectives remove s.b.us.warped_hyphae
scoreboard objectives remove s.b.mi.stripped_warped_hyphae
scoreboard objectives remove s.b.us.stripped_warped_hyphae
scoreboard objectives remove s.f.pu.wheat
scoreboard objectives remove s.f.dr.wheat
scoreboard objectives remove s.f.pu.carrot
scoreboard objectives remove s.f.dr.carrot
scoreboard objectives remove s.f.us.carrot
scoreboard objectives remove s.f.pu.potato
scoreboard objectives remove s.f.dr.potato
scoreboard objectives remove s.f.us.potato
scoreboard objectives remove s.f.pu.beetroot
scoreboard objectives remove s.f.dr.beetroot
scoreboard objectives remove s.f.pu.nether_wart
scoreboard objectives remove s.f.dr.nether_wart
scoreboard objectives remove s.f.us.nether_wart
scoreboard objectives remove s.f.pu.sweet_berries
scoreboard objectives remove s.f.dr.sweet_berries
scoreboard objectives remove s.f.us.sweet_berries
scoreboard objectives remove s.f.pu.glow_berries
scoreboard objectives remove s.f.dr.glow_berries
scoreboard objectives remove s.f.us.glow_berries
scoreboard objectives remove s.f.mi.melon
scoreboard objectives remove s.f.up.melon
scoreboard objectives remove s.f.mi.pumpkin
scoreboard objectives remove s.f.up.pumpkin
scoreboard objectives remove s.f.mi.sugar_cane
scoreboard objectives remove s.f.up.sugar_cane
scoreboard objectives remove s.f.mi.cocoa
scoreboard objectives remove s.f.up.cocoa
scoreboard objectives remove s.f.mi.cactus
scoreboard objectives remove s.f.up.cactus
scoreboard objectives remove s.m.mi.stone
scoreboard objectives remove s.m.us.stone
scoreboard objectives remove s.m.mi.deepslate
scoreboard objectives remove s.m.us.deepslate
scoreboard objectives remove s.m.mi.andesite
scoreboard objectives remove s.m.us.andesite
scoreboard objectives remove s.m.mi.diorite
scoreboard objectives remove s.m.us.diorite
scoreboard objectives remove s.m.mi.granite
scoreboard objectives remove s.m.us.granite
scoreboard objectives remove s.m.mi.tuff
scoreboard objectives remove s.m.us.tuff
scoreboard objectives remove s.m.mi.blackstone
scoreboard objectives remove s.m.us.blackstone
scoreboard objectives remove s.m.mi.netherrack
scoreboard objectives remove s.m.us.netherrack
scoreboard objectives remove s.m.mi.basalt
scoreboard objectives remove s.m.us.basalt
scoreboard objectives remove s.m.mi.smooth_basalt
scoreboard objectives remove s.m.us.smooth_basalt
scoreboard objectives remove s.m.mi.calcite
scoreboard objectives remove s.m.us.calcite
scoreboard objectives remove s.m.mi.dripstone_block
scoreboard objectives remove s.m.us.dripstone_block
scoreboard objectives remove s.m.mi.end_stone
scoreboard objectives remove s.m.us.end_stone
scoreboard objectives remove s.m.mi.sandstone
scoreboard objectives remove s.m.us.sandstone
scoreboard objectives remove s.m.mi.red_sandstone
scoreboard objectives remove s.m.us.red_sandstone
scoreboard objectives remove s.m.mi.obsidian
scoreboard objectives remove s.m.us.obsidian
scoreboard objectives remove s.m.mi.crying_obsidian
scoreboard objectives remove s.m.us.crying_obsidian
scoreboard objectives remove s.m.mi.coal_ore
scoreboard objectives remove s.m.us.coal_ore
scoreboard objectives remove s.m.mi.deepslate_coal_ore
scoreboard objectives remove s.m.us.deepslate_coal_ore
scoreboard objectives remove s.m.mi.copper_ore
scoreboard objectives remove s.m.us.copper_ore
scoreboard objectives remove s.m.mi.deepslate_copper_ore
scoreboard objectives remove s.m.us.deepslate_copper_ore
scoreboard objectives remove s.m.mi.iron_ore
scoreboard objectives remove s.m.us.iron_ore
scoreboard objectives remove s.m.mi.deepslate_iron_ore
scoreboard objectives remove s.m.us.deepslate_iron_ore
scoreboard objectives remove s.m.mi.gold_ore
scoreboard objectives remove s.m.us.gold_ore
scoreboard objectives remove s.m.mi.deepslate_gold_ore
scoreboard objectives remove s.m.us.deepslate_gold_ore
scoreboard objectives remove s.m.mi.redstone_ore
scoreboard objectives remove s.m.us.redstone_ore
scoreboard objectives remove s.m.mi.deepslate_redstone_ore
scoreboard objectives remove s.m.us.deepslate_redstone_ore
scoreboard objectives remove s.m.mi.lapis_ore
scoreboard objectives remove s.m.us.lapis_ore
scoreboard objectives remove s.m.mi.deepslate_lapis_ore
scoreboard objectives remove s.m.us.deepslate_lapis_ore
scoreboard objectives remove s.m.mi.diamond_ore
scoreboard objectives remove s.m.us.diamond_ore
scoreboard objectives remove s.m.mi.deepslate_diamond_ore
scoreboard objectives remove s.m.us.deepslate_diamond_ore
scoreboard objectives remove s.m.mi.emerald_ore
scoreboard objectives remove s.m.us.emerald_ore
scoreboard objectives remove s.m.mi.deepslate_emerald_ore
scoreboard objectives remove s.m.us.deepslate_emerald_ore
scoreboard objectives remove s.m.mi.nether_gold_ore
scoreboard objectives remove s.m.us.nether_gold_ore
scoreboard objectives remove s.m.mi.nether_quartz_ore
scoreboard objectives remove s.m.us.nether_quartz_ore
scoreboard objectives remove s.m.mi.ancient_debris
scoreboard objectives remove s.m.us.ancient_debris
scoreboard objectives remove s.c.k.chicken
scoreboard objectives remove s.c.k.cow
scoreboard objectives remove s.c.k.pig
scoreboard objectives remove s.c.k.sheep
scoreboard objectives remove s.c.k.rabbit
scoreboard objectives remove s.c.k.goat
scoreboard objectives remove s.c.k.mooshroom
scoreboard objectives remove s.c.k.silverfish
scoreboard objectives remove s.c.k.slime
scoreboard objectives remove s.c.k.magma_cube
scoreboard objectives remove s.c.k.zombie
scoreboard objectives remove s.c.k.husk
scoreboard objectives remove s.c.k.zombie_villager
scoreboard objectives remove s.c.k.spider
scoreboard objectives remove s.c.k.piglin
scoreboard objectives remove s.c.k.zombified_piglin
scoreboard objectives remove s.c.k.drowned
scoreboard objectives remove s.c.k.skeleton
scoreboard objectives remove s.c.k.cave_spider
scoreboard objectives remove s.c.k.vex
scoreboard objectives remove s.c.k.stray
scoreboard objectives remove s.c.k.bogged
scoreboard objectives remove s.c.k.creeper
scoreboard objectives remove s.c.k.phantom
scoreboard objectives remove s.c.k.pillager
scoreboard objectives remove s.c.k.witch
scoreboard objectives remove s.c.k.enderman
scoreboard objectives remove s.c.k.blaze
scoreboard objectives remove s.c.k.guardian
scoreboard objectives remove s.c.k.hoglin
scoreboard objectives remove s.c.k.creaking
scoreboard objectives remove s.c.k.vindicator
scoreboard objectives remove s.c.k.shulker
scoreboard objectives remove s.c.k.zoglin
scoreboard objectives remove s.c.k.ghast
scoreboard objectives remove s.c.k.wither_skeleton
scoreboard objectives remove s.c.k.breeze
scoreboard objectives remove s.c.k.piglin_brute
scoreboard objectives remove s.c.k.evoker
scoreboard objectives remove s.c.k.ravager
scoreboard objectives remove s.c.kills
scoreboard objectives remove s.c.k.wither
scoreboard objectives remove s.c.k.ender_dragon
scoreboard objectives remove s.c.k.warden
scoreboard objectives remove s.c.k.elder_guardian
scoreboard objectives remove s.p.fish
scoreboard objectives remove s.e.bred
scoreboard objectives remove s.e.pu.white
scoreboard objectives remove s.e.dr.white
scoreboard objectives remove s.e.us.white
scoreboard objectives remove s.e.pu.black
scoreboard objectives remove s.e.dr.black
scoreboard objectives remove s.e.us.black
scoreboard objectives remove s.e.pu.gray
scoreboard objectives remove s.e.dr.gray
scoreboard objectives remove s.e.us.gray
scoreboard objectives remove s.e.pu.light_gray
scoreboard objectives remove s.e.dr.light_gray
scoreboard objectives remove s.e.us.light_gray
scoreboard objectives remove s.e.pu.brown
scoreboard objectives remove s.e.dr.brown
scoreboard objectives remove s.e.us.brown
scoreboard objectives remove s.e.pu.red
scoreboard objectives remove s.e.dr.red
scoreboard objectives remove s.e.us.red
scoreboard objectives remove s.e.pu.orange
scoreboard objectives remove s.e.dr.orange
scoreboard objectives remove s.e.us.orange
scoreboard objectives remove s.e.pu.yellow
scoreboard objectives remove s.e.dr.yellow
scoreboard objectives remove s.e.us.yellow
scoreboard objectives remove s.e.pu.lime
scoreboard objectives remove s.e.dr.lime
scoreboard objectives remove s.e.us.lime
scoreboard objectives remove s.e.pu.green
scoreboard objectives remove s.e.dr.green
scoreboard objectives remove s.e.us.green
scoreboard objectives remove s.e.pu.cyan
scoreboard objectives remove s.e.dr.cyan
scoreboard objectives remove s.e.us.cyan
scoreboard objectives remove s.e.pu.light_blue
scoreboard objectives remove s.e.dr.light_blue
scoreboard objectives remove s.e.us.light_blue
scoreboard objectives remove s.e.pu.blue
scoreboard objectives remove s.e.dr.blue
scoreboard objectives remove s.e.us.blue
scoreboard objectives remove s.e.pu.purple
scoreboard objectives remove s.e.dr.purple
scoreboard objectives remove s.e.us.purple
scoreboard objectives remove s.e.pu.magenta
scoreboard objectives remove s.e.dr.magenta
scoreboard objectives remove s.e.us.magenta
scoreboard objectives remove s.e.pu.pink
scoreboard objectives remove s.e.dr.pink
scoreboard objectives remove s.e.us.pink
scoreboard objectives remove s.n.ench
scoreboard objectives remove s.n.shelf
scoreboard objectives remove s.n.shelfmi
scoreboard objectives remove s.t.trade
scoreboard objectives remove s.k.us.oak_planks
scoreboard objectives remove s.k.mi.oak_planks
scoreboard objectives remove s.k.us.spruce_planks
scoreboard objectives remove s.k.mi.spruce_planks
scoreboard objectives remove s.k.us.birch_planks
scoreboard objectives remove s.k.mi.birch_planks
scoreboard objectives remove s.k.us.jungle_planks
scoreboard objectives remove s.k.mi.jungle_planks
scoreboard objectives remove s.k.us.acacia_planks
scoreboard objectives remove s.k.mi.acacia_planks
scoreboard objectives remove s.k.us.dark_oak_planks
scoreboard objectives remove s.k.mi.dark_oak_planks
scoreboard objectives remove s.k.us.mangrove_planks
scoreboard objectives remove s.k.mi.mangrove_planks
scoreboard objectives remove s.k.us.cherry_planks
scoreboard objectives remove s.k.mi.cherry_planks
scoreboard objectives remove s.k.us.pale_oak_planks
scoreboard objectives remove s.k.mi.pale_oak_planks
scoreboard objectives remove s.k.us.bamboo_planks
scoreboard objectives remove s.k.mi.bamboo_planks
scoreboard objectives remove s.k.us.crimson_planks
scoreboard objectives remove s.k.mi.crimson_planks
scoreboard objectives remove s.k.us.warped_planks
scoreboard objectives remove s.k.mi.warped_planks
scoreboard objectives remove s.k.us.oak_stairs
scoreboard objectives remove s.k.mi.oak_stairs
scoreboard objectives remove s.k.us.spruce_stairs
scoreboard objectives remove s.k.mi.spruce_stairs
scoreboard objectives remove s.k.us.birch_stairs
scoreboard objectives remove s.k.mi.birch_stairs
scoreboard objectives remove s.k.us.jungle_stairs
scoreboard objectives remove s.k.mi.jungle_stairs
scoreboard objectives remove s.k.us.acacia_stairs
scoreboard objectives remove s.k.mi.acacia_stairs
scoreboard objectives remove s.k.us.dark_oak_stairs
scoreboard objectives remove s.k.mi.dark_oak_stairs
scoreboard objectives remove s.k.us.mangrove_stairs
scoreboard objectives remove s.k.mi.mangrove_stairs
scoreboard objectives remove s.k.us.cherry_stairs
scoreboard objectives remove s.k.mi.cherry_stairs
scoreboard objectives remove s.k.us.pale_oak_stairs
scoreboard objectives remove s.k.mi.pale_oak_stairs
scoreboard objectives remove s.k.us.bamboo_stairs
scoreboard objectives remove s.k.mi.bamboo_stairs
scoreboard objectives remove s.k.us.crimson_stairs
scoreboard objectives remove s.k.mi.crimson_stairs
scoreboard objectives remove s.k.us.warped_stairs
scoreboard objectives remove s.k.mi.warped_stairs
scoreboard objectives remove s.k.us.oak_slab
scoreboard objectives remove s.k.mi.oak_slab
scoreboard objectives remove s.k.us.spruce_slab
scoreboard objectives remove s.k.mi.spruce_slab
scoreboard objectives remove s.k.us.birch_slab
scoreboard objectives remove s.k.mi.birch_slab
scoreboard objectives remove s.k.us.jungle_slab
scoreboard objectives remove s.k.mi.jungle_slab
scoreboard objectives remove s.k.us.acacia_slab
scoreboard objectives remove s.k.mi.acacia_slab
scoreboard objectives remove s.k.us.dark_oak_slab
scoreboard objectives remove s.k.mi.dark_oak_slab
scoreboard objectives remove s.k.us.mangrove_slab
scoreboard objectives remove s.k.mi.mangrove_slab
scoreboard objectives remove s.k.us.cherry_slab
scoreboard objectives remove s.k.mi.cherry_slab
scoreboard objectives remove s.k.us.pale_oak_slab
scoreboard objectives remove s.k.mi.pale_oak_slab
scoreboard objectives remove s.k.us.bamboo_slab
scoreboard objectives remove s.k.mi.bamboo_slab
scoreboard objectives remove s.k.us.crimson_slab
scoreboard objectives remove s.k.mi.crimson_slab
scoreboard objectives remove s.k.us.warped_slab
scoreboard objectives remove s.k.mi.warped_slab
scoreboard objectives remove s.k.us.oak_fence
scoreboard objectives remove s.k.mi.oak_fence
scoreboard objectives remove s.k.us.spruce_fence
scoreboard objectives remove s.k.mi.spruce_fence
scoreboard objectives remove s.k.us.birch_fence
scoreboard objectives remove s.k.mi.birch_fence
scoreboard objectives remove s.k.us.jungle_fence
scoreboard objectives remove s.k.mi.jungle_fence
scoreboard objectives remove s.k.us.acacia_fence
scoreboard objectives remove s.k.mi.acacia_fence
scoreboard objectives remove s.k.us.dark_oak_fence
scoreboard objectives remove s.k.mi.dark_oak_fence
scoreboard objectives remove s.k.us.mangrove_fence
scoreboard objectives remove s.k.mi.mangrove_fence
scoreboard objectives remove s.k.us.cherry_fence
scoreboard objectives remove s.k.mi.cherry_fence
scoreboard objectives remove s.k.us.pale_oak_fence
scoreboard objectives remove s.k.mi.pale_oak_fence
scoreboard objectives remove s.k.us.bamboo_fence
scoreboard objectives remove s.k.mi.bamboo_fence
scoreboard objectives remove s.k.us.crimson_fence
scoreboard objectives remove s.k.mi.crimson_fence
scoreboard objectives remove s.k.us.warped_fence
scoreboard objectives remove s.k.mi.warped_fence
scoreboard objectives remove s.k.us.oak_door
scoreboard objectives remove s.k.mi.oak_door
scoreboard objectives remove s.k.us.spruce_door
scoreboard objectives remove s.k.mi.spruce_door
scoreboard objectives remove s.k.us.birch_door
scoreboard objectives remove s.k.mi.birch_door
scoreboard objectives remove s.k.us.jungle_door
scoreboard objectives remove s.k.mi.jungle_door
scoreboard objectives remove s.k.us.acacia_door
scoreboard objectives remove s.k.mi.acacia_door
scoreboard objectives remove s.k.us.dark_oak_door
scoreboard objectives remove s.k.mi.dark_oak_door
scoreboard objectives remove s.k.us.mangrove_door
scoreboard objectives remove s.k.mi.mangrove_door
scoreboard objectives remove s.k.us.cherry_door
scoreboard objectives remove s.k.mi.cherry_door
scoreboard objectives remove s.k.us.pale_oak_door
scoreboard objectives remove s.k.mi.pale_oak_door
scoreboard objectives remove s.k.us.bamboo_door
scoreboard objectives remove s.k.mi.bamboo_door
scoreboard objectives remove s.k.us.crimson_door
scoreboard objectives remove s.k.mi.crimson_door
scoreboard objectives remove s.k.us.warped_door
scoreboard objectives remove s.k.mi.warped_door
scoreboard objectives remove s.k.us.oak_trapdoor
scoreboard objectives remove s.k.mi.oak_trapdoor
scoreboard objectives remove s.k.us.spruce_trapdoor
scoreboard objectives remove s.k.mi.spruce_trapdoor
scoreboard objectives remove s.k.us.birch_trapdoor
scoreboard objectives remove s.k.mi.birch_trapdoor
scoreboard objectives remove s.k.us.jungle_trapdoor
scoreboard objectives remove s.k.mi.jungle_trapdoor
scoreboard objectives remove s.k.us.acacia_trapdoor
scoreboard objectives remove s.k.mi.acacia_trapdoor
scoreboard objectives remove s.k.us.dark_oak_trapdoor
scoreboard objectives remove s.k.mi.dark_oak_trapdoor
scoreboard objectives remove s.k.us.mangrove_trapdoor
scoreboard objectives remove s.k.mi.mangrove_trapdoor
scoreboard objectives remove s.k.us.cherry_trapdoor
scoreboard objectives remove s.k.mi.cherry_trapdoor
scoreboard objectives remove s.k.us.pale_oak_trapdoor
scoreboard objectives remove s.k.mi.pale_oak_trapdoor
scoreboard objectives remove s.k.us.bamboo_trapdoor
scoreboard objectives remove s.k.mi.bamboo_trapdoor
scoreboard objectives remove s.k.us.crimson_trapdoor
scoreboard objectives remove s.k.mi.crimson_trapdoor
scoreboard objectives remove s.k.us.warped_trapdoor
scoreboard objectives remove s.k.mi.warped_trapdoor
scoreboard objectives remove s.k.us.cobblestone
scoreboard objectives remove s.k.mi.cobblestone
scoreboard objectives remove s.k.us.mossy_cobblestone
scoreboard objectives remove s.k.mi.mossy_cobblestone
scoreboard objectives remove s.k.us.stone_bricks
scoreboard objectives remove s.k.mi.stone_bricks
scoreboard objectives remove s.k.us.mossy_stone_bricks
scoreboard objectives remove s.k.mi.mossy_stone_bricks
scoreboard objectives remove s.k.us.cracked_stone_bricks
scoreboard objectives remove s.k.mi.cracked_stone_bricks
scoreboard objectives remove s.k.us.chiseled_stone_bricks
scoreboard objectives remove s.k.mi.chiseled_stone_bricks
scoreboard objectives remove s.k.us.smooth_stone
scoreboard objectives remove s.k.mi.smooth_stone
scoreboard objectives remove s.k.us.bricks
scoreboard objectives remove s.k.mi.bricks
scoreboard objectives remove s.k.us.mud_bricks
scoreboard objectives remove s.k.mi.mud_bricks
scoreboard objectives remove s.k.us.deepslate_bricks
scoreboard objectives remove s.k.mi.deepslate_bricks
scoreboard objectives remove s.k.us.deepslate_tiles
scoreboard objectives remove s.k.mi.deepslate_tiles
scoreboard objectives remove s.k.us.polished_deepslate
scoreboard objectives remove s.k.mi.polished_deepslate
scoreboard objectives remove s.k.us.cobbled_deepslate
scoreboard objectives remove s.k.mi.cobbled_deepslate
scoreboard objectives remove s.k.us.polished_andesite
scoreboard objectives remove s.k.mi.polished_andesite
scoreboard objectives remove s.k.us.polished_diorite
scoreboard objectives remove s.k.mi.polished_diorite
scoreboard objectives remove s.k.us.polished_granite
scoreboard objectives remove s.k.mi.polished_granite
scoreboard objectives remove s.k.us.polished_blackstone
scoreboard objectives remove s.k.mi.polished_blackstone
scoreboard objectives remove s.k.us.polished_blackstone_bricks
scoreboard objectives remove s.k.mi.polished_blackstone_bricks
scoreboard objectives remove s.k.us.polished_tuff
scoreboard objectives remove s.k.mi.polished_tuff
scoreboard objectives remove s.k.us.tuff_bricks
scoreboard objectives remove s.k.mi.tuff_bricks
scoreboard objectives remove s.k.us.nether_bricks
scoreboard objectives remove s.k.mi.nether_bricks
scoreboard objectives remove s.k.us.red_nether_bricks
scoreboard objectives remove s.k.mi.red_nether_bricks
scoreboard objectives remove s.k.us.end_stone_bricks
scoreboard objectives remove s.k.mi.end_stone_bricks
scoreboard objectives remove s.k.us.prismarine_bricks
scoreboard objectives remove s.k.mi.prismarine_bricks
scoreboard objectives remove s.k.us.dark_prismarine
scoreboard objectives remove s.k.mi.dark_prismarine
scoreboard objectives remove s.k.us.quartz_block
scoreboard objectives remove s.k.mi.quartz_block
scoreboard objectives remove s.k.us.quartz_bricks
scoreboard objectives remove s.k.mi.quartz_bricks
scoreboard objectives remove s.k.us.quartz_pillar
scoreboard objectives remove s.k.mi.quartz_pillar
scoreboard objectives remove s.k.us.smooth_quartz
scoreboard objectives remove s.k.mi.smooth_quartz
scoreboard objectives remove s.k.us.smooth_sandstone
scoreboard objectives remove s.k.mi.smooth_sandstone
scoreboard objectives remove s.k.us.cut_sandstone
scoreboard objectives remove s.k.mi.cut_sandstone
scoreboard objectives remove s.k.us.smooth_red_sandstone
scoreboard objectives remove s.k.mi.smooth_red_sandstone
scoreboard objectives remove s.k.us.cut_red_sandstone
scoreboard objectives remove s.k.mi.cut_red_sandstone
scoreboard objectives remove s.k.us.glass
scoreboard objectives remove s.k.mi.glass
scoreboard objectives remove s.k.us.glass_pane
scoreboard objectives remove s.k.mi.glass_pane
scoreboard objectives remove s.k.us.terracotta
scoreboard objectives remove s.k.mi.terracotta
scoreboard objectives remove s.k.us.lantern
scoreboard objectives remove s.k.mi.lantern
scoreboard objectives remove s.k.us.iron_bars
scoreboard objectives remove s.k.mi.iron_bars
scoreboard objectives remove s.k.us.iron_chain
scoreboard objectives remove s.k.mi.iron_chain
scoreboard objectives remove s.k.us.ladder
scoreboard objectives remove s.k.mi.ladder
scoreboard objectives remove s.k.us.cobblestone_stairs
scoreboard objectives remove s.k.mi.cobblestone_stairs
scoreboard objectives remove s.k.us.cobblestone_slab
scoreboard objectives remove s.k.mi.cobblestone_slab
scoreboard objectives remove s.k.us.cobblestone_wall
scoreboard objectives remove s.k.mi.cobblestone_wall
scoreboard objectives remove s.k.us.stone_brick_stairs
scoreboard objectives remove s.k.mi.stone_brick_stairs
scoreboard objectives remove s.k.us.stone_brick_slab
scoreboard objectives remove s.k.mi.stone_brick_slab
scoreboard objectives remove s.k.us.stone_brick_wall
scoreboard objectives remove s.k.mi.stone_brick_wall
scoreboard objectives remove s.k.us.brick_stairs
scoreboard objectives remove s.k.mi.brick_stairs
scoreboard objectives remove s.k.us.brick_slab
scoreboard objectives remove s.k.mi.brick_slab
scoreboard objectives remove s.k.us.brick_wall
scoreboard objectives remove s.k.mi.brick_wall
scoreboard objectives remove s.k.us.deepslate_brick_stairs
scoreboard objectives remove s.k.mi.deepslate_brick_stairs
scoreboard objectives remove s.k.us.deepslate_brick_slab
scoreboard objectives remove s.k.mi.deepslate_brick_slab
scoreboard objectives remove s.k.us.deepslate_tile_stairs
scoreboard objectives remove s.k.mi.deepslate_tile_stairs
scoreboard objectives remove s.k.us.deepslate_tile_slab
scoreboard objectives remove s.k.mi.deepslate_tile_slab
scoreboard objectives remove s.k.us.quartz_stairs
scoreboard objectives remove s.k.mi.quartz_stairs
scoreboard objectives remove s.k.us.quartz_slab
scoreboard objectives remove s.k.mi.quartz_slab
scoreboard objectives remove s.k.us.smooth_stone_slab
scoreboard objectives remove s.k.mi.smooth_stone_slab
scoreboard objectives remove s.k.us.sandstone_stairs
scoreboard objectives remove s.k.mi.sandstone_stairs
scoreboard objectives remove s.k.us.sandstone_slab
scoreboard objectives remove s.k.mi.sandstone_slab
scoreboard objectives remove s.k.us.polished_blackstone_brick_stairs
scoreboard objectives remove s.k.mi.polished_blackstone_brick_stairs
scoreboard objectives remove s.k.us.mud_brick_stairs
scoreboard objectives remove s.k.mi.mud_brick_stairs
scoreboard objectives remove s.k.us.nether_brick_stairs
scoreboard objectives remove s.k.mi.nether_brick_stairs
scoreboard objectives remove s.k.us.prismarine_brick_stairs
scoreboard objectives remove s.k.mi.prismarine_brick_stairs
scoreboard objectives remove s.k.us.white_concrete
scoreboard objectives remove s.k.mi.white_concrete
scoreboard objectives remove s.k.us.white_terracotta
scoreboard objectives remove s.k.mi.white_terracotta
scoreboard objectives remove s.k.us.white_stained_glass
scoreboard objectives remove s.k.mi.white_stained_glass
scoreboard objectives remove s.k.us.white_stained_glass_pane
scoreboard objectives remove s.k.mi.white_stained_glass_pane
scoreboard objectives remove s.k.us.white_glazed_terracotta
scoreboard objectives remove s.k.mi.white_glazed_terracotta
scoreboard objectives remove s.k.us.orange_concrete
scoreboard objectives remove s.k.mi.orange_concrete
scoreboard objectives remove s.k.us.orange_terracotta
scoreboard objectives remove s.k.mi.orange_terracotta
scoreboard objectives remove s.k.us.orange_stained_glass
scoreboard objectives remove s.k.mi.orange_stained_glass
scoreboard objectives remove s.k.us.orange_stained_glass_pane
scoreboard objectives remove s.k.mi.orange_stained_glass_pane
scoreboard objectives remove s.k.us.orange_glazed_terracotta
scoreboard objectives remove s.k.mi.orange_glazed_terracotta
scoreboard objectives remove s.k.us.magenta_concrete
scoreboard objectives remove s.k.mi.magenta_concrete
scoreboard objectives remove s.k.us.magenta_terracotta
scoreboard objectives remove s.k.mi.magenta_terracotta
scoreboard objectives remove s.k.us.magenta_stained_glass
scoreboard objectives remove s.k.mi.magenta_stained_glass
scoreboard objectives remove s.k.us.magenta_stained_glass_pane
scoreboard objectives remove s.k.mi.magenta_stained_glass_pane
scoreboard objectives remove s.k.us.magenta_glazed_terracotta
scoreboard objectives remove s.k.mi.magenta_glazed_terracotta
scoreboard objectives remove s.k.us.light_blue_concrete
scoreboard objectives remove s.k.mi.light_blue_concrete
scoreboard objectives remove s.k.us.light_blue_terracotta
scoreboard objectives remove s.k.mi.light_blue_terracotta
scoreboard objectives remove s.k.us.light_blue_stained_glass
scoreboard objectives remove s.k.mi.light_blue_stained_glass
scoreboard objectives remove s.k.us.light_blue_stained_glass_pane
scoreboard objectives remove s.k.mi.light_blue_stained_glass_pane
scoreboard objectives remove s.k.us.light_blue_glazed_terracotta
scoreboard objectives remove s.k.mi.light_blue_glazed_terracotta
scoreboard objectives remove s.k.us.yellow_concrete
scoreboard objectives remove s.k.mi.yellow_concrete
scoreboard objectives remove s.k.us.yellow_terracotta
scoreboard objectives remove s.k.mi.yellow_terracotta
scoreboard objectives remove s.k.us.yellow_stained_glass
scoreboard objectives remove s.k.mi.yellow_stained_glass
scoreboard objectives remove s.k.us.yellow_stained_glass_pane
scoreboard objectives remove s.k.mi.yellow_stained_glass_pane
scoreboard objectives remove s.k.us.yellow_glazed_terracotta
scoreboard objectives remove s.k.mi.yellow_glazed_terracotta
scoreboard objectives remove s.k.us.lime_concrete
scoreboard objectives remove s.k.mi.lime_concrete
scoreboard objectives remove s.k.us.lime_terracotta
scoreboard objectives remove s.k.mi.lime_terracotta
scoreboard objectives remove s.k.us.lime_stained_glass
scoreboard objectives remove s.k.mi.lime_stained_glass
scoreboard objectives remove s.k.us.lime_stained_glass_pane
scoreboard objectives remove s.k.mi.lime_stained_glass_pane
scoreboard objectives remove s.k.us.lime_glazed_terracotta
scoreboard objectives remove s.k.mi.lime_glazed_terracotta
scoreboard objectives remove s.k.us.pink_concrete
scoreboard objectives remove s.k.mi.pink_concrete
scoreboard objectives remove s.k.us.pink_terracotta
scoreboard objectives remove s.k.mi.pink_terracotta
scoreboard objectives remove s.k.us.pink_stained_glass
scoreboard objectives remove s.k.mi.pink_stained_glass
scoreboard objectives remove s.k.us.pink_stained_glass_pane
scoreboard objectives remove s.k.mi.pink_stained_glass_pane
scoreboard objectives remove s.k.us.pink_glazed_terracotta
scoreboard objectives remove s.k.mi.pink_glazed_terracotta
scoreboard objectives remove s.k.us.gray_concrete
scoreboard objectives remove s.k.mi.gray_concrete
scoreboard objectives remove s.k.us.gray_terracotta
scoreboard objectives remove s.k.mi.gray_terracotta
scoreboard objectives remove s.k.us.gray_stained_glass
scoreboard objectives remove s.k.mi.gray_stained_glass
scoreboard objectives remove s.k.us.gray_stained_glass_pane
scoreboard objectives remove s.k.mi.gray_stained_glass_pane
scoreboard objectives remove s.k.us.gray_glazed_terracotta
scoreboard objectives remove s.k.mi.gray_glazed_terracotta
scoreboard objectives remove s.k.us.light_gray_concrete
scoreboard objectives remove s.k.mi.light_gray_concrete
scoreboard objectives remove s.k.us.light_gray_terracotta
scoreboard objectives remove s.k.mi.light_gray_terracotta
scoreboard objectives remove s.k.us.light_gray_stained_glass
scoreboard objectives remove s.k.mi.light_gray_stained_glass
scoreboard objectives remove s.k.us.light_gray_stained_glass_pane
scoreboard objectives remove s.k.mi.light_gray_stained_glass_pane
scoreboard objectives remove s.k.us.light_gray_glazed_terracotta
scoreboard objectives remove s.k.mi.light_gray_glazed_terracotta
scoreboard objectives remove s.k.us.cyan_concrete
scoreboard objectives remove s.k.mi.cyan_concrete
scoreboard objectives remove s.k.us.cyan_terracotta
scoreboard objectives remove s.k.mi.cyan_terracotta
scoreboard objectives remove s.k.us.cyan_stained_glass
scoreboard objectives remove s.k.mi.cyan_stained_glass
scoreboard objectives remove s.k.us.cyan_stained_glass_pane
scoreboard objectives remove s.k.mi.cyan_stained_glass_pane
scoreboard objectives remove s.k.us.cyan_glazed_terracotta
scoreboard objectives remove s.k.mi.cyan_glazed_terracotta
scoreboard objectives remove s.k.us.purple_concrete
scoreboard objectives remove s.k.mi.purple_concrete
scoreboard objectives remove s.k.us.purple_terracotta
scoreboard objectives remove s.k.mi.purple_terracotta
scoreboard objectives remove s.k.us.purple_stained_glass
scoreboard objectives remove s.k.mi.purple_stained_glass
scoreboard objectives remove s.k.us.purple_stained_glass_pane
scoreboard objectives remove s.k.mi.purple_stained_glass_pane
scoreboard objectives remove s.k.us.purple_glazed_terracotta
scoreboard objectives remove s.k.mi.purple_glazed_terracotta
scoreboard objectives remove s.k.us.blue_concrete
scoreboard objectives remove s.k.mi.blue_concrete
scoreboard objectives remove s.k.us.blue_terracotta
scoreboard objectives remove s.k.mi.blue_terracotta
scoreboard objectives remove s.k.us.blue_stained_glass
scoreboard objectives remove s.k.mi.blue_stained_glass
scoreboard objectives remove s.k.us.blue_stained_glass_pane
scoreboard objectives remove s.k.mi.blue_stained_glass_pane
scoreboard objectives remove s.k.us.blue_glazed_terracotta
scoreboard objectives remove s.k.mi.blue_glazed_terracotta
scoreboard objectives remove s.k.us.brown_concrete
scoreboard objectives remove s.k.mi.brown_concrete
scoreboard objectives remove s.k.us.brown_terracotta
scoreboard objectives remove s.k.mi.brown_terracotta
scoreboard objectives remove s.k.us.brown_stained_glass
scoreboard objectives remove s.k.mi.brown_stained_glass
scoreboard objectives remove s.k.us.brown_stained_glass_pane
scoreboard objectives remove s.k.mi.brown_stained_glass_pane
scoreboard objectives remove s.k.us.brown_glazed_terracotta
scoreboard objectives remove s.k.mi.brown_glazed_terracotta
scoreboard objectives remove s.k.us.green_concrete
scoreboard objectives remove s.k.mi.green_concrete
scoreboard objectives remove s.k.us.green_terracotta
scoreboard objectives remove s.k.mi.green_terracotta
scoreboard objectives remove s.k.us.green_stained_glass
scoreboard objectives remove s.k.mi.green_stained_glass
scoreboard objectives remove s.k.us.green_stained_glass_pane
scoreboard objectives remove s.k.mi.green_stained_glass_pane
scoreboard objectives remove s.k.us.green_glazed_terracotta
scoreboard objectives remove s.k.mi.green_glazed_terracotta
scoreboard objectives remove s.k.us.red_concrete
scoreboard objectives remove s.k.mi.red_concrete
scoreboard objectives remove s.k.us.red_terracotta
scoreboard objectives remove s.k.mi.red_terracotta
scoreboard objectives remove s.k.us.red_stained_glass
scoreboard objectives remove s.k.mi.red_stained_glass
scoreboard objectives remove s.k.us.red_stained_glass_pane
scoreboard objectives remove s.k.mi.red_stained_glass_pane
scoreboard objectives remove s.k.us.red_glazed_terracotta
scoreboard objectives remove s.k.mi.red_glazed_terracotta
scoreboard objectives remove s.k.us.black_concrete
scoreboard objectives remove s.k.mi.black_concrete
scoreboard objectives remove s.k.us.black_terracotta
scoreboard objectives remove s.k.mi.black_terracotta
scoreboard objectives remove s.k.us.black_stained_glass
scoreboard objectives remove s.k.mi.black_stained_glass
scoreboard objectives remove s.k.us.black_stained_glass_pane
scoreboard objectives remove s.k.mi.black_stained_glass_pane
scoreboard objectives remove s.k.us.black_glazed_terracotta
scoreboard objectives remove s.k.mi.black_glazed_terracotta
scoreboard objectives remove a.oak_log
scoreboard objectives remove a.spruce_log
scoreboard objectives remove a.birch_log
scoreboard objectives remove a.jungle_log
scoreboard objectives remove a.acacia_log
scoreboard objectives remove a.dark_oak_log
scoreboard objectives remove a.mangrove_log
scoreboard objectives remove a.cherry_log
scoreboard objectives remove a.pale_oak_log
scoreboard objectives remove a.crimson_stem
scoreboard objectives remove a.warped_stem
scoreboard objectives remove a.sneak
scoreboard objectives remove m.quit
scoreboard objectives remove m.dmg
scoreboard objectives remove m.arm
scoreboard objectives remove m.acd
scoreboard objectives remove m.id
scoreboard objectives remove m.dshow
scoreboard objectives remove m.dall
scoreboard objectives remove m.defi
scoreboard objectives remove m.heure
scoreboard objectives remove m.boss
scoreboard objectives remove m.total
scoreboard objectives remove m.b_pr
scoreboard objectives remove m.b_out
scoreboard objectives remove m.b_cd
scoreboard objectives remove m.b_st
scoreboard objectives remove m.dp_b
scoreboard objectives remove m.dd_b
scoreboard objectives remove m.f_pr
scoreboard objectives remove m.f_out
scoreboard objectives remove m.f_cd
scoreboard objectives remove m.f_st
scoreboard objectives remove m.dp_f
scoreboard objectives remove m.dd_f
scoreboard objectives remove m.m_pr
scoreboard objectives remove m.m_out
scoreboard objectives remove m.m_cd
scoreboard objectives remove m.m_st
scoreboard objectives remove m.dp_m
scoreboard objectives remove m.dd_m
scoreboard objectives remove m.c_pr
scoreboard objectives remove m.c_out
scoreboard objectives remove m.c_cd
scoreboard objectives remove m.c_st
scoreboard objectives remove m.dp_c
scoreboard objectives remove m.dd_c
scoreboard objectives remove m.p_pr
scoreboard objectives remove m.p_out
scoreboard objectives remove m.p_cd
scoreboard objectives remove m.p_st
scoreboard objectives remove m.dp_p
scoreboard objectives remove m.dd_p
scoreboard objectives remove m.e_pr
scoreboard objectives remove m.e_out
scoreboard objectives remove m.e_cd
scoreboard objectives remove m.e_st
scoreboard objectives remove m.dp_e
scoreboard objectives remove m.dd_e
scoreboard objectives remove m.n_pr
scoreboard objectives remove m.n_out
scoreboard objectives remove m.n_cd
scoreboard objectives remove m.n_st
scoreboard objectives remove m.dp_n
scoreboard objectives remove m.dd_n
scoreboard objectives remove m.x_pr
scoreboard objectives remove m.x_out
scoreboard objectives remove m.x_cd
scoreboard objectives remove m.x_st
scoreboard objectives remove m.dp_x
scoreboard objectives remove m.dd_x
scoreboard objectives remove m.t_pr
scoreboard objectives remove m.t_out
scoreboard objectives remove m.t_cd
scoreboard objectives remove m.t_st
scoreboard objectives remove m.dp_t
scoreboard objectives remove m.dd_t
scoreboard objectives remove m.k_pr
scoreboard objectives remove m.k_out
scoreboard objectives remove m.k_cd
scoreboard objectives remove m.k_st
scoreboard objectives remove m.dp_k
scoreboard objectives remove m.dd_k
scoreboard objectives remove dq.b1_0
scoreboard objectives remove dq.b2_0
scoreboard objectives remove dq.b3_0
scoreboard objectives remove dq.b4_0
scoreboard objectives remove dq.b5_0
scoreboard objectives remove dq.b6_0
scoreboard objectives remove dq.b6_1
scoreboard objectives remove dq.b7_0
scoreboard objectives remove dq.b8_0
scoreboard objectives remove dq.b8_1
scoreboard objectives remove dq.b8_2
scoreboard objectives remove dq.b8_3
scoreboard objectives remove dq.b8_4
scoreboard objectives remove dq.b8_5
scoreboard objectives remove dq.b8_6
scoreboard objectives remove dq.b8_7
scoreboard objectives remove dq.b8_8
scoreboard objectives remove dq.b8_9
scoreboard objectives remove dq.b8_10
scoreboard objectives remove dq.f1_0
scoreboard objectives remove dq.f2_0
scoreboard objectives remove dq.f3_0
scoreboard objectives remove dq.f4_0
scoreboard objectives remove dq.f5_0
scoreboard objectives remove dq.f6_0
scoreboard objectives remove dq.f7_0
scoreboard objectives remove dq.f8_0
scoreboard objectives remove dq.m1_0
scoreboard objectives remove dq.m2_0
scoreboard objectives remove dq.m3_0
scoreboard objectives remove dq.m3_1
scoreboard objectives remove dq.m4_0
scoreboard objectives remove dq.m4_1
scoreboard objectives remove dq.m5_0
scoreboard objectives remove dq.m5_1
scoreboard objectives remove dq.m6_0
scoreboard objectives remove dq.m6_1
scoreboard objectives remove dq.m7_0
scoreboard objectives remove dq.m8_0
scoreboard objectives remove dq.m8_1
scoreboard objectives remove dq.m9_0
scoreboard objectives remove dq.c1_0
scoreboard objectives remove dq.c2_0
scoreboard objectives remove dq.c3_0
scoreboard objectives remove dq.c4_0
scoreboard objectives remove dq.c5_0
scoreboard objectives remove dq.c6_0
scoreboard objectives remove dq.c7_0
scoreboard objectives remove dq.c8_0
scoreboard objectives remove dq.c9_0
scoreboard objectives remove dq.p1_0
scoreboard objectives remove dq.p2_0
scoreboard objectives remove dq.p3_0
scoreboard objectives remove dq.p4_0
scoreboard objectives remove dq.p5_0
scoreboard objectives remove dq.p6_0
scoreboard objectives remove dq.e1_0
scoreboard objectives remove dq.e2_0
scoreboard objectives remove dq.e3_0
scoreboard objectives remove dq.e4_0
scoreboard objectives remove dq.e5_0
scoreboard objectives remove dq.e6_0
scoreboard objectives remove dq.n1_0
scoreboard objectives remove dq.n2_0
scoreboard objectives remove dq.n3_0
scoreboard objectives remove dq.n4_0
scoreboard objectives remove dq.n5_0
scoreboard objectives remove dq.x1_0
scoreboard objectives remove dq.x2_0
scoreboard objectives remove dq.x3_0
scoreboard objectives remove dq.x3_1
scoreboard objectives remove dq.x4_0
scoreboard objectives remove dq.x5_0
scoreboard objectives remove dq.x6_0
scoreboard objectives remove dq.x7_0
scoreboard objectives remove dq.t1_0
scoreboard objectives remove dq.t2_0
scoreboard objectives remove dq.t3_0
scoreboard objectives remove dq.t4_0
scoreboard objectives remove dq.k1_0
scoreboard objectives remove dq.k1_1
scoreboard objectives remove dq.k1_2
scoreboard objectives remove dq.k1_3
scoreboard objectives remove dq.k1_4
scoreboard objectives remove dq.k1_5
scoreboard objectives remove dq.k1_6
scoreboard objectives remove dq.k1_7
scoreboard objectives remove dq.k1_8
scoreboard objectives remove dq.k1_9
scoreboard objectives remove dq.k1_10
scoreboard objectives remove dq.k1_11
scoreboard objectives remove dq.k2_0
scoreboard objectives remove dq.k2_1
scoreboard objectives remove dq.k2_2
scoreboard objectives remove dq.k2_3
scoreboard objectives remove dq.k3_0
scoreboard objectives remove dq.k3_1
scoreboard objectives remove dq.k3_2
scoreboard objectives remove dq.k3_3
scoreboard objectives remove dq.k3_4
scoreboard objectives remove dq.k3_5
scoreboard objectives remove dq.k3_6
scoreboard objectives remove dq.k3_7
scoreboard objectives remove dq.k3_8
scoreboard objectives remove dq.k3_9
scoreboard objectives remove dq.k3_10
scoreboard objectives remove dq.k3_11
scoreboard objectives remove dq.k3_12
scoreboard objectives remove dq.k3_13
scoreboard objectives remove dq.k3_14
scoreboard objectives remove dq.k3_15
scoreboard objectives remove dq.k3_16
scoreboard objectives remove dq.k3_17
scoreboard objectives remove dq.k4_0
scoreboard objectives remove dq.k4_1
scoreboard objectives remove dq.k4_2
scoreboard objectives remove dq.k4_3
scoreboard objectives remove dq.k4_4
scoreboard objectives remove dq.k4_5
scoreboard objectives remove dq.k4_6
scoreboard objectives remove dq.k4_7
scoreboard objectives remove dq.k4_8
scoreboard objectives remove dq.k4_9
scoreboard objectives remove dq.k4_10
scoreboard objectives remove dq.k4_11
scoreboard objectives remove dq.k4_12
scoreboard objectives remove dq.k4_13
scoreboard objectives remove dq.k4_14
scoreboard objectives remove dq.k4_15
scoreboard objectives remove dq.k5_0
scoreboard objectives remove dq.k5_1
scoreboard objectives remove dq.k5_2
scoreboard objectives remove dq.k5_3
scoreboard objectives remove dq.k5_4
scoreboard objectives remove dq.k5_5
scoreboard objectives remove dq.k5_6
scoreboard objectives remove dq.k5_7
scoreboard objectives remove dq.k5_8
scoreboard objectives remove dq.k5_9
scoreboard objectives remove dq.k5_10
scoreboard objectives remove dq.k5_11
scoreboard objectives remove dq.k5_12
scoreboard objectives remove dq.k5_13
scoreboard objectives remove dq.k5_14
scoreboard objectives remove dq.k6_0
scoreboard objectives remove dq.k6_1
scoreboard objectives remove dq.k6_2
scoreboard objectives remove dq.k6_3
scoreboard objectives remove dq.k7_0
scoreboard objectives remove dq.k7_1
scoreboard objectives remove dq.k7_2
scoreboard objectives remove dq.k7_3
scoreboard objectives remove dq.k7_4
scoreboard objectives remove dq.k7_5
scoreboard objectives remove dq.k7_6
scoreboard objectives remove dq.k7_7
scoreboard objectives remove dq.k7_8
scoreboard objectives remove dq.k7_9
scoreboard objectives remove dq.k7_10
scoreboard objectives remove dq.k7_11
bossbar remove metiers:heure
bossbar remove metiers:boss
tag @a remove metiers.v6
kill @e[tag=metiers.boss]
kill @e[tag=metiers.sbire]
execute in minecraft:overworld run forceload remove 0 0
tag @a remove metiers.v4
tag @a remove metiers.v5
tellraw @s {"text":"[Métiers] Désinstallé. Retire le zip du dossier datapacks puis redémarre.","color":"gold"}
