function metiers:refonte/joueur

# Bûcheron (Double coupe et Charbonnier passent par les sources d'XP, Abattage par le tick)

# Fermier
execute if entity @s[tag=metiers.sk.f2,tag=!metiers.skoff.f2] run function metiers:f/semeur
execute if entity @s[tag=metiers.sk.f3,tag=!metiers.skoff.f3] if score #vingt m.timer matches 0 run effect give @s minecraft:saturation 1 0 true
execute if entity @s[tag=metiers.sk.f4,tag=!metiers.skoff.f4] if score #soixante m.timer matches 0 run function metiers:f/engrais
execute if score @s m.saison matches 1.. run scoreboard players remove @s m.saison 1

# Mineur
execute if entity @s[tag=metiers.sk.m1,tag=!metiers.skoff.m1] if items entity @s weapon.mainhand #minecraft:pickaxes run effect give @s minecraft:haste 2 0 true
execute if entity @s[tag=metiers.sk.m2,tag=!metiers.skoff.m2] if items entity @s weapon.mainhand #minecraft:pickaxes run effect give @s minecraft:haste 2 1 true
execute if entity @s[tag=metiers.sk.m6,tag=!metiers.skoff.m6] if items entity @s weapon.mainhand #minecraft:pickaxes run effect give @s minecraft:haste 2 2 true
execute if entity @s[tag=metiers.sk.m3,tag=!metiers.skoff.m3] run effect give @s minecraft:night_vision 15 0 true
execute if entity @s[tag=metiers.sk.m6,tag=!metiers.skoff.m6,y=-64,dy=64] run effect give @s minecraft:resistance 2 0 true
execute if entity @s[tag=metiers.sk.m5,tag=!metiers.skoff.m5] run function metiers:m/fonte

# Chasseur
attribute @s minecraft:attack_damage modifier remove metiers:c1
attribute @s minecraft:attack_damage modifier remove metiers:c5
execute if entity @s[tag=metiers.sk.c1,tag=!metiers.skoff.c1] run attribute @s minecraft:attack_damage modifier add metiers:c1 1 add_value
execute if entity @s[tag=metiers.sk.c2,tag=!metiers.skoff.c2] if items entity @s weapon.mainhand #metiers:epees run effect give @e[type=#metiers:hostiles,distance=..16] minecraft:glowing 2 0 true
execute if entity @s[tag=metiers.sk.c4,tag=!metiers.skoff.c4] if predicate metiers:nuit run effect give @s minecraft:strength 2 0 true
execute if entity @s[tag=metiers.sk.c4,tag=!metiers.skoff.c4] if predicate metiers:nuit run effect give @s minecraft:speed 2 0 true
execute if entity @s[tag=metiers.sk.c6,tag=!metiers.skoff.c6] if entity @e[type=#metiers:hostiles,distance=..8] run effect give @s minecraft:strength 2 0 true
execute if entity @s[tag=metiers.sk.c6,tag=!metiers.skoff.c6] if entity @e[type=#metiers:hostiles,distance=..8] run effect give @s minecraft:speed 2 0 true

# Pêcheur
attribute @s minecraft:luck modifier remove metiers:p1
attribute @s minecraft:luck modifier remove metiers:p6
execute if entity @s[tag=metiers.sk.p1,tag=!metiers.skoff.p1] run attribute @s minecraft:luck modifier add metiers:p1 2 add_value
execute if entity @s[tag=metiers.sk.p6,tag=!metiers.skoff.p6] run attribute @s minecraft:luck modifier add metiers:p6 3 add_value
execute if entity @s[tag=metiers.sk.p2,tag=!metiers.skoff.p2] if block ~ ~1 ~ minecraft:water run effect give @s minecraft:water_breathing 3 0 true
execute if entity @s[tag=metiers.sk.p4,tag=!metiers.skoff.p4] if block ~ ~ ~ minecraft:water run effect give @s minecraft:dolphins_grace 2 0 true
execute if entity @s[tag=metiers.sk.p6,tag=!metiers.skoff.p6] if block ~ ~ ~ minecraft:water run effect give @s minecraft:conduit_power 3 0 true

# Éleveur
execute if entity @s[tag=metiers.sk.e2,tag=!metiers.skoff.e2] run effect give @e[type=#metiers:animaux,distance=..6] minecraft:regeneration 3 0 true
execute if entity @s[tag=metiers.sk.e4,tag=!metiers.skoff.e4] if score #t m.timer matches 120 run function metiers:e/croissance
execute if entity @s[tag=metiers.sk.e5,tag=!metiers.skoff.e5] if score #soixante m.timer matches 0 run function metiers:e/fertilite
execute if entity @s[tag=metiers.sk.e6,tag=!metiers.skoff.e6] on vehicle run effect give @s minecraft:speed 2 1 true
execute if entity @s[tag=metiers.sk.e6,tag=!metiers.skoff.e6] on vehicle run effect give @s minecraft:jump_boost 2 1 true

# Enchanteur
execute if entity @s[tag=metiers.sk.n2,tag=!metiers.skoff.n2] if score #huit m.timer matches 0 run function metiers:n/renouveau
execute if entity @s[tag=metiers.sk.n3,tag=!metiers.skoff.n3] run function metiers:n/bouclier
execute if entity @s[tag=metiers.sk.n4,tag=!metiers.skoff.n4] run function metiers:n/clignement
execute if entity @s[tag=metiers.sk.n5,tag=!metiers.skoff.n5] run function metiers:n/foudre
execute if score @s m.blcd matches 1.. run scoreboard players remove @s m.blcd 1
execute if score @s m.bscd matches 1.. run scoreboard players remove @s m.bscd 1
execute if score @s m.fdcd matches 1.. run scoreboard players remove @s m.fdcd 1
scoreboard players set @s s.jump 0
scoreboard players set @s s.hit 0

# Explorateur
attribute @s minecraft:step_height modifier remove metiers:x1
attribute @s minecraft:fall_damage_multiplier modifier remove metiers:x3
execute if entity @s[tag=metiers.sk.x1,tag=!metiers.skoff.x1] run attribute @s minecraft:step_height modifier add metiers:x1 0.5 add_value
execute if entity @s[tag=metiers.sk.x2,tag=!metiers.skoff.x2] run effect give @s minecraft:speed 2 0 true
execute if entity @s[tag=metiers.sk.x4,tag=!metiers.skoff.x4] run effect give @s minecraft:speed 2 1 true
execute if entity @s[tag=metiers.sk.x3,tag=!metiers.skoff.x3] run effect give @s minecraft:jump_boost 2 0 true
execute if entity @s[tag=metiers.sk.x3,tag=!metiers.skoff.x3] run attribute @s minecraft:fall_damage_multiplier modifier add metiers:x3 -0.5 add_multiplied_base
execute if entity @s[tag=metiers.sk.x5,tag=!metiers.skoff.x5] if predicate metiers:accroupi run function metiers:x/instinct
execute if entity @s[tag=metiers.sk.x6,tag=!metiers.skoff.x6] run effect give @s minecraft:fire_resistance 3 0 true
execute if entity @s[tag=metiers.sk.x6,tag=!metiers.skoff.x6] run effect give @s minecraft:water_breathing 3 0 true

# Marchand
execute if entity @s[tag=metiers.sk.t2,tag=!metiers.skoff.t2] run effect give @s minecraft:hero_of_the_village 3 0 true
execute if entity @s[tag=metiers.sk.t4,tag=!metiers.skoff.t4] run effect give @s minecraft:hero_of_the_village 3 2 true
execute if entity @s[tag=metiers.sk.t6,tag=!metiers.skoff.t6] run effect give @s minecraft:hero_of_the_village 3 4 true
execute if entity @s[tag=metiers.sk.t5,tag=!metiers.skoff.t5] run function metiers:t/colporteur
function metiers:comp/joueur
# Bâtisseur
attribute @s minecraft:block_interaction_range modifier remove metiers:k1
attribute @s minecraft:block_interaction_range modifier remove metiers:k5
attribute @s minecraft:block_interaction_range modifier remove metiers:pk
attribute @s minecraft:fall_damage_multiplier modifier remove metiers:k2
execute if entity @s[tag=metiers.sk.k1,tag=!metiers.skoff.k1] run attribute @s minecraft:block_interaction_range modifier add metiers:k1 1 add_value
execute if entity @s[tag=metiers.sk.k5,tag=!metiers.skoff.k5] run attribute @s minecraft:block_interaction_range modifier add metiers:k5 2 add_value
execute if entity @s[tag=metiers.sk.k2,tag=!metiers.skoff.k2] run attribute @s minecraft:fall_damage_multiplier modifier add metiers:k2 -0.5 add_multiplied_base
execute if entity @s[tag=metiers.sk.k3,tag=!metiers.skoff.k3] if predicate metiers:accroupi if block ~ ~-1 ~ #minecraft:air if block ~ ~-2 ~ #minecraft:air run effect give @s minecraft:slow_falling 1 0 true
execute if entity @s[tag=metiers.sk.k4,tag=!metiers.skoff.k4,tag=!metiers.sk.k6] run effect give @s minecraft:haste 2 0 true
execute if entity @s[tag=metiers.sk.k6,tag=!metiers.skoff.k6] run effect give @s minecraft:haste 2 1 true
execute if entity @s[tag=metiers.sk.k6,tag=!metiers.skoff.k6] run effect give @s minecraft:resistance 2 0 true
execute if entity @s[tag=metiers.sk.pk5] run attribute @s minecraft:block_interaction_range modifier add metiers:pk 3 add_value
execute if entity @s[tag=metiers.sk.pk3,tag=!metiers.sk.pk5] run attribute @s minecraft:block_interaction_range modifier add metiers:pk 2 add_value
execute if entity @s[tag=metiers.sk.pk1,tag=!metiers.sk.pk3] run attribute @s minecraft:block_interaction_range modifier add metiers:pk 1 add_value
execute if entity @s[tag=metiers.sk.pk3] run effect give @s minecraft:resistance 2 0 true
execute if entity @s[tag=metiers.sk.pk5] run effect give @s minecraft:haste 2 1 true
execute if score @s m.kit matches 1.. run scoreboard players remove @s m.kit 1
